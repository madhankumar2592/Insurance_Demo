/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestClientException;

import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
/**
 * 
 * The class to handle the custom error
 *  
 * @author	Cognizant
 * @version	last updated : Sep 12, 2012 
 * @see  
 *
 */
public class CustomResponseErrorHandler implements ResponseErrorHandler {

	private static Logger LOGGER = LoggerFactory
	.getLogger(CustomResponseErrorHandler.class);

	private ResponseErrorHandler errorHandler = new DefaultResponseErrorHandler();

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void handleError(ClientHttpResponse response) throws IOException, ReferenceDataExceptionVO {
		
		HashMap<String,Object> result = new ObjectMapper().readValue(response.getBody(), HashMap.class); 
		for(Map.Entry e : result.entrySet()){
			LOGGER.info(e.getKey() + " : " + e.getValue());
		}

	    try {     
	        errorHandler.handleError(response);
	    } catch (RestClientException scx) {
//	    	if(result.get("errorObject") != null) {
//	    		((Exception)result.get("errorObject")).printStackTrace();
//	    	}
	        throw new ReferenceDataExceptionVO((String)result.get("errorCode"),
	        		(String)result.get("errorMessage"), result.get("errorObject"));
	    }
	}

	public boolean hasError(ClientHttpResponse response) throws IOException {
	    return errorHandler.hasError(response);
	}
}
