	/*
	 * D&B PROPRIETARY/CONFIDENTIAL.
	 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
	 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
	 */
	package com.dnb.dsc.refdata.web.controller;
	
	import java.io.File;
	import java.io.IOException;
	import java.text.DateFormat;
	import java.text.ParseException;
	import java.text.SimpleDateFormat;
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.Collections;
	import java.util.Comparator;
	import java.util.Date;
	import java.util.HashMap;
	import java.util.Iterator;
	import java.util.LinkedHashMap;
	import java.util.List;
	import java.util.Map;
	import java.util.concurrent.CopyOnWriteArrayList;
	
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpSession;
	
	import org.slf4j.Logger;
	import org.slf4j.LoggerFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.validation.BindingResult;
	import org.springframework.validation.ObjectError;
	import org.springframework.web.bind.annotation.ModelAttribute;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;
	import org.springframework.web.bind.annotation.RequestParam;
	import org.springframework.web.bind.annotation.ResponseBody;
	import org.springframework.web.bind.annotation.SessionAttributes;
	import org.springframework.web.bind.support.SessionStatus;
	import org.springframework.web.multipart.MultipartFile;
	import org.springframework.web.servlet.ModelAndView;
	import org.springframework.web.servlet.View;
	import org.springframework.web.servlet.view.RedirectView;
	
	import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
	import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
	import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
	import com.dnb.dsc.refdata.core.entity.CodeTable;
	import com.dnb.dsc.refdata.core.entity.CodeValue;
	import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
	import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
	import com.dnb.dsc.refdata.core.entity.CodeValueText;
	import com.dnb.dsc.refdata.core.entity.CountryApplicability;
	import com.dnb.dsc.refdata.core.entity.GeographySearch;
	import com.dnb.dsc.refdata.core.entity.SystemApplicability;
	import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
	import com.dnb.dsc.refdata.core.interceptor.TransactionLogger;
	import com.dnb.dsc.refdata.core.util.CommonUtil;
	import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
	import com.dnb.dsc.refdata.core.vo.CodeValueVO;
	import com.dnb.dsc.refdata.core.vo.SCoTSSearchCriteriaVO;
	import com.dnb.dsc.refdata.core.vo.ScotsBulkDowloadVO;
	import com.dnb.dsc.refdata.core.vo.ScotsBulkUploadVO;
	import com.dnb.dsc.refdata.core.vo.UserContextVO;
	import com.dnb.dsc.refdata.core.vo.WorkQueueVO;
	import com.dnb.dsc.refdata.web.proxy.FinancialTemplateWebServiceProxy;
	import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;
	import com.dnb.dsc.refdata.web.proxy.SCoTSWebServiceProxy;
	import com.dnb.dsc.refdata.web.util.UserRoleMapper;
	
	/**
	 * The Controller class for SCoTS Domain. The methods in the class will be
	 * mapped as per the UI requests. The UI front controller will redirect to the
	 * respective methods based on the request and the request parameters.
	 * 
	 * @author Cognizant
	 * @version last updated : Mar 23, 2012
	 * @see
	 * 
	 */
	@Controller
	@SessionAttributes({ "codeTableForView", "codeValue", "scotsSearchCriteriaVO" })
	public class SCoTSController {
	
		@Autowired
		private HomeController homeController;
	
		@Autowired
		private SCoTSWebServiceProxy serviceProxy;
	
		@Autowired
		private GeographyWebServiceProxy geoWsProxy;
	
		@Autowired
		private RefDataConfigUtil refdataConfig;
	
		@Autowired
		private FinancialTemplateWebServiceProxy ftProxy;
	
		@Autowired
		private TransactionLogger transactionLogger;
	
		@Autowired
		private UserRoleMapper roleMapper;
	
		/**
		 * The instance variable for Logging
		 */
		private static final Logger LOGGER = LoggerFactory
				.getLogger(SCoTSController.class);
	
		/**
		 * The constant for the codeTableSearchColumns
		 */
		private final String[] codeTableSearchColumns = { "codeTableId",
				"codeTableName", "businessDescription" };
	
		/**
		 * The constant for the codeValueSearchColumns
		 */
		private final String[] codeValueSearchColumns = { "codeValueId",
				"codeValueDescription", "businessDescription" };
	
		/**
		 * The constant for the searchCodeValueColumns - Search Code Value page
		 */
		private final String[] searchCodeValueColumns = { "codeValueId",
				"codeValueDescription", "codeTableId", "businessDescription",
		"codeTableName" };
	
		/**
		 * 
		 * The method is to search the SCoTs tables. The user will enter the code
		 * table name or description to find the details of a SCoTS Code Table. The
		 * method is invoked on screenLoad of the menu link click.
		 * 
		 * @param session
		 * @return ModelAndView
		 */
		@SuppressWarnings({ "rawtypes" })
		@RequestMapping(value = "/showCodeTableSearch.form", method = RequestMethod.GET)
		public ModelAndView showCodeTableSearch(HttpSession session) {
			LOGGER.info("entering ScotsController | showCodeTableSearch");
			ModelAndView codeTblSearch = new ModelAndView("codeTableSearch");
	
			if (session.getAttribute("systemApplicabilities") == null) {
				List sysAppCodeValueVOs = serviceProxy.retrieveSystemApplicability(
						-1L, 1);
				// Collections.sort(sysAppCodeValueVOs, new MsaCodeComparable());
				session.setAttribute("systemApplicabilities", sysAppCodeValueVOs);
			}
			if (session.getAttribute("countryApplicabilities") == null) {
				List ctryAppCodeValueVOs = serviceProxy
						.retrieveCountryApplicability(-1L, 1);
				// Collections.sort(ctryAppCodeValueVOs, new MsaCodeComparable());
				session.setAttribute("countryApplicabilities", ctryAppCodeValueVOs);
			}
			LOGGER.info("exiting ScotsController | showCodeTableSearch");
			return codeTblSearch;
		}
	
		/**
		 * 
		 * The method is to search the SCoTs tables. The search will be performed on
		 * the staging DB based on the filter conditions. The method will be invoked
		 * when the user clicks on the Search button in the UI.
		 * 
		 * @return
		 */
		@RequestMapping(value = "/codeTableSearchAjaxResults.form", method = RequestMethod.GET)
		public @ResponseBody
		Map<String, Object> getCodeTableSearchAjaxResults(
				HttpServletRequest request, HttpSession session) {
			LOGGER.info("entering ScotsController | getCodeTableSearchAjaxResults");
			Date startTime = new Date();
	
			SCoTSSearchCriteriaVO searchCriteriaVO = getSCoTSSearchCriteriaVO(
					request, true);
	
			// Get the count results from the session. The countResults will be
			// reset for all search button clicks
			Long countCodeTableResults = (Long) session
					.getAttribute("countCodeTableResults");
			if ((countCodeTableResults == null)
					|| (searchCriteriaVO.getRowIndex() == 0)) {
				countCodeTableResults = serviceProxy
						.countSearchCodeTables(searchCriteriaVO);
				session.setAttribute("countCodeTableResults", countCodeTableResults);
			}
	
			List<CodeTable> codeTables = serviceProxy
					.searchCodeTables(searchCriteriaVO);
			session.setAttribute("codeTables", codeTables);
	
			// transaction logging
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"codeTableSearch", 0L, searchCriteriaVO, 0L);
	
			LOGGER.info("exiting ScotsController | getCodeTableSearchAjaxResults");
			return homeController.getJsonMap(request, codeTables,
					countCodeTableResults, codeTableSearchColumns);
		}
	
		/**
		 * 
		 * The method to construct the searchCriteriaVO for the Code Table Search.
		 * The filter string will be set in the request which has to be split as per
		 * the conditions given in the jQuery.
		 * 
		 * @param request
		 * @return searchCriteriaVO
		 */
		private SCoTSSearchCriteriaVO getSCoTSSearchCriteriaVO(
				HttpServletRequest request, Boolean isCodeTable) {
			LOGGER.info("entering ScotsController | getSCoTSSearchCriteriaVO");
	
			SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
			searchCriteriaVO.setSortOrder(homeController.getSortOrder(request));
			searchCriteriaVO.setSortBy(homeController.getSortBy(request,
					isCodeTable ? codeTableSearchColumns : codeValueSearchColumns));
			searchCriteriaVO.setMaxResults(homeController.getMaxResults(request));
			searchCriteriaVO.setRowIndex(homeController.getStartIndex(request));
			String compositeSearchString = homeController.getSearchString(request);
			// Search string will be in the format
			// TblName#~ctryAppy#~SysAppy
			String searchCriteriaDelimiter = "~";
			if (compositeSearchString != null) {
				String[] splitCriteria = compositeSearchString
						.split(searchCriteriaDelimiter);
				if (splitCriteria.length > 0) {
					if (!(splitCriteria[0].replace("#", "").trim().isEmpty())) {
						searchCriteriaVO.setTableDescription(splitCriteria[0]
								.replace("#", "").trim());
					}
				}
				if (splitCriteria.length > 1) {
					if (!(splitCriteria[1].replace("#", "").trim().isEmpty())) {
						searchCriteriaVO.setCountryApplicabilityCode(Long
								.valueOf(splitCriteria[1].replace("#", "").trim()));
					}
				}
				if (splitCriteria.length > 2) {
					if (!(splitCriteria[2].replace("#", "").trim().isEmpty())) {
						searchCriteriaVO.setSystemApplicabilityCode(Long
								.valueOf(splitCriteria[2].replace("#", "").trim()));
					}
				}
				if (splitCriteria.length > 3) {
					if (!(splitCriteria[3].replace("#", "").trim().isEmpty())) {
						searchCriteriaVO.setLanguageCode(Long
								.valueOf(splitCriteria[3].replace("#", "").trim()));
					}
				}
			}
			LOGGER.info("ScotsController | getSCoTSSearchCriteriaVO | searchCriteriaVO : "
					+ searchCriteriaVO);
			LOGGER.info("exiting ScotsController | getSCoTSSearchCriteriaVO");
			return searchCriteriaVO;
		}
	
		/**
		 * This method is to show the SCoTs Tables. The lists are populated from the
		 * staging DB
		 * 
		 * @param model
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "/listCodeTable.form", method = RequestMethod.GET)
		public ModelAndView listCodeTables(Model model, HttpSession session) {
			LOGGER.info("entering SCoTSController | listCodeTable");
	
			ModelAndView listCodeTable = new ModelAndView("listCodeTable");
			List<CodeValueVO> codeTables = getCodeTableList();
			List<CodeValueVO> codeLanguages = getCodeLanguages();
			session.setAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION,
					codeTables);
			session.setAttribute(
					RefDataUIConstants.SCOTS_LIST_CODE_LANGUAGE_SESSION,
					codeLanguages);
			LOGGER.info("exiting SCoTSController | listCodeTable");
			return listCodeTable;
		}
	
		/**
		 * This method will retrieve the Code Table details from the DB. The return
		 * is a VO that contains Code Table ID and Code Table Name.
		 */
		private List<CodeValueVO> getCodeTableList() {
			return this.serviceProxy.retrieveCodeTableList();
		}
	
		/**
		 * This method will retrieve the Code Table details from the DB. The return
		 * is a VO that contains Code Table ID and Code Table Description.
		 */
		private List<CodeValueVO> getCodeLanguages() {
			return this.serviceProxy.retrieveCodeLanguages();
		}
	
		/**
		 * 
		 * The method will retrieve all systems applicable from the Search DB based
		 * on the code table selected by the user. The return type is a VO which
		 * contains the system code and description .
		 * 
		 * @param codeTableId
		 * @param session
		 * @return systemsList
		 */
		@RequestMapping(value = "retrieveSystemApplicabilityAjaxResults.form", method = RequestMethod.GET)
		public @ResponseBody
		List<CodeValueVO> retrieveSystemApplicability(
				@RequestParam(value = "codeTableId") Long codeTableId, Model model,
				HttpSession session) {
			LOGGER.info("entering SCoTSController | retrieveSystemApplicability");
			Date startTime = new Date();
	
			List<CodeValueVO> systemsList = this.serviceProxy
					.retrieveSystemApplicability(codeTableId, 0);
			session.setAttribute("systemApplicabilityList", systemsList);
	
			// transaction logging
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			transactionLogger
			.log(startTime, userContextVO.getUserIdentifier(), roleMapper
					.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"retrieveSystemApplicability", 0L, codeTableId, 0L,
					systemsList);
	
			LOGGER.info("exiting SCoTSController | retrieveSystemApplicability | returned : "
					+ systemsList);
			return systemsList;
		}
	
		/**
		 * The method will retrieve all Countries applicable from the Search DB
		 * based on the code table selected by the user. The return type is a VO
		 * which contains the country code and country .
		 * 
		 * @param codeTableId
		 */
		@RequestMapping(value = "retrieveCountryApplicabilityAjaxResults.form", method = RequestMethod.GET)
		public @ResponseBody
		List<CodeValueVO> retrieveCountryApplicability(
				@RequestParam(value = "codeTableId") Long codeTableId) {
			LOGGER.info("entering SCoTSController | retrieveCountryApplicability.form");
			return this.serviceProxy.retrieveCountryApplicability(codeTableId, 0);
		}
	
		/**
		 * 
		 * The method is to search the SCoTs table values. The search will be
		 * performed on the staging DB based on the filter conditions. The method
		 * will be invoked when the user clicks on the Search button in the UI.
		 * 
		 * @return
		 */
		@RequestMapping(value = "/codeValueSearchAjaxResults.form", method = RequestMethod.GET)
		public @ResponseBody
		Map<String, Object> getCodeValueSearchAjaxResults(
				HttpServletRequest request, HttpSession session) {
			LOGGER.info("entering ScotsController | getCodeValueSearchAjaxResults");
			Date startTime = new Date();
	
			SCoTSSearchCriteriaVO searchCriteriaVO = getSCoTSSearchCriteriaVO(
					request, false);
	
			if (searchCriteriaVO.getTableDescription() == null) {
				return homeController.getJsonMap(request, new ArrayList<Object>(),
						0L, codeValueSearchColumns);
			}
	
			// Get the count results from the session. The countResults will be
			// reset for all search button clicks
			Long countCodeValueResults = (Long) session
					.getAttribute("countCodeValueResults");
			if ((countCodeValueResults == null)
					|| (searchCriteriaVO.getRowIndex() == 0)) {
				countCodeValueResults = serviceProxy
						.countCodeValuesByTableId(searchCriteriaVO);
				session.setAttribute("countCodeValueResults", countCodeValueResults);
			}
	
			List<CodeValue> codeValues = serviceProxy
					.searchCodeValues(searchCriteriaVO);
			session.setAttribute("codeValues", codeValues);
	
			// transaction logging
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"codeValueSearch", 0L, searchCriteriaVO, 0L);
	
			return homeController.getJsonMap(request, codeValues,
					countCodeValueResults, codeValueSearchColumns);
		}
	
		/**
		 * 
		 * The method to populate the code table details in List Code Table page
		 * 
		 * @param codeTableId
		 * @return codeTableDetails
		 */
		@RequestMapping(value = "/getCodeTableDescriptionAjaxResults.form", method = RequestMethod.GET)
		public @ResponseBody
		String[] retrieveCodeTableById(
				@RequestParam(value = "codeTableId") String codeTableId,
				HttpSession session) {
			LOGGER.info("entering ScotsController | getCodeTableDescriptionAjaxResults ");
			Date startTime = new Date();
	
			String[] codeTableDetails = new String[4];
			CodeTable codeTable = serviceProxy.retrieveCodeTableById(Long
					.valueOf(codeTableId));
			codeTableDetails[0] = codeTable.getCodeTableId().toString();
			codeTableDetails[1] = codeTable.getCodeTableName().toString();
			codeTableDetails[2] = codeTable.getBusinessDescription().toString();
			codeTableDetails[3] = CommonUtil.convertDate(codeTable
					.getEffectiveDate());
	
			// transaction logging
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"retrieveCodeTableById", 0L, codeTableId, 0L, Arrays
					.toString(codeTableDetails));
	
			LOGGER.info("exiting ScotsController | getCodeTableDescriptionAjaxResults | returned : "
					+ codeTable);
			return codeTableDetails;
		}
	
		/**
		 * 
		 * The method is to search the SCoTs values. The user will enter the code
		 * value name or description to find the details of a SCoTS Code Value. The
		 * method is invoked on screenLoad of the menu link click.
		 * 
		 * @param session
		 * @return ModelAndView
		 */
		@RequestMapping(value = "/searchCodeValue.form", method = RequestMethod.GET)
		public ModelAndView searchCodeValue(HttpSession session) {
			LOGGER.info("entering ScotsController | searchCodeValue");
			ModelAndView searchCodeTableView = new ModelAndView("codeValueSearch");
			session.setAttribute("searchCodeTableLanguages", getCodeLanguages());
			return searchCodeTableView;
		}
	
		/**
		 * 
		 * This method is invoked by dataTables plug-in through ajax calls. Response
		 * is provided in JSON format. The method is invoked from the Code Value
		 * Search page.
		 * 
		 */
		@RequestMapping(value = "/codeValueDescSearchAjaxResults.form", method = RequestMethod.GET)
		public @ResponseBody
		Map<String, Object> getCodeValueDescSearchAjaxResults(
				HttpServletRequest request, HttpSession session) {
			LOGGER.info("entering ScotsController | getCodeValueDescSearchAjaxResults");
			Date startTime = new Date();
	
			String searchString = homeController.getSearchString(request);
			// return if no search filter condition
			if (searchString == null || searchString.trim().isEmpty()) {
				return homeController.getJsonMap(request,
						new ArrayList<GeographySearch>(), 0L,
						searchCodeValueColumns);
			}
	
			SCoTSSearchCriteriaVO searchCriteriaVO = getSearchCodeValueFilterCriteria(request);
	
			Long countCodeResults = (Long) session
					.getAttribute("countScotsCodeValueResults");
			if (countCodeResults == null || searchCriteriaVO.getRowIndex() == 0) {
				countCodeResults = serviceProxy
						.countOfSearchCodeValues(searchCriteriaVO);
				session.setAttribute("countScotsCodeValueResults", countCodeResults);
			}
	
			// transaction logging
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"codeValueDescSearchResults", 0L, searchCriteriaVO, 0L);
	
			LOGGER.info("exiting ScotsController | getCodeValueDescSearchAjaxResults");
			return homeController.getJsonMap(request,
					serviceProxy.searchSCoTSCodeValues(searchCriteriaVO),
					countCodeResults, searchCodeValueColumns);
		}
	
		/**
		 * 
		 * The method to retrieve the searchCriteriaVO for the Search Code Value
		 * page
		 * 
		 * @param request
		 * @return searchCriteriaVO
		 */
		private SCoTSSearchCriteriaVO getSearchCodeValueFilterCriteria(
				HttpServletRequest request) {
			SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
			searchCriteriaVO.setSortOrder(homeController.getSortOrder(request));
			searchCriteriaVO.setSortBy(homeController.getSortBy(request,
					searchCodeValueColumns));
			searchCriteriaVO.setMaxResults(homeController.getMaxResults(request));
			searchCriteriaVO.setRowIndex(homeController.getStartIndex(request));
			String compositeSearchString = homeController.getSearchString(request);
			// Search string will be in the format
			// CodeDesc#~radioBtnName#~LangCode
			String searchCriteriaDelimiter = "#~";
			if (compositeSearchString != null) {
				String[] splitCriteria = compositeSearchString
						.split(searchCriteriaDelimiter);
				if (splitCriteria.length > 0) {
					if ("codeValue".equals(splitCriteria[1])) {
						searchCriteriaVO.setCodeValueId(Long
								.valueOf(splitCriteria[0].trim()));
	
					} else if ("codeValueDesc".equals(splitCriteria[1])) {
						searchCriteriaVO.setCodeValueDescription(splitCriteria[0]
								.trim());
	
					} else {
						searchCriteriaVO
						.setCodeValueBusinessDescription(splitCriteria[0]
								.trim());
					}
				}
				if (splitCriteria.length > 2) {
					if (!(splitCriteria[2].trim().isEmpty())) {
						searchCriteriaVO.setLanguageCode(Long
								.valueOf(splitCriteria[2].trim()));
					}
				}
			}
	
			LOGGER.info("exiting ScotsController | getSearchCodeValueFilterCriteria "
					+ "| searchCriteriaVO : " + searchCriteriaVO);
			return searchCriteriaVO;
		}
	
		/**
		 * Views the SCoTs Code Value. The Lists are being populated from Staging
		 * DB.
		 * <p>
		 * 
		 * @param codeValueId
		 * @param model
		 * @param session
		 * @return codeValueView, the ModelAndView
		 */
		@SuppressWarnings({ "rawtypes", "unchecked" })
		@RequestMapping(value = "/codeValueView.form", method = RequestMethod.GET)
		public ModelAndView codeValueView(
				@RequestParam("codeValueId") final String codeValueId,
				@RequestParam("taskId") final String taskId,
				@RequestParam("changeTypeId") final String changeTypeId,
				@RequestParam("search") final String search, Model model,
				HttpSession session) {
			LOGGER.info("entering ScotsController | codeValueView");
			Date startTime = new Date();
	
			ModelAndView codeValueView = new ModelAndView("codeValueView");
			codeValueView.addObject("taskId", taskId);
			session.setAttribute("taskId", taskId);
			model.addAttribute("search", search);
	
			CodeValue codeValue = null;
			LOGGER.info("ScotsController | codeValueView | taskId : " + taskId);
			if ((taskId != null) && !taskId.trim().isEmpty()) {
				codeValue = serviceProxy.reviewCodeValueChanges(Long
						.valueOf(codeValueId));
			} else {
				codeValue = serviceProxy.retrieveCodeValueByCodeValueId(Long
						.valueOf(codeValueId));
			}
	
			// Retrieving the Lists for currency Code and Data Provider
			List<Integer> codeTableIds = new ArrayList<Integer>();
			codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
			codeTableIds
			.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE);
			codeTableIds
			.add(RefDataPropertiesConstants.CODE_TABLE_ID_CODING_SCHEME);
	
			Map<String, List<CodeValue>> tempCodeValueMap = homeController
					.retrieveCodeValues(codeTableIds);
	
			List codeValues = tempCodeValueMap
					.get(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE_STRING);
			// sort the codeValues based on the Code Value Id
			Collections.sort(codeValues, new CodeValueIdComparable());
	
			List codingSchemes = tempCodeValueMap
					.get(RefDataPropertiesConstants.CODE_TABLE_ID_CODING_SCHEME_STRING);
			// sort the codeValues based on the Code Value Id
			Collections.sort(codingSchemes, new CodeValueIdComparable());
			List languageCodeValues = tempCodeValueMap.get(String
					.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE));
			// sort the list of languages and add to model
			Collections.sort(languageCodeValues, new CodeValueIdComparable());
			session.setAttribute(
					RefDataUIConstants.SCOTS_LIST_CODE_LANGUAGE_SESSION,
					languageCodeValues);
			if(changeTypeId != null){
				codeValueView.addObject("changeTypeId",changeTypeId);
			}
			codeValueView.addObject("languageCodeValues", languageCodeValues);
			codeValueView.addObject(
					RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION,
					getCodeTableList());
			codeValueView.addObject("codeValues", codeValues);
			codeValueView.addObject("codingSchemes", codingSchemes);
			codeValueView.addObject("codeValue", codeValue);
	
			codeValueView.addObject("allSystems",
					serviceProxy.retrieveSystemApplicability(Long.valueOf(-1), 0));
			codeValueView
			.addObject(
					"allCountries",
					geoWsProxy
					.retrieveAllCountries(
							RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
							RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));
			session.setAttribute("taskId", taskId);
	
			// transaction logging
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS, "codeValueView",
					0L, codeValueId, 0L, codeValue);
	
			LOGGER.info("exiting ScotsController | codeValueView | returned :"
					+ codeValue);
			return codeValueView;
		}
	
		/**
		 * 
		 * The Comparator class will sort the CodeValue based on the codeValueId
		 * 
		 * @author Cognizant
		 * @version last updated : Mar 12, 2012
		 * @see
		 * 
		 */
		@SuppressWarnings("rawtypes")
		public class CodeValueIdComparable implements Comparator<LinkedHashMap> {
	
			@Override
			public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
				return ((Integer) codeValue1.get("codeValueId"))
						.compareTo((Integer) codeValue2.get("codeValueId"));
			}
		}
	
		/**
		 * This method is to view the SCoTs Code Table. The lists are populated from
		 * the staging DB
		 * 
		 * @param codeTableId
		 * @param model
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "/codeTableView.form", method = RequestMethod.GET)
		public ModelAndView codeTableView(
				@RequestParam(value = "codeTableId") final String codeTableId,
				@RequestParam("taskId") final String taskId,
				@RequestParam("search") final String search, Model model,
				HttpSession session) {
			LOGGER.info("entering ScotsController | codeTableView");
			Date startTime = new Date();
	
			ModelAndView codeTableView = new ModelAndView("codeTableView");
	
			codeTableView.addObject("taskId", taskId);
			model.addAttribute("search", search);
			CodeTable codeTable = null;
			if ((taskId != null) && !taskId.trim().isEmpty()) {
				codeTable = serviceProxy.reviewCodeTableChanges(Long
						.valueOf(codeTableId));
			} else {
				codeTable = serviceProxy.retrieveCodeTableById(Long
						.valueOf(codeTableId));
			}
			LOGGER.info("ScotsController | codeTableView | codeTable: " + codeTable);
			model.addAttribute("codeTableForView", codeTable);
	
			codeTableView.addObject("codeTableIdAndName", codeTableId + " ["
					+ codeTable.getCodeTableName() + "]");
			codeTableView.addObject("allSystems",
					serviceProxy.retrieveSystemApplicability(Long.valueOf(-1), 0));
			codeTableView
			.addObject(
					"allCountries",
					geoWsProxy
					.retrieveAllCountries(
							RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
							RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));
			codeTableView.addObject("today", new Date());
			session.setAttribute("taskId", taskId);
	
			// transaction logging
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS, "codeTableView",
					0L, codeTableId, 0L, codeTable);
	
			LOGGER.info("exiting ScotsController | codeTableView ");
			return codeTableView;
		}
	
		/**
		 * The method will persist the edited code table in the Transactional DB.
		 * Only the changed relational data will be inserted. The service method
		 * need to perform validation to identify the records which have been
		 * updated from the UI.
		 * 
		 * @param codeTable
		 *            model attribute
		 * @return View
		 * @throws ParseException
		 */
	
		@RequestMapping(value = "/updateCodeTable.form", method = RequestMethod.POST)
		public View updateCodeTable(
				@ModelAttribute("codeTableForView") CodeTable codeTable,
				Model model, SessionStatus sessionStatus, HttpSession session,
				HttpServletRequest request) throws ParseException {
			LOGGER.info("entering ScotsController | updateCodeTable");
			// audit variables
			Date startTime = new Date();
	
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			String loggedInUser = userContextVO.getUserIdentifier();
			codeTable.setModifiedUser(userContextVO.getUserIdentifier());
			codeTable.setModifiedDate(new Date());
			List<SystemApplicability> finalSystemUpdateList = new ArrayList<SystemApplicability>();
			int systemFlag = 0;
			int countryFlag = 0;
			List<String> systemList = codeTable.getSystemList();
			List<SystemApplicability> initialSystems = codeTable
					.getSystemApplicability();
	
			LOGGER.info("ScotsController | updateCodeTable | initial systems:"
					+ initialSystems);
			if (initialSystems != null) {
				if (systemList == null) {
					// all systems have been removed
					for (SystemApplicability systems : initialSystems) {
						systems.setExpirationDate(new Date());
						finalSystemUpdateList.add(systems);
					}
				}
				if (systemList != null && !(systemList.isEmpty())) {
					for (SystemApplicability systems : initialSystems) {
						for (String updateSystemList : systemList) {
							if (systems.getDnbSystemCode().toString()
									.equals(updateSystemList)) {
								systemFlag = 1;
								break;
							}
						}
						if (systemFlag == 1) {
							systemList
							.remove(systems.getDnbSystemCode().toString());
							systemFlag = 0;
						} else {
							systems.setExpirationDate(new Date());
							finalSystemUpdateList.add(systems);
						}
					}
				}
			}
			if (systemList != null && !(systemList.isEmpty())) {
				for (String updateSystemList : systemList) {
					SystemApplicability newSystem = new SystemApplicability();
					newSystem.setApplicabilityIndicator(1);
					newSystem.setCodeTableId(codeTable.getCodeTableId());
					newSystem.setDnbSystemCode(Long.valueOf(updateSystemList));
					newSystem.setCodeValueId(null);
					finalSystemUpdateList.add(newSystem);
				}
			}
			LOGGER.info("ScotsController | updateCodeTable | updated systems in list are: "
					+ finalSystemUpdateList);
			List<String> countryList = codeTable.getCountryList();
			List<CountryApplicability> initialCountries = codeTable
					.getCountryApplicability();
			List<CountryApplicability> finalCountryUpdateList = new ArrayList<CountryApplicability>();
	
			if (initialCountries != null) {
				if (countryList == null) {
					// all countries have been removed
					for (CountryApplicability countries : initialCountries) {
						countries.setExpirationDate(new Date());
						finalCountryUpdateList.add(countries);
					}
				}
				if (countryList != null && !countryList.isEmpty()) {
					for (CountryApplicability countries : initialCountries) {
						for (String updateCountryList : countryList) {
							LOGGER.info("ScotsController | updateCodeTable | "
									+ "comparing ||"
									+ countries.getCountryGeoUnitId() + " with "
									+ updateCountryList);
							if (Long.valueOf(countries.getCountryGeoUnitId())
									.compareTo(Long.valueOf(updateCountryList)) == 0) {
								countryFlag = 1;
								break;
							}
						}
						if (countryFlag == 1) {
							countryList.remove(countries.getCountryGeoUnitId()
									.toString());
							countryFlag = 0;
						} else {
							countries.setExpirationDate(new Date());
							finalCountryUpdateList.add(countries);
						}
					}
				}
			}
			if (countryList != null && !countryList.isEmpty()) {
				for (String updateCountryList : countryList) {
					CountryApplicability newCountry = new CountryApplicability();
					newCountry.setCodeTableId(codeTable.getCodeTableId());
					newCountry.setCountryGeoUnitId(Long.valueOf(updateCountryList));
					newCountry.setApplicabilityIndicator(1);
					newCountry.setCodeValueId(null);
					finalCountryUpdateList.add(newCountry);
				}
			}
	
			codeTable.setSystemApplicability(finalSystemUpdateList);
			prepareSystemApplicability(codeTable, loggedInUser);
			codeTable.setCountryApplicability(finalCountryUpdateList);
			prepareCountryApplicability(codeTable, loggedInUser);
	
			LOGGER.info("ScotsController | updateCodeTable | updated countries in list are: "
					+ codeTable.getCountryApplicability());
			Long trackingId = serviceProxy.updateCodeTable(codeTable);
			LOGGER.info("ScotsController | updateCodeTable | updated code table with id: "
					+ trackingId);
	
			String taskId = (String) session.getAttribute("taskId");
			if ((taskId != null) && !taskId.trim().isEmpty()) {
				homeController.reSubmitTaskRequest(userContextVO, taskId,
						RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
						RefDataPropertiesConstants.SCOTS_CODE_SUBMITTER_GROUP_ID);
			} else {
				createSCoTSWorkflowTask(trackingId.toString(),
						RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_CODE_TABLE,
						loggedInUser, codeTable.getReasonText());
			}
			sessionStatus.setComplete();
			session.removeAttribute("taskId");
	
			// transaction logging
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"updateCodeTable", 0L, trackingId, 0L, codeTable);
	
			LOGGER.info("exiting ScotsController | updateCodeTable");
			return new RedirectView("submitterWorkQueueHome.form?domainName=SCoTS");
		}
	
		/**
		 * 
		 * The method will validate the Code Table for any locks (If already been
		 * opened by any other user for edit). If no lock is currently available
		 * then the method will lock the record and return FALSE indicating no lock
		 * currently. But if a lock already exists, the method will return TRUE. The
		 * lock operation will be performed in the Transactional DB.
		 * 
		 * @param codeTable
		 * @return boolean
		 */
		@RequestMapping(value = "lockCodeTableForEdit.form", method = RequestMethod.GET)
		public @ResponseBody
		String lockCodeTable(
				@ModelAttribute("codeTableForView") CodeTable codeTable,
				HttpSession session) {
			LOGGER.info("entering ScotsController | lockCodeTable");
			if (((String) session.getAttribute("taskId")).length() > 0) {
				return "false";
			} else {
				Long lockCodeTableId = codeTable.getCodeTableId();
				return this.serviceProxy.lockCodeTable(lockCodeTableId);
			}
		}
	
		/**
		 * 
		 * The method will validate the Code Value for any locks (If already been
		 * opened by any other user for edit). If no lock is currently available
		 * then the method will lock the record and return FALSE indicating no lock
		 * currently. But if a lock already exists, the method will return TRUE. The
		 * lock operation will be performed in the Transactional DB.
		 * 
		 * @param codeTable
		 * @return boolean
		 */
		@RequestMapping(value = "lockCodeValueForEdit.form", method = RequestMethod.GET)
		public @ResponseBody
		String lockCodeValue(@ModelAttribute("codeValue") CodeValue codeValue,
				HttpSession session) {
			LOGGER.info("entering  ScotsController | lockCodeValue | " + codeValue);
			if (((String) session.getAttribute("taskId")).length() > 0) {
				return "false";
			} else {
				return this.serviceProxy.lockCodeValue(codeValue.getCodeValueId());
			}
		}
	
		/**
		 * 
		 * The method will validate the Code Value Alternate Scheme Code for any
		 * locks (If already been opened by any other user for edit). If no lock is
		 * currently available then the method will lock the record and return FALSE
		 * indicating no lock currently. But if a lock already exists, the method
		 * will return TRUE. The lock operation will be performed in the
		 * Transactional DB.
		 * 
		 * @param codeTable
		 * @return boolean
		 */
		@RequestMapping(value = "lockAltSchemeCodeForEdit.form", method = RequestMethod.GET)
		public @ResponseBody
		String lockAltSchemeCode(
				@RequestParam(value = "schemeCode") final Long schemeCode,
				HttpSession session) {
			LOGGER.info("entering  ScotsController | lockAltSchemeCode | schemeCode :"
					+ schemeCode);		
			if ((String) session.getAttribute("taskId") == null) {
				return "false";
			} else {
				return this.serviceProxy.lockAltSchemeCode(schemeCode);
			}
	
		}
	
		/**
		 * 
		 * The method to display the Manage SCoTS Relationship JSP. The method will
		 * be invoked on click of the Relationship page from the menu.
		 * 
		 * @param session
		 * @return codeAssnView
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "/manageCodeRelationship.form", method = RequestMethod.GET)
		public ModelAndView manageCodeRelationship(HttpSession session, Model model) {
			LOGGER.info("entering ScotsController | manageCodeRelationship");
	
			ModelAndView codeAssnView = new ModelAndView("codeRelationshipView");
			List codeTables = null;
			if (session
					.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION) == null) {
				codeTables = getCodeTableList();
			} else {
				codeTables = (List) session
						.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION);
			}
			Collections.sort(codeTables, new MsaCodeComparable());
			session.setAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION,
					codeTables);
			session.setAttribute("prntCodeTableList", codeTables);
			session.setAttribute("chldCodeTableList", codeTables);
	
			session.setAttribute("prntCdTblToggleIndicator", "");
			session.setAttribute("chldCdTblToggleIndicator", "");
			model.addAttribute("scotsSearchCriteriaVO", new SCoTSSearchCriteriaVO());
	
			LOGGER.info("exiting ScotsController | manageCodeRelationship");
			return codeAssnView;
		}
	
		/**
		 * The method to retrieve all codeValue associations from database. The
		 * method will accept the parent and child code table Id s and will return
		 * all associations having the relationship between the specified parent and
		 * child code tables.
		 * 
		 * @param parentCodeTableId
		 * @param childCodeTableId
		 * @param model
		 * @return ModelAndView
		 */
		@RequestMapping(value = "/retrieveCodeRelationship.form", method = RequestMethod.GET)
		public ModelAndView retrieveCodeRelationship(
				@RequestParam(value = "parentCodeTableId") Long parentCodeTableId,
				@RequestParam(value = "childCodeTableId") Long childCodeTableId,
				@RequestParam(value = "taskId") Long taskId,
				@RequestParam(value = "isStagingDB") Boolean isStagingDB,
				Model model, HttpSession session) {
			LOGGER.info("entering ScotsController | retrieveCodeRelationship");
			// audit variables
			Date startTime = new Date();
	
			ModelAndView codeAssnView = new ModelAndView("codeRelationshipView");
			codeAssnView.addObject("taskId", taskId);
			session.setAttribute("codeRelTaskId", taskId);
			
			/*Added To fix bug in Approver queue*/
			List codeTables = getCodeTableList();				
			codeAssnView.addObject("prntCodeTableList", codeTables);
			codeAssnView.addObject("chldCodeTableList", codeTables);
		
			
			
			List<CodeValueAssociation> codeValueAssociations = getCodeValueAssnsFromLinkedMap(serviceProxy
					.retrieveCodeValueAssociations(parentCodeTableId,
							childCodeTableId, isStagingDB).iterator());
			LOGGER.info("ScotsController | retrieveCodeRelationship | codeValueAssociations : "
					+ codeValueAssociations);
	
	
			// if code value association is empty or null then add an empty
			// association for display
			if (codeValueAssociations == null || codeValueAssociations.size() == 0) {
				codeAssnView.addObject("addNewAssociations", "true");
				codeValueAssociations = new ArrayList<CodeValueAssociation>();
				codeValueAssociations.add(new CodeValueAssociation());
			}
			// setting the model attribute
			SCoTSSearchCriteriaVO criteriaVO = new SCoTSSearchCriteriaVO();
			criteriaVO.setCodeValueAssociations(codeValueAssociations);
			criteriaVO.setParentCodeTableId(parentCodeTableId);
			criteriaVO.setChildCodeTableId(childCodeTableId);
			model.addAttribute("scotsSearchCriteriaVO", criteriaVO);
	
	
	
			// retrieve the respective code values for the selected code tables
			retrieveCodeValuesForRelationship(parentCodeTableId, childCodeTableId,
					codeAssnView);
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			// transaction logging
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"retrieveCodeRelationship", 0L, codeValueAssociations, 0L,
					parentCodeTableId, childCodeTableId);
	
			LOGGER.info("exiting ScotsController | retrieveCodeRelationship");
	
			return codeAssnView;
		}
	
		/**
		 * 
		 * The method to retrieve the codeValues for the codeTableId
		 * 
		 * @param parentCodeTableId
		 * @param childCodeTableId
		 * @param codeAssnView
		 * @return map
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		private void retrieveCodeValuesForRelationship(Long parentCodeTableId,
				Long childCodeTableId, ModelAndView codeAssnView) {
			// Retrieving the Lists for currency Code and Data Provider
			List<Integer> codeTableIds = new ArrayList<Integer>();
			codeTableIds.add(parentCodeTableId.intValue());
			codeTableIds.add(childCodeTableId.intValue());
	
			Map<String, List<CodeValue>> tempCodeValueMap = homeController
					.retrieveCodeValues(codeTableIds);
	
			List parentCodeValues = tempCodeValueMap.get(String
					.valueOf(parentCodeTableId));
			if (parentCodeValues != null) {
				Collections.sort(parentCodeValues, new MsaCodeValueIdComparable());
				codeAssnView.addObject("parentCodeValues", parentCodeValues);
			}
			List childCodeValues = tempCodeValueMap.get(String
					.valueOf(childCodeTableId));
			if (childCodeValues != null) {
				Collections.sort(childCodeValues, new MsaCodeValueIdComparable());
				codeAssnView.addObject("childCodeValues", childCodeValues);
			}
		}
	
		/**
		 * 
		 * The method to transform the list of LinkedHashMap to the list of
		 * CodeValueAssociations. The JSON will return the list as LinkedHashMap.
		 * 
		 * @param itr
		 * @return associations
		 */
		@SuppressWarnings("rawtypes")
		private List<CodeValueAssociation> getCodeValueAssnsFromLinkedMap(
				Iterator itr) {
			List<CodeValueAssociation> associations = new ArrayList<CodeValueAssociation>();
	
			while (itr.hasNext()) {
	
				LinkedHashMap assn = (LinkedHashMap) itr.next();
				CodeValueAssociation codeValueAssociation = new CodeValueAssociation();
				codeValueAssociation.setCodeValueAssociationId(Long
						.valueOf((Integer) assn.get("codeValueAssociationId")));
				codeValueAssociation.setParentCodeValueId(Long
						.valueOf((Integer) assn.get("parentCodeValueId")));
				codeValueAssociation.setChildCodeValueId(Long
						.valueOf((Integer) assn.get("childCodeValueId")));
				DateFormat df = new SimpleDateFormat(
						RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT);
				try {
					codeValueAssociation.setEffectiveDate(((String) assn
							.get("effectiveDate")) != null ? df.parse((String) assn
									.get("effectiveDate")) : null);
					codeValueAssociation.setExpirationDate(((String) assn
							.get("expirationDate")) != null ? df
									.parse((String) assn.get("expirationDate")) : null);
	
					Object createdDtObj = assn.get("createdDate");
					if (createdDtObj instanceof String) {
						codeValueAssociation.setCreatedDate(((String) assn
								.get("createdDate")) != null ? df
										.parse((String) assn.get("createdDate")) : null);
					} else if (createdDtObj instanceof Long) {
						codeValueAssociation.setCreatedDate(((Long) assn
								.get("createdDate")) != null ? new Date((Long) assn
										.get("createdDate")) : null);
					}
					Object modifiedDtObj = assn.get("modifiedDate");
					if (modifiedDtObj instanceof String) {
						codeValueAssociation.setModifiedDate(((String) assn
								.get("modifiedDate")) != null ? df
										.parse((String) assn.get("modifiedDate")) : null);
					} else if (modifiedDtObj instanceof Long) {
						codeValueAssociation.setModifiedDate(((Long) assn
								.get("modifiedDate")) != null ? new Date(
										(Long) assn.get("modifiedDate")) : null);
					}
				} catch (ParseException e) {
					LOGGER.error("Parse Exception occurred : ", e);
					;
				}
				codeValueAssociation.setCreatedUser((String) assn
						.get("createdUser"));
				codeValueAssociation.setModifiedUser((String) assn
						.get("modifiedUser"));
				associations.add(codeValueAssociation);
			}
	
			return associations;
		}
	
		/**
		 * 
		 * The method to toggle the Parent Code Table drop down values
		 * 
		 * @param toggleIndicator
		 * @param session
		 * @return model
		 * @return codeValues
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "toggleCodeTables.form", method = RequestMethod.GET)
		public @ResponseBody
		List<CodeValue> toggleCodeTables(
				@RequestParam(value = "toggleIndicator", required = true) String toggleIndicator,
				HttpSession session, Model model) {
			LOGGER.info("toggleIndicator : " + toggleIndicator);
	
			List codeValues = new ArrayList(
					(List) session
					.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION));
	
			if (codeValues != null) {
				if (RefDataUIConstants.TOGGLE_INDICATOR_CODE
						.equals(toggleIndicator)) {
					Collections.sort(codeValues, new MsaCodeComparable());
					model.addAttribute("toggleIndicator",
							RefDataUIConstants.TOGGLE_INDICATOR_VALUE);
	
				} else if (RefDataUIConstants.TOGGLE_INDICATOR_VALUE
						.equals(toggleIndicator)) {
					Collections.sort(codeValues, new MsaValueComparable());
					model.addAttribute("toggleIndicator",
							RefDataUIConstants.TOGGLE_INDICATOR_CODE);
				}
			}
			return codeValues;
		}
	
		/**
		 * 
		 * The method invoked on toggle of code table drop-down in the code
		 * relationship screen.
		 * 
		 * @param toggleIndicator
		 * @param isParent
		 * @param session
		 * @param model
		 * @return
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "toggleCodeRelationshipTables.form", method = RequestMethod.GET)
		public @ResponseBody
		List<CodeValue> toggleParentCodeTableRelationship(
				@RequestParam(value = "toggleIndicator", required = true) String toggleIndicator,
				@RequestParam(value = "isParent", required = true) boolean isParent,
				HttpSession session, Model model) {
			LOGGER.info("toggleParentCodeTableRelationship | toggleIndicator : "
					+ toggleIndicator);
			LOGGER.info("toggleParentCodeTableRelationship | isParent : "
					+ isParent);
			String sessionObject = null;
			List codeValues = null;
			if (isParent) {
				sessionObject = "prntCdTblToggleIndicator";
				codeValues = new ArrayList(
						(List) session.getAttribute("prntCodeTableList"));
			} else {
				sessionObject = "chldCdTblToggleIndicator";
				codeValues = new ArrayList(
						(List) session.getAttribute("chldCodeTableList"));
			}
	
			if (RefDataUIConstants.TOGGLE_INDICATOR_CODE.equals(toggleIndicator)) {
				Collections.sort(codeValues, new MsaCodeComparable());
				session.setAttribute(sessionObject,
						RefDataUIConstants.TOGGLE_INDICATOR_CODE);
			} else {
				Collections.sort(codeValues, new MsaValueComparable());
				session.setAttribute(sessionObject,
						RefDataUIConstants.TOGGLE_INDICATOR_VALUE);
			}
	
			if (isParent) {
				session.setAttribute("prntCodeTableList", codeValues);
			} else {
				session.setAttribute("chldCodeTableList", codeValues);
			}
	
			return codeValues;
		}
	
		/**
		 * 
		 * The method to persist the code relationships. The user entered details
		 * will be persisted in the transaction DB.
		 * 
		 * @param scotsSearchCriteriaVO
		 * @param result
		 * @param model
		 * @param sessionStatus
		 * @param session
		 * @throws ParseException
		 */
		@RequestMapping(value = "/saveCodeRelationship.form", method = RequestMethod.POST)
		public View saveCodeRelationship(
				@ModelAttribute("scotsSearchCriteriaVO") SCoTSSearchCriteriaVO sCoTSSearchCriteriaVO,
				BindingResult result, Model model, SessionStatus sessionStatus,
				HttpSession session, HttpServletRequest request)
						throws ParseException {
			LOGGER.info("entering SCoTSScontroller | saveCodeRelationship");
			// audit variables
			Date startTime = new Date();
	
			String taskId = (String) session.getAttribute("codeRelTaskId");
			LOGGER.info("SCoTSScontroller | saveCodeRelationship | taskId : "
					+ taskId);
	
			Long associationIdIndex = 0L;
			UserContextVO userVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			String loggedInUser = (userVO == null ? "" : userVO.getUserIdentifier());
	
			List<CodeValueAssociation> updateAssociations = new ArrayList<CodeValueAssociation>();
			for (CodeValueAssociation currentCodeValueAssociation : sCoTSSearchCriteriaVO
					.getCodeValueAssociations()) {
				currentCodeValueAssociation.setModifiedDate(new Date());
				currentCodeValueAssociation.setModifiedUser(loggedInUser);
				if (currentCodeValueAssociation.getEffectiveDate() == null) {
					currentCodeValueAssociation.setEffectiveDate(new Date());
				}
				if (currentCodeValueAssociation.getCodeValueAssociationId() == null) {
					currentCodeValueAssociation
					.setCodeValueAssociationId(associationIdIndex--);
					currentCodeValueAssociation.setCreatedDate(new Date());
					currentCodeValueAssociation.setCreatedUser(loggedInUser);
					updateAssociations.add(currentCodeValueAssociation);
				} else if (currentCodeValueAssociation.getExpirationDate() != null) {
					updateAssociations.add(currentCodeValueAssociation);
				}
			}
			sCoTSSearchCriteriaVO.setCodeValueAssociations(updateAssociations);
			LOGGER.info("SCoTSScontroller | saveCodeRelationship | criteriaVO.sssociations : "
					+ sCoTSSearchCriteriaVO.getCodeValueAssociations());
	
			serviceProxy.updateCodeValueAssociation(sCoTSSearchCriteriaVO);
			LOGGER.info("SCoTSScontroller | saveCodeRelationship | after save relationships");
	
			if (taskId != null && (!taskId.trim().isEmpty())) {
				homeController.reSubmitTaskRequest(userVO, taskId,
						RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
						RefDataPropertiesConstants.SCOTS_CODE_SUBMITTER_GROUP_ID);
			} else {
				createSCoTSWorkflowTask(
						getCodeRelationShipDomainId(sCoTSSearchCriteriaVO),
						RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_SCOTS_RELATIONSHIP,
						loggedInUser, null);
			}
	
			// transaction logging
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"updateCodeValueAssociation", 0L,
					getCodeRelationShipDomainId(sCoTSSearchCriteriaVO), 0L,
					sCoTSSearchCriteriaVO);
	
			LOGGER.info("exiting SCoTSScontroller | saveCodeRelationship");
			return new RedirectView("submitterWorkQueueHome.form?domainName=SCoTS");
		}
	
		/**
		 * 
		 * The method to append the parent and child code table id
		 * 
		 * @param sCoTSSearchCriteriaVO
		 * @return
		 */
		private String getCodeRelationShipDomainId(
				SCoTSSearchCriteriaVO sCoTSSearchCriteriaVO) {
			LOGGER.info("SCoTSScontroller | getCodeRelationShipDomainId | sCoTSSearchCriteriaVO : "
					+ sCoTSSearchCriteriaVO);
			return (sCoTSSearchCriteriaVO.getParentCodeTableId() + "~" + sCoTSSearchCriteriaVO
					.getChildCodeTableId());
		}
	
		/**
		 * 
		 * The method is to retrieve all system applicability. The method is invoked
		 * on screenLoad of the menu link click.
		 * 
		 * @param session
		 * @return ModelAndView
		 */
		@SuppressWarnings({ "rawtypes", "unchecked" })
		@RequestMapping(value = "/getManageSystemApplicability.form", method = RequestMethod.GET)
		public ModelAndView getManageSystemApplicability(
				@RequestParam(value = "applicability") String applicability,
				@RequestParam(value = "domainId") String domainId,
				@RequestParam(value = "taskId") Long taskId,
				@RequestParam(value = "dnbSystemCode") Long dnbSystemCode,
				HttpSession session, Model model) {
			LOGGER.info("entering ScotsController | getManageSystemApplicability");
	
			ModelAndView manageSystemApplicabilityModelAndView = new ModelAndView(
					"manageSystemApplicability");
	
			List systemApplicabilityList = serviceProxy
					.retrieveAllSystemApplicability(applicability);
			Collections.sort(systemApplicabilityList, new MsaValueComparable());
			session.setAttribute("SystemApplicabilityList", systemApplicabilityList);
			LOGGER.info("ScotsController | getManageSystemApplicability |"
					+ " systemApplicabilityList " + systemApplicabilityList);
	
			if ((dnbSystemCode != null && dnbSystemCode > 0)
					|| (domainId != null && !domainId.trim().isEmpty() && Long
					.valueOf(domainId) > 0)) {
				List<CodeValueVO> codeTableList = (List<CodeValueVO>) session
						.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION);
				if (codeTableList == null) {
					codeTableList = getCodeTableList();
					session.setAttribute(
							RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION,
							codeTableList);
				}
				Long applicabilityCode = 0L;
				Boolean isStagingDB = true;
				if (dnbSystemCode != null && dnbSystemCode > 0) {
					applicabilityCode = dnbSystemCode;
					isStagingDB = true;
				}
	
				if (domainId != null && !domainId.trim().isEmpty()
						&& Long.valueOf(domainId) > 0) {
					applicabilityCode = Long.valueOf(domainId);
					isStagingDB = false;
				}
				List applicabilityList = retrieveSystemForCode(applicability,
						applicabilityCode, isStagingDB, session);
				Map<Integer, Long> codeTableMap = new HashMap<Integer, Long>();
				Map<Long, List> codeValueMap = new HashMap<Long, List>();
				List rawList = null;
				Iterator applicabilityItr = null;
				LinkedHashMap appyLinkedMap = null;
				Long appId = null;
				if (applicabilityList != null) {
					applicabilityItr = applicabilityList.iterator();
					while (applicabilityItr.hasNext()) {
						appyLinkedMap = (LinkedHashMap) applicabilityItr.next();
						
						
						if ((Integer) appyLinkedMap.get("applicabilityIndicator") == 1) {
							if ("System".equalsIgnoreCase(applicability)) {
								appId = ((Integer) appyLinkedMap.get("sysAppyId"))
										.longValue();
							} else if ("Market".equalsIgnoreCase(applicability)) {
								appId = ((Integer) appyLinkedMap.get("ctryAppyId"))
										.longValue();
							}
							codeTableMap.put(
									(Integer) appyLinkedMap.get("codeTableId"),
									appId);
						} else if ((Integer) appyLinkedMap
								.get("applicabilityIndicator") == 0) {
							if (codeValueMap.containsKey(((Integer) appyLinkedMap
									.get("codeTableId")).longValue())) {
								rawList = codeValueMap.get(((Integer) appyLinkedMap
										.get("codeTableId")).longValue());
							} else {
								rawList = new ArrayList();
							}
							rawList.add(appyLinkedMap);
							codeValueMap.put(((Integer) appyLinkedMap
									.get("codeTableId")).longValue(), rawList);
							
							System.out.println("Printing Expiration date "+rawList);
							
						}
					}
				}
				if (codeValueMap.size() == 0) {
					List emptyList = new ArrayList();
					if ("System".equalsIgnoreCase(applicability)) {
						emptyList.add(new SystemApplicability());
					} else if ("Market".equalsIgnoreCase(applicability)) {
						emptyList.add(new CountryApplicability());
					}
					codeValueMap.put(0L, emptyList);
				}
				manageSystemApplicabilityModelAndView.addObject("codeValueMap",
						codeValueMap);
				manageSystemApplicabilityModelAndView.addObject("codeTableMap",
						codeTableMap);
			}
	
			WorkQueueVO wqVO = new WorkQueueVO();
			wqVO.setDomainId(domainId);
			wqVO.setTaskId(taskId);
			wqVO.setChangeType("Market".equals(applicability) ? Long
					.valueOf(RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_MARKET_APPLICABILITY)
					: Long.valueOf(RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_SYSTEM_APPLICABILITY));
			manageSystemApplicabilityModelAndView.addObject("wqRequestDetails",
					wqVO);
	
			model.addAttribute("codeTableForView", getEmptyCodeTable());
			manageSystemApplicabilityModelAndView.addObject("applicability",
					applicability);
			manageSystemApplicabilityModelAndView.addObject("dnbSystemCode",
					dnbSystemCode);
	
			LOGGER.info("exiting ScotsController | getManageSystemApplicability");
			return manageSystemApplicabilityModelAndView;
		}
	
		private CodeTable getEmptyCodeTable() {
			CodeTable codeTable = new CodeTable();
			List<SystemApplicability> systemApplicabilityList = new ArrayList<SystemApplicability>();
			systemApplicabilityList.add(new SystemApplicability());
			codeTable.setSystemApplicability(systemApplicabilityList);
	
			List<CountryApplicability> countryApplicabilityList = new ArrayList<CountryApplicability>();
			countryApplicabilityList.add(new CountryApplicability());
			codeTable.setCountryApplicability(countryApplicabilityList);
			return codeTable;
		}
	
		/**
		 * 
		 * The method to toggle the system applicability drop down values
		 * 
		 * @param toggleIndicator
		 * @param session
		 * @return model
		 * @return codeValues
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "toggleSystemApplicability.form", method = RequestMethod.GET)
		public @ResponseBody
		List<CodeValueVO> toggleSystemApplicability(
				@RequestParam(value = "toggleIndicator", required = true) Boolean toggleIndicator,
				HttpSession session) {
			LOGGER.info("toggleIndicator : " + toggleIndicator);
	
			List codeValueVOList = (List) session
					.getAttribute("SystemApplicabilityList");
	
			if (codeValueVOList != null) {
				if (toggleIndicator) {
					Collections.sort(codeValueVOList, new MsaValueComparable());
	
				} else {
					Collections.sort(codeValueVOList, new MsaCodeComparable());
				}
			}
			return codeValueVOList;
		}
	
		/**
		 * 
		 * The method to toggle the system applicability drop down values by the
		 * SysAppy entity
		 * 
		 * @param toggleIndicator
		 * @param session
		 * @return sysAppyEnitityList
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "toggleSystemApplicabilityByEntity.form", method = RequestMethod.GET)
		public @ResponseBody
		List<CodeValueVO> toggleSystemApplicabilityByEntity(
				@RequestParam(value = "toggleIndicator", required = true) Boolean toggleIndicator,
				HttpSession session) {
			LOGGER.info("toggleIndicator : " + toggleIndicator);
	
			List sysAppyEnitityList = (List) session
					.getAttribute("systemApplicabilities");
			LOGGER.info("sysAppyEnitityList : " + sysAppyEnitityList);
			if (sysAppyEnitityList != null) {
				if (toggleIndicator) {
					Collections.sort(sysAppyEnitityList,
							new MsaValueComparableForSystem());
				} else {
					Collections.sort(sysAppyEnitityList,
							new SysAppyDnbSysCodeComparable());
				}
			}
			return sysAppyEnitityList;
		}
	
		/**
		 * 
		 * The method to toggle the code table drop down values
		 * 
		 * @param toggleIndicator
		 * @param session
		 * @return model
		 * @return codeValues
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "toggleCodeTableList.form", method = RequestMethod.GET)
		public @ResponseBody
		List<CodeValueVO> toggleCodeTableList(
				@RequestParam(value = "toggleIndicator", required = true) Boolean toggleIndicator,
				HttpSession session) {
			LOGGER.info("toggleIndicator : " + toggleIndicator);
	
			List codeValueVOList = (List) session
					.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION);
	
			if (codeValueVOList != null) {
				if (toggleIndicator) {
					Collections.sort(codeValueVOList, new MsaValueComparable());
				} else {
					Collections.sort(codeValueVOList, new MsaCodeComparable());
				}
			}
			return codeValueVOList;
		}
	
		/**
		 * 
		 * The method to toggle the languages drop down values
		 * 
		 * @param toggleIndicator
		 * @param session
		 * @return model
		 * @return codeValues
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "toggleLanguageList.form", method = RequestMethod.GET)
		public @ResponseBody
		List<CodeValueVO> toggleLanguageList(
				@RequestParam(value = "toggleIndicator", required = true) Boolean toggleIndicator,
				HttpSession session) {
			LOGGER.info("toggleIndicator : " + toggleIndicator);
	
			List codeValueVOList = (List) session
					.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_LANGUAGE_SESSION);
			LOGGER.info("language list before toggle: " + codeValueVOList);
			if (codeValueVOList != null) {
				if (toggleIndicator) {
					Collections.sort(codeValueVOList, new MsaValueComparable());
				} else {
					Collections.sort(codeValueVOList, new MsaCodeComparable());
				}
			}
	
			LOGGER.info("language list after toggle: " + codeValueVOList);
			return codeValueVOList;
		}
	
		/**
		 * 
		 * The method to toggle the languages drop down values
		 * 
		 * @param toggleIndicator
		 * @param session
		 * @return model
		 * @return codeValues
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "toggleLanguageCodeValueList.form", method = RequestMethod.GET)
		public @ResponseBody
		List<CodeValue> toggleLanguageCodeValueList(
				@RequestParam(value = "toggleIndicator", required = true) Boolean toggleIndicator,
				HttpSession session) {
			LOGGER.info("toggleIndicator : " + toggleIndicator);
	
			List codeValueList = (List) session
					.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_LANGUAGE_SESSION);
			LOGGER.info("language list before toggle: " + codeValueList);
			if (codeValueList != null) {
				if (toggleIndicator) {
					Collections.sort(codeValueList,
							new MsaValueComparableForSystem());
				} else {
					Collections.sort(codeValueList, new MsaCodeValueIdComparable());
				}
			}
	
			LOGGER.info("language list after toggle: " + codeValueList);
			return codeValueList;
		}
	
		/**
		 * 
		 * The method to toggle the systems drop down values
		 * 
		 * @param toggleIndicator
		 * @param session
		 * @return model
		 * @return codeValues
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "toggleSystemList.form", method = RequestMethod.GET)
		public @ResponseBody
		List<SystemApplicability> toggleSystemList(
				@RequestParam(value = "toggleIndicator", required = true) Boolean toggleIndicator,
				HttpSession session) {
			LOGGER.info("toggleIndicator : " + toggleIndicator);
	
			List systemApplicabilityList = (List) session
					.getAttribute("systemApplicabilityList");
	
			if (systemApplicabilityList != null) {
				if (toggleIndicator) {
					Collections.sort(systemApplicabilityList,
							new MsaValueComparableForSystem());
				} else {
					Collections.sort(systemApplicabilityList,
							new SysAppyDnbSysCodeComparable());
				}
			}
	
			return systemApplicabilityList;
		}
	
		/**
		 * 
		 * The method to display the Manage SCoTS Alternate Scheme Code JSP. The
		 * method will be invoked on click of the Alternate Scheme Code page from
		 * the menu.
		 * 
		 * @param session
		 * @param model
		 * @return codeAssnView
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "/manageAltSchemeCode.form", method = RequestMethod.GET)
		public ModelAndView manageAlternateSchemeCode(HttpSession session,
				Model model) {
			LOGGER.info("entering ScotsController | manageAlternateSchemeCode");
			Date startTime = new Date();
	
			List<Integer> codeTableIds = new ArrayList<Integer>();
			codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_CODING_SCHEME);
			Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
			List codingSchemes = tempCodeValueMap.get(RefDataPropertiesConstants.CODE_TABLE_ID_CODING_SCHEME_STRING);
			// sort the codeValues based on the Code Value Id
			Collections.sort(codingSchemes, new CodeValueIdComparable());
	
			// retrieve the list of all alternate scheme codes
			if (session.getAttribute("alternateSchemeCodes") == null) {
				session.setAttribute("alternateSchemeCodes",codingSchemes);
			}
	
			// retrieve the list of all code tables
			if (session
					.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION) == null) {
				List codeTables = getCodeTableList();
				Collections.sort(codeTables, new MsaCodeComparable());
	
				session.setAttribute(
						RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION,
						codeTables);
			}
			model.addAttribute("scotsSearchCriteriaVO", new SCoTSSearchCriteriaVO());
	
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			// transaction logging
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"manageAlternateSchemeCode", 0L, null, 0L);
	
			LOGGER.info("exiting ScotsController | manageAlternateSchemeCode");
			return new ModelAndView("codeAltSchemeView");
		}
	
		/**
		 * 
		 * The method to retrieve all alternate scheme codes based on the scheme
		 * type code filter condition. The search will be performed on the staging
		 * DB to fetch all alternate scheme codes matching the scheme type code
		 * selected by the user.
		 * 
		 * @param schemeTypeCode
		 * @param model
		 * @return
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "/retrieveAlternateSchemeCodes.form", method = RequestMethod.GET)
		public ModelAndView retrieveAlternateSchemeCodes(
				@RequestParam(value = "schemeTypeCode") Long schemeTypeCode,
				@RequestParam("taskId") final String taskId, Model model,
				HttpSession session) {
			LOGGER.info("entering ScotsController | retrieveAlternateSchemeCodes");
			LOGGER.info("ScotsController | retrieveAlternateSchemeCodes | schemeTypeCode : "
					+ schemeTypeCode);
			/**
			 * The below code is added to display the submitted records in the Approve Queue.
			 * Ticket #209363690 
			 * */
			List<Integer> codeTableIds = new ArrayList<Integer>();
			codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_CODING_SCHEME);
			Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
			List codingSchemes = tempCodeValueMap.get(RefDataPropertiesConstants.CODE_TABLE_ID_CODING_SCHEME_STRING);
			// sort the codeValues based on the Code Value Id
			Collections.sort(codingSchemes, new CodeValueIdComparable());
	
			if (session.getAttribute("alternateSchemeCodes") == null) {
				session.setAttribute("alternateSchemeCodes",codingSchemes);
			}
			/***/
	
			Date startTime = new Date();
	
			ModelAndView codeAltSchemeView = new ModelAndView("codeAltSchemeView");
			List<CodeValueAlternateScheme> alternateSchemes = null;
	
			if ((taskId != null) && !taskId.trim().isEmpty()) {
				alternateSchemes = getAltSchemeCodesFromLinkedMap(serviceProxy
						.reviewAlternateSchemeCodeChanges(schemeTypeCode)
						.iterator());
			} else {	
				alternateSchemes = getAltSchemeCodesFromLinkedMap(serviceProxy
						.retrieveAlternateSchemeCodes(schemeTypeCode).iterator());
			}
	
	
	
	
			LOGGER.info("ScotsController | retrieveAlternateSchemeCodes | alternateSchemes : "
					+ alternateSchemes);
	
			// if code value alternate scheme is empty or null then add an empty
			// alternate scheme code for display
			if (alternateSchemes == null || alternateSchemes.isEmpty()) {
	
				codeAltSchemeView.addObject("addNewAssociations", "true");
				alternateSchemes = new ArrayList<CodeValueAlternateScheme>();
				alternateSchemes.add(new CodeValueAlternateScheme());
			}
			// setting the model attribute
	
			SCoTSSearchCriteriaVO criteriaVO = new SCoTSSearchCriteriaVO();
			criteriaVO.setAlternateSchemeTypeCode(schemeTypeCode);
			criteriaVO.setCodeValueAlternateSchemes(alternateSchemes);
	
			model.addAttribute("scotsSearchCriteriaVO", criteriaVO);
			session.setAttribute("taskId", taskId);
	
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			// transaction logging
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"retrieveAlternateSchemeCodes", 0L, alternateSchemes, 0L,
					schemeTypeCode);
	
			return codeAltSchemeView;
		}
	
		/**
		 * 
		 * The method to convert the list of linked hash map to
		 * List<CodeValueAlternateScheme>
		 * 
		 * @param itr
		 * @return List<CodeValueAlternateScheme>
		 */
		@SuppressWarnings("rawtypes")
		private List<CodeValueAlternateScheme> getAltSchemeCodesFromLinkedMap(
				Iterator itr) {
			List<CodeValueAlternateScheme> alternateSchemes = new ArrayList<CodeValueAlternateScheme>();
			LOGGER.info("getAltSchemeCodesFromLinkedMap | itr : " + itr);
			while (itr.hasNext()) {
				LinkedHashMap altSch = (LinkedHashMap) itr.next();
				LOGGER.info("getAltSchemeCodesFromLinkedMap | altSch : " + altSch);
				CodeValueAlternateScheme alternateScheme = new CodeValueAlternateScheme();
				alternateScheme
				.setCodeValueAlternateSchemeId(Long
						.valueOf((Integer) altSch
								.get("codeValueAlternateSchemeId")));
				alternateScheme.setCodeValueId(Long.valueOf((Integer) altSch
						.get("codeValueId")));
				alternateScheme.setCodeTableId(Long.valueOf((Integer) altSch
						.get("codeTableId")));
				alternateScheme.setAlternateSchemeTypeCode(Long
						.valueOf((Integer) altSch.get("alternateSchemeTypeCode")));
				alternateScheme.setAlternateSchemeCodeValue((String) altSch
						.get("alternateSchemeCodeValue"));
				DateFormat df = new SimpleDateFormat(
						RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT);
				try {
					alternateScheme.setEffectiveDate(((String) altSch
							.get("effectiveDate")) != null ? df
									.parse((String) altSch.get("effectiveDate")) : null);
					alternateScheme.setExpirationDate(((String) altSch
							.get("expirationDate")) != null ? df
									.parse((String) altSch.get("expirationDate")) : null);
	
					Object createdDateObj = (Object) altSch.get("createdDate");
					if (createdDateObj instanceof Long) {
						alternateScheme.setCreatedDate(((Long) altSch
								.get("createdDate")) != null ? new Date(
										(Long) altSch.get("createdDate")) : null);
					} else if (createdDateObj instanceof String) {
						alternateScheme.setCreatedDate(((String) altSch
								.get("createdDate")) != null ? df
										.parse((String) altSch.get("createdDate")) : null);
					}
	
					Object modifiedDateObj = (Object) altSch.get("createdDate");
					if (modifiedDateObj instanceof Long) {
						alternateScheme.setModifiedDate(((Long) altSch
								.get("modifiedDate")) != null ? new Date(
										(Long) altSch.get("modifiedDate")) : null);
					} else if (modifiedDateObj instanceof String) {
						alternateScheme.setModifiedDate(((String) altSch
								.get("modifiedDate")) != null ? df
										.parse((String) altSch.get("modifiedDate")) : null);
					}
	
				} catch (ParseException e) {
					LOGGER.error("Parse Exception occurred : ", e);
				}
				alternateScheme.setCreatedUser((String) altSch.get("createdUser"));
				alternateScheme
				.setModifiedUser((String) altSch.get("modifiedUser"));
				alternateScheme
				.setAlternateSchemeCodeValueDescription((String) altSch
						.get("alternateSchemeCodeValueDescription"));
				alternateScheme.setCodeValueDescription((String) altSch
						.get("codeValueDescription"));
				alternateScheme.setCodeTableName((String) altSch
						.get("codeTableName"));
				alternateSchemes.add(alternateScheme);
			}
	
			LOGGER.info("SCoTSController | getAltSchemeCodesFromLinkedMap | alternateSchemes : "
					+ alternateSchemes);
			return alternateSchemes;
		}
	
		/**
		 * 
		 * The method to toggle the display of the Alternate Scheme Type Codes
		 * 
		 * @param toggleIndicator
		 * @param session
		 * @return model
		 * @return codeValues
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "toggleAltSchemeCodeTypes.form", method = RequestMethod.GET)
		public @ResponseBody
		List<CodeValue> toggleAltSchemeCodeTypes(
				@RequestParam(value = "toggleIndicator", required = true) String toggleIndicator,
				HttpSession session, Model model) {
			LOGGER.info("SCoTSController | toggleAltSchemeCodeTypes | toggleIndicator : "
					+ toggleIndicator);
	
	
	
			List codeValues = (List) session.getAttribute("alternateSchemeCodes");
	
			if (codeValues != null) {
				if (RefDataUIConstants.TOGGLE_INDICATOR_CODE
						.equals(toggleIndicator)) {
					Collections.sort(codeValues, new MsaCodeValueIdComparable());
					model.addAttribute("toggleIndicator",
							RefDataUIConstants.TOGGLE_INDICATOR_VALUE);
	
	
				} else if (RefDataUIConstants.TOGGLE_INDICATOR_VALUE
						.equals(toggleIndicator)) {
					Collections.sort(codeValues, new MsaCodeDescriptionComparable());
					model.addAttribute("toggleIndicator",
							RefDataUIConstants.TOGGLE_INDICATOR_CODE);
	
				}
			}
			LOGGER.info("SCoTSController | toggleAltSchemeCodeTypes | Code Values : "
					+ codeValues);
	
			return codeValues;
		}
	
		/**
		 * 
		 * The Comparator class will sort the CodeValueVO based on the value
		 * 
		 * @author Cognizant
		 * @version last updated : Apr 05, 2012
		 * @see
		 * 
		 */
		@SuppressWarnings("rawtypes")
		public class MsaValueComparable implements Comparator<LinkedHashMap> {
	
			@Override
			public int compare(LinkedHashMap codeValueVO1,
					LinkedHashMap codeValueVO2) {
				return ((String) codeValueVO1.get("value"))
						.compareTo((String) codeValueVO2.get("value"));
			}
		}
	
		/**
		 * 
		 * The Comparator class will sort the CodeValueVO based on the value
		 * 
		 * @author Cognizant
		 * @version last updated : Apr 05, 2012
		 * @see
		 * 
		 */
		@SuppressWarnings("rawtypes")
		public class MsaValueComparableForSystem implements
		Comparator<LinkedHashMap> {
	
			@Override
			public int compare(LinkedHashMap codeValueVO1,
					LinkedHashMap codeValueVO2) {
				return ((String) codeValueVO1.get("codeValueDescription"))
						.compareTo((String) codeValueVO2
								.get("codeValueDescription"));
			}
		}
	
		@SuppressWarnings("rawtypes")
		public class MsaCodeComparable implements Comparator<LinkedHashMap> {
	
			@Override
			public int compare(LinkedHashMap codeValueVO1,
					LinkedHashMap codeValueVO2) {
				return ((Integer) codeValueVO1.get("code"))
						.compareTo((Integer) codeValueVO2.get("code"));
			}
		}
	
		/**
		 * 
		 * The Comparator class will sort the CodeValue based on the codeValueId
		 * property
		 * 
		 * @author Cognizant
		 * @version last updated : Apr 09, 2012
		 * @see
		 * 
		 */
		@SuppressWarnings("rawtypes")
		public class MsaCodeValueIdComparable implements Comparator<LinkedHashMap> {
	
			@Override
			public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
				return ((Integer) codeValue1.get("codeValueId"))
						.compareTo((Integer) codeValue2.get("codeValueId"));
			}
		}
	
		/**
		 * 
		 * The Comparator class will sort the System Applicability based on the
		 * dnbSysCode property
		 * 
		 * @author Cognizant
		 * @version last updated : May 27, 2012
		 * @see
		 * 
		 */
		@SuppressWarnings("rawtypes")
		public class SysAppyDnbSysCodeComparable implements
		Comparator<LinkedHashMap> {
	
			@Override
			public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
				return ((Integer) codeValue1.get("dnbSystemCode"))
						.compareTo((Integer) codeValue2.get("dnbSystemCode"));
			}
		}
	
		/**
		 * 
		 * The Comparator class will sort the CodeValue based on the
		 * codeValueDescription property
		 * 
		 * @author Cognizant
		 * @version last updated : Apr 9, 2012
		 * @see
		 * 
		 */
		@SuppressWarnings("rawtypes")
		public class MsaCodeDescriptionComparable implements
		Comparator<LinkedHashMap> {
	
			@Override
			public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
				return ((String) codeValue1.get("codeValueDescription"))
						.compareTo((String) codeValue2.get("codeValueDescription"));
			}
		}
	
		/**
		 * 
		 * The method will retrieve all systems applicable from the Search DB based
		 * on the code table selected by the user. The return type is List of
		 * SystemApplicability
		 * 
		 * @param applicability
		 * @param applicabilityCode
		 * @param isStagingDB
		 * @param session
		 * @return applicability
		 */
		@SuppressWarnings("rawtypes")
		@RequestMapping(value = "retrieveSystemForCode.form", method = RequestMethod.GET)
		public @ResponseBody
		List retrieveSystemForCode(
				@RequestParam(value = "applicability") String applicability,
				@RequestParam(value = "applicabilityCode") Long applicabilityCode,
				@RequestParam(value = "isStagingDB") Boolean isStagingDB,
				HttpSession session) {
			LOGGER.info("entering SCoTSController | retrieveSystemForCode.form");
			List applicabilities = this.serviceProxy.retrieveSystemForCode(
					applicability, applicabilityCode, isStagingDB);
	
			if (!isStagingDB) {
				applicabilities = populateCodeTableNames(applicabilities,
						applicability, session);
				applicabilities = populateCodeValueNames(applicabilities,
						applicability);
			}
			return applicabilities;
		}
	
		/**
		 * 
		 * The method to populate the code table names from the values in session
		 * 
		 * @param applicabilities
		 * @param appyIndicator
		 * @param session
		 * @return applicabilities
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		private List populateCodeTableNames(List applicabilities,
				String appyIndicator, HttpSession session) {
			List<CodeValueVO> codeValueVOs = (List<CodeValueVO>) session
					.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION);
			if (codeValueVOs != null) {
	
				Iterator appyItr = applicabilities.iterator();
				Iterator cdValItr = codeValueVOs.iterator();
				while (appyItr.hasNext()) {
					LinkedHashMap appy = (LinkedHashMap) appyItr.next();
					while (cdValItr.hasNext()) {
						LinkedHashMap codeValueVO = (LinkedHashMap) cdValItr.next();
						if (String.valueOf(codeValueVO.get("code")).equals(
								String.valueOf(appy.get("codeTableId")))) {
							appy.put("codeTableName", codeValueVO.get("value"));
							break;
						}
					}
				}
			}
			return applicabilities;
		}
	
		@SuppressWarnings({ "rawtypes", "unchecked" })
		private List populateCodeValueNames(List applicabilities,
				String appyIndicator) {
			List<Integer> codeValueIdList = new ArrayList<Integer>();
			if (applicabilities == null) {
				return applicabilities;
			}
			Iterator appyItr = applicabilities.iterator();
			LinkedHashMap curr = null;
			Integer codeValueId = null;
			while (appyItr.hasNext()) {
				curr = (LinkedHashMap) appyItr.next();
				codeValueId = (Integer) curr.get("codeValueId");
				if (codeValueId != null) {
					codeValueIdList.add((Integer) curr.get("codeValueId"));
				}
			}
			Map<Integer, String> descForIdMap = ftProxy
					.retrieveDescForId(codeValueIdList);
			appyItr = applicabilities.iterator();
			while (appyItr.hasNext()) {
				curr = (LinkedHashMap) appyItr.next();
				curr.put("codeValueDescription",
						descForIdMap.get(String.valueOf(curr.get("codeValueId"))));
			}
			return applicabilities;
		}
	
		@RequestMapping(value = "retrieveCodeValuesForTableId.form", method = RequestMethod.GET)
		public @ResponseBody
		Map<String, List<CodeValue>> retrieveCodeValuesForTableId(
				@RequestParam(value = "codeTableId") Long codeTableId) {
			LOGGER.info("entering SCoTSController | retrieveCodeValuesForTableId.form");
			List<Integer> idList = new ArrayList<Integer>();
			idList.add(codeTableId.intValue());
			return homeController.retrieveCodeValues(idList);
		}
	
		@RequestMapping(value = "/applicabilitySave.form", method = RequestMethod.POST)
		public View applicabilitySave(
				@ModelAttribute("codeTableForView") CodeTable codeTable,
				SessionStatus sessionStatus, HttpServletRequest request,
				HttpSession session) {
	
			String applicability = (String) request.getParameter("applicability");
			String taskId = request.getParameter("taskId");
			UserContextVO userVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			String loggedInUser = (userVO == null ? "" : userVO.getUserIdentifier());
			if ("System".equalsIgnoreCase(applicability)) {
				if (codeTable.getSystemApplicability() != null) {
					prepareSystemApplicability(codeTable, loggedInUser);
					this.serviceProxy.updateApplicability(codeTable, true);
					if (taskId != null && (!taskId.trim().isEmpty())) {
						homeController
						.reSubmitTaskRequest(
								userVO,
								taskId,
								RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
								RefDataPropertiesConstants.SCOTS_CODE_SUBMITTER_GROUP_ID);
					} else {
						createSCoTSWorkflowTask(
								getScotsDomainId(codeTable, applicability),
								RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_SYSTEM_APPLICABILITY,
								loggedInUser, null);
					}
				}
			} else if ("Market".equalsIgnoreCase(applicability)) {
				if (codeTable.getCountryApplicability() != null) {
					prepareCountryApplicability(codeTable, loggedInUser);
					this.serviceProxy.updateApplicability(codeTable, false);
					if (taskId != null && (!taskId.trim().isEmpty())) {
						homeController
						.reSubmitTaskRequest(
								userVO,
								taskId,
								RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
								RefDataPropertiesConstants.SCOTS_CODE_SUBMITTER_GROUP_ID);
					} else {
						createSCoTSWorkflowTask(
								getScotsDomainId(codeTable, applicability),
								RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_MARKET_APPLICABILITY,
								loggedInUser, null);
					}
				}
			}
			sessionStatus.setComplete();
			return new RedirectView("submitterWorkQueueHome.form?domainName=SCoTS");
		}
	
		private String getScotsDomainId(CodeTable codeTable, String applicability) {
			if ("System".equalsIgnoreCase(applicability)) {
				if (codeTable.getSystemApplicability() != null
						&& codeTable.getSystemApplicability().size() > 0) {
					return String.valueOf(codeTable.getSystemApplicability().get(0)
							.getDnbSystemCode());
				}
			} else if ("Market".equalsIgnoreCase(applicability)) {
				if (codeTable.getCountryApplicability() != null
						&& codeTable.getCountryApplicability().size() > 0) {
					return String.valueOf(codeTable.getCountryApplicability()
							.get(0).getCountryGeoUnitId());
				}
			}
			return "0";
		}
	
		private void prepareSystemApplicability(CodeTable codeTable,
				String loggedInUser) {
			// Remove empty list
			if (codeTable.getSystemApplicability() != null
					&& codeTable.getSystemApplicability().size() == 1) {
				SystemApplicability currSystem = codeTable.getSystemApplicability()
						.get(0);
				if (currSystem.getDnbSystemCode() == null) {
					codeTable.getSystemApplicability().remove(0);
				}
			}
			if (codeTable.getSystemApplicability() != null) {
				Date today = new Date();
				Long sysAppId = 0L;
				for (SystemApplicability currSystem : codeTable
						.getSystemApplicability()) {
					if (currSystem.getSysAppyId() == null) {
						currSystem.setSysAppyId(sysAppId--);
					}
					currSystem.setCreatedDate(today);
					currSystem.setCreatedUser(loggedInUser);
					currSystem.setEffectiveDate(today);
					currSystem.setModifiedDate(today);
					currSystem.setModifiedUser(loggedInUser);
				}
			}
		}
	
		private void prepareSystemApplicability(CodeValue codeValue,
				String loggedInUser) {
			// Remove empty list
			if (codeValue.getSystemApplicability() != null
					&& codeValue.getSystemApplicability().size() == 1) {
				SystemApplicability currSystem = codeValue.getSystemApplicability()
						.get(0);
				if (currSystem.getDnbSystemCode() == null) {
					codeValue.getSystemApplicability().remove(0);
				}
			}
			if (codeValue.getSystemApplicability() != null) {
				Date today = new Date();
				Long sysAppId = 0L;
				for (SystemApplicability currSystem : codeValue
						.getSystemApplicability()) {
					if (currSystem.getSysAppyId() == null) {
						currSystem.setSysAppyId(sysAppId--);
					}
					currSystem.setCreatedDate(today);
					currSystem.setCreatedUser(loggedInUser);
					currSystem.setEffectiveDate(today);
					currSystem.setModifiedDate(today);
					currSystem.setModifiedUser(loggedInUser);
				}
			}
		}
	
		private void prepareCountryApplicability(CodeTable codeTable,
				String loggedInUser) {
			// Remove empty list
			if (codeTable.getCountryApplicability() != null
					&& codeTable.getCountryApplicability().size() == 1) {
				CountryApplicability currCountry = codeTable
						.getCountryApplicability().get(0);
				if (currCountry.getCountryGeoUnitId() == null) {
					codeTable.getCountryApplicability().remove(0);
				}
			}
			if (codeTable.getCountryApplicability() != null) {
				Date today = new Date();
				Long ctryAppyId = 0L;
				for (CountryApplicability currCountry : codeTable
						.getCountryApplicability()) {
					if (currCountry.getCtryAppyId() == null) {
						currCountry.setCtryAppyId(ctryAppyId--);
					}
					currCountry.setCreatedDate(today);
					currCountry.setCreatedUser(loggedInUser);
					currCountry.setEffectiveDate(today);
					currCountry.setModifiedDate(today);
					currCountry.setModifiedUser(loggedInUser);
				}
			}
		}
	
		/**
		 * 
		 * Prepare the Country Applicability for CodeValue
		 * 
		 * @param codeValue
		 * @param loggedInUser
		 */
		private void prepareCountryApplicability(CodeValue codeValue,
				String loggedInUser) {
			// Remove empty list
			if (codeValue.getCountryApplicability() != null
					&& codeValue.getCountryApplicability().size() == 1) {
				CountryApplicability currCountry = codeValue
						.getCountryApplicability().get(0);
				if (currCountry.getCountryGeoUnitId() == null) {
					codeValue.getCountryApplicability().remove(0);
				}
			}
			if (codeValue.getCountryApplicability() != null) {
				Date today = new Date();
				Long ctryAppyId = 0L;
				for (CountryApplicability currCountry : codeValue
						.getCountryApplicability()) {
					if (currCountry.getCtryAppyId() == null) {
						currCountry.setCtryAppyId(ctryAppyId--);
					}
					currCountry.setCreatedDate(today);
					currCountry.setCreatedUser(loggedInUser);
					currCountry.setEffectiveDate(today);
					currCountry.setModifiedDate(today);
					currCountry.setModifiedUser(loggedInUser);
				}
			}
		}
	
		/**
		 * 
		 * Prepare the CodeValue Alternate Scheme for CodeValue update
		 * 
		 * @param codeValue
		 * @param loggedInUser
		 */
		private void prepareCodeValueAlternateScheme(CodeValue codeValue,
				String loggedInUser) {
			// Remove empty list
			if (codeValue.getCodeValueSchemes() != null
					&& codeValue.getCodeValueSchemes().size() == 1) {
				CodeValueAlternateScheme currCodeValueAlternateScheme = codeValue
						.getCodeValueSchemes().get(0);
				if (currCodeValueAlternateScheme.getCodeValueAlternateSchemeId() == null) {
					codeValue.getCodeValueSchemes().remove(0);
				}
			}
			if (codeValue.getCodeValueSchemes() != null) {
				Date today = new Date();
				Long codeValueSchemesId = 0L;
				for (CodeValueAlternateScheme currCodeValueAlternateScheme : codeValue
						.getCodeValueSchemes()) {
					if (currCodeValueAlternateScheme
							.getCodeValueAlternateSchemeId() == null) {
						currCodeValueAlternateScheme
						.setCodeValueAlternateSchemeId(codeValueSchemesId--);
					}
					currCodeValueAlternateScheme.setCodeValueId(codeValue
							.getCodeValueId());
					currCodeValueAlternateScheme.setCreatedDate(today);
					currCodeValueAlternateScheme.setCreatedUser(loggedInUser);
					if (currCodeValueAlternateScheme.getEffectiveDate() == null) {
						currCodeValueAlternateScheme.setEffectiveDate(today);
					}
					currCodeValueAlternateScheme.setModifiedDate(today);
					currCodeValueAlternateScheme.setModifiedUser(loggedInUser);
				}
			}
		}
	
		/**
		 * 
		 * Prepare the CodeValue Association for CodeValue update
		 * 
		 * @param codeValue
		 * @param loggedInUser
		 */
		private void prepareCodeValueAssociations(CodeValue codeValue,
				String loggedInUser) {
			// Remove empty list
			if (codeValue.getParentCodeValueAssociations() != null
					&& codeValue.getParentCodeValueAssociations().size() == 1) {
				CodeValueAssociation currCodeValueAssn = codeValue
						.getParentCodeValueAssociations().get(0);
				if (currCodeValueAssn.getChildCodeValueId() == null) {
					codeValue.getParentCodeValueAssociations().remove(0);
				}
			}
			if (codeValue.getParentCodeValueAssociations() != null) {
				Date today = new Date();
				Long codeValueAssnsId = 0L;
				for (CodeValueAssociation currCodeValueAssn : codeValue
						.getParentCodeValueAssociations()) {
					if (currCodeValueAssn.getCodeValueAssociationId() == null) {
						currCodeValueAssn
						.setCodeValueAssociationId(codeValueAssnsId--);
					}
					currCodeValueAssn.setCreatedDate(today);
					currCodeValueAssn.setCreatedUser(loggedInUser);
					currCodeValueAssn.setChildCodeValueId(codeValue
							.getCodeValueId());
					if (currCodeValueAssn.getEffectiveDate() == null) {
						currCodeValueAssn.setEffectiveDate(today);
					}
					currCodeValueAssn.setModifiedDate(today);
					currCodeValueAssn.setModifiedUser(loggedInUser);
				}
			}
	
			// Remove empty list
			if (codeValue.getChildCodeValueAssociations() != null
					&& codeValue.getChildCodeValueAssociations().size() == 1) {
				CodeValueAssociation currCodeValueAssn = codeValue
						.getChildCodeValueAssociations().get(0);
				if (currCodeValueAssn.getChildCodeValueId() == null) {
					codeValue.getChildCodeValueAssociations().remove(0);
				}
			}
			if (codeValue.getChildCodeValueAssociations() != null) {
				Date today = new Date();
				Long codeValueAssnsId = 0L;
				for (CodeValueAssociation currCodeValueAssn : codeValue
						.getChildCodeValueAssociations()) {
					if (currCodeValueAssn.getCodeValueAssociationId() == null) {
						currCodeValueAssn
						.setCodeValueAssociationId(codeValueAssnsId--);
					}
					currCodeValueAssn.setParentCodeValueId(codeValue
							.getCodeValueId());
					currCodeValueAssn.setCreatedDate(today);
					currCodeValueAssn.setCreatedUser(loggedInUser);
					if (currCodeValueAssn.getEffectiveDate() == null) {
						currCodeValueAssn.setEffectiveDate(today);
					}
					currCodeValueAssn.setModifiedDate(today);
					currCodeValueAssn.setModifiedUser(loggedInUser);
				}
			}
		}
	
		private void prepareCodeValueTexts(CodeValue codeValue, String loggedInUser) {
			// Remove empty list
			if (codeValue.getCodeValueTexts() != null
					&& codeValue.getCodeValueTexts().size() == 1) {
				CodeValueText currCodeValueText = codeValue.getCodeValueTexts()
						.get(0);
				if (currCodeValueText.getCodeValueTextId() == null) {
					codeValue.getCodeValueTexts().remove(0);
				}
			}
			if (codeValue.getCodeValueTexts() != null) {
				Date today = new Date();
				Long codeValueTextsId = 0L;
				for (CodeValueText currCodeValueText : codeValue
						.getCodeValueTexts()) {
					if (currCodeValueText.getCodeValueTextId() == null) {
						currCodeValueText.setCodeValueTextId(codeValueTextsId--);
						currCodeValueText.setCreatedDate(today);
						currCodeValueText.setCreatedUser(loggedInUser);
						if (currCodeValueText.getEffectiveDate() == null) {
							currCodeValueText.setEffectiveDate(today);
						}
					}
					currCodeValueText
					.setWritingScriptCode(RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
					currCodeValueText.setCodeValueId(codeValue.getCodeValueId());
					currCodeValueText.setModifiedDate(today);
					currCodeValueText.setModifiedUser(loggedInUser);
				}
			}
		}
	
		/**
		 * 
		 * The method to create new task with work-flow.
		 * 
		 * @param scotsDomainId
		 * @param requestType
		 * @param userContextVO
		 */
		private void createSCoTSWorkflowTask(String scotsDomainId,
				String changeTypeId, String loggedInUser, String reason) {
			LOGGER.info("createSCoTSWorkflowTask | scotsDomainId " + scotsDomainId);
			homeController.createReferenceData(scotsDomainId,
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					Long.valueOf(changeTypeId), loggedInUser, "" + scotsDomainId
					+ (reason != null ? " : " + reason : ""),
					RefDataPropertiesConstants.SCOTS_CODE_APPROVER_GROUP_ID,
					RefDataPropertiesConstants.SCOTS_CODE_SUBMITTER_GROUP_ID);
		}
	
		/**
		 * The method will persist the edited code Value in the Transactional DB.
		 * Only the changed relational data will be inserted. The service method
		 * need to perform validation to identify the records which have been
		 * updated from the UI.
		 * 
		 * @param codeTable
		 *            model attribute
		 * @return View
		 * @throws ParseException
		 */
	
		@RequestMapping(value = "/updateCodeValue.form", method = RequestMethod.POST)
		public View updateCodeValue(
				@ModelAttribute("codeValue") CodeValue codeValue, Model model,
				SessionStatus sessionStatus, HttpSession session,
				HttpServletRequest request) throws ParseException {
			LOGGER.info("entering ScotsController | updateCodeValue");
			// audit variables
			Date startTime = new Date();
	
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			String loggedInUser = userContextVO.getUserIdentifier();
			codeValue.setModifiedUser(userContextVO.getUserIdentifier());
			codeValue.setModifiedDate(new Date());
	
			List<SystemApplicability> finalSystemUpdateList = getUpdatedSystemApplicabilities(codeValue);
			LOGGER.info("ScotsController | updateCodeValue | updated systems in list are: "
					+ finalSystemUpdateList);
	
			List<CountryApplicability> finalCountryUpdateList = getUpdatedCountryApplicabilities(codeValue);
	
			codeValue.setSystemApplicability(finalSystemUpdateList);
			prepareSystemApplicability(codeValue, loggedInUser);
	
			codeValue.setCountryApplicability(finalCountryUpdateList);
			prepareCountryApplicability(codeValue, loggedInUser);
			prepareCodeValueAlternateScheme(codeValue, loggedInUser);
			prepareCodeValueTexts(codeValue, loggedInUser);
			prepareCodeValueAssociations(codeValue, loggedInUser);
	
			LOGGER.info("ScotsController | updateCodeValue | updated countries in list are: "
					+ codeValue.getCountryApplicability());
	
			Long trackingId = serviceProxy.updateCodeValue(codeValue);
	
			LOGGER.info("ScotsController | updateCodeValue | updated code value with id: "
					+ trackingId);
			String taskId = (String) session.getAttribute("taskId");
			if ((taskId != null) && !taskId.trim().isEmpty()) {
				homeController.reSubmitTaskRequest(userContextVO, taskId,
						RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
						RefDataPropertiesConstants.SCOTS_CODE_SUBMITTER_GROUP_ID);
			} else {
				createSCoTSWorkflowTask(trackingId.toString(),
						RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_CODE_VALUE,
						loggedInUser, codeValue.getReasonText());
			}
			sessionStatus.setComplete();
			session.removeAttribute("taskId");
	
			// transaction logging
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"updateCodeValue", 0L, trackingId, 0L, codeValue);
	
			LOGGER.info("exiting ScotsController | updateCodeValue ");
			return new RedirectView("submitterWorkQueueHome.form?domainName=SCoTS");
		}
	
		/**
		 * 
		 * The method which servers the screen load functionality for the Add Code
		 * Value Screen. The screen will populate the drop downs and default values
		 * required in the screen.
		 * 
		 * @param session
		 * @param model
		 * @return ModelAndView
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "/showAddCodeValueHome.form", method = RequestMethod.GET)
		public ModelAndView showAddCodeValueHome(HttpSession session, Model model) {
			LOGGER.info("entering ScotsController | showAddCodeValueHome");
			ModelAndView addCodeValueView = new ModelAndView("addCodeValue");
	
			// setting the list of code tables for UI
			if (session
					.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION) == null) {
				session.setAttribute(
						RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION,
						serviceProxy.retrieveCodeTableList());
			}
	
			// setting the list of all applicable systems for UI
			addCodeValueView.addObject("allSystems",
					serviceProxy.retrieveSystemApplicability(Long.valueOf(-1), 0));
	
			// setting the list of all applicable countries for UI
			addCodeValueView
			.addObject(
					"allMarkets",
					geoWsProxy
					.retrieveAllCountries(
							RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
							RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));
	
			// Retrieving the Lists for language codes
			List<Integer> codeTableIds = new ArrayList<Integer>();
			codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
			Map<String, List<CodeValue>> tempCodeValueMap = homeController
					.retrieveCodeValues(codeTableIds);
			List languageCodeValues = tempCodeValueMap.get(String
					.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE));
			// sort the list of languages and add to model
			Collections.sort(languageCodeValues, new CodeValueIdComparable());
			session.setAttribute(
					RefDataUIConstants.SCOTS_LIST_CODE_LANGUAGE_SESSION,
					languageCodeValues);
	
			// setting the model attribute as CodeValue entity
			model.addAttribute("codeValue", prepareCodeValueForAdd(session, null));
			LOGGER.info("exiting ScotsController | showAddCodeValueHome");
			return addCodeValueView;
		}
	
		/**
		 * 
		 * The method to populate the codeValue entity for display in UI. The method
		 * will populate the required/mandatory fields for the codeValue.
		 * 
		 * @param session
		 * @return codeValue
		 */
		private CodeValue prepareCodeValueForAdd(HttpSession session,
				CodeValue codeValue) {
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			Date currentDate = new Date();
	
			codeValue = codeValue != null ? codeValue : new CodeValue();
			if (codeValue.getCodeValueId() == null) {
				codeValue.setCodeValueId(-1L);
				if (codeValue.getEffectiveDate() == null) {
					codeValue.setEffectiveDate(currentDate);
				}
				codeValue.setCreatedDate(currentDate);
				codeValue.setCreatedUser(userContextVO.getUserIdentifier());
			}
			codeValue.setModifiedDate(currentDate);
			codeValue.setModifiedUser(userContextVO.getUserIdentifier());
	
			List<CodeValueText> codeValueTexts = codeValue.getCodeValueTexts() != null ? codeValue
					.getCodeValueTexts() : new ArrayList<CodeValueText>();
	
					if (codeValueTexts.size() == 0) {
						CodeValueText codeValueText = new CodeValueText();
						codeValueTexts.add(codeValueText);
					}
					int pkIndex = 0;
					for (CodeValueText codeValueText : codeValueTexts) {
						if ((codeValueText.getCodeValueTextId() == null)
								|| (codeValueText.getCodeValueTextId() != null && codeValueText
								.getCodeValueTextId() <= 0)) {
							codeValueText.setCodeValueTextId(Long.valueOf(--pkIndex));
							codeValueText
							.setWritingScriptCode(RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
							if (codeValueText.getEffectiveDate() == null) {
								codeValueText.setEffectiveDate(currentDate);
							}
							codeValueText.setCreatedDate(currentDate);
							codeValueText.setCreatedUser(userContextVO.getUserIdentifier());
						}
						codeValueText.setModifiedDate(currentDate);
						codeValueText.setModifiedUser(userContextVO.getUserIdentifier());
					}
					codeValue.setCodeValueTexts(codeValueTexts);
	
					LOGGER.info("exiting prepareCodeValueForAdd | codeValue " + codeValue);
					return codeValue;
		}
	
		/**
		 * 
		 * The method to insert the newly added CodeValue to the database. The
		 * method will bind the UI values and construct the CodeValue entity.
		 * 
		 * @param codeValue
		 * @param result
		 * @param session
		 * @param request
		 * @return RedirectView
		 */
		@RequestMapping(value = "/insertCodeValue.form", method = RequestMethod.POST)
		public View insertCodeValue(
				@ModelAttribute("codeValue") CodeValue codeValue,
				BindingResult result, HttpSession session,
				HttpServletRequest request) {
			LOGGER.info("entering SCoTsController | insertCodeValue");
			// audit variables
			Date startTime = new Date();
	
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
	
			List<SystemApplicability> systemApplicabilities = getUpdatedSystemApplicabilities(codeValue);
			List<CountryApplicability> countryApplicabilities = getUpdatedCountryApplicabilities(codeValue);
	
			codeValue.setSystemApplicability(systemApplicabilities);
			prepareSystemApplicability(codeValue, userContextVO.getUserIdentifier());
	
			codeValue.setCountryApplicability(countryApplicabilities);
			prepareCountryApplicability(codeValue,
					userContextVO.getUserIdentifier());
	
			// merge the details to the code value table
			Long codeValueId = serviceProxy.updateCodeValue(prepareCodeValueForAdd(
					session, codeValue));
			LOGGER.info("SCoTsController | insertCodeValue | completed for codeValueId "
					+ codeValueId);
	
			// if the request is to update the SCoTS details in the transaction db
			// then create a task with work-flow
			boolean isIntermediateSave = codeValue.getIsIntermediateSave();
			LOGGER.info("SCoTsController | insertCodeValue | checking intermediate save "
					+ isIntermediateSave);
			if (!isIntermediateSave) {
				String taskId = request.getParameter("taskId");
				LOGGER.info("SCoTsController | insertCodeValue | checking taskId "
						+ taskId);
				if ((taskId != null) && !taskId.trim().isEmpty()) {
					homeController
					.reSubmitTaskRequest(
							userContextVO,
							taskId,
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							RefDataPropertiesConstants.SCOTS_CODE_SUBMITTER_GROUP_ID);
				} else {
					createSCoTSWorkflowTask(String.valueOf(codeValueId),
							RefDataChangeTypeConstants.CHANGE_TYPE_ADD_CODE_VALUE,
							userContextVO.getUserIdentifier(),
							codeValue.getReasonText());
				}
			} else {
				LOGGER.info("SCoTsController | insertCodeValue | update savedRecords ");
				// update the save function in the ui_svd_rec table
				ftProxy.insertSavedRecord(codeValueId,
						RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
						RefDataChangeTypeConstants.CHANGE_TYPE_ADD_CODE_VALUE,
						userContextVO.getUserIdentifier(), "ID:" + codeValueId);
			}
	
			// transaction logging
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"insertCodeValue", 0L, codeValueId, 0L, codeValue);
	
			LOGGER.info("exiting ScotsController | insertCodeValue");
			if (!isIntermediateSave) {
				return new RedirectView(
						"submitterWorkQueueHome.form?domainName=SCoTS");
			} else {
				return null;
			}
		}
	
		/**
		 * 
		 * The method to update the systemApplicabilities for the codeValue
		 * 
		 * @param codeValue
		 * @return finalSystemUpdateList
		 */
		private List<SystemApplicability> getUpdatedSystemApplicabilities(
				CodeValue codeValue) {
			int systemFlag = 0;
	
			List<SystemApplicability> finalSystemUpdateList = new ArrayList<SystemApplicability>();
			List<String> systemList = new CopyOnWriteArrayList<String>();
			systemList = codeValue.getSystemList();
			List<SystemApplicability> initialSystems = codeValue
					.getSystemApplicability();
			try{
				LOGGER.info("initial systems:" + initialSystems);
				LOGGER.info("systemList:" + systemList);
				if (initialSystems != null) {
					if (systemList == null) {
						// all systems have been removed
						for (SystemApplicability systems : initialSystems) {
							systems.setExpirationDate(new Date());
							finalSystemUpdateList.add(systems);
						}
					}
					if (systemList != null && !(systemList.isEmpty())) {
						for (SystemApplicability systems : initialSystems) {
							for (String updateSystemList : systemList) {
								if (systems.getDnbSystemCode().toString()
										.equals(updateSystemList)) {
									systemFlag = 1;
									break;
								}
							}
							if (systemFlag == 1) {
								systemList
								.remove(systems.getDnbSystemCode().toString());
								systemFlag = 0;
							} else {
								systems.setExpirationDate(new Date());
								finalSystemUpdateList.add(systems);
							}
						}
					}
				}
				if (systemList != null && !(systemList.isEmpty())) {
					for (String updateSystemList : systemList) {
						SystemApplicability newSystem = new SystemApplicability();
						newSystem.setApplicabilityIndicator(0);
						newSystem.setCodeValueId(codeValue.getCodeValueId());
						newSystem.setDnbSystemCode(Long.valueOf(updateSystemList));
						newSystem.setCodeTableId(null);
						finalSystemUpdateList.add(newSystem);
					}
				}
	
	
			}catch(Exception e){
				LOGGER.error("Error in getUpdatedSystemApplicabilities | finalSystemUpdateList ",e);
				return null;
			}
	
			LOGGER.info("getUpdatedSystemApplicabilities | finalSystemUpdateList "
					+ finalSystemUpdateList);
			return finalSystemUpdateList;
	
	
		}
	
		/**
		 * 
		 * The method to update the countryApplicabilities for the codeValue
		 * 
		 * @param codeValue
		 * @return
		 */
		private List<CountryApplicability> getUpdatedCountryApplicabilities(
				CodeValue codeValue) {
	
			int countryFlag = 0;
			List<String> countryList = new CopyOnWriteArrayList<String>();
			countryList = codeValue.getCountryList();
			List<CountryApplicability> initialCountries = codeValue
					.getCountryApplicability();
			List<CountryApplicability> finalCountryUpdateList = new ArrayList<CountryApplicability>();
	
			try{
	
				if (initialCountries != null) {
					if (countryList == null) {
						// all systems have been removed
						for (CountryApplicability countries : initialCountries) {
							countries.setExpirationDate(new Date());
							finalCountryUpdateList.add(countries);
						}
					}
					if (countryList != null && !countryList.isEmpty()) {
	
						for (CountryApplicability countries : initialCountries) {
							for (String updateCountryList : codeValue.getCountryList()) {
								LOGGER.info("comparing ||"
										+ countries.getCountryGeoUnitId() + " with "
										+ updateCountryList);
	
								if (countries.getCountryGeoUnitId().toString()
										.equals(updateCountryList)) {
									countryFlag = 1;
									break;
								}
								if (countryFlag == 1) {
									countryList.remove(countries.getCountryGeoUnitId()
											.toString());
									countryFlag = 0;
	
								} else {
									countries.setExpirationDate(new Date());
									finalCountryUpdateList.add(countries);
								}
							}
						}
					}
				}
				if (countryList != null && !countryList.isEmpty()) {
					for (String updateCountryList : countryList) {
						CountryApplicability newCountry = new CountryApplicability();
						newCountry.setCodeValueId(codeValue.getCodeValueId());
						newCountry.setCountryGeoUnitId(Long.valueOf(updateCountryList));
						newCountry.setApplicabilityIndicator(0);
						newCountry.setCodeTableId(null);
						finalCountryUpdateList.add(newCountry);
					}
				}
	
			}catch(Exception e){
				LOGGER.error("Error in getUpdatedSystemApplicabilities | finalCountryUpdateList ",e);
			}
			LOGGER.info("getUpdatedCountryApplicabilities | finalCountryUpdateList "
					+ finalCountryUpdateList);
			return finalCountryUpdateList;
		}
	
		/**
		 * 
		 * The method to show the home screen to add a new code table
		 * 
		 * @param model
		 * @return
		 */
		@RequestMapping(value = "/scotsAddCodeTable.form")
		public ModelAndView showAddCodeTableHome(Model model) {
			ModelAndView addCodeTableView = new ModelAndView("addCodeTable");
			CodeTable codeTable = new CodeTable();
			addCodeTableView.addObject("allSystems",
					serviceProxy.retrieveSystemApplicability(Long.valueOf(-1), 0));
			addCodeTableView
			.addObject(
					"allCountries",
					geoWsProxy
					.retrieveAllCountries(
							RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
							RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));
			model.addAttribute("codeTable", codeTable);
			return addCodeTableView;
		}
	
		/**
		 * 
		 * The method to insert a new codeTable
		 * 
		 * @param codeTable
		 * @param result
		 * @param session
		 * @param request
		 * @return
		 */
		@RequestMapping(value = "/insertCodeTable.form")
		public View insertCodeTable(
				@ModelAttribute("codeTable") CodeTable codeTable,
				BindingResult result, HttpSession session,
				HttpServletRequest request) {
			LOGGER.info("entering ScotsController | insertCodeTable");
			// audit variables
			Date startTime = new Date();
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
	
			List<SystemApplicability> systemApplicabilities = getUpdatedSystemApplicabilities(codeTable);
			List<CountryApplicability> countryApplicabilities = getUpdatedCountryApplicabilities(codeTable);
			String userId = userContextVO.getUserIdentifier();
			codeTable.setSystemApplicability(systemApplicabilities);
			prepareSystemApplicability(codeTable, userId);
	
			codeTable.setCountryApplicability(countryApplicabilities);
			prepareCountryApplicability(codeTable, userId);
			codeTable.setCodeTableId(-1L);
			Date today = new Date();
			codeTable.setCreatedDate(today);
			codeTable.setCreatedUser(userId);
			codeTable.setModifiedDate(today);
			codeTable.setModifiedUser(userId);
	
			// merge the details to the code table
			LOGGER.info("ScotsController | insertCodeTable | insert " + codeTable);
			Long codeTableId = serviceProxy.updateCodeTable(codeTable);
			LOGGER.info("ScotsController | insertCodeTable | inserted codeTableId "
					+ codeTableId);
	
			String taskId = request.getParameter("taskId");
			if ((taskId != null) && !taskId.trim().isEmpty()) {
				homeController.reSubmitTaskRequest(userContextVO, taskId,
						RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
						RefDataPropertiesConstants.SCOTS_CODE_SUBMITTER_GROUP_ID);
			} else {
				createSCoTSWorkflowTask(String.valueOf(codeTableId),
						RefDataChangeTypeConstants.CHANGE_TYPE_ADD_CODE_TABLE,
						userContextVO.getUserIdentifier(),
						codeTable.getReasonText());
			}
	
			// transaction logging
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"insertCodeValue", 0L, codeTableId, 0L, codeTable);
	
			LOGGER.info("exiting ScotsController | insertCodeTable");
			return new RedirectView("submitterWorkQueueHome.form?domainName=SCoTS");
		}
	
		/**
		 * 
		 * The method to update the SystemApplicabilities for the codeTable
		 * 
		 * @param codeTable
		 * @return
		 */
		private List<SystemApplicability> getUpdatedSystemApplicabilities(
				CodeTable codeTable) {
	
			List<SystemApplicability> finalSystemUpdateList = new ArrayList<SystemApplicability>();
			List<String> systemList = codeTable.getSystemList();
			LOGGER.info("systemList:" + systemList);
			if (systemList != null && !systemList.isEmpty()) {
				for (String updateSystemList : systemList) {
					SystemApplicability newSystem = new SystemApplicability();
					newSystem.setApplicabilityIndicator(1);
					newSystem.setDnbSystemCode(Long.valueOf(updateSystemList));
					finalSystemUpdateList.add(newSystem);
				}
			}
			return finalSystemUpdateList;
		}
	
		/**
		 * 
		 * The method to update the countryApplicabilities for the codeTable
		 * 
		 * @param codeTable
		 * @return
		 */
		private List<CountryApplicability> getUpdatedCountryApplicabilities(
				CodeTable codeTable) {
			List<String> countryList = codeTable.getCountryList();
			LOGGER.info("countryList:" + countryList);
			List<CountryApplicability> finalCountryUpdateList = new ArrayList<CountryApplicability>();
			if (countryList != null && !countryList.isEmpty()) {
				for (String updateCountryList : countryList) {
					CountryApplicability newCountry = new CountryApplicability();
					newCountry.setCountryGeoUnitId(Long.valueOf(updateCountryList));
					newCountry.setApplicabilityIndicator(1);
					finalCountryUpdateList.add(newCountry);
				}
			}
	
			return finalCountryUpdateList;
		}
	
		/**
		 * The method will persist the edited AlternateSchemCode in the
		 * Transactional DB. Only the changed relational data will be inserted. The
		 * service method need to perform validation to identify the records which
		 * have been updated from the UI.
		 * 
		 * @param scotsSearchCriteriaVO
		 *            model attribute
		 * @return View
		 * @throws ParseException
		 */
		@RequestMapping(value = "/saveAlternateSchemeCodes.form", method = RequestMethod.POST)
		public View updateAlternateSchemCode(
				@ModelAttribute("scotsSearchCriteriaVO") SCoTSSearchCriteriaVO scotsSearchCriteriaVO,
				Model model, SessionStatus sessionStatus, HttpSession session,
				HttpServletRequest request) throws ParseException {
			LOGGER.info("entering ScotsController | updateAlternateSchemCode | scotsSearchCriteriaVO :"
					+ scotsSearchCriteriaVO);
			// audit variables
			Date startTime = new Date();		
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			String loggedInUser = userContextVO.getUserIdentifier();
			String taskId = request.getParameter("taskId");
			Long associationIdIndex = 0L;
			List<CodeValueAlternateScheme> updatedSchemes = new ArrayList<CodeValueAlternateScheme>();
			for (CodeValueAlternateScheme currentCodeValueAlternateScheme : scotsSearchCriteriaVO
					.getCodeValueAlternateSchemes()) {
				if (currentCodeValueAlternateScheme.getEffectiveDate() == null) {
					currentCodeValueAlternateScheme.setEffectiveDate(new Date());
				}
				currentCodeValueAlternateScheme.setModifiedDate(new Date());
				currentCodeValueAlternateScheme.setModifiedUser(loggedInUser);
				if (currentCodeValueAlternateScheme.getCodeValueAlternateSchemeId() == null) {
					currentCodeValueAlternateScheme
					.setCodeValueAlternateSchemeId(associationIdIndex--);
					currentCodeValueAlternateScheme.setCreatedDate(new Date());
					currentCodeValueAlternateScheme.setCreatedUser(loggedInUser);
					currentCodeValueAlternateScheme
					.setAlternateSchemeTypeCode(scotsSearchCriteriaVO
							.getAlternateSchemeTypeCode());
					updatedSchemes.add(currentCodeValueAlternateScheme);
				} else if (currentCodeValueAlternateScheme.getExpirationDate() != null) {
					updatedSchemes.add(currentCodeValueAlternateScheme);
				}
			}
	
			LOGGER.info("updateAlternateSchemCode | codeValueAlternateSchemes : "
					+ updatedSchemes);
			scotsSearchCriteriaVO.setCodeValueAlternateSchemes(updatedSchemes);
			Long trackingId = serviceProxy
					.updateCodeValueAlternateScheme(scotsSearchCriteriaVO);
	
			if (taskId != null && (!taskId.trim().isEmpty())) {
				homeController.reSubmitTaskRequest(userContextVO, taskId,
						RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
						RefDataPropertiesConstants.SCOTS_CODE_SUBMITTER_GROUP_ID);
			} else {
				createSCoTSWorkflowTask(
						trackingId.toString(),
						RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_ALTERNATE_SCHEME_CODES,
						loggedInUser, null);
			}
			session.removeAttribute("taskId");
	
			// transaction logging
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"insertCodeValue", 0L, trackingId, 0L, scotsSearchCriteriaVO);
	
			return new RedirectView("submitterWorkQueueHome.form?domainName=SCoTS");
		}
	
		/**
		 * The method will populate the existing Scots data from the Transaction DB.
		 * The service method need to retrieve the values from the DB and populate
		 * the UI.
		 * 
		 * @param model
		 *            attribute
		 * @return ModelAndView
		 * 
		 */
		@RequestMapping(value ="/scotsBulkDownload.form" , method = RequestMethod.GET)
		public ModelAndView scotsBulkDownload(Model model,HttpSession session) {
			LOGGER.info("entering ScotsController | ScotsBulkDownload");
			List<CodeValueVO> codeTables = getCodeTableList();
			//List<CodeValueVO> codeLanguages = getCodeLanguages();
			List<Integer> codeTableIds = new ArrayList<Integer>();
			codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
			Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
			ScotsBulkDowloadVO scotsBulkDowloadVO = new ScotsBulkDowloadVO();
			model.addAttribute("scotsBulkDownload", scotsBulkDowloadVO);
	
			session.setAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION,
					codeTables);
			ModelAndView objModelAndView = new ModelAndView("scotsBulkDownload");
			objModelAndView
			.addObject(
					"languageCodeValues",
					tempCodeValueMap.get(String
							.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));
			return objModelAndView;
		}
	
		/**
		 * The method will populate the existing IndustryCode data from the
		 * Transaction DB. The service method need to retrive the values from the DB
		 * based on the user selection
		 * 
		 * @param scotsCodeBulkDownloadVO
		 *            model attribute
		 * @return View
		 * @throws ParseException
		 */
		@RequestMapping(value = "/scotsMyDownLoad.form", method = RequestMethod.POST)
		public View scotsCodeBulkDownload(
				@ModelAttribute("scotsBulkDownload") ScotsBulkDowloadVO scotsBulkDowloadVO,
				BindingResult result, Model model, SessionStatus sessionStatus,
				HttpSession session) throws ParseException {
			LOGGER.info("entering SCoTSController | scotsCodeBulkDownload");
	
			Date startTime = new Date();
			UiBulkDownload uiBulkDownload = new UiBulkDownload();
			uiBulkDownload.setDwnloadStartTime(startTime);
			uiBulkDownload.setFileType(scotsBulkDowloadVO.getFileType());
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			uiBulkDownload.setUserId(userContextVO.getUserIdentifier());
			uiBulkDownload
			.setDomainName(RefDataPropertiesConstants.DOMAIN_CODE_SCOTS);
			uiBulkDownload
			.setBulkDownloadStatus(RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_FILE_STATUS);
			Long uiBlkDwnldTrackingId = serviceProxy
					.addUIBulkDownload(uiBulkDownload);
	
			scotsBulkDowloadVO.setUiBlkDwnldId(uiBlkDwnldTrackingId);
			String fileType = null;
			if (uiBulkDownload.getFileType().equalsIgnoreCase("Code Table")) {
				fileType = "Code_Table";
			} else if (uiBulkDownload.getFileType().equalsIgnoreCase("Code Value")) {
				fileType = "Code_Value";
			}
	
			String scotsDownLoadFileName = refdataConfig
					.getValue(RefDataPropertiesConstants.REFDATA_SCOTS_BLK_DOWNLOAD_LOCATION)
					+ fileType
					+ RefDataPropertiesConstants.UNDERSOCRE
					+ uiBlkDwnldTrackingId
					+ RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_FILE_FORMAT;
			scotsBulkDowloadVO.setScotsDownLoadFileName(scotsDownLoadFileName);
			serviceProxy.scotsBulkDownload(scotsBulkDowloadVO);
	
			// transaction logging
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"scotsCodeBulkDownload", 0L, scotsBulkDowloadVO, 0L,
					uiBulkDownload);
	
			return new RedirectView("workQueueDownload.form");
		}
	
		/** 	
		 * 
		 * The method to retrieve all valid industry code group levels
		 * 
		 * @return validIndustryCodeGroupLevels
		 */
		public List<CodeValue> retrieveValidIndustryCodeGroupLevels() {
			return serviceProxy.retrieveValidIndustryCodeGroupLevels();
		}
	
		/**
		 * The method will show scots bulk upload form
		 * 
		 * @return ModelAndView
		 */
		@RequestMapping(value = "/scotsBulkUpload.form")
		public ModelAndView scotsBulkUploadForm(Model model) {
			LOGGER.info("entering SCoTSController | scotsBulkUploadForm");
			ModelAndView scotsBulkUpload = new ModelAndView();
			ScotsBulkUploadVO scotsBulkUploadVO = new ScotsBulkUploadVO();
			model.addAttribute("scotsBulkUpload", scotsBulkUploadVO);
			LOGGER.info("exiting SCoTSController | scotsBulkUploadForm");
			return scotsBulkUpload;
	
		}
	
		/**
		 * The method will retrive the values from the UI based on the user
		 * selection
		 * 
		 * 
		 * @return View
		 * @throws ParseException
		 */
	
		@RequestMapping(value = "/scotsUpLoad.form", method = RequestMethod.POST)
		public View scotsBulkUpload(
				@ModelAttribute("scotsBulkUpload") ScotsBulkUploadVO scotsBulkUploadVO,
				BindingResult result, Model model, SessionStatus sessionStatus,
				HttpSession session) throws ParseException {
			LOGGER.info("entering SCoTSController | scotsBulkUpload");
			Date startTime = new Date();
	
			String fileName = refdataConfig
					.getValue(RefDataPropertiesConstants.REFDATA_SCOTS_BLK_UPLOAD_LOCATION)
					+ scotsBulkUploadVO.getFile().getOriginalFilename();
			LOGGER.info("SCoTSController | scotsBulkUpload | File Name"+fileName);
			File f = new File(fileName);
	
			MultipartFile multipartFile = scotsBulkUploadVO.getFile();
	
			try {
				multipartFile.transferTo(f);
			} catch (IllegalStateException e) {
				LOGGER.error("Error in SCoTS Upload",e);
			} catch (IOException e) {
				LOGGER.error("Error in SCoTS Upload",e);
			} catch(Exception e){
				LOGGER.error("Error in SCoTS Upload",e);
			}
	
			if (result.hasErrors()) {
				for (ObjectError error : result.getAllErrors()) {
					LOGGER.error("Error: " + error.getCode() + " - "
							+ error.getDefaultMessage());
				}
			}
	
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			createNewScotsBulkUploadWorkflowTask(scotsBulkUploadVO,
					RefDataChangeTypeConstants.CHANGE_TYPE_BULK_UPLOAD_SCOTS,
					userContextVO);
	
			sessionStatus.setComplete();
	
			// transaction logging
			transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(
							RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
							userContextVO.getUserRoles()),
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					"scotsBulkUpload", 0L, fileName, 0L, scotsBulkUploadVO);
	
			LOGGER.info("exiting  SCoTSController | scotsBulkUpload");
			return new RedirectView("submitterWorkQueueHome.form?domainName=SCoTS");
		}
	
		/**
		 * 
		 * The method to create new task with work-flow for Scots bulk upload.
		 * 
		 * @param indusCodeBulkUploadVO
		 * @param requestType
		 * @param userContextVO
		 */
	
		private void createNewScotsBulkUploadWorkflowTask(
				ScotsBulkUploadVO scotsBulkUploadVO, String requestType,
				UserContextVO userContextVO) {
	
			String domainId = null;
			String fileName = scotsBulkUploadVO.getFile().getOriginalFilename();
			domainId = "Scots";
	
			LOGGER.info("params for createNewScotsWorkflowTaskForScotsBulkUpload : "
					+ scotsBulkUploadVO
					+ " : "
					+ requestType
					+ " : "
					+ userContextVO
					+ " : "
					+ RefDataPropertiesConstants.SCOTS_CODE_APPROVER_GROUP_ID
					+ " : "
					+ RefDataPropertiesConstants.SCOTS_CODE_SUBMITTER_GROUP_ID);
	
			homeController.createScotsBulkUploadReferenceData(domainId,
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
					Long.valueOf(requestType), userContextVO.getUserIdentifier(),
					"SCoTS Bulk Upload" + 401, fileName,
					RefDataPropertiesConstants.SCOTS_CODE_APPROVER_GROUP_ID,
					RefDataPropertiesConstants.SCOTS_CODE_SUBMITTER_GROUP_ID);
		}
	
		/**
		 * If applicability is "System", value of dnbSystemCode will be
		 * dnbSystemCode in sys_appy table. If it is "Market", value of
		 * dnbSystemCode will be ctry_geo_unit_id in ctry_appy table. This method
		 * checks if the applicability with given dnbSystemCode is already present
		 * in transactional db. If it exists, the return map will contain
		 * isLocked=true and username=modifiedUser. Else the map will contain
		 * isLocked=false and username="".
		 * 
		 * @param dnbSystemCode
		 * @param applicability
		 * @return map
		 */
		@RequestMapping(value = "lockApplicabilityForEdit.form", method = RequestMethod.GET)
		public @ResponseBody
		Map<String, Object> lockApplicabilityForEdit(
				@RequestParam(value = "dnbSystemCode") Long dnbSystemCode,
				@RequestParam(value = "applicability") String applicability) {
			LOGGER.info("entering SCoTSController | lockApplicabilityForEdit");
			return serviceProxy.lockApplicabilityForEdit(dnbSystemCode,
					applicability);
		}
	
		/**
		 * 
		 * The method to populate the Code Tables drop down in the Manage Alternate
		 * Scheme page
		 * 
		 * @param session
		 * @return
		 */
		@SuppressWarnings("unchecked")
		@RequestMapping(value = "retrieveCodeTablesForAltScheme.form", method = RequestMethod.GET)
		public @ResponseBody
		List<CodeValueVO> retrieveCodeTablesForAltScheme(HttpSession session) {
			return (List<CodeValueVO>) session
					.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION);
		}
	
		/** Implemented to fix 209048785 -Edit SCoTS Approval Page**/
	
		@RequestMapping(value = "/editApprovalCodeValue.form", method = RequestMethod.GET)
		public @ResponseBody
		Boolean editApprovalCodeValue(
				@RequestParam(value = "reasonText") String reason,
				@RequestParam(value = "businessDescription") String busdesc,
				@RequestParam(value = "codeValueId") Long codeValueId,
				HttpSession session) {
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
	
			String ApproverId = userContextVO.getUserIdentifier();
	
			LOGGER.info("entering ScotsController | editApprovalCodeValue");
			LOGGER.info("entering ScotsController | editApprovalCodeValue" + reason);
			LOGGER.info("entering ScotsController | editApprovalCodeValue"
					+ busdesc);
			LOGGER.info("entering ScotsController | editApprovalCodeValue"
					+ codeValueId);
			LOGGER.info("entering ScotsController | editApprovalCodeValue"
					+ ApproverId);
	
			Boolean isUpdated = serviceProxy.editApprovalCodeValue(reason, busdesc,
					codeValueId, ApproverId);
			return isUpdated;
	
		}
	
		/**
		 * 
		 * The method will validate the Scots Relationship for any locks (If already been
		 * opened by any other user for edit). If no lock is currently available
		 * then the method will lock the record and return FALSE indicating no lock
		 * currently. But if a lock already exists, the method will return TRUE. The
		 * lock operation will be performed in the Transactional DB.
		 * 
		 * @param codeTable
		 * @return boolean
		 */
		@RequestMapping(value = "lockScotsRelationship.form", method = RequestMethod.GET)
		public @ResponseBody
		String lockScotsRelationship(
				@ModelAttribute("scotsSearchCriteriaVO") SCoTSSearchCriteriaVO scotsSearchCriteriaVO,
				HttpSession session) {		
			LOGGER.info("entering ScotsController | lockScotsRelationship");	
			Long parentTableId = scotsSearchCriteriaVO.getParentCodeTableId();
			Long childTableId = scotsSearchCriteriaVO.getChildCodeTableId();			
			return serviceProxy.lockCodeRelationship(parentTableId,childTableId);
	
		}
	
	
	
	
	}