/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.proxy;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplate;
import com.dnb.dsc.refdata.web.util.RestWebServiceUtil;

/**
 * @author Cognizant
 * @version last updated : June 19, 2012
 * @see
 *
 */
@Component("financialTemplateWebServiceProxy")
public class FinancialTemplateWebServiceProxy {
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(FinancialTemplateWebServiceProxy.class);
	
	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private RestWebServiceUtil restWSUtil;
	/**
	 * 
	 * The method to get the financial templates
	 *
	 * @param codeTableId
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<CodeValueText> getFinancialTemplates(Long codeTableId) {
		LOGGER.info("entering FinancialTemplateWebServiceProxy | getFinancialTemplates");

		HttpEntity<List<CodeValueText>> entity = new HttpEntity<List<CodeValueText>>(
				restWSUtil.constructRequestHeader());
		String queryParams = "/{codeTableId}/getFinancialTemplates.service";
		ResponseEntity<List> result = null;
		result = this.restTemplate
				.exchange(restWSUtil.getServiceURL(queryParams),
				HttpMethod.GET, entity, List.class, new Object[] {codeTableId});
		LOGGER.info("exiting FinancialTemplateWebServiceProxy | getFinancialTemplates");
		return result != null ? (List) result.getBody() : null;
	}
	/**
	 * 
	 * The method to get the schedules for statement type
	 *
	 * @param statementType
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<CodeValueText> getSchedulesForStatementType(Long statementType) {
		LOGGER.info("entering FinancialTemplateWebServiceProxy | getSchedulesForStatementType");

		HttpEntity<List<CodeValueText>> entity = new HttpEntity<List<CodeValueText>>(
				restWSUtil.constructRequestHeader());
		String queryParams = "/{statementType}/getSchedulesForStatementType.service";
		ResponseEntity<List> result = null;
		result = this.restTemplate
				.exchange(restWSUtil.getServiceURL(queryParams),
				HttpMethod.GET, entity, List.class, new Object[] {statementType});
		LOGGER.info("exiting FinancialTemplateWebServiceProxy | getSchedulesForStatementType");
		return result != null ? (List) result.getBody() : null;
	}
	/**
	 * 
	 * The method to update the financial statement templates
	 *
	 * @param fsTemplate
	 * @return
	 */
	public Long updateFinancialStatementTemplate(FinancialStatementTemplate fsTemplate) {
		LOGGER.info("entering FinancialTemplateWebServiceProxy | updateFinancialStatementTemplate");

		String queryParams = "/updateFinancialStatementTemplate.service";
		HttpEntity<FinancialStatementTemplate> entity = new HttpEntity<FinancialStatementTemplate>(fsTemplate);
		Long result = null;
		result = restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Long.class);
		LOGGER.info("exiting FinancialTemplateWebServiceProxy | updateFinancialStatementTemplate");
		return result;
	}
	/**
	 * 
	 * TODO
	 *
	 * @param financialTemplateTypeCode
	 * @param isStagingDB
	 * @return
	 */
	public FinancialStatementTemplate retrieveFinancialStatementTemplateByTypeCode(Long financialTemplateTypeCode,
			Boolean isStagingDB) {
		LOGGER.info("entering FinancialTemplateWebServiceProxy | retrieveFinancialStatementTemplateByTypeCode");

		HttpEntity<FinancialStatementTemplate> entity = new HttpEntity<FinancialStatementTemplate>(
				restWSUtil.constructRequestHeader());
		String queryParams = "/{financialTemplateTypeCode}/{isStagingDB}/retrieveFinancialStatementTemplateByTypeCode.service";
		ResponseEntity<FinancialStatementTemplate> result = null;
		result = restTemplate.exchange(restWSUtil.getServiceURL(queryParams), HttpMethod.GET,entity,
					FinancialStatementTemplate.class, financialTemplateTypeCode, isStagingDB);
		LOGGER.info("exiting FinancialTemplateWebServiceProxy | retrieveFinancialStatementTemplateByTypeCode");
		return (result != null) ? result.getBody() : null;
	}
	/**
	 * 
	 * TODO
	 *
	 * @param scheduleType
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<CodeValueText> getLineItemsForScheduleType(Long scheduleType) {
		LOGGER.info("entering FinancialTemplateWebServiceProxy | getLineItemsForScheduleType");

		HttpEntity<List<CodeValueText>> entity = new HttpEntity<List<CodeValueText>>(
				restWSUtil.constructRequestHeader());
		String queryParams = "/{scheduleType}/getLineItemsForScheduleType.service";
		ResponseEntity<List> result = null;
		result = this.restTemplate
				.exchange(restWSUtil.getServiceURL(queryParams),
				HttpMethod.GET, entity, List.class, new Object[] {scheduleType});
		LOGGER.info("exiting FinancialTemplateWebServiceProxy | getLineItemsForScheduleType");
		return result != null ? (List) result.getBody() : null;
	}
	
	/**
	 * 
	 * TODO
	 *
	 * @param codeValueIdList
	 * @return
	 */
	@SuppressWarnings({ "unchecked" })
	public Map<Integer, String> retrieveDescForId(
			List<Integer> codeValueIdList) {
		LOGGER.info("entering FinancialTemplateWebServiceProxy | retrieveDescForId");

		String queryParams = "/retrieveDescForId.service";
		HttpEntity<List<Integer>> entity = new HttpEntity<List<Integer>>(
				codeValueIdList);
		Map<Integer, String> result = null;
		result = restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Map.class);
		LOGGER.info("exiting FinancialTemplateWebServiceProxy | retrieveDescForId");
		return result;
	}

	/**
	 * 
	 * TODO
	 *
	 * @param financialStatementTemplateId
	 * @return
	 */
	public FinancialStatementTemplate retrieveFinancialStatementTemplateById(Long financialStatementTemplateId) {
		LOGGER.info("entering FinancialTemplateWebServiceProxy | retrieveFinancialStatementTemplateById");

		HttpEntity<FinancialStatementTemplate> entity = new HttpEntity<FinancialStatementTemplate>(
				restWSUtil.constructRequestHeader());
		String queryParams = "/{financialStatementTemplateId}/getFinancialStatementTemplateById.service";
		ResponseEntity<FinancialStatementTemplate> result = null;
		result = this.restTemplate
				.exchange(restWSUtil.getServiceURL(queryParams),
				HttpMethod.GET, entity, FinancialStatementTemplate.class, financialStatementTemplateId);
		LOGGER.info("exiting FinancialTemplateWebServiceProxy | retrieveFinancialStatementTemplateById");
		return result != null ? result.getBody() : null;
	}
	/**
	 * 
	 * TODO
	 *
	 * @param scheduleCodeList
	 * @return
	 */
	@SuppressWarnings({ "unchecked" })
	public List<CodeValueText> retrieveStatementForSchedules(
			List<Integer> scheduleCodeList) {
		LOGGER.info("entering FinancialTemplateWebServiceProxy | retrieveStatementForSchedules");

		String queryParams = "/retrieveStatementForSchedules.service";
		HttpEntity<List<Integer>> entity = new HttpEntity<List<Integer>>(
				scheduleCodeList);
		List<CodeValueText> result = null;
		result = restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, List.class);
		LOGGER.info("exiting FinancialTemplateWebServiceProxy | retrieveStatementForSchedules");
		return result;
	}

	/**
	 * 
	 * The method to get the financial template by id
	 *
	 * @param financeTemplateId
	 * @return
	 */
	public Long retrieveFinanceTemplateCodeById(Long financeTemplateId) {

		LOGGER.info("entering FinancialTemplateWebServiceProxy | retrieveFinanceTemplateCodeById");

		String queryParams = "/retrieveFinanceTemplateCodeById.service";
		HttpEntity<Long> entity = new HttpEntity<Long>(financeTemplateId);

		Long result = null;
		result = restTemplate.postForObject(restWSUtil.getServiceURL(queryParams), entity, Long.class);
		LOGGER.info("exiting FinancialTemplateWebServiceProxy | retrieveFinanceTemplateCodeById");
		return result;

	}

	/**
	 * 
	 * The method to insert the saved record transaction to the ui_svd_rec
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param deletedUser
	 * @param userComment
	 * @return savedRecordId
	 */
	@SuppressWarnings({"unchecked", "rawtypes"})
	public Long insertSavedRecord(Long domainId, String domainName, String changeType, String deletedUser,
			String userComment) {
		LOGGER.info("entering FinancialTemplateWebServiceProxy | insertSavedRecord");

		String queryParams = "/{domainId}/{domainName}/{changeType}/{deletedUser}/"
				+ "{userComment}/insertSavedRecord.service";
		HttpEntity entity = new HttpEntity(restWSUtil.constructRequestHeader());

		ResponseEntity<Long> result = null;
		result = restTemplate.exchange(restWSUtil.getServiceURL(queryParams), HttpMethod.GET, entity, Long.class,
				domainId, domainName, changeType, deletedUser, userComment);
		LOGGER.info("exiting FinancialTemplateWebServiceProxy | insertSavedRecord");
		return result != null ? result.getBody() : null;
	}
}
