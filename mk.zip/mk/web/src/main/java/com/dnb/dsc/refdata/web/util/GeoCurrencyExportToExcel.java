/**
 * 
 */
package com.dnb.dsc.refdata.web.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dnb.dsc.refdata.core.entity.GeoCurrency;

/**
 * @author cognizant
 *
 */
public class GeoCurrencyExportToExcel extends SXSSFWorkbook{
	
	/** The Excel Sheet */
	private Sheet geoCrcySheet;

	/** The row count. */
	private Integer searchRowCount = 0;
	
	private static final Logger LOGGER = LoggerFactory
	.getLogger(GeoCurrencyExportToExcel.class);
	
	/**
	 * Instantiates a new Geo Currency export to excel.
	 *
	 * @param exportType the export type
	 */
	public GeoCurrencyExportToExcel() {
		super(300);		
		geoCrcySheet = createSheet("Geo Currency");
		geoCrcySheetHeader();
	}
	
	/**
	 * Geo Currency Sheet Header
	 */
	private void geoCrcySheetHeader() {
		LOGGER.info("entering GeoCurrencyExportToExcel | geoCrcySheetHeader | Writing Header");
		Row indusCdHeader = geoCrcySheet.createRow(0);
			
		Cell headerCell0 = indusCdHeader.createCell(0);
		headerCell0.setCellValue("Geo Currency Id");
		
		Cell headerCell1 = indusCdHeader.createCell(1);
		headerCell1.setCellValue("Country Id");
		
		Cell headerCell2 = indusCdHeader.createCell(2);
		headerCell2.setCellValue("Country Name");

		Cell headerCell3 = indusCdHeader.createCell(3);
		headerCell3.setCellValue("Currency Code");
		
		Cell headerCell4 = indusCdHeader.createCell(4);
		headerCell4.setCellValue("Currency Code Description");
		
		Cell headerCell5 = indusCdHeader.createCell(5);
		headerCell5.setCellValue("Effective Date");

		Cell headerCell6 = indusCdHeader.createCell(6);
		headerCell6.setCellValue("End Date");		
		
		LOGGER.info("exiting GeoCurrencyExportToExcel | geoCrcySheetHeader | Finished Writing Header");

	}
	
	/**
	 * Write Search results to excel
	 *
	 */
	@SuppressWarnings("rawtypes")
	public void geoCrcyWriteDataToExcel(List<GeoCurrency> geoCurrency) {
		
		LOGGER.info("entering GeoCurrencyExportToExcel | geoCrcyWriteDataToExcel | Writing data");
		List<GeoCurrency> rows = new ArrayList<GeoCurrency>();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		Iterator itr = geoCurrency.iterator();
		while (itr.hasNext()) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			GeoCurrency row = new GeoCurrency();

			row.setGeoCurrencyId(Long.valueOf((curr.get("geoCurrencyId").toString())));
			row.setGeoUnitId(Long.valueOf((curr.get("geoUnitId").toString())));			
			row.setCountryName((String)(curr.get("countryName")));
			row.setCurrencyCode(Long.valueOf((curr.get("currencyCode").toString())));
			row.setCurrencyCodeDescription((String)(curr.get("currencyCodeDescription")));				
			try {
				Long effectiveDate = (Long) curr.get("effectiveDate");
				Date date = new Date(effectiveDate);
				String efctvDate = formatter.format(date);
				row.setEffectiveDate((Date) formatter.parse(efctvDate));
				if(curr.get("endDate") != null){
					Long expDt = (Long) curr.get("endDate");
					Date d2 = new Date(expDt);
					String expDate = formatter.format(d2);				
					row.setEndDate((Date) formatter.parse(expDate));
				}else{
					row.setEndDate((Date) curr.get("endDate"));
				}
			} catch (Exception ex) {
				LOGGER.error("entering GeoCurrencyExportToExcel | Error in parsing date ", ex);
			}
			
			rows.add(row);
		}
		for (GeoCurrency geoCrcy : rows) {
			searchRowCount++;
			Row dataRow = geoCrcySheet.createRow(searchRowCount);
			
			Cell indscell0 = dataRow.createCell(0);
			indscell0.setCellValue(geoCrcy.getGeoCurrencyId());
			
			Cell indscell1 = dataRow.createCell(1);
			indscell1.setCellValue(geoCrcy.getGeoUnitId());
			
			Cell indscell2 = dataRow.createCell(2);
			indscell2.setCellValue(geoCrcy.getCountryName());			
			
			Cell indscell3 = dataRow.createCell(3);
			indscell3.setCellValue(geoCrcy.getCurrencyCode());
			
			Cell indscell4 = dataRow.createCell(4);
			indscell4.setCellValue(geoCrcy.getCurrencyCodeDescription());

			Cell indscell5 = dataRow.createCell(5);
			indscell5.setCellValue(formatter.format(geoCrcy.getEffectiveDate()));	
			
			Cell indscell6 = dataRow.createCell(6);
			if(geoCrcy.getEndDate()!= null){
				indscell6.setCellValue(formatter.format(geoCrcy.getEndDate()));
			}else{
				indscell6.setCellValue("");
			}
			LOGGER.info("exiting GeoCurrencyExportToExcel | geoCrcyWriteDataToExcel | Finished Writing data");

		}

	}

}
