package com.dnb.dsc.refdata.web.proxy;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.Score;
import com.dnb.dsc.refdata.core.entity.ScoreType;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.AddNewScoreVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.GranularityValueVO;
import com.dnb.dsc.refdata.core.vo.ScoreDtlVO;
import com.dnb.dsc.refdata.core.vo.ScoreSearchVO;
import com.dnb.dsc.refdata.core.vo.ScoreVO;
import com.dnb.dsc.refdata.web.util.RestWebServiceUtil;


/**
 * The web service proxy class will handle the mapping between the UI web
 * requests and the respective service end point class. The class will construct
 * the REST WS requests and exchange the request with the service end point for
 * the response.
 * <p>
 *
 * The web service proxy class will handle all the service requests within the
 * Scoring domain.
 * <p>
 *
 * @author Cognizant
 * @version last updated : Aug 21, 2014
 * @see
 *
 */

@Component
public class ScoreWebServiceProxy {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private RestWebServiceUtil restWSUtil;

	@Autowired
	private RefDataConfigUtil refDataConfigUtil;

		
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ScoreWebServiceProxy.class);
	
	
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveGranularityCodes(String capabilityCode) {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveGroupLevelCodes");
		String serviceURL = "/{capabilityCode}/retrieveGranularityCodes.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL, capabilityCode);
		
	}
	
	public Long updateGranularityCode(GranularityValueVO granularityValueVO) {
		LOGGER.info("entering ScoreWebServiceProxy | updateGranularityCode");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/updateGranularityCode.service";
		HttpEntity<GranularityValueVO> entity = new HttpEntity<GranularityValueVO>(granularityValueVO);
		LOGGER.info("exiting ScoreWebServiceProxy | updateGranularityCode");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}
	
	
	@SuppressWarnings("unchecked")
	public List<ScoreType> retrieveScoreCodes() {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveScoreCodes");
		String serviceURL = "/retrieveScoreCodes.service";
		return restWSUtil.exchangeForList(ScoreType.class, serviceURL);
		
	}


	public Long updateNewScoreCode(AddNewScoreVO addNewScoreVO) {
		LOGGER.info("entering ScoreWebServiceProxy | updateNewScoreCode");
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/updateNewScoreCode.service";
		HttpEntity<AddNewScoreVO> entity = new HttpEntity<AddNewScoreVO>(addNewScoreVO);
		LOGGER.info("exiting ScoreWebServiceProxy | updateNewScoreCode");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}


///////////// score search Chnages - starts

	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveScrSearchScoreTypeCode(
			ScoreVO scoreVo) {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveScrSearchScoreTypeCode");
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/retrieveScrSearchScoreTypeCode.service";
		
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL, scoreVo);

	}
	
	
	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveScrSearchGranularity(
			ScoreVO scoreVo) {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveScrSearchGranularity");
		
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/retrieveScrSearchGranularity.service";		
				
		HttpEntity<ScoreVO> entity = new HttpEntity<ScoreVO>(scoreVo);
		
		LOGGER.info("exiting ScoreWebServiceProxy | retrieveScrSearchGranularity");
		
		return (List<CodeValue>) this.restTemplate.postForObject(serviceURL, entity, List.class, new Object[0]);
		
	}


//////////////// score search Chnages - ends


	
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllScoreTypeCode() {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveAllCountries");
		String queryParams = "/retrieveAllScoreTypeCode.service";

		return restWSUtil.exchangeForList(CodeValueVO.class, queryParams);
	}


	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveMarketTypeCodes(Long scoreType) {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveMarketTypeCodes");
		String serviceURL = "/{scoreType}/retrieveMarketTypeCodes.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL, scoreType);
	}

	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrievescoreVersions(Long scoreType, Long marketType) {
		LOGGER.info("entering ScoreWebServiceProxy | retrievescoreVersions");
		String serviceURL = "/{scoreType}/{marketType}/retrievescoreVersions.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL, scoreType, marketType);
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<AddNewScoreVO> retrieveAttributeDetails(Long scoreType, Long marketType,
			Double scoreVersion) {
		LOGGER.info("entering ScoreWebServiceProxy | SearchFailure");
		AddNewScoreVO addNewScoreVO = new AddNewScoreVO();
 		addNewScoreVO.setScoreTypeCode(scoreType);
 		addNewScoreVO.setMarketCode(marketType);
 		addNewScoreVO.setScoreVersion(scoreVersion);
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{scoreType}/{marketType}/{scoreVersion}/retrieveAttributeDetails.service";
		HttpEntity<AddNewScoreVO> entity = new HttpEntity<AddNewScoreVO>(
				addNewScoreVO);
		LOGGER.info("exiting ScoreWebServiceProxy | searchScores");
		List addNewScoreVOs = this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[]{scoreType,marketType,scoreVersion});
		List<AddNewScoreVO> addNewScrVOs = new ArrayList<AddNewScoreVO>();
		for (int i = 0; i < addNewScoreVOs.size(); i++) {
			AddNewScoreVO addNewScoreVOss = new AddNewScoreVO();
			LinkedHashMap<String, Integer> lhm = (LinkedHashMap<String, Integer>) addNewScoreVOs.get(i);
			for(Entry<String, Integer> t : lhm.entrySet()) {
				if(t.getValue()!=null){
					try{
		        if(t.getKey().equalsIgnoreCase("scoreGranuAssnId")){
		        	addNewScoreVOss.setScoreGranuAssnId(new Long(t.getValue()));
		        }
		        else if(t.getKey().equalsIgnoreCase("scoreMappingLabel")){
		        	addNewScoreVOss.setScoreMappingLabel(String.valueOf(t.getValue()));
		        }
		        else if(t.getKey().equalsIgnoreCase("scoreId")){
		        	addNewScoreVOss.setScoreId(new Long(t.getValue()));
		        }
					}
					catch(Exception e){
						System.out.println(e);
						e.printStackTrace();
					}
				}
		    }
			addNewScrVOs.add(addNewScoreVOss);
		}
		return addNewScrVOs;
	}

	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveScoreTypeCodeValues(ScoreVO scoreVO) {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveScoreTypeCodeValues");
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveScoreTypeCodeValues.service";
		HttpEntity<ScoreVO> entity = new HttpEntity<ScoreVO>(
				scoreVO);
		LOGGER.info("exiting ScoreWebServiceProxy | retrieveScoreTypeCodeValues");
		return (List<CodeValue>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}
	@SuppressWarnings("unchecked")
	public List<Long> retrieveScoreTypeCode() {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveScoreTypeCode");
		String queryParams = "/retrieveScoreTypeCode.service";
		return restWSUtil.exchangeForList(Long.class, queryParams);
	}


	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveMarketCodeValues(ScoreVO scoreVO) {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveMarketCodeValues");
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveMarketCodeValues.service";
		HttpEntity<ScoreVO> entity = new HttpEntity<ScoreVO>(
				scoreVO);
		LOGGER.info("exiting ScoreWebServiceProxy | retrieveMarketCodeValues");
		return (List<CodeValueVO>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<Score> retrieveVersionForScrMktAndType(Score scoreVO) {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveVersionForScrMktAndType");
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveVersionValues.service";
		HttpEntity<Score> entity = new HttpEntity<Score>(
				scoreVO);
		LOGGER.info("exiting ScoreWebServiceProxy | retrieveVersionForScrMktAndType");
		List valueList = (List<Score>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
		
		List<Score> score = new ArrayList<Score>();
		for (int i = 0; i < valueList.size(); i++) {
			Score scores = new Score();
			LinkedHashMap<String, Double> lhm = (LinkedHashMap<String, Double>)valueList.get(i);
			for(Entry<String, Double> t : lhm.entrySet()) {
				if(t.getValue()!=null){
					try{
		        if(t.getKey().equalsIgnoreCase("scoreVersion")){
		        	scores.setScoreVersion(t.getValue());
		        }
		        /*else if(t.getKey().equalsIgnoreCase("scoreMappingLabel")){
		        	scores.setScoreMappingLabel(String.valueOf(t.getValue()));
		        }*/
		        /*else if(t.getKey().equalsIgnoreCase("scoreId")){
		        	scores.setScoreId(new Long(t.getValue()));
		        }*/
					}
					catch(Exception e){
						System.out.println(e);
						e.printStackTrace();
					}
				}
		    }
			score.add(scores);
		}
		return score;
	}


	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveGranularityForScrType(ScoreVO scoreVO) {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveGranularityForScrType");
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveGranularityForScrType.service";
		HttpEntity<ScoreVO> entity = new HttpEntity<ScoreVO>(
				scoreVO);
		LOGGER.info("exiting ScoreWebServiceProxy | retrieveGranularityForScrType");
		return (List<CodeValue>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}


	public Long updateScoreDtl(ScoreDtlVO scoreDtlVO) {
		LOGGER.info("entering ScoreWebServiceProxy | updateScoreDtl");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/updateScoreDtl.service";
		HttpEntity<ScoreDtlVO> entity = new HttpEntity<ScoreDtlVO>(scoreDtlVO);
		LOGGER.info("exiting ScoreWebServiceProxy | updateScoreDtl");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}
	
		public Long updateNewScoreMapping(AddNewScoreVO addNewScoreVO) {
		LOGGER.info("entering ScoreWebServiceProxy | updateNewScoreMapping");
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/updateNewScoreMapping.service";
		HttpEntity<AddNewScoreVO> entity = new HttpEntity<AddNewScoreVO>(addNewScoreVO);
		LOGGER.info("exiting ScoreWebServiceProxy | updateNewScoreMapping");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}
	
	/*@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllScoreType() {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveAllCountries");
		String queryParams = "/retrieveAllScoreType.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, queryParams);
	}*/

	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveGruTypeCodeValues(ScoreVO scoreVO) {
		LOGGER.info("entering ScoreWebServiceProxy | retrieveGruTypeCodeValues");
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveGruTypeCodeValues.service";
		HttpEntity<ScoreVO> entity = new HttpEntity<ScoreVO>(
				scoreVO);
		LOGGER.info("exiting ScoreWebServiceProxy | retrieveGruTypeCodeValues");
		return (List<CodeValue>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}
	public Long countOfscoreSearch(ScoreSearchVO searchCriteriaVO) {
		return countSearchScore(searchCriteriaVO, "/countSearchScore.service");
	}
	private Long countSearchScore(ScoreSearchVO searchCriteriaVO, String deployURL) {
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + deployURL;
		HttpEntity<ScoreSearchVO> entity = new HttpEntity<ScoreSearchVO>(searchCriteriaVO);
		return (Long) this.restTemplate.postForObject(serviceURL, entity, Long.class, new Object[0]);
	}
	@SuppressWarnings("unchecked")
	public List<ScoreSearchVO> SearchScores(
			ScoreSearchVO searchCriteriaVO)throws Exception {
		LOGGER.info("entering ScoreWebServiceProxy | SearchFailure");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/scoreSearchResult.service";
		HttpEntity<ScoreSearchVO> entity = new HttpEntity<ScoreSearchVO>(
				searchCriteriaVO);
		LOGGER.info("exiting ScoreWebServiceProxy | searchScores");
		return (List<ScoreSearchVO>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}


	public ScoreSearchVO editScoreSearch(Long scrID,Long scrTypCd) {
		ScoreSearchVO scoreSearchVO = new ScoreSearchVO();
		scoreSearchVO.setScr_id(scrID);
		scoreSearchVO.setScoreTypeCode(scrTypCd);
		/*LOGGER.info("entering ScoreWebServiceProxy | SearchFailure");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/scoreSearchResult.service";
		HttpEntity<ScoreSearchVO> entity = new HttpEntity<ScoreSearchVO>(
				scoreSearchVO);
		LOGGER.info("exiting ScoreWebServiceProxy | searchScores");
		return (ScoreSearchVO) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
		
		LOGGER.info("entering ScoreWebServiceProxy | updateScoreDtl");*/

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/editScoreSearch.service";
		HttpEntity<ScoreSearchVO> entity = new HttpEntity<ScoreSearchVO>(scoreSearchVO);
		LOGGER.info("exiting ScoreWebServiceProxy | updateScoreDtl");
		return restTemplate.postForObject(serviceURL, entity, ScoreSearchVO.class);
		
	}


	public Long updateScoreMapDtl(ScoreSearchVO scoreSearchVO) {
		LOGGER.info("entering ScoreWebServiceProxy | updateScoreMapDtl");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/updateScoreMapDtl.service";
		HttpEntity<ScoreSearchVO> entity = new HttpEntity<ScoreSearchVO>(scoreSearchVO);
		LOGGER.info("exiting ScoreWebServiceProxy | updateScoreMapDtl");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}

	
    public Boolean checkForDuplicate(Long scoreTypeCode,Long scoreMarketCode,Double scoreVersion) {
           LOGGER.info("entering ScoreWebServiceProxy | checkForDuplicate");
           HttpEntity<Boolean> entity = new HttpEntity<Boolean>(
                        restWSUtil.constructRequestHeader());
           String serviceURL = refDataConfigUtil.getServiceDeployURL()
                        + "/{scoreTypeCode}/{scoreMarketCode}/{scoreVersion}/checkForDuplicate.service";
           ResponseEntity<Boolean> result = restTemplate.exchange(serviceURL,
                        HttpMethod.GET, entity, Boolean.class, scoreTypeCode,
                        scoreMarketCode, scoreVersion);
           LOGGER.info("exiting ScoreWebServiceProxy | checkForDuplicate");
           return result != null ?(Boolean) result.getBody() : null;

    }

}
