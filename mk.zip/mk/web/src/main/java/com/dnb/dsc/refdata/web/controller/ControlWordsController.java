/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.controller;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.taglibs.standard.tag.common.xml.ForEachTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsyCtryAppy;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeInferment;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.InfermentTextCountryApplicability;
import com.dnb.dsc.refdata.core.entity.LegalFormInferment;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.interceptor.TransactionLogger;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ControlWordsBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.ControlWordsSearchVO;
import com.dnb.dsc.refdata.core.vo.ControlWordsUploadVO;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.web.proxy.ControlWordsProxy;
import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;
import com.dnb.dsc.refdata.web.proxy.IndustryCodesWebServiceProxy;
import com.dnb.dsc.refdata.web.util.UserRoleMapper;

/**
 * The Controller class for Control Words Domain. The methods in the class will
 * be mapped as per the UI requests. The UI front controller will redirect to
 * the respective methods based on the request and the request parameters.
 * 
 * @author Cognizant
 * @version last updated : May 29, 2012
 * @see
 * 
 */
@Controller
@SessionAttributes({"dnbUnusGlsy", "infermentText", "phoneAreaCode"})
public class ControlWordsController {

	@Autowired
	private ControlWordsProxy ctrlWrdsProxy;

	
	@Autowired
	private GeographyWebServiceProxy geoWsProxy;

	@Autowired
	private HomeController homeController;

	@Autowired
	private SCoTSController scotsController;

	@Autowired
	private UserRoleMapper roleMapper;

	@Autowired
	private IndustryCodesWebServiceProxy indsProxy;
	@Autowired
	private RefDataConfigUtil refdataConfig;

	@Autowired
	private TransactionLogger transactionLogger;

	private final String[] ctrlWordsSearchColumns = {"geoName", "languageDescription", "legalFormCodeValue",
			"legalFormClassCodeValue", "infermentText", "status", "icountryGeoUnitId", "languageCode", "legalFormCode",
			"legalFormClassCode", "infermentTextId"};

	/**
	 * The search results column for Area Code Numbers
	 */
	private final String[] areaCodeSearchColumns = {"areaCodeNumber", "areaCodeServiceDescription",
			"countryGeoUnitOfficialName", "territoryGeoUnitOfficialName", "unUsedGlossaryExpirationDate",
			"phoneAreaCodeId"};

	private final String[] industryInfermentSearchColumns = {"countryName", "language", "industryCodeTypeCodeDesc",
			"industryDescription", "industryCode", "infermentText", "infermentTextId"};

	private final String[] unUsOffWordsSearchColumns = {"officialGeoName", "dnbUnusTxt", "alwdWthOthWdIndc",
			"stopPrcsRecIndc", "status","effvDt","expnDt","exctMtchIndc","dnbUnusGlsyId","dnbUnusGlsyTypCd"};
	
	private final String[] unUsOrgNameSearchColumns = {"officialGeoName", "dnbUnusTxt", "exctMtchIndc",
			"stopPrcsRecIndc", "status","effvDt","expnDt","alwdWthOthWdIndc","dnbUnusGlsyId","dnbUnusGlsyTypCd"};
	
	private final String[] unUsAreaCodeSearchColumns = {"officialGeoName", "stopPrcsRecIndc","areaCodeNumber",
			"areaCodeServiceDescription","countryGeoUnitOfficialName","territoryGeoUnitOfficialName", "status",
			"dnbUnusTxt", "exctMtchIndc","effvDt","expnDt","alwdWthOthWdIndc",
			"countryGeoUnitId","territoryGeoUnitId","dnbUnusGlsyId","dnbUnusGlsyTypCd"};
	
	private final String[] unUsAddressSearchColumns = {"officialGeoName", "dnbUnusTxt","ln1Adr","ln2Adr","strNme",
			"primTownNme","cntyNme","terrNme","postCode", "status",
			"exctMtchIndc","effvDt","expnDt","alwdWthOthWdIndc","stopPrcsRecIndc","dnbUnusGlsyId",
			"dnbUnusGlsyTypCd"};
	
	private final String[] unUsTelNumberSearchColumns = {"officialGeoName", "dnbUnusTxt","areaCodeNbr","tlcmExchCode","phonExtnNbr","status",
			"exctMtchIndc","effvDt","expnDt","alwdWthOthWdIndc","stopPrcsRecIndc","dnbUnusGlsyId",
			"dnbUnusGlsyTypCd"};
	
	private final String[] unUsIndNameSearchColumns = {"officialGeoName", "dnbUnusTxt","frnm","midlNme","srnme","nmeSfxTxt","stopPrcsRecIndc","status",
			"exctMtchIndc","effvDt","expnDt","alwdWthOthWdIndc","dnbUnusGlsyId",
			"dnbUnusGlsyTypCd"};
	
	private final String[] noiseWordSearchColumns = {"officialGeoName", "dnbUnusTxt","stopPrcsRecIndc","status",
			"exctMtchIndc","effvDt","expnDt","alwdWthOthWdIndc","dnbUnusGlsyId",
			"dnbUnusGlsyTypCd"};

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ControlWordsController.class);

	private static final String DELETE = "Delete";
	private static final String ADD = "add";
	private static final String UPDATE = "update";

	/**
	 * 
	 * The method for the Control Words Search home page
	 *
	 * @param model
	 * @param session
	 * @return controlWordsSearch View 
	 */
	@RequestMapping(value = "/showControlWordsSearch.form", method = RequestMethod.GET)
	public ModelAndView showControlWordsSearch(Model model, HttpSession session) {
		LOGGER.info("entering ControlWordsController | showControlWordsSearch");
		ModelAndView controlWordsSearch = new ModelAndView("controlWordsSearch");
		controlWordsSearch.addObject("allControlWords", getAllControlWords(session));
		controlWordsSearch.addObject("allControlWorldCountries", getAllControlWorldCountries(session));
		model.addAttribute("controlWordsSearchVO", new ControlWordsSearchVO());
		return controlWordsSearch;
	}

	/**
	 * 
	 * The method to retrieve the control words search results
	 *
	 * @param controlWordsSearchVO
	 * @param session
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/retrieveControlWordsSearchResults.form", method = RequestMethod.POST)
	public ModelAndView retrieveControlWordsSearchResults(
			@ModelAttribute("controlWordsSearchVO") ControlWordsSearchVO controlWordsSearchVO, HttpSession session,
			Model model) {
		LOGGER.info("entering ControlWordsController | retrieveControlWordsSearchResults");
		ModelAndView controlWordsSearch = new ModelAndView("controlWordsSearch");
		controlWordsSearch.addObject("allControlWords", getAllControlWords(session));
		controlWordsSearch.addObject("allControlWorldCountries", getAllControlWorldCountries(session));
		// Result will be set in the VO itself
		controlWordsSearchVO = ctrlWrdsProxy.retrieveControlWordsSearchResults(controlWordsSearchVO);
		model.addAttribute("controlWordsSearchVO", controlWordsSearchVO);
		return controlWordsSearch;
	}

	/**
	 * 
	 * The method to retrieve all control words search types
	 *
	 * @param session
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<CodeValueText> getAllControlWords(HttpSession session) {
		List<CodeValueText> allControlWords = (List<CodeValueText>) session.getAttribute("allControlWords");
		if (allControlWords == null) {
			allControlWords = ctrlWrdsProxy.retrieveAllControlWords();
			session.setAttribute("allControlWords", allControlWords);
		}
		return allControlWords;
	}
	/**
	 * 
	 * The method to retrieve all control words countries
	 *
	 * @param session
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<CodeValueVO> getAllControlWorldCountries(HttpSession session) {
		List<CodeValueVO> allControlWorldCountries = (List<CodeValueVO>) session
				.getAttribute("allControlWorldCountries");
		if (allControlWorldCountries == null) {
			allControlWorldCountries = geoWsProxy.retrieveAllCountries(
					RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
					RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			session.setAttribute("allControlWorldCountries", allControlWorldCountries);
		}
		return allControlWorldCountries;
	}

	/**
	 * 
	 * The method to retrieve control words by id and type code
	 *
	 * @param dnbUnusGlsyId
	 * @param dnbUnusGlsyTypCdText
	 * @param taskId
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/retrieveControlWordByIdAndTypeCode.form", method = RequestMethod.GET)
	public ModelAndView retrieveControlWordByIdAndTypeCode(@RequestParam("dnbUnusGlsyId") final Long dnbUnusGlsyId,
			@RequestParam("dnbUnusGlsyTypCdText") final String dnbUnusGlsyTypCdText,
			@RequestParam("taskId") Long taskId, Model model) {
		
		
		Map<String,String>mk=new HashMap<String,String>();
		
		mk.put("one", "mk");
		mk.put("two", "ck");
		
		for(Map.Entry<String,String > entry : mk.entrySet()){
			
			System.out.println("Print"+entry.getValue());
		}

		
		Iterator iterator=mk.entrySet().iterator();
		
		while(iterator.hasNext()){
			Map.Entry<String , String> entries=(Map.Entry)iterator.next();
			String key=entries.getKey();
			String value=entries.getValue();

			
			
		}
		
		
		
		
		
		
		
		
		
		LOGGER.info("entering ControlWordsController | retrieveControlWordByIdAndTypeCode");
		LOGGER.info("retrieveControlWordByIdAndTypeCode | dnbUnusGlsyTypCdText : " + dnbUnusGlsyTypCdText);
		LOGGER.info("retrieveControlWordByIdAndTypeCode | dnbUnusGlsyId : " + dnbUnusGlsyId);
		LOGGER.info("retrieveControlWordByIdAndTypeCode | taskId : " + taskId);
		
		ModelAndView controlWordDetail = new ModelAndView("controlWordDetail");
		
		controlWordDetail.addObject("allCountries", geoWsProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));		
		DnbUnusGlsy stagingDnbUnusGlsy = ctrlWrdsProxy.retrieveControlWordById(dnbUnusGlsyId, true);
		DnbUnusGlsy transactionalDnbUnusGlsy = null;
		DnbUnusGlsy dnbUnusGlsy = null;
		if (taskId != null && taskId > 0) {
			try {
				transactionalDnbUnusGlsy = ctrlWrdsProxy.retrieveControlWordById(dnbUnusGlsyId, false);
			} catch(ReferenceDataExceptionVO exceptionVO) {
				LOGGER.info("No data available in transaction DB");
			}
		}
		if (transactionalDnbUnusGlsy != null) {
			dnbUnusGlsy = transactionalDnbUnusGlsy;
			if (stagingDnbUnusGlsy != null) {
				if (dnbUnusGlsy.getCountryApplicability() != null) {
					dnbUnusGlsy.getCountryApplicability().addAll(stagingDnbUnusGlsy.getCountryApplicability());
				} else {
					dnbUnusGlsy.setCountryApplicability(stagingDnbUnusGlsy.getCountryApplicability());
				}
				dnbUnusGlsy.setDnbUnusAdr(stagingDnbUnusGlsy.getDnbUnusAdr());
				dnbUnusGlsy.setDnbUnusIndNme(stagingDnbUnusGlsy.getDnbUnusIndNme());
				if (dnbUnusGlsy.getPhoneAreaCode() == null) {
					dnbUnusGlsy.setPhoneAreaCode(stagingDnbUnusGlsy.getPhoneAreaCode());
				}
				dnbUnusGlsy.setTelecomAddress(stagingDnbUnusGlsy.getTelecomAddress());
			} 
		} else {
			dnbUnusGlsy = stagingDnbUnusGlsy;
		}

		List<DnbUnusGlsyCtryAppy> activeCtryList = new ArrayList<DnbUnusGlsyCtryAppy>();
		if (dnbUnusGlsy.getCountryApplicability() != null) {
			for (DnbUnusGlsyCtryAppy ctry : dnbUnusGlsy.getCountryApplicability()) {
				if (ctry.getExpnDt() != null && ctry.getExpnDt().before(new Date())) {
					continue;
				} else {
					activeCtryList.add(ctry);
				}
			}
			dnbUnusGlsy.setCountryApplicability(activeCtryList);
		}
		dnbUnusGlsy.setOfficialGeoName(dnbUnusGlsyTypCdText.replaceAll("ampersandSymbol", "&").replaceAll("\\d", "")
				.replaceAll("\\[", "").replaceAll("\\]", ""));
		model.addAttribute("dnbUnusGlsy", dnbUnusGlsy);
		return controlWordDetail;
	}

	/**
	 * 
	 * The method to update the control word text
	 *
	 * @param dnbUnusGlsy
	 * @param session
	 * @return View
	 */
	@RequestMapping(value = "/controlWordUpdate.form", method = RequestMethod.POST)
	public View controlWordUpdate(@ModelAttribute("dnbUnusGlsy") DnbUnusGlsy dnbUnusGlsy, HttpSession session) {
		LOGGER.info("entering ControlWordsController | controlWordUpdate");
		//audit variables
		Date startTime = new Date();
		
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		Long dnbUnusGlsyId = null;
		if (userContextVO != null) {
			String loggedInUser = userContextVO.getUserIdentifier();
			dnbUnusGlsyId =  ctrlWrdsProxy.updateControlWord(prepareDnbUnusGlsyForUpdate(dnbUnusGlsy, loggedInUser));
			boolean isDelete = ((dnbUnusGlsy.getExpnDt() != null) && (dnbUnusGlsy.getExpnDt().before(new Date())))
					? true : false;
			createControlWordsWorkflowTask(dnbUnusGlsy, userContextVO, isDelete ? DELETE : UPDATE);
		}

		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
				"controlWordUpdate", 0L, dnbUnusGlsyId, 0L, dnbUnusGlsy);
		
		return new RedirectView("submitterWorkQueueHome.form?domainName=Control Words");
	}

	/**
	 * 
	 * The method to identify the control words change type
	 *
	 * @param dnbUnusGlsy
	 * @param action
	 * @return type
	 */
	private String getControlWordChangeType(DnbUnusGlsy dnbUnusGlsy, String action) {
		String type = "0";
		if (action.equals(DELETE)) {
			switch (dnbUnusGlsy.getDnbUnusGlsyTypCd().intValue()) {
				case 24799 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_INDUSTRY_CODE_INFERRMENT_NOISE_WORD;
					break;
				case 24801 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_UNUSABLE_PHONE_AREA_CODE_NUMBER;
					break;
				case 24802 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_UNUSABLE_ADDRESS;
					break;
				case 24803 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_UNUSABLE_ORGANIZATION_NAME;
					break;
				case 24804 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_UNUSABLE_OFFENSIVE_WORD;
					break;
				case 24806 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_UNUSABLE_TELEPHONE_NUMBER;
					break;
				case 24808 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_UNUSABLE_INDIVIDUAL_NAME;
					break;
			}
		} else if (action.equals(UPDATE)) {
			switch (dnbUnusGlsy.getDnbUnusGlsyTypCd().intValue()) {
				case 24799 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_INDUSTRY_CODE_INFERRMENT_NOISE_WORD;
					break;
				case 24801 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_UNUSABLE_PHONE_AREA_CODE_NUMBER;
					break;
				case 24802 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_UNUSABLE_ADDRESS;
					break;
				case 24803 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_UNUSABLE_ORGANIZATION_NAME;
					break;
				case 24804 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_UNUSABLE_OFFENSIVE_WORD;
					break;
				case 24806 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_UNUSABLE_TELEPHONE_NUMBER;
					break;
				case 24808 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_UNUSABLE_INDIVIDUAL_NAME;
					break;
			}
		} else if (action.equals(ADD)) {
			switch (dnbUnusGlsy.getDnbUnusGlsyTypCd().intValue()) {
				case 24799 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_ADD_INDUSTRY_CODE_INFERRMENT_NOISE_WORD;
					break;
				case 24801 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_ADD_UNUSABLE_PHONE_AREA_CODE_NUMBER;
					break;
				case 24802 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_ADD_UNUSABLE_ADDRESS;
					break;
				case 24803 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_ADD_UNUSABLE_ORGANIZATION_NAME;
					break;
				case 24804 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_ADD_UNUSABLE_OFFENSIVE_WORD;
					break;
				case 24806 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_ADD_UNUSABLE_TELEPHONE_NUMBER;
					break;
				case 24808 :
					type = RefDataChangeTypeConstants.CHANGE_TYPE_ADD_UNUSABLE_INDIVIDUAL_NAME;
					break;
			}
		}
		return type;
	}

	/**
	 * 
	 * The method to prepare for the update unusable glossary
	 *
	 * @param dnbUnusGlsy
	 * @param loggedInUser
	 * @return
	 */
	private DnbUnusGlsy prepareDnbUnusGlsyForUpdate(DnbUnusGlsy dnbUnusGlsy, String loggedInUser) {
		Long idIndex = 0L;
		dnbUnusGlsy.setModifiedDate(new Date());
		dnbUnusGlsy.setModifiedUser(loggedInUser);

		List<DnbUnusGlsyCtryAppy> applicabilityList = new ArrayList<DnbUnusGlsyCtryAppy>();
		DnbUnusGlsyCtryAppy tempAppy = null;
		boolean isNewApplicability = true;
		if (dnbUnusGlsy.getCountryApplicabilityCheckboxValues() != null) {
			for (String countryGeoUnitId : dnbUnusGlsy.getCountryApplicabilityCheckboxValues()) {
				isNewApplicability = true;
				if (dnbUnusGlsy.getCountryApplicability() != null) {
					for (DnbUnusGlsyCtryAppy ctryAppy : dnbUnusGlsy.getCountryApplicability()) {
						if (String.valueOf(ctryAppy.getCtryGeoUnitId()).equalsIgnoreCase(countryGeoUnitId)) {
							isNewApplicability = false;
							break;
						}
					}
				}

				if (isNewApplicability) {
					tempAppy = new DnbUnusGlsyCtryAppy();
					tempAppy.setDnbUnusGlsyCtryAppyId(--idIndex);
					tempAppy.setCreatedDate(new Date());
					tempAppy.setCreatedUser(loggedInUser);
					tempAppy.setCtryGeoUnitId(Long.valueOf(countryGeoUnitId));
					tempAppy.setDnbUnusGlsyId(dnbUnusGlsy.getDnbUnusGlsyId());
					tempAppy.setEffvDt(new Date());
					tempAppy.setModifiedDate(new Date());
					tempAppy.setModifiedUser(loggedInUser);
					applicabilityList.add(tempAppy);
				}
			}
		}

		boolean isDeletedApplicability = true;
		if (dnbUnusGlsy.getCountryApplicability() != null) {
			for (DnbUnusGlsyCtryAppy ctryAppy : dnbUnusGlsy.getCountryApplicability()) {
				isDeletedApplicability = true;
				if (dnbUnusGlsy.getCountryApplicabilityCheckboxValues() != null) {
					for (String countryGeoUnitId : dnbUnusGlsy.getCountryApplicabilityCheckboxValues()) {
						if (String.valueOf(ctryAppy.getCtryGeoUnitId()).equalsIgnoreCase(countryGeoUnitId)) {
							isDeletedApplicability = false;
							break;
						}
					}
				}

				if (isDeletedApplicability) {
					ctryAppy.setExpnDt(new Date());
					ctryAppy.setModifiedDate(new Date());
					ctryAppy.setModifiedUser(loggedInUser);
					applicabilityList.add(ctryAppy);
				}
			}
		}

		dnbUnusGlsy.setCountryApplicability(applicabilityList);
		return dnbUnusGlsy;
	}

	/**
	 * 
	 * The method to create a workflow task
	 *
	 * @param dnbUnusGlsy
	 * @param userContextVO
	 * @param action
	 */
	private void createControlWordsWorkflowTask(DnbUnusGlsy dnbUnusGlsy, UserContextVO userContextVO, String action) {
		createCtrlWrdsWorkflowTask(String.valueOf(dnbUnusGlsy.getDnbUnusGlsyId()),
				getControlWordChangeType(dnbUnusGlsy, action), userContextVO);
	}

	/**
	 * 
	 * The method to display the home page of Area Code Numbers - Control Words
	 * UI
	 * 
	 * @param session
	 * @param model
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/areaCodeNumbersHome.form")
	public ModelAndView viewAreaCodeNumbersHome(HttpSession session, Model model) {
		LOGGER.info("entering ControlWordsController | viewAreaCodeNumbersHome");
		ModelAndView areaCodeNumbersSearch = new ModelAndView("areaCodeNumbersSearch");
		areaCodeNumbersSearch.addObject("allApplicableCountries",
				getAllAreaCodeApplicableGeoUnits(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY));
		areaCodeNumbersSearch.addObject("allApplicableTerritories",
				getAllAreaCodeApplicableGeoUnits(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_TERRITORY));
		model.addAttribute("controlWordsSearchVO", new ControlWordsSearchVO());
		return areaCodeNumbersSearch;
	}

	/**
	 * 
	 * The method to retrieve all applicable country codes for the Area Code
	 * Numbers
	 * 
	 * @param geoUnitTypeCode
	 * @return codeValueVOs
	 */
	private List<CodeValueVO> getAllAreaCodeApplicableGeoUnits(Long geoUnitTypeCode) {
		LOGGER.info("entering ControlWordsController | getAllAreaCodeApplicableCountries");
		return ctrlWrdsProxy.getAllAreaCodeApplicableGeoUnits(geoUnitTypeCode);
	}

	/**
	 * 
	 * Retrieves the Area Code search details.
	 * <p>
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/areaCodeSearchAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getAreaCodeSearchAjaxResults(HttpServletRequest request, HttpSession session) {
		LOGGER.info("entering ControlWordsController | getAreaCodeSearchAjaxResults");

		ControlWordsSearchVO controlWordsSearchVO = constructAreaCodeSearchCriteria(request);
//		if (controlWordsSearchVO.getSearchText() == null && controlWordsSearchVO.getCountryGeoUnitId() == null
//				&& controlWordsSearchVO.getTerritoryGeoUnitId() == null) {
//			return homeController.getJsonMap(request, new ArrayList<Object>(), 0L, areaCodeSearchColumns);
//		}
		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		Long countAreaCodeResults = (Long) session.getAttribute("countAreaCodeResults");
		if (countAreaCodeResults == null || controlWordsSearchVO.getRowIndex() == 0) {
			countAreaCodeResults = ctrlWrdsProxy.countSearchAreaCodeNumbers(controlWordsSearchVO);
			session.setAttribute("countAreaCodeResults", countAreaCodeResults);
		}

		List<PhoneAreaCode> areaCodeSerachResults = ctrlWrdsProxy.searchAreaCodeNumbers(controlWordsSearchVO);
		session.setAttribute("areaCodeSerachResults", areaCodeSerachResults);

		LOGGER.info("exiting ControlWordsController | getAreaCodeSearchAjaxResults");
		return homeController.getJsonMap(request, areaCodeSerachResults, countAreaCodeResults, areaCodeSearchColumns);
	}

	/**
	 * 
	 * The method to construct the controlWordsSearchVO from the data table
	 * request parameters. The method will retrieve all the details for search
	 * from the request
	 * 
	 * @param request
	 * @return controlWordsSearchVO
	 */
	private ControlWordsSearchVO constructAreaCodeSearchCriteria(HttpServletRequest request) {
		ControlWordsSearchVO controlWordsSearchVO = new ControlWordsSearchVO();
		controlWordsSearchVO.setSortOrder(homeController.getSortOrder(request));
		controlWordsSearchVO.setSortBy(homeController.getSortBy(request, areaCodeSearchColumns));
		controlWordsSearchVO.setMaxResults(homeController.getMaxResults(request));
		controlWordsSearchVO.setRowIndex(homeController.getStartIndex(request));
		String searchString = homeController.getSearchString(request);

		String searchCriteriaDelimiter = "#~";
		if (searchString != null) {
			String[] splitCriteria = searchString.split(searchCriteriaDelimiter);
			
			if ((splitCriteria.length > 0) && !(splitCriteria[0].trim().isEmpty())) {
				controlWordsSearchVO.setSearchText(splitCriteria[0].trim());
			}
			if ((splitCriteria.length > 1) && !(splitCriteria[1].trim().isEmpty())) {
				controlWordsSearchVO.setCountryGeoUnitId(Long.valueOf(splitCriteria[1].trim()));
			}
			if ((splitCriteria.length > 2) && !(splitCriteria[2].trim().isEmpty())) {
				controlWordsSearchVO.setTerritoryGeoUnitId(Long.valueOf(splitCriteria[2].trim()));
			}
			if ((splitCriteria.length > 3) && !(splitCriteria[3].trim().isEmpty())) {
				controlWordsSearchVO.setIsActive(true);
			}
			if ((splitCriteria.length > 4) && !(splitCriteria[4].trim().isEmpty())) {
				controlWordsSearchVO.setIsInactive(true);
			}
		}
		LOGGER.info("constructAreaCodeSearchCriteria | controlWordsSearchVO " + controlWordsSearchVO);
		return controlWordsSearchVO;
	}
	/**
	 * 
	 * Loads the Legal Forms search home page.
	 * <p>
	 * 
	 * @param session
	 * @return legalFormInferment, the ModelAndView
	 */
	@RequestMapping(value = "/legalFormInferment.form", method = RequestMethod.GET)
	public ModelAndView getLegalFormInfermentHome(HttpSession session) {
		LOGGER.info("entering ControlWordsController | getLegalFormInfermentHome");
		ModelAndView legalFormInferment = new ModelAndView("legalFormInferment");
		legalFormInferment.addObject("legalFormClassCodeList", ctrlWrdsProxy.retrieveLegalFormClassCodes());
		List<CodeValueVO> languageList = ctrlWrdsProxy.retrieveLegalFormLanguages();
		session.setAttribute(RefDataUIConstants.LEGAL_FORM_LANGUAGE_SESSION, languageList);
		legalFormInferment.addObject("languageList", languageList);
		legalFormInferment.addObject("legalFormCodeList", ctrlWrdsProxy.retrieveLegalFormCodes());
		legalFormInferment.addObject("legalFormCountryList", ctrlWrdsProxy.retrieveLegalFormCountries());
		return legalFormInferment;
	}
	/**
	 * 
	 * This method is invoked by datatables plugin through Ajax calls. Response
	 * is provided in JSON format.
	 * 
	 * @param ctrlWrdsSearchCriteria
	 * @param result
	 * @param response
	 * @param session
	 * @return List of InfermentText
	 */
	@RequestMapping(value = "/legalFormSearchAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getLegalFormSearchAjaxResults(HttpServletRequest request, HttpSession session) {
		LOGGER.info("entering ControlWordsController | getLegalFormSearchAjaxResults");
		ControlWordsSearchVO ctrlWrdsSearchCriteria = getCtrlWrdsSearchCriteria(request);

		LOGGER.info("entering ControlWordsController | getLegalFormSearchAjaxResults||ctrlWrdsSearchCriteria:"
				+ ctrlWrdsSearchCriteria);
		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		Long legalCountResults = (Long) session.getAttribute("legalCountResults");
		if ((legalCountResults == null) || (ctrlWrdsSearchCriteria.getRowIndex() == 0)) {
			legalCountResults = ctrlWrdsProxy.countSearchLegalFormInfermentText(ctrlWrdsSearchCriteria);
			session.setAttribute("legalCountResults", legalCountResults);
		}
		List<InfermentText> searchResults = ctrlWrdsProxy.searchLegalFormInfermentText(ctrlWrdsSearchCriteria);
		LOGGER.info("exiting ControlWordsController | getLegalFormSearchAjaxResults");
		return homeController.getJsonMap(request, searchResults, legalCountResults, ctrlWordsSearchColumns);
	}
	/**
	 * 
	 * The method will construct the CtrlWrdsSearchCriteria
	 * 
	 * @param request
	 * @return ctrlWrdsSearchCriteriaVO
	 */
	private ControlWordsSearchVO getCtrlWrdsSearchCriteria(HttpServletRequest request) {
		ControlWordsSearchVO ctrlWrdsSearchCriteriaVO = new ControlWordsSearchVO();
		ctrlWrdsSearchCriteriaVO.setSortOrder(homeController.getSortOrder(request));
		ctrlWrdsSearchCriteriaVO.setSortBy(homeController.getSortBy(request, ctrlWordsSearchColumns));
		ctrlWrdsSearchCriteriaVO.setMaxResults(homeController.getMaxResults(request));
		ctrlWrdsSearchCriteriaVO.setRowIndex(homeController.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);
		// Search string will be in the format
		// infr_txt#~country#~lgl_form_cd#~lgl_form_cls_cd#~lang_cd
		String searchCriteriaDelimiter = "~";
		if (compositeSearchString != null) {
			String[] splitCriteria = compositeSearchString.split(searchCriteriaDelimiter);
			if (splitCriteria.length > 0) {
				if (!(splitCriteria[0].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO.setInfermentText(splitCriteria[0].replace("#", "").trim());
				}
			}
			if (splitCriteria.length > 1) {
				if (!(splitCriteria[1].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO
							.setCountryGeoUnitId(Long.valueOf(splitCriteria[1].replace("#", "").trim()));
				}
			}
			if (splitCriteria.length > 2) {
				if (!(splitCriteria[2].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO.setLegalFormCode(Long.valueOf(splitCriteria[2].replace("#", "").trim()));
				}
			}
			if (splitCriteria.length > 3) {
				if (!(splitCriteria[3].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO.setLegalFormClassCode(Long.valueOf(splitCriteria[3].replace("#", "")
							.trim()));
				}
			}
			if (splitCriteria.length > 4) {
				if (!(splitCriteria[4].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO.setLanguageCode(Long.valueOf((splitCriteria[4].replace("#", "").trim())));
				}
			}
			if (splitCriteria.length > 5) {
				if (!(splitCriteria[5].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO.setIsActive(Boolean.valueOf(splitCriteria[5].replace("#", "").trim()));
				}
			}
			if (splitCriteria.length > 6) {
				if (!(splitCriteria[6].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO.setIsInactive(Boolean.valueOf(splitCriteria[6].replace("#", "").trim()));
				}
			}
		}
		return ctrlWrdsSearchCriteriaVO;
	}

	/**
	 * 
	 * The method to retrieve the legal form inferment by inferment id 
	 *
	 * @param infermentTextId
	 * @param taskId
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/legalFormInfermentView.form", method = RequestMethod.GET)
	public ModelAndView legalInfermentTextView(
			@RequestParam(RefDataUIConstants.INFERMENT_TEXT_ID_REQ_PARAM) final Long infermentTextId,
			@RequestParam("taskId") final String taskId, Model model, HttpSession session) {
		LOGGER.info("entering ControlWordsController | legalInfermentTextView");
		ModelAndView infermentTextView = new ModelAndView("legalFormInfermentView");
		InfermentText infermentText = null;
		if ((taskId != null) && !taskId.trim().isEmpty()) {
			infermentText = ctrlWrdsProxy.reviewInfermentChanges(Long.valueOf(infermentTextId));
		} else {
			infermentText = ctrlWrdsProxy.retrieveInfermentTextByInfermentTextId(Long.valueOf(infermentTextId));
		}
		prepareInfermentTextForView(infermentText);
		infermentTextView.addObject("legalFormClassCodeList", ctrlWrdsProxy.retrieveLegalFormClassCodes());
		infermentTextView.addObject("legalFormCodeList", ctrlWrdsProxy.retrieveLegalFormCodes());
		infermentTextView.addObject("legalFormCountryList", ctrlWrdsProxy.retrieveLegalFormCountries());
		infermentTextView.addObject("allCountries", geoWsProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));
		infermentTextView.addObject("today", new Date());
		// Retrieving the Lists of languages
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
		infermentTextView.addObject("languageCodeValues",
				tempCodeValueMap.get(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));
		LOGGER.info("exiting ControlWordsController | legalInfermentTextView ||infermentText" + infermentText);
		session.setAttribute("taskId", taskId);
		model.addAttribute("infermentText", infermentText);
		return infermentTextView;
	}
	/**
	 * 
	 * The method will validate the InfermentText for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param InfermentText
	 * @return boolean
	 */
	@RequestMapping(value = "lockInfermentTextForEdit.form", method = RequestMethod.GET)
	public @ResponseBody
	Boolean lockInfermentText(@ModelAttribute("infermentText") InfermentText infermentText, HttpSession session) {
		LOGGER.info("entering ControlWordsController | lockInfermentText||" + infermentText);
		String taskId = (String) session.getAttribute("taskId");
		if ((taskId != null) && !taskId.trim().isEmpty()) {
			return false;
		} else {
			Long lockInfermentTextId = infermentText.getInfermentTextId();
			return this.ctrlWrdsProxy.lockInfermentText(lockInfermentTextId);
		}
	}
	/**
	 * The method will persist the edited inferment Text in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param infermentText
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */

	@RequestMapping(value = "/updateLegalFormInferment.form", method = RequestMethod.POST)
	public View updateLegalFormInferment(@ModelAttribute("infermentText") InfermentText infermentText, Model model,
			SessionStatus sessionStatus, HttpSession session, HttpServletRequest request) throws ParseException {
		LOGGER.info("entering ControlWordsController | updateLegalFormInferment ||infermentText " + infermentText);
		//audit variables
		Date startTime = new Date();
		Long trackingId  =null;
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		if(userContextVO != null) {
			String loggedInUser = userContextVO.getUserIdentifier();
			infermentText.setModifiedUser(userContextVO.getUserIdentifier());
			infermentText.setModifiedDate(new Date());
	
			List<InfermentTextCountryApplicability> finalCountryUpdateList = getUpdatedCountryApplicabilities(infermentText);
	
			infermentText.setCountryApplicabilities(finalCountryUpdateList);
			prepareCountryApplicability(infermentText, loggedInUser);
			prepareInfermentText(infermentText, loggedInUser);
	
			LOGGER.info("\n\nupdated countries in list are: \n" + infermentText.getCountryApplicabilities());
	
			trackingId = ctrlWrdsProxy.updateInfermentText(infermentText);
	
			LOGGER.info("\n\nupdated code value with id: \n" + trackingId);
			String taskId = request.getParameter("taskId");
			if ((taskId != null) && !taskId.trim().isEmpty()) {
				homeController.reSubmitTaskRequest(userContextVO, taskId,
						RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						roleMapper.getSubmitterUserGroupId(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS, null));
			} else {
				createCtrlWrdsWorkflowTask(trackingId.toString(),
						RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_LEGAL_FORM_INFERMENT, userContextVO);
			}
			session.removeAttribute("taskId");
			sessionStatus.setComplete();
		}
		LOGGER.info("exiting ControlWordsController | updateLegalFormInferment ");

		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
				"controlWordUpdate", 0L, trackingId, 0L, infermentText);		

		return new RedirectView("submitterWorkQueueHome.form?domainName=Control Words");
	}

	/**
	 * Loads the Industry Codes Inferment search home page.
	 * <p>
	 * 
	 * Retrieves all industry codes inferment information to be populated in the
	 * screen.
	 * <p>
	 * 
	 * @param model
	 * @param session
	 * @return indsCodesSearchHome, the ModelAndView object
	 */
	@RequestMapping(value = "/indsCodeInfermentSearchHome.form", method = RequestMethod.GET)
	public ModelAndView getIndustryCodesInfermentSearchHome(HttpSession session) {
		LOGGER.info("entering ControlWordsController | getIndustryCodesInfermentSearchHome");
		ModelAndView indsCodesInfermentSearcHome = new ModelAndView("indsCodeSearchInferment");

		// Retrieving the Lists for Industry Code Type and Description
		Integer codeTableId = RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE;
		Long languageCode = RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH;
		List<IndustryCodeInferment> industryCodeTypeList = ctrlWrdsProxy.retrieveIndustryCodeTypeAndDesc(codeTableId,
				languageCode);
		List<IndustryCodeInferment> languageList = ctrlWrdsProxy.retrieveLanguageCode();
		
		indsCodesInfermentSearcHome.addObject("industryCodeTypeAndDescription", industryCodeTypeList);
		indsCodesInfermentSearcHome.addObject("languageList", languageList);
		indsCodesInfermentSearcHome.addObject("countryList", ctrlWrdsProxy.retrieveLegalFormCountries());

		session.setAttribute(RefDataUIConstants.INDUSTRY_CODES_SEARCH_INDUSTRY_CODE_INFERMENT_TYPES_SESSION,
				industryCodeTypeList);
		session.setAttribute(RefDataUIConstants.CTRL_WORD_LIST_CODE_LANGUAGE_SESSION, languageList);
		LOGGER.info("exiting ControlWordsController | getIndustryCodesInfermentSearchHome");
		return indsCodesInfermentSearcHome;
	}

	/**
	 * The method fetches the Industry Code Description for industry code type
	 * 
	 * @param industryCodeTypeCode
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "retrieveIndustryCodeDescriptionForIndsCodeType.form", method = RequestMethod.GET)
	public @ResponseBody
	List<IndustryCode> retrieveIndustryCodeDescription(
			@RequestParam(value = "industryCodeType", required = true) Long industryCodeTypeCode, HttpSession session) {

		LOGGER.info("entering ControlWordsController | retrieveIndustryCodeDescription");

		List<IndustryCode> industryCode = ctrlWrdsProxy.retrieveIndustryCodeDescription(industryCodeTypeCode);

		LOGGER.info("exiting ControlWordsController | retrieveIndustryCodeDescription");
		return industryCode;

	}

	/**
	 * 
	 * The method to toggle the Parent Code Table drop down values
	 * 
	 * @param toggleIndicator
	 * @param session
	 * @return model
	 * @return codeValues
	 */
	@SuppressWarnings({"unchecked", "rawtypes"})
	@RequestMapping(value = "toggleIndsCodeTypeTable.form", method = RequestMethod.GET)
	public @ResponseBody
	List<IndustryCodeInferment> toggleCodeTables(
			@RequestParam(value = "toggleIndicator", required = true) String toggleIndicator, HttpSession session,
			Model model) {
		LOGGER.info("toggleIndicator : " + toggleIndicator);

		List industryCodeTypeList = (List) session
				.getAttribute(RefDataUIConstants.INDUSTRY_CODES_SEARCH_INDUSTRY_CODE_INFERMENT_TYPES_SESSION);

		if (industryCodeTypeList != null) {
			if (RefDataUIConstants.TOGGLE_INDICATOR_CODE.equals(toggleIndicator)) {
				Collections.sort(industryCodeTypeList, new IndustryCodeInfermentComparable());
				model.addAttribute("toggleIndicator", RefDataUIConstants.TOGGLE_INDICATOR_VALUE);

			} else if (RefDataUIConstants.TOGGLE_INDICATOR_VALUE.equals(toggleIndicator)) {
				Collections.sort(industryCodeTypeList, new IndustryCodeInfermentLiteralComparable());
				model.addAttribute("toggleIndicator", RefDataUIConstants.TOGGLE_INDICATOR_CODE);
			}
		}
		return industryCodeTypeList;
	}

	/**
	 * 
	 * The method to toggle the Parent Code Table drop down values
	 * 
	 * @param toggleIndicator
	 * @param session
	 * @return model
	 * @return codeValues
	 */
	@SuppressWarnings({"unchecked", "rawtypes"})
	@RequestMapping(value = "togglelanguageCodeTable.form", method = RequestMethod.GET)
	public @ResponseBody
	List<IndustryCodeInferment> toggleLanguageCodeTables(
			@RequestParam(value = "toggleIndicator", required = true) String toggleIndicator, HttpSession session,
			Model model) {
		LOGGER.info("entering ControlWordsController | toggleLanguageCodeTables");
		LOGGER.info("toggleIndicator : " + toggleIndicator);

		List languageCodeList = (List) session.getAttribute(RefDataUIConstants.CTRL_WORD_LIST_CODE_LANGUAGE_SESSION);

		if (languageCodeList != null) {
			if (RefDataUIConstants.TOGGLE_INDICATOR_CODE.equals(toggleIndicator)) {
				Collections.sort(languageCodeList, new LanguageInfermentComparable());
				model.addAttribute("toggleIndicator", RefDataUIConstants.TOGGLE_INDICATOR_VALUE);

			} else if (RefDataUIConstants.TOGGLE_INDICATOR_VALUE.equals(toggleIndicator)) {
				Collections.sort(languageCodeList, new LanguageInfermentLiteralComparable());
				model.addAttribute("toggleIndicator", RefDataUIConstants.TOGGLE_INDICATOR_CODE);
			}
		}
		LOGGER.info("languageCodeList is " + languageCodeList);
		return languageCodeList;
	}

	/**
	 * The method to retrieve the industry code inferment search results
	 * 
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/indsCodeInfermentSearchAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getIndustryCodeInfermentSearchAjaxResults(HttpServletRequest request, HttpSession session) {
		LOGGER.info("entering IndustryCodesController | getIndustryCodesSearchAjaxResults");

		ControlWordsSearchVO industryCodesInfermentSearchCriteria = getIndustryCodeInfermentSearchCriteria(request);

		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		Long countIndustryCodesInfermentResults = (Long) session.getAttribute("countIndustryCodesInfermentResults");
		if ((countIndustryCodesInfermentResults == null) || (industryCodesInfermentSearchCriteria.getRowIndex() == 0)) {
			countIndustryCodesInfermentResults = ctrlWrdsProxy
					.countSearchIndustryCodesInferment(industryCodesInfermentSearchCriteria);
			session.setAttribute("countIndustryCodesInfermentResults", countIndustryCodesInfermentResults);
		}

		LOGGER.info("exiting IndustryCodesController | getIndustryCodesSearchAjaxResults");
		return homeController.getJsonMap(request,
				ctrlWrdsProxy.searchIndustryCodesInferment(industryCodesInfermentSearchCriteria),
				countIndustryCodesInfermentResults, industryInfermentSearchColumns);
	}

	/**
	 * The method for the industry code inferment search view
	 * 
	 * @param session
	 * @return
	 */
	@SuppressWarnings({"rawtypes", "unchecked"})
	@RequestMapping(value = "/indsCodeInfermentSearchView.form", method = RequestMethod.GET)
	public ModelAndView industryCodeInfermentSearchView(
			@RequestParam(RefDataUIConstants.CTRL_WORDS_INFERMENT_TEXT_REQ_PARAM) final String infermentTextId,
			@RequestParam("taskId") final String taskId, Model model, HttpSession session) {
		LOGGER.info("entering ControlWordsController | industryCodeInfermentSearchView");

		LOGGER.info("infermentText is " + infermentTextId);
		ModelAndView indsCodeInfermentSearchView = new ModelAndView("indsCodeInfermentSearchView");

		InfermentText infermentTextObj = null;
		IndustryCodeInferment industryCodeInferment = null;
		if ((taskId != null) && !taskId.trim().isEmpty()) {
			infermentTextObj = ctrlWrdsProxy.reviewInfermentChanges(Long.valueOf(infermentTextId));
		} else {
			infermentTextObj = ctrlWrdsProxy.retrieveInfermentTextByInfermentTextId(Long.valueOf(infermentTextId));

		}

		LOGGER.info("infermentTextObj is " + infermentTextObj);

		// fetch all details other than country applicability
		industryCodeInferment = ctrlWrdsProxy.industryCodeInfermentSearchView(Long.valueOf(infermentTextId));
		LOGGER.info(" industryCodeInferment is " + industryCodeInferment);

		// setting IndustryCode object

		// fetching industry code type
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);

		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
		List codeValues = tempCodeValueMap.get(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING);
		LOGGER.info("codeValues is " + codeValues);
		// sort the codeValues based on the Code Value Id
		Collections.sort(codeValues, new IndustryCodeValueIdComparable());

		session.setAttribute(RefDataUIConstants.INDUSTRY_CODES_SEARCH_INDUSTRY_CODE_TYPES_SESSION, codeValues);

		// fetching the country applicability list
		indsCodeInfermentSearchView.addObject("legalFormCountryList", ctrlWrdsProxy.retrieveLegalFormCountries());
		indsCodeInfermentSearchView.addObject("allCountries", geoWsProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));

		// Retrieving the Lists of languages
		indsCodeInfermentSearchView.addObject("languageCodeValues",
				tempCodeValueMap.get(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));

		indsCodeInfermentSearchView.addObject("infermentTextView", industryCodeInferment);
		model.addAttribute("infermentText", infermentTextObj);

		return indsCodeInfermentSearchView;

	}

	/**
	 * The method will persist the edited inferment Text in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param infermentText
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/updateIndustryFormInferment.form", method = RequestMethod.POST)
	public View updateIndustryCodeInferment(@ModelAttribute("infermentText") InfermentText infermentText, Model model,
			SessionStatus sessionStatus, HttpSession session, HttpServletRequest request) throws ParseException {
		LOGGER.info("entering ControlWordsController | updateIndustryCodeInferment ||infermentText " + infermentText);
		//audit variables
		Date startTime = new Date();
		
		Long trackingId =null;
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		if(userContextVO != null) {
			String loggedInUser = userContextVO.getUserIdentifier();
			infermentText.setModifiedUser(userContextVO.getUserIdentifier());
			infermentText.setModifiedDate(new Date());
	
			List<InfermentTextCountryApplicability> finalCountryUpdateList = getUpdatedCountryApplicabilities(infermentText);
	
			infermentText.setCountryApplicabilities(finalCountryUpdateList);
			prepareCountryApplicability(infermentText, loggedInUser);
		        prepareIndustryCodeInferment(infermentText, loggedInUser);
			prepareInfermentText(infermentText, loggedInUser);
	
			LOGGER.info("\n\nupdated countries in list are: \n" + infermentText.getCountryApplicabilities());
	
			trackingId = ctrlWrdsProxy.updateInfermentText(infermentText);
	
			LOGGER.info("\n\nupdated code value with id: \n" + trackingId);
			String taskId = request.getParameter("taskId");
			if ((taskId != null) && !taskId.trim().isEmpty()) {
				homeController.reSubmitTaskRequest(userContextVO, taskId,
						RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						roleMapper.getSubmitterUserGroupId(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS, null));
			} else {
				createCtrlWrdsWorkflowTask(trackingId.toString(),
						RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_INDUSTRY_CODE_INFERMENT, userContextVO);
			}
			session.removeAttribute("taskId");
			sessionStatus.setComplete();
		}
		LOGGER.info("exiting ControlWordsController | updateIndustryCodeInferment ");

		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
				"controlWordUpdate", 0L, trackingId, 0L, infermentText);
		
		return new RedirectView("submitterWorkQueueHome.form?domainName=Control Words");
	}

	/**
	 * 
	 * The method to update the countryApplicabilities for the codeValue
	 * 
	 * @param codeValue
	 * @return
	 */
	private List<InfermentTextCountryApplicability> getUpdatedCountryApplicabilities(InfermentText infermentText) {

		int countryFlag = 0;
		List<String> countryList = infermentText.getCountryList();
		LOGGER.info("countryList ||" + countryList);
		List<InfermentTextCountryApplicability> initialCountries = infermentText.getCountryApplicabilities();
		List<InfermentTextCountryApplicability> finalCountryUpdateList = new ArrayList<InfermentTextCountryApplicability>();

		if (initialCountries != null) {
			for (InfermentTextCountryApplicability countries : initialCountries) {
				for (String updateCountryList : infermentText.getCountryList()) {
					if (Long.valueOf(countries.getIcountryGeoUnitId()).compareTo(Long.valueOf(updateCountryList)) == 0) {
						countryFlag = 1;
						break;
					}
				}
				if (countryFlag == 1) {
					countryList.remove(countries.getIcountryGeoUnitId().toString());
					countryFlag = 0;
				} else {
					countries.setExpirationDate(new Date());
					finalCountryUpdateList.add(countries);
				}
			}
		}
		if (countryList != null && !countryList.isEmpty()) {
			for (String updateCountryList : countryList) {
				InfermentTextCountryApplicability newCountry = new InfermentTextCountryApplicability();
				newCountry.setInfermentTextId(infermentText.getInfermentTextId());
				newCountry.setIcountryGeoUnitId(Long.valueOf(updateCountryList));
				finalCountryUpdateList.add(newCountry);
			}
		}
		
		LOGGER.info("getUpdatedCountryApplicabilities | finalCountryUpdateList " + finalCountryUpdateList);		
		return finalCountryUpdateList;
	}
	/**
	 * Prepare InfermentCountryApplicability for InfermentText update
	 * 
	 * @param infermentText
	 * @param loggedInUser
	 */
	private void prepareCountryApplicability(InfermentText infermentText, String loggedInUser) {
		// Remove empty list
		if (infermentText.getCountryApplicabilities() != null && infermentText.getCountryApplicabilities().size() == 1) {
			InfermentTextCountryApplicability currCountry = infermentText.getCountryApplicabilities().get(0);
			if (currCountry.getIcountryGeoUnitId() == null) {
				infermentText.getCountryApplicabilities().remove(0);
			}
		}
		if (infermentText.getCountryApplicabilities() != null) {
			Date today = new Date();
			Long ctryAppyId = 0L;
			for (InfermentTextCountryApplicability currCountry : infermentText.getCountryApplicabilities()) {
				if (currCountry.getInfermentTextCountryApplicabilityId() == null) {
					currCountry.setInfermentTextCountryApplicabilityId(ctryAppyId--);
					currCountry.setEffectiveDate(today);
				}
				currCountry.setCreatedDate(today);
				currCountry.setCreatedUser(loggedInUser);
				currCountry.setModifiedDate(today);
				currCountry.setModifiedUser(loggedInUser);
			}
		}
	}

	/**
	 * 
	 * The method to populate the mandatory attributes to IndustryCodeInferment
	 *
	 * @param infermentText
	 * @param loggedInUser
	 */
	private void prepareIndustryCodeInferment(InfermentText infermentText, String loggedInUser) {
		List<IndustryCodeInferment> industryCodeInfermentList = new ArrayList<IndustryCodeInferment>();
		LOGGER.info("infermentText.getIndustryCodeList() size is " + infermentText.getIndustryCodeList().size());
		for (IndustryCode industryCode : infermentText.getIndustryCodeList()) {
			LOGGER.info("industryCode is  " + industryCode);
			Long industryCodeInfermentId = 0L;
			Date today = new Date();
			IndustryCodeInferment industryCodeInferment = new IndustryCodeInferment();
			industryCodeInferment.setIndustryCodeInfermentId(industryCodeInfermentId--);
			industryCodeInferment.setIndustryCodeId(industryCode.getIndustryCodeId());
			industryCodeInferment.setInfermentTextId(infermentText.getInfermentTextId());

			industryCodeInferment.setCreatedDate(today);
			industryCodeInferment.setCreatedUser(loggedInUser);
			industryCodeInferment.setModifiedDate(today);
			industryCodeInferment.setModifiedUser(loggedInUser);
			industryCodeInfermentList.add(industryCodeInferment);
		}
		LOGGER.info("industryCodeInfermentList " + industryCodeInfermentList);
		infermentText.setIndustryCodeInferment(industryCodeInfermentList);
	}
	/**
	 * 
	 * Prepare the InfermentText for InfermentText update
	 * 
	 * @param InfermentText
	 * @param loggedInUser
	 */
	private void prepareInfermentText(InfermentText infermentText, String loggedInUser) {
		// Remove empty list
		if (infermentText.getLegalFormInferments() != null && infermentText.getLegalFormInferments().size() == 1) {
			LegalFormInferment currLegalFormInferment = infermentText.getLegalFormInferments().get(0);
			if (currLegalFormInferment.getLegalFormInfermentId() == null) {
				infermentText.getLegalFormInferments().remove(0);
			}
		}
		if (infermentText.getLegalFormInferments() != null) {
			Date today = new Date();
			Long legalFormInfermentId = 0L;
			for (LegalFormInferment currLegalFormInferment : infermentText.getLegalFormInferments()) {
				if (currLegalFormInferment.getLegalFormInfermentId() == null) {
					currLegalFormInferment.setLegalFormInfermentId(legalFormInfermentId--);
					currLegalFormInferment.setEffectiveDate(today);
				}
				currLegalFormInferment.setInfermentTextId(infermentText.getInfermentTextId());
				currLegalFormInferment.setCreatedDate(today);
				currLegalFormInferment.setCreatedUser(loggedInUser);
				currLegalFormInferment.setModifiedDate(today);
				currLegalFormInferment.setModifiedUser(loggedInUser);
			}
		}

		if (infermentText.getIndustryCodeInferment() != null && infermentText.getIndustryCodeInferment().size() == 1) {
			IndustryCodeInferment currIndustryCodeInferment = infermentText.getIndustryCodeInferment().get(0);
			if (currIndustryCodeInferment.getIndustryCodeInfermentId() == null) {
				infermentText.getIndustryCodeInferment().remove(0);
			}
		}

		if (infermentText.getIndustryCodeInferment() != null) {
			Date today = new Date();
			Long industryCodeInfermentId = 0L;
			for (IndustryCodeInferment currindustryCodeInferment : infermentText.getIndustryCodeInferment()) {
				if (currindustryCodeInferment.getIndustryCodeInfermentId() == null) {
					currindustryCodeInferment.setIndustryCodeInfermentId(industryCodeInfermentId--);
				}
				LOGGER.info("infermentText.getIndustryCodeList().get(0).getIndustryCodeId() is"
						+ infermentText.getIndustryCodeList().get(0).getIndustryCodeId());
				currindustryCodeInferment.setIndustryCodeId(infermentText.getIndustryCodeList().get(0)
						.getIndustryCodeId());
				currindustryCodeInferment.setInfermentTextId(infermentText.getInfermentTextId());
				currindustryCodeInferment.setCreatedDate(today);
				currindustryCodeInferment.setCreatedUser(loggedInUser);
				currindustryCodeInferment.setModifiedDate(today);
				currindustryCodeInferment.setModifiedUser(loggedInUser);
			}
		}
	}
	/**
	 * This method is to remove those data in InfermentText entity which has an
	 * expiration date less than today
	 * 
	 * @param infermentText
	 */
	private void prepareInfermentTextForView(InfermentText infermentText) {
		if (null != infermentText.getCountryApplicabilities()) {
			List<InfermentTextCountryApplicability> applicableCountries = new ArrayList<InfermentTextCountryApplicability>();
			for (InfermentTextCountryApplicability country : infermentText.getCountryApplicabilities()) {
				if ((country.getExpirationDate() == null)
						|| (((country.getExpirationDate()) != null) && !((new Date()).compareTo((country
								.getExpirationDate())) > 0))) {
					applicableCountries.add(country);
				}
			}
			infermentText.setCountryApplicabilities(applicableCountries);
		}

		if (null != infermentText.getLegalFormInferments()) {
			List<LegalFormInferment> legalFormInferments = new ArrayList<LegalFormInferment>();
			for (LegalFormInferment legalFormInferment : infermentText.getLegalFormInferments()) {
				if ((legalFormInferment.getExpirationDate() == null)
						|| (((legalFormInferment.getExpirationDate()) != null) && !((new Date())
								.compareTo((legalFormInferment.getExpirationDate())) > 0))) {
					legalFormInferments.add(legalFormInferment);
				}
			}
			infermentText.setLegalFormInferments(legalFormInferments);
		}
	}

	/**
	 * 
	 * The method to populate the Industry Code Inferment Search Criteria
	 *
	 * @param request
	 * @return
	 */
	private ControlWordsSearchVO getIndustryCodeInfermentSearchCriteria(HttpServletRequest request) {
		ControlWordsSearchVO industryCodeInfermentSearchCriteria = new ControlWordsSearchVO();
		industryCodeInfermentSearchCriteria.setSortOrder(homeController.getSortOrder(request));
		industryCodeInfermentSearchCriteria.setMaxResults(homeController.getMaxResults(request));
		industryCodeInfermentSearchCriteria.setRowIndex(homeController.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);

		String searchCriteriaDelimiter = "~";
		if (compositeSearchString != null) {
			String[] splitCriteria = compositeSearchString.split(searchCriteriaDelimiter);

			if (splitCriteria.length > 0) {
				if (!(splitCriteria[0].replace("#", "").trim().isEmpty())) {
					industryCodeInfermentSearchCriteria.setInfermentText(splitCriteria[0].replace("#", "").trim());
				}
			}
			if (splitCriteria.length > 1) {
				if (!(splitCriteria[1].replace("#", "").trim().isEmpty())) {
					industryCodeInfermentSearchCriteria.setCountryGeoUnitId(Long.valueOf(splitCriteria[1].replace("#",
							"").trim()));
				}
			}
			if (splitCriteria.length > 2) {
				if (!(splitCriteria[2].replace("#", "").trim().isEmpty())) {
					industryCodeInfermentSearchCriteria.setIndustryCodeType(splitCriteria[2].replace("#", "").trim());
				}
			}
			if (splitCriteria.length > 3) {
				if (!(splitCriteria[3].replace("#", "").trim().isEmpty())) {
					industryCodeInfermentSearchCriteria.setIndustryCode(splitCriteria[3].replace("#", "").trim());
				}
			}
			if (splitCriteria.length > 4) {
				if (!(splitCriteria[4].replace("#", "").trim().isEmpty())) {
					industryCodeInfermentSearchCriteria.setLanguageCode(Long.valueOf((splitCriteria[4].replace("#", "")
							.trim())));
				}
			}
		}

		return industryCodeInfermentSearchCriteria;

	}
	/**
	 * 
	 * The method to toggle the languages drop down values
	 * 
	 * @param toggleIndicator
	 * @param session
	 * @return model
	 * @return codeValues
	 */
	@SuppressWarnings({"unchecked", "rawtypes"})
	@RequestMapping(value = "toggleLegalFormLanguages.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> toggleLegalFormLanguages(
			@RequestParam(value = "toggleIndicator", required = true) Boolean toggleIndicator, HttpSession session) {
		LOGGER.info("toggleIndicator : " + toggleIndicator);

		List codeValueVOList = (List) session.getAttribute(RefDataUIConstants.LEGAL_FORM_LANGUAGE_SESSION);
		LOGGER.info("language list before toggle: " + codeValueVOList);
		if (codeValueVOList != null) {
			if (toggleIndicator) {
				Collections.sort(codeValueVOList, scotsController.new MsaValueComparable());

			} else {
				Collections.sort(codeValueVOList, scotsController.new MsaCodeComparable());
			}
		}

		LOGGER.info("language list after toggle: " + codeValueVOList);
		return codeValueVOList;
	}

	/**
	 * 
	 * The method to toggle the languages drop down values
	 * 
	 * @param toggleIndicator
	 * @param session
	 * @return model
	 * @return codeValues
	 */
	@SuppressWarnings({"unchecked", "rawtypes"})
	@RequestMapping(value = "toggleAddLegalFormLanguages.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> toggleAddLegalFormLanguages(
			@RequestParam(value = "addLegalLanguageToggleindc", required = true) Boolean toggleIndicator,
			HttpSession session) {
		LOGGER.info("toggleIndicator : " + toggleIndicator);

		List codeValueList = (List) session.getAttribute(RefDataUIConstants.LEGAL_FORM_LANGUAGE_SESSION);
		LOGGER.info("language list before toggle: " + codeValueList);
		if (codeValueList != null) {
			if (toggleIndicator) {
				Collections.sort(codeValueList, scotsController.new MsaCodeDescriptionComparable());

			} else {
				Collections.sort(codeValueList, scotsController.new CodeValueIdComparable());
			}
		}

		LOGGER.info("language list after toggle: " + codeValueList);
		return codeValueList;
	}

	/**
	 * 
	 * The Comparator class will sort the CodeValue based on the code
	 * 
	 * @author Cognizant
	 * @version last updated : Mar 12, 2012
	 * @see
	 * 
	 */
	@SuppressWarnings("rawtypes")
	private class IndustryCodeInfermentComparable implements Comparator<LinkedHashMap> {

		@Override
		public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
			return ((Integer) codeValue1.get("industryCodeTypeCode")).compareTo((Integer) codeValue2
					.get("industryCodeTypeCode"));
		}
	}

	/**
	 * 
	 * The Comparator class will sort the CodeValue based on the
	 * codeValueDescription
	 * 
	 * @author Cognizant
	 * @version last updated : Mar 12, 2012
	 * @see
	 * 
	 */
	@SuppressWarnings("rawtypes")
	private class IndustryCodeInfermentLiteralComparable implements Comparator<LinkedHashMap> {

		@Override
		public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
			return ((String) codeValue1.get("codeValueShortDescription")).compareTo((String) codeValue2
					.get("codeValueShortDescription"));
		}
	}

	/**
	 * 
	 * The method to display the control words home page
	 *
	 * @return
	 */
	@RequestMapping(value = "/addControlWordsText.form")
	public ModelAndView showAddControlWordsHome() {
		LOGGER.info("entering ControlWordsController | showAddControlWordsHome");
		ModelAndView addControlWords = new ModelAndView("addControlWordsText");
		addControlWords.addObject("allControlWords", ctrlWrdsProxy.retrieveAllControlWords());
		addControlWords.addObject("allCountries", geoWsProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));
		addControlWords.addObject("dnbUnusGlsy", new DnbUnusGlsy());
		List<String> areaCode = ctrlWrdsProxy.retrieveAreaCodeInfo();
		addControlWords.addObject("areaCode", areaCode.subList(0, areaCode.indexOf("#####")));
		addControlWords.addObject("areaCodeServDesc", areaCode.subList(areaCode.indexOf("#####") + 1, areaCode.size()));
		return addControlWords;
	}

	/**
	 * 
	 * The method to insert a new control word text
	 *
	 * @param dnbUnusGlsy
	 * @param session
	 * @return RedirectView
	 */
	@RequestMapping(value = "/controlWordInsert.form", method = RequestMethod.POST)
	public View controlWordInsert(@ModelAttribute("dnbUnusGlsy") DnbUnusGlsy dnbUnusGlsy, HttpSession session) {
		LOGGER.info("entering ControlWordsController | controlWordInsert");
		//audit variables
		Date startTime = new Date();
		
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		Long dnbUnusGlsyId  =null;
		if (userContextVO != null) {
			String loggedInUser = userContextVO.getUserIdentifier();

			dnbUnusGlsyId = ctrlWrdsProxy
					.updateControlWord(prepareDnbUnusGlsyForInsert(dnbUnusGlsy, loggedInUser));

			dnbUnusGlsy.setDnbUnusGlsyId(dnbUnusGlsyId);
			createControlWordsWorkflowTask(dnbUnusGlsy, userContextVO, ADD);
		}
		
		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
				"controlWordInsert", 0L, dnbUnusGlsyId, 0L, dnbUnusGlsy);
		
		return new RedirectView("submitterWorkQueueHome.form?domainName=Control Words");
	}

	/**
	 * 
	 * The method to prepare the insert of unusable glosaary 
	 *
	 * @param dnbUnusGlsy
	 * @param loggedInUser
	 * @return
	 */
	private DnbUnusGlsy prepareDnbUnusGlsyForInsert(DnbUnusGlsy dnbUnusGlsy, String loggedInUser) {
		switch (dnbUnusGlsy.getDnbUnusGlsyTypCd().intValue()) {
			case 24804 :
				dnbUnusGlsy.setDnbUnusIndNme(null);
				dnbUnusGlsy.setDnbUnusAdr(null);
				dnbUnusGlsy.setPhoneAreaCode(null);
				dnbUnusGlsy.setTelecomAddress(null);
				break;
			case 24808 :
				dnbUnusGlsy.setDnbUnusAdr(null);
				dnbUnusGlsy.setPhoneAreaCode(null);
				dnbUnusGlsy.setTelecomAddress(null);
				break;
			case 24803 :
				dnbUnusGlsy.setDnbUnusIndNme(null);
				dnbUnusGlsy.setDnbUnusAdr(null);
				dnbUnusGlsy.setPhoneAreaCode(null);
				dnbUnusGlsy.setTelecomAddress(null);
				break;
			case 24799 :
				dnbUnusGlsy.setDnbUnusIndNme(null);
				dnbUnusGlsy.setDnbUnusAdr(null);
				dnbUnusGlsy.setPhoneAreaCode(null);
				dnbUnusGlsy.setTelecomAddress(null);
				break;
			case 24806 :
				dnbUnusGlsy.setDnbUnusIndNme(null);
				dnbUnusGlsy.setDnbUnusAdr(null);
				dnbUnusGlsy.setPhoneAreaCode(null);
				break;
			case 24802 :
				dnbUnusGlsy.setDnbUnusIndNme(null);
				dnbUnusGlsy.setTelecomAddress(null);
				dnbUnusGlsy.setPhoneAreaCode(null);
				break;
			case 24801 :
				dnbUnusGlsy.setDnbUnusIndNme(null);
				dnbUnusGlsy.setTelecomAddress(null);
				dnbUnusGlsy.setDnbUnusAdr(null);
				break;
		}
		dnbUnusGlsy.setDnbUnusTxt(dnbUnusGlsy.getDnbUnusTxt());
		dnbUnusGlsy.setDnbUnusGlsyId(null);
		dnbUnusGlsy.setCreatedDate(new Date());
		dnbUnusGlsy.setCreatedUser(loggedInUser);
		dnbUnusGlsy.setModifiedDate(new Date());
		dnbUnusGlsy.setModifiedUser(loggedInUser);
		Long idIndex = 0L;

		List<DnbUnusGlsyCtryAppy> applicabilityList = new ArrayList<DnbUnusGlsyCtryAppy>();
		if (dnbUnusGlsy.getCountryApplicabilityCheckboxValues() != null) {
			for (String countryGeoUnitId : dnbUnusGlsy.getCountryApplicabilityCheckboxValues()) {
				DnbUnusGlsyCtryAppy tempAppy = new DnbUnusGlsyCtryAppy();
				tempAppy.setDnbUnusGlsyCtryAppyId(--idIndex);
				tempAppy.setCreatedDate(new Date());
				tempAppy.setCreatedUser(loggedInUser);
				tempAppy.setCtryGeoUnitId(Long.valueOf(countryGeoUnitId));
				tempAppy.setEffvDt(new Date());
				tempAppy.setModifiedDate(new Date());
				tempAppy.setModifiedUser(loggedInUser);
				applicabilityList.add(tempAppy);
			}

			dnbUnusGlsy.setCountryApplicability(applicabilityList);
		}
		return dnbUnusGlsy;
	}

	/**
	 * 
	 * The Comparator class will sort the CodeValue based on the code
	 * 
	 * @author Cognizant
	 * @version last updated : Mar 12, 2012
	 * @see
	 * 
	 */
	@SuppressWarnings("rawtypes")
	private class LanguageInfermentComparable implements Comparator<LinkedHashMap> {

		@Override
		public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
			return ((Integer) codeValue1.get("languageCode")).compareTo((Integer) codeValue2.get("languageCode"));
		}
	}

	/**
	 * 
	 * The Comparator class will sort the CodeValue based on the
	 * codeValueShortDescription
	 * 
	 * @author Cognizant
	 * @version last updated : Mar 12, 2012
	 * @see
	 * 
	 */
	@SuppressWarnings("rawtypes")
	private class LanguageInfermentLiteralComparable implements Comparator<LinkedHashMap> {

		@Override
		public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
			return ((String) codeValue1.get("codeValueShortDescription")).compareTo((String) codeValue2
					.get("codeValueShortDescription"));
		}
	}

	/**
	 * 
	 * The Comparator class will sort the CodeValue based on the
	 * codeValueId
	 * 
	 * @author Cognizant
	 * @version last updated : Mar 12, 2012
	 * @see
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public class IndustryCodeValueIdComparable implements Comparator<LinkedHashMap> {

		@Override
		public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
			return ((Integer) codeValue1.get("codeValueId")).compareTo((Integer) codeValue2.get("codeValueId"));
		}
	}
	/**
	 * 
	 * The method for add legal form inferment
	 *
	 * @param model
	 * @param session
	 * @return
	 */
	@SuppressWarnings({"rawtypes", "unchecked"})
	@RequestMapping(value = "/addLegalFormInferment.form", method = RequestMethod.GET)
	public ModelAndView addLegalFormInferment(Model model, HttpSession session) {
		LOGGER.info("entering ControlWordsController | addLegalFormInferment");
		ModelAndView infermentTextView = new ModelAndView("addLegalFormInferment");
		infermentTextView.addObject("legalFormClassCodeList", ctrlWrdsProxy.retrieveLegalFormClassCodes());
		infermentTextView.addObject("legalFormCodeList", ctrlWrdsProxy.retrieveLegalFormCodes());
		infermentTextView.addObject("legalFormCountryList", ctrlWrdsProxy.retrieveLegalFormCountries());
		infermentTextView.addObject("allCountries", geoWsProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));
		infermentTextView.addObject("today", new Date());
		// Retrieving the Lists of languages
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
		List languageCodeValues = tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE));
		// sort the list of languages and add to model
		Collections.sort(languageCodeValues, scotsController.new CodeValueIdComparable());
		session.setAttribute(RefDataUIConstants.LEGAL_FORM_LANGUAGE_SESSION, languageCodeValues);
		infermentTextView.addObject("languageCodeValues", languageCodeValues);
		model.addAttribute("infermentText",
				prepareInfermentTextForAdd(session, null, RefDataPropertiesConstants.CODE_INFERMENT_TYPE_LEGAL));
		LOGGER.info("exiting ControlWordsController | addLegalFormInferment ");
		return infermentTextView;
	}
	/**
	 * 
	 * The method to retrieve the area code numbers
	 *
	 * @param phoneAreaCodeId
	 * @param isStagingDB
	 * @param taskId
	 * @param model
	 * @param session
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getAddAreaCodeNumbers.form", method = RequestMethod.GET)
	public ModelAndView getAddAreaCodeNumbers(@RequestParam("phoneAreaCodeId") final Long phoneAreaCodeId,
			@RequestParam("isStagingDB") final Boolean isStagingDB,
			@RequestParam("taskId") final Long taskId,
			Model model, HttpSession session) {
		LOGGER.info("entering ControlWordsController | getAddAreaCodeNumbers");
		ModelAndView addAreaCodeNumbersModelAndView = new ModelAndView("addAreaCodeNumbers");
		List<CodeValueVO> addAreaCodeCountryList = (List<CodeValueVO>) session.getAttribute("addAreaCodeCountryList");
		if (addAreaCodeCountryList == null) {
			addAreaCodeCountryList = geoWsProxy.retrieveAllCountries(
					RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
					RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			session.setAttribute("addAreaCodeCountryList", addAreaCodeCountryList);
		}
		PhoneAreaCode phoneAreaCode = null;
		if ((phoneAreaCodeId != null) && (phoneAreaCodeId > 0)) {
			phoneAreaCode = ctrlWrdsProxy.retrievePhoneAreaCodeById(phoneAreaCodeId, isStagingDB);
			List<CodeValueVO> addAreaCodeTerritoryList = geoWsProxy.retrieveChildGeoUnitsByType(
					RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH, 
					RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_TERRITORY,
					phoneAreaCode.getCountryGeoUnitId(), RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL);
			addAreaCodeNumbersModelAndView.addObject("addAreaCodeTerritoryList", addAreaCodeTerritoryList);
		} else {
			phoneAreaCode = new PhoneAreaCode();
		}
		model.addAttribute("phoneAreaCode", phoneAreaCode);
		session.setAttribute("taskId",taskId);
		return addAreaCodeNumbersModelAndView;
	}

	/**
	 * 
	 * The method to save the area code numbers
	 *
	 * @param phoneAreaCode
	 * @param session
	 * @param model
	 * @return RedirectView
	 */
	@RequestMapping(value = "/saveAddAreaCodeNumbers.form", method = RequestMethod.POST)
	public RedirectView saveAddAreaCodeNumbers(@ModelAttribute("phoneAreaCode") PhoneAreaCode phoneAreaCode,
			HttpSession session, Model model) {
		LOGGER.info("entering ControlWordsController | saveAddAreaCodeNumbers");
		
		//audit variables		
		Date startTime = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
		String effvDt =formatter.format(startTime);		
		try {
			phoneAreaCode.setEffvDt(formatter.parse(effvDt));
		} catch (ParseException e) {
			LOGGER.info("Error in Effective Date");			
		}
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		Long phoneAreaCodeId = null;
		/*
		 * The userContextVO can not be null. If null that means the user session has timed out. 
		 */
		if (userContextVO != null) {
			String loggedInUser = userContextVO.getUserIdentifier();

			phoneAreaCodeId = ctrlWrdsProxy.updatePhoneAreaCode(prepareSaveAddAreaCodeNumbers(phoneAreaCode,
					loggedInUser));

			String taskId = (String) session.getAttribute("taskId");
			/*
			 * If taskId already exists then invoke the workFlow resubmit task.
			 * Else invoke create new task with workFlow
			 */
			if ((taskId != null) && !taskId.trim().isEmpty()) {
				homeController.reSubmitTaskRequest(userContextVO, taskId,
						RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						roleMapper.getSubmitterUserGroupId(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS, null));
			} else {
				Long changeTypeCode = null;
				if ((phoneAreaCode.getPhoneAreaCodeId() != null) && (phoneAreaCode.getPhoneAreaCodeId() > 0L)) {
					changeTypeCode = Long.valueOf(RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_PHONE_AREA_CODE_NUMBER);
				} else {
					changeTypeCode = Long.valueOf(RefDataChangeTypeConstants.CHANGE_TYPE_ADD_PHONE_AREA_CODE_NUMBER);
				}

				createCtrlWrdsWorkflowTask(String.valueOf(phoneAreaCodeId), String.valueOf(changeTypeCode),
						userContextVO);
			}
			session.removeAttribute("taskId");
		}
		
		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
				"saveAddAreaCodeNumbers", 0L, phoneAreaCodeId, 0L, phoneAreaCode);
		
		return new RedirectView("submitterWorkQueueHome.form?domainName=Control Words");
	}

	/**
	 * 
	 * The method to prepare the save functionality of add area code numbers
	 *
	 * @param phoneAreaCode
	 * @param loggedInUser
	 * @return phoneAreaCode
	 */
	private PhoneAreaCode prepareSaveAddAreaCodeNumbers(PhoneAreaCode phoneAreaCode, String loggedInUser) {
		if (phoneAreaCode.getPhoneAreaCodeId() == null) {
			phoneAreaCode.setPhoneAreaCodeId(0L);
		}
		if (phoneAreaCode.getCreatedDate() == null) {
			phoneAreaCode.setCreatedDate(new Date());
		}
		if (phoneAreaCode.getCreatedUser() == null) {
			phoneAreaCode.setCreatedUser(loggedInUser);
		}
		phoneAreaCode.setModifiedDate(new Date());
		phoneAreaCode.setModifiedUser(loggedInUser);

		return phoneAreaCode;
	}

	/**
	 * 
	 * The method will redirect to Add Industry Code Inferment home page
	 * 
	 * @param model
	 * @param session
	 * @return ModelAndView
	 */
	@SuppressWarnings({"unchecked", "rawtypes"})
	@RequestMapping(value = "/addIndsCodeInfermentHome.form", method = RequestMethod.GET)
	public ModelAndView addIndustryCodeInfermentHome(Model model, HttpSession session) {
		LOGGER.info("entering ControlWordsController | addIndustryCodeInfermentHome");
		ModelAndView addIndustryCodeInfermentPage = new ModelAndView("addindustryCodeInferment");
		LOGGER.info("exiting ControlWordsController | addIndustryCodeInfermentHome");

		// Retrieving the Lists for language and industry code type
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE);

		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);

		LOGGER.info("tempCodeValueMap is " + tempCodeValueMap);
		List codeValuesLanguage = tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE));

		// sort the codeValues based on the Code Value Id
		Collections.sort(codeValuesLanguage, scotsController.new CodeValueIdComparable());

		List codeValueIndustryCodeType = tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE));

		// sort the codeValues based on the Code Value Id
		Collections.sort(codeValueIndustryCodeType, scotsController.new CodeValueIdComparable());

		// setting countries to model view
		addIndustryCodeInfermentPage.addObject("allCountries", geoWsProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));
		// setting languages
		addIndustryCodeInfermentPage.addObject("languageCodeValues", codeValuesLanguage);
		// setting industry code type
		addIndustryCodeInfermentPage.addObject("codeValueIndustryCodeType", codeValueIndustryCodeType);
		session.setAttribute("codeValueIndustryCodeType", codeValueIndustryCodeType);
		model.addAttribute("infermentText",
				prepareInfermentTextForAdd(session, null, RefDataPropertiesConstants.CODE_INFERMENT_TYPE_INDUSTRYCODE));

		return addIndustryCodeInfermentPage;
	}

	/**
	 * 
	 * The method to populate the infermentText entity for display in UI. The
	 * method will populate the required/mandatory fields for the infermentText.
	 * 
	 * @param session
	 * @return infermentText
	 */
	private InfermentText prepareInfermentTextForAdd(HttpSession session, InfermentText infermentText,
			Long infermentType) {
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		Date currentDate = new Date();

		infermentText = infermentText != null ? infermentText : new InfermentText();
		if (infermentText.getInfermentTextId() == null) {
			infermentText.setInfermentTextId(-1L);
			infermentText.setEffectiveDate(currentDate);
			infermentText.setCreatedDate(currentDate);
			infermentText.setCreatedUser(userContextVO.getUserIdentifier());
		}
		infermentText.setModifiedDate(currentDate);
		infermentText.setModifiedUser(userContextVO.getUserIdentifier());
		if (infermentType == RefDataPropertiesConstants.CODE_INFERMENT_TYPE_LEGAL) {
			prepareLegalFormInfermentForAdd(userContextVO.getUserIdentifier(), currentDate, infermentText);
		}
		if (infermentType == RefDataPropertiesConstants.CODE_INFERMENT_TYPE_INDUSTRYCODE) {
			prepareIndustryCodeInfermentForAdd(userContextVO.getUserIdentifier(), currentDate, infermentText);
		}
		LOGGER.info("exiting prepareInfermentTextForAdd | infermentText " + infermentText);
		return infermentText;
	}

	/**
	 * 
	 * The method to prepare the legal form inferment add functionality
	 *
	 * @param loggedInUser
	 * @param currentDate
	 * @param infermentText
	 */
	private void prepareLegalFormInfermentForAdd(String loggedInUser, Date currentDate, InfermentText infermentText) {

		List<LegalFormInferment> legalFormInferments = infermentText.getLegalFormInferments() != null ? infermentText
				.getLegalFormInferments() : new ArrayList<LegalFormInferment>();

		if (legalFormInferments.size() == 0) {
			LegalFormInferment legalFormInferment = new LegalFormInferment();
			legalFormInferments.add(legalFormInferment);
		}
		int pkIndex = 0;
		for (LegalFormInferment legalFormInferment : legalFormInferments) {
			if ((legalFormInferment.getLegalFormInfermentId() == null)
					|| (legalFormInferment.getLegalFormInfermentId() != null && legalFormInferment
							.getLegalFormInfermentId() <= 0)) {
				legalFormInferment.setLegalFormInfermentId(Long.valueOf(--pkIndex));
				legalFormInferment.setEffectiveDate(currentDate);
				legalFormInferment.setCreatedDate(currentDate);
				legalFormInferment.setCreatedUser(loggedInUser);
			}
			legalFormInferment.setModifiedDate(currentDate);
			legalFormInferment.setModifiedUser(loggedInUser);
		}
		infermentText.setLegalFormInferments(legalFormInferments);
		LOGGER.info("exiting prepareLegalFormInfermentForAdd | infermentText " + infermentText);
	}

	/**
	 * 
	 * The method to prepare the industry code inferment add functionality
	 *
	 * @param loggedInUser
	 * @param currentDate
	 * @param infermentText
	 */
	private void prepareIndustryCodeInfermentForAdd(String loggedInUser, Date currentDate, InfermentText infermentText) {

		List<IndustryCode> industryCodes = infermentText.getIndustryCodeList() != null ? infermentText
				.getIndustryCodeList() : new ArrayList<IndustryCode>();
		if (industryCodes.size() == 0) {
			IndustryCode indsCode = new IndustryCode();
			industryCodes.add(indsCode);
			infermentText.setIndustryCodeList(industryCodes);
		}

		List<IndustryCodeInferment> industryCodeInferments = new ArrayList<IndustryCodeInferment>();

		int pkIndex = 0;
		if (infermentText.getIndustryCodeList() != null) {
			for (IndustryCode industryCode : infermentText.getIndustryCodeList()) {

				IndustryCodeInferment indsCodeInfer = new IndustryCodeInferment();

				if (industryCode.getIndustryCodeTypeCode() != null && industryCode.getIndustryCode() != null) {
					indsCodeInfer.setIndustryCodeInfermentId(Long.valueOf(--pkIndex));
					indsCodeInfer.setIndustryCodeId(indsProxy.retrieveIndustryCodeIdByCodeTypeCode(
							industryCode.getIndustryCodeTypeCode(), industryCode.getIndustryCode()));
					indsCodeInfer.setCreatedDate(currentDate);
					indsCodeInfer.setCreatedUser(loggedInUser);
					indsCodeInfer.setModifiedDate(currentDate);
					indsCodeInfer.setModifiedUser(loggedInUser);

					industryCodeInferments.add(indsCodeInfer);
				}
			}
			infermentText.setIndustryCodeInferment(industryCodeInferments);
		}
		LOGGER.info("exiting prepareLegalFormInfermentForAdd | infermentText " + infermentText);
	}

	/**
	 * 
	 * The method for the inferment text country applicability
	 *
	 * @param infermentText
	 * @param countryList
	 * @param loggedInUser
	 * @param currentDate
	 */
	private void prepareInfermentTextCountryApplicability(InfermentText infermentText, List<String> countryList,
			String loggedInUser, Date currentDate) {
		List<InfermentTextCountryApplicability> countryApplicabilities = new ArrayList<InfermentTextCountryApplicability>();
		for (String countryGeoUnitId : countryList) {
			InfermentTextCountryApplicability country = new InfermentTextCountryApplicability();
			country.setInfermentTextCountryApplicabilityId(-1L);
			country.setIcountryGeoUnitId(Long.valueOf(countryGeoUnitId));
			country.setCreatedDate(currentDate);
			country.setCreatedUser(loggedInUser);
			country.setModifiedDate(currentDate);
			country.setModifiedUser(loggedInUser);
			country.setEffectiveDate(currentDate);
			countryApplicabilities.add(country);
		}
		infermentText.setCountryApplicabilities(countryApplicabilities);
	}
	/**
	 * 
	 * The method to insert the newly added LegalFormInferment to the database.
	 * The method will bind the UI values and construct the infermentText
	 * entity.
	 * 
	 * @param infermentText
	 * @param result
	 * @param session
	 * @param request
	 * @return RedirectView
	 */
	@RequestMapping(value = "/insertLegalFormInferment.form", method = RequestMethod.POST)
	public View insertLegalFormInferment(@ModelAttribute("infermentText") InfermentText infermentText, Model model,
			SessionStatus sessionStatus, HttpSession session, HttpServletRequest request) throws ParseException {
		LOGGER.info("entering ControlWordsController | insertLegalFormInferment " + infermentText);
		//audit variables
		Date startTime = new Date();
		
		Date currentDate = new Date();
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		infermentText.setInfermentTypeCode(RefDataPropertiesConstants.CODE_INFERMENT_TYPE_LEGAL);
		infermentText.setWritingScriptCode(RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
		prepareInfermentTextForAdd(session, infermentText, infermentText.getInfermentTypeCode());
		prepareInfermentTextCountryApplicability(infermentText, infermentText.getCountryList(),
				userContextVO.getUserIdentifier(), currentDate);
		LOGGER.info("exiting ControlWordsController | insertLegalFormInferment " + infermentText);
		Long trackingId = ctrlWrdsProxy.updateInfermentText(infermentText);
		LOGGER.info("inserted inferment text: trackingId " + trackingId);
		createCtrlWrdsWorkflowTask(trackingId.toString(),
				RefDataChangeTypeConstants.CHANGE_TYPE_ADD_LEGAL_FORM_INFERMENT, userContextVO);
		
		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
				"insertLegalFormInferment", 0L, trackingId, 0L, infermentText);
		
		return new RedirectView("submitterWorkQueueHome.form?domainName=Control Words");
	}

	/**
	 * 
	 * The method to insert the newly added LegalFormInferment to the database.
	 * The method will bind the UI values and construct the infermentText
	 * entity.
	 * 
	 * @param infermentText
	 * @param result
	 * @param session
	 * @param request
	 * @return RedirectView
	 */
	@RequestMapping(value = "/insertIndustryCodeInferment.form", method = RequestMethod.POST)
	public View insertIndustryCodeInferment(@ModelAttribute("infermentText") InfermentText infermentText, Model model,
			SessionStatus sessionStatus, HttpSession session, HttpServletRequest request) throws ParseException {
		LOGGER.info("entering ControlWordsController | insertIndustryCodeInferment " + infermentText);
		//audit variables
		Date startTime = new Date();
		
		Date currentDate = new Date();
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		infermentText.setInfermentTypeCode(RefDataPropertiesConstants.CODE_INFERMENT_TYPE_INDUSTRYCODE);
		infermentText.setWritingScriptCode(RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
		prepareInfermentTextForAdd(session, infermentText, infermentText.getInfermentTypeCode());
		prepareInfermentTextCountryApplicability(infermentText, infermentText.getCountryList(),
				userContextVO.getUserIdentifier(), currentDate);
		LOGGER.info("exiting ControlWordsController | insertLegalFormInferment " + infermentText);
		Long domainId = ctrlWrdsProxy.updateInfermentText(infermentText);
		LOGGER.info("inserted inferment text: trackingId " + domainId);
		createCtrlWrdsWorkflowTask(domainId.toString(),
				RefDataChangeTypeConstants.CHANGE_TYPE_ADD_INDUSTRY_CODE_INFERMENT, userContextVO);
		
		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
				"insertLegalFormInferment", 0L, domainId, 0L, infermentText);
		
		return new RedirectView("submitterWorkQueueHome.form?domainName=Control Words");
	}

	/**
	 * 
	 * The method to create new task with work-flow. Control Words domain where we
	 * need the user role identifier while creating a request. This is required
	 * for auto approver functionality.
	 *
	 * @param domainId
	 * @param changeTypeId
	 * @param userContextVO
	 */
	private void createCtrlWrdsWorkflowTask(String domainId, String changeTypeId, UserContextVO userContextVO) {

		homeController.createReferenceData(domainId, RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS, 
				Long.valueOf(changeTypeId), userContextVO.getUserIdentifier(), 
				"Control Words ID: " + domainId,
				RefDataPropertiesConstants.CONTROL_WORDS_APPROVER_GROUP_ID,
				RefDataPropertiesConstants.CONTROL_WORDS_SUBMITTER_GROUP_ID, 
				roleMapper.hasDomainApproverRoleForUser(
						RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS, userContextVO.getUserRoles())
						? RefDataUIConstants.WRKFLW_USER_ROLE_ID_APPROVER
						: RefDataUIConstants.WRKFLW_USER_ROLE_ID_SUBMITTER);
	}
	
	
	
	/**
	 * The method will populate the existing Control Words data from the
	 * Transaction DB. The service method need to retrieve the values from the DB
	 * and populate the UI.
	 * 
	 * @param industryCodeBulkDownloadVO
	 *            model attribute
	 * @return ModelAndView
	 * 
	 */
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/controlWordsBulkDownload.form")
	public ModelAndView controlWordsBulkDownloadForm(Model model,
			HttpSession session) {
		LOGGER.info("entering ControlWordsController | controlWordsBulkDownloadForm");
		ModelAndView controlWordsBulkDownload = new ModelAndView("controlWordsBulkDownload");
		ControlWordsBulkDownloadVO controlWordsBulkDownloadVO = new ControlWordsBulkDownloadVO();
		model.addAttribute("controlWordsBulkDownload",controlWordsBulkDownloadVO);
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
		List codeValuesLanguage = tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE));		
		controlWordsBulkDownload.addObject("allCountries", geoWsProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));
		controlWordsBulkDownload.addObject("languageCodeValues", codeValuesLanguage);
		// sort the codeValues based on the Code Value Id
		Collections.sort(codeValuesLanguage, scotsController.new CodeValueIdComparable());	
		
		LOGGER.info("exiting ControlWordsController | controlWordsBulkDownloadForm");
		return controlWordsBulkDownload;

	}
	
	
	/**
	 * This method receives the values selected by the user in the ControlWords
	 * Bulk Download page
	 * 
	 * @param controlWordsBulkDownloadVO
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/controlWordsMyDownLoad.form", method = RequestMethod.POST)
	public View controlWordsBulkDownload(
			@ModelAttribute("controlWordsBulkDownload") ControlWordsBulkDownloadVO controlWordsBulkDownloadVO,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session) throws ParseException {

		LOGGER.info("entering ControlWordsController | indusCodeBulkdownload");
		Date startTime = new Date();
		UiBulkDownload uiBulkDownload = new UiBulkDownload();
		uiBulkDownload.setDwnloadStartTime(startTime);
		uiBulkDownload.setFileType(controlWordsBulkDownloadVO.getFileType());
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		uiBulkDownload.setUserId(userContextVO.getUserIdentifier());
		uiBulkDownload.setDomainName(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS);
		uiBulkDownload.setBulkDownloadStatus(RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_FILE_STATUS);
		Long uiBlkDwnldTrackingId = indsProxy.addUIBulkDownload(uiBulkDownload);
		controlWordsBulkDownloadVO.setUiBlkDwnldId(uiBlkDwnldTrackingId);
		String fileType = null;
		if (uiBulkDownload.getFileType().equalsIgnoreCase("Inferrment Text")) {
			fileType = "Infrmnt_Txt";
		} else if (uiBulkDownload.getFileType().equalsIgnoreCase("Unusable Glossary")) {
			fileType = "Unus_Glsy";
		} else if (uiBulkDownload.getFileType().equalsIgnoreCase("Telecommunication")) {
			fileType = "Telecom";
		} 
		String ctrlWrdsDownLoadFileName = refdataConfig
				.getValue(RefDataPropertiesConstants.REFDATA_CTRLWRDS_BLK_DOWNLOAD_LOCATION)
				+ fileType
				+ RefDataPropertiesConstants.UNDERSOCRE
				+ uiBlkDwnldTrackingId
				+ RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_FILE_FORMAT;
		controlWordsBulkDownloadVO.setCtrlWrdsDownLoadFileName(ctrlWrdsDownLoadFileName);
		ctrlWrdsProxy.ctrlWrdsBulkDownload(controlWordsBulkDownloadVO);
		
		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
				"controlWordsBulkDownload", 0L, ctrlWrdsDownLoadFileName, 0L, controlWordsBulkDownloadVO);
		return new RedirectView("workQueueDownload.form");
	}
	
	/**
	 * 
	 * The method for the control words bulk upload form
	 *
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/ctrlWrdsBulkUpload.form")
	public ModelAndView controlWordsBulkUploadForm(Model model,HttpSession session) {
		LOGGER.info("entering ControlWordsController | controlWordsBulkUpload");
		ModelAndView controlWordsBulkUpload = new ModelAndView("controlWordsBulkUpload");
		ControlWordsUploadVO controlWordsUploadVO = new ControlWordsUploadVO();
		model.addAttribute("CtrlWrdsBulkUpload",controlWordsUploadVO);		
		LOGGER.info("exiting ControlWordsController | controlWordsBulkUpload");
		return controlWordsBulkUpload;
	}
	
	
	/**
	 * 
	 * 
	 * @param indusCodeBulkUploadVO
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/ctrlWrdsBulkUploader.form", method = RequestMethod.POST)
	public View controlWordsBulkUpload(
			@ModelAttribute("CtrlWrdsBulkUpload") ControlWordsUploadVO controlWordsUploadVO,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session) throws ParseException {
		LOGGER.info("entering ControlWordsController | indusCodeUpload");
		Date startTime = new Date();
		
		String fileName = refdataConfig
				.getValue(RefDataPropertiesConstants.REFDATA_CTRLWRDS_BLK_UPLOAD_LOCATION)
				+ controlWordsUploadVO.getFile().getOriginalFilename();
		File f = new File(fileName);
		LOGGER.info("ControlWordsController | indusCodeUpload | File Name"+fileName);
		MultipartFile multipartFile = controlWordsUploadVO.getFile();

		try {
			multipartFile.transferTo(f);
		} catch (IllegalStateException e) {
			LOGGER.error("Error in ControlWords Upload",e);
		} catch (IOException e) {
			LOGGER.error("Error in ControlWords Upload",e);
		} catch(Exception e){
			LOGGER.error("Error in ControlWords Upload",e);
		}

		if (result.hasErrors()) {
			for (ObjectError error : result.getAllErrors()) {
				LOGGER.error("Error: " + error.getCode() + " - "
						+ error.getDefaultMessage());
			}
		}

		createNewCtrlWrdsBulkUploadWorkflowTask(
				controlWordsUploadVO,
				RefDataChangeTypeConstants.CHANGE_TYPE_BULK_UPLOAD_CTRLWRDS,
				(UserContextVO) session
						.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT));

		sessionStatus.setComplete();
		
		// transaction logging 
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);		
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
				"controlWordsBulkUpload", 0L, controlWordsUploadVO, 0L);
		
		LOGGER.info("exiting  ControlWordsController | indusCodeUpload");
		return new RedirectView("submitterWorkQueueHome.form?domainName=Control Words");

	}

	/**
	 * 
	 * The method to create new task with work-flow for Industry bulk upload.
	 * 
	 * @param indusCodeBulkUploadVO
	 * @param requestType
	 * @param userContextVO
	 */
	private void createNewCtrlWrdsBulkUploadWorkflowTask(
			ControlWordsUploadVO controlWordsUploadVO, String requestType,
			UserContextVO userContextVO) {		
		String domainId = null;
		String fileName = controlWordsUploadVO.getFile().getOriginalFilename();
		if (controlWordsUploadVO.getFileType().equalsIgnoreCase(
				"Industry Code Inferment")) {
			domainId = "24761";

		}else if(controlWordsUploadVO.getFileType().equalsIgnoreCase(
		"Area Code Numbers")){
			domainId = "24805";
		}else if(controlWordsUploadVO.getFileType().equalsIgnoreCase(
		"D&B Unusable Phone Area Code Number")){
			domainId = "24801";
		}

		LOGGER.info("params for createNewControlWordsWorkflowTaskForCrcyBulkUpload : "
				+ controlWordsUploadVO
				+ " : "
				+ requestType
				+ " : "
				+ userContextVO
				+ " : "
				+ RefDataPropertiesConstants.CONTROLWORDS_APPROVER_GROUP_ID
				+ " : "
				+ RefDataPropertiesConstants.CONTROLWORDS_SUBMITTER_GROUP_ID);
		

		homeController.createCtrlWrdsBulkUploadReferenceData(domainId,
				RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
				Long.valueOf(requestType), userContextVO.getUserIdentifier(),
				"Industry Code Bulk Upload Reference Data" + 401, fileName,
				RefDataPropertiesConstants.CONTROLWORDS_APPROVER_GROUP_ID,
				RefDataPropertiesConstants.CONTROLWORDS_SUBMITTER_GROUP_ID);
	}
	
	@RequestMapping(value = "lockPhoneAreaCodeForEdit.form", method = RequestMethod.GET)
	public @ResponseBody
	Boolean lockPhoneAreaCodeForEdit(@ModelAttribute("phoneAreaCode") PhoneAreaCode phoneAreaCode) {
		LOGGER.info("entering ControlWordsController | lockPhoneAreaCodeForEdit");
		return this.ctrlWrdsProxy.lockPhoneAreaCodeForEdit(phoneAreaCode.getPhoneAreaCodeId());
	}
	
	/**
	 * 
	 * This method is invoked by datatables plugin through Ajax calls. Response
	 * is provided in JSON format.
	 * 
	 * @param ctrlWrdsSearchCriteria
	 * @param result
	 * @param response
	 * @param session
	 * @return List of ControlWords
	 */
	@RequestMapping(value = "/controlWordsSearchAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getControlWordsSearchAjaxResults(HttpServletRequest request, HttpSession session) {
		LOGGER.info("entering ControlWordsController | getControlWordsSearchAjaxResults");
		ControlWordsSearchVO ctrlWrdsSearchCriteria = getCtrlWrdsAjaxSearchCriteria(request);
		if (ctrlWrdsSearchCriteria.getControlWordsTypeCode()==null) {
			return homeController.getJsonMap(request, new ArrayList<Object>(),
					0L, unUsOffWordsSearchColumns);
		}
		LOGGER.info("entering ControlWordsController | getControlWordsSearchAjaxResults||ctrlWrdsSearchCriteria:"
				+ ctrlWrdsSearchCriteria);
		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		List<DnbUnusGlsy> retrieveControlWordsAjaxSearchResults= ctrlWrdsProxy.retrieveControlWordsAjaxSearchResults(ctrlWrdsSearchCriteria);
		Long ctrlWordsCount = (Long) session.getAttribute("ctrlWordsCount");
		if ((ctrlWordsCount == null) || (ctrlWrdsSearchCriteria.getRowIndex() == 0)) {
			ctrlWordsCount = ctrlWrdsProxy.countSearchControlWords(ctrlWrdsSearchCriteria);
			session.setAttribute("ctrlWordsCount", ctrlWordsCount);
		}
		LOGGER.info("exiting ControlWordsController | getControlWordsSearchAjaxResults");
		if(ctrlWrdsSearchCriteria.getControlWordsTypeCode()==24801L){
			return homeController.getJsonMap(request, retrieveControlWordsAjaxSearchResults, ctrlWordsCount, unUsAreaCodeSearchColumns);
		}else if(ctrlWrdsSearchCriteria.getControlWordsTypeCode()==24802L){
			return homeController.getJsonMap(request, retrieveControlWordsAjaxSearchResults, ctrlWordsCount, unUsAddressSearchColumns);
		}else if(ctrlWrdsSearchCriteria.getControlWordsTypeCode()==24803L){
			return homeController.getJsonMap(request, retrieveControlWordsAjaxSearchResults, ctrlWordsCount, unUsOrgNameSearchColumns);
		}else if(ctrlWrdsSearchCriteria.getControlWordsTypeCode()==24804L){
			return homeController.getJsonMap(request, retrieveControlWordsAjaxSearchResults, ctrlWordsCount, unUsOffWordsSearchColumns);
		}else if(ctrlWrdsSearchCriteria.getControlWordsTypeCode()==24806L){
			return homeController.getJsonMap(request, retrieveControlWordsAjaxSearchResults, ctrlWordsCount, unUsTelNumberSearchColumns);
		}else if(ctrlWrdsSearchCriteria.getControlWordsTypeCode()==24808L){
			return homeController.getJsonMap(request, retrieveControlWordsAjaxSearchResults, ctrlWordsCount, unUsIndNameSearchColumns);
		}else if(ctrlWrdsSearchCriteria.getControlWordsTypeCode()==24799L){
			return homeController.getJsonMap(request, retrieveControlWordsAjaxSearchResults, ctrlWordsCount, noiseWordSearchColumns);
		}else {
			return homeController.getJsonMap(request, new ArrayList<Object>(),
					0L, unUsOffWordsSearchColumns);
		}
	}
	/**
	 * 
	 * The method will construct the CtrlWrdsSearchCriteria
	 * 
	 * @param request
	 * @return ctrlWrdsSearchCriteriaVO
	 */
	private ControlWordsSearchVO getCtrlWrdsAjaxSearchCriteria(HttpServletRequest request) {
		ControlWordsSearchVO ctrlWrdsSearchCriteriaVO = new ControlWordsSearchVO();
		ctrlWrdsSearchCriteriaVO.setSortOrder(homeController.getSortOrder(request));
		ctrlWrdsSearchCriteriaVO.setSortBy(homeController.getSortBy(request, unUsOffWordsSearchColumns));
		ctrlWrdsSearchCriteriaVO.setMaxResults(homeController.getMaxResults(request));
		ctrlWrdsSearchCriteriaVO.setRowIndex(homeController.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);
		// Search string will be in the format
		// typ_cd#~search_txt#~Country#~Active#~Inactive
		String searchCriteriaDelimiter = "~";
		if (compositeSearchString != null) {
			String[] splitCriteria = compositeSearchString.split(searchCriteriaDelimiter);
			if (splitCriteria.length > 0) {
				if (!(splitCriteria[0].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO.setControlWordsTypeCode(Long.valueOf(splitCriteria[0].replace("#", "").trim()));
				}
			}
			if (splitCriteria.length > 1) {
				if (!(splitCriteria[1].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO
							.setSearchText(splitCriteria[1].replace("#", "").trim());
				}
			}
			
			if (splitCriteria.length > 2) {
				if (!(splitCriteria[2].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO.setCountryGeoUnitId(Long.valueOf((splitCriteria[2].replace("#", "").trim())));
				}
			}
			if (splitCriteria.length > 3) {
				if (!(splitCriteria[3].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO.setIsActive(Boolean.valueOf(splitCriteria[3].replace("#", "").trim()));
				}
			}
			if (splitCriteria.length > 4) {
				if (!(splitCriteria[4].replace("#", "").trim().isEmpty())) {
					ctrlWrdsSearchCriteriaVO.setIsInactive(Boolean.valueOf(splitCriteria[4].replace("#", "").trim()));
				}
			}
		}
		return ctrlWrdsSearchCriteriaVO;
	}

}
