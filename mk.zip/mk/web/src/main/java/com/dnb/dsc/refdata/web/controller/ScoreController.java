package com.dnb.dsc.refdata.web.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.Score;
import com.dnb.dsc.refdata.core.entity.ScoreGranularity;
import com.dnb.dsc.refdata.core.vo.AddNewScoreVO;

import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.EditScoreSearchVO;
import com.dnb.dsc.refdata.core.vo.GranularityDetailVO;
import com.dnb.dsc.refdata.core.vo.GranularityMapDetails;
import com.dnb.dsc.refdata.core.vo.GranularityValueVO;
import com.dnb.dsc.refdata.core.vo.ScoreDtlVO;
import com.dnb.dsc.refdata.core.vo.ScoreOverrideMapVO;
import com.dnb.dsc.refdata.core.vo.ScoreSearchVO;
import com.dnb.dsc.refdata.core.vo.ScoreVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;
import com.dnb.dsc.refdata.web.proxy.ScoreWebServiceProxy;
import com.dnb.dsc.refdata.web.util.ScoreSearchExportToExcel;

@Controller
public class ScoreController {

	@Autowired
	private HomeController homeController;

	@Autowired
	private GeographyWebServiceProxy geoWsProxy;

	@Autowired
	private ScoreWebServiceProxy scoreProxy;

	/*
	 * @Autowired private ScoreController scoreController;
	 */

	/**
	 * The constant for the searchSERScoreColumns - Search Code Value page
	 */
	
	private final String[] scoreSearchColumns = { "scr_id", "scoreTypeCode",
			"scr_typ_cd_val_d", "scr_vers", "scr_mkt_cd_id", "country_name",
			"scoreGranularity", "scr_gru_cd_val_d" };
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ScoreController.class);

	/**
	 * Loads the Scores search home page.
	 * <p>
	 * 
	 * Retrieves all Scores information to be populated in the screen.
	 * <p>
	 * 
	 * @param model
	 * @param session
	 * @return scoreSearchHome, the ModelAndView object
	 */

	@RequestMapping(value = "/scoreSearchHome.form", method = RequestMethod.GET)
	public ModelAndView ScoringSearchHome(Model model, HttpSession session) {
		LOGGER.info("entering ScoringController | ScoringSearchHome");
		ModelAndView scoreSearchHome = new ModelAndView("scoreSearch");

		ScoreSearchVO scoreSearchVO = new ScoreSearchVO();

		ScoreVO scoreVO = new ScoreVO();
		List<CodeValue> scoreTypeValueMap = scoreProxy
				.retrieveScoreTypeCodeValues(scoreVO);

		List<CodeValue> granularityTypeValueMap = scoreProxy
				.retrieveGruTypeCodeValues(scoreVO);

		scoreSearchHome.addObject("scoreTypCode", scoreTypeValueMap);
		scoreSearchHome.addObject("granularTypCode", granularityTypeValueMap);
		scoreSearchHome.addObject(
				RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION,
				getCountryList());

		model.addAttribute("scoreSearch", scoreSearchVO);

		return scoreSearchHome;
	}

	

	@RequestMapping(value = "/scoreSearchSubmit.form", method = RequestMethod.POST)
	public void getScoreSearchExportToExcelResults(
			@ModelAttribute("scoreSearch") ScoreSearchVO scoreSearchVO,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) {
		LOGGER.info("entering ScoreController | getScoreSearchExportToExcelResults");

		ScoreSearchVO searchCriteriaVO = scoreSearchVO;
		ScoreSearchExportToExcel scoreSearchExportToExcel = null;
		scoreSearchExportToExcel = new ScoreSearchExportToExcel("");
		try {
			scoreSearchExportToExcel.insertScoreSearchData(scoreProxy
					.SearchScores(searchCriteriaVO));
		} catch (Exception e1) {
			LOGGER.error("problem in getScoreSearchExportToExcelResults List |"
					+ e1.getMessage());
		}
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();
		String dateAppend = new SimpleDateFormat("MMddyyyyHHmmss")
				.format(new Date());
		response.setContentType("application/xlsx");
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ "Ent_Ref_data_SearchResultScore_" + loggedInUser + ""
				+ dateAppend + ".xlsx" + "\"");
		try {
			scoreSearchExportToExcel.write(response.getOutputStream());
		} catch (IOException e) {
			LOGGER.error("problem in ScoreController |" + e.getMessage());
		}

	}

	
	@RequestMapping(value = "/exportToExcelWithGran.form", method = RequestMethod.GET)
	public @ResponseBody
	void exportToExcelWithGran(
			@RequestParam(value = "scrTypCdList", required = true) String scoreTypeCode,
			@RequestParam(value = "marketCodeList", required = true) String scoreMktCode,
			@RequestParam(value = "scrGruCdList", required = true) String scoreGraCode,
			@RequestParam(value = "exportIndc", required = true) String exportIndc,
			HttpSession session, HttpServletResponse response) {

		LOGGER.info("entering ScoreController | getScoreSearchExportToExcelResults");
		ScoreSearchVO scoreSearchVO = new ScoreSearchVO();
		scoreSearchVO.setSr_typ_cd(scoreTypeCode);
		scoreSearchVO.setSr_gru_cd(scoreGraCode);
		scoreSearchVO.setMkt_cd(scoreMktCode);
		scoreSearchVO.setExportIndc(exportIndc);
		ScoreSearchVO searchCriteriaVO = scoreSearchVO;
		ScoreSearchExportToExcel scoreSearchExportToExcel = null;
		scoreSearchExportToExcel = new ScoreSearchExportToExcel("");
		try {
			scoreSearchExportToExcel.insertScoreSearchData(scoreProxy
					.SearchScores(searchCriteriaVO));
		} catch (Exception e1) {
			LOGGER.error("problem in getScoreSearchExportToExcelResults List |"
					+ e1.getMessage());
		}
		response.setContentType("application/xlsx");
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ "SearchResult.xlsx" + "\"");
		try {
			scoreSearchExportToExcel.write(response.getOutputStream());
		} catch (IOException e) {
			LOGGER.error("problem in ScoreController |" + e.getMessage());
		}

	}

	
	@RequestMapping(value = "/exportToExcel.form", method = RequestMethod.GET)
	public @ResponseBody
	Boolean exportToExcel(
			@RequestParam(value = "scrTypCdList", required = true) String scoreTypeCode,
			@RequestParam(value = "marketCodeList", required = true) String scoreMktCode,
			@RequestParam(value = "exportIndc", required = true) String exportIndc,
			HttpSession session, HttpServletRequest request,
			HttpServletResponse response) {

		LOGGER.info("entering ScoreController | getScoreSearchExportToExcelResults");
		ScoreSearchVO scoreSearchVO = new ScoreSearchVO();
		scoreSearchVO.setSr_typ_cd(scoreTypeCode);
		scoreSearchVO.setMkt_cd(scoreMktCode);
		scoreSearchVO.setExportIndc(exportIndc);
		/*
		 * ScoreSearchVO searchCriteriaVO = scoreSearchVO;
		 * ScoreSearchExportToExcel scoreSearchExportToExcel = null;
		 * scoreSearchExportToExcel = new ScoreSearchExportToExcel(""); try {
		 * scoreSearchExportToExcel
		 * .insertScoreSearchData(scoreProxy.SearchScores(searchCriteriaVO)); }
		 * catch (Exception e1) {
		 * LOGGER.error("problem in getScoreSearchExportToExcelResults List |" +
		 * e1.getMessage()); } response.setContentType("application/xlsx");
		 * response.setHeader("Content-Disposition", "attachment; filename=\"" +
		 * "SearchResult.xlsx" + "\""); try {
		 * scoreSearchExportToExcel.write(response.getOutputStream());
		 * response.getOutputStream().flush();
		 * response.getOutputStream().close();
		 * 
		 * } catch (IOException e) { LOGGER.error("problem in ScoreController |"
		 * + e.getMessage()); }
		 */
		getScoreSearchExportToExcelResults(scoreSearchVO, request, session,
				response);

		return true;

	}

	@RequestMapping(value = "/scoreSearchAjaxResult.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getScoreSearchAjaxResult(HttpServletRequest request,
			HttpSession session) throws Exception {
		LOGGER.info("entering ScoringController | getScoreSearchAjaxResult");

		String searchString = homeController.getSearchString(request);

		if (searchString == null || searchString.trim().isEmpty()) {
			return homeController.getJsonMap(request,
					new ArrayList<ScoreSearchVO>(), 0L, scoreSearchColumns);
		}
		ScoreSearchVO searchCriteriaVO = getScoreSearchCrteria(request);

		Long countScoreResults = (Long) session
				.getAttribute("countScotsCodeValueResults");
		if (countScoreResults == null || searchCriteriaVO.getRowIndex() == 0) {
			countScoreResults = scoreProxy.countOfscoreSearch(searchCriteriaVO);
			session.setAttribute("countScotsCodeValueResults",
					countScoreResults);
		}
		LOGGER.info("exiting ScoringController | getScoreSearchAjaxResult");

		return homeController.getJsonMap(request,
				scoreProxy.SearchScores(searchCriteriaVO), countScoreResults,
				scoreSearchColumns);
	}

	private List<CodeValueVO> getCountryList() {
		return this.geoWsProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
	}

		

	private static void copy(String[] source, List<Long> target, int index) {
		if (index == source.length)
			return;
		target.add(Long.parseLong(source[index]));
		copy(source, target, index + 1);
	}

	private ScoreSearchVO getScoreSearchCrteria(HttpServletRequest request) {
		ScoreSearchVO searchCriteriaVO = new ScoreSearchVO();
		searchCriteriaVO.setSortOrder(homeController.getSortOrder(request));
		searchCriteriaVO.setSortBy(homeController.getSortBy(request,
				scoreSearchColumns));
		searchCriteriaVO.setMaxResults(homeController.getMaxResults(request));
		searchCriteriaVO.setRowIndex(homeController.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);
		// Search string will be in the format
		// CodeDesc#~radioBtnName#~LangCode
		String searchCriteriaDelimiter = "#~";
		if (compositeSearchString != null) {
			String[] splitCriteria = compositeSearchString
					.split(searchCriteriaDelimiter);
			if (splitCriteria.length >= 3) {
				String arr[] = splitCriteria[0].split(",");
				List<Long> mktCodeList = new ArrayList<Long>();
				copy(arr, mktCodeList, 0);
				searchCriteriaVO.setMarketCodeList(mktCodeList);
				searchCriteriaVO.setMkt_cd(splitCriteria[0]);
				// searchCriteriaVO.setScoreTypeCode(Long.valueOf(splitCriteria[1]));
				searchCriteriaVO.setSr_typ_cd(splitCriteria[1]);
				searchCriteriaVO.setSr_gru_cd(splitCriteria[2]);
				// searchCriteriaVO.setScoreGranularity(Long.valueOf(splitCriteria[2]));

			} else {
				String arr[] = splitCriteria[0].split(",");
				List<Long> mktCodeList = new ArrayList<Long>();
				copy(arr, mktCodeList, 0);
				searchCriteriaVO.setMarketCodeList(mktCodeList);
				searchCriteriaVO.setMkt_cd(splitCriteria[0]);
				searchCriteriaVO.setSr_typ_cd(splitCriteria[1]);
				// searchCriteriaVO.setScoreTypeCode(Long.valueOf(splitCriteria[1]));
			}
			/*
			 * if ("codeValue".equals(splitCriteria[1])) {
			 * searchCriteriaVO.setMarketCodeList(splitCriteria[0]);
			 * 
			 * } else if ("codeValueDesc".equals(splitCriteria[1])) {
			 * searchCriteriaVO.setCodeValueDescription(splitCriteria[0]
			 * .trim());
			 * 
			 * } else { searchCriteriaVO
			 * .setCodeValueBusinessDescription(splitCriteria[0] .trim()); }
			 */

		}

		LOGGER.info("exiting ScotsController | getSearchCodeValueFilterCriteria "
				+ "| searchCriteriaVO : " + searchCriteriaVO);
		return searchCriteriaVO;

	}

	@RequestMapping(value = "/scoreEditAjaxResults.form")
	public @ResponseBody
	Boolean getScoreEditAjaxResults(HttpServletRequest request,
			HttpSession session) {

		int id = Integer.parseInt(request.getParameter("id"));
		int columnId = Integer.parseInt(request.getParameter("columnId"));
		int columnPosition = Integer.parseInt(request
				.getParameter("columnPosition"));
		int rowId = Integer.parseInt(request.getParameter("rowId"));
		String value = request.getParameter("value");
		String columnName = request.getParameter("columnName");
		System.out.println("id::" + id + "\ncolumnId::" + columnId
				+ "\ncolumnPosition::" + columnPosition + "\nrowId::" + rowId
				+ "\nvalue::" + value + "\ncolumnName::" + columnName);
		return true;

	}

	/**
	 * Loads the Scores search home page.
	 * <p>
	 * 
	 * Retrieves all Scores information to be populated in the screen.
	 * <p>
	 * 
	 * @param model
	 * @param session
	 * @return scoreSearchHome, the ModelAndView object
	 */

	@RequestMapping(value = "/scoreReportsHome.form", method = RequestMethod.GET)
	public ModelAndView ScoringReportsHome(HttpSession session) {
		LOGGER.info("entering ScoringController | getIndustryCodesSearchHome");
		ModelAndView scoreReportsHome = new ModelAndView("scoreReports");

		List<Integer> codeTableIds = new ArrayList<Integer>();

		codeTableIds.add(185);
		codeTableIds.add(477);
		codeTableIds.add(351);

		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);

		scoreReportsHome.addObject(
				RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION,
				getCountryList());
		scoreReportsHome.addObject("granularity",
				tempCodeValueMap.get(String.valueOf(185)));
		scoreReportsHome.addObject("product",
				tempCodeValueMap.get(String.valueOf(351)));

		return scoreReportsHome;
	}

	@RequestMapping(value = "/scoreProdMappingHome.form", method = RequestMethod.GET)
	public ModelAndView ScoreProdMappingHome(HttpSession session) {
		LOGGER.info("entering ScoringController | getIndustryCodesSearchHome");
		ModelAndView scoreSearchHome = new ModelAndView("scoreProductMapping");

		List<Integer> codeTableIds = new ArrayList<Integer>();

		// codeTableIds.add(185);
		codeTableIds.add(477);
		codeTableIds.add(351);

		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValues(codeTableIds);

		// scoreSearchHome.addObject("granularity",
		// tempCodeValueMap.get(String.valueOf(185)));
		scoreSearchHome.addObject("scoreversion",
				tempCodeValueMap.get(String.valueOf(477)));
		scoreSearchHome.addObject("product",
				tempCodeValueMap.get(String.valueOf(351)));
		scoreSearchHome.addObject("productversion",
				tempCodeValueMap.get(String.valueOf(477)));

		return scoreSearchHome;
	}
	
	
	@RequestMapping(value = "/scoreGranMappingHome.form", method = RequestMethod.GET)
	public ModelAndView ScoreGranMappingHome(Model model, HttpSession session,Boolean success) {
		LOGGER.info("entering ScoreController | ScoreGranMappingHome");
		ModelAndView scoreGranMappingHome = new ModelAndView("mappingScoreGran");

		List<Integer> codeTableIds = new ArrayList<Integer>();

		codeTableIds.add(713);
		codeTableIds.add(714);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValuesScr(codeTableIds);

		scoreGranMappingHome.addObject("scoreTypeCode",
				tempCodeValueMap.get(String.valueOf(713)));
		scoreGranMappingHome.addObject("granularityCode",
				tempCodeValueMap.get(String.valueOf(714)));
		scoreGranMappingHome.addObject("success",success);

		GranularityValueVO granularityValueVO = new GranularityValueVO();
		model.addAttribute("scoreGranularity",
				populateEmptyGranularity(granularityValueVO));

		return scoreGranMappingHome;
	}

	@RequestMapping(value = "/scoreGranMapping.form", method = RequestMethod.POST)
	public ModelAndView ScoreGranMapping(
			@ModelAttribute("scoreGranularity") GranularityValueVO granularityValueVO,
			Model model, HttpSession session,Boolean success) {
		LOGGER.info("entering ScoreController | ScoreGranMappingHome");

		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();

		populateScoreGranCodeMandatoryFields(granularityValueVO, loggedInUser);

		session.removeAttribute("tempCodeValueMap");
		Long updatedScoreTypeCode = scoreProxy
				.updateGranularityCode(granularityValueVO);

		LOGGER.info("ScoreController | scoreGranMappingHome | updating ScoreTypeCode : "
				+ updatedScoreTypeCode);

		LOGGER.info("exiting ScoreController | ScoreGranMappingHome");
		success = true;

		return ScoreGranMappingHome(model, session,success);
	}

	private void populateScoreGranCodeMandatoryFields(
			GranularityValueVO granularityValueVO, String loggedInUser) {
		LOGGER.info("entering ScoreController | populateScoreGranCodeMandatoryFields");
		granularityValueVO.setCreatedDate(new Date());
		granularityValueVO.setCreatedUser(loggedInUser);
		granularityValueVO.setModifiedDate(new Date());
		granularityValueVO.setModifiedUser(loggedInUser);

		if (granularityValueVO.getGranularityDetailVO() != null) {
			for (GranularityDetailVO granularityDetailVO : granularityValueVO
					.getGranularityDetailVO()) {
				granularityDetailVO.setCreatedDate(new Date());
				granularityDetailVO.setCreatedUser(loggedInUser);
				granularityDetailVO.setModifiedDate(new Date());
				granularityDetailVO.setModifiedUser(loggedInUser);
			}
		}

		LOGGER.info("exiting ScoreController | populateScoreGranCodeMandatoryFields");
	}

	public GranularityValueVO populateEmptyGranularity(
			GranularityValueVO scoreDtl) {
		LOGGER.info("entering ScoreController | populateEmptyGranularity");
		if (isEmptyGranularityList(scoreDtl)) {
			GranularityDetailVO emptyScoreGranularity = new GranularityDetailVO();
			List<GranularityDetailVO> emptyScoreGranularityList = new ArrayList<GranularityDetailVO>();
			emptyScoreGranularityList.add(emptyScoreGranularity);
			scoreDtl.setGranularityDetailVO(emptyScoreGranularityList);
		}
		LOGGER.info("exiting ScoreController | populateEmptyGranularity");
		return scoreDtl;
	}

	public boolean isEmptyGranularityList(GranularityValueVO scoreDtl) {
		if (scoreDtl.getGranularityDetailVO() == null
				|| (scoreDtl.getGranularityDetailVO() != null && scoreDtl
						.getGranularityDetailVO().isEmpty())) {
			return true;
		} else {
			return false;
		}
	}

	@RequestMapping(value = "/addNewScoreHome.form", method = RequestMethod.GET)
	public ModelAndView AddNewScoreHome(Model model, HttpSession session,Boolean success) {
		LOGGER.info("entering ScoreController | AddNewScoreHome");
		ModelAndView addScoresHome = new ModelAndView("addingNewScore");
		
		List<Integer> codeTableIds = new ArrayList<Integer>();
		
		addScoresHome.addObject(
				RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION,
				getCountryList());

		codeTableIds.add(713);

		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValuesScr(codeTableIds);

		addScoresHome.addObject("scoreTypeCode",
				tempCodeValueMap.get(String.valueOf(713)));
		
		addScoresHome.addObject("success",success);

		AddNewScoreVO addNewScoreVO = new AddNewScoreVO();
		model.addAttribute("addScores", addNewScoreVO);

		LOGGER.info("exiting ScoreController | AddNewScoreHome");

		return addScoresHome;
	}

	@RequestMapping(value = "/newScoreMapping.form", method = RequestMethod.POST)
	public ModelAndView NewScoreMapping(
			@ModelAttribute("addScores") AddNewScoreVO addNewScoreVO,
			Model model, HttpSession session,Boolean success) {
		LOGGER.info("entering ScoreController | newScoreMapping");

		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();

		populateNewScoreMandatoryFields(addNewScoreVO, loggedInUser);

		session.removeAttribute("tempCodeValueMap");
		Long updatedNewScoreCode = scoreProxy.updateNewScoreCode(addNewScoreVO);
		
		

		LOGGER.info("ScoreController | newScoreMapping | updating NewScoreTypeCode : "
				+ updatedNewScoreCode);

		LOGGER.info("exiting ScoreController | newScoreMapping");
		success = true;
		
		return AddNewScoreHome(model,session,success); 
	}

	private void populateNewScoreMandatoryFields(AddNewScoreVO addNewScoreVO,
			String loggedInUser) {
		LOGGER.info("entering ScoreController | populateNewScoreMandatoryFields");
		addNewScoreVO.setCreatedDate(new Date());
		addNewScoreVO.setCreatedUser(loggedInUser);
		addNewScoreVO.setModifiedDate(new Date());
		addNewScoreVO.setModifiedUser(loggedInUser);
		LOGGER.info("exiting ScoreController | populateNewScoreMandatoryFields");

	}

	@RequestMapping(value = "/addScoreMappingHome.form", method = RequestMethod.GET)
	public ModelAndView AddScoreMappingHome(Model model, HttpSession session,Boolean successGranValMap) {
		LOGGER.info("entering ScoreController | AddScoreMappingHome");
		ModelAndView addScoreMappingHome = new ModelAndView(
				"addingNewScoreMapping");

		addScoreMappingHome.addObject("scoreTypeCode", getScoreTypeCodeList());
		addScoreMappingHome.addObject("successGranValMap",successGranValMap);

		AddNewScoreVO addNewScoreVO = new AddNewScoreVO();
		model.addAttribute("scoreMapping", addNewScoreVO);

		return addScoreMappingHome;
	}

	@RequestMapping(value = "/scoreMappingHome.form", method = RequestMethod.POST)
	public ModelAndView ScoreMappingHome(
			@ModelAttribute("scoreMapping") AddNewScoreVO addNewScoreVO,
			Model model, HttpSession session,Boolean successGranValMap) {
		LOGGER.info("entering ScoreController | ScoreMappingHome");

		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();

		populateNewScoreMandatoryFields(addNewScoreVO, loggedInUser);

		session.removeAttribute("tempCodeValueMap");
		Long updatedNewScoreCode = scoreProxy
				.updateNewScoreMapping(addNewScoreVO);

		LOGGER.info("ScoreController | ScoreMappingHome | updating NewScoreTypeCode : "
				+ updatedNewScoreCode);

		LOGGER.info("exiting ScoreController | ScoreMappingHome");
		successGranValMap = true;
		return AddScoreMappingHome(model, session,successGranValMap);
	}

	@RequestMapping(value = "retrieveMarketTypeCodes.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveMarketTypeCodes(
			@RequestParam(value = "scoreType", required = true) Long scoreType,

			HttpSession session) {
		LOGGER.info("entering ScoreController | retrieveMarketTypeCodes");
		// audit variables

		List<CodeValueVO> CodeValueVOs = this.scoreProxy
				.retrieveMarketTypeCodes(scoreType);

		LOGGER.info("exiting ScoreController | retrieveMarketTypeCodes");
		return CodeValueVOs;
	}

	// ////// Score Search Changes- starts
	@RequestMapping(value = "retrieveScrSerachScoreTypeCode.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveScrSearchScoreTypeCode(
			@RequestParam(value = "marketCode", required = true) List<Long> marketCode,

			HttpSession session) {

		LOGGER.info("entering ScoreController | retrieveScrSearchScoreTypeCode");

		ScoreVO scoreVo = new ScoreVO();

		Iterator<Long> mrktCodeIterator = marketCode.iterator();
		while (mrktCodeIterator.hasNext()) {
			scoreVo.setScoreMarketCode(mrktCodeIterator.next());
		}

		List<CodeValue> ScoreTypeCodes = this.scoreProxy
				.retrieveScrSearchScoreTypeCode(scoreVo);

		LOGGER.info("exiting ScoreController | retrieveScrSearchScoreTypeCode");

		return ScoreTypeCodes;
	}

	@RequestMapping(value = "retrieveScrSearchGranularity.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveScrSearchGranularity(

			@RequestParam(value = "scoreTypeCode", required = true) List<Long> scoreTypeCode,
			@RequestParam(value = "marketCode", required = true) List<Long> marketCode,
			HttpSession session) {

		LOGGER.info("entering ScoreController | retrieveScrSearchGranularity");

		ScoreVO scoreVo = new ScoreVO();

		Iterator<Long> mrktCodeIterator = marketCode.iterator();
		while (mrktCodeIterator.hasNext()) {
			scoreVo.setScoreMarketCode(mrktCodeIterator.next());
		}

		Iterator<Long> scoreTypIterator = scoreTypeCode.iterator();
		while (scoreTypIterator.hasNext()) {
			scoreVo.setScoreId(scoreTypIterator.next());
			scoreVo.setScoreTypeId(scoreTypIterator.next());
		}

		List<CodeValue> GranularityCodes = this.scoreProxy
				.retrieveScrSearchGranularity(scoreVo);

		LOGGER.info("exiting ScoreController | retrieveScrSearchGranularity");

		return GranularityCodes;

	}

	// ///// Score Search Changes- ends

	@RequestMapping(value = "retrievescoreVersions.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrievescoreVersions(
			@RequestParam(value = "scoreType", required = true) Long scoreType,
			@RequestParam(value = "marketType", required = true) Long marketType,
			HttpSession session) {
		LOGGER.info("entering ScoreController | retrievescoreVersions");
		// audit variables

		List<CodeValueVO> Scores = this.scoreProxy.retrievescoreVersions(
				scoreType, marketType);

		LOGGER.info("exiting ScoreController | retrievescoreVersions");
		return Scores;
	}

	@RequestMapping(value = "retrieveAttributeDetails.form", method = RequestMethod.GET)
	public @ResponseBody
	List<AddNewScoreVO> retrieveAttributeDetails(
			@RequestParam(value = "scoreType", required = true) Long scoreType,
			@RequestParam(value = "marketType", required = true) Long marketType,
			@RequestParam(value = "scoreVersion", required = true) Double scoreVersion,
			HttpSession session) {
		LOGGER.info("entering ScoreController | retrieveAttributeDetails");
		// audit variables
		List<AddNewScoreVO> addNewScoreVOs = this.scoreProxy
				.retrieveAttributeDetails(scoreType, marketType, scoreVersion);

		LOGGER.info("exiting ScoreController | retrieveAttributeDetails");
		return addNewScoreVOs;
	}

	private List<CodeValueVO> getScoreTypeCodeList() {
		return this.scoreProxy.retrieveAllScoreTypeCode();

	}

	@RequestMapping(value = "/addScoreOverrideMappingHome.form", method = RequestMethod.GET)
	public ModelAndView AddScoreOverrideMappingHome(Model model,
			HttpSession session) {
		LOGGER.info("entering ScoreController | AddScoreMappingHome");
		ModelAndView addScoreOverrideMappingHome = new ModelAndView(
				"addingScoreOverrideMapping");

		addScoreOverrideMappingHome.addObject("scoreTypeCode",
				getScoreTypeCodeList());

		ScoreOverrideMapVO scoreOverrideMapVO = new ScoreOverrideMapVO();
		model.addAttribute("scoreMapping", scoreOverrideMapVO);

		return addScoreOverrideMappingHome;
	}

	@RequestMapping(value = "/scoreDetailsMap.form")
	public ModelAndView scoreOverrideLabelMap(Model model,Boolean success) {
		ModelAndView scoreGranularityView = new ModelAndView("scoreDetailsMap");
		ScoreVO scoreVO = new ScoreVO();
		List<CodeValue> tempCodeValueMap = scoreProxy
				.retrieveScoreTypeCodeValues(scoreVO);
		
		ScoreDtlVO scoreDtl = new ScoreDtlVO();
		scoreGranularityView.addObject("scoreTyp", tempCodeValueMap);
		scoreGranularityView.addObject("success",success);
		model.addAttribute("score",
				populateEmptyDescriptionMappingRows(scoreDtl));

		return scoreGranularityView;
	}

	public ScoreDtlVO populateEmptyDescriptionMappingRows(ScoreDtlVO scoreDtl) {
		if (isEmptyGranularityList(scoreDtl)) {
			ScoreGranularity emptyScoreGranularity = new ScoreGranularity();
			List<ScoreGranularity> emptyScoreGranularityList = new ArrayList<ScoreGranularity>();
			emptyScoreGranularityList.add(emptyScoreGranularity);
			scoreDtl.setScoreGranularity(emptyScoreGranularityList);
		}
		return scoreDtl;
	}

	public boolean isEmptyGranularityList(ScoreDtlVO scoreDtl) {
		if (scoreDtl.getScoreGranularity() == null
				|| (scoreDtl.getScoreGranularity() != null && scoreDtl
						.getScoreGranularity().isEmpty())) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * private List<CodeValueVO> getScoreType() { return
	 * this.scoreProxy.retrieveAllScoreType(); }
	 */

	@RequestMapping(value = "retrieveMarketCodesForScrType.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveMarketCodesForScrType(
			@RequestParam(value = "scoreType", required = true) Long scoreTypeCode,
			HttpSession session) {
		LOGGER.info("entering ScoreController | retrieveMarketCodesForScrType");
		LOGGER.info("ScoreController | retrieveMarketCodesForScrType | "
				+ "scoreTypeCode : " + scoreTypeCode);
		ScoreVO scoreVO = new ScoreVO();
		scoreVO.setScoreId(scoreTypeCode);
		List<CodeValueVO> getCountryList = scoreProxy
				.retrieveMarketCodeValues(scoreVO);

		return getCountryList;
	}

	@RequestMapping(value = "retrieveVersionForScrMktAndType.form", method = RequestMethod.GET)
	public @ResponseBody
	List<Score> retrieveVersionForScrMktAndType(
			@RequestParam(value = "scoreMkt", required = true) Long scoreMkt,
			@RequestParam(value = "scoreType", required = true) Long scoreType,
			HttpSession session) {
		LOGGER.info("entering ScoreController | retrieveMarketCodesForScrType");
		LOGGER.info("ScoreController | retrieveMarketCodesForScrType | "
				+ "scoreType : " + scoreType + " scoreMkt : " + scoreMkt);
		/*
		 * ScoreVO scoreVO = new ScoreVO();
		 * scoreVO.setScoreMarketCode(scoreMkt); scoreVO.setScoreId(scoreType);
		 */

		Score scoreVO = new Score();
		scoreVO.setScoreMarketCode(scoreMkt);
		scoreVO.setScoreTypeId(scoreType);

		List<Score> scoreVersion = scoreProxy
				.retrieveVersionForScrMktAndType(scoreVO);

		return scoreVersion;
	}

	@RequestMapping(value = "retrieveGranularityForScrType.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveGranularityForScrType(
			@RequestParam(value = "scoreMkt", required = true) Long scoreMkt,
			@RequestParam(value = "scoreType", required = true) Long scoreType,
			@RequestParam(value = "scoreVer", required = true) Double scoreVersion,
			HttpSession session) {
		LOGGER.info("entering ScoreController | retrieveGranularityForScrType");
		LOGGER.info("ScoreController | retrieveGranularityForScrType | "
				+ "scoreType : " + scoreType + " scoreMkt : " + scoreMkt
				+ " scoreVer : " + scoreVersion);
		ScoreVO scoreVO = new ScoreVO();
		scoreVO.setScoreMarketCode(scoreMkt);
		scoreVO.setScoreId(scoreType);
		scoreVO.setScoreTypeId(scoreType);
		List<CodeValue> scoregranularity = scoreProxy
				.retrieveGranularityForScrType(scoreVO);
		return scoregranularity;
	}

	@RequestMapping(value = "/scoreDtlSubmitToDB.form", method = RequestMethod.POST)
	public ModelAndView scoreDtlAddToDB(
			@ModelAttribute("score") ScoreDtlVO scoreDtlVO,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session,Boolean success) throws ParseException {
		LOGGER.info("entering ScoreController | scoreDtlAddToDB | ScoreDtlVO: "
				+ scoreDtlVO);
		

		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();
		scoreDtlVO.setLoggedInUser(loggedInUser);
		LOGGER.info("ScoreController | scoreDtlAddToDB | updating ScoreDtl as: "
				+ scoreDtlVO);
		Long trackingId = scoreProxy.updateScoreDtl(scoreDtlVO);
		LOGGER.info("ScoreController | scoreDtlAddToDB | ScoreDtlVO:"+trackingId);
		success = true;

		return scoreOverrideLabelMap(model,success);
	}

	
	@RequestMapping(value = "/editScoreSearch.form", method = RequestMethod.GET)
	public ModelAndView editScoreSearch(
			@RequestParam("scrID") final Long scrID,
			@RequestParam("scrTypCd") final Long scrTypCd, Model model,
			HttpSession session) {
		LOGGER.info("entering ScoreController | editScoreSearch");
		ModelAndView editScoreSearch = new ModelAndView("scoreSearchView");
		System.out.println("scrID : " + scrID);
		ScoreSearchVO scoreSearchVO = scoreProxy.editScoreSearch(scrID,
				scrTypCd);
		ScoreVO scoreVO = new ScoreVO();
		scoreVO.setScoreId(scrTypCd);
		List<CodeValueVO> getCountryList = scoreProxy
				.retrieveMarketCodeValues(scoreVO);
		editScoreSearch.addObject(
				RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION,
				getCountryList);
		editScoreSearch.addObject("scrSearchVO", scoreSearchVO);
		Map<String, List<GranularityMapDetails>> mapValues = new HashMap<String, List<GranularityMapDetails>>();
		List<String> distGranularityLable = new ArrayList<String>();

		if (scoreSearchVO.getEditScoreSearchList().size() > 0) {
			List<EditScoreSearchVO> editScoreSearchList = scoreSearchVO
					.getEditScoreSearchList();
			EditScoreSearchVO editVO = editScoreSearchList.get(0);
			scoreSearchVO.setScrVersion(editVO.getScr_ver());
			List<EditScoreSearchVO> editScoreSearchLit = new ArrayList<EditScoreSearchVO>();
			scoreSearchVO.setEditScoreSearchLit(editScoreSearchLit);
			model.addAttribute("version", editVO.getScr_ver());
			model.addAttribute("scrID", editVO.getScr_id());
			model.addAttribute("mktCd", editVO.getScr_mkt_cd());
			List<String> granularityLable = new ArrayList<String>();
			for (EditScoreSearchVO editVOs : editScoreSearchList) {
				granularityLable.add(editVOs.getScrGranularityLable());
			}
			HashSet<String> removeduplicates = new HashSet<String>(
					granularityLable);
			distGranularityLable = new ArrayList<String>(removeduplicates);

			EditScoreSearchVO values = new EditScoreSearchVO();
			List<GranularityMapDetails> granularityMapDetails = new ArrayList<GranularityMapDetails>();
			/*
			 * List<String> values = new ArrayList<String>(); Map<String,
			 * List<String>> mapValues = new HashMap<String, List<String>>();
			 * 
			 * for(String granulartyLable : distGranularityLable){ values = new
			 * ArrayList<String>(); for(EditScoreSearchVO editVOs :
			 * editScoreSearchList){
			 * if(editVOs.getScrGranularityLable().equalsIgnoreCase
			 * (granulartyLable)) { values.add(editVOs.getScr_attr_val());
			 * mapValues.put(editVOs.getScr_map_id()+granulartyLable, values); }
			 * } }
			 */

			for (String granulartyLable : distGranularityLable) {
				values = new EditScoreSearchVO();
				granularityMapDetails = new ArrayList<GranularityMapDetails>();
				for (EditScoreSearchVO editVOs : editScoreSearchList) {
					if (editVOs.getScrGranularityLable().equalsIgnoreCase(
							granulartyLable)) {
						GranularityMapDetails graMapDetails = new GranularityMapDetails();
						graMapDetails.setPrnt_scr_id(editVOs.getPrnt_scr_id());
						graMapDetails
								.setScr_attr_val(editVOs.getScr_attr_val());
						graMapDetails.setScr_map_id(editVOs.getScr_map_id());
						granularityMapDetails.add(graMapDetails);
						values.setGranularityMapDetailList(granularityMapDetails);
						mapValues.put(granulartyLable, granularityMapDetails);
					}
				}
			}
			editScoreSearch.addObject("mapValues", mapValues);
			editScoreSearch.addObject("distGranularityLable",
					distGranularityLable);
		}

		model.addAttribute("version", scoreSearchVO.getScrVersion());
		model.addAttribute("scrID", scoreSearchVO.getScr_id());
		model.addAttribute("mktCd", scoreSearchVO.getScr_mkt_cd_id());
		editScoreSearch.addObject("mapValues", mapValues);
		editScoreSearch.addObject("distGranularityLable", distGranularityLable);
		model.addAttribute("scoreSearchVO", scoreSearchVO);
		editScoreSearch.addObject("scrTypCode", "[" + scrTypCd + "]"
				+ scoreSearchVO.getScr_typ_cd_val_d());

		return editScoreSearch;
	}

	@RequestMapping(value = "/scoreSubmitToDB.form", method = RequestMethod.POST)
	public ModelAndView scoreSubmitToDB(
			@ModelAttribute("scoreSearchVO") ScoreSearchVO scoreSearchVO,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session) throws ParseException {
		LOGGER.info("entering ScoreController | scoreDtlAddToDB | ScoreDtlVO: "
				+ scoreSearchVO);
		

		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();
		scoreSearchVO.setLoggedInUser(loggedInUser);
		LOGGER.info("ScoreController | scoreDtlAddToDB | updating ScoreDtl as: "
				+ scoreSearchVO);

		List<EditScoreSearchVO> editScoreSearchVO = scoreSearchVO
				.getEditScoreSearchLit();
		List<EditScoreSearchVO> newEditScoreList = new ArrayList<EditScoreSearchVO>();
		try {
			if (editScoreSearchVO.size() > 0) {
				for (EditScoreSearchVO edit : editScoreSearchVO) {
					String vals_Scr_attr_val = null;
					String valArr_Scr_attr_val[] = null;
					String vals_Scr_map_id_val = null;
					String valArr_Scr_map_id_val[] = null;
					String vals_Prnt_scr_id_val = null;
					String valArr_Prnt_scr_id_val[] = null;

					try {
						vals_Scr_attr_val = edit.getScr_attr_val();
						valArr_Scr_attr_val = vals_Scr_attr_val.split(",");
					} catch (Exception e) {

					}
					try {
						vals_Scr_map_id_val = edit.getScr_map_id_val();
						valArr_Scr_map_id_val = vals_Scr_map_id_val.split(",");
					} catch (Exception e) {

					}
					try {
						vals_Prnt_scr_id_val = edit.getPrnt_scr_id_val();
						valArr_Prnt_scr_id_val = vals_Prnt_scr_id_val
								.split(",");
					} catch (Exception e) {

					}
					if (valArr_Prnt_scr_id_val.length > 0) {
						for (int i = 0; i < valArr_Prnt_scr_id_val.length; i++) {

							EditScoreSearchVO edtScoreSearchVO = new EditScoreSearchVO();
							edtScoreSearchVO.setPrnt_scr_id(Long
									.valueOf(valArr_Prnt_scr_id_val[i]));
							edtScoreSearchVO
									.setScr_attr_val(valArr_Scr_attr_val[i]);
							edtScoreSearchVO.setScr_map_id(Long
									.valueOf(valArr_Scr_map_id_val[i]));
							newEditScoreList.add(edtScoreSearchVO);
						}
					}
				}
			}
		} catch (Exception e) {

		}
		scoreSearchVO.setEditScoreSearchLit(newEditScoreList);
		Long trackingId = scoreProxy.updateScoreMapDtl(scoreSearchVO);
		LOGGER.info("entering ScoreController | scoreDtlAddToDB | ScoreDtlVO: "
				+ trackingId);
		return ScoringSearchHome(model, session);
	}
	
	/**
	 * 
	 * The method will validate the Score Type-Market-Version for possible duplicate
	 *(If the same values are already present). 
	 * 
	 * @param codeTable
	 * @return boolean
	 */
	@RequestMapping(value = "/checkForDuplicate.form", method = RequestMethod.GET)
	public @ResponseBody
	Boolean checkForDuplicate(@RequestParam(value = "scoreTypeCode") Long scoreTypeCode,
            @RequestParam(value = "scoreMarketCode") Long scoreMarketCode,
            @RequestParam(value = "scoreVersion") Double scoreVersion,
            HttpSession session) {
			LOGGER.info("entering  ScoreController | checkForDuplicate | " + scoreTypeCode +"scoreMarketCode"+scoreMarketCode+"scoreVersion"+scoreVersion);				
			Boolean isDuplicate = scoreProxy.checkForDuplicate(scoreTypeCode,scoreMarketCode,scoreVersion);
			LOGGER.info("entering  ScoreController | checkForDuplicate | isDuplicate" +isDuplicate);			
		return isDuplicate;
	}

	
	
	
	
}