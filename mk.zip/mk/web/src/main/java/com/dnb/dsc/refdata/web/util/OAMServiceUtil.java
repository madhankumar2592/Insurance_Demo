/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.util;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.core.vo.UserRoleVO;
/**
 * The utility class for the work-flow web service integration.
 * 
 * @author Cognizant
 * @version last updated : Mar 8, 2012
 * @see
 * 
 */
@Component
public class OAMServiceUtil {
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(OAMServiceUtil.class);

	/**
	 * 
	 * The method to populate the userContext for the logged in reference data
	 * user. The details will be fetched from the request header as the OAM team
	 * will be populating the user details in the header.The UserContextVO will
	 * be populated and will be returned.
	 * 
	 * @param request
	 * @return userContext
	 */
	public UserContextVO getUserContext(HttpServletRequest request) {
		LOGGER.info("entering OAMServiceUtil | getUserContext");
		UserContextVO userContext = new UserContextVO();
		
		Enumeration<?> enumeration = request.getHeaderNames();
		while (enumeration.hasMoreElements()) {
			String name = (String) enumeration.nextElement();
			String value = request.getHeader(name);			
			LOGGER.info("OAMServiceUtil | getUserContext | " + name + " : " + value);
			/*
			 * Iterate through the header enumerations to retrieve each keys and
			 * assign it to the respective setter methods of the userContextVO.
			 * 
			 * The unique identifier for an user (email identifier)
			 */
			if(RefDataUIConstants.ONELOGIN_HEADER_HTTP_OBLIX_UID.equals(name)) {
				userContext.setUserIdentifier(value);
			} 
			/*
			 * The dnb user first name and the last name. 
			 */
			else if(RefDataUIConstants.ONELOGIN_HEADER_DNB_FIRST_NAME.equals(name)) {
				userContext.setUserFirstName(value);
			} else if(RefDataUIConstants.ONELOGIN_HEADER_DNB_LAST_NAME.equals(name)) {
				userContext.setUserLastName(value);
			} 
			/*
			 * The user's default country code. The format will be US~1073  
			 */
			else if(RefDataUIConstants.ONELOGIN_HEADER_DNB_COUNTRY.equals(name)) {
				if(value != null && value.length() > 0) {
					userContext.setUserCountryCode(value);					
				}
			} 
			/*
			 * Retrieve the user roles for the user.
			 */
			else if(RefDataUIConstants.ONELOGIN_HEADER_DNB_USER_ROLE.equals(name)) {
				userContext.setUserRoles(getUserRoles(value));
			}
		}
		
		LOGGER.info("UserContextVO : " + userContext);
		LOGGER.info("exiting OAMServiceUtil | getUserContext");
		return userContext;
	}

	/**
	 * 
	 * The method to retrieve the user role details from the OAM header. The
	 * method will accept the OAM header role value as input argument and will
	 * return the List<UserRolveVO> as output. As user who has multiple roles
	 * will have multiple occurrences of [applicationid@role~roelcode@Group]
	 * with appropriate values.
	 * 
	 * @param roleHeaderValue
	 * @return userRoles
	 */
	public List<UserRoleVO> getUserRoles(String roleHeaderValue) {
		LOGGER.info("roleHeaderValue : " + roleHeaderValue);
		List<UserRoleVO> userRoles = null;
		/**
		 * A user who has access to Ref Data , will have CAMS-HTTP-DNB-USERROLE like
		 * Currency_Approver:FT_Approver:SCoTS_Approver
		 * 
		 */
		if(roleHeaderValue != null && roleHeaderValue.length() > 0) {
			userRoles = new ArrayList<UserRoleVO>();
			
			for (String appRoleArray : roleHeaderValue
					.split(RefDataUIConstants.ONELOGIN_HEADER_APPLICATION_SEPARATOR)) {
				LOGGER.info("appRoleArray : " + appRoleArray);		
				UserRoleVO roleVO = new UserRoleVO();
					roleVO.setRoleCode(appRoleArray);
					roleVO.setRoleDescription(appRoleArray);
					roleVO.setUserGroup(appRoleArray);
					userRoles.add(roleVO);
			}
		}
		return userRoles;
	}

	/**
	 * 
	 * The method to populate the userContextVO. The context details will be
	 * hard-coded and only used while OAM application cannot be accessed from the
	 * refData application.
	 * 
	 * @return userContextVO
	 */
    public UserContextVO populateUserContextWithTestData(){
    	UserContextVO userContext = new UserContextVO();
    	userContext.setUserCountryCode("US");
    	userContext.setUserCountryGeoUnitId(952L);
    	userContext.setUserFirstName("Madhan");
    	userContext.setUserLastName("Kumar");
    	userContext.setUserIdentifier(RefDataPropertiesConstants.APPROVER_EMAIL_ADDRESS);
    	List<UserRoleVO> userRoles = new ArrayList<UserRoleVO>();
    	
        	
    	UserRoleVO userRole2 = new UserRoleVO();
    	userRole2.setRoleCode("Geo_Approver");
    	userRole2.setRoleDescription("Geo_Approver");
    	userRole2.setUserGroup("Geography");
    	userRoles.add(userRole2);
    	
    	UserRoleVO userRole3 = new UserRoleVO();
    	userRole3.setRoleCode("NCurrency_Basic");
    	userRole3.setRoleDescription("Currency_Basic");
    	userRole3.setUserGroup("Currency Exchange");
    	userRoles.add(userRole3);
        	
    	UserRoleVO userRole32 = new UserRoleVO();
    	userRole32.setRoleCode("Currency_Approver");
    	userRole32.setRoleDescription("Currency_Approver");
    	userRole32.setUserGroup("Currency Exchange");
    	userRoles.add(userRole32);  	
    	    	
    	UserRoleVO userRole7 = new UserRoleVO();
    	userRole7.setRoleCode("Industry_Basic");
    	userRole7.setRoleDescription("Industry_Basic");
    	userRole7.setUserGroup("Industry Code");
    	userRoles.add(userRole7);
    	
    	UserRoleVO userRole8 = new UserRoleVO();
    	userRole8.setRoleCode("Industry_Approver");
    	userRole8.setRoleDescription("Industry_Approver");
    	userRole8.setUserGroup("Industry Code");
    	userRoles.add(userRole8);
    	
    	UserRoleVO userRole9 = new UserRoleVO();
    	userRole9.setRoleCode("SCoTS_Approver");
    	userRole9.setRoleDescription("SCoTS_Approver");
    	userRole9.setUserGroup("SCoTS");
    	userRoles.add(userRole9);
    	
    	UserRoleVO userRole10 = new UserRoleVO();
    	userRole10.setRoleCode("SCoTS_Basic");
    	userRole10.setRoleDescription("SCoTS_Basic");
    	userRole10.setUserGroup("SCoTS");
    	userRoles.add(userRole10);
    	
    	UserRoleVO userRole11 = new UserRoleVO();
    	userRole11.setRoleCode("GL_Basic");
    	userRole11.setRoleDescription("GL_Basic");
    	userRole11.setUserGroup("XML Schema Labels");
    	userRoles.add(userRole11);
    	
    	UserRoleVO userRole12 = new UserRoleVO();
    	userRole12.setRoleCode("GL_Approver");
    	userRole12.setRoleDescription("GL_Approver");
    	userRole12.setUserGroup("XML Schema Labels");
    	userRoles.add(userRole12);
    	
    	UserRoleVO userRole13 = new UserRoleVO();
    	userRole13.setRoleCode("CW_Approver");
    	userRole13.setRoleDescription("CW_Approver");
    	userRole13.setUserGroup("Control Words");
    	userRoles.add(userRole13);
    	
    	UserRoleVO userRole14 = new UserRoleVO();
    	userRole14.setRoleCode("CW_Basic");
    	userRole14.setRoleDescription("CW_Basic");
    	userRole14.setUserGroup("Control Words");
    	userRoles.add(userRole14);
        	
    	UserRoleVO userRole17 = new UserRoleVO();
    	userRole17.setRoleCode("FT_Approver");
    	userRole17.setRoleDescription("FT_Approver");
    	userRole17.setUserGroup("Financial Templates");
    	userRoles.add(userRole17);
    	
    	userContext.setUserRoles(userRoles);
    	return userContext;
    }
}
