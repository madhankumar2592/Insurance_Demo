/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.entity.FinancialStatementSchedule;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplate;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateLineItem;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.IndustryCodeInferment;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeDescription;
import com.dnb.dsc.refdata.core.entity.IndustryCodeMap;
import com.dnb.dsc.refdata.core.interceptor.TransactionLogger;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.FinancialStatementVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.core.vo.UserRoleVO;
import com.dnb.dsc.refdata.core.vo.WorkQueueHistoryVO;
import com.dnb.dsc.refdata.core.vo.WorkQueueVO;
import com.dnb.dsc.refdata.web.proxy.ControlWordsProxy;
import com.dnb.dsc.refdata.web.proxy.CurrencyExchangeWebServiceProxy;
import com.dnb.dsc.refdata.web.proxy.FinancialTemplateWebServiceProxy;
import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;
import com.dnb.dsc.refdata.web.proxy.SCoTSWebServiceProxy;
import com.dnb.dsc.refdata.web.proxy.XmlSchemaLabelProxy;
import com.dnb.dsc.refdata.web.util.OESServiceUtil;
import com.dnb.dsc.refdata.web.util.UserRoleMapper;
import com.dnb.dsc.refdata.web.proxy.IndustryCodesWebServiceProxy;
import com.dnb.dsc.refdata.web.util.WorkFlowWebServiceUtil;
import com.dnb.dsc_wrkflow_rsp.DSCWRKFLWWSRSPTYP;
import com.dnb.wrkflwcommon.GRPDTLTYP;
import com.dnb.wrkflwcommon.GRPMEMDTLTYP;
import com.dnb.wrkflwcommon.TSKLSTDATATYP;
import com.dnb.wrkflwcommon.TSKLSTDTLTYP;
import com.dnb.wrkflwcommon.TSKLSTHISTDTLTYP;
import com.dnb.wrkflwcommon.TSKLSTHISTTYP;

import java.io.IOException;

/**
 * The Controller class is for WorkQueue. The methods in the class will be
 * mapped as per the UI requests. The UI front controller will redirect to the
 * respective methods based on the request and the request parameters.
 * 
 * @author Cognizant
 * @version last updated : Feb 15, 2012
 * @see
 * 
 */
@SuppressWarnings("unused")
@Controller
@SessionAttributes("crcyExchange")
public class WorkQueueController {

	@Autowired
	private HomeController homeController;

	@Autowired
	private GeographyController geoController;

	@Autowired
	private IndustryCodesController indsCodesController;

	@Autowired
	private SCoTSController scotsController;

	@Autowired
	private ControlWordsController controlWordsController;

	@Autowired
	private GeographyWebServiceProxy wsProxy;

	@Autowired
	private IndustryCodesWebServiceProxy indsCodeWsProxy;

	@Autowired
	private CurrencyExchangeWebServiceProxy crcyWsProxy;

	@Autowired
	private SCoTSWebServiceProxy scotsWsProxy;

	@Autowired
	private XmlSchemaLabelProxy xmlProxy;

	@Autowired
	private ControlWordsProxy cwProxy;

	@Autowired
	private WorkFlowWebServiceUtil webServiceUtil;

	@Autowired
	private RefDataConfigUtil configUtil;

	@Autowired
	private UserRoleMapper roleMapper;

	@Autowired
	private RefDataConfigUtil refdataConfig;

	@Autowired
	private SCoTSController sCoTSController;

	@Autowired
	private FinancialTemplateController financialTemplateController;

	@Autowired
	private FinancialTemplateWebServiceProxy ftProxy;

	@Autowired
	private TransactionLogger transactionLogger;

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(WorkQueueController.class);

	/**
	 * 
	 * The method will serve the home page of workQueue for the approver. The
	 * method will retrieve all unassigned group tasks and the tasks assigned to
	 * the user.
	 * 
	 * @param model
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "/approverWorkQueueHome.form", method = RequestMethod.GET)
	public ModelAndView geApproverWorkQueueHome(
			@RequestParam("domainName") final String domainName,
			HttpSession session) throws ParseException {
		LOGGER.info("entering WorkQueueController | geApproverWorkQueueHome");
		ModelAndView approverWorkQueueModelAndView = new ModelAndView(
				"approverWorkQueue");
		approverWorkQueueModelAndView.addObject("domainList",
				getApproverDomainList(session));
		if (domainName != null && !domainName.trim().isEmpty()) {
			DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST taskList = getApproverTasks(
					domainName, session);
			Map<String, List<WorkQueueVO>> queueMap = mapTaskArrayToVOList(
					taskList,
					RefDataUIConstants.WRKFLW_USER_ROLE_ID_APPROVER.intValue(),
					getGroupId(domainName, false), false);
			if (queueMap != null) {
				approverWorkQueueModelAndView.addObject("availableQueueList",
						queueMap.get("Available"));
				approverWorkQueueModelAndView.addObject("assignedQueueList",
						queueMap.get("Assigned"));
			}
			approverWorkQueueModelAndView.addObject("approverList",
					getApproverList(taskList));
		}
		approverWorkQueueModelAndView.addObject("domainName", domainName);
		LOGGER.info("exiting WorkQueueController | geApproverWorkQueueHome");
		return approverWorkQueueModelAndView;
	}

	/**
	 * 
	 * The method to get the list of approvers
	 * 
	 * @param taskList
	 * @return
	 */
	private List<String> getApproverList(
			DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST taskList) {
		LOGGER.info("entering WorkQueueController | geApproverWorkQueueHome");
		Set<String> approverUserNames = new HashSet<String>();
		if (taskList != null && taskList.getGRPAPPRLST() != null
				&& taskList.getGRPAPPRLST().getGRPAPPRLSTDATA() != null) {
			for (GRPDTLTYP groupDetail : taskList.getGRPAPPRLST()
					.getGRPAPPRLSTDATA().getGRPDTL()) {
				if (groupDetail != null && groupDetail.getGRPMEMDTL() != null) {
					for (GRPMEMDTLTYP groupMember : groupDetail.getGRPMEMDTL()) {
						if (groupMember != null) {
							approverUserNames.add(groupMember.getUSRNME());
						}
					}
				}
			}
		}
		LOGGER.info("exiting WorkQueueController | getApproverList | approverUserNames : "
				+ approverUserNames);
		return new ArrayList<String>(approverUserNames);
	}

	/**
	 * 
	 * The method is to display the submitter's workQueue details
	 * 
	 * @param domainName
	 * @param session
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "/submitterWorkQueueHome.form", method = RequestMethod.GET)
	public ModelAndView getSubmitterWorkQueueHome(
			@RequestParam("domainName") final String domainName,
			HttpSession session) throws ParseException {
		LOGGER.info("entering WorkQueueController | getSubmitterWorkQueueHome");
		ModelAndView submitterWorkQueueHomeModelAndView = new ModelAndView(
				"submitterWorkQueueHome");
		submitterWorkQueueHomeModelAndView.addObject("domainList",
				getSubmitterDomainList(session));
		if (domainName != null && !domainName.trim().isEmpty()) {
			Map<String, List<WorkQueueVO>> queueMap = mapTaskArrayToVOList(
					getSubmitterTasks(domainName, session),
					RefDataUIConstants.WRKFLW_USER_ROLE_ID_SUBMITTER.intValue(),
					getGroupId(domainName, true), true);
			if (queueMap != null) {
				submitterWorkQueueHomeModelAndView.addObject(
						"submitterQueueList", queueMap.get("Submitter"));
			}
		}
		submitterWorkQueueHomeModelAndView.addObject("domainName", domainName);
		LOGGER.info("exiting WorkQueueController | getSubmitterWorkQueueHome");
		return submitterWorkQueueHomeModelAndView;
	}

	/**
	 * 
	 * The method will return the domains identified as part of the reference
	 * data project for the submitter queue. The return type will be a map.
	 * 
	 * @return map of domain list
	 */
	@SuppressWarnings("unchecked")
	private Map<String, String> getSubmitterDomainList(HttpSession session) {
		LOGGER.info("entering WorkQueueController | getSubmitterDomainList");
		OESServiceUtil oesServiceUtil = (OESServiceUtil) session
				.getAttribute("oesUtil");
		List<String> ls = (List<String>) session
				.getAttribute("accessibleResourceName");

		LOGGER.info("Checking the access for each domain");
		boolean industryCodeQueueAllowed = oesServiceUtil != null ? oesServiceUtil
				.getUIComponentAccess(ls, "INDUSTRYCODES/WORK_QUEUE") : true;

				boolean geographyQueueAllowed = oesServiceUtil != null ? oesServiceUtil
						.getUIComponentAccess(ls, "GEOGRAPHY/WORK_QUEUE") : true;
						boolean currencyQueueAllowed = oesServiceUtil != null ? oesServiceUtil
								.getUIComponentAccess(ls, "CURRENCY/WORK_QUEUE") : true;
								boolean scotsQueueAllowed = oesServiceUtil != null ? oesServiceUtil
										.getUIComponentAccess(ls, "SCOTS/WORK_QUEUE") : true;
										boolean finTempQueueAllowed = oesServiceUtil != null ? oesServiceUtil
												.getUIComponentAccess(ls, "FINTEMP/WORK_QUEUE") : true;
												boolean controlWordsQueueAllowed = oesServiceUtil != null ? oesServiceUtil
														.getUIComponentAccess(ls, "CTRLWORDS/WORK_QUEUE") : true;
														boolean gsrLiteralsQueueAllowed = oesServiceUtil != null ? oesServiceUtil
																.getUIComponentAccess(ls, "GSRLLITERALS/WORK_QUEUE") : true;

																Map<String, String> domainList = new LinkedHashMap<String, String>();
																if (controlWordsQueueAllowed) {
																	domainList.put(
																			RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
																			RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS);
																}

																if (currencyQueueAllowed) {
																	domainList.put(
																			RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
																			RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE);
																}
																if (finTempQueueAllowed) {
																	domainList.put(
																			RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
																			RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES);
																}
																if (geographyQueueAllowed) {
																	domainList.put(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
																			RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY);
																}

																if (industryCodeQueueAllowed) {
																	domainList.put(
																			RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
																			RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE);
																}

																if (scotsQueueAllowed) {
																	domainList.put(RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
																			RefDataPropertiesConstants.DOMAIN_CODE_SCOTS);
																}

																if (gsrLiteralsQueueAllowed) {
																	domainList.put(
																			RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS,
																			RefDataPropertiesConstants.DOMAIN_CODE_GSRL_METADATA);
																}

																LOGGER.info("exiting WorkQueueController | getSubmitterDomainList | domainList : "
																		+ domainList);
																return domainList;
	}

	/**
	 * 
	 * The method will return the domains identified as part of the reference
	 * data project for the approver queue. The return type will be a map.
	 * 
	 * @return map of domain list
	 */
	@SuppressWarnings("unchecked")
	private Map<String, String> getApproverDomainList(HttpSession session) {
		LOGGER.info("entering WorkQueueController | getApproverDomainList");
		OESServiceUtil oesServiceUtil = (OESServiceUtil) session
				.getAttribute("oesUtil");
		List<String> ls = (List<String>) session
				.getAttribute("accessibleResourceName");

		LOGGER.info("Checking the access for each domain");
		boolean industryCodeApproveAllowed = oesServiceUtil != null ? oesServiceUtil
				.getUIComponentAccess(ls, "INDUSTRYCODES/APPROVER_QUEUE")
				: true;

				boolean geographyApproveAllowed = oesServiceUtil != null ? oesServiceUtil
						.getUIComponentAccess(ls, "GEOGRAPHY/APPROVER_QUEUE") : true;

						boolean currencyApproveAllowed = oesServiceUtil != null ? oesServiceUtil
								.getUIComponentAccess(ls, "CURRENCY/APPROVER_QUEUE") : true;

								boolean scotsApproveAllowed = oesServiceUtil != null ? oesServiceUtil
										.getUIComponentAccess(ls, "SCOTS/APPROVER_QUEUE") : true;

										boolean finTempApproveAllowed = oesServiceUtil != null ? oesServiceUtil
												.getUIComponentAccess(ls, "FINTEMP/APPROVER_QUEUE") : true;

												boolean controlWordsApproveAllowed = oesServiceUtil != null ? oesServiceUtil
														.getUIComponentAccess(ls, "CTRLWORDS/APPROVER_QUEUE") : true;

														boolean gsrlLiteralsApproveAllowed = oesServiceUtil != null ? oesServiceUtil
																.getUIComponentAccess(ls, "GSRLLITERALS/APPROVER_QUEUE") : true;

																Map<String, String> domainList = new LinkedHashMap<String, String>();
																if (controlWordsApproveAllowed) {
																	domainList.put(
																			RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS,
																			RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS);
																}
																if (currencyApproveAllowed) {
																	domainList.put(
																			RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
																			RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE);
																}

																if (finTempApproveAllowed) {
																	domainList.put(
																			RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
																			RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES);
																}

																if (geographyApproveAllowed) {
																	domainList.put(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
																			RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY);
																}

																if (industryCodeApproveAllowed) {
																	domainList.put(
																			RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
																			RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE);
																}

																if (scotsApproveAllowed) {
																	domainList.put(RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
																			RefDataPropertiesConstants.DOMAIN_CODE_SCOTS);
																}

																if (gsrlLiteralsApproveAllowed) {
																	domainList.put(
																			RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS,
																			RefDataPropertiesConstants.DOMAIN_CODE_GSRL_METADATA);
																}

																LOGGER.info("exiting WorkQueueController | getApproverDomainList | returned : "
																		+ domainList);
																return domainList;
	}

	/**
	 * 
	 * The method to map the task lists retrieved from the workFlow to the
	 * WorkQueueVO
	 * 
	 * @param taskList
	 * @param userRoleId
	 * @param userGroupId
	 * @param isSubmitterQueue
	 * @return
	 * @throws ParseException
	 */
	private Map<String, List<WorkQueueVO>> mapTaskArrayToVOList(
			DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST taskList,
			int userRoleId, int userGroupId, boolean isSubmitterQueue)
					throws ParseException {
		LOGGER.info("entering WorkQueueController | mapTaskArrayToVOList | taskList : "
				+ taskList);
		LOGGER.info("WorkQueueController | mapTaskArrayToVOList | userRoleId : "
				+ userRoleId
				+ " | userGroupId : "
				+ userGroupId
				+ " | isSubmitterQueue : " + isSubmitterQueue);
		if (taskList == null) {
			return null;
		}
		TSKLSTDATATYP taskListDataType = taskList.getTSKLSTDATA();
		if (taskListDataType == null) {
			return null;
		}
		List<TSKLSTDTLTYP> taskArray = taskListDataType.getTSKLSTDTL();

		List<WorkQueueVO> availableQueueList = new LinkedList<WorkQueueVO>();
		List<WorkQueueVO> assignedQueueList = new LinkedList<WorkQueueVO>();
		List<WorkQueueVO> submitterQueueList = new LinkedList<WorkQueueVO>();
		Map<String, List<WorkQueueVO>> queueMap = new HashMap<String, List<WorkQueueVO>>();

		WorkQueueVO currWQVO = null;
		if (taskArray == null) {
			return null;
		}

		for (TSKLSTDTLTYP currentTask : taskArray) {
			if ("Waiting For Approval".equalsIgnoreCase(currentTask
					.getREQSSTAT())) {
				currentTask.setREQSSTAT("Submitted For Approval");
			}
			if (currentTask != null && currentTask.getDOMNID() != null) {
				currWQVO = new WorkQueueVO(
						currentTask.getTRKGID(),
						currentTask.getDOMNID(),
						currentTask.getTSKID(),
						currentTask.getTSKSTAT(),
						currentTask.getAPRVID(),
						isSubmitterQueue ? RefDataPropertiesConstants.SUBMITTER_EMAIL_ADDRESS
								: currentTask.getSUBMTRID(),
								currentTask.getDOMNNME(),
								currentTask.getCHGTYP(),
								currentTask.getNOTES(),
								changeDateFormat(currentTask.getREQSSBMTDT(),
										"MM/dd/yyyy", "yyyy-MM-dd"),
								currentTask.getREQSSTAT(),
								currentTask.getREJREAS(),
								currentTask.getREJREAS() != null ? changeDateFormat(
										currentTask.getREQSRVWDT(), "MM/dd/yyyy",
										"yyyy-MM-dd") : null,
										userRoleId,
										userGroupId,
										configUtil
										.getValue(RefDataPropertiesConstants.REFDATA_REQUEST_CHANGE_TYPE_CD
												+ currentTask.getCHGTYP()));
				currWQVO.setFileName(currentTask.getFLENME());
				currWQVO.setRequestServicedDate(currentTask.getREQSRVWDT());
				if (isSubmitterQueue) {
					submitterQueueList.add(currWQVO);
				} else {
					if (currentTask.getTSKSTAT() != null
							&& currentTask.getTSKSTAT().trim()
							.equalsIgnoreCase("Available")) {
						availableQueueList.add(currWQVO);
					} else if (currentTask.getTSKSTAT() != null
							&& currentTask.getTSKSTAT().trim()
							.equalsIgnoreCase("Assigned")) {
						assignedQueueList.add(currWQVO);
					}
				}
			}
		}

		if (isSubmitterQueue) {
			queueMap.put("Submitter", submitterQueueList);
		} else {
			queueMap.put("Available", availableQueueList);
			queueMap.put("Assigned", assignedQueueList);
		}
		LOGGER.info("exiting WorkQueueController | mapTaskArrayToVOList | returned : "
				+ queueMap);
		return queueMap;
	}

	/**
	 * Returns an array of tasks assigned to the submitter.
	 * <p>
	 * 
	 * @param submitterID
	 * @return an array of ReferenceDataTask
	 */
	private DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST getSubmitterTasks(
			String domainName, HttpSession session) {
		LOGGER.info("entering WorkQueueController | getSubmitterTasks");
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		List<UserRoleVO> userRoleVOs = userContextVO.getUserRoles();

		return getTaskListByTypeId(domainName,
				userContextVO.getUserIdentifier(),
				RefDataUIConstants.WRKFLW_USER_ROLE_ID_SUBMITTER.intValue(),
				getGroupId(domainName, true), 600,
				getAllGroupIdsForUser(domainName, userRoleVOs, false));
	}

	/**
	 * 
	 * The method to retrieve the user group id for the domain. The method has
	 * argument isSubmitter which will determine whether the user is a submitter
	 * or approver role
	 * 
	 * @param domainName
	 * @param isSubmitter
	 * @return groupId
	 */
	private int getGroupId(String domainName, boolean isSubmitter) {
		LOGGER.info("entering WorkQueueController | getGroupId | domainName : "
				+ domainName + " | isSubmitter : " + isSubmitter);
		if (domainName != null
				&& domainName
				.equalsIgnoreCase(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY)) {
			return isSubmitter ? 200 : 201;
		} else if (domainName != null
				&& domainName
				.equalsIgnoreCase(RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE)) {
			return isSubmitter ? 213 : 214;
		} else if (domainName != null
				&& domainName
				.equalsIgnoreCase(RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE)) {
			return isSubmitter ? 209 : 210;
		} else if (domainName != null
				&& domainName
				.equalsIgnoreCase(RefDataPropertiesConstants.DOMAIN_CODE_SCOTS)) {
			return isSubmitter ? 211 : 212;
		} else if (domainName != null
				&& domainName
				.equalsIgnoreCase(RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS)) {
			return isSubmitter ? 227 : 228;
		} else if (domainName != null
				&& domainName
				.equalsIgnoreCase(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS)) {
			return isSubmitter ? 225 : 226;
		} else if (domainName != null
				&& domainName
				.equalsIgnoreCase(RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES)) {
			return isSubmitter ? 217 : 218;
		} else {
			return 0;
		}
	}

	/**
	 * Returns an array of tasks assigned to the approver.
	 * <p>
	 * 
	 * @param approverID
	 * @return an array of ReferenceDataTask
	 */
	private DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST getApproverTasks(
			String domainName, HttpSession session) {
		LOGGER.info("entering WorkQueueController | getApproverTasks");
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		List<UserRoleVO> userRoleVOs = userContextVO.getUserRoles();

		return getTaskListByTypeId(domainName,
				userContextVO.getUserIdentifier(),
				RefDataUIConstants.WRKFLW_USER_ROLE_ID_APPROVER.intValue(),
				getGroupId(domainName, false), 601,
				getAllGroupIdsForUser(domainName, userRoleVOs, true));
	}

	/**
	 * 
	 * The method to retrieve the task list for the work queue page
	 * 
	 * @param domainName
	 * @param userEmailAddress
	 * @param userRoleId
	 * @param userGroupId
	 * @param typeId
	 * @param userGroupIds
	 * @return
	 */
	private DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST getTaskListByTypeId(
			String domainName, String userEmailAddress, int userRoleId,
			int userGroupId, int typeId, List<Integer> userGroupIds) {
		LOGGER.info("entering WorkQueueController | getTaskListByTypeId");
		try {
			return webServiceUtil.getTaskList(domainName, userEmailAddress,
					userRoleId, userGroupId, typeId, userGroupIds);
		} catch (RemoteException e) {
			LOGGER.error(e.getMessage());
			return null;
		} catch (MalformedURLException e) {
			LOGGER.error(e.getMessage());
			return null;
		} catch (ServiceException e) {
			LOGGER.error(e.getMessage());
			return null;
		}
	}

	/**
	 * 
	 * The method will serve the home page of workqueue.
	 * 
	 * @param model
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "/workQueueDetail.form", method = RequestMethod.GET)
	public ModelAndView getWorkQueueDetail(HttpServletRequest request,
			HttpSession session, Model model) throws ParseException {
		ModelAndView workQueueDetailModelAndView;

		LOGGER.info("entering WorkQueueController | getWorkQueueDetail");
		workQueueDetailModelAndView = null;
		WorkQueueVO wqVO = getWorkQueueParams(request);
		session.setAttribute("wqVO", wqVO);
		LOGGER.info("Request details \nDomainId::"+wqVO.getDomainId()+"\nDomainName::"+wqVO.getDomainName()+"\nRequestStatus::"+wqVO.getRequestStatus()+"\nTrackingId::"+wqVO.getTrackingId());
		// Redirecting to separate Work queue detail pages depending on domain
		// names.
		try {
			if (RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY.equals(wqVO
					.getDomainName())) {
				workQueueDetailModelAndView = new ModelAndView("workQueueDetail");
				workQueueDetailModelAndView.addObject("taskHistoryList",
						getWorkQueueHistoryDetails(session, wqVO));
				if (!Long
						.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_BULK_UPLOAD_GEOGRAPHY)
						.equals(wqVO.getChangeType())) {
					prepareGeoWorkQueueDetails(workQueueDetailModelAndView, model,
							wqVO);
				} else {
					prepareGeoWorkQueueDetailsForBulkUpload(
							workQueueDetailModelAndView, wqVO);
				}
			} else if (RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE
					.equals(wqVO.getDomainName())) {
				workQueueDetailModelAndView = new ModelAndView(
						"crcyWorkQueueDetail");
				workQueueDetailModelAndView.addObject("taskHistoryList",
						getWorkQueueHistoryDetails(session, wqVO));
				prepareCurrencyWorkQueueDetails(workQueueDetailModelAndView, model,
						wqVO);
			} else if (RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE
					.equals(wqVO.getDomainName())) {
				if (Long.valueOf(
						RefDataChangeTypeConstants.CHANGE_TYPE_ADD_INDUSTRY_CODE)
						.equals(wqVO.getChangeType())) {
					ModelAndView addIndsCodeModelAndView = indsCodesController
							.getIndustryCodesDetail(
									Long.valueOf(wqVO.getDomainId()),
									String.valueOf(wqVO.getTaskId()), model,
									session);
					addIndsCodeModelAndView.addObject("wqRequestDetails", wqVO);
					addIndsCodeModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					return addIndsCodeModelAndView;
				} else if (Long
						.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_INDUSTRY_CODE)
						.equals(wqVO.getChangeType())
						|| Long.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_INDUSTRY_CODE)
						.equals(wqVO.getChangeType())) {
					workQueueDetailModelAndView = new ModelAndView(
							"industryCodeWorkQueueDetail");
					workQueueDetailModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					prepareIndustryCodeWorkQueueDetails(
							workQueueDetailModelAndView, model, wqVO);
				} else if (Long
						.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_BULK_UPLOAD_INDUSTRY_CODE)
						.equals(wqVO.getChangeType())) {
					workQueueDetailModelAndView = new ModelAndView(
							"industryCodeWorkQueueDetail");
					workQueueDetailModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					prepareIndustryCodeWorkQueueDetailsForBulkUpload(
							workQueueDetailModelAndView, model, wqVO);
				}
			} else if (RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS
					.equals(wqVO.getDomainName())) {
				workQueueDetailModelAndView = new ModelAndView(
						"xmlSchemaWorkQueueDetail");
				workQueueDetailModelAndView.addObject("taskHistoryList",
						getWorkQueueHistoryDetails(session, wqVO));
				prepareXmLSchemaWorkQueueDetails(workQueueDetailModelAndView,
						model, wqVO);
			} else if (RefDataPropertiesConstants.DOMAIN_CODE_SCOTS.equals(wqVO
					.getDomainName())) {
				if (Long.valueOf(
						RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_SYSTEM_APPLICABILITY)
						.equals(wqVO.getChangeType())) {
					ModelAndView systemModelAndView = sCoTSController
							.getManageSystemApplicability("System",
									wqVO.getDomainId(), null,
									Long.valueOf(wqVO.getDomainId()), session,
									model);
					systemModelAndView.addObject("wqRequestDetails", wqVO);
					systemModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					return systemModelAndView;

				} else if (Long
						.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_MARKET_APPLICABILITY)
						.equals(wqVO.getChangeType())) {
					ModelAndView marketModelAndView = sCoTSController
							.getManageSystemApplicability("Market",
									wqVO.getDomainId(), null,
									Long.valueOf(wqVO.getDomainId()), session,
									model);
					marketModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					marketModelAndView.addObject("wqRequestDetails", wqVO);
					return marketModelAndView;

				} else if (Long
						.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_ALTERNATE_SCHEME_CODES)
						.equals(wqVO.getChangeType())) {
					ModelAndView altSchemeCodeModelAndView = sCoTSController
							.retrieveAlternateSchemeCodes(
									Long.valueOf(wqVO.getDomainId()),
									String.valueOf(wqVO.getTaskId()), model,
									session);
					altSchemeCodeModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					altSchemeCodeModelAndView.addObject("wqRequestDetails", wqVO);
					return altSchemeCodeModelAndView;

				} else if (Long.valueOf(
						RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_CODE_VALUE)
						.equals(wqVO.getChangeType())
						|| Long.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_ADD_CODE_VALUE)
						.equals(wqVO.getChangeType())) {
					workQueueDetailModelAndView = new ModelAndView(
							"codeValueWorkQueueDetail");
					workQueueDetailModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					prepareCodeValueWorkQueueDetails(workQueueDetailModelAndView,
							model, wqVO);

				} else if (Long.valueOf(
						RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_CODE_TABLE)
						.equals(wqVO.getChangeType())
						|| Long.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_ADD_CODE_TABLE)
						.equals(wqVO.getChangeType())) {
					workQueueDetailModelAndView = new ModelAndView(
							"codeTableWorkQueueDetail");
					workQueueDetailModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					prepareCodeTableWorkQueueDetails(workQueueDetailModelAndView,
							model, wqVO);

				} else if (Long
						.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_SCOTS_RELATIONSHIP)
						.equals(wqVO.getChangeType())) {
					String relationShipId = wqVO.getDomainId();
					workQueueDetailModelAndView = sCoTSController
							.retrieveCodeRelationship(
									Long.valueOf(relationShipId.split("~")[0]),
									Long.valueOf(relationShipId.split("~")[1]),
									wqVO.getTaskId(), false, model, session);
					workQueueDetailModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);
				} else if (Long.valueOf(
						RefDataChangeTypeConstants.CHANGE_TYPE_BULK_UPLOAD_SCOTS)
						.equals(wqVO.getChangeType())) {
					workQueueDetailModelAndView = new ModelAndView(
							"codeValueWorkQueueDetail");
					workQueueDetailModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					prepareScotsWorkQueueDetailsForBulkUpload(
							workQueueDetailModelAndView, model, wqVO);
				}
			}
			// Control Words domain
			else if (RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS
					.equals(wqVO.getDomainName())) {
				if (Long.valueOf(
						RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_LEGAL_FORM_INFERMENT)
						.equals(wqVO.getChangeType())
						|| Long.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_ADD_LEGAL_FORM_INFERMENT)
						.equals(wqVO.getChangeType())) {
					workQueueDetailModelAndView = new ModelAndView(
							"legalFormInfermentView");
					workQueueDetailModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					prepareLegalFormInfermentWorkQueueuDetails(
							workQueueDetailModelAndView, model, wqVO, session);
					return workQueueDetailModelAndView;

				} else if (Long
						.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_INDUSTRY_CODE_INFERMENT)
						.equals(wqVO.getChangeType())
						|| Long.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_ADD_INDUSTRY_CODE_INFERMENT)
						.equals(wqVO.getChangeType())) {
					ModelAndView indsCodeInfermentModelAndView = new ModelAndView(
							"indsCodeInfermentSearchView");
					indsCodeInfermentModelAndView.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					prepareIndustryCodeInfermentWorkQueueuDetails(
							indsCodeInfermentModelAndView, model, wqVO, session);
					return indsCodeInfermentModelAndView;
				} else if (Long
						.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_ADD_PHONE_AREA_CODE_NUMBER)
						.equals(wqVO.getChangeType())
						|| Long.valueOf(
								RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_PHONE_AREA_CODE_NUMBER)
						.equals(wqVO.getChangeType())) {
					ModelAndView addPhoneAreaCodeNumbersModelAndView = controlWordsController
							.getAddAreaCodeNumbers(
									Long.valueOf(wqVO.getDomainId()), false,
									wqVO.getTaskId(), model, session);
					addPhoneAreaCodeNumbersModelAndView.addObject(
							"taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					addPhoneAreaCodeNumbersModelAndView.addObject(
							"wqRequestDetails", wqVO);
					return addPhoneAreaCodeNumbersModelAndView;
				} else {
					ModelAndView controlWordDetail = controlWordsController
							.retrieveControlWordByIdAndTypeCode(
									Long.valueOf(wqVO.getDomainId()),
									getTypeCodeText(wqVO.getChangeType()),
									wqVO.getTrackingId(), model);
					controlWordDetail.addObject("taskHistoryList",
							getWorkQueueHistoryDetails(session, wqVO));
					controlWordDetail.addObject("wqRequestDetails", wqVO);
					return controlWordDetail;
				}
			}// Finance
			else if (RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES
					.equals(wqVO.getDomainName())) {
				workQueueDetailModelAndView = new ModelAndView(
						"previewFinancialTemplate");
				workQueueDetailModelAndView.addObject("taskHistoryList",
						getWorkQueueHistoryDetails(session, wqVO));
				workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);
				prepareFinancialStatementTemplateWorkQueueDetails(
						workQueueDetailModelAndView, model, wqVO, session);
			}

			LOGGER.info("exiting WorkQueueController | getWorkQueueDetail | returned : "
					+ workQueueDetailModelAndView);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return workQueueDetailModelAndView;
	}

	/**
	 * 
	 * The method to prepare the financial template work queue details
	 * 
	 * @param workQueueDetailModelAndView
	 * @param model
	 * @param wqVO
	 * @param session
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	private ModelAndView prepareFinancialStatementTemplateWorkQueueDetails(
			ModelAndView workQueueDetailModelAndView, Model model,
			WorkQueueVO wqVO, HttpSession session) {
		LOGGER.info("entering WorkQueueController | prepareFinancialStatementTemplateWorkQueueDetails");
		LOGGER.info("WorkQueueController | prepareFinancialStatementTemplateWorkQueueDetails "
				+ "| domainId : " + wqVO.getDomainId());
		FinancialStatementTemplate financialStatementTemplate = financialTemplateController
				.retrieveFinancialStatementTemplateById(Long.valueOf(wqVO
						.getDomainId()));
		FinancialStatementVO fsVO = new FinancialStatementVO();

		LOGGER.info("WorkQueueController | prepareFinancialStatementTemplateWorkQueueDetails "
				+ "| financialStatementTemplate : "
				+ financialStatementTemplate);
		if (financialStatementTemplate != null) {
			financialStatementTemplate = financialTemplateController
					.populateDescForId(financialStatementTemplate);
			List<Integer> scheduleCodeList = financialTemplateController
					.getScheduleCodeList(financialStatementTemplate);

			List<CodeValueText> statementList = ftProxy
					.retrieveStatementForSchedules(scheduleCodeList);
			LOGGER.info("WorkQueueController | prepareFinancialStatementTemplateWorkQueueDetails "
					+ "| statementList : " + statementList);

			Iterator stmtItr = null;
			Map<Long, FinancialStatementTemplate> fsTemplateMap = new LinkedHashMap<Long, FinancialStatementTemplate>();
			FinancialStatementTemplate fsTemplate = null;
			List<FinancialStatementSchedule> scheduleList = null;
			Collections.sort(financialStatementTemplate
					.getFinancialStatementScheduleList(),
					new ScheduleComparable());
			for (FinancialStatementSchedule schedule : financialStatementTemplate
					.getFinancialStatementScheduleList()) {
				Collections.sort(
						schedule.getFinancialStatementTemplateLineItemList(),
						new LineItemComparable());
				stmtItr = statementList.iterator();
				while (stmtItr.hasNext()) {
					LinkedHashMap curr = (LinkedHashMap) stmtItr.next();
					if (schedule.getFinancialStatementScheduleCode() == ((Integer) curr
							.get("childCodeValueId")).longValue()) {
						if (fsTemplateMap.containsKey(((Integer) curr
								.get("codeValueId")).longValue())) {
							fsTemplate = fsTemplateMap.get(((Integer) curr
									.get("codeValueId")).longValue());
						} else {
							fsTemplate = new FinancialStatementTemplate();
						}
						fsTemplate.setFinancialTemplateTypeCode(((Integer) curr
								.get("codeValueId")).longValue());
						fsTemplate.setTypeCodeDescription((String) curr
								.get("codeValueDescription"));
						break;
					}
				}
				scheduleList = fsTemplate.getFinancialStatementScheduleList();
				if (scheduleList == null) {
					scheduleList = new ArrayList<FinancialStatementSchedule>();
				}
				scheduleList.add(schedule);
				fsTemplate.setFinancialStatementScheduleList(scheduleList);
				if (!fsTemplateMap.containsKey(schedule
						.getFinancialStatementScheduleCode())) {
					fsTemplateMap.put(
							fsTemplate.getFinancialTemplateTypeCode(),
							fsTemplate);
				}
			}
			fsVO.setFinancialStatementTemplateList(fsTemplateMap);
			// setting the modified user details QC: 3687
			fsVO.setModifiedDate(financialStatementTemplate.getModifiedDate());
			fsVO.setModifiedUser(financialStatementTemplate.getModifiedUser());
			fsVO.setEffectiveDate(financialStatementTemplate
					.getEffectiveFromDate());
		}

		LOGGER.info("WorkQueueController | prepareFinancialStatementTemplateWorkQueueDetails "
				+ "| financialStatementVO : " + fsVO);
		model.addAttribute("financialStatementVO", fsVO);
		LOGGER.info("exiting WorkQueueController | prepareFinancialStatementTemplateWorkQueueDetails");
		return workQueueDetailModelAndView;

	}

	/**
	 * 
	 * The method to prepare the IndustryCode for the Industry Code bulk upload
	 * 
	 * @param workQueueDetailModelAndView
	 * @param model
	 * @param wqVO
	 * @return
	 */
	private ModelAndView prepareIndustryCodeWorkQueueDetailsForBulkUpload(
			ModelAndView workQueueDetailModelAndView, Model model,
			WorkQueueVO wqVO) {
		//AddTryCatch
		try {
			workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);
			IndustryCode industryCode = new IndustryCode();
			industryCode.setModifiedDate(new Date());
			industryCode.setModifiedUser("Test");
			model.addAttribute("industryCode", industryCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return workQueueDetailModelAndView;

	}

	/**
	 * 
	 * The method to prepare the GeoUnit for the Geography bulk upload
	 * 
	 * @param workQueueDetailModelAndView
	 * @param wqVO
	 * @return
	 */
	private ModelAndView prepareGeoWorkQueueDetailsForBulkUpload(
			ModelAndView workQueueDetailModelAndView, WorkQueueVO wqVO) {
		try {
			workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);
			// GeoUnit geoUnit =
			// wsProxy.reviewGeoUnitChanges(Long.valueOf(wqVO.getDomainId()));
			GeoUnit geoUnit = new GeoUnit();
			geoUnit.setModifiedDate(new Date());
			geoUnit.setModifiedUser("Test");
			geoUnit.setExpiredByDate(new Date());
			workQueueDetailModelAndView.addObject("geoUnit", geoUnit);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return workQueueDetailModelAndView;
	}

	/**
	 * 
	 * The method to prepare the CodeValue for the Scots bulk upload
	 * 
	 * @param workQueueDetailModelAndView
	 * @param model
	 * @param wqVO
	 * @return
	 */
	private ModelAndView prepareScotsWorkQueueDetailsForBulkUpload(
			ModelAndView workQueueDetailModelAndView, Model model,
			WorkQueueVO wqVO) {
		workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);
		CodeValue codeValue = new CodeValue();
		codeValue.setModifiedDate(new Date());
		codeValue.setModifiedUser("Test");
		model.addAttribute("codeValue", codeValue);
		return workQueueDetailModelAndView;

	}

	/**
	 * 
	 * The method to retrieve the workQueue parameters
	 * 
	 * @param request
	 * @return
	 * @throws ParseException
	 */
	private WorkQueueVO getWorkQueueParams(HttpServletRequest request)
			throws ParseException {
		LOGGER.info("entering WorkQueueController | getWorkQueueParams");
		WorkQueueVO wqVO = new WorkQueueVO();
		if (request.getParameter("trackingId") != null
				&& !request.getParameter("trackingId").trim().isEmpty()) {
			wqVO.setTrackingId(Long.valueOf(request.getParameter("trackingId")));
		}
		if (request.getParameter("domainId") != null
				&& !request.getParameter("domainId").trim().isEmpty()) {
			wqVO.setDomainId(request.getParameter("domainId"));
		}
		if (request.getParameter("taskId") != null
				&& !request.getParameter("taskId").trim().isEmpty()) {
			wqVO.setTaskId(Long.valueOf(request.getParameter("taskId")));
		}
		if (request.getParameter("changeType") != null
				&& !request.getParameter("changeType").trim().isEmpty()) {
			wqVO.setChangeType(Long.valueOf(request.getParameter("changeType")));
		}
		if (request.getParameter("changeTypeDesc") != null
				&& !request.getParameter("changeTypeDesc").trim().isEmpty()) {
			wqVO.setChangeTypeDescription(request
					.getParameter("changeTypeDesc"));
		}
		wqVO.setSourceQueue(request.getParameter("sourceQueue"));
		wqVO.setFileName(request.getParameter("fileName"));
		wqVO.setDomainName(request.getParameter("domainName"));
		wqVO.setSubmitterId(request.getParameter("submitterId"));
		wqVO.setRequestStatus(request.getParameter("requestStatus"));
		wqVO.setRequestSubmittedDate(request.getParameter("dateSubmitted"));
		if (request.getParameter("submitterRoleId") != null
				&& !request.getParameter("submitterRoleId").trim().isEmpty()) {
			wqVO.setSubmitterRoleId(Integer.valueOf(request
					.getParameter("submitterRoleId")));
		}
		if (request.getParameter("submitterGroupId") != null
				&& !request.getParameter("submitterGroupId").trim().isEmpty()) {
			wqVO.setSubmitterGroupId(Integer.valueOf(request
					.getParameter("submitterGroupId")));
		}

		LOGGER.info("exiting WorkQueueController | getWorkQueueParams | returned : "
				+ wqVO);
		return wqVO;
	}

	/**
	 * 
	 * The method is invoked when the user clicks on the approve button in the
	 * approval/ review page
	 * 
	 * @param taskId
	 * @param trackingId
	 * @param submitterGroupId
	 * @param approverDecision
	 * @param approverComments
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "workQueueComplete.form", method = RequestMethod.GET)
	public @ResponseBody
	Boolean workQueueComplete(@RequestParam("taskId") long taskId,
			@RequestParam("trackingId") long trackingId,
			@RequestParam("submitterGroupId") int submitterGroupId,
			@RequestParam("approverDecision") boolean approverDecision,
			@RequestParam("approverComments") String approverComments,
			HttpSession session) {

		LOGGER.info("entering WorkQueueController | workQueueComplete");
		// audit variables
		Date startTime = new Date();
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);

		String submitterId = userContextVO.getUserIdentifier();
		LOGGER.info(taskId + " : " + trackingId + " : " + submitterId + " : "
				+ submitterGroupId + " : " + approverDecision + " : "
				+ approverComments);

		Boolean isComplete = completeTask(taskId, trackingId, submitterId,
				submitterGroupId, approverDecision, approverComments);

		WorkQueueVO wqVO = (WorkQueueVO) session.getAttribute("wqVO");
		// transaction logging
		transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(wqVO.getDomainName(),
						userContextVO.getUserRoles()), wqVO.getDomainName(),
				"workQueueComplete - " + (isComplete ? "APPROVE" : "REJECT"),
				0L, wqVO.getDomainId(), wqVO.getTrackingId(), wqVO);

		LOGGER.info("exiting WorkQueueController | workQueueComplete | isComplete : "
				+ isComplete);
		return isComplete;
	}

	/**
	 * Updates the data slot values and completes the work step (where the work
	 * flow was paused for the approver to review the request).
	 * <p>
	 * 
	 * @param workflowID
	 * @param taskID
	 * @param approverID
	 * @param approverDecision
	 * @param approverComments
	 * @param trackingID
	 * @return an instance of ReferenceDataServiceResponse
	 */
	private boolean completeTask(long taskId, long workflowTrackingId,
			String submitterEmailAddress, int submitterGroupId,
			boolean approverDecision, String approverComments) {
		LOGGER.info("entering WorkQueueController | completeTask");
		try {
			webServiceUtil.completeTask(taskId, workflowTrackingId,
					submitterEmailAddress, submitterGroupId, approverDecision,
					approverComments);

			LOGGER.info("exiting WorkQueueController | completeTask");
			return true;
		} catch (MalformedURLException e) {
			LOGGER.info(e.getMessage());
			return false;
		} catch (ServiceException e) {
			LOGGER.info(e.getMessage());
			return false;
		} catch (RemoteException e) {
			LOGGER.info(e.getMessage());
			return false;
		} catch (Exception e) {
			LOGGER.info(e.getMessage());
			return false;
		}
	}

	/**
	 * Prepares work queue details for the domain Geography.
	 * <p>
	 * 
	 * @param workQueueDetailModelAndView
	 * @param model
	 * @param wqVO
	 * @return workQueueDetailModelAndView, the ModelAndView
	 */
	private ModelAndView prepareGeoWorkQueueDetails(
			ModelAndView workQueueDetailModelAndView, Model model,
			WorkQueueVO wqVO) {
		try {
			workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);
			GeoUnit geoUnit = wsProxy.reviewGeoUnitChanges(Long.valueOf(wqVO
					.getDomainId()));
			if (geoUnit.getParentGeoUnitAssociations() != null && !geoUnit.getParentGeoUnitAssociations().isEmpty()) {
				geoController.populateGeoUnitAssociationParentGeoUnit(geoUnit);
				geoUnit.setParentGeoUnitAssociations(geoController
						.sortGeoUnitAssociations(geoUnit
								.getParentGeoUnitAssociations()));
			}

			model.addAttribute("geoUnit", geoUnit);

			// setting the default language for the GeoUnit
			workQueueDetailModelAndView.addObject("geoDefaultLanguage",
					geoController.findGeoDefaultLanguageCode(geoUnit));

			// Populating request object with code values
			List<Integer> codeTableIds = new ArrayList<Integer>();
			codeTableIds
			.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE);
			codeTableIds
			.add(RefDataPropertiesConstants.CODE_TABLE_ID_INFO_SOURCES);
			codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
			codeTableIds
			.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_UNIT_TYPE);
			codeTableIds
			.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_CODE_TYPE);
			Map<String, List<CodeValue>> tempCodeValueMap = homeController
					.retrieveCodeValues(codeTableIds);

			// set the code values to the view object
			workQueueDetailModelAndView
			.addObject(
					"nameTypeCodeValues",
					tempCodeValueMap.get(String
							.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE)));
			workQueueDetailModelAndView
			.addObject(
					"languageCodeValues",
					tempCodeValueMap.get(String
							.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));
			workQueueDetailModelAndView
			.addObject(
					"dataProviderCodeValues",
					tempCodeValueMap.get(String
							.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INFO_SOURCES)));
			workQueueDetailModelAndView
			.addObject(
					"geoUnitTypeCodeValues",
					tempCodeValueMap.get(String
							.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_UNIT_TYPE)));
			workQueueDetailModelAndView
			.addObject(
					"geoCodeTypeCodeValues",
					tempCodeValueMap.get(String
							.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_CODE_TYPE)));
			List<CodeValueVO> countryList = getCountryList();				
			workQueueDetailModelAndView.addObject("countryList",countryList);

		} catch (Exception e) {
			LOGGER.error("entering WorkQueueController | prepareGeoWorkQueueDetails ::",e);

		}
		return workQueueDetailModelAndView;
	}

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	private List<CodeValueVO> getCountryList() {
		return this.wsProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
	}

	/**
	 * Prepares work queue details for the domain Currency Exchange.
	 * <p>
	 * 
	 * @param workQueueDetailModelAndView
	 * @param model
	 * @param wqVO
	 * @return workQueueDetailModelAndView, the ModelAndView
	 */
	@SuppressWarnings("rawtypes")
	private ModelAndView prepareCurrencyWorkQueueDetails(
			ModelAndView workQueueDetailModelAndView, Model model,
			WorkQueueVO wqVO) {
		workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);
		LOGGER.info("entering WorkQueueController | prepareCurrencyWorkQueueDetails | wqVO:"
				+ wqVO);
		/*
		 * For bulk upload no need to check for any attributes from the currency
		 * exchange table. The screen will display link to the uploaded file.
		 */
		if (RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_CURRENCY_EXCHANGE
				.equals(String.valueOf(wqVO.getChangeType()))) {
			CurrencyExchange crcyExchange = crcyWsProxy
					.reviewCurrencyExchangeChanges(Long.valueOf(wqVO
							.getDomainId()));
			model.addAttribute("crcyExchange", crcyExchange);
			LOGGER.info("WorkQueueController | prepareCurrencyWorkQueueDetails | currencyExchange:"
					+ crcyExchange);
			// Populating request object with code values
			List<Integer> codeTableIds = new ArrayList<Integer>();
			codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_CURRENCY);
			codeTableIds
			.add(RefDataPropertiesConstants.CODE_TABLE_ID_DATA_PRECISION);
			Map<String, List<CodeValue>> tempCodeValueMap = homeController
					.retrieveCodeValues(codeTableIds);

			// set the code values to the view object
			workQueueDetailModelAndView
			.addObject(
					"currencyCodeValues",
					tempCodeValueMap.get(String
							.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_CURRENCY)));
			workQueueDetailModelAndView
			.addObject(
					"datePrecisionCodeValues",
					tempCodeValueMap.get(String
							.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_DATA_PRECISION)));

			List curcyExchDataProviders = crcyWsProxy
					.retrieveCurcyExchDataProviders(RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			workQueueDetailModelAndView.addObject("dataProviderCodeValues",
					curcyExchDataProviders);
		}

		LOGGER.info("exiting WorkQueueController | prepareCurrencyWorkQueueDetails");
		return workQueueDetailModelAndView;
	}

	/**
	 * Prepares work queue details for the domain Industry Code.
	 * <p>
	 * 
	 * @param workQueueDetailModelAndView
	 * @param model
	 * @param wqVO
	 * @return workQueueDetailModelAndView, the ModelAndView
	 */
	private ModelAndView prepareIndustryCodeWorkQueueDetails(
			ModelAndView workQueueDetailModelAndView, Model model,
			WorkQueueVO wqVO) {
		LOGGER.info("entering WorkQueueController | prepareIndustryCodeWorkQueueDetails");
		LOGGER.info("WorkQueueController | prepareIndustryCodeWorkQueueDetails | wqVO : "
				+ wqVO);
		workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);

		IndustryCode industryCodeById = null;
		industryCodeById = indsCodeWsProxy.reviewIndustryCodeChanges(Long
				.valueOf(wqVO.getDomainId()));
		LOGGER.info("WorkQueueController | prepareIndustryCodeWorkQueueDetails | "
				+ industryCodeById);

		model.addAttribute("industryCode", industryCodeById);

		Map<String, List<CodeValue>> tempCodeValueMap = null;
		// Retrieve data from SCOTS
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds
		.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE);
		codeTableIds
		.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_GROUP_LEVEL);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		codeTableIds
		.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE);

		tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);

		workQueueDetailModelAndView
		.addObject(
				"industryCodeTypeCodeValues",
				tempCodeValueMap
				.get(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING));

		workQueueDetailModelAndView
		.addObject(
				"industryCodeGroupLevelValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_GROUP_LEVEL)));

		workQueueDetailModelAndView
		.addObject(
				"industryCodeLanguageValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));
		workQueueDetailModelAndView
		.addObject(
				"industryCodeDescLengthValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE)));

		populateMapToIndustryCode(industryCodeById);
		model.addAttribute("industryCode", industryCodeById);

		if (indsCodesController.isEmptyDescriptionList(industryCodeById)) {
			workQueueDetailModelAndView
			.addObject("emptyDescriptionList", "yes");
		}
		if (indsCodesController.isEmptyMappingList(industryCodeById)) {
			workQueueDetailModelAndView.addObject("emptyMappingList", "yes");
		}

		LOGGER.info("exiting WorkQueueController | prepareIndustryCodeWorkQueueDetails");
		return workQueueDetailModelAndView;
	}

	/**
	 * 
	 * The method to retrieve the history details for a request
	 * 
	 * @param session
	 * @param wqVO
	 * @return
	 */
	private List<WorkQueueHistoryVO> getWorkQueueHistoryDetails(
			HttpSession session, WorkQueueVO wqVO) {
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		List<Integer> apprvrId = new ArrayList<Integer>();
		apprvrId.add(getGroupId(wqVO.getDomainName(), false));
		try {
			DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST taskList = webServiceUtil
					.getTaskHistoryList(wqVO.getDomainName(),
							userContextVO.getUserIdentifier(),
							RefDataUIConstants.WRKFLW_USER_ROLE_ID_SUBMITTER,
							getGroupId(wqVO.getDomainName(), true), 602L,
							apprvrId, wqVO.getTrackingId());
			Map<String, List<WorkQueueHistoryVO>> queueMap = mapTaskHistoryArrayToVOList(
					taskList,
					RefDataUIConstants.WRKFLW_USER_ROLE_ID_SUBMITTER.intValue(),
					getGroupId(wqVO.getDomainName(), true), true);
			if (queueMap != null) {
				return queueMap.get("taskHistory");
			}
		} catch (Exception e) {
			LOGGER.error("Exception occurred in getWorkQueueHistoryDetails method "
					+ e);
		}
		return null;
	}

	/**
	 * 
	 * The method to populate the industry code map
	 * 
	 * @param industryCodeById
	 */
	private void populateMapToIndustryCode(IndustryCode industryCodeById) {
		if (null != industryCodeById.getIndustryCodeMaps()) {
			for (IndustryCodeMap currMap : industryCodeById
					.getIndustryCodeMaps()) {
				currMap.setToIndustryCode(indsCodeWsProxy
						.retrieveIndustryCodeByIndustryCodeId(currMap
								.getIndustryCodeMapPK().getToIndustryCodeId()));
				if ((currMap.getToIndustryCode() != null)
						&& (currMap.getToIndustryCode()
								.getIndustryCodeDescriptions() != null)) {
					for (IndustryCodeDescription currIndustryCodeDescription : currMap
							.getToIndustryCode().getIndustryCodeDescriptions()) {
						if (currIndustryCodeDescription.getLanguageCode() != null
								&& currIndustryCodeDescription
								.getLanguageCode().longValue() == RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH
								.longValue()) {
							currMap.getToIndustryCode()
							.setIndustryCodeDescription(
									currIndustryCodeDescription
									.getIndustryDescription());
						}
					}
				}
			}
		}
	}

	/**
	 * Prepares work queue details for the domain SCoTS(CodeTable).
	 * <p>
	 * 
	 * @param workQueueDetailModelAndView
	 * @param model
	 * @param wqVO
	 * @return workQueueDetailModelAndView, the ModelAndView
	 */
	private ModelAndView prepareCodeTableWorkQueueDetails(
			ModelAndView workQueueDetailModelAndView, Model model,
			WorkQueueVO wqVO) {
		LOGGER.info("entering WorkQueueController | prepareCodeTableWorkQueueDetails");
		LOGGER.info("WorkQueueController | prepareCodeTableWorkQueueDetails | "
				+ wqVO);
		workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);
		CodeTable codeTable = scotsWsProxy.reviewCodeTableChanges(Long
				.valueOf(wqVO.getDomainId()));
		model.addAttribute("codeTable", codeTable);

		workQueueDetailModelAndView.addObject(
				"codeTableIdAndName",
				Long.valueOf(wqVO.getDomainId()) + " ["
						+ codeTable.getCodeTableName() + "]");
		workQueueDetailModelAndView.addObject("allSystems",
				scotsWsProxy.retrieveSystemApplicability(Long.valueOf(-1), 0));
		workQueueDetailModelAndView
		.addObject(
				"allCountries",
				wsProxy.retrieveAllCountries(
						RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
						RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));
		workQueueDetailModelAndView.addObject("today", new Date());

		return workQueueDetailModelAndView;
	}

	/**
	 * Prepares work queue details for the domain SCoTS(CodeValue).
	 * <p>
	 * 
	 * @param workQueueDetailModelAndView
	 * @param model
	 * @param wqVO
	 * @return workQueueDetailModelAndView, the ModelAndView
	 */
	private ModelAndView prepareXmLSchemaWorkQueueDetails(
			ModelAndView workQueueDetailModelAndView, Model model,
			WorkQueueVO wqVO) {
		LOGGER.info("entering WorkQueueController | prepareXmLSchemaWorkQueueDetails");
		LOGGER.info("WorkQueueController | prepareXmLSchemaWorkQueueDetails | "
				+ wqVO);
		workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);
		XmlSchemaElement xmlSchemaElement = xmlProxy
				.reviewXmlSchemaByXmlElementChanges(wqVO.getDomainId());

		// adding details to model object
		workQueueDetailModelAndView.addObject("xmlSchemaElement",
				xmlSchemaElement);
		workQueueDetailModelAndView.addObject("xmlSchemaElementLabelDetails",
				xmlSchemaElement.getXmlSchemaElementLabelDetails());
		workQueueDetailModelAndView.addObject("xmlSchemaElementXPath",
				xmlSchemaElement.getXmlSchemaElementXPath());

		// Populating request object with code values
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValues(codeTableIds);
		workQueueDetailModelAndView
		.addObject(
				"languageCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));
		model.addAttribute("xmlSchemaElement", xmlSchemaElement);
		LOGGER.info("exiting WorkQueueController | prepareXmLSchemaWorkQueueDetails "
				+ "| xmlSchemaElement: " + xmlSchemaElement);

		return workQueueDetailModelAndView;
	}

	/**
	 * Prepares work queue details for the domain SCoTS(CodeValue).
	 * <p>
	 * 
	 * @param workQueueDetailModelAndView
	 * @param model
	 * @param wqVO
	 * @return workQueueDetailModelAndView, the ModelAndView
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private ModelAndView prepareCodeValueWorkQueueDetails(
			ModelAndView workQueueDetailModelAndView, Model model,
			WorkQueueVO wqVO) {
		LOGGER.info("entering WorkQueueController | prepareCodeValueWorkQueueDetails");
		LOGGER.info("WorkQueueController | prepareCodeValueWorkQueueDetails | "
				+ wqVO);
		workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);

		CodeValue codeValue = scotsWsProxy.reviewCodeValueChanges(Long
				.valueOf(wqVO.getDomainId()));
		model.addAttribute("codeValue", codeValue);
		// Retrieving the Lists for currency Code and Data Provider
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		codeTableIds
		.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE);
		codeTableIds
		.add(RefDataPropertiesConstants.CODE_TABLE_ID_CODING_SCHEME);

		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValues(codeTableIds);

		List codeValues = tempCodeValueMap
				.get(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE_STRING);
		// sort the codeValues based on the Code Value Id
		Collections.sort(codeValues,
				scotsController.new CodeValueIdComparable());

		List codingSchemes = tempCodeValueMap
				.get(RefDataPropertiesConstants.CODE_TABLE_ID_CODING_SCHEME_STRING);
		// sort the codeValues based on the Code Value Id
		Collections.sort(codingSchemes,
				scotsController.new CodeValueIdComparable());

		workQueueDetailModelAndView
		.addObject(
				"languageCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));
		workQueueDetailModelAndView.addObject(
				RefDataUIConstants.SCOTS_LIST_CODE_TABLE_SESSION,
				scotsWsProxy.retrieveCodeTableList());
		workQueueDetailModelAndView.addObject("codeValues", codeValues);
		workQueueDetailModelAndView.addObject("codingSchemes", codingSchemes);
		workQueueDetailModelAndView.addObject("codeValue", codeValue);

		workQueueDetailModelAndView.addObject("allSystems",
				scotsWsProxy.retrieveSystemApplicability(Long.valueOf(-1), 0));
		workQueueDetailModelAndView
		.addObject(
				"allCountries",
				wsProxy.retrieveAllCountries(
						RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
						RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));

		LOGGER.info("exiting ScotsController | prepareCodeValueWorkQueueDetails | codeValueView :"
				+ codeValue);
		return workQueueDetailModelAndView;
	}

	/**
	 * 
	 * The method for redirecting to the workQueue page
	 * 
	 * @param geoUnit
	 * @param result
	 * @param model
	 * @param session
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "/workQueueProcess.form", method = RequestMethod.POST)
	public View workQueueProcess(@ModelAttribute("geoUnit") GeoUnit geoUnit,
			BindingResult result, Model model, HttpSession session)
					throws ParseException {
		return new RedirectView("submitterWorkQueueHome.form?domainName=");
	}

	/**
	 * 
	 * The method to re assign the task to another user
	 * 
	 * @param taskIdArray
	 * @param approverEmailAddress
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "assignTasksToAnotherUser.form", method = RequestMethod.GET)
	public @ResponseBody
	Boolean assignTasksToAnotherUser(
			@RequestParam("taskIdArray[]") int[] taskIdArray,
			@RequestParam("approverEmailAddress") String approverEmailAddress,
			@RequestParam("domainName") String domainName, HttpSession session) {
		LOGGER.info("entering WorkQueueController | assignTasksToAnotherUser");
		// audit variables
		Date startTime = new Date();
		Long txnStatus = 0L;
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		Boolean rtnValue = false;
		try {
			webServiceUtil
			.assignTasksToAnotherUser(taskIdArray, userContextVO
					.getUserIdentifier(),
					RefDataUIConstants.WRKFLW_USER_ROLE_ID_SUBMITTER
					.intValue(), getGroupId(domainName, true),
					approverEmailAddress);
			LOGGER.info("WorkQueueController | assignTasksToAnotherUser | assigned... ");
			rtnValue = true;
		} catch (RemoteException e) {
			LOGGER.error(e.getMessage());
			txnStatus = 1000L;
			rtnValue = false;
		} catch (MalformedURLException e) {
			LOGGER.error(e.getMessage());
			txnStatus = 2000L;
			rtnValue = false;
		} catch (ServiceException e) {
			LOGGER.error(e.getMessage());
			txnStatus = 3000L;
			rtnValue = false;
		} finally {
			// transaction logging
			transactionLogger.log(
					startTime,
					userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(domainName,
							userContextVO.getUserRoles()), domainName,
					"assignTasksToAnotherUser", txnStatus,
					Arrays.toString(taskIdArray), 0L, approverEmailAddress);
		}

		return rtnValue;
	}

	/**
	 * 
	 * The method to unassign the workQueue Tasks
	 * 
	 * @param taskIdArray
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "unassignTasks.form", method = RequestMethod.GET)
	public @ResponseBody
	Boolean unassignTasks(@RequestParam("taskIdArray[]") int[] taskIdArray,
			@RequestParam("domainName") String domainName, HttpSession session) {

		LOGGER.info("entering WorkQueueController | unassignTasks");
		// audit variables
		Date startTime = new Date();
		Long txnStatus = 0L;
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		Boolean rtnValue = false;
		try {
			webServiceUtil
			.unassignTasks(taskIdArray, userContextVO
					.getUserIdentifier(),
					RefDataUIConstants.WRKFLW_USER_ROLE_ID_SUBMITTER
					.intValue(), getGroupId(domainName, true));
			rtnValue = true;

		} catch (RemoteException e) {
			LOGGER.error(e.getMessage());
			txnStatus = 1000L;
			rtnValue = false;
		} catch (MalformedURLException e) {
			LOGGER.error(e.getMessage());
			txnStatus = 2000L;
			rtnValue = false;
		} catch (ServiceException e) {
			LOGGER.error(e.getMessage());
			txnStatus = 3000L;
			rtnValue = false;
		} finally {
			// transaction logging
			transactionLogger.log(
					startTime,
					userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(domainName,
							userContextVO.getUserRoles()), domainName,
					"unassignTasks", txnStatus, Arrays.toString(taskIdArray),
					0L);
		}
		return rtnValue;
	}

	/**
	 * 
	 * The method to retrieve the users groupIds. The search will be based on
	 * the parameter isApproverOnlyRequired. If true then the method will return
	 * only the approver user groups entitled to the user. Else will return only
	 * the submitter user roles.
	 * 
	 * @param domainName
	 * @param userRoleVOs
	 * @param isApproverOnlyRequired
	 * @return userGroupIds
	 */
	private List<Integer> getAllGroupIdsForUser(String domainName,
			List<UserRoleVO> userRoleVOs, Boolean isApproverOnlyRequired) {
		return roleMapper.getAllGroupIdsForUser(domainName, userRoleVOs,
				isApproverOnlyRequired);
	}

	/**
	 * 
	 * The method to format the date
	 * 
	 * @param inputDate
	 * @param sourceFormat
	 * @param destinationFormat
	 * @return
	 */
	private String changeDateFormat(String inputDate, String sourceFormat,
			String destinationFormat) {
		if (inputDate == null || sourceFormat == null
				|| destinationFormat == null) {
			return null;
		}
		if (inputDate.isEmpty() || sourceFormat.isEmpty()
				|| destinationFormat.isEmpty()) {
			return "";
		}

		try {
			Date dateObj = (new SimpleDateFormat(sourceFormat))
					.parse(inputDate);
			return (new SimpleDateFormat(destinationFormat)).format(dateObj);
		} catch (ParseException e) {
			return null;
		}
	}

	/**
	 * 
	 * The method will populate value from DB and display in the My Downloads
	 * Page
	 * 
	 * @return ModelAndView
	 */
	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = "/workQueueDownload.form", method = RequestMethod.GET)
	public ModelAndView workQueueDownload(HttpSession session,
			HttpServletRequest request) throws ParseException {
		LOGGER.info("entering WorkQueueController | workQueueDownload");
		ModelAndView myDownloads = new ModelAndView("workQueueDownload");
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		List<UiBulkDownload> uiBulkDownloadList = (List<UiBulkDownload>) indsCodeWsProxy
				.retrieveUIBulkDownload(userContextVO.getUserIdentifier());
		String fileName = "";

		List<UiBulkDownload> rows = new ArrayList<UiBulkDownload>();
		for (Iterator itr = uiBulkDownloadList.iterator(); itr.hasNext();) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			UiBulkDownload uiBulkDownload = new UiBulkDownload();
			uiBulkDownload.setUserId((String) curr.get("userId"));
			uiBulkDownload.setUiBulkDownloadId(((Integer) curr
					.get("uiBulkDownloadId")).longValue());
			uiBulkDownload.setDomainName((String) curr.get("domainName"));
			uiBulkDownload.setFileType((String) curr.get("fileType"));
			uiBulkDownload.setDwnloadStartTime(new Date(((Long) curr
					.get("dwnloadStartTime"))));
			if (curr.get("dwnloadEndTime") != null) {
				uiBulkDownload.setDwnloadEndTime(new Date(((Long) curr
						.get("dwnloadEndTime"))));
			}
			uiBulkDownload.setBulkDownloadStatus((String) curr
					.get("bulkDownloadStatus"));
			String fileType = null;
			if (uiBulkDownload.getFileType().equalsIgnoreCase(
					"Industry Code and Description")) {
				fileType = "Inds_Cd_And_Desc";
			} else if (uiBulkDownload.getFileType().equalsIgnoreCase(
					"Industry Code Crosswalk")) {
				fileType = "Inds_Cd_CrossWalk";
			} else if (uiBulkDownload.getFileType().equalsIgnoreCase(
					"Geo Unit Name/Geo Unit Code")) {
				fileType = "Geo_Name_And_Code";
			} else if (uiBulkDownload.getFileType().equalsIgnoreCase(
					"Geo Unit Association")) {
				fileType = "Geo_Unit_Assn";
			} else if (uiBulkDownload.getFileType().equalsIgnoreCase(
					"Code Table")) {
				fileType = "Code_Table";
			} else if (uiBulkDownload.getFileType().equalsIgnoreCase(
					"Code Value")) {
				fileType = "Code_Value";
			} else if (uiBulkDownload.getFileType().equalsIgnoreCase(
					"Inferrment Text")) {
				fileType = "Infrmnt_Txt";
			} else if (uiBulkDownload.getFileType().equalsIgnoreCase(
					"Unusable Glossary")) {
				fileType = "Unus_Glsy";
			} else if (uiBulkDownload.getFileType().equalsIgnoreCase(
					"Telecommunication")) {
				fileType = "Telecom";
			}
			fileName = fileType
					+ RefDataPropertiesConstants.UNDERSOCRE
					+ uiBulkDownload.getUiBulkDownloadId()
					+ RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_FILE_FORMAT;
			uiBulkDownload.setFileName(fileName);
			File file = null;
			if (uiBulkDownload.getDomainName().equals(
					RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE)) {
				file = new File(
						refdataConfig
						.getValue(RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_LOCATION)
						+ fileName);
			} else if (uiBulkDownload.getDomainName().equals(
					RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY)) {
				file = new File(
						refdataConfig
						.getValue(RefDataPropertiesConstants.REFDATA_GEOGRAPHY_BLK_DOWNLOAD_LOCATION)
						+ fileName);
			} else if (uiBulkDownload.getDomainName().equals(
					RefDataPropertiesConstants.DOMAIN_CODE_SCOTS)) {
				file = new File(
						refdataConfig
						.getValue(RefDataPropertiesConstants.REFDATA_SCOTS_BLK_DOWNLOAD_LOCATION)
						+ fileName);
			} else if (uiBulkDownload.getDomainName().equals(
					RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS)) {
				file = new File(
						refdataConfig
						.getValue(RefDataPropertiesConstants.REFDATA_CTRLWRDS_BLK_DOWNLOAD_LOCATION)
						+ fileName);
			}

			if (uiBulkDownload.getBulkDownloadStatus().equalsIgnoreCase(
					"Completed")) {
				if (!file.exists()) {
					uiBulkDownload.setFileName("No Records Found");
				}
			}
			rows.add(uiBulkDownload);
		}
		myDownloads.addObject("downloadlist", rows);
		LOGGER.info("exiting WorkQueueController | workQueueDownload");
		return myDownloads;
	}

	/**
	 * 
	 * The method will download the currency bulk file
	 * 
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/myDownloads.form", method = RequestMethod.GET)
	public @ResponseBody
	ModelAndView downloadFile(@RequestParam("fileName") String fileName,
			@RequestParam("domainName") String domainName,
			HttpServletResponse response) {
		LOGGER.info("entering WorkQueueController | downloadFile");
		File file = null;
		if (domainName
				.equals(RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE)) {
			file = new File(
					refdataConfig
					.getValue(RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_LOCATION)
					+ fileName);
		} else if (domainName
				.equals(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY)) {
			file = new File(
					refdataConfig
					.getValue(RefDataPropertiesConstants.REFDATA_GEOGRAPHY_BLK_DOWNLOAD_LOCATION)
					+ fileName);
		} else if (domainName
				.equals(RefDataPropertiesConstants.DOMAIN_CODE_SCOTS)) {
			file = new File(
					refdataConfig
					.getValue(RefDataPropertiesConstants.REFDATA_SCOTS_BLK_DOWNLOAD_LOCATION)
					+ fileName);
		} else if (domainName
				.equals(RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS)) {
			file = new File(
					refdataConfig
					.getValue(RefDataPropertiesConstants.REFDATA_CTRLWRDS_BLK_DOWNLOAD_LOCATION)
					+ fileName);
		}
		FileInputStream fin;
		try {
			fin = new FileInputStream(file);
			response.setContentType("application/xlsx");
			response.setContentLength((int) file.length());
			response.setHeader("Cache-Control","no-store");
			response.setHeader("Pragma", "private"); 			
			response.setHeader("Content-Disposition", "attachment; filename=\""
					+ fileName + "\"");
			FileCopyUtils.copy(fin, response.getOutputStream());
		} catch (FileNotFoundException e) {
			LOGGER.error(e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
		LOGGER.info("exiting WorkQueueController | downloadFile");
		return null;
	}

	/**
	 * 
	 * The method to view the uploaded file
	 * 
	 * @param fileName
	 * @param domainName
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/viewUploadedFile.form", method = RequestMethod.GET)
	public @ResponseBody
	ModelAndView viewUploadedFile(@RequestParam("fileName") String fileName,
			@RequestParam("domainName") String domainName,
			HttpServletResponse response) {
		LOGGER.info("entering WorkQueueController | viewUploadedFile");
		File file = null;
		if (fileName.contains("/")) {
			file = new File(fileName);
		} else {
			if (domainName
					.equals(RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE)) {
				file = new File(
						RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_UPLOAD_VAL_LOCATION
						+ fileName);
			} else if (domainName
					.equals(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY)) {
				file = new File(
						RefDataPropertiesConstants.REFDATA_GEOGRAPHY_BLK_UPLOAD_VAL_LOCATION
						+ fileName);
			} else if (domainName
					.equals(RefDataPropertiesConstants.DOMAIN_CODE_SCOTS)) {
				file = new File(
						RefDataPropertiesConstants.REFDATA_SCOTS_BLK_UPLOAD_VAL_LOCATION
						+ fileName);
			}
		}
		FileInputStream fin;
		try {
			fin = new FileInputStream(file);
			response.setContentType("application/xlsx");
			response.setContentLength((int) file.length());
			response.setHeader("Content-Disposition", "attachment; filename=\""
					+ fileName + "\"");
			FileCopyUtils.copy(fin, response.getOutputStream());
		} catch (FileNotFoundException e) {
			LOGGER.error(e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
		LOGGER.info("exiting WorkQueueController | viewUploadedFile");
		return null;
	}

	/**
	 * Prepares work queue details for the domain Control Words Legal Form
	 * Inferment.
	 * <p>
	 * 
	 * @param workQueueDetailModelAndView
	 * @param model
	 * @param wqVO
	 * @return workQueueDetailModelAndView, the ModelAndView
	 */
	private ModelAndView prepareLegalFormInfermentWorkQueueuDetails(
			ModelAndView workQueueDetailModelAndView, Model model,
			WorkQueueVO wqVO, HttpSession session) {
		LOGGER.info("entering WorkQueueController | prepareLegalFormInfermentWorkQueueuDetails");
		LOGGER.info("WorkQueueController | prepareLegalFormInfermentWorkQueueuDetails | "
				+ wqVO);
		workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);
		InfermentText infermentText = cwProxy.reviewInfermentChanges(Long
				.valueOf(wqVO.getDomainId()));

		// adding details to model object
		workQueueDetailModelAndView.addObject("legalFormClassCodeList",
				cwProxy.retrieveLegalFormClassCodes());
		workQueueDetailModelAndView.addObject("legalFormCodeList",
				cwProxy.retrieveLegalFormCodes());
		workQueueDetailModelAndView.addObject("legalFormCountryList",
				cwProxy.retrieveLegalFormCountries());
		workQueueDetailModelAndView
		.addObject(
				"allCountries",
				wsProxy.retrieveAllCountries(
						RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
						RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));
		workQueueDetailModelAndView.addObject("today", new Date());
		// Retrieving the Lists of languages
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValues(codeTableIds);
		workQueueDetailModelAndView
		.addObject(
				"languageCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));

		LOGGER.info("WorkQueueController | prepareLegalFormInfermentWorkQueueuDetails "
				+ "| infermentText : " + infermentText);
		model.addAttribute("infermentText", infermentText);

		LOGGER.info("exiting WorkQueueController | prepareLegalFormInfermentWorkQueueuDetails");
		return workQueueDetailModelAndView;
	}

	/**
	 * Prepares work queue details for the domain Control Words Industry Code
	 * Inferment.
	 * 
	 * @param workQueueDetailModelAndView
	 * @param model
	 * @param wqVO
	 * @param session
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private ModelAndView prepareIndustryCodeInfermentWorkQueueuDetails(
			ModelAndView workQueueDetailModelAndView, Model model,
			WorkQueueVO wqVO, HttpSession session) {
		LOGGER.info("entering WorkQueueController | prepareIndustryCodeInfermentWorkQueueuDetails");
		LOGGER.info("WorkQueueController | prepareIndustryCodeInfermentWorkQueueuDetails | "
				+ wqVO);
		workQueueDetailModelAndView.addObject("wqRequestDetails", wqVO);

		InfermentText infermentText = cwProxy.reviewInfermentChanges(Long
				.valueOf(wqVO.getDomainId()));

		LOGGER.info("WorkQueueController | prepareIndustryCodeInfermentWorkQueueuDetails "
				+ "| infermentText : " + infermentText);
		LOGGER.info("iNDUSTRY lIST IS " + infermentText.getIndustryCodeList());

		IndustryCodeInferment industryCodeInferment = null;
		// fetch all details other than country applicability
		industryCodeInferment = cwProxy.industryCodeInfermentSearchView(Long
				.valueOf(wqVO.getDomainId()));
		LOGGER.info("WorkQueueController | prepareIndustryCodeInfermentWorkQueueuDetails "
				+ "| industryCodeInferment: " + industryCodeInferment);
		// setting IndustryCode object

		// fetching industry code type
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds
		.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);

		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValues(codeTableIds);
		List industryCodeTypes = tempCodeValueMap
				.get(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING);

		// sort the codeValues based on the Code Value Id
		Collections.sort(industryCodeTypes,
				controlWordsController.new IndustryCodeValueIdComparable());

		// session.setAttribute(RefDataUIConstants.INDUSTRY_CODES_SEARCH_INDUSTRY_CODE_TYPES_SESSION,
		// codeValues);

		// fetching the country applicability list
		workQueueDetailModelAndView.addObject("legalFormCountryList",
				cwProxy.retrieveLegalFormCountries());
		workQueueDetailModelAndView
		.addObject(
				"allCountries",
				wsProxy.retrieveAllCountries(
						RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
						RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH));

		// Retrieving the Lists of languages
		workQueueDetailModelAndView
		.addObject(
				"languageCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));
		workQueueDetailModelAndView.addObject("industryCodeTypes",
				industryCodeTypes);

		workQueueDetailModelAndView.addObject("infermentTextView",
				industryCodeInferment);
		model.addAttribute("infermentText", infermentText);

		LOGGER.info("exiting WorkQueueController | prepareIndustryCodeInfermentWorkQueueuDetails");
		return workQueueDetailModelAndView;

	}

	/**
	 * 
	 * The method to map the task history array to the WorkQueueVO
	 * 
	 * @param taskList
	 * @param userRoleId
	 * @param userGroupId
	 * @param isSubmitterQueue
	 * @return
	 * @throws ParseException
	 */
	private Map<String, List<WorkQueueHistoryVO>> mapTaskHistoryArrayToVOList(
			DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST taskList,
			int userRoleId, int userGroupId, boolean isSubmitterQueue)
					throws ParseException {
		if (taskList == null) {
			return null;
		}
		TSKLSTDATATYP taskListDataType = taskList.getTSKLSTDATA();
		if (taskListDataType == null) {
			return null;
		}

		TSKLSTHISTTYP taskHistory = taskListDataType.getTSKLSTHIST();
		if (taskHistory == null) {
			return null;
		}
		List<TSKLSTHISTDTLTYP> taskHistoryArray = taskHistory
				.getTSKLSTHISTDTL();
		List<WorkQueueHistoryVO> submitterQueueHistoryList = new ArrayList<WorkQueueHistoryVO>();
		Map<String, List<WorkQueueHistoryVO>> queueMap = new HashMap<String, List<WorkQueueHistoryVO>>();
		WorkQueueHistoryVO currWQVO = null;
		for (TSKLSTHISTDTLTYP currentTask : taskHistoryArray) {
			if (currentTask != null) {
				currWQVO = new WorkQueueHistoryVO(currentTask.getSBMTRID(),
						changeDateFormat(currentTask.getREQSSBMTDT(),
								"MM/dd/yyyy", "yyyy-MM-dd"),
						currentTask.getAPRVID(), changeDateFormat(
								currentTask.getREQSRVWDT(), "MM/dd/yyyy",
								"yyyy-MM-dd"), currentTask.getREQSSTAT(),
						currentTask.getREJREAS());
				submitterQueueHistoryList.add(currWQVO);
			}
		}
		queueMap.put("taskHistory", submitterQueueHistoryList);
		return queueMap;
	}

	/**
	 * 
	 * getTypeCodeText
	 * 
	 * @param changeType
	 * @return
	 */
	private String getTypeCodeText(Long changeType) {
		String typeCodeText = null;
		switch (changeType.intValue()) {
		case 531:
		case 532:
		case 533:
			typeCodeText = "D&B Unsuable Individual Name";
			break;
		case 541:
		case 542:
		case 543:
			typeCodeText = "D&B Unsuable Organization Name";
			break;
		case 551:
		case 552:
		case 553:
			typeCodeText = "D&B Unsuable Address";
			break;
		case 561:
		case 562:
		case 563:
			typeCodeText = "Industry Code Inferment Noise Word";
			break;
		case 571:
		case 572:
		case 573:
			typeCodeText = "D&B Unsuable Telephone Number";
			break;
		case 581:
		case 582:
		case 583:
			typeCodeText = "D&B Unsuable Area Code Number";
			break;
		case 591:
		case 592:
		case 593:
			typeCodeText = "Phone Area Code Number";
			break;

		}
		return typeCodeText;
	}

	/**
	 * 
	 * The class to implement the comparator for Financial Statement Template
	 * line item
	 * 
	 * @author Cognizant
	 * @version last updated : Jul 7, 2012
	 * @see
	 * 
	 */
	public class LineItemComparable implements
	Comparator<FinancialStatementTemplateLineItem> {
		@Override
		public int compare(FinancialStatementTemplateLineItem lineItem1,
				FinancialStatementTemplateLineItem lineItem2) {
			return ((Integer) lineItem1.getLineItemSequenceNumber().intValue())
					.compareTo((Integer) lineItem2.getLineItemSequenceNumber()
							.intValue());
		}
	}

	/**
	 * 
	 * The class to implement the comparator for Financial Statement Schedule
	 * 
	 * @author Cognizant
	 * @version last updated : Jul 7, 2012
	 * @see
	 * 
	 */
	public class ScheduleComparable implements
	Comparator<FinancialStatementSchedule> {
		@Override
		public int compare(FinancialStatementSchedule schedule1,
				FinancialStatementSchedule schedule2) {
			return ((Integer) schedule1.getFinancialStatementScheduleId()
					.intValue()).compareTo((Integer) schedule2
							.getFinancialStatementScheduleId().intValue());
		}
	}

	/**
	 * 
	 * The method is to display the saved records
	 * 
	 * @param domainName
	 * @param session
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "/savedRecords.form", method = RequestMethod.GET)
	public ModelAndView getSavedRecord(
			@RequestParam("domainName") final String domainName,
			HttpSession session) throws ParseException {
		LOGGER.info("entering WorkQueueController | getSavedRecord");
		ModelAndView savedRecordsModelAndView = new ModelAndView("savedRecords");
		Map<String, String> domainList = new LinkedHashMap<String, String>();
		// domainList.put(RefDataPropertiesConstants.DOMAIN_CODE_SCOTS,
		// RefDataPropertiesConstants.DOMAIN_CODE_SCOTS);
		domainList.put(
				RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
				RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES);

		savedRecordsModelAndView.addObject("domainList", domainList);
		if (domainName != null && !domainName.trim().isEmpty()) {
			Map<String, List<SavedRecord>> queueMap = scotsWsProxy
					.retrieveSavedRecordsByDomainName(domainName);
			if (!queueMap.isEmpty() || queueMap != null) {
				List<SavedRecord> savedRecordList = getSavedRecordsFromLinkedMap(queueMap
						.get(domainName).iterator());
				savedRecordsModelAndView.addObject("savedRecordList",
						savedRecordList);
			}
		}
		savedRecordsModelAndView.addObject("domainName", domainName);
		LOGGER.info("exiting WorkQueueController | getSavedRecord");
		return savedRecordsModelAndView;
	}

	/**
	 * 
	 * The method will serve the home page of workqueue.
	 * 
	 * @param model
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "/savedRecordDetail.form", method = RequestMethod.GET)
	public ModelAndView getSavedRecordDetail(
			@RequestParam("domainName") final String domainName,
			@RequestParam("domainId") final String domainId,
			@RequestParam("changeTypeCode") final String changeTypeCode,
			HttpServletRequest request, HttpSession session, Model model)
					throws ParseException {
		ModelAndView workQueueDetailModelAndView = null;
		WorkQueueVO wqVO = getWorkQueueParams(request);
		// Redirecting to separate Saved Record detail pages depending on domain
		// names.
		if (RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE.equals(wqVO
				.getDomainName())) {
			workQueueDetailModelAndView = new ModelAndView("workQueueDetail");
			if (!Long
					.valueOf(
							RefDataChangeTypeConstants.CHANGE_TYPE_BULK_UPLOAD_GEOGRAPHY)
					.equals(wqVO.getChangeType())) {
				prepareGeoWorkQueueDetails(workQueueDetailModelAndView, model,
						wqVO);
			}
		}
		return workQueueDetailModelAndView;
	}

	/**
	 * 
	 * The method to transform the list of LinkedHashMap to the list of
	 * savedRecords. The JSON will return the list as LinkedHashMap.
	 * 
	 * @param itr
	 * @return savedRecords
	 */
	@SuppressWarnings("rawtypes")
	private List<SavedRecord> getSavedRecordsFromLinkedMap(Iterator itr) {
		List<SavedRecord> savedRecords = new ArrayList<SavedRecord>();

		while (itr.hasNext()) {
			LinkedHashMap assn = (LinkedHashMap) itr.next();
			SavedRecord savedRecord = new SavedRecord();
			savedRecord.setSavedRecordId(Long.valueOf((Integer) assn
					.get("savedRecordId")));
			savedRecord.setUserId((String) assn.get("userId"));
			savedRecord
			.setDomainId(Long.valueOf((Integer) assn.get("domainId")));
			savedRecord.setDomainName((String) assn.get("domainName"));
			savedRecord.setChangeTypeCode(Long.valueOf((Integer) assn
					.get("changeTypeCode")));
			savedRecord.setUserComment((String) assn.get("userComment"));
			DateFormat df = new SimpleDateFormat(
					RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT);
			try {
				Object createdDtObj = assn.get("createdDate");
				if (createdDtObj instanceof String) {
					savedRecord.setCreatedDate(((String) assn
							.get("createdDate")) != null ? df
									.parse((String) assn.get("createdDate")) : null);
				} else if (createdDtObj instanceof Long) {
					savedRecord
					.setCreatedDate(((Long) assn.get("createdDate")) != null ? new Date(
							(Long) assn.get("createdDate")) : null);
				}
			} catch (ParseException e) {
				LOGGER.error("Parse Exception occurred : ", e);
				
			}
			savedRecord.setChangeType(getChangeTypeDescription(savedRecord
					.getChangeTypeCode()));
			savedRecords.add(savedRecord);
		}

		return savedRecords;
	}

	/**
	 * the method to set the change type description
	 * 
	 * @param changeTypeCode
	 * @return
	 */
	private String getChangeTypeDescription(Long changeTypeCode) {
		switch (changeTypeCode.intValue()) {
		case 701:
			return "MANAGE FINANCIAL TEMPLATE";
		default:
			return new String("Invalid type");
		}
	}

	/**
	 * 
	 * The method will remove the withdrwan requests.
	 * 
	 * @param model
	 * @return
	 * @throws IOException 
	 * @throws ParseException
	 */
		
	@RequestMapping(value = "/withdrawRequest.form", method = RequestMethod.GET)
	public @ResponseBody
	String withdrawRequest(
			@RequestParam("trackingIds[]") String trackingIds,
			@RequestParam("domainName") String domainName,
			@RequestParam("domainId[]") String domainId,
			@RequestParam("changeTypeCode[]") String changeTypeCode,HttpSession session) throws IOException {
		
		LOGGER.info("Entering WorkqueueController | withdrawRequest | trackingIds::"+trackingIds);


		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);		
		String host= refdataConfig.getValue(RefDataPropertiesConstants.REFDATA_MAIL_HOST);
		String receiver=refdataConfig.getValue(RefDataPropertiesConstants.REFDATA_MAIL_BOT);
		String from=refdataConfig.getValue(RefDataPropertiesConstants.REFDATA_MAIL_FROM);		
		String body="Tracking_ID :"+trackingIds+"\n";
		String result=RefDataPropertiesConstants.REFDATA_WITHDRAW_ALERT;
		
		body=body +"Submitter_ID :"+userContextVO.getUserIdentifier()+"\n";
		body=body+"DomainName :"+domainName+"\n";
		body=body+"Domain_ID:"+domainId+"\n";
		body=body+"ChangeTypeCode:"+changeTypeCode;


		Properties properties = System.getProperties();  
		properties.setProperty(RefDataPropertiesConstants.REFDATA_MAIL_SMTP_HOST, host);  
		properties.setProperty(RefDataPropertiesConstants.REFDATA_MAIL_SMTP_PORT, RefDataPropertiesConstants.REFDATA_MAIL_SMTP_PORT_NO);
		properties.setProperty(RefDataPropertiesConstants.REFDATA_MAIL_SMTP_SOCKET ,RefDataPropertiesConstants.REFDATA_MAIL_SMTP_PORT_NO);
		Session mailSession = Session.getDefaultInstance(properties);
		
		try{  
			MimeMessage message = new MimeMessage(mailSession); 
			BodyPart messageBodyPart = new MimeBodyPart();
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO,new InternetAddress(receiver));  
			message.setSubject(RefDataPropertiesConstants.REFDATA_MAIL_SUBJECT);  
			message.setText(body);     
			Transport.send(message);
		}catch (MessagingException mex) {
			
		LOGGER.info("Error in  WorkqueueController ::"+mex);
		return null;
		
		}  
		
		LOGGER.info("Exiting WorkqueueController | withdrawRequest | trackingIds::"+trackingIds);
		return result;
	}
	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = "/bulkTemplate.form", method = RequestMethod.GET)
	public ModelAndView bulkTemplate(HttpSession session,
			HttpServletRequest request) throws ParseException {
				
		ModelAndView bulkTemplate=new ModelAndView("bulkTemplate");
		
		return bulkTemplate;
		
		
		
	}

}
