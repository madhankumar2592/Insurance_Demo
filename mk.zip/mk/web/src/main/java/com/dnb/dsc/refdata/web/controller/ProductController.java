package com.dnb.dsc.refdata.web.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.Product;
import com.dnb.dsc.refdata.core.vo.AddNewProductsVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ProductMetaData;
import com.dnb.dsc.refdata.core.vo.ProductResources;
import com.dnb.dsc.refdata.core.vo.ProductScoreMappingVO;
import com.dnb.dsc.refdata.core.vo.ProductScoreReportVO;
import com.dnb.dsc.refdata.core.vo.ProductSearchVO;
import com.dnb.dsc.refdata.core.vo.ProductVO;
import com.dnb.dsc.refdata.core.vo.ResourceMetadataVO;
import com.dnb.dsc.refdata.core.vo.SalesMetadataVO;
import com.dnb.dsc.refdata.core.vo.ScoreMappingListVO;
import com.dnb.dsc.refdata.core.vo.ScoreVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;
import com.dnb.dsc.refdata.web.proxy.ProductWebServiceProxy;
import com.dnb.dsc.refdata.web.proxy.ScoreWebServiceProxy;
import com.dnb.dsc.refdata.web.util.ProductSearchExportToExcel;

@Controller
public class ProductController {
	@Autowired
	private HomeController homeController;

	@Autowired
	private GeographyWebServiceProxy geoWsProxy;

	@Autowired
	private ProductWebServiceProxy productProxy;

	@Autowired
	private ScoreWebServiceProxy scoreProxy;

	/**
	 * The constant for the searchSERScoreColumns - Search Code Value page
	 */
	private final String[] productSearchColumns = { "prodId", "prodCd",
			"prodCodeDesc", "prodDtlMtdtCd", "prodDtlMtdtCdDesc",
			"prodDtlMtdCdVal", "prodGrpCd", "prodGrpCdDesc", "prodVers",
			"rescCd", "rescCodeDesc", "bilgSysCd", "rescDtlMtdtCd",
			"rescDtlMtdtCdDesc", "rescMtdtVal", "rescGrpCd", "rescGrpCdDesc",
			"rescVers", "countryCode", "countryDesc", "mktGrpCd",
			"mktGrpCdDesc", "slsChnlDtlMtdtCd", "slsChnlDtlMtdtVal",
			"slsChnlDtlMtdtCdDesc", "prodAvailId", "saleChnlid", "prodMktId",
			"rescMapId", "rescId", "prodGrpId", "prodDtlId", "mktGrpId",
			"rescGrpId", "rescDtlID", "slsChnlDtlID" };

	private final String[] productScrReportsColumns = { "scr_id",
			"scoreTypeCode", "scr_typ_cd_val_d", "scr_vers", "scr_mkt_cd_id",
			"country_name", "scoreGranularity", "scr_gru_cd_val_d", "prodId",
			"prodCd", "prodCodeDesc", "prodDtlMtdtCd", "prodDtlMtdtCdDesc",
			"prodDtlMtdCdVal", "prodGrpCd", "prodGrpCdDesc", "prodVers",
			"rescCd", "rescCodeDesc", "bilgSysCd", "rescDtlMtdtCd",
			"rescDtlMtdtCdDesc", "rescMtdtVal", "rescGrpCd", "rescGrpCdDesc",
			"rescVers", "countryCode", "countryDesc", "mktGrpCd",
			"mktGrpCdDesc", "slsChnlDtlMtdtCd", "slsChnlDtlMtdtVal",
			"slsChnlDtlMtdtCdDesc", "prodAvailId", "saleChnlid", "prodMktId",
			"rescMapId", "rescId", "prodGrpId", "prodDtlId", "mktGrpId",
			"rescGrpId", "rescDtlID", "slsChnlDtlID" };

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ProductController.class);

	@RequestMapping(value = "/productSearchHome.form", method = RequestMethod.GET)
	public ModelAndView productSearchHome(Model model, HttpSession session) {
		LOGGER.info("entering ProductController | productSearchHome");
		ModelAndView productSearchHome = new ModelAndView("productSearch");

		ProductSearchVO productSearchVO = new ProductSearchVO();
		ProductVO productVO = new ProductVO();
		List<CodeValue> productTypeValueMap = productProxy
				.retrieveProductTypeCodeValues(productVO);

		List<CodeValue> resourceTypeValueMap = productProxy
				.retrieveResourceTypeCodeValues(productVO);

		productSearchHome.addObject("productTypCode", productTypeValueMap);
		productSearchHome.addObject("resourceTypCode", resourceTypeValueMap);
		productSearchHome.addObject(
				RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION,
				getCountryList());

		model.addAttribute("productSearch", productSearchVO);

		return productSearchHome;

	}

	private List<CodeValueVO> getCountryList() {
		return this.geoWsProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
	}

	@RequestMapping(value = "/productSearchAjaxResult.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getProductSearchAjaxResult(HttpServletRequest request,
			HttpSession session) throws Exception {
		LOGGER.info("entering ProductController | getProductSearchAjaxResult");

		String searchString = homeController.getSearchString(request);

		if (searchString == null || searchString.trim().isEmpty()) {
			return homeController.getJsonMap(request,
					new ArrayList<ProductScoreReportVO>(), 0L,
					productSearchColumns);
		}
		ProductSearchVO productSearchVO = getProductSearchCrteria(request);

		Long countScoreResults = (Long) session
				.getAttribute("countScotsCodeValueResults");
		if (countScoreResults == null || productSearchVO.getRowIndex() == 0) {
			countScoreResults = productProxy
					.countOfProductSearch(productSearchVO);
			session.setAttribute("countScotsCodeValueResults",
					countScoreResults);
		}
		LOGGER.info("exiting ProductController | getProductSearchAjaxResult");

		return homeController.getJsonMap(request,
				productProxy.SearchProduct(productSearchVO), countScoreResults,
				productSearchColumns);
	}

	private ProductSearchVO getProductSearchCrteria(HttpServletRequest request) {
		ProductSearchVO productSearchVO = new ProductSearchVO();
		productSearchVO.setSortOrder(homeController.getSortOrder(request));
		productSearchVO.setSortBy(homeController.getSortBy(request,
				productSearchColumns));
		productSearchVO.setMaxResults(homeController.getMaxResults(request));
		productSearchVO.setRowIndex(homeController.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);
		// Search string will be in the format
		// CodeDesc#~radioBtnName#~LangCode
		String searchCriteriaDelimiter = "#~";
		if (compositeSearchString != null) {
			String[] splitCriteria = compositeSearchString
					.split(searchCriteriaDelimiter);
			if (splitCriteria.length >= 3) {
				productSearchVO.setProduct_cd(splitCriteria[0]);
				productSearchVO.setMkt_cd(splitCriteria[1]);
				productSearchVO.setResc_cd(splitCriteria[2]);

			} else {
				productSearchVO.setProduct_cd(splitCriteria[0]);
				productSearchVO.setMkt_cd(splitCriteria[1]);
			}
		}

		LOGGER.info("exiting ProductController | getProductSearchCrteria "
				+ "| searchCriteriaVO : " + productSearchVO);
		return productSearchVO;

	}

	@RequestMapping(value = "/productSearchSubmit.form", method = RequestMethod.POST)
	public void getProductSearchExportToExcelResults(
			@ModelAttribute("productSearch") ProductSearchVO productSearchVO,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) {
		LOGGER.info("entering ProductController | getProductSearchExportToExcelResults");
		ProductSearchVO searchCriteriaVO = productSearchVO;
		ProductSearchExportToExcel productSearchExportToExcel = null;
		productSearchExportToExcel = new ProductSearchExportToExcel("");
		try {
			productSearchExportToExcel.insertProductSearchData(productProxy
					.SearchProduct(searchCriteriaVO));
		} catch (Exception e1) {
			LOGGER.error("problem in getProductSearchExportToExcelResults List |"
					+ e1.getMessage());
		}
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();
		String dateAppend = new SimpleDateFormat("MMddyyyyHHmmss")
				.format(new Date());
		response.setContentType("application/xlsx");
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ "Ent_Ref_data_SearchResultProd_" + loggedInUser + ""
				+ dateAppend + ".xlsx" + "\"");
		try {
			productSearchExportToExcel.write(response.getOutputStream());
		} catch (IOException e) {
			LOGGER.error("problem in ProductController |", e);
		}

	}

	@RequestMapping(value = "/addNewProductHome.form", method = RequestMethod.GET)
	public ModelAndView AddNewProductHome(Model model, HttpSession session,Boolean addProductSuccess) {
		LOGGER.info("entering ProductController | AddProductsHome");
		ModelAndView addNewProductsHome = new ModelAndView("addNewProducts");

		
		// For Two values - Start

		List<Integer> codeTableIdVal = new ArrayList<Integer>();
		codeTableIdVal.add(0);
		codeTableIdVal.add(307);
		List<CodeValue> tempCodeValueMapsVal = homeController
				.retrieveCodeValuesScores(codeTableIdVal);

		// For Two Values - End

		// retrieveMktGrpCodes -- starts

		List<CodeValue> tempCodeValueMapsValues = homeController
				.retrieveMktGrpCodes();

		// retrieveMktGrpCodes -- ends

		List<Integer> codeTableId = new ArrayList<Integer>();

		codeTableId.add(0);
		codeTableId.add(307);
		codeTableId.add(129);

		Map<String, List<CodeValue>> tempCodeValueMaps = homeController
				.retrieveCodeValues(codeTableId);

		List<Integer> codeTableIds = new ArrayList<Integer>();

		codeTableIds.add(716);// Product - Resource
		codeTableIds.add(715);// Product
		codeTableIds.add(717);// Metadata code

		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValuesScr(codeTableIds);
		addNewProductsHome.addObject("productCode",
				tempCodeValueMap.get(String.valueOf(715)));
		addNewProductsHome.addObject("productFamilyCode",
				tempCodeValueMap.get(String.valueOf(715)));
		
		addNewProductsHome.addObject("productGroupCode",
				tempCodeValueMaps.get(String.valueOf(0)));

		addNewProductsHome.addObject("productMetadataCode",
				tempCodeValueMap.get(String.valueOf(717)));
		addNewProductsHome.addObject("resourceCode",
				tempCodeValueMap.get(String.valueOf(716)));
		

		addNewProductsHome.addObject("resourceType",
				tempCodeValueMaps.get(String.valueOf(0)));

		
		addNewProductsHome.addObject("billingSysCode",
				tempCodeValueMaps.get(String.valueOf(0)));

		addNewProductsHome.addObject("billingSysType",
				tempCodeValueMap.get(String.valueOf(716)));
		addNewProductsHome.addObject("resourceMetadataCode",
				tempCodeValueMap.get(String.valueOf(717)));
		
		addNewProductsHome.addObject("resourceGroupCode",
				tempCodeValueMaps.get(String.valueOf(0)));

		
		addNewProductsHome.addObject("salesChannelCode", tempCodeValueMapsVal);

		addNewProductsHome.addObject("salesMetadataCode",
				tempCodeValueMap.get(String.valueOf(717)));
		

		addNewProductsHome
				.addObject("marketGroupCode", tempCodeValueMapsValues);

		addNewProductsHome.addObject("allCountries", getCountryList());
		addNewProductsHome.addObject("addProductSuccess",addProductSuccess);
		
		AddNewProductsVO addNewProductsVO = new AddNewProductsVO();
		model.addAttribute("resources",
				populateEmptyDescriptionMappingRows(addNewProductsVO));

		return addNewProductsHome;
	}

	public AddNewProductsVO populateEmptyDescriptionMappingRows(
			AddNewProductsVO addNewProductsVO) {
		if (isEmptyGranularityList(addNewProductsVO)) {

			ProductResources emptyProductMetadata = new ProductResources();
			List<ProductResources> productMetaDataList = new ArrayList<ProductResources>();
			productMetaDataList.add(emptyProductMetadata);
			addNewProductsVO.setProductResources(productMetaDataList);

			if (isEmptyResourceMetadataList(emptyProductMetadata)) {
				ResourceMetadataVO emptyResrcMetadata = new ResourceMetadataVO();
				List<ResourceMetadataVO> resrcMetadataList = new ArrayList<ResourceMetadataVO>();
				resrcMetadataList.add(emptyResrcMetadata);
				emptyProductMetadata.setResourceMetadata(resrcMetadataList);
			}

		}
		if (isEmptyProductMetaDataList(addNewProductsVO)) {
			ProductMetaData emptyProductMetadata = new ProductMetaData();
			List<ProductMetaData> productMetaDataList = new ArrayList<ProductMetaData>();
			productMetaDataList.add(emptyProductMetadata);
			addNewProductsVO.setProductMetaData(productMetaDataList);
		}
		if (isEmptySalesMetadata(addNewProductsVO)) {
			SalesMetadataVO emptySalesMetadata = new SalesMetadataVO();
			List<SalesMetadataVO> salesMetadataList = new ArrayList<SalesMetadataVO>();
			salesMetadataList.add(emptySalesMetadata);
			addNewProductsVO.setSalesMetadata(salesMetadataList);
		}

		return addNewProductsVO;
	}

	private boolean isEmptyResourceMetadataList(ProductResources prodctResources) {
		if (prodctResources.getResourceMetadata() == null
				|| (prodctResources.getResourceMetadata() != null && prodctResources
						.getResourceMetadata().isEmpty())) {
			return true;
		}

		return false;
	}

	private boolean isEmptySalesMetadata(AddNewProductsVO addNewProductsVO) {
		if (addNewProductsVO.getSalesMetadata() == null
				|| (addNewProductsVO.getSalesMetadata() != null && addNewProductsVO
						.getSalesMetadata().isEmpty())) {
			return true;
		}

		return false;
	}

	
	private boolean isEmptyProductMetaDataList(AddNewProductsVO addNewProductsVO) {
		if (addNewProductsVO.getProductMetaData() == null
				|| (addNewProductsVO.getProductMetaData() != null && addNewProductsVO
						.getProductMetaData().isEmpty())) {
			return true;
		}
		return false;
	}

	public boolean isEmptyGranularityList(AddNewProductsVO addNewProductsVO) {
		if (addNewProductsVO.getProductResources() == null
				|| (addNewProductsVO.getProductResources() != null && addNewProductsVO
						.getProductResources().isEmpty())) {
			return true;
		} else {
			return false;
		}
	}

	@RequestMapping(value = "/insertNewProductValue.form", method = RequestMethod.POST)
	public ModelAndView InsertNewProductValue(
			@ModelAttribute("addNewProducts") AddNewProductsVO addNewProductsVO,
			BindingResult result, Model model, HttpSession session,
			HttpServletRequest request,Boolean addProductSuccess) {
		try {
			LOGGER.info("entering ProductController | InsertProductValueHome");
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			String loggedInUser = userContextVO.getUserIdentifier();
			populateNewProductsMandatoryFields(addNewProductsVO, loggedInUser);

			session.removeAttribute("tempCodeValueMap");
			Long updatedScoreTypeCode = productProxy
					.updateNewProducts(addNewProductsVO);

			LOGGER.info("ProductController | addNewProductHome | inserting addNewProductsVO : "
					+ updatedScoreTypeCode);

			LOGGER.info("exiting ProductController | ScoreGranMappingHome");
		} catch (Exception e) {
			LOGGER.error("ProductController | ScoreGranMappingHome", e);
		}
		addProductSuccess = true;
		return AddNewProductHome(model, session,addProductSuccess);
	}

	private void populateNewProductsMandatoryFields(
			AddNewProductsVO addNewProductsVO, String loggedInUser) {
		LOGGER.info("entering ProductController | populateNewProductsMandatoryFields");
		addNewProductsVO.setCreatedDate(new Date());
		addNewProductsVO.setCreatedUser(loggedInUser);
		addNewProductsVO.setModifiedDate(new Date());
		addNewProductsVO.setModifiedUser(loggedInUser);

		if (addNewProductsVO.getProductResources() != null) {
			for (ProductResources productResources : addNewProductsVO
					.getProductResources()) {
				productResources.setCreatedDate(new Date());
				productResources.setCreatedUser(loggedInUser);
				productResources.setModifiedDate(new Date());
				productResources.setModifiedUser(loggedInUser);
			}
		}

		LOGGER.info("exiting ProductController | populateNewProductsMandatoryFields");

	}

	@RequestMapping(value = "/editProductSearch.form", method = RequestMethod.GET)
	public ModelAndView editProductSearch(
			@RequestParam("prdID") final Long prdID,
			@RequestParam("prodAvailId") final Long prodAvailId,
			@RequestParam("saleChnlid") final Long saleChnlid,
			@RequestParam("prodMktId") final Long prodMktId,
			@RequestParam("rescMapId") final Long rescMapId,
			@RequestParam("rescId") final Long rescId,
			@RequestParam("prodGrpId") final Long prodGrpId,
			@RequestParam("prodDtlId") final Long prodDtlId,
			@RequestParam("mktGrpId") final Long mktGrpId,
			@RequestParam("rescGrpId") final Long rescGrpId,
			@RequestParam("rescDtlID") final Long rescDtlID,
			@RequestParam("slsChnlDtlID") final Long slsChnlDtlID, Model model,
			HttpSession session) {
		ModelAndView addNewProductsHome = new ModelAndView("productSearchView");

		ProductSearchVO productSearchVO = new ProductSearchVO();
		productSearchVO.setProdId(prdID);
		productSearchVO.setProdAvailId(prodAvailId);
		productSearchVO.setSaleChnlid(saleChnlid);
		productSearchVO.setProdMktId(prodMktId);
		productSearchVO.setRescMapId(rescMapId);
		productSearchVO.setRescId(rescId);
		productSearchVO.setProdGrpId(prodGrpId);
		productSearchVO.setProdDtlId(prodDtlId);
		productSearchVO.setMktGrpId(mktGrpId);
		productSearchVO.setRescGrpId(rescGrpId);
		productSearchVO.setRescDtlID(rescDtlID);
		productSearchVO.setSlsChnlDtlID(slsChnlDtlID);

		AddNewProductsVO addNewProductsVO = productProxy
				.retrieveProductDetails(productSearchVO);
		// For Two values - Start

		List<Integer> codeTableIdVal = new ArrayList<Integer>();
		codeTableIdVal.add(0);
		codeTableIdVal.add(307);
		List<CodeValue> tempCodeValueMapsVal = homeController
				.retrieveCodeValuesScores(codeTableIdVal);

		// For Two Values - End

		// retrieveMktGrpCodes -- starts

		List<CodeValue> tempCodeValueMapsValues = homeController
				.retrieveMktGrpCodes();

		// retrieveMktGrpCodes -- ends

		List<Integer> codeTableId = new ArrayList<Integer>();

		codeTableId.add(0);
		codeTableId.add(307);
		codeTableId.add(129);

		Map<String, List<CodeValue>> tempCodeValueMaps = homeController
				.retrieveCodeValues(codeTableId);

		List<Integer> codeTableIds = new ArrayList<Integer>();

		codeTableIds.add(716);// Product - Resource
		codeTableIds.add(715);// Product
		codeTableIds.add(717);// Metadata code

		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValues(codeTableIds);
		addNewProductsHome.addObject("productCode",
				tempCodeValueMap.get(String.valueOf(715)));
		addNewProductsHome.addObject("productFamilyCode",
				tempCodeValueMap.get(String.valueOf(715)));
		/*
		 * addNewProductsHome.addObject("productGroupCode",
		 * tempCodeValueMap.get(String.valueOf(715)));
		 */

		addNewProductsHome.addObject("productGroupCode",
				tempCodeValueMaps.get(String.valueOf(0)));

		addNewProductsHome.addObject("productMetadataCode",
				tempCodeValueMap.get(String.valueOf(717)));
		addNewProductsHome.addObject("resourceCode",
				tempCodeValueMap.get(String.valueOf(716)));
		

		addNewProductsHome.addObject("resourceType",
				tempCodeValueMaps.get(String.valueOf(0)));

		
		addNewProductsHome.addObject("billingSysCode",
				tempCodeValueMaps.get(String.valueOf(0)));

		addNewProductsHome.addObject("billingSysType",
				tempCodeValueMap.get(String.valueOf(716)));
		addNewProductsHome.addObject("resourceMetadataCode",
				tempCodeValueMap.get(String.valueOf(717)));
		
		addNewProductsHome.addObject("resourceGroupCode",
				tempCodeValueMaps.get(String.valueOf(0)));

		

		addNewProductsHome.addObject("salesChannelCode", tempCodeValueMapsVal);

		addNewProductsHome.addObject("salesMetadataCode",
				tempCodeValueMap.get(String.valueOf(717)));
		

		addNewProductsHome
				.addObject("marketGroupCode", tempCodeValueMapsValues);

		addNewProductsHome.addObject("allCountries", getCountryList());
		List<Long> prodMktIdListFromDB = productProxy.retrieveProductMarketDetails(prodAvailId);
		addNewProductsVO.setProdId(prdID);
		addNewProductsVO.setProdAvailId(prodAvailId);
		addNewProductsVO.setSaleChnlid(saleChnlid);
		addNewProductsVO.setProdMktId(prodMktId);		
		addNewProductsVO.setRescMapId(rescMapId);
		addNewProductsVO.setRescId(rescId);
		addNewProductsVO.setProdGrpId(prodGrpId);
		addNewProductsVO.setProdDtlId(prodDtlId);
		addNewProductsVO.setMktGrpId(mktGrpId);
		addNewProductsVO.setRescGrpId(rescGrpId);
		addNewProductsVO.setRescDtlID(rescDtlID);
		addNewProductsVO.setSlsChnlDtlID(slsChnlDtlID);
		addNewProductsHome
		.addObject("prodmktList", prodMktIdListFromDB.toString()); //123,123,123
		model.addAttribute("resources", addNewProductsVO);		
		return addNewProductsHome;

	}

	@RequestMapping(value = "/editProductValue.form", method = RequestMethod.POST)
	public ModelAndView editProductValue(
			@ModelAttribute("resources") AddNewProductsVO addNewProductsVO,
			BindingResult result, Model model, HttpSession session,
			HttpServletRequest request) {
		try {
			LOGGER.info("entering ProductController | editProductValue");
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			String loggedInUser = userContextVO.getUserIdentifier();
			populateNewProductsMandatoryFields(addNewProductsVO, loggedInUser);

			session.removeAttribute("tempCodeValueMap");
			Long updatedScoreTypeCode = productProxy
					.editProducts(addNewProductsVO);

			LOGGER.info("ProductController | addNewProductHome | editing addNewProductsVO : "
					+ updatedScoreTypeCode);

			LOGGER.info("exiting ProductController | editProductValue");
		} catch (Exception e) {
			LOGGER.error("exiting ProductController | editProductValue",e);
		}
		return productSearchHome(model, session);
	}

	@RequestMapping(value = "/productScoreRpt.form", method = RequestMethod.GET)
	public ModelAndView productScoreRpt(Model model, HttpSession session) {
		LOGGER.info("entering ProductController | productScoreRpt");
		ModelAndView productScoreRpt = new ModelAndView("productScoreReport");

		ProductScoreReportVO productScoreReportVO = new ProductScoreReportVO();

		ProductVO productVO = new ProductVO();
		List<CodeValue> productTypeValueMap = productProxy
				.retrieveProductTypeCodeValues(productVO);
		List<CodeValue> resourceTypeValueMap = productProxy
				.retrieveResourceTypeCodeValues(productVO);

		ScoreVO scoreVO = new ScoreVO();
		List<CodeValue> scoreTypeValueMap = scoreProxy
				.retrieveScoreTypeCodeValues(scoreVO);
		List<CodeValue> granularityTypeValueMap = scoreProxy
				.retrieveGruTypeCodeValues(scoreVO);

		productScoreRpt.addObject("productTypCode", productTypeValueMap);
		productScoreRpt.addObject("resourceTypCode", resourceTypeValueMap);
		productScoreRpt.addObject(
				RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION,
				getCountryList());
		productScoreRpt.addObject("scoreTypCode", scoreTypeValueMap);
		productScoreRpt.addObject("granularTypCode", granularityTypeValueMap);

		model.addAttribute("productScrReport", productScoreReportVO);

		return productScoreRpt;
	}

	@RequestMapping(value = "/productScrReportAjaxResult.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getProductScrReportAjaxResult(
			HttpServletRequest request, HttpSession session) throws Exception {
		LOGGER.info("entering ProductController | getProductScrReportAjaxResult");

		String searchString = homeController.getSearchString(request);

		if (searchString == null || searchString.trim().isEmpty()) {
			return homeController.getJsonMap(request,
					new ArrayList<ProductScoreReportVO>(), 0L,
					productScrReportsColumns);
		}
		ProductScoreReportVO productScoreReportVO = getProductScrReportCrteria(request);

		Long countScoreResults = (Long) session
				.getAttribute("countScotsCodeValueResults");
		if (countScoreResults == null
				|| productScoreReportVO.getRowIndex() == 0) {
			countScoreResults = productProxy
					.countOfProductScrRpt(productScoreReportVO);
			session.setAttribute("countScotsCodeValueResults",
					countScoreResults);
		}
		LOGGER.info("exiting ProductController | getProductScrReportAjaxResult");

		return homeController.getJsonMap(request,
				productProxy.productScrReport(productScoreReportVO),
				countScoreResults, productScrReportsColumns);
	}

	private ProductScoreReportVO getProductScrReportCrteria(
			HttpServletRequest request) {
		ProductScoreReportVO productScoreReportVO = new ProductScoreReportVO();
		productScoreReportVO.setSortOrder(homeController.getSortOrder(request));
		productScoreReportVO.setSortBy(homeController.getSortBy(request,
				productSearchColumns));
		productScoreReportVO.setMaxResults(homeController
				.getMaxResults(request));
		productScoreReportVO.setRowIndex(homeController.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);
		// Search string will be in the format
		// CodeDesc#~radioBtnName#~LangCode
		String searchCriteriaDelimiter = "#~";
		if (compositeSearchString != null) {
			String[] splitCriteria = compositeSearchString
					.split(searchCriteriaDelimiter);
			if (("1").equalsIgnoreCase(splitCriteria[0])) {
				if (splitCriteria.length >= 7) {
					productScoreReportVO.setMkt_cd_scr(splitCriteria[1]);
					productScoreReportVO.setSr_typ_cd(splitCriteria[2]);
					productScoreReportVO.setSr_gru_cd(splitCriteria[3]);
					productScoreReportVO.setProduct_cd(splitCriteria[4]);
					productScoreReportVO.setMkt_cd(splitCriteria[5]);
					productScoreReportVO.setResc_cd(splitCriteria[6]);

				} else {
					productScoreReportVO.setMkt_cd_scr(splitCriteria[1]);
					productScoreReportVO.setSr_typ_cd(splitCriteria[2]);
					productScoreReportVO.setProduct_cd(splitCriteria[3]);
					productScoreReportVO.setMkt_cd(splitCriteria[4]);
					productScoreReportVO.setResc_cd(splitCriteria[5]);
				}
			} else {
				if (splitCriteria.length >= 6) {
					productScoreReportVO.setMkt_cd_scr(splitCriteria[1]);
					productScoreReportVO.setSr_typ_cd(splitCriteria[2]);
					productScoreReportVO.setSr_gru_cd(splitCriteria[3]);
					productScoreReportVO.setProduct_cd(splitCriteria[4]);
					productScoreReportVO.setMkt_cd(splitCriteria[5]);

				} else {
					productScoreReportVO.setMkt_cd_scr(splitCriteria[1]);
					productScoreReportVO.setSr_typ_cd(splitCriteria[2]);
					productScoreReportVO.setProduct_cd(splitCriteria[3]);
					productScoreReportVO.setMkt_cd(splitCriteria[4]);
				}
			}
		}
		
		LOGGER.info("exiting ProductController | getProductSearchCrteria "
				+ "| searchCriteriaVO : " + productScoreReportVO);
		return productScoreReportVO;

	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/productScoreRptSubmit.form", method = RequestMethod.POST)
	public void getProductScrRptExportToExcelResults(
			@ModelAttribute("productScrReport") ProductScoreReportVO productScoreReportVO,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) {
		LOGGER.info("entering ProductController | getProductScrRptExportToExcelResults");
		ProductScoreReportVO searchCriteriaVO = productScoreReportVO;
		ProductSearchExportToExcel productSearchExportToExcel = null;
		productSearchExportToExcel = new ProductSearchExportToExcel("", "");
		try {
			productSearchExportToExcel
					.insertProductScrRptExportToExcelData(productProxy
							.productScrReport(productScoreReportVO));
		} catch (Exception e1) {
			LOGGER.error("problem in getProductScrRptExportToExcelResults List |"
					+ e1.getMessage());
		}
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();
		String dateAppend = new SimpleDateFormat("MMddyyyyHHmmss")
				.format(new Date());
		response.setContentType("application/xlsx");
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ "Ent_Ref_data_SearchResultRepo_" + loggedInUser + ""
				+ dateAppend + ".xlsx" + "\"");
		try {
			productSearchExportToExcel.write(response.getOutputStream());
		} catch (IOException e) {
			LOGGER.error("problem in ProductController |" + e.getMessage());
		}

	}

	@RequestMapping(value = "/prodScrMap.form")
	public ModelAndView prodScrMap(Model model) {
		ModelAndView scoreGranularityView = new ModelAndView(
				"productScoreMapping");
		ScoreVO scoreVO = new ScoreVO();
		List<CodeValue> tempCodeValueMap = scoreProxy
				.retrieveScoreTypeCodeValues(scoreVO);
		AddNewProductsVO addNewProductsVO = new AddNewProductsVO();
		ProductScoreMappingVO scoreDtl = new ProductScoreMappingVO();
		List<CodeValue> tempCodeValueMapProduct = productProxy
				.retrieveProductCodeValues(addNewProductsVO);
		scoreGranularityView.addObject("scoreTyp", tempCodeValueMap);
		scoreGranularityView.addObject("product", tempCodeValueMapProduct);
		model.addAttribute("score",
				populateEmptyDescriptionMappingRows(scoreDtl));

		return scoreGranularityView;
	}

	private Object populateEmptyDescriptionMappingRows(
			ProductScoreMappingVO productScoreMappingVO) {
		if (isEmptyGranularityList(productScoreMappingVO)) {
			ScoreMappingListVO emptyScoreGranularity = new ScoreMappingListVO();
			List<ScoreMappingListVO> emptyScoreGranularityList = new ArrayList<ScoreMappingListVO>();
			emptyScoreGranularityList.add(emptyScoreGranularity);
			productScoreMappingVO
					.setScoreMappingList(emptyScoreGranularityList);
		}
		productScoreMappingVO.setIsSearch("false");
		return productScoreMappingVO;
	}

	public boolean isEmptyGranularityList(
			ProductScoreMappingVO scoreMappingListVO) {
		if (scoreMappingListVO.getScoreMappingList() == null
				|| (scoreMappingListVO.getScoreMappingList() != null && scoreMappingListVO
						.getScoreMappingList().isEmpty())) {
			return true;
		} else {
			return false;
		}
	}

	@RequestMapping(value = "retrieveGranularityCodes.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveGranularityForScrType(
			@RequestParam(value = "scoreMkt", required = true) Long scoreMkt,
			@RequestParam(value = "scoreType", required = true) Long scoreType,
			@RequestParam(value = "scoreVer", required = true) Double scoreVersion,
			HttpSession session) {
		LOGGER.info("entering ScoreController | retrieveGranularityForScrType");
		LOGGER.info("ScoreController | retrieveGranularityForScrType | "
				+ "scoreType : " + scoreType + " scoreMkt : " + scoreMkt
				+ " scoreVer : " + scoreVersion);
		ScoreVO scoreVO = new ScoreVO();
		scoreVO.setScoreMarketCode(scoreMkt);
		scoreVO.setScoreId(scoreType);
		scoreVO.setScoreTypeId(scoreType);
		scoreVO.setScoreVersion(scoreVersion);
		scoreVO.setIndicator("1");
		List<CodeValue> codeValue = scoreProxy
				.retrieveGranularityForScrType(scoreVO);
		if (!(codeValue.size() > 0)) {
			CodeValue cdVal = new CodeValue();
			cdVal.setIndicator("3");
			codeValue.add(cdVal);
		}
		return codeValue;
	}

	@RequestMapping(value = "retrieveProdFamCode.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveProdFamCode(
			@RequestParam(value = "prodCode", required = true) Long prodCode,
			HttpSession session) {
		LOGGER.info("entering ProductController | retrieveGranularityCodes");

		List<CodeValue> codeValue = productProxy.retrieveProdFamCode(prodCode);

		if (!(codeValue.size() > 0)) {
			List<Product> prodVersion = productProxy.retrieveProdVers(prodCode);
			codeValue = new ArrayList<CodeValue>();
			if ((prodVersion.size() > 0)) {
				for (Product prod : prodVersion) {
					CodeValue cdVal = new CodeValue();
					cdVal.setCodeValueId(prod.getProductVersion());
					cdVal.setIndicator("1");
					codeValue.add(cdVal);
				}
			} else {
				codeValue = productProxy.retrieveResource(prodCode);
				List<CodeValue> codeValueLst = new ArrayList<CodeValue>();
				for (CodeValue cdVals : codeValue) {
					CodeValue cdVal = new CodeValue();
					cdVal.setIndicator("2");
					cdVal.setCodeValueId(cdVals.getCodeValueId());
					cdVal.setCodeValueDescription(cdVals
							.getCodeValueDescription());
					cdVal.setBusinessDescription(cdVals
							.getBusinessDescription());
					codeValueLst.add(cdVal);
				}
				codeValue = codeValueLst;
			}
		}
		if (!(codeValue.size() > 0)) {
			CodeValue cdVal = new CodeValue();
			cdVal.setIndicator("3");
			codeValue.add(cdVal);
		}
		LOGGER.info("exiting ProductController | retrieveGranularityCodes");
		return codeValue;
	}

	@RequestMapping(value = "retrieveFamProdVersion.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveFamProdVersion(
			@RequestParam(value = "prodCode", required = true) Long prodCode,
			@RequestParam(value = "famCode", required = true) Long famCode,
			HttpSession session) {
		LOGGER.info("entering ProductController | retrieveFamProdVersion");
		List<CodeValue> codeValue = new ArrayList<CodeValue>();
		List<Product> productVersion = productProxy.retrieveFamProdVersion(
				famCode, prodCode);
		if (!(productVersion.size() > 0)) {
			codeValue = productProxy.retrieveFamVerResource(famCode, prodCode);
		} else {
			for (Product prod : productVersion) {
				CodeValue cdVal = new CodeValue();
				cdVal.setCodeValueId(prod.getProductVersion());
				cdVal.setIndicator("1");
				codeValue.add(cdVal);
			}
		}
		if (!(codeValue.size() > 0)) {
			CodeValue cdVal = new CodeValue();
			cdVal.setIndicator("3");
			codeValue.add(cdVal);
		}
		LOGGER.info("exiting ProductController | retrieveFamProdVersion");
		return codeValue;
	}

	@RequestMapping(value = "retrieveProdFamVerResource.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveProdFamVerResource(
			@RequestParam(value = "prodCode", required = true) Long prodCode,
			@RequestParam(value = "famCode", required = true) Long famCode,
			@RequestParam(value = "prodVer", required = true) Long prodVer,
			HttpSession session) {
		LOGGER.info("entering ProductController | retrieveProdFamVerResource");
		List<CodeValue> codeValue = productProxy.retrieveProdFamVerResource(
				famCode, prodCode, prodVer);
		if (!(codeValue.size() > 0)) {
			CodeValue cdVal = new CodeValue();
			cdVal.setIndicator("3");
			codeValue.add(cdVal);
		}
		LOGGER.info("exiting ProductController | retrieveProdFamVerResource");
		return codeValue;
	}

	@RequestMapping(value = "/prodScrSubmitToDB.form", method = RequestMethod.POST)
	public ModelAndView prodScrSubmitToDB(
			@ModelAttribute("score") ProductScoreMappingVO productScoreMappingVO,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session) throws ParseException {
		LOGGER.info("entering ProductController | prodScrSubmitToDB | ScoreDtlVO: "
				+ productScoreMappingVO);

		// To remove empty elements - Start
		List<ScoreMappingListVO> prodRescList = productScoreMappingVO
				.getScoreMappingList();		
		List<ScoreMappingListVO> prodRescLst = new ArrayList<ScoreMappingListVO>();
		try {
			if (prodRescList.size() > 0) {
				for (ScoreMappingListVO prodResc : prodRescList) {
					try {
						if (prodResc.getScoreTypeCode() == null) {
							prodRescLst.add(prodResc);
						}
					} catch (Exception e) {
						LOGGER.error("ProductController | prodScrSubmitToDB | ScoreDtlVO:",e);
					}
				}
				prodRescList.removeAll(prodRescLst);
				productScoreMappingVO.setScoreMappingList(prodRescList);
			}
		} catch (Exception e) {
			LOGGER.error("ProductController | prodScrSubmitToDB | ScoreDtlVO:",e);
		}
		// To remove empty elements - End

		LOGGER.info("productScoreMappingVO.getIsSearch():::"+productScoreMappingVO.getIsSearch());

		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();
		productScoreMappingVO.setLoggedInUser(loggedInUser);
		LOGGER.info("ProductController | prodScrSubmitToDB | updating ScoreDtl as: "
				+ productScoreMappingVO);
		ProductScoreMappingVO productScoreMappingVOObject = productProxy
				.updateProdRescScoreGranMapDtl(productScoreMappingVO);
		return prodScrMapSearchResults(model, productScoreMappingVOObject,
				session);

	}

	public ModelAndView prodScrMapSearchResults(Model model,
			ProductScoreMappingVO productScoreMappingVOObject,
			HttpSession session) {

		// To remove empty elements - Start
		List<ScoreMappingListVO> prodRescList = productScoreMappingVOObject
				.getScoreMappingList();
		List<ScoreMappingListVO> prodRescLst = new ArrayList<ScoreMappingListVO>();
		try {
			if (prodRescList.size() > 0) {
				for (ScoreMappingListVO prodResc : prodRescList) {
					try {
						if (prodResc.getScoreTypeCode() == null) {
							prodRescLst.add(prodResc);
						}
					} catch (Exception e) {
						LOGGER.error("ProductController | prodScrMapSearchResults:",e);
					}
				}
				prodRescList.removeAll(prodRescLst);
				productScoreMappingVOObject.setScoreMappingList(prodRescList);
			}
		} catch (Exception e) {
			LOGGER.error("ProductController | prodScrMapSearchResults:",e);
		}
		// To remove empty elements - End

		ModelAndView scoreGranularityView = new ModelAndView(
				"productScoreMappingSearch");
		ScoreVO scoreVO = new ScoreVO();
		List<CodeValue> tempCodeValueMap = scoreProxy
				.retrieveScoreTypeCodeValues(scoreVO);
		AddNewProductsVO addNewProductsVO = new AddNewProductsVO();
		List<CodeValue> tempCodeValueMapProduct = productProxy
				.retrieveProductCodeValues(addNewProductsVO);
		scoreGranularityView.addObject("scoreTyp", tempCodeValueMap);
		scoreGranularityView.addObject("product", tempCodeValueMapProduct);
		scoreGranularityView.addObject("score", productScoreMappingVOObject);
		LOGGER.info("productScoreMappingVOObject.getResourceString()::"+productScoreMappingVOObject.getResourceString());

		// return productScoreRpt(model,session);
		LOGGER.info("productScoreMappingVOObject.getIsSearch()::"+productScoreMappingVOObject.getIsSearch());
		if ("falsePSerch".equalsIgnoreCase(productScoreMappingVOObject
				.getIsSearch())) {
			// return scoreGranularityView;
			return productScoreRpt(model, session);
		} else if ("false".equalsIgnoreCase(productScoreMappingVOObject
				.getIsSearch())) {
			return productScoreRpt(model, session);
		} else {
			return scoreGranularityView;
		}
	}

	@RequestMapping(value = "/editProductScrMapping.form", method = RequestMethod.GET)
	public ModelAndView editProductScrMapping(
			@RequestParam("rescMapId") final Long rescMapId, Model model,
			HttpSession session) {
		ProductScoreMappingVO productScoreMappingVOObject = productProxy
				.retreiveProdRescScoreGranMapDtl(rescMapId);
		productScoreMappingVOObject.setRescMapId(rescMapId);
		return prodScrMapSearchResults(model, productScoreMappingVOObject,
				session);

	}
}
