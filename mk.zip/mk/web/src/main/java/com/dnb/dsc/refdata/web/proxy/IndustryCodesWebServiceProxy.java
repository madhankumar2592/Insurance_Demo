/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.proxy;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.IndusCodeBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.InduscodeMappingBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.IndustryCodesSearchCriteriaVO;
import com.dnb.dsc.refdata.web.util.RestWebServiceUtil;

/**
 * The web service proxy class will handle the mapping between the UI web
 * requests and the respective service end point class.
 * <p>
 * The class will construct the RESTful WS requests and exchange the request
 * with the service end point for the response.
 * <p>
 * 
 * The web service proxy class will handle all the service requests within the
 * Industry Codes domain.
 * <p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Component
public class IndustryCodesWebServiceProxy {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(IndustryCodesWebServiceProxy.class);
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private RefDataConfigUtil refDataConfigUtil; 
	
	@Autowired
	private RestWebServiceUtil restWSUtil;
	
	/**
	 * Retrieves the Industry Code search Results. <p>
	 * The search will be done on the flat db based on the search criteria the user had
	 * provided.<p>
	 * 
	 * @param industryCodesSearchCriteria
	 * @return a list of IndustryCode
	 */
	@SuppressWarnings("unchecked")
	public List<IndustryCode> searchIndustryCodes(
			IndustryCodesSearchCriteriaVO industryCodesSearchCriteria) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | searchIndustryCodes");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/searchIndustryCodes.service";
		HttpEntity<IndustryCodesSearchCriteriaVO> entity = new HttpEntity<IndustryCodesSearchCriteriaVO>(industryCodesSearchCriteria);
		LOGGER.info("exiting IndustryCodesWebServiceProxy | searchIndustryCodes");
		return (List<IndustryCode>) this.restTemplate.postForObject(serviceURL, entity,
				List.class, new Object[0]);
	}
	
	/**
	 * The method will retrieve Industry code CrossWalks for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 * 
	 * @param industryCodeTypeCode
	 * @return list of codeValueVO
	 */
	@SuppressWarnings( "unchecked")
	public List<CodeValueVO> retrieveCrossWalksForIndsCodeType(Long industryCodeTypeCode) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | retrieveCrossWalksForIndsCodeType");
		String serviceURL = "/{industryCodeTypeCode}/retrieveCrossWalksForIndsCodeType.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL, industryCodeTypeCode);
	}
	
	/**
	 * The method will retrieve Industry code and description for the selected
	 * industry code type.
	 * 
	 * @param industryCodeTypeCode
	 * @return list of codeValueVO
	 */
	public String retrieveDescriptionForIndsCodeTypeCode(Long industryCodeTypeCode, String industryCode) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | retrieveDescriptionForIndsCodeTypeCode");
		HttpEntity<String> entity = new HttpEntity<String>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{industryCodeTypeCode}/{industryCode}/retrieveDescriptionForIndsCodeTypeCode.service";
		ResponseEntity<String> result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
				String.class, industryCodeTypeCode, industryCode);
		LOGGER.info("exiting IndustryCodesWebServiceProxy | retrieveDescriptionForIndsCodeTypeCode");
		return result != null ? result.getBody() : null;
	}	
	
	/**
	 * 
	 * TODO
	 *
	 * @param industryCodeTypeCode
	 * @param industryCode
	 * @return
	 */
	public Long retrieveIndustryCodeIdByCodeTypeCode(Long industryCodeTypeCode, String industryCode) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | retrieveIndustryCodeIdByCodeTypeCode");
		HttpEntity<Long> entity = new HttpEntity<Long>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{industryCodeTypeCode}/{industryCode}/retrieveIndustryCodeIdByCodeTypeCode.service";
		ResponseEntity<Long> result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
				Long.class, industryCodeTypeCode, industryCode);
		LOGGER.info("exiting IndustryCodesWebServiceProxy | retrieveDescriptionForIndsCodeTypeCode");
		return result != null ? result.getBody() : null;
	}	
	
	/**
	 * The method will retrieve Industry code Group Levels for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 * 
	 * @param industryCodeTypeCode
	 * @param session
	 * @return list of codeValueVO
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveGroupLevelCodes(Long industryCodeTypeCode, Long languageCode) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | retrieveGroupLevelCodes");
		String serviceURL = "/{industryCodeTypeCode}/{languageCode}/retrieveGroupLevelCodes.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL, industryCodeTypeCode, languageCode);
	}

	/**
	 * 
	 * The method will count the records in the hierarchy search of industry codes on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param currencySearchCriteriaVO
	 * @return countResults
	 */
	public Long countSearchIndustryCodes(IndustryCodesSearchCriteriaVO industryCodesSearchCriteria) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | countSearchIndustryCodes");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/countSearchIndustryCodes.service";
		HttpEntity<IndustryCodesSearchCriteriaVO> entity = new HttpEntity<IndustryCodesSearchCriteriaVO>(
				industryCodesSearchCriteria);
		LOGGER.info("exiting IndustryCodesWebServiceProxy | countSearchIndustryCodes");
		return (Long) this.restTemplate.postForObject(serviceURL, entity,
				Long.class, new Object[0]);
	}
	
	/**
	 * The method will search the Staging SoR for the IndustryCode based on the 
	 * IndustryCodeId and will return the IndustryCode entity.
	 * 
	 * @param industryCodeId
	 * @return IndustryCode
	 */
	public IndustryCode retrieveIndustryCodeByIndustryCodeId(Long industryCodeId) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | retrieveIndustryCodeByIndustryCodeId");

		HttpEntity<IndustryCode> entity = new HttpEntity<IndustryCode>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{industryCodeId}/retrieveIndustryCodeByIndustryCodeId.service";
		ResponseEntity<IndustryCode> result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
				IndustryCode.class, industryCodeId);
		LOGGER.info("exiting IndustryCodesWebServiceProxy | retrieveIndustryCodeByIndustryCodeId");
		return result != null ? result.getBody() : null;
	}
	
	/**
	 * The method will persist the existing IndustryCode data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param GeoUnit
	 * @return update status
	 */
	public Long updateIndustryCode(IndustryCode industryCode) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | updateIndustryCode");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/updateIndustryCode.service";
		HttpEntity<IndustryCode> entity = new HttpEntity<IndustryCode>(industryCode);
		LOGGER.info("exiting IndustryCodesWebServiceProxy | updateIndustryCode");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}
	
	/**
	 * 
	 * The method will fetch the language codes available for the selected
	 * Industry Code Type. The method will be invoked when the user selects the
	 * Industry Code type value.
	 * 
	 * @param industryCodeTypeCode
	 * @param groupLevelCodes
	 * @param session
	 * @return list of codeValueVO
	 */
	@SuppressWarnings({ "unchecked" })
	public List<CodeValueVO> retrieveIndustryCodeLanguages(
			Long industryCodeTypeCode, List<Long> groupLevelCodes) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | retrieveIndustryCodeLanguages");
		
		HttpEntity<List<Long>> entity = new HttpEntity<List<Long>>(groupLevelCodes);
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{industryCodeTypeCode}/retrieveIndustryCodeLanguages.service";
		LOGGER.info("exiting IndustryCodesWebServiceProxy | retrieveIndustryCodeLanguages");
		return restTemplate.postForObject(serviceURL, entity,
				List.class, industryCodeTypeCode);
	}
	
	/**
	 * 
	 * The method to lock the industry code record for edit
	 *
	 * @param industryCodeId
	 * @return isLocked
	 */
	public String lockIndustryCode(Long industryCodeId) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | lockIndustryCode");

		HttpEntity<Boolean> entity = new HttpEntity<Boolean>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{industryCodeId}/lockIndustryCode.service";
		ResponseEntity<String> result = this.restTemplate.exchange(serviceURL, HttpMethod.GET,
					entity, String.class, new Object[] { industryCodeId });
		LOGGER.info("exiting IndustryCodesWebServiceProxy | lockIndustryCode");
		return result != null ? (String) result.getBody() : null;
	}

		/**
		 * The method will be invoked by the when the the business owner reviews the
		 * changes submitted for his approval. The user reviews the changes and he
		 * could approve or reject the request.
		 *
		 * @param trackingId
		 */
		public IndustryCode reviewIndustryCodeChanges(Long domainId) {
			LOGGER.info("entering IndustryCodesWebServiceProxy | reviewIndustryCodeChanges");

			HttpEntity<IndustryCode> entity = new HttpEntity<IndustryCode>(
					restWSUtil.constructRequestHeader());
			String serviceURL = refDataConfigUtil.getServiceDeployURL()
					+ "/{domainId}/reviewIndustryCodeChanges.service";
			ResponseEntity<IndustryCode> result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
					IndustryCode.class, domainId);
			LOGGER.info("exiting IndustryCodesWebServiceProxy | reviewIndustryCodeChanges");
			return result != null ? result.getBody() : null;
	}
	
	/**
	 * The method will down load the IndustryCodes based on the 
	 * IndustryCode type, languages and description length code.
	 * 
	 * @param industryCodeTypeCode,languageCode,descLengthCode
	 * @return 
	 */
	public Boolean industryCodeBulkDownload(IndusCodeBulkDownloadVO indusCodebulkDownloadVO) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | industryCodeBulkDownload");		
		String serviceURL = refDataConfigUtil.getBatchDeployURL()+ "/industryCodeBulkDownload.service";			
		HttpEntity<IndusCodeBulkDownloadVO> entity = new HttpEntity<IndusCodeBulkDownloadVO>(indusCodebulkDownloadVO);		
		LOGGER.info("exiting IndustryCodesWebServiceProxy | industryCodeBulkDownload");
		return restTemplate.postForObject(serviceURL, entity, Boolean.class);
	}
	
	/**
	 * The method will add UiBulkDownload data in the Transactional 
	 * 	 * DB. 
	 * 
	 * @param UiBulkDownload
	 * @return insert status
	 */
	public Long addUIBulkDownload(UiBulkDownload uiBulkDownload) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | addUIBulkDownload");
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/addUIBulkDownload.service";
		HttpEntity<UiBulkDownload> entity = new HttpEntity<UiBulkDownload>(uiBulkDownload);
		LOGGER.info("exiting IndustryCodesWebServiceProxy | addUIBulkDownload");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}
	
	/**
	 * The method will search the Staging SoR for the UiBulkDownload based on the 
	 * userId and will return the UiBulkDownload entity.
	 * 
	 * @param userId
	 * @return UiBulkDownload
	 */
	@SuppressWarnings("unchecked")
	public List<UiBulkDownload> retrieveUIBulkDownload(String  userId) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | retrieveUIBulkDownload");
		HttpEntity<UiBulkDownload> entity = new HttpEntity<UiBulkDownload>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{userId}/retrieveUIBulkDownload.service";
		LOGGER.info("exiting IndustryCodesWebServiceProxy | retrieveUIBulkDownload");
		return (List<UiBulkDownload>)this.restTemplate.postForObject(serviceURL,entity,
				List.class, userId);
	}
	
	/**
	 * 
	 * The method to delete an existing Industry Code. After delete the control
	 * will be navigated to the Submitter view page.
	 * 
	 * @param industryCodeId
	 * @param deletedUser
	 * @return isSuccess
	 */
	public Boolean deleteIndustryCode(Long industryCodeId, String deletedUser) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | deleteIndustryCode");
		HttpEntity<Boolean> entity = new HttpEntity<Boolean>(restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{industryCodeId}/{deletedUser}/deleteIndustryCode.service";
		ResponseEntity<Boolean> result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity, Boolean.class, industryCodeId,
					deletedUser);
		LOGGER.info("exiting IndustryCodesWebServiceProxy | deleteIndustryCode");
		return result != null ? result.getBody() : null;
	}
	/**
	 * 
	 * The method to lock the industry code record for edit
	 *
	 * @param industryCode
	 * @param industryCodeTypeCode
	 * @return isLocked
	 */
	public Boolean isIndustryCodeDescriptionDuplicate(String industryCode,
			Long industryCodeTypeCode, String industryDescription) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | isIndustryCodeDescriptionDuplicate");

		HttpEntity<Boolean> entity = new HttpEntity<Boolean>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{industryCode}/{industryCodeTypeCode}/{industryDescription}/" +
						"countIndustryCodeDescriptionForDuplicate.service";
		ResponseEntity<Boolean> result = restTemplate.exchange(serviceURL, HttpMethod.GET,
					entity, Boolean.class, industryCode, industryCodeTypeCode,industryDescription);
		LOGGER.info("exiting IndustryCodesWebServiceProxy | isIndustryCodeDescriptionDuplicate");
		return result != null ? (Boolean) result.getBody() : null;
	}

	/**
	 * 
	 * The method will retrieve the Industry code data for all the tables given
	 * as parameter from the Staging SoR. The input will be Code Table ID of the
	 * Industry Code Type table. This method will be invoked only for search as
	 * this will fetch only the existing industry code types from inds_code
	 * table.
	 * 
	 * @param indsCodeTableId
	 * @return
	 */
	@SuppressWarnings({ "unchecked" })
	public Map<String, List<CodeValue>> retrieveIndustryCodeValues(Long indsCodeTableId) {
		LOGGER.info("entering IndustryCodesWebServiceProxy | retrieveIndustryCodeValues");

		String queryParams = "/{indsCodeTableId}/retrieveIndustryCodeValues.service";
		HttpEntity<Map<String, List<CodeValue>>> entity = new HttpEntity<Map<String, List<CodeValue>>>(
				restWSUtil.constructRequestHeader());
		Map<String, List<CodeValue>> result = restTemplate.postForObject(restWSUtil.getServiceURL(queryParams),
				entity, Map.class, indsCodeTableId);
		LOGGER.info("exiting IndustryCodesWebServiceProxy | retrieveIndustryCodeValues");
		return result;
	}

	/**
	 * This method will retrieve all the crosswalks available with respective count of each crosswalk
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<InduscodeMappingBulkDownloadVO> retrieveCrosswalkDetails() {
		LOGGER.info("entering IndustryCodesWebServiceProxy | retrieveCrosswalkDetails");
		String serviceURL = "/retrieveCrosswalkDetails.service";
		return restWSUtil.exchangeForList(InduscodeMappingBulkDownloadVO.class, serviceURL);
	}
}
