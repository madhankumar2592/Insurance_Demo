/*
 * Cognizant PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Cognizant Technology Solutions. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */

package com.dnb.dsc.refdata.web.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.dnb.dsc.refdata.core.entity.IndustryCode;

// TODO: Auto-generated Javadoc

/**
 * The Class IndsExportToExcel.
 */
public class IndsExportToExcel extends SXSSFWorkbook {

	/** The inds_code_sheet. */
	private Sheet inds_code_sheet;

	/** The inds cd row count. */
	private Integer indsCdRowCount = 0;

	/** The inds cd desc row count. */
	private Integer indsCdDescRowCount = 0;

	/**
	 * Instantiates a new inds export to excel.
	 *
	 * @param exportType the export type
	 */
	public IndsExportToExcel(String indsDesc) {
		super(300);		
		inds_code_sheet = createSheet("Inds Srch Rslts");
		inds_code_sheet_header(indsDesc);
		
			
		

	}
	public IndsExportToExcel(String fromDesc,String toDesc) {
		super(300);
		
		inds_code_sheet = createSheet("Inds CrsWlk Srch Rslts");
		inds_code_CrossWalk_sheet_header(fromDesc,toDesc);
		

	}

	/**
	 * Inds_code_sheet_header.
	 */
	private void inds_code_sheet_header(String indsDesc) {

		Row indusCdHeader = inds_code_sheet.createRow(0);

		Cell headerCell0 = indusCdHeader.createCell(0);
		headerCell0.setCellValue(indsDesc);
		
		Cell headerCell4 = indusCdHeader.createCell(1);
		headerCell4.setCellValue("Grp Lvl Code");

		Cell headerCell1 = indusCdHeader.createCell(2);
		headerCell1.setCellValue("Description");

		Cell headerCell2 = indusCdHeader.createCell(3);
		headerCell2.setCellValue("Language Code");
		
		Cell headerCell3 = indusCdHeader.createCell(4);
		headerCell3.setCellValue("Desc Length Code");
		
		Cell headerCell5 = indusCdHeader.createCell(5);
		headerCell5.setCellValue("Desc Length Code Description");

	}

	/**
	 * Inds_code_ cross walk_sheet_header.
	 */
	private void inds_code_CrossWalk_sheet_header(String fromDesc,String toDesc) {

		Row indusCdHeader = inds_code_sheet.createRow(0);

		Cell headerCell0 = indusCdHeader.createCell(0);
		headerCell0.setCellValue(fromDesc);

		Cell headerCell1 = indusCdHeader.createCell(1);
		headerCell1.setCellValue("From Description");
		
		Cell headerCell3 = indusCdHeader.createCell(2);
		headerCell3.setCellValue("From Desc Len CD");
		
		Cell headerCell7 = indusCdHeader.createCell(3);
		headerCell7.setCellValue("From Desc Len CD Descrption");

		Cell headerCell4 = indusCdHeader.createCell(4);
		headerCell4.setCellValue(toDesc);
		
		Cell headerCell2 = indusCdHeader.createCell(5);
		headerCell2.setCellValue("To Description");
		
		Cell headerCell5 = indusCdHeader.createCell(6);
		headerCell5.setCellValue("To Desc Len CD");
		
		Cell headerCell8 = indusCdHeader.createCell(7);
		headerCell8.setCellValue("To Desc Len CD Descrption");

		Cell headerCell6 = indusCdHeader.createCell(8);
		headerCell6.setCellValue("Pref Indc");

	}

	/**
	 * Insert inds code data.
	 *
	 * @param indsuCodeList the indsu code list
	 */
	@SuppressWarnings("rawtypes")
	public void insertIndsCodeData(List<IndustryCode> indusCodeList) {
		List<IndustryCode> rows = new ArrayList<IndustryCode>();
		Iterator itr = indusCodeList.iterator();
		while (itr.hasNext()) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			IndustryCode row = new IndustryCode();

			row.setIndustryCode((String) curr.get("industryCode"));
			
			if(curr.get("industryCodeGroupLvelCode")!=null){
				row.setIndustryCodeGroupLvelCode(Long.valueOf(curr.get(
					"industryCodeGroupLvelCode").toString()));
			}
			
			row.setIndustryCodeDescription((String) curr
					.get("industryCodeDescription"));
			row.setLanguageCode(Long.valueOf(curr.get("languageCode")
					.toString()));
			row.setDescLenCD(Long.valueOf(curr.get("descLenCD")
					.toString()));	
			row.setDescLenCdDescription((String)(curr.get("descLenCdDescription")
					.toString()));	
			rows.add(row);
		}
		for (IndustryCode indsCode : rows) {
			indsCdRowCount++;
			Row dataRow = inds_code_sheet.createRow(indsCdRowCount);
			Cell indscell = dataRow.createCell(0);
			indscell.setCellValue(indsCode.getIndustryCode());
			
			Cell indscell4 = dataRow.createCell(1);
			if (indsCode.getIndustryCodeGroupLvelCode() != null) {

				indscell4.setCellValue(indsCode
						.getIndustryCodeGroupLvelCode());
			} else {
				indscell4.setCellValue("");
			}

			Cell indscell1 = dataRow.createCell(2);
			indscell1.setCellValue(indsCode.getIndustryCodeDescription());

			Cell indscell2 = dataRow.createCell(3);
			indscell2.setCellValue(indsCode.getLanguageCode());
			
			Cell indscell3 = dataRow.createCell(4);
			indscell3.setCellValue(indsCode.getDescLenCD());
			
			Cell indscell5 = dataRow.createCell(5);
			indscell5.setCellValue(indsCode.getDescLenCdDescription());

		}

	}

	/**
	 * Insert inds code desc data.
	 *
	 * @param indsuCodeDescList the indsu code desc list
	 */
	@SuppressWarnings("rawtypes")
	public void insertIndsCodeDescData(List<IndustryCode> indusCodeDescList) {
		indsCdDescRowCount++;

		List<IndustryCode> rows = new ArrayList<IndustryCode>();

		Iterator itr = indusCodeDescList.iterator();
		while (itr.hasNext()) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			IndustryCode row = new IndustryCode();

			row.setIndustryCode((String) curr.get("industryCode"));
			
			row.setIndustryCodeDescription((String) curr
					.get("industryCodeDescription"));
			row.setDescLenCD(Long.valueOf(curr.get("descLenCD")
					.toString()));
			row.setDescLenCdDescription((String) curr
					.get("descLenCdDescription").toString());
			row.setToDescLenCD(Long.valueOf(curr.get("toDescLenCD")
					.toString()));
			row.setToDescLenCdDescription((String) curr
					.get("toDescLenCdDescription").toString());
			row.setCrosswalkIndustryCode((String) curr
					.get("crosswalkIndustryCode"));
			row.setCrosswalkIndustryDescription((String) curr
					.get("crosswalkIndustryDescription"));
			row.setPreferredMapIndicator((Integer.valueOf(curr.get(
					"preferredMapIndicator").toString())));

			rows.add(row);
		}
		for (IndustryCode indsCode : rows) {
			indsCdRowCount++;
			Row dataRow = inds_code_sheet.createRow(indsCdRowCount);
			Cell indscell = dataRow.createCell(0);
			indscell.setCellValue(indsCode.getIndustryCode());

			Cell indscell1 = dataRow.createCell(1);
			indscell1.setCellValue(indsCode.getIndustryCodeDescription());
			
			Cell indscell3 = dataRow.createCell(2);
			indscell3.setCellValue(indsCode.getDescLenCD());
			
			Cell indscell7 = dataRow.createCell(3);
			indscell7.setCellValue(indsCode.getDescLenCdDescription());

			Cell indsCrsWlkcell = dataRow.createCell(4);
			indsCrsWlkcell.setCellValue(indsCode.getCrosswalkIndustryCode());

			Cell indsdescell1 = dataRow.createCell(5);
			indsdescell1.setCellValue(indsCode
					.getCrosswalkIndustryDescription());
			
			Cell indsdescell4 = dataRow.createCell(6);
			indsdescell4.setCellValue(indsCode
					.getToDescLenCD());
			
			Cell indscell8 = dataRow.createCell(7);
			indscell8.setCellValue(indsCode.getToDescLenCdDescription());


			Cell indscell2 = dataRow.createCell(8);
			indscell2.setCellValue(indsCode.getPreferredMapIndicator());

		}

	}

}
