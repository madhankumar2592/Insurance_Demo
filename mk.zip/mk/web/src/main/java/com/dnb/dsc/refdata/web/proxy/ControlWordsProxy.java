/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.proxy;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeInferment;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ControlWordsBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.ControlWordsSearchVO;
import com.dnb.dsc.refdata.web.util.RestWebServiceUtil;

/**
 * The web service proxy class will handle the mapping between the UI web
 * requests and the respective service end point class. The class will construct
 * the REST WS requests and exchange the request with the service end point for
 * the response.
 * <p>
 * 
 * The web service proxy class will handle all the service requests within the
 * Control Words domain.
 * <p>
 * 
 * @author Cognizant
 * @version last updated : May 31, 2012
 * @see
 * 
 */
@Component
public class ControlWordsProxy {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ControlWordsProxy.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private RefDataConfigUtil refDataConfigUtil;
	
	@Autowired
	private RestWebServiceUtil restWSUtil;

	/**
	 * 
	 * The method to retrieve all control words
	 *
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueText> retrieveAllControlWords(){
		LOGGER.info("entering ControlWordsProxy | retrieveAllControlWords");
		HttpEntity<CodeValueText> entity = new HttpEntity<CodeValueText>(
				new CodeValueText());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveAllControlWords.service";
		List<CodeValueText> result = null;
		result = (List<CodeValueText>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
		LOGGER.info("exiting ControlWordsProxy | retrieveAllControlWords");
		return result;		
	}
	/**
	 * 
	 * The method to retrieve the control words search results 
	 *
	 * @param controlWordsSearchVO
	 * @return
	 */
	public ControlWordsSearchVO retrieveControlWordsSearchResults(
			ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering ControlWordsProxy | retrieveControlWordsSearchResults");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveControlWordsSearchResults.service";
		HttpEntity<ControlWordsSearchVO> entity = new HttpEntity<ControlWordsSearchVO>(
				controlWordsSearchVO);
		ControlWordsSearchVO result = null;
		result = (ControlWordsSearchVO) this.restTemplate.postForObject(
				serviceURL, entity, ControlWordsSearchVO.class, new Object[0]);
		LOGGER.info("exiting ControlWordsProxy | retrieveControlWordsSearchResults");
		return result;
	}
	/**
	 * 
	 * The method to retrieve control words by the unusable glosaary id
	 *
	 * @param dnbUnusGlsyId
	 * @param isStagingDB
	 * @return
	 */
	public DnbUnusGlsy retrieveControlWordById(Long dnbUnusGlsyId, Boolean isStagingDB) {
		LOGGER.info("entering ControlWordsProxy | retrieveControlWordById");

		HttpEntity<DnbUnusGlsy> entity = new HttpEntity<DnbUnusGlsy>(
				restWSUtil.constructRequestHeader());
		String queryParams = "/{dnbUnusGlsyId}/{isStagingDB}/retrieveControlWordById.service";
		ResponseEntity<DnbUnusGlsy> result = null;
		result = restTemplate.exchange(
				restWSUtil.getServiceURL(queryParams), HttpMethod.GET,
				entity, DnbUnusGlsy.class, dnbUnusGlsyId, isStagingDB);
		LOGGER.info("exiting ControlWordsProxy | retrieveControlWordById");
		return result != null ? result.getBody() : null;
	}
	/**
	 * 
	 * The method to update the control word text in the transaction db
	 *
	 * @param dnbUnusGlsy
	 * @return
	 */
	public Long updateControlWord(DnbUnusGlsy dnbUnusGlsy) {
		LOGGER.info("entering ControlWordsProxy | updateControlWord");

		String queryParams = "/updateControlWord.service";
		HttpEntity<DnbUnusGlsy> entity = new HttpEntity<DnbUnusGlsy>(dnbUnusGlsy);
		Long result = null;
		result = restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Long.class);
		LOGGER.info("exiting ControlWordsProxy | updateControlWord");
		return result;
	}

	/**
	 * 
	 * The method to retrieve all applicable country codes for the Area Code Numbers
	 *
	 * @return codeValueVOs
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> getAllAreaCodeApplicableGeoUnits(Long geoUnitTypeCode){
		LOGGER.info("entering ControlWordsProxy | getAllAreaCodeApplicableCountries");
		String queryParams = "/{geoUnitTypeCode}/retrieveAllAreaCodeGeoUnits.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, queryParams, geoUnitTypeCode);
	}
	
	/**
	 * 
	 * The method will count the records in the hierarchy search of control
	 * words on the search db. The search will be done on the flat db based on
	 * the search criteria the user had provided.
	 * 
	 * @param controlWordsSearchVO
	 * @return countResults
	 */
	public Long countSearchAreaCodeNumbers(ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering ControlWordsProxy | countSearchAreaCodeNumbers");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/countSearchAreaCodeNumbers.service";
		HttpEntity<ControlWordsSearchVO> entity = new HttpEntity<ControlWordsSearchVO>(controlWordsSearchVO);
		Long result = null;
		result = (Long) this.restTemplate.postForObject(serviceURL, entity,	Long.class, new Object[0]);
		LOGGER.info("exiting ControlWordsProxy | countSearchAreaCodeNumbers");
		return result;
	}
	
	/**
	 * 
	 * Retrieves the Area Code Numbers search Results.
	 * <p>
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param currencySearchCriteria
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<PhoneAreaCode> searchAreaCodeNumbers(
			ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering ControlWordsProxy | searchAreaCodeNumbers");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()	+ "/searchAreaCodeNumbers.service";
		HttpEntity<ControlWordsSearchVO> entity = new HttpEntity<ControlWordsSearchVO>(controlWordsSearchVO);
		List<PhoneAreaCode> result = null;
		result = (List<PhoneAreaCode>) this.restTemplate.postForObject(serviceURL, entity, 
				List.class, new Object[0]);
		LOGGER.info("exiting ControlWordsProxy | searchAreaCodeNumbers");
		return result;
	}
	/**
	 * The method will retrieve all Legal Form Class Codes from the Search DB
	 * The return type is a VO which contains the Legal Form Class Code and Code
	 * Value description of the code.
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveLegalFormClassCodes() {
		LOGGER.info("entering ControlWordsWebServiceProxy | retrieveLegalFormClassCodes");
		String serviceURL = "/retrieveLegalFormClassCodes.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL);
	}
	
	/**
	 * The method will retrieve all Legal Form Codes from the Search DB
	 * The return type is a VO which contains the Legal Form Class Code and Code
	 * Value description of the code.
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveLegalFormCodes() {
		LOGGER.info("entering ControlWordsWebServiceProxy | retrieveLegalFormCodes");
		String serviceURL = "/retrieveLegalFormCodes.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL);
	}

	/**
	 * The method will retrieve all Legal Form Languages from the Search DB
	 * The return type is a VO which contains the Legal Form Languages and Code
	 * Value description of the code.
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveLegalFormLanguages() {
		LOGGER.info("entering ControlWordsWebServiceProxy | retrieveLegalFormLanguages");
		String serviceURL = "/retrieveLegalFormLanguages.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL);
	}
	/**
	 * The method will retrieve all Legal Form Countries from the Search DB
	 * The return type is a VO which contains the Legal Form Country Code and Code
	 * Value description of the code.
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveLegalFormCountries() {
		LOGGER.info("entering ControlWordsWebServiceProxy | retrieveLegalFormCountries");
		String serviceURL = "/retrieveLegalFormCountries.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL);
	}
	/**
	 *
	 * The method will perform a hierarchy search of count of Inferment Text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param ctrlWrdsSearchCriteriaVO
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<InfermentText> searchLegalFormInfermentText(
			ControlWordsSearchVO ctrlWrdsSearchCriteriaVO) {
		LOGGER.info("entering ControlWordsWebServiceProxy | searchLegalFormInfermentText");
		String queryParams = "/searchLegalFormInfermentText.service";
		HttpEntity<ControlWordsSearchVO> entity = new HttpEntity<ControlWordsSearchVO>(
				ctrlWrdsSearchCriteriaVO);
		List<InfermentText> result = null;
		result = (List<InfermentText>) this.restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, List.class,
				new Object[0]);
		LOGGER.info("exiting ControlWordsWebServiceProxy | searchLegalFormInfermentText");
		return result;
	}
	/**
	 * 
	 * The method will count the records in the hierarchy search of Inferment Texts on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param ctrlWrdsSearchCriteriaVO
	 * @return countResults
	 */
	public Long countSearchLegalFormInfermentText(ControlWordsSearchVO ctrlWrdsSearchCriteriaVO) {
		LOGGER.info("entering ControlWordsWebServiceProxy | countSearchLegalFormInfermentText");

		String queryParams = "/countSearchLegalFormInfermentText.service";
		HttpEntity<ControlWordsSearchVO> entity = new HttpEntity<ControlWordsSearchVO>(
				ctrlWrdsSearchCriteriaVO);
		Long result = null;
		result = (Long) this.restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Long.class,
				new Object[0]);
		LOGGER.info("exiting ControlWordsWebServiceProxy | countSearchLegalFormInfermentText");
		return result;
	}
    /**
	 * Searches the Staging DB for the Inferment Text based on the infermentTextId and will return the 
	 * InfermentText entity.<p>
	 *
	 * @param infermentTextId
	 * @return InfermentText
	 */
	public InfermentText retrieveInfermentTextByInfermentTextId(Long infermentTextId) {
		LOGGER.info("entering ControlWordsWebServiceProxy | retrieveInfermentTextByInfermentTextId");
		HttpEntity<InfermentText> entity = new HttpEntity<InfermentText>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{infermentTextId}/retrieveInfermentTextByInfermentTextId.service";
		ResponseEntity<InfermentText> result = null;
		LOGGER.info("Before calling the rest method: ");
		result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
				InfermentText.class, infermentTextId);
		LOGGER.info("exiting ControlWordsWebServiceProxy | retrieveInfermentTextByInfermentTextId || result: "
				+ result);
		return result != null ? result.getBody() : null;
	}

	/**
     * The method to fetch all the industry code type related to inferment
     * 
     * @param codeTableId
     * @param languageCode
     * @return
     */
    @SuppressWarnings({ "unchecked" })
    public List<IndustryCodeInferment> retrieveIndustryCodeTypeAndDesc(Integer codeTableId, Long languageCode) {
        LOGGER.info("entering ControlWordsWebServiceProxy | retrieveIndustryCodeTypeAndDesc");

        String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/retrieveIndustryInfermentCode.service";
        HttpEntity<Integer> entity = new HttpEntity<Integer>(codeTableId);
        List<IndustryCodeInferment> result = null;
        result = (List<IndustryCodeInferment>) this.restTemplate.postForObject(serviceURL, entity, List.class,
                  new Object[0]);
        LOGGER.info("exiting ControlWordsWebServiceProxy | retrieveIndustryCodeTypeAndDesc");
        return result;
    }

    /**
     * 
     * The method to retrieve the language codes for the industry code inferment
     * 
     * @return
     */
    @SuppressWarnings("unchecked")
    public List<IndustryCodeInferment> retrieveLanguageCode() {
        LOGGER.info("entering ControlWordsWebServiceProxy | retrieveLanguageCode");
        String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/retrieveLanguageCode.service";
        HttpEntity<List<IndustryCodeInferment>> entity = new HttpEntity<List<IndustryCodeInferment>>(
                restWSUtil.constructRequestHeader());
        List<IndustryCodeInferment> result = null;
        result = (List<IndustryCodeInferment>) this.restTemplate.postForObject(serviceURL, entity, List.class,
                 new Object[0]);
        return result;
    }

    /**
     * The method to retrieve the industry code description for an industry code
     * 
     * @return
     */
    @SuppressWarnings("unchecked")
    public List<IndustryCode> retrieveIndustryCodeDescription(Long industryCodeTypeCode) {
        LOGGER.info("entering ControlWordsWebServiceProxy | retrieveIndustryCodeDescription");
        String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/{industryCodeTypeCode}/retrieveIndustryCodeDescription.service";
        HttpEntity<List<IndustryCode>> entity = new HttpEntity<List<IndustryCode>>(
                restWSUtil.constructRequestHeader());
        List<IndustryCode> result = null;
        result = (List<IndustryCode>) this.restTemplate.postForObject(serviceURL, entity, List.class,
                 industryCodeTypeCode);
        return result;

    }

    /**
     * 
     * The method will count the records in the hierarchy search of industry codes inferment on the search db. The
     * search will be done on the flat db based on the search criteria the user had provided.
     * 
     * @param industryCodesInfermentSearchCriteria
     * @return countResults
     */
    public Long countSearchIndustryCodesInferment(ControlWordsSearchVO industryCodesInfermentSearchCriteria) {
        LOGGER.info("entering ControlWordsWebServiceProxy | countSearchIndustryCodesInferment");

        String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/countSearchIndustryCodesInferment.service";
        HttpEntity<ControlWordsSearchVO> entity = new HttpEntity<ControlWordsSearchVO>(
                industryCodesInfermentSearchCriteria);
        Long result = null;
        result = (Long) this.restTemplate.postForObject(serviceURL, entity, Long.class, new Object[0]);
        LOGGER.info("exiting ControlWordsWebServiceProxy | countSearchIndustryCodesInferment");
        return result;
    }

    /**
     * Retrieves the Industry Code Inferment search Results.
     * <p>
     * The search will be done on the flat db based on the search criteria the user had provided.
     * <p>
     * 
     * @param industryCodesSearchCriteria
     * @return a list of IndustryCode
     */
    @SuppressWarnings("unchecked")
    public List<IndustryCodeInferment> searchIndustryCodesInferment(
            ControlWordsSearchVO industryCodesInfermentSearchCriteria) {
        LOGGER.info("entering ControlWordsWebServiceProxy | searchIndustryCodesInferment");

        String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/searchIndustryCodesInferment.service";
        HttpEntity<ControlWordsSearchVO> entity = new HttpEntity<ControlWordsSearchVO>(
                industryCodesInfermentSearchCriteria);
        List<IndustryCodeInferment> result = null;
        result = (List<IndustryCodeInferment>) this.restTemplate.postForObject(serviceURL, entity, List.class,
                 new Object[0]);
        LOGGER.info("exiting ControlWordsWebServiceProxy | searchIndustryCodesInferment");
        return result;
    }

    /**
     * The method fetched the inferment search view page details
     *
     * @param infermentText
     * @return
     */
    public IndustryCodeInferment industryCodeInfermentSearchView(Long infermentText) {
        LOGGER.info("entering ControlWordsWebServiceProxy | industryCodeInfermentSearchView");

        String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/{infermentText}/searchIndustryCodesInfermentSearchView.service";
        HttpEntity<IndustryCodeInferment> entity = new HttpEntity<IndustryCodeInferment>(
        		restWSUtil.constructRequestHeader());
       
        ResponseEntity<IndustryCodeInferment> result = null;
        result = (ResponseEntity<IndustryCodeInferment>) this.restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
                 IndustryCodeInferment.class, infermentText);
        LOGGER.info("exiting ControlWordsWebServiceProxy | searchIndustryCodesInferment");
        return result != null ? result.getBody() : null;
    }
    
    /**
	 * 
	 * The method will validate the InfermentText for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param infermentTextId
	 * @return
	 */
	public Boolean lockInfermentText(Long infermentTextId) {
		LOGGER.info("entering ControlWordsWebServiceProxy | lockInfermentText");

		HttpEntity<Boolean> entity = new HttpEntity<Boolean>(
				restWSUtil.constructRequestHeader());
		String serviceURL =refDataConfigUtil.getServiceDeployURL() + "/{infermentTextId}/lockInfermentText.service";
		ResponseEntity<Boolean> result = null;
		result = this.restTemplate.exchange(serviceURL, HttpMethod.GET,
				entity, Boolean.class, new Object[] { infermentTextId });
		LOGGER.info("exiting ControlWordsWebServiceProxy | lockInfermentText");
		return result != null ? (Boolean) result.getBody() : null;
	}
	
    
    /**
     * The method will search the Transaction SoR for the InfermentText based on the infermentTextId 
     * and will return the InfermentText entity.
     *
     * @param infermentTextId
     * @return InfermentText
     */
    public InfermentText reviewInfermentChanges(Long infermentTextId) {
        LOGGER.info("entering ControlWordsWebServiceProxy | reviewLegalInfermentChanges");

        HttpEntity<InfermentText> entity = new HttpEntity<InfermentText>(
                restWSUtil.constructRequestHeader());
        String serviceURL = refDataConfigUtil.getServiceDeployURL()
                + "/{infermentTextId}/reviewLegalFormInfermentChanges.service";
        ResponseEntity<InfermentText> result = null;
        result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
                 InfermentText.class, infermentTextId);
        LOGGER.info("exiting ControlWordsWebServiceProxy | reviewLegalInfermentChanges ||result: " + result);
        return result != null ? result.getBody() : null;
    }
    
    	/**
	 * The method will persist the edited legalFormInferment in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param infermentText
	 */
	public Long updateInfermentText(InfermentText infermentText) {
		LOGGER.info("entering ControlWordsWebServiceProxy | updateInfermentText");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/updateInfermentText.service";
		HttpEntity<InfermentText> entity = new HttpEntity<InfermentText>(
				infermentText);
		Long result = null;
		result = restTemplate.postForObject(serviceURL, entity, Long.class);
		LOGGER.info("exiting ControlWordsWebServiceProxy | updateInfermentText");
		return result;
	}

	/**
	 * 
	 * The method to retrieve the area code information
	 *
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<String> retrieveAreaCodeInfo(){
		LOGGER.info("entering ControlWordsWebServiceProxy | retrieveAreaCodeInfo");
		HttpEntity<List<String>> entity = new HttpEntity<List<String>>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveAreaCodeInfo.service";
		@SuppressWarnings("rawtypes")
		ResponseEntity<List> result = null;
		result = restTemplate.exchange(serviceURL, HttpMethod.POST, entity,
				List.class);
		LOGGER.info("exiting ControlWordsWebServiceProxy | retrieveAreaCodeInfo");
		return result != null ? (List<String>)result.getBody(): null;
	}
	/**
	 * 
	 * The method to update the phone area code
	 *
	 * @param phoneAreaCode
	 * @return
	 */
	public Long updatePhoneAreaCode(PhoneAreaCode phoneAreaCode) {
		LOGGER.info("entering ControlWordsWebServiceProxy | updatePhoneAreaCode");

		String queryParams = "/updatePhoneAreaCode.service";
		HttpEntity<PhoneAreaCode> entity = new HttpEntity<PhoneAreaCode>(phoneAreaCode);
		Long result = null;
		result = restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Long.class);
		LOGGER.info("exiting ControlWordsWebServiceProxy | updatePhoneAreaCode");
		return result;
	}
	/**
	 * 
	 * TODO
	 *
	 * @param phoneAreaCodeId
	 * @param isStagingDB
	 * @return
	 */
	public PhoneAreaCode retrievePhoneAreaCodeById(Long phoneAreaCodeId, Boolean isStagingDB) {
		LOGGER.info("entering ControlWordsProxy | retrievePhoneAreaCodeById");

		HttpEntity<PhoneAreaCode> entity = new HttpEntity<PhoneAreaCode>(
				restWSUtil.constructRequestHeader());
		String queryParams = "/{phoneAreaCodeId}/{isStagingDB}/retrievePhoneAreaCodeById.service";
		ResponseEntity<PhoneAreaCode> result = null;
		result = restTemplate.exchange(
				restWSUtil.getServiceURL(queryParams), HttpMethod.GET,
				entity, PhoneAreaCode.class, phoneAreaCodeId, isStagingDB);
		LOGGER.info("exiting ControlWordsProxy | retrievePhoneAreaCodeById");
		return result != null ? result.getBody() : null;
	}
	
	/**
	 * The method will down load the Contrl Words based on the 
	 * controlwords type.
	 * 
	 * @param controlWordsBulkDownloadVO
	 * @return 
	 */
	public Boolean ctrlWrdsBulkDownload(ControlWordsBulkDownloadVO controlWordsBulkDownloadVO) {
		LOGGER.info("entering ControlWordsProxy | ctrlWrdsBulkDownload");		
		String serviceURL = refDataConfigUtil.getBatchDeployURL()+ "/ctrlWrdsBulkDownload.service";			
		HttpEntity<ControlWordsBulkDownloadVO> entity = new HttpEntity<ControlWordsBulkDownloadVO>(controlWordsBulkDownloadVO);		
		Boolean result = null;
		result = restTemplate.postForObject(serviceURL, entity, Boolean.class);
		LOGGER.info("exiting ControlWordsProxy | ctrlWrdsBulkDownload");
		return result;
	}
	
	public Boolean lockPhoneAreaCodeForEdit(Long phoneAreaCodeId) {
		LOGGER.info("entering ControlWordsProxy | lockPhoneAreaCodeForEdit");

		HttpEntity<Boolean> entity = new HttpEntity<Boolean>(
				restWSUtil.constructRequestHeader());
		String queryParams = "/{phoneAreaCodeId}/lockPhoneAreaCodeForEdit.service";
		ResponseEntity<Boolean> result = null;
		result = this.restTemplate.exchange(
				restWSUtil.getServiceURL(queryParams), HttpMethod.GET,
				entity, Boolean.class, new Object[] { phoneAreaCodeId });
		LOGGER.info("exiting ControlWordsProxy | lockPhoneAreaCodeForEdit");
		return result != null ? (Boolean) result.getBody() : null;
	}
	/**
	 * 
	 * The method to retrieve the control words search results 
	 *
	 * @param controlWordsSearchVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<DnbUnusGlsy> retrieveControlWordsAjaxSearchResults(
			ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering ControlWordsProxy | retrieveControlWordsSearchResults");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveControlWordsAJAXSearchResults.service";
		HttpEntity<ControlWordsSearchVO> entity = new HttpEntity<ControlWordsSearchVO>(
				controlWordsSearchVO);
		List<DnbUnusGlsy> result = new ArrayList<DnbUnusGlsy>();
		result = (List<DnbUnusGlsy>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
		LOGGER.info("exiting ControlWordsProxy | retrieveControlWordsSearchResults");
		return result;
	}
	/**
	 * 
	 * The method will count the records in the hierarchy search of Inferment Texts on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param ctrlWrdsSearchCriteriaVO
	 * @return countResults
	 */
	public Long countSearchControlWords(ControlWordsSearchVO ctrlWrdsSearchCriteriaVO) {
		LOGGER.info("entering ControlWordsWebServiceProxy | countSearchControlWords");

		String queryParams = "/countSearchControlWords.service";
		HttpEntity<ControlWordsSearchVO> entity = new HttpEntity<ControlWordsSearchVO>(
				ctrlWrdsSearchCriteriaVO);
		Long result = null;
		result = (Long) this.restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Long.class,
				new Object[0]);
		LOGGER.info("exiting ControlWordsWebServiceProxy | countSearchControlWords");
		return result;
	}
  
}
