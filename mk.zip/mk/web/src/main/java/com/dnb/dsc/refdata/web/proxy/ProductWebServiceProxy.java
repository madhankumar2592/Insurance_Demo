package com.dnb.dsc.refdata.web.proxy;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.Product;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.AddNewProductsVO;
import com.dnb.dsc.refdata.core.vo.ProductScoreMappingVO;
import com.dnb.dsc.refdata.core.vo.ProductScoreReportVO;
import com.dnb.dsc.refdata.core.vo.ProductSearchVO;
import com.dnb.dsc.refdata.core.vo.ProductVO;
import com.dnb.dsc.refdata.web.util.RestWebServiceUtil;

@Component
public class ProductWebServiceProxy {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private RestWebServiceUtil restWSUtil;

	@Autowired
	private RefDataConfigUtil refDataConfigUtil;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ProductWebServiceProxy.class);

	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveProductTypeCodeValues(ProductVO productVO) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveProductTypeCodeValues");
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveProdTypeCodeVals.service";
		HttpEntity<ProductVO> entity = new HttpEntity<ProductVO>(productVO);
		LOGGER.info("exiting ProductWebServiceProxy | retrieveProductTypeCodeValues");
		List<CodeValue> list = (List<CodeValue>) this.restTemplate
				.postForObject(serviceURL, entity, List.class, new Object[0]);
		return list;
	}

	
	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveResourceTypeCodeValues(ProductVO productVO) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveResourceTypeCodeValues");
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveRescTypeCodeVals.service";
		HttpEntity<ProductVO> entity = new HttpEntity<ProductVO>(productVO);
		LOGGER.info("exiting ProductWebServiceProxy | retrieveResourceTypeCodeValues");
		return (List<CodeValue>) this.restTemplate.postForObject(serviceURL,
				entity, List.class, new Object[0]);
	}

	
	public Long countOfProductSearch(ProductSearchVO productSearchVO) {
		return countSearchProduct(productSearchVO,
				"/countSearchProduct.service");
	}

	private Long countSearchProduct(ProductSearchVO productSearchVO,
			String deployURL) {
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + deployURL;
		HttpEntity<ProductSearchVO> entity = new HttpEntity<ProductSearchVO>(
				productSearchVO);
		return (Long) this.restTemplate.postForObject(serviceURL, entity,
				Long.class, new Object[0]);
	}

	@SuppressWarnings("unchecked")
	public List<ProductSearchVO> SearchProduct(ProductSearchVO productSearchVO)
			throws Exception {
		LOGGER.info("entering ProductWebServiceProxy | SearchProduct");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/productSearchResult.service";
		HttpEntity<ProductSearchVO> entity = new HttpEntity<ProductSearchVO>(
				productSearchVO);
		LOGGER.info("exiting ProductWebServiceProxy | SearchProduct");
		return (List<ProductSearchVO>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}

	public Long updateNewProducts(AddNewProductsVO addNewProductsVO) {
		LOGGER.info("entering ProductWebServiceProxy | updateNewProducts");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/updateNewProducts.service";
		HttpEntity<AddNewProductsVO> entity = new HttpEntity<AddNewProductsVO>(
				addNewProductsVO);
		LOGGER.info("exiting ProductWebServiceProxy | updateNewProducts");
		Long res = (Long) restTemplate.postForObject(serviceURL, entity,
				Long.class, new Object[0]);
		return res;
	}

	public AddNewProductsVO retrieveProductDetails(
			ProductSearchVO productSearchVO) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveProductDetails");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveProductDetail.service";
		HttpEntity<ProductSearchVO> entity = new HttpEntity<ProductSearchVO>(
				productSearchVO);
		LOGGER.info("exiting ProductWebServiceProxy | retrieveProductDetails");
		AddNewProductsVO res = (AddNewProductsVO) restTemplate.postForObject(
				serviceURL, entity, AddNewProductsVO.class, new Object[0]);
		return res;
	}

	public Long editProducts(AddNewProductsVO addNewProductsVO) {
		LOGGER.info("entering ProductWebServiceProxy | editProducts");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/editProducts.service";
		HttpEntity<AddNewProductsVO> entity = new HttpEntity<AddNewProductsVO>(
				addNewProductsVO);
		LOGGER.info("exiting ProductWebServiceProxy | editProducts");
		Long res = (Long) restTemplate.postForObject(serviceURL, entity,
				Long.class, new Object[0]);
		return res;
	}

	public Long countOfProductScrRpt(ProductScoreReportVO productScoreReportVO) {
		return countOfProdScrRpt(productScoreReportVO,
				"/countOfProductScrRpt.service");
	}

	private Long countOfProdScrRpt(ProductScoreReportVO productScoreReportVO,
			String deployURL) {
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + deployURL;
		HttpEntity<ProductScoreReportVO> entity = new HttpEntity<ProductScoreReportVO>(
				productScoreReportVO);
		return (Long) this.restTemplate.postForObject(serviceURL, entity,
				Long.class, new Object[0]);
	}

	@SuppressWarnings("unchecked")
	public List<ProductScoreReportVO> productScrReport(
			ProductScoreReportVO productScoreReportVO) {
		LOGGER.info("entering ProductWebServiceProxy | productScrReport");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/productScrReport.service";
		HttpEntity<ProductScoreReportVO> entity = new HttpEntity<ProductScoreReportVO>(
				productScoreReportVO);
		LOGGER.info("exiting ProductWebServiceProxy | productScrReport");
		return (List<ProductScoreReportVO>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}

	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveGranularityCodes(Long scoreType) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveGranularityCodes");
		String serviceURL = "/{scoreType}/retrieveGranularityCodes.service";
		return restWSUtil.exchangeForList(CodeValue.class, serviceURL,
				scoreType);
	}

	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveProductCodeValues(
			AddNewProductsVO addNewProductsVO) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveProductCodeValues");
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveProductCodeValues.service";
		HttpEntity<AddNewProductsVO> entity = new HttpEntity<AddNewProductsVO>(
				addNewProductsVO);
		LOGGER.info("exiting ProductWebServiceProxy | retrieveProductCodeValues");
		return (List<CodeValue>) this.restTemplate.postForObject(serviceURL,
				entity, List.class, new Object[0]);
	}

	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveProdFamCode(Long prodCode) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveProdFamCode");
		String serviceURL = "/{prodCode}/retrieveProdFamCode.service";
		return restWSUtil
				.exchangeForList(CodeValue.class, serviceURL, prodCode);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<Product> retrieveProdVers(Long prodCode) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveProdVers");
		String serviceURL = "/{prodCode}/retrieveProdVers.service";
		List prodList = restWSUtil.exchangeForList(Product.class, serviceURL,
				prodCode);
		//
		List<Product> prodLists = new ArrayList<Product>();
		for (int i = 0; i < prodList.size(); i++) {
			Product product = new Product();
			LinkedHashMap<String, Integer> lhm = (LinkedHashMap<String, Integer>) prodList
					.get(i);
			for (Entry<String, Integer> t : lhm.entrySet()) {
				if (t.getValue() != null) {
					try {
						if (t.getKey().equalsIgnoreCase("productVersion")) {
							product.setProductVersion(new Long(t.getValue()));
						}
					} catch (Exception e) {
						LOGGER.error("ProductWebServiceProxy | retrieveProdVers", e);
					}
				}
			}
			prodLists.add(product);
		}
		
		return prodLists;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<CodeValue> retrieveResource(Long prodCode) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveResource");
		String serviceURL = "/{prodCode}/retrieveResource.service";
		List resourceLst = restWSUtil.exchangeForList(CodeValue.class,
				serviceURL, prodCode);
		List<CodeValue> resourceList = new ArrayList<CodeValue>();
		for (int i = 0; i < resourceLst.size(); i++) {
			CodeValue codeValue = new CodeValue();
			LinkedHashMap<String, Integer> lhm = (LinkedHashMap<String, Integer>) resourceLst
					.get(i);
			for (Entry<String, Integer> t : lhm.entrySet()) {
				if (t.getValue() != null) {
					try {
						if (t.getKey().equalsIgnoreCase("codeValueId")) {
							codeValue.setCodeValueId(new Long(t.getValue()));
						} else if (t.getKey().equalsIgnoreCase(
								"codeValueShortDescription")) {
							codeValue.setCodeValueDescription(String.valueOf(t
									.getValue()));
						} else if (t.getKey().equalsIgnoreCase(
								"codeValueDescription")) {
							codeValue.setBusinessDescription(String.valueOf(t
									.getValue()));
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			resourceList.add(codeValue);
		}
		return resourceList;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<Product> retrieveFamProdVersion(Long famCode, Long prodCode) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveResource");
		String serviceURL = "/{famCode}/{prodCode}/retrieveFamProdVersion.service";
		List prodList = restWSUtil.exchangeForList(Product.class, serviceURL,
				famCode, prodCode);
		
		List<Product> prodLists = new ArrayList<Product>();
		for (int i = 0; i < prodList.size(); i++) {
			Product product = new Product();
			LinkedHashMap<String, Integer> lhm = (LinkedHashMap<String, Integer>) prodList
					.get(i);
			for (Entry<String, Integer> t : lhm.entrySet()) {
				if (t.getValue() != null) {
					try {
						if (t.getKey().equalsIgnoreCase("productVersion")) {
							product.setProductVersion(new Long(t.getValue()));
						}
					} catch (Exception e) {
						LOGGER.error("ProductWebServiceProxy | retrieveResource |", e);
					}
				}
			}
			prodLists.add(product);
		}
		
		return prodLists;
	}

	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveFamVerResource(Long famCode, Long prodCode) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveResource");
		String serviceURL = "/{famCode}/{prodCode}/retrieveFamVerResource.service";
		return restWSUtil.exchangeForList(CodeValue.class, serviceURL, famCode,
				prodCode);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<CodeValue> retrieveProdFamVerResource(Long famCode,
			Long prodCode, Long prodVer) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveProdFamVerResource");
		String serviceURL = "/{famCode}/{prodCode}/{prodVer}/retrieveProdFamVerResource.service";
		List resourceLst = restWSUtil.exchangeForList(CodeValue.class,
				serviceURL, famCode, prodCode, prodVer);
		List<CodeValue> resourceList = new ArrayList<CodeValue>();
		for (int i = 0; i < resourceLst.size(); i++) {
			CodeValue codeValue = new CodeValue();
			LinkedHashMap<String, Integer> lhm = (LinkedHashMap<String, Integer>) resourceLst
					.get(i);
			for (Entry<String, Integer> t : lhm.entrySet()) {
				if (t.getValue() != null) {
					try {
						if (t.getKey().equalsIgnoreCase("codeValueId")) {
							codeValue.setCodeValueId(new Long(t.getValue()));
						} else if (t.getKey().equalsIgnoreCase(
								"codeValueShortDescription")) {
							codeValue.setCodeValueDescription(String.valueOf(t
									.getValue()));
						} else if (t.getKey().equalsIgnoreCase(
								"codeValueDescription")) {
							codeValue.setBusinessDescription(String.valueOf(t
									.getValue()));
						}
					} catch (Exception e) {
						LOGGER.error("ProductWebServiceProxy | retrieveProdFamVerResource", e);
					}
				}
			}
			resourceList.add(codeValue);
		}
		return resourceList;
	}

	public ProductScoreMappingVO updateProdRescScoreGranMapDtl(
			ProductScoreMappingVO productScoreMappingVO) {
		LOGGER.info("entering ProductWebServiceProxy | updateProdRescScoreGranMapDtl");
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/updateProdRescScoreGranMapDtl.service";
		HttpEntity<ProductScoreMappingVO> entity = new HttpEntity<ProductScoreMappingVO>(
				productScoreMappingVO);
		LOGGER.info("exiting ProductWebServiceProxy | updateProdRescScoreGranMapDtl");
		return restTemplate.postForObject(serviceURL, entity,
				ProductScoreMappingVO.class);
	}

	public ProductScoreMappingVO retreiveProdRescScoreGranMapDtl(Long rescMapId) {
		ProductScoreMappingVO productScoreMappingVO = new ProductScoreMappingVO();
		productScoreMappingVO.setRescMapId(rescMapId);
		LOGGER.info("entering ProductWebServiceProxy | retreiveProdRescScoreGranMapDtl");
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retreiveProdRescScoreGranMapDtl.service";
		HttpEntity<ProductScoreMappingVO> entity = new HttpEntity<ProductScoreMappingVO>(
				productScoreMappingVO);
		LOGGER.info("exiting ProductWebServiceProxy | retreiveProdRescScoreGranMapDtl");
		return restTemplate.postForObject(serviceURL, entity,
				ProductScoreMappingVO.class);
	}


	@SuppressWarnings("unchecked")
	public List<Long> retrieveProductMarketDetails(Long prodAvailId) {
		LOGGER.info("entering ProductWebServiceProxy | retrieveProductMarketDetails");
		String serviceURL = "/{prodAvailId}/retrieveProductMarketDetails.service";
		return restWSUtil.exchangeForList(List.class, serviceURL, prodAvailId);
	}

}
