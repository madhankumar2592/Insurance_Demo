/*
 * Cognizant PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Cognizant Technology Solutions. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */

package com.dnb.dsc.refdata.web.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.dnb.dsc.refdata.core.vo.ProductScoreReportVO;
import com.dnb.dsc.refdata.core.vo.ProductSearchVO;

// TODO: Auto-generated Javadoc

/**
 * The Class IndsExportToExcel.
 */
public class ProductSearchExportToExcel extends SXSSFWorkbook {

	/** The inds_code_sheet. */
	private Sheet search_product;

	/** The inds cd row count. */
	private Integer searchProdRowCount = 0;

	/**
	 * Instantiates a new inds export to excel.
	 *
	 * @param exportType the export type
	 */
	public ProductSearchExportToExcel(String scrDesc) {
		super(300);		
		search_product = createSheet("Product Search Rslts");
		prod_sheet_header(scrDesc);
		
			
		

	}

	/**
	 * Inds_code_sheet_header.
	 */
	private void prod_sheet_header(String prodDesc) {

		Row indusCdHeader = search_product.createRow(0);

		Cell headerCell0 = indusCdHeader.createCell(0);
		headerCell0.setCellValue("Product ID");
		
		Cell headerCell4 = indusCdHeader.createCell(1);
		headerCell4.setCellValue("Product Code");

		Cell headerCell1 = indusCdHeader.createCell(2);
		headerCell1.setCellValue("Product Code Description");

		Cell headerCell2 = indusCdHeader.createCell(3);
		headerCell2.setCellValue("Product MetaData Code");
		
		Cell headerCell3 = indusCdHeader.createCell(4);
		headerCell3.setCellValue("Product Metadata Code Description");
		
		Cell headerCell5 = indusCdHeader.createCell(5);
		headerCell5.setCellValue("Product Metadata Code Value");
		
		Cell headerCell6 = indusCdHeader.createCell(6);
		headerCell6.setCellValue("Product Group Code");
		
		Cell headerCell7 = indusCdHeader.createCell(7);
		headerCell7.setCellValue("Product Group Code Description");
		
		Cell headerCell8 = indusCdHeader.createCell(8);
		headerCell8.setCellValue("Product Version");
		
		Cell headerCell9 = indusCdHeader.createCell(9);
		headerCell9.setCellValue("Resource Code");
		
		Cell headerCell10 = indusCdHeader.createCell(10);
		headerCell10.setCellValue("Resource Code Description");

		Cell headerCell11 = indusCdHeader.createCell(11);
		headerCell11.setCellValue("Billing System Code");

		Cell headerCell12 = indusCdHeader.createCell(12);
		headerCell12.setCellValue("Resource MetaData Code");
		
		Cell headerCell13 = indusCdHeader.createCell(13);
		headerCell13.setCellValue("Resource Metadata Code Description");
		
		Cell headerCell14 = indusCdHeader.createCell(14);
		headerCell14.setCellValue("Resource Metadata Code Value");
		
		Cell headerCell15 = indusCdHeader.createCell(15);
		headerCell15.setCellValue("Resource Group Code");
		
		Cell headerCell16 = indusCdHeader.createCell(16);
		headerCell16.setCellValue("Resource Group Code Description");
		
		Cell headerCell17 = indusCdHeader.createCell(17);
		headerCell17.setCellValue("Resource Version");
		
		Cell headerCell18 = indusCdHeader.createCell(18);
		headerCell18.setCellValue("Product Country");

		Cell headerCell19 = indusCdHeader.createCell(19);
		headerCell19.setCellValue("Product Country Description");
		
		Cell headerCell20 = indusCdHeader.createCell(20);
		headerCell20.setCellValue("Market Group Code");
		
		Cell headerCell21 = indusCdHeader.createCell(21);
		headerCell21.setCellValue("Market Group Code Description");
		
		Cell headerCell22 = indusCdHeader.createCell(22);
		headerCell22.setCellValue("Delivery Channel Metadata Code");
		
		Cell headerCell23 = indusCdHeader.createCell(23);
		headerCell23.setCellValue("Delivery Channel Metadata Code Value");
		
		Cell headerCell24 = indusCdHeader.createCell(24);
		headerCell24.setCellValue("Delivery Channel Metadata Code Description");

	}

	/**
	 * Insert inds code data.
	 *
	 * @param indsuCodeList the indsu code list
	 * private final String[] productSearchColumns = { "prodAvailId",
				"productCod", "prodCodeDesc", "prodVers", "countryCode", "countryDesc", "rescCode", "rescCodeDesc", "rescVers" };
	 */
	@SuppressWarnings("rawtypes")
	public void insertProductSearchData(List<ProductSearchVO> productSearchVO) {
		List<ProductSearchVO> rows = new ArrayList<ProductSearchVO>();
		Iterator itr = productSearchVO.iterator();
		while (itr.hasNext()) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			ProductSearchVO row = new ProductSearchVO();

			row.setProdId(Long.valueOf((curr.get("prodId").toString())));
			row.setProdCd(Long.valueOf((curr.get("prodCd").toString())));
			row.setProdCodeDesc((String)(curr.get("prodCodeDesc").toString()));
			row.setProdDtlMtdtCd(Long.valueOf((curr.get("prodDtlMtdtCd").toString())));
			row.setProdDtlMtdtCdDesc((String)(curr.get("prodDtlMtdtCdDesc").toString()));
			row.setProdDtlMtdCdVal((String)(curr.get("prodDtlMtdCdVal").toString()));
			row.setProdGrpCd(Long.valueOf((curr.get("prodGrpCd").toString())));
			row.setProdGrpCdDesc((String)(curr.get("prodGrpCdDesc").toString()));
			row.setProdVers(Long.valueOf((curr.get("prodVers").toString())));
			row.setRescCd(Long.valueOf((curr.get("rescCd").toString())));
			row.setRescCodeDesc((String)(curr.get("rescCodeDesc").toString()));
			row.setBilgSysCd(Long.valueOf((curr.get("bilgSysCd").toString())));
			row.setRescDtlMtdtCd(Long.valueOf((curr.get("rescDtlMtdtCd").toString())));
			row.setRescDtlMtdtCdDesc((String)(curr.get("rescDtlMtdtCdDesc").toString()));
			row.setRescMtdtVal((String)(curr.get("rescMtdtVal").toString()));
			row.setRescGrpCd(Long.valueOf((curr.get("rescGrpCd").toString())));
			row.setRescGrpCdDesc((String)(curr.get("rescGrpCdDesc").toString()));
			row.setRescVers(Long.valueOf((curr.get("rescVers").toString())));
			row.setCountryCode(Long.valueOf((curr.get("countryCode").toString())));
			row.setCountryDesc((String)(curr.get("countryDesc").toString()));
			row.setMktGrpCd(Long.valueOf((curr.get("mktGrpCd").toString())));
			row.setMktGrpCdDesc((String)(curr.get("mktGrpCdDesc").toString()));
			row.setSlsChnlDtlMtdtCd(Long.valueOf((curr.get("slsChnlDtlMtdtCd").toString())));
			row.setSlsChnlDtlMtdtVal((String)(curr.get("slsChnlDtlMtdtVal").toString()));
			row.setSlsChnlDtlMtdtCdDesc((String)(curr.get("slsChnlDtlMtdtCdDesc").toString()));

			
			rows.add(row);
		}
		for (ProductSearchVO scrSearch : rows) {
			searchProdRowCount++;
			Row dataRow = search_product.createRow(searchProdRowCount);
			Cell indscell0 = dataRow.createCell(0);
			indscell0.setCellValue(scrSearch.getProdId());
			Cell indscell1 = dataRow.createCell(1);
			indscell1.setCellValue(scrSearch.getProdCd());
			Cell indscell2 = dataRow.createCell(2);
			indscell2.setCellValue(scrSearch.getProdCodeDesc());
			Cell indscell3 = dataRow.createCell(3);
			indscell3.setCellValue(scrSearch.getProdDtlMtdtCd());
			Cell indscell4 = dataRow.createCell(4);
			indscell4.setCellValue(scrSearch.getProdDtlMtdtCdDesc());
			Cell indscell5 = dataRow.createCell(5);
			indscell5.setCellValue(scrSearch.getProdDtlMtdCdVal());
			Cell indscell6 = dataRow.createCell(6);
			indscell6.setCellValue(scrSearch.getProdGrpCd());
			Cell indscell7 = dataRow.createCell(7);
			indscell7.setCellValue(scrSearch.getProdGrpCdDesc());
			Cell indscell8 = dataRow.createCell(8);
			indscell8.setCellValue(scrSearch.getProdVers());
			Cell indscell9 = dataRow.createCell(9);
			indscell9.setCellValue(scrSearch.getRescCd());
			Cell indscell10 = dataRow.createCell(10);
			indscell10.setCellValue(scrSearch.getRescCodeDesc());
			Cell indscell11 = dataRow.createCell(11);
			indscell11.setCellValue(scrSearch.getBilgSysCd());
			Cell indscell12 = dataRow.createCell(12);
			indscell12.setCellValue(scrSearch.getRescDtlMtdtCd());
			Cell indscell13 = dataRow.createCell(13);
			indscell13.setCellValue(scrSearch.getRescDtlMtdtCdDesc());
			Cell indscell14 = dataRow.createCell(14);
			indscell14.setCellValue(scrSearch.getRescMtdtVal());
			Cell indscell15 = dataRow.createCell(15);
			indscell15.setCellValue(scrSearch.getRescGrpCd());
			Cell indscell16 = dataRow.createCell(16);
			indscell16.setCellValue(scrSearch.getRescGrpCdDesc());
			Cell indscell17 = dataRow.createCell(17);
			indscell17.setCellValue(scrSearch.getRescVers());
			Cell indscell18 = dataRow.createCell(18);
			indscell18.setCellValue(scrSearch.getCountryCode());
			Cell indscell19 = dataRow.createCell(19);
			indscell19.setCellValue(scrSearch.getCountryDesc());
			Cell indscell20 = dataRow.createCell(20);
			indscell20.setCellValue(scrSearch.getMktGrpCd());
			Cell indscell21 = dataRow.createCell(21);
			indscell21.setCellValue(scrSearch.getMktGrpCdDesc());
			Cell indscell22 = dataRow.createCell(22);
			indscell22.setCellValue(scrSearch.getSlsChnlDtlMtdtCd());
			Cell indscell23 = dataRow.createCell(23);
			indscell23.setCellValue(scrSearch.getSlsChnlDtlMtdtVal());
			Cell indscell24 = dataRow.createCell(24);
			indscell24.setCellValue(scrSearch.getSlsChnlDtlMtdtCdDesc());
		}

	}

	@SuppressWarnings("rawtypes")
	public void insertProductScrRptExportToExcelData(
			List<ProductScoreReportVO> productScrReport) {

		List<ProductScoreReportVO> rows = new ArrayList<ProductScoreReportVO>();
		
		Iterator itr = productScrReport.iterator();
		while (itr.hasNext()) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			ProductScoreReportVO row = new ProductScoreReportVO();
			
			row.setScr_id(Long.valueOf((curr.get("scr_id").toString())));			
			row.setScoreTypeCode(Long.valueOf((curr.get("scoreTypeCode").toString())));
			row.setScr_typ_cd_val_d((String)(curr.get("scr_typ_cd_val_d")));
			row.setScr_vers(Double.valueOf((curr.get("scr_vers").toString())));
			row.setScr_mkt_cd_id(Long.valueOf((curr.get("scr_mkt_cd_id").toString())));
			row.setCountry_name((String)(curr.get("country_name").toString()));
			row.setScoreGranularity(Long.valueOf((curr.get("scoreGranularity").toString())));
			row.setScr_gru_cd_val_d((String)((curr.get("scr_gru_cd_val_d").toString())));
			
			row.setProdId(Long.valueOf((curr.get("prodId").toString())));
			row.setProdCd(Long.valueOf((curr.get("prodCd").toString())));
			row.setProdCodeDesc((String)(curr.get("prodCodeDesc").toString()));
			row.setProdDtlMtdtCd(Long.valueOf((curr.get("prodDtlMtdtCd").toString())));
			row.setProdDtlMtdtCdDesc((String)(curr.get("prodDtlMtdtCdDesc").toString()));
			row.setProdDtlMtdCdVal((String)(curr.get("prodDtlMtdCdVal").toString()));
			row.setProdGrpCd(Long.valueOf((curr.get("prodGrpCd").toString())));
			row.setProdGrpCdDesc((String)(curr.get("prodGrpCdDesc").toString()));
			row.setProdVers(Long.valueOf((curr.get("prodVers").toString())));
			row.setRescCd(Long.valueOf((curr.get("rescCd").toString())));
			row.setRescCodeDesc((String)(curr.get("rescCodeDesc").toString()));
			row.setBilgSysCd(Long.valueOf((curr.get("bilgSysCd").toString())));
			row.setRescDtlMtdtCd(Long.valueOf((curr.get("rescDtlMtdtCd").toString())));
			row.setRescDtlMtdtCdDesc((String)(curr.get("rescDtlMtdtCdDesc").toString()));
			row.setRescMtdtVal((String)(curr.get("rescMtdtVal").toString()));
			row.setRescGrpCd(Long.valueOf((curr.get("rescGrpCd").toString())));
			row.setRescGrpCdDesc((String)(curr.get("rescGrpCdDesc").toString()));
			row.setRescVers(Long.valueOf((curr.get("rescVers").toString())));
			row.setCountryCode(Long.valueOf((curr.get("countryCode").toString())));
			row.setCountryDesc((String)(curr.get("countryDesc").toString()));
			row.setMktGrpCd(Long.valueOf((curr.get("mktGrpCd").toString())));
			row.setMktGrpCdDesc((String)(curr.get("mktGrpCdDesc").toString()));
			row.setSlsChnlDtlMtdtCd(Long.valueOf((curr.get("slsChnlDtlMtdtCd").toString())));
			row.setSlsChnlDtlMtdtVal((String)(curr.get("slsChnlDtlMtdtVal").toString()));
			row.setSlsChnlDtlMtdtCdDesc((String)(curr.get("slsChnlDtlMtdtCdDesc").toString()));

			
			rows.add(row);
		}
		for (ProductScoreReportVO scrSearch : rows) {
			searchProdRowCount++;
			Row dataRow = search_product.createRow(searchProdRowCount);
						
			Cell indscell = dataRow.createCell(0);
			indscell.setCellValue(scrSearch.getScr_id());			
			Cell indscell4 = dataRow.createCell(1);
			indscell4.setCellValue(scrSearch.getScoreTypeCode());
			Cell indscell1 = dataRow.createCell(2);
			indscell1.setCellValue(scrSearch.getScr_typ_cd_val_d());			
			Cell indscell7 = dataRow.createCell(3);
			indscell7.setCellValue(scrSearch.getScr_vers());
			Cell indscell2 = dataRow.createCell(4);
			indscell2.setCellValue(scrSearch.getScr_mkt_cd_id());			
			Cell indscell3 = dataRow.createCell(5);
			indscell3.setCellValue(scrSearch.getCountry_name());			
			Cell indscell5 = dataRow.createCell(6);
			indscell5.setCellValue(scrSearch.getScoreGranularity());			
			Cell indscell6 = dataRow.createCell(7);
			indscell6.setCellValue(scrSearch.getScr_gru_cd_val_d());			
			Cell indscell0 = dataRow.createCell(8);
			indscell0.setCellValue(scrSearch.getProdId());
			Cell indscell25 = dataRow.createCell(9);
			indscell25.setCellValue(scrSearch.getProdCd());
			Cell indscell26 = dataRow.createCell(10);
			indscell26.setCellValue(scrSearch.getProdCodeDesc());
			Cell indscell27 = dataRow.createCell(11);
			indscell27.setCellValue(scrSearch.getProdDtlMtdtCd());
			Cell indscell28 = dataRow.createCell(12);
			indscell28.setCellValue(scrSearch.getProdDtlMtdtCdDesc());
			Cell indscell29 = dataRow.createCell(13);
			indscell29.setCellValue(scrSearch.getProdDtlMtdCdVal());
			Cell indscell30 = dataRow.createCell(14);
			indscell30.setCellValue(scrSearch.getProdGrpCd());
			Cell indscell31 = dataRow.createCell(15);
			indscell31.setCellValue(scrSearch.getProdGrpCdDesc());
			Cell indscell8 = dataRow.createCell(16);
			indscell8.setCellValue(scrSearch.getProdVers());
			Cell indscell9 = dataRow.createCell(17);
			indscell9.setCellValue(scrSearch.getRescCd());
			Cell indscell10 = dataRow.createCell(18);
			indscell10.setCellValue(scrSearch.getRescCodeDesc());
			Cell indscell11 = dataRow.createCell(19);
			indscell11.setCellValue(scrSearch.getBilgSysCd());
			Cell indscell12 = dataRow.createCell(20);
			indscell12.setCellValue(scrSearch.getRescDtlMtdtCd());
			Cell indscell13 = dataRow.createCell(21);
			indscell13.setCellValue(scrSearch.getRescDtlMtdtCdDesc());
			Cell indscell14 = dataRow.createCell(22);
			indscell14.setCellValue(scrSearch.getRescMtdtVal());
			Cell indscell15 = dataRow.createCell(23);
			indscell15.setCellValue(scrSearch.getRescGrpCd());
			Cell indscell16 = dataRow.createCell(24);
			indscell16.setCellValue(scrSearch.getRescGrpCdDesc());
			Cell indscell17 = dataRow.createCell(25);
			indscell17.setCellValue(scrSearch.getRescVers());
			Cell indscell18 = dataRow.createCell(26);
			indscell18.setCellValue(scrSearch.getCountryCode());
			Cell indscell19 = dataRow.createCell(27);
			indscell19.setCellValue(scrSearch.getCountryDesc());
			Cell indscell20 = dataRow.createCell(28);
			indscell20.setCellValue(scrSearch.getMktGrpCd());
			Cell indscell21 = dataRow.createCell(29);
			indscell21.setCellValue(scrSearch.getMktGrpCdDesc());
			Cell indscell22 = dataRow.createCell(30);
			indscell22.setCellValue(scrSearch.getSlsChnlDtlMtdtCd());
			Cell indscell23 = dataRow.createCell(31);
			indscell23.setCellValue(scrSearch.getSlsChnlDtlMtdtVal());
			Cell indscell24 = dataRow.createCell(32);
			indscell24.setCellValue(scrSearch.getSlsChnlDtlMtdtCdDesc());


		}
		
	}
	public ProductSearchExportToExcel(String scrDesc,String Desc) {
		super(300);		
		search_product = createSheet("Product Score Reports Rslts");
		prod_sheet_header(scrDesc,"");

	}
	private void prod_sheet_header(String prodDesc,String desc) {

		Row indusCdHeader = search_product.createRow(0);
		
		Cell headerCell0 = indusCdHeader.createCell(0);
		headerCell0.setCellValue("Score ID");
		
		Cell headerCell4 = indusCdHeader.createCell(1);
		headerCell4.setCellValue("Score Type Code");

		Cell headerCell1 = indusCdHeader.createCell(2);
		headerCell1.setCellValue("Score Type Description");
		
		Cell headerCell7 = indusCdHeader.createCell(3);
		headerCell7.setCellValue("Score Version");

		Cell headerCell2 = indusCdHeader.createCell(4);
		headerCell2.setCellValue("Score Market Code");
		
		Cell headerCell3 = indusCdHeader.createCell(5);
		headerCell3.setCellValue("Country Name");
		
		Cell headerCell5 = indusCdHeader.createCell(6);
		headerCell5.setCellValue("Score Granularity Code");
		
		Cell headerCell6 = indusCdHeader.createCell(7);
		headerCell6.setCellValue("Score Granularity Description");
		
		Cell headerCell24 = indusCdHeader.createCell(8);
		headerCell24.setCellValue("Product ID");
		
		Cell headerCell25 = indusCdHeader.createCell(9);
		headerCell25.setCellValue("Product Code");

		Cell headerCell26 = indusCdHeader.createCell(10);
		headerCell26.setCellValue("Product Code Description");

		Cell headerCell27 = indusCdHeader.createCell(11);
		headerCell27.setCellValue("Product MetaData Code");
		
		Cell headerCell28 = indusCdHeader.createCell(12);
		headerCell28.setCellValue("Product Metadata Code Description");
		
		Cell headerCell29 = indusCdHeader.createCell(13);
		headerCell29.setCellValue("Product Metadata Code Value");
		
		Cell headerCell30 = indusCdHeader.createCell(14);
		headerCell30.setCellValue("Product Group Code");
		
		Cell headerCell31 = indusCdHeader.createCell(15);
		headerCell31.setCellValue("Product Group Code Description");
		
		Cell headerCell32 = indusCdHeader.createCell(16);
		headerCell32.setCellValue("Product Version");
		
		Cell headerCell33 = indusCdHeader.createCell(17);
		headerCell33.setCellValue("Resource Code");
		
		Cell headerCell34 = indusCdHeader.createCell(18);
		headerCell34.setCellValue("Resource Code Description");

		Cell headerCell35 = indusCdHeader.createCell(19);
		headerCell35.setCellValue("Billing System Code");

		Cell headerCell36 = indusCdHeader.createCell(20);
		headerCell36.setCellValue("Resource MetaData Code");
		
		Cell headerCell37 = indusCdHeader.createCell(21);
		headerCell37.setCellValue("Resource Metadata Code Description");
		
		Cell headerCell38 = indusCdHeader.createCell(22);
		headerCell38.setCellValue("Resource Metadata Code Value");
		
		Cell headerCell39 = indusCdHeader.createCell(23);
		headerCell39.setCellValue("Resource Group Code");
		
		Cell headerCell43 = indusCdHeader.createCell(24);
		headerCell43.setCellValue("Resource Group Code Description");
		
		Cell headerCell40 = indusCdHeader.createCell(25);
		headerCell40.setCellValue("Resource Version");
		
		Cell headerCell41 = indusCdHeader.createCell(26);
		headerCell41.setCellValue("Product Country");

		Cell headerCell42 = indusCdHeader.createCell(27);
		headerCell42.setCellValue("Product Country Description");
		
		Cell headerCell44 = indusCdHeader.createCell(28);
		headerCell44.setCellValue("Market Group Code");
		
		Cell headerCell45 = indusCdHeader.createCell(29);
		headerCell45.setCellValue("Market Group Code Description");
		
		Cell headerCell46 = indusCdHeader.createCell(30);
		headerCell46.setCellValue("Delivery Channel Metadata Code");
		
		Cell headerCell47 = indusCdHeader.createCell(31);
		headerCell47.setCellValue("Delivery Channel Metadata Code Value");
		
		Cell headerCell48 = indusCdHeader.createCell(32);
		headerCell48.setCellValue("Delivery Channel Metadata Code Description");

	}
}

