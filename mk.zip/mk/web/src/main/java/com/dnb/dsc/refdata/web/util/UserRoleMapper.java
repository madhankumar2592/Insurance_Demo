/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dnb.dsc.refdata.core.entity.UserGroupMapping;
import com.dnb.dsc.refdata.core.vo.UserRoleVO;
import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;


/**
 * The utility class for mapping the user roles. The values will be based on the
 * logged in user details retrieved through OAM.
 * 
 * @author Cognizant
 * @version last updated : Apr 19, 2012
 * @see
 * 
 */
@Component
public class UserRoleMapper {
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(UserRoleMapper.class);
	
	@Autowired
	private GeographyWebServiceProxy wsProxy;
		
	/**
	 * 
	 * The method to identify the approver user group for a particular domain. 
	 * Approver user group should be decided based on the domain. Please find 
	 * the logic below
	 * 
	 * If Domain = Geography and Country updated is �US� 
	 * Then Approver User Group = US Geo Approver 
	 * Else If Domain = Geography and Country updated is �UK� 
	 * Then Approver User Group = UK/IRE Geo Approver 
	 * Else If Domain = Geography and Country updated is �CA� 
	 * Then Approver User Group = CA Geo Approver 
	 * Else If Domain = Geography Then Approver User Group = ROW Geo Approver 
	 * Else If Domain = Currency Then Approver User Group = Currency Approver 
	 * Else If Domain = SCoTS Then Approver User Group = SCoTS Approver
	 * Else If Domain = Industry Codes Then Approver User Group = Industry Approver 
	 * Else If Domain = Financial Template and Country updated is �US�
	 * Then Approver User Group = US FT Approver 
	 * Else If Domain = Financial Template and Country updated is �CA� 
	 * Then Approver User Group = CA FT Approver 
	 * Else If Domain = Financial Template and Country updated is �UK�
	 * Then Approver User Group = UK FT Approver 
	 * Else If Domain = Financial Template and Country updated is �IR� 
	 * Then Approver User Group = IRE FT Approver 
	 * Else If Domain = Financial Template 
	 * Then Approver User Group = Global FT Approver 
	 * Else If Domain = Control Words Then Approver User Group = CW Approver 
	 * Else If Domain = GSRL Literals Then Approver User Group = GL Approver 
	 * End If 
	 * 
	 * @param submitterUserGroup
	 * @return approverGroupId
	 */
	public Long getApproverUserGroupId(String submitterUserGroup) {
		LOGGER.info("entering UserRoleMapper | getApproverUserGroupId");
		LOGGER.info("submitterUserGroup: " + submitterUserGroup);
		Long approverGroupId = 0L;
		/*
		 * The userGroupMappings will be cached on server startup. Iterate
		 * through the mappings and identify the mapping corresponding to the
		 * submitterUserGroup.
		 */
		List<UserGroupMapping> groupMappings = convertToUserGroupMapping(
				wsProxy.retrieveAllUserGroupMappings().iterator());		
		for(UserGroupMapping groupMapping : groupMappings) {
			if(groupMapping.getGroupName().equals(submitterUserGroup)) {
				approverGroupId = groupMapping.getApproverGroupId();
				break;
			}
		}
		
		LOGGER.info("approverGroupId: " + approverGroupId);
		return approverGroupId;
	}

	/**
	 * 
	 * The method to retrieve the approver user group id with the submitter user
	 * group id as the input argument.
	 * 
	 * @param submitterUserGroupId
	 * @return approverGroupId
	 */
	public Long getApproverUserGroupId(Long submitterUserGroupId) {
		LOGGER.info("entering UserRoleMapper | getApproverUserGroupId");
		LOGGER.info("submitterUserGroupId: " + submitterUserGroupId);
		Long approverGroupId = 0L;
		/*
		 * The userGroupMappings will be cached on server startup. Iterate
		 * through the mappings and identify the mapping corresponding to the
		 * submitterUserGroup.
		 */
		List<UserGroupMapping> groupMappings = convertToUserGroupMapping(
				wsProxy.retrieveAllUserGroupMappings().iterator());		
		for(UserGroupMapping groupMapping : groupMappings) {
			if(groupMapping.getGroupIdentifier().equals(submitterUserGroupId)) {
				approverGroupId = groupMapping.getApproverGroupId();
				break;
			}
		}
		
		LOGGER.info("approverGroupId: " + approverGroupId);
		return approverGroupId;
	}
	
	/**
	 * 
	 * The method to identify the approver user group for a particular domain 
	 * and the domain identifier. Approver user group should be decided based 
	 * on the domain and the data that is being updated. Please find the logic 
	 * below
	 * 
	 * If Domain = Geography and Country updated is �US� 
	 * Then Approver User Group = US Geo Approver 
	 * Else If Domain = Geography and Country updated is �UK� 
	 * Then Approver User Group = UK/IRE Geo Approver 
	 * Else If Domain = Geography and Country updated is �CA� 
	 * Then Approver User Group = CA Geo Approver 
	 * Else If Domain = Geography Then Approver User Group = ROW Geo Approver 
	 * Else If Domain = Currency Then Approver User Group = Currency Approver 
	 * Else If Domain = SCoTS Then Approver User Group = SCoTS Approver
	 * Else If Domain = Industry Codes Then Approver User Group = Industry Approver 
	 * Else If Domain = Financial Template and Country updated is �US�
	 * Then Approver User Group = US FT Approver 
	 * Else If Domain = Financial Template and Country updated is �CA� 
	 * Then Approver User Group = CA FT Approver 
	 * Else If Domain = Financial Template and Country updated is �UK�
	 * Then Approver User Group = UK FT Approver 
	 * Else If Domain = Financial Template and Country updated is �IR� 
	 * Then Approver User Group = IRE FT Approver 
	 * Else If Domain = Financial Template 
	 * Then Approver User Group = Global FT Approver 
	 * Else If Domain = Control Words Then Approver User Group = CW Approver 
	 * Else If Domain = GSRL Literals Then Approver User Group = GL Approver 
	 * End If 
	 * 
	 * @param domainName
	 * @param domainIdentifier
	 * @return approverGroupId
	 */
	public Long getApproverUserGroupId(String domainName, Long domainIdentifier){
		LOGGER.info("entering UserRoleMapper | getApproverUserGroupId");
		LOGGER.info("UserRoleMapper | getApproverUserGroupId | domainName: " 
				+ domainName + " | domainIdentifier: " + domainIdentifier);
		Long approverGroupId = 0L;
		/*
		 * The userGroupMappings will be cached on server startup. Iterate
		 * through the mappings and identify the mapping corresponding to the
		 * domainName and identifier.
		 */
		List<UserGroupMapping> groupMappings = convertToUserGroupMapping(
				wsProxy.retrieveAllUserGroupMappings().iterator());
		for(UserGroupMapping groupMapping : groupMappings) {
			if (groupMapping.getDomainName().equals(domainName)
					&& domainIdentifier.equals(groupMapping.getDomainIdentifier()) 
					&& groupMapping.getIsApprover()) {
				approverGroupId = groupMapping.getGroupIdentifier();
				break;
			}
		}
		
		LOGGER.info("UserRoleMapper | getApproverUserGroupId | approverGroupId: " + approverGroupId);
		return approverGroupId;
	}
	
	/**
	 * 
	 * The method to identify the submiiter user group for a particular domain.
	 * Submitter user group should be decided based on the domain and the data
	 * that is being updated. Please find the logic below
	 *
	 * @param domainName
	 * @param domainIdentifier
	 * @return submitterUserGroupId
	 */
	public Long getSubmitterUserGroupId(String domainName, Long domainIdentifier) {
		LOGGER.info("entering UserRoleMapper | getSubmitterUserGroupId");
		LOGGER.info("UserRoleMapper | getSubmitterUserGroupId | domainName: " + 
				domainName + " | domainIdentifier: " + domainIdentifier);
		Long submitterGroupId = 0L;
		/*
		 * The userGroupMappings will be cached on server startup. Iterate
		 * through the mappings and identify the mapping corresponding to the
		 * domainName and identifier.
		 */
		List<UserGroupMapping> groupMappings = convertToUserGroupMapping(
				wsProxy.retrieveAllUserGroupMappings().iterator());
		for(UserGroupMapping groupMapping : groupMappings) {
			if(groupMapping.getDomainName().equals(domainName) 
					&& domainIdentifier.equals(groupMapping.getDomainIdentifier())
					&& !groupMapping.getIsApprover()) {
				submitterGroupId = groupMapping.getGroupIdentifier();
				break;
			}
		}
		
		LOGGER.info("UserRoleMapper | getSubmitterUserGroupId | submitterGroupId: " + submitterGroupId);
		return submitterGroupId;
	}
	
	/**
	 * 
	 * The method to convert the LinkedHashMap list to the list of UserGroupMapping
	 *
	 * @param itr
	 * @return groupMappings
	 */
	@SuppressWarnings("rawtypes")
	private List<UserGroupMapping> convertToUserGroupMapping(Iterator itr) {
		List<UserGroupMapping> groupMappings = new ArrayList<UserGroupMapping>();
		while (itr.hasNext()) {
			UserGroupMapping groupMapping = new UserGroupMapping();
			LinkedHashMap usrGrpMap = (LinkedHashMap) itr.next();
			groupMapping.setGroupIdentifier(Long.valueOf((Integer) usrGrpMap.get("groupIdentifier")));
			groupMapping.setGroupName(String.valueOf( usrGrpMap.get("groupName")));
			groupMapping.setDomainName(String.valueOf( usrGrpMap.get("domainName")));
			if(usrGrpMap.get("domainIdentifier") != null) {
				groupMapping.setDomainIdentifier(Long.valueOf((Integer) usrGrpMap.get("domainIdentifier")));
			}
			if(usrGrpMap.get("approverGroupId") != null) {
				groupMapping.setApproverGroupId(Long.valueOf((Integer) usrGrpMap.get("approverGroupId")));
			}
			groupMapping.setIsApprover(Boolean.valueOf((Boolean) usrGrpMap.get("isApprover")));
			
			groupMappings.add(groupMapping);
		}
		return groupMappings;
	}

	/**
	 * 
	 * The method to retrieve the users groupIds. The search will be based on
	 * the parameter isApproverOnlyRequired. If true then the method will return
	 * only the approver user groups entitled to the user. Else will return only
	 * the submitter user roles.
	 * 
	 * @param domainName
	 * @param userRoleVOs
	 * @param isApproverOnlyRequired
	 * @return userGroupIds
	 */
	public List<Integer> getAllGroupIdsForUser(String domainName,
			List<UserRoleVO> userRoleVOs, Boolean isApproverOnlyRequired) {
		LOGGER.info("entering UserRoleMapper | getAllGroupsForUser");
		LOGGER.info("userRoleVOs: " + userRoleVOs + " | isApproverOnlyRequired: " + isApproverOnlyRequired);
		
		List<Integer> userGroupIds = new ArrayList<Integer>();
		List<String> userGroupNames = getAllGroupNamesForUser(userRoleVOs);
		List<UserGroupMapping> groupMappings = convertToUserGroupMapping(
				wsProxy.retrieveAllUserGroupMappings().iterator());
		
		for(UserGroupMapping groupMapping : groupMappings) {
			if (userGroupNames.contains(groupMapping.getGroupName())
					&& domainName.equals(groupMapping.getDomainName())
					&& groupMapping.getIsApprover().equals(isApproverOnlyRequired)) {
				userGroupIds.add(groupMapping.getGroupIdentifier().intValue());
			}
		}
		
		LOGGER.info("userGroupIds : " + userGroupIds);
		LOGGER.info("exiting UserRoleMapper | getAllGroupsForUser");
		return userGroupIds;
	}
	/**
	 * 
	 * The method to return the users available group names.
	 *
	 * @param userRoleVOs
	 * @return userGroupNames
	 */
	public List<String> getAllGroupNamesForUser(List<UserRoleVO> userRoleVOs) {
		List<String> userGroupNames = new ArrayList<String>();
		
		for(UserRoleVO userRoleVO : userRoleVOs) {
			userGroupNames.add(userRoleVO.getRoleCode());
		}
		LOGGER.info("userGroupNames : " + userGroupNames);
		return userGroupNames;
	}

	/**
	 * 
	 * The method to identify whether the logged in user is having any approver
	 * role. the method is basically used for the Control Words domain where we
	 * need the user role identifier while creating a request. This is required
	 * for auto approver functionality.
	 * 
	 * @param domainName
	 * @param userRoleVOs
	 * @return hasApproverRole
	 * 
	 */
	public Boolean hasDomainApproverRoleForUser(String domainName, List<UserRoleVO> userRoleVOs) {		
		Boolean hasApproverRole = false;
		List<UserGroupMapping> groupMappings = convertToUserGroupMapping(
				wsProxy.retrieveAllUserGroupMappings().iterator());
		
		List<String> domainApproverIds =  new ArrayList<String>();
		for(UserGroupMapping groupMapping : groupMappings) {
			if (domainName.equals(groupMapping.getDomainName())
					&& groupMapping.getIsApprover()) {
				domainApproverIds.add(groupMapping.getGroupName());
			}
		}
		
		for(UserRoleVO userRoleVO : userRoleVOs) {
			if(domainApproverIds.contains(userRoleVO.getRoleCode())) {
				hasApproverRole = true;
				break;
			}
		}
		LOGGER.info("UserRoleMapper | hasDomainApproverRoleForUser : " + hasApproverRole);
		return hasApproverRole;
	}
	
	/**
	 * 
	 * The method to identify the roles that an user has based on the domain
	 *
	 * @param domainName
	 * @param userRoleVOs
	 * @return
	 */
	public List<String> findDomainUserRoles(String domainName, List<UserRoleVO> userRoleVOs) {
		List<UserGroupMapping> groupMappings = convertToUserGroupMapping(
				wsProxy.retrieveAllUserGroupMappings().iterator());
		
		List<String> groupNames =  new ArrayList<String>();
		for(UserGroupMapping groupMapping : groupMappings) {
			if (domainName.equals(groupMapping.getDomainName())) {
				groupNames.add(groupMapping.getGroupName());
			}
		}
		
		List<String> userRoles =  new ArrayList<String>();
		for(UserRoleVO userRoleVO : userRoleVOs) {
			if(groupNames.contains(userRoleVO.getRoleCode())) {
				userRoles.add(userRoleVO.getRoleCode());
			}
		}
		LOGGER.info("UserRoleMapper | findDomainUserRoles : " + userRoles);
		return userRoles;
	}
}
