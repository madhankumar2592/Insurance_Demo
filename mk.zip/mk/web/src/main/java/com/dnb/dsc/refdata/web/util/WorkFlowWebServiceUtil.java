/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.util;

import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc_wrkflow_req.DSCWRKFLWWSREQTYP;
import com.dnb.dsc_wrkflow_rsp.DSCWRKFLWWSRSPTYP;
import com.dnb.dscwkflwservice.DSCWKFlwPortType;
import com.dnb.dscwkflwservice.DSCWkFlwService;
import com.dnb.wrkflwcommon.BLKUPLDPAYLTYP;
import com.dnb.wrkflwcommon.BLKUPLDPRCSINSTNTYP;
import com.dnb.wrkflwcommon.GRPIDLSTDATATYP;
import com.dnb.wrkflwcommon.GRPIDLSTDTLTYP;
import com.dnb.wrkflwcommon.REALTMEPRCSINSTNTYP;
import com.dnb.wrkflwcommon.REALTMETRXPAYLTYP;
import com.dnb.wrkflwcommon.TSKASGLSTTYP;
import com.dnb.wrkflwcommon.TSKASGTYP;
import com.dnb.wrkflwcommon.TSKPAYLTYP;
import com.dnb.wrkflwcommon.TSKTYP;

/**
 * The utility class for the work-flow web service integration.
 * 
 * @author Cognizant
 * @version last updated : Mar 8, 2012
 * @see
 * 
 */
@Component
public class WorkFlowWebServiceUtil {

	private static final Logger LOGGER = LoggerFactory
	.getLogger(WorkFlowWebServiceUtil.class);
	
	@Autowired
	private RefDataConfigUtil refDataConfigUtil;

	/**
	 * 
	 * The method to retrieve the port type for the workFlow web service invocation
	 *
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public DSCWKFlwPortType getPortType() throws MalformedURLException, ServiceException {
		URL url = new URL(refDataConfigUtil.getRefDataProperty(RefDataPropertiesConstants.REFDATA_WORKFLOW_SERVICE_URL));
		DSCWkFlwService serviceLocator = new DSCWkFlwService(url);
		DSCWKFlwPortType portType = serviceLocator.getDSCWkFlwBinding();
		return portType;
	}
	/**
	 * 
	 * The method to parse the response for the task lists from the workflow.
	 *
	 * @param response
	 * @return taskList
	 */
	private DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST parseResponse(
			DSCWRKFLWWSRSPTYP response) {
		DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1 msg = response.getWRKFLWMSGSRSV1();
		if (msg == null) {
			return null;
		}
		DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS msgUpdSet = msg.getSUBJUPDTRNRS();
		if (msgUpdSet == null) {
			return null;
		}
		DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS msgUpd = msgUpdSet.getSUBJUPDRS();
		if (msgUpd == null) {
			return null;
		}
		DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA payloadData = msgUpd.getWRKFLWPAYLDATA();
		if (payloadData == null) {
			return null;
		}
		DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST taskList = payloadData
				.getTSKLST();
		if (taskList == null) {
			return null;
		}
		return payloadData.getTSKLST();
	}

	/**
	 * 
	 * The method to retrieve the task lists from the workflow.
	 *
	 * @param domainName
	 * @param userEmailAddress
	 * @param userRoleId
	 * @param userGroupId
	 * @param typeId
	 * @param approverGroupIds
	 * @return
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST getTaskList(String domainName, String userEmailAddress,
										int userRoleId, int userGroupId, int typeId, List<Integer> approverGroupIds)
						throws RemoteException, MalformedURLException, ServiceException{
		return parseResponse(executeWorkflowRequest(prepareGetTasksRequest
				(domainName, userEmailAddress,userRoleId, userGroupId, typeId, approverGroupIds, null)));
	}
	/**
	 * 
	 * The method to retrieve the history list for the task
	 *
	 * @param domainName
	 * @param userEmailAddress
	 * @param userRoleId
	 * @param userGroupId
	 * @param typeId
	 * @param approverGroupIds
	 * @param trackingId
	 * @return
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public DSCWRKFLWWSRSPTYP.WRKFLWMSGSRSV1.SUBJUPDTRNRS.SUBJUPDRS.WRKFLWPAYLDATA.TSKLST getTaskHistoryList(
			String domainName, String userEmailAddress, Long userRoleId, int userGroupId, long typeId,
			List<Integer> approverGroupIds, long trackingId) throws RemoteException, MalformedURLException,
			ServiceException {
		return parseResponse(executeWorkflowRequest(prepareGetTaskHistoryRequest(
				domainName, userEmailAddress, userRoleId, userGroupId, typeId,
				approverGroupIds, trackingId)));
	}

	/**
	 * 
	 * The method to populate the re-submit task request
	 *
	 * @param submitterId
	 * @param submitterGroupId
	 * @param taskId
	 * @return request
	 */
	public DSCWRKFLWWSREQTYP prepareReSubmitTaskRequest(String submitterId, int submitterGroupId,
				int taskId) {
        LOGGER.info(
        		" prepareReSubmitTaskRequest : " +
        		" submitterId : " + submitterId +
        		" submitterGroupId : " + submitterGroupId + 
        		" taskId : " + taskId
        );
		DSCWRKFLWWSREQTYP request = new DSCWRKFLWWSREQTYP();
		// Sign-On Request Message Set
		request.setSIGNONMSGSRQV1(populateSignOnReqMsgSet());

		// Request Payload
		// Transaction Message Request Set
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1 trxMsgRequestSet = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1();
		// Transaction Request
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ trxRequest = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ();
		// Transaction Request Message
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ trxRequestMsg = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ();
		trxRequestMsg.setWRKFLWPAYLHDR(populateWrkFlwPayloadHeader(
				RefDataUIConstants.WRKFLW_PROCESS_NME_ID_TRAN_PROC, RefDataUIConstants.WRKFLW_REQ_TYPE_ID_PERFORM_TASK, null,
				submitterId, RefDataUIConstants.WRKFLW_USER_ROLE_ID_SUBMITTER, submitterGroupId));

		// payload Data
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA payloadData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA();
		// Task Status Data
		payloadData.setTSKSTAT(populatePayLoadDataTaskStatus(RefDataUIConstants.WRKFLW_TASK_STAT_TYP_ID_801,
				Long.valueOf(taskId)));
		trxRequestMsg.setWRKFLWPAYLDATA(payloadData);

		trxRequest.setSUBJUPDRQ(trxRequestMsg);
        trxRequest.setTRNUID("" + System.currentTimeMillis());

		trxMsgRequestSet.setSUBJUPDTRNRQ(trxRequest);

		request.setWRKFLWMSGSRQV1(trxMsgRequestSet);
		return request;
	}

	/**
	 * 
	 * The method to retrieve the task details
	 *
	 * @param domainName
	 * @param userEmailAddress
	 * @param userRoleId
	 * @param userGroupId
	 * @param taskType
	 * @param approverGroupIds
	 * @param trackingId
	 * @return
	 */
	public DSCWRKFLWWSREQTYP prepareGetTasksRequest(String domainName,
			String userEmailAddress, int userRoleId, int userGroupId,
			int taskType, List<Integer> approverGroupIds, Long trackingId) {
		
        LOGGER.info(
        		" prepareGetTasksRequest : " +
        		" domainName : " + domainName +
        		" userEmailAddress : " + userEmailAddress + 
        		" userRoleId : " + userRoleId +
        		" userGroupId : " + userGroupId +
        		" taskType : " + taskType +
        		" approverGroupIds : " + approverGroupIds
        );
		
		DSCWRKFLWWSREQTYP request = new DSCWRKFLWWSREQTYP();
		// Sign-On Request Message Set
		request.setSIGNONMSGSRQV1(populateSignOnReqMsgSet());

		// Request Payload
		// Transaction Message Request Set
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1 trxMsgRequestSet = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1();
		// Transaction Request
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ trxRequest = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ();
		// Transaction Request Message
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ trxRequestMsg = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ();
		trxRequestMsg.setWRKFLWPAYLHDR(populateWrkFlwPayloadHeader(RefDataUIConstants.WRKFLW_PROCESS_NME_ID_TRAN_PROC,
				RefDataUIConstants.WRKFLW_REQ_TYPE_ID_GET_TASK_LIST, trackingId, userEmailAddress, Long.valueOf(userRoleId),
				userGroupId));

		// payload Data
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA payloadData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA();
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKLST taskList = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKLST();
		taskList.setTSKLSTTYPID(BigInteger.valueOf(taskType));
		taskList.setDOMNNME(domainName);
		GRPIDLSTDATATYP groupIdListDataType = new GRPIDLSTDATATYP();
		List<GRPIDLSTDTLTYP> groupIdListData = new ArrayList<GRPIDLSTDTLTYP>();
		
		GRPIDLSTDTLTYP groupIdListDetail = null;
		for(Integer currId : approverGroupIds){
			groupIdListDetail = new GRPIDLSTDTLTYP();
			groupIdListDetail.setGRPID(BigInteger.valueOf(currId));
			groupIdListData.add(groupIdListDetail);
		}
		groupIdListDataType.getGRPIDLSTDTL().addAll(groupIdListData);
		taskList.setGRPIDLSTDATA(groupIdListDataType);

		payloadData.setTSKLST(taskList);

		trxRequestMsg.setWRKFLWPAYLDATA(payloadData);

		trxRequest.setSUBJUPDRQ(trxRequestMsg);
        trxRequest.setTRNUID("" + System.currentTimeMillis());
		trxMsgRequestSet.setSUBJUPDTRNRQ(trxRequest);

		request.setWRKFLWMSGSRQV1(trxMsgRequestSet);
		return request;
	}
	/**
	 * 
	 * The method to get the task history details
	 *
	 * @param domainName
	 * @param userEmailAddress
	 * @param userRoleId
	 * @param userGroupId
	 * @param taskType
	 * @param approverGroupIds
	 * @param trackingId
	 * @return
	 */
	public DSCWRKFLWWSREQTYP prepareGetTaskHistoryRequest(String domainName,
			String userEmailAddress, Long userRoleId, int userGroupId,
			Long taskType, List<Integer> approverGroupIds,long trackingId) {
		
        LOGGER.info(
        		" prepareGetTasksRequest : " +
        		" domainName : " + domainName +
        		" userEmailAddress : " + userEmailAddress + 
        		" userRoleId : " + userRoleId +
        		" userGroupId : " + userGroupId +
        		" taskType : " + taskType +
        		" approverGroupIds : " + approverGroupIds
        );
		return prepareGetTasksRequest(domainName, userEmailAddress, userRoleId.intValue(), userGroupId,
				taskType.intValue(), approverGroupIds, trackingId);
        }
	/**
	 * 
	 * The method is invoked to create a new task with work-flow. When ever a
	 * reference data update happens the method is invoked with the required
	 * input attributes and the method will invoke the webServices to create a
	 * new task with the work-flow.
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param submitterEmailAddress
	 * @param submitterGroupId
	 * @param approverGroupId
	 * @param notes
	 * @param userRoleId
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public void createProcessInstance(String domainId, 
			String domainName, long changeType, String submitterEmailAddress,
			int submitterGroupId, int approverGroupId, String notes, Long userRoleId) 
		throws RemoteException, MalformedURLException, ServiceException {
		executeWorkflowRequest(
				prepareCreateProcessInstanceRequest(domainId, 
						domainName, changeType, submitterEmailAddress, 
						submitterGroupId, approverGroupId, notes, userRoleId)
		);
	}
	
	/**
	 * 
	 * The method is invoked to create a new task with work-flow. When ever a
	 * currency bulk upload reference data happens, the method is invoked with the required
	 * input attributes and the method will invoke the webServices to create a
	 * new task with the work-flow.
	 * 
	 * 
	 * @param domainId
	 * @param domainName
	 * @param changeTypeId
	 * @param submitterEmailAddress
	 * @param fileName
	 * @param submitterGroupId
	 * @param approverGroupId
	 * @param notes
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public void createProcessCurrencyBulkUploadInstance(String domainId, 
			String domainName, long changeType, String submitterEmailAddress,
			String fileName, int submitterGroupId, int approverGroupId, String notes) 
		throws RemoteException, MalformedURLException, ServiceException {
		executeWorkflowRequest(prepareCreateCurrencyBulkUploadProcessInstanceRequest(
				domainId, domainName, changeType, submitterEmailAddress, fileName,
						submitterGroupId, approverGroupId, notes)
		);
	}
	
	/**
	 * 
	 * The method is invoked to create a new task with work-flow. When ever a
	 * currency bulk upload reference data happens, the method is invoked with the required
	 * input attributes and the method will invoke the webServices to create a
	 * new task with the work-flow.
	 * 
	 * 
	 * @param domainId
	 * @param domainName
	 * @param changeTypeId
	 * @param submitterEmailAddress
	 * @param fileName
	 * @param submitterGroupId
	 * @param approverGroupId
	 * @param notes
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public void createProcessIndustryCodeBulkUploadInstance(String domainId, 
			String domainName, long changeType, String submitterEmailAddress,
			String fileName, int submitterGroupId, int approverGroupId, String notes) 
		throws RemoteException, MalformedURLException, ServiceException {
		executeWorkflowRequest(prepareCreateIndustryCodeBulkUploadProcessInstanceRequest(
				domainId, domainName, changeType, submitterEmailAddress, fileName,
						submitterGroupId, approverGroupId, notes)
		);
	}
	/**
	 * 
	 * The method to construct the create process request.
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param submitterEmailAddress
	 * @param submitterGroupId
	 * @param approverGroupId
	 * @param notes
	 * @param userRoleId
	 * @return DSCWRKFLWWSREQTYP
	 */
	public DSCWRKFLWWSREQTYP prepareCreateProcessInstanceRequest(String domainId, 
				String domainName, long changeType, String submitterEmailAddress,
				int submitterGroupId, int approverGroupId, String notes, Long userRoleId) {	

        LOGGER.info(
        		" prepareCreateProcessInstanceRequest : " +
        		" domainId : " + domainId +
        		" domainName : " + domainName +
        		" changeType : " + changeType +
        		" submitterEmailAddress : " + submitterEmailAddress + 
        		" submitterGroupId : " + submitterGroupId +
        		" approverGroupId : " + approverGroupId +
        		" notes : " + notes +
        		" userRoleId : " + userRoleId
        );
        
		DSCWRKFLWWSREQTYP request = new DSCWRKFLWWSREQTYP();
		// Sign-On Request Message Set
		request.setSIGNONMSGSRQV1(populateSignOnReqMsgSet());

		// Request Payload
		// Transaction Message Request Set
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1 trxMsgRequestSet = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1();
		// Transaction Request
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ trxRequest = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ();
		// Transaction Request Message
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ trxRequestMsg = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ();
		trxRequestMsg.setWRKFLWPAYLHDR(populateWrkFlwPayloadHeader(RefDataUIConstants.WRKFLW_PROCESS_NME_ID_TRAN_PROC,
				RefDataUIConstants.WRKFLW_REQ_TYPE_ID_CREATE_PROCESS_INSTANCE, null, submitterEmailAddress,
				userRoleId, submitterGroupId));

		// payload Data
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA payloadData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA();
		// Process Data
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.PRCSDATA processData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.PRCSDATA();
		// Real Time Transaction Data
		processData.setREALTMETRXDATA(populateRealTimeTxnPayloadType(
				domainName, domainId, changeType, notes, approverGroupId));

		payloadData.setPRCSDATA(processData);
		trxRequestMsg.setWRKFLWPAYLDATA(payloadData);

		trxRequest.setSUBJUPDRQ(trxRequestMsg);
		trxRequest.setTRNUID("" + System.currentTimeMillis());
		trxMsgRequestSet.setSUBJUPDTRNRQ(trxRequest);
		request.setWRKFLWMSGSRQV1(trxMsgRequestSet);
		return request;
	}

	/**
	 * 
	 * The method to construct the create process request for currency bulk upload.
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param submitterEmailAddress
	 * @param fileName
	 * @param submitterGroupId
	 * @param approverGroupId
	 * @param notes
	 * @return DSCWRKFLWWSREQTYP
	 */
	public DSCWRKFLWWSREQTYP prepareCreateCurrencyBulkUploadProcessInstanceRequest(String domainId, 
				String domainName, long changeType, String submitterEmailAddress,String fileName,
				int submitterGroupId, int approverGroupId, String notes) {	
        
		DSCWRKFLWWSREQTYP request = new DSCWRKFLWWSREQTYP();
		// Sign-On Request Message Set
		request.setSIGNONMSGSRQV1(populateSignOnReqMsgSet());

		// Request Payload
		// Transaction Message Request Set
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1 trxMsgRequestSet = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1();
		// Transaction Request
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ trxRequest = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ();
		// Transaction Request Message
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ trxRequestMsg = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ();
		trxRequestMsg.setWRKFLWPAYLHDR(populateWrkFlwPayloadHeader(
				RefDataUIConstants.WRKFLW_CRCY_BULK_UPLOAD_PROCESS_NME_ID_TRAN_PROC,
				RefDataUIConstants.WRKFLW_REQ_TYPE_ID_CREATE_PROCESS_INSTANCE, null, submitterEmailAddress,
				RefDataUIConstants.WRKFLW_USER_ROLE_ID_SUBMITTER, submitterGroupId));

		// payload Data
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA payloadData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA();
		// Process Data
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.PRCSDATA processData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.PRCSDATA();
		BLKUPLDPAYLTYP bulkUploadPayLoad = new BLKUPLDPAYLTYP();
		BLKUPLDPRCSINSTNTYP bulkUploadPrcsInstntType = new BLKUPLDPRCSINSTNTYP();
		bulkUploadPrcsInstntType.setAPRVGRPID(BigInteger.valueOf(approverGroupId));
		bulkUploadPrcsInstntType.setCHGTYP(changeType);
		bulkUploadPrcsInstntType.setDOMNID(domainId);
		bulkUploadPrcsInstntType.setDOMNNME(domainName);
		bulkUploadPrcsInstntType.setINPFLENME(fileName);
		bulkUploadPrcsInstntType.setNOTES(notes);
		//bulkUploadPrcsInstntType.setPRCSINSTNID(RefDataUIConstants.WRKFLW_CRCY_BULK_UPLOAD_PROCESS_NME_ID_TRAN_PROC);
		bulkUploadPayLoad.setBLKUPLDPRCSINSTNPAYL(bulkUploadPrcsInstntType);
		processData.setBLKUPLDDATA(bulkUploadPayLoad);
		
		// Real Time Transaction Data
		processData.setREALTMETRXDATA(populateRealTimeTxnPayloadType(
				domainName, domainId, changeType, notes, approverGroupId));

		payloadData.setPRCSDATA(processData);
		trxRequestMsg.setWRKFLWPAYLDATA(payloadData);

		trxRequest.setSUBJUPDRQ(trxRequestMsg);
		trxRequest.setTRNUID("" + System.currentTimeMillis());
		trxMsgRequestSet.setSUBJUPDTRNRQ(trxRequest);
		request.setWRKFLWMSGSRQV1(trxMsgRequestSet);
		return request;
	}

	/**
	 * 
	 * The method is invoked when the user clicks on the approve button from the UI.
	 *
	 * @param taskId
	 * @param trackingId
	 * @param submitterEmailAddress
	 * @param submitterGroupId
	 * @param approverDecision
	 * @param approverComments
	 * @return
	 */
	public DSCWRKFLWWSREQTYP prepareCompleteTask(long taskId, long trackingId,
			String submitterEmailAddress, 
			int submitterGroupId, boolean approverDecision,
			String approverComments) {	

        LOGGER.info(
        		" prepareCompleteTask : " +
        		" taskId : " + taskId +
        		" trackingId : " + trackingId +
        		" submitterEmailAddress : " + submitterEmailAddress + 
        		" submitterGroupId : " + submitterGroupId +
        		" approverDecision : " + approverDecision +
        		" approverComments : " + approverComments
        );
        
		DSCWRKFLWWSREQTYP request = new DSCWRKFLWWSREQTYP();
		// Sign-On Request Message Set
		request.setSIGNONMSGSRQV1(populateSignOnReqMsgSet());

		// Request Payload
		// Transaction Message Request Set
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1 trxMsgRequestSet = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1();
		// Transaction Request
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ trxRequest = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ();
		// Transaction Request Message
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ trxRequestMsg = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ();
		trxRequestMsg.setWRKFLWPAYLHDR(populateWrkFlwPayloadHeader(RefDataUIConstants.WRKFLW_PROCESS_NME_ID_TRAN_PROC,
				RefDataUIConstants.WRKFLW_REQ_TYPE_ID_PERFORM_TASK, trackingId, submitterEmailAddress,
				RefDataUIConstants.WRKFLW_USER_ROLE_ID_APPROVER, submitterGroupId));

		// payload Data
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA payloadData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA();
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKSTAT taskStatus = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKSTAT();
		taskStatus.setTSKSTATTYPID(BigInteger
				.valueOf(RefDataUIConstants.WRKFLW_TASK_STAT_TYP_ID_COMPLETE));
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKSTAT.TSKSTATDATA taskStatusData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKSTAT.TSKSTATDATA();
		TSKPAYLTYP taskPayload = new TSKPAYLTYP();
		TSKTYP taskType = new TSKTYP();
		taskType.setAPRVDCSN(approverDecision);
		taskType.setREJREAS(approverComments);
		taskType.setTSKID(taskId);

		taskPayload.setTSKPAYL(taskType);
		taskStatusData.setSBMTTSKDATA(taskPayload);
		taskStatus.setTSKSTATDATA(taskStatusData);
		payloadData.setTSKSTAT(taskStatus);
		trxRequestMsg.setWRKFLWPAYLDATA(payloadData);

		trxRequest.setSUBJUPDRQ(trxRequestMsg);
		trxRequest.setTRNUID("" + System.currentTimeMillis());
		trxMsgRequestSet.setSUBJUPDTRNRQ(trxRequest);
		request.setWRKFLWMSGSRQV1(trxMsgRequestSet);
		return request;
	}

	/**
	 * 
	 * The method is invoked when the user clicks on the approve button from the UI.
	 *
	 * @param taskId
	 * @param workflowTrackingId
	 * @param submitterEmailAddress
	 * @param submitterGroupId
	 * @param approverDecision
	 * @param approverComments
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public void completeTask(long taskId, long workflowTrackingId,
			String submitterEmailAddress,
			int submitterGroupId, boolean approverDecision,
			String approverComments) throws RemoteException,
			MalformedURLException, ServiceException {
			executeWorkflowRequest(prepareCompleteTask(taskId, workflowTrackingId, submitterEmailAddress,
						submitterGroupId, approverDecision, approverComments)
		);
	}

	/**
	 * 
	 * The method is invoked when the user assigns a task to another user within the group
	 *
	 * @param taskIdArray
	 * @param submitterEmailAddress
	 * @param submitterRoleId
	 * @param submitterGroupId
	 * @param approverEmailAddress
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public void assignTasksToAnotherUser(int[] taskIdArray, String submitterEmailAddress,
			int submitterRoleId, int submitterGroupId, String approverEmailAddress) 
			throws RemoteException, MalformedURLException, ServiceException {
			executeWorkflowRequest(prepareAssignTasks(taskIdArray, submitterEmailAddress,
						submitterRoleId, submitterGroupId, approverEmailAddress, true)
		);
	}

	/**
	 * 
	 * The method to prepare for the assign task webservice call. The method is
	 * invoked when the user assigns a task to another user within the group
	 * 
	 * @param taskIdArray
	 * @param submitterEmailAddress
	 * @param submitterRoleId
	 * @param submitterGroupId
	 * @param approverEmailAddress
	 * @param isAssign
	 * @return
	 */
	public DSCWRKFLWWSREQTYP prepareAssignTasks(int[] taskIdArray,
			String submitterEmailAddress, int submitterRoleId,
			int submitterGroupId, String approverEmailAddress, boolean isAssign) {

        LOGGER.info(
        		" prepareAssignTasks : " +
        		" submitterEmailAddress : " + submitterEmailAddress + 
        		" submitterRoleId : " + submitterRoleId +
        		" submitterGroupId : " + submitterGroupId +
        		" approverEmailAddress : " + approverEmailAddress +
        		" isAssign : " + isAssign
        );
        
		DSCWRKFLWWSREQTYP request = new DSCWRKFLWWSREQTYP();
		// Sign-On Request Message Set
		request.setSIGNONMSGSRQV1(populateSignOnReqMsgSet());

		// Request Payload
		// Transaction Message Request Set
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1 trxMsgRequestSet = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1();
		// Transaction Request
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ trxRequest = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ();
		// Transaction Request Message
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ trxRequestMsg = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ();
		trxRequestMsg.setWRKFLWPAYLHDR(populateWrkFlwPayloadHeader(RefDataUIConstants.WRKFLW_PROCESS_NME_ID_TRAN_PROC,
				RefDataUIConstants.WRKFLW_REQ_TYPE_ID_504, null, submitterEmailAddress, Long.valueOf(submitterRoleId),
				submitterGroupId));

		// payload Data
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA payloadData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA();
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKASG taskAssignment = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKASG();
		if (isAssign) {
			taskAssignment.setTSKASGTYPID(BigInteger
					.valueOf(RefDataUIConstants.WRKFLW_TSK_ASG_TYP_ID_901));
		} else {
			taskAssignment.setTSKASGTYPID(BigInteger
					.valueOf(RefDataUIConstants.WRKFLW_TSK_ASG_TYP_ID_902));
		}

		TSKASGLSTTYP taskAssignmentType = new TSKASGLSTTYP();
		List<TSKASGTYP> taskAssignmentTypeArray = new ArrayList<TSKASGTYP>();
		TSKASGTYP currentTaskAssignmentType = null;

		for (int taskId : taskIdArray) {
			currentTaskAssignmentType = new TSKASGTYP();
			currentTaskAssignmentType.setTSKID(Long.valueOf(taskId));
			taskAssignmentTypeArray.add(currentTaskAssignmentType);
		}
		taskAssignmentType.getTSKASG().addAll(taskAssignmentTypeArray);
		taskAssignment.setTSKASGDATA(taskAssignmentType);
		taskAssignment.setTSKOWRID(approverEmailAddress);
		payloadData.setTSKASG(taskAssignment);
		trxRequestMsg.setWRKFLWPAYLDATA(payloadData);

		trxRequest.setSUBJUPDRQ(trxRequestMsg);
		trxRequest.setTRNUID("" + System.currentTimeMillis());
		trxMsgRequestSet.setSUBJUPDTRNRQ(trxRequest);
		request.setWRKFLWMSGSRQV1(trxMsgRequestSet);
		return request;
	}

	/**
	 * 
	 * The method is invoked when the user unassigns a task from his work queue.
	 *
	 * @param taskIdArray
	 * @param submitterEmailAddress
	 * @param submitterRoleId
	 * @param submitterGroupId
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public void unassignTasks(int[] taskIdArray, String submitterEmailAddress,
			int submitterRoleId, int submitterGroupId) throws RemoteException,
			MalformedURLException, ServiceException {
			executeWorkflowRequest(prepareAssignTasks(taskIdArray, submitterEmailAddress,
						submitterRoleId, submitterGroupId, null, false));
	}
	/**
	 * 
	 * The method is for resubmitted an already rejected task by the user
	 *
	 * @param submitterId
	 * @param submitterGroupId
	 * @param taskId
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public void reSubmitTaskRequest(String submitterId,
			int submitterGroupId, int taskId) 
							throws RemoteException, MalformedURLException, ServiceException{
			executeWorkflowRequest(prepareReSubmitTaskRequest(submitterId, submitterGroupId,taskId));
	}

	/**
	 * 
	 * The method to construct the create process request for currency bulk upload.
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param submitterEmailAddress
	 * @param fileName
	 * @param submitterGroupId
	 * @param approverGroupId
	 * @param notes
	 * @return DSCWRKFLWWSREQTYP
	 */
	public DSCWRKFLWWSREQTYP prepareCreateIndustryCodeBulkUploadProcessInstanceRequest(String domainId, 
				String domainName, long changeType, String submitterEmailAddress,String fileName,
				int submitterGroupId, int approverGroupId, String notes) {	

        LOGGER.info(
        		" prepareCreateIndustryCodeBulkUploadProcessInstanceRequest : " +
        		" domainId : " + domainId +
        		" domainName : " + domainName +
        		" changeType : " + changeType +
        		" submitterEmailAddress : " + submitterEmailAddress + 
        		" submitterGroupId : " + submitterGroupId +
        		" approverGroupId : " + approverGroupId +
        		" notes : " + notes
        );
        
		DSCWRKFLWWSREQTYP request = new DSCWRKFLWWSREQTYP();
		// Sign-On Request Message Set
		request.setSIGNONMSGSRQV1(populateSignOnReqMsgSet());

		// Request Payload
		// Transaction Message Request Set
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1 trxMsgRequestSet = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1();
		// Transaction Request
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ trxRequest = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ();
		// Transaction Request Message
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ trxRequestMsg = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ();
		trxRequestMsg.setWRKFLWPAYLHDR(populateWrkFlwPayloadHeader(
				RefDataUIConstants.WRKFLW_CRCY_BULK_UPLOAD_PROCESS_NME_ID_TRAN_PROC,
				RefDataUIConstants.WRKFLW_REQ_TYPE_ID_CREATE_PROCESS_INSTANCE, null, submitterEmailAddress,
				RefDataUIConstants.WRKFLW_USER_ROLE_ID_SUBMITTER, submitterGroupId));

		// payload Data
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA payloadData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA();
		// Process Data
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.PRCSDATA processData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.PRCSDATA();
		BLKUPLDPAYLTYP bulkUploadPayLoad = new BLKUPLDPAYLTYP();
		BLKUPLDPRCSINSTNTYP bulkUploadPrcsInstntType = new BLKUPLDPRCSINSTNTYP();
		bulkUploadPrcsInstntType.setAPRVGRPID(BigInteger.valueOf(approverGroupId));
		bulkUploadPrcsInstntType.setCHGTYP(changeType);
		bulkUploadPrcsInstntType.setDOMNID(domainId);
		bulkUploadPrcsInstntType.setDOMNNME(domainName);
		bulkUploadPrcsInstntType.setINPFLENME(fileName);
		bulkUploadPrcsInstntType.setNOTES(notes);
		//bulkUploadPrcsInstntType.setPRCSINSTNID(RefDataUIConstants.WRKFLW_CRCY_BULK_UPLOAD_PROCESS_NME_ID_TRAN_PROC);
		bulkUploadPayLoad.setBLKUPLDPRCSINSTNPAYL(bulkUploadPrcsInstntType);
		processData.setBLKUPLDDATA(bulkUploadPayLoad);
		
		// Real Time Transaction Data
		processData.setREALTMETRXDATA(populateRealTimeTxnPayloadType(
				domainName, domainId, changeType, notes, approverGroupId));
		payloadData.setPRCSDATA(processData);
		trxRequestMsg.setWRKFLWPAYLDATA(payloadData);
		trxRequest.setSUBJUPDRQ(trxRequestMsg);		
		trxRequest.setTRNUID("" + System.currentTimeMillis());
		trxMsgRequestSet.setSUBJUPDTRNRQ(trxRequest);
		request.setWRKFLWMSGSRQV1(trxMsgRequestSet);
		return request;
	}
	/**
	 * 
	 * The method is invoked to create a new task with work-flow. When ever a
	 * currency bulk upload reference data happens, the method is invoked with the required
	 * input attributes and the method will invoke the webServices to create a
	 * new task with the work-flow.
	 * 
	 * 
	 * @param domainId
	 * @param domainName
	 * @param changeTypeId
	 * @param submitterEmailAddress
	 * @param fileName
	 * @param submitterGroupId
	 * @param approverGroupId
	 * @param notes
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public void createProcessGeographyBulkUploadInstance(String domainId, 
			String domainName, long changeType, String submitterEmailAddress,
			String fileName, int submitterGroupId, int approverGroupId, String notes) 
		throws RemoteException, MalformedURLException, ServiceException {
		executeWorkflowRequest(prepareCreateGeographyBulkUploadProcessInstanceRequest(
				domainId, domainName, changeType, submitterEmailAddress, fileName,
						submitterGroupId, approverGroupId, notes)
		);
	}
	
	/**
	 * 
	 * The method to construct the create process request for currency bulk upload.
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param submitterEmailAddress
	 * @param fileName
	 * @param submitterGroupId
	 * @param approverGroupId
	 * @param notes
	 * @return DSCWRKFLWWSREQTYP
	 */
	public DSCWRKFLWWSREQTYP prepareCreateGeographyBulkUploadProcessInstanceRequest(String domainId, 
				String domainName, long changeType, String submitterEmailAddress,String fileName,
				int submitterGroupId, int approverGroupId, String notes) {	

        LOGGER.info(
        		" prepareCreateIndustryCodeBulkUploadProcessInstanceRequest : " +
        		" domainId : " + domainId +
        		" domainName : " + domainName +
        		" changeType : " + changeType +
        		" submitterEmailAddress : " + submitterEmailAddress + 
        		" submitterGroupId : " + submitterGroupId +
        		" approverGroupId : " + approverGroupId +
        		" notes : " + notes
        );
		return prepareCreateIndustryCodeBulkUploadProcessInstanceRequest(domainId, domainName, changeType,
				submitterEmailAddress, fileName, submitterGroupId, approverGroupId, notes);
	}
	
	/**
	 * 
	 * The method to populate the signOnReqMsgSet for the WorkFlow service request.
	 *
	 * @return signOnReqMsgSet
	 */
	private DSCWRKFLWWSREQTYP.SIGNONMSGSRQV1 populateSignOnReqMsgSet() {
		// Sign-On Request Message Set
		DSCWRKFLWWSREQTYP.SIGNONMSGSRQV1 signOnReqMsgSet = new DSCWRKFLWWSREQTYP.SIGNONMSGSRQV1();
		// Sign-On Request Message
		DSCWRKFLWWSREQTYP.SIGNONMSGSRQV1.SONRQ signOnRequestMsg = new DSCWRKFLWWSREQTYP.SIGNONMSGSRQV1.SONRQ();
		signOnRequestMsg.setAPPID("Savvion");
		signOnRequestMsg.setAPPVER("1.2");
		signOnRequestMsg.setDTCLIENT("20120202 02:02:02");
		signOnRequestMsg.setLANGUAGE("ENG");
		signOnReqMsgSet.setSONRQ(signOnRequestMsg);
		return signOnReqMsgSet;
	}
	
	/**
	 * 
	 * Prepare the request info for the payload header
	 *
	 * @param prcsNameId
	 * @param requestTypeId
	 * @param trackingId
	 * @return
	 */
	private DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLHDR.REQSINFO populatePayLoadHeaderRequestInfo(
			Long prcsNameId, Long requestTypeId, Long trackingId) {
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLHDR.REQSINFO requestInfo = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLHDR.REQSINFO();
		requestInfo.setPRCSNMEID(BigInteger.valueOf(prcsNameId));
		requestInfo.setREQSTYPID(BigInteger.valueOf(requestTypeId));
		requestInfo.setTRKGID(trackingId != null ? BigInteger.valueOf(trackingId) : null);
		return requestInfo;
	}
	
	/**
	 * 
	 * Prepare the user info for the payload header
	 *
	 * @param submitterId
	 * @param userRoleId
	 * @param submitterGroupId
	 * @return
	 */
	private DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLHDR.USRINFO populatePayLoadHeaderUserInfo(
			String submitterId, Long userRoleId, int submitterGroupId) {
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLHDR.USRINFO userInfo = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLHDR.USRINFO();
		userInfo.setUSRID(submitterId);
		userInfo.setUSRROLEID(BigInteger.valueOf(userRoleId));
		userInfo.setGRPID(BigInteger.valueOf(submitterGroupId));
		return userInfo;
	}
	
	/**
	 * 
	 * populatePayLoadDataTaskStatus
	 *
	 * @param taskStatusTypeId
	 * @param taskId
	 * @return
	 */
	private DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKSTAT populatePayLoadDataTaskStatus(
			Long taskStatusTypeId, Long taskId) {
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKSTAT taskStatus = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKSTAT();
		taskStatus.setTSKSTATTYPID(BigInteger.valueOf(taskStatusTypeId));

		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKSTAT.TSKSTATDATA taskStatusData = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLDATA.TSKSTAT.TSKSTATDATA();
		TSKPAYLTYP taskPayloadType = new TSKPAYLTYP();

		TSKTYP taskType = new TSKTYP();
		taskType.setTSKID(taskId);

		taskPayloadType.setTSKPAYL(taskType);
		taskStatusData.setSBMTTSKDATA(taskPayloadType);
		taskStatus.setTSKSTATDATA(taskStatusData);
		return taskStatus;
	}
	
	/**
	 * 
	 * The method to populate the workFlow Payload header info
	 *
	 * @param prcsNameId
	 * @param requestTypeId
	 * @param trackingId
	 * @param submitterEmailAddress
	 * @param userRoleId
	 * @param submitterGroupId
	 * @return payloadHeader
	 */
	private DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLHDR populateWrkFlwPayloadHeader(
			Long prcsNameId, Long requestTypeId, Long trackingId, String submitterEmailAddress, Long userRoleId,
			int submitterGroupId) {
		// payload Header
		DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLHDR payloadHeader = new DSCWRKFLWWSREQTYP.WRKFLWMSGSRQV1.SUBJUPDTRNRQ.SUBJUPDRQ.WRKFLWPAYLHDR();
		// Request Info
		payloadHeader.setREQSINFO(populatePayLoadHeaderRequestInfo(prcsNameId, requestTypeId, trackingId));
		// User Info
		payloadHeader.setUSRINFO(populatePayLoadHeaderUserInfo(submitterEmailAddress, userRoleId, submitterGroupId));
		return payloadHeader;
	}
	
	/**
	 * 
	 * The method to populate the real time request for the workFlow payload header
	 *
	 * @param domainName
	 * @param domainId
	 * @param changeType
	 * @param notes
	 * @param approverGroupId
	 * @return realTimeRequest
	 */
	private REALTMETRXPAYLTYP populateRealTimeTxnPayloadType(String domainName, String domainId, long changeType,
			String notes, int approverGroupId) {
		REALTMETRXPAYLTYP realTimeRequest = new REALTMETRXPAYLTYP();
		// Real Time Process Instance Data
		REALTMEPRCSINSTNTYP realTimeRequestInstn = new REALTMEPRCSINSTNTYP();
		realTimeRequestInstn.setDOMNNME(domainName);
		realTimeRequestInstn.setDOMNID(domainId);
		realTimeRequestInstn.setCHGTYP(changeType);
		realTimeRequestInstn.setNOTES(notes);
		realTimeRequestInstn.setAPRVGRPID(BigInteger.valueOf(approverGroupId));
		realTimeRequest.setREALTMEPRCS(realTimeRequestInstn);
		return realTimeRequest;
	}
	
	/**
	 * 
	 * The method is invoked to create a new task with work-flow. When ever a
	 * currency bulk upload reference data happens, the method is invoked with the required
	 * input attributes and the method will invoke the webServices to create a
	 * new task with the work-flow.
	 * 
	 * 
	 * @param domainId
	 * @param domainName
	 * @param changeTypeId
	 * @param submitterEmailAddress
	 * @param fileName
	 * @param submitterGroupId
	 * @param approverGroupId
	 * @param notes
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	public void createProcessScotsBulkUploadInstance(String domainId, 
			String domainName, long changeType, String submitterEmailAddress,
			String fileName, int submitterGroupId, int approverGroupId, String notes) 
		throws RemoteException, MalformedURLException, ServiceException {
		executeWorkflowRequest(prepareCreateScotsBulkUploadProcessInstanceRequest(domainId, 
						domainName, changeType, submitterEmailAddress, fileName,
						submitterGroupId, approverGroupId, notes)
		);
	}
	
	/**
	 * 
	 * The method to construct the create process request for currency bulk upload.
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param submitterEmailAddress
	 * @param fileName
	 * @param submitterGroupId
	 * @param approverGroupId
	 * @param notes
	 * @return DSCWRKFLWWSREQTYP
	 */
	public DSCWRKFLWWSREQTYP prepareCreateScotsBulkUploadProcessInstanceRequest(String domainId, 
				String domainName, long changeType, String submitterEmailAddress,String fileName,
				int submitterGroupId, int approverGroupId, String notes) {	
        
		return prepareCreateIndustryCodeBulkUploadProcessInstanceRequest(domainId, domainName, changeType,
				submitterEmailAddress, fileName, submitterGroupId, approverGroupId, notes);
	}
	
	private DSCWRKFLWWSRSPTYP executeWorkflowRequest(DSCWRKFLWWSREQTYP request){
		DSCWRKFLWWSRSPTYP response = null;
		try{
			response = getPortType().executeWKFLOW(request);
		}catch(Exception ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_WORKFLOW,  ex);
		}
		return response;
	}
}

