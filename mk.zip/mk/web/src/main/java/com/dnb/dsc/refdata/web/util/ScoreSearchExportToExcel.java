/*
 * Cognizant PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Cognizant Technology Solutions. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */

package com.dnb.dsc.refdata.web.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.dnb.dsc.refdata.core.vo.ScoreSearchVO;

// TODO: Auto-generated Javadoc

/**
 * The Class IndsExportToExcel.
 */
public class ScoreSearchExportToExcel extends SXSSFWorkbook {

	/** The inds_code_sheet. */
	private Sheet search_score;

	/** The inds cd row count. */
	private Integer searchScrRowCount = 0;

	
	/**
	 * Instantiates a new inds export to excel.
	 *
	 * @param exportType the export type
	 */
	public ScoreSearchExportToExcel(String scrDesc) {
		super(300);		
		search_score = createSheet("Score Search Rslts");
		scr_sheet_header(scrDesc);
		
			
		

	}
	/*public ScoreSearchExportToExcel(String fromDesc,String toDesc) {
		super(300);
		
		search_score = createSheet("Inds CrsWlk Srch Rslts");
		inds_code_CrossWalk_sheet_header(fromDesc,toDesc);
		

	}*/

	/**
	 * Inds_code_sheet_header.
	 */
	private void scr_sheet_header(String indsDesc) {

		Row indusCdHeader = search_score.createRow(0);

		Cell headerCell0 = indusCdHeader.createCell(0);
		headerCell0.setCellValue("Score ID");
		
		Cell headerCell4 = indusCdHeader.createCell(1);
		headerCell4.setCellValue("Score Type Code");

		Cell headerCell1 = indusCdHeader.createCell(2);
		headerCell1.setCellValue("Score Type Description");
		
		Cell headerCell7 = indusCdHeader.createCell(3);
		headerCell7.setCellValue("Score Version");

		Cell headerCell2 = indusCdHeader.createCell(4);
		headerCell2.setCellValue("Score Market Code");
		
		Cell headerCell3 = indusCdHeader.createCell(5);
		headerCell3.setCellValue("Country Name");
		
		Cell headerCell5 = indusCdHeader.createCell(6);
		headerCell5.setCellValue("Score Granularity Code");
		
		Cell headerCell6 = indusCdHeader.createCell(7);
		headerCell6.setCellValue("Score Granularity Description");

	}

	/**
	 * Inds_code_ cross walk_sheet_header.
	 */
	/*private void inds_code_CrossWalk_sheet_header(String fromDesc,String toDesc) {

		Row indusCdHeader = search_score.createRow(0);

		Cell headerCell0 = indusCdHeader.createCell(0);
		headerCell0.setCellValue(fromDesc);

		Cell headerCell1 = indusCdHeader.createCell(1);
		headerCell1.setCellValue("From Description");
		
		Cell headerCell3 = indusCdHeader.createCell(2);
		headerCell3.setCellValue("From Desc Len CD");
		
		Cell headerCell7 = indusCdHeader.createCell(3);
		headerCell7.setCellValue("From Desc Len CD Descrption");

		Cell headerCell4 = indusCdHeader.createCell(4);
		headerCell4.setCellValue(toDesc);
		
		Cell headerCell2 = indusCdHeader.createCell(5);
		headerCell2.setCellValue("To Description");
		
		Cell headerCell5 = indusCdHeader.createCell(6);
		headerCell5.setCellValue("To Desc Len CD");
		
		Cell headerCell8 = indusCdHeader.createCell(7);
		headerCell8.setCellValue("To Desc Len CD Descrption");

		Cell headerCell6 = indusCdHeader.createCell(8);
		headerCell6.setCellValue("Pref Indc");

	}*/

	/**
	 * Insert inds code data.
	 *
	 * @param indsuCodeList the indsu code list
	 * private final String[] scoreSearchColumns = { "scr_id",
				"scoreTypeCode", "scr_typ_cd_val_d", "scr_mkt_cd_id", "country_name", "scoreGranularity", "scr_gru_cd_val_d" };
	 */
	@SuppressWarnings("rawtypes")
	public void insertScoreSearchData(List<ScoreSearchVO> scoreSearchVO) {
		List<ScoreSearchVO> rows = new ArrayList<ScoreSearchVO>();
		Iterator itr = scoreSearchVO.iterator();
		while (itr.hasNext()) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			ScoreSearchVO row = new ScoreSearchVO();

			row.setScr_id(Long.valueOf((curr.get("scr_id").toString())));			
			row.setScoreTypeCode(Long.valueOf((curr.get("scoreTypeCode").toString())));
			row.setScr_typ_cd_val_d((String)(curr.get("scr_typ_cd_val_d")));
			row.setScr_vers(Double.valueOf((curr.get("scr_vers").toString())));
			row.setScr_mkt_cd_id(Long.valueOf((curr.get("scr_mkt_cd_id").toString())));
			row.setCountry_name((String)(curr.get("country_name").toString()));
			row.setScoreGranularity(Long.valueOf((curr.get("scoreGranularity").toString())));
			row.setScr_gru_cd_val_d((String)((curr.get("scr_gru_cd_val_d").toString())));
			
			rows.add(row);
		}
		for (ScoreSearchVO scrSearch : rows) {
			searchScrRowCount++;
			Row dataRow = search_score.createRow(searchScrRowCount);
			Cell indscell = dataRow.createCell(0);
			indscell.setCellValue(scrSearch.getScr_id());
			
			Cell indscell4 = dataRow.createCell(1);
			indscell4.setCellValue(scrSearch.getScoreTypeCode());

			Cell indscell1 = dataRow.createCell(2);
			indscell1.setCellValue(scrSearch.getScr_typ_cd_val_d());
			
			Cell indscell7 = dataRow.createCell(3);
			indscell7.setCellValue(scrSearch.getScr_vers());

			Cell indscell2 = dataRow.createCell(4);
			indscell2.setCellValue(scrSearch.getScr_mkt_cd_id());
			
			Cell indscell3 = dataRow.createCell(5);
			indscell3.setCellValue(scrSearch.getCountry_name());
			
			Cell indscell5 = dataRow.createCell(6);
			indscell5.setCellValue(scrSearch.getScoreGranularity());
			
			Cell indscell6 = dataRow.createCell(7);
			indscell6.setCellValue(scrSearch.getScr_gru_cd_val_d());

		}

	}

	

}
