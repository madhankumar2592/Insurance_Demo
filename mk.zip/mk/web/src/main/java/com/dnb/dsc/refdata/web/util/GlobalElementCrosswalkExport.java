package com.dnb.dsc.refdata.web.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.dnb.dsc.refdata.core.entity.GloblalElementCrossWalk;

public class GlobalElementCrosswalkExport extends SXSSFWorkbook{
	/** The inds_code_sheet. */
	private Sheet all_search;

	/** The inds cd row count. */
	private Integer searchRowCount = 0;

	
	/**
	 * Instantiates a new inds export to excel.
	 *
	 * @param exportType the export type
	 */
	public GlobalElementCrosswalkExport(String geAllDesc) {
		super(300);		
		all_search = createSheet("All Search Rslts");
		all_srch_sheet_header(geAllDesc);
		
			
		

	}
	


	/**
	 * Inds_code_sheet_header.
	 */
	private void all_srch_sheet_header(String sheetName) {

		Row indusCdHeader = all_search.createRow(0);

			
		Cell headerCell0 = indusCdHeader.createCell(0);
		headerCell0.setCellValue("Global Element Id");
		
		Cell headerCell1 = indusCdHeader.createCell(1);
		headerCell1.setCellValue("Global Element Crosswalk Id");
		
		Cell headerCell2 = indusCdHeader.createCell(2);
		headerCell2.setCellValue("Element Meta Data Code");

		Cell headerCell3 = indusCdHeader.createCell(3);
		headerCell3.setCellValue("Platform Meta Data Code Description");
		
		Cell headerCell4 = indusCdHeader.createCell(4);
		headerCell4.setCellValue("Platform Meta Data Value");
		
		Cell headerCell5 = indusCdHeader.createCell(5);
		headerCell5.setCellValue("Platform Code");
		
		Cell headerCell6 = indusCdHeader.createCell(6);
		headerCell6.setCellValue("Data Platform");
		
		Cell headerCell7 = indusCdHeader.createCell(7);
		headerCell7.setCellValue("Crosswalk Group Name");

	}
	/**
	 * Insert all search data.
	 *
	 * 
	 * private final String[] allSearchColumns = { "globalElementTopicCategoryName","globalElementId",
			"globalElementName", "globalElementShortDescription", 
			"globalElementLongDescription"};
	 */
	@SuppressWarnings("rawtypes")
	public void insertCrosswalkSearchData(List<GloblalElementCrossWalk> globalElement) {
		List<GloblalElementCrossWalk> rows = new ArrayList<GloblalElementCrossWalk>();
		Iterator itr = globalElement.iterator();
		while (itr.hasNext()) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			GloblalElementCrossWalk row = new GloblalElementCrossWalk();
			
			row.setGlobalElementId(Long.valueOf(curr.get("globalElementId").toString()));
			row.setGlobalElementCrosswalkId(Long.valueOf(curr.get("globalElementCrosswalkId").toString()));
			row.setGlobalElementMetadataCode(Long.valueOf((curr.get("globalElementMetadataCode").toString())));
			row.setGlobalElementMetadataCodeDescription(curr.get("globalElementMetadataCodeDescription").toString());
			row.setGlobalElementMetadataValue((String)(curr.get("globalElementMetadataValue").toString()));
			row.setGlobalElementPlatformCode(Long.valueOf((curr.get("globalElementPlatformCode").toString())));			
			row.setGlobalElementPlatformCodeDescription((String)(curr.get("globalElementPlatformCodeDescription").toString()));
			row.setGlobalElementCrosswalkGrpNme((String)(curr.get("globalElementCrosswalkGrpNme").toString()));
			
			rows.add(row);
		}
		for (GloblalElementCrossWalk allSearch : rows) {
			searchRowCount++;
			Row dataRow = all_search.createRow(searchRowCount);
			
			Cell indscell0 = dataRow.createCell(0);
			indscell0.setCellValue(allSearch.getGlobalElementId());
			
			Cell indscell1 = dataRow.createCell(1);
			indscell1.setCellValue(allSearch.getGlobalElementCrosswalkId());

			Cell indscell2 = dataRow.createCell(2);
			indscell2.setCellValue(allSearch.getGlobalElementMetadataCode());	
			
			Cell indscell3 = dataRow.createCell(3);
			indscell3.setCellValue(allSearch.getGlobalElementMetadataCodeDescription());
			
			Cell indscell4 = dataRow.createCell(4);
			indscell4.setCellValue(allSearch.getGlobalElementMetadataValue());

			Cell indscell5 = dataRow.createCell(5);
			indscell5.setCellValue(allSearch.getGlobalElementPlatformCode());	
			
			Cell indscell6 = dataRow.createCell(6);
			indscell6.setCellValue(allSearch.getGlobalElementPlatformCodeDescription());
			
			Cell indscell7 = dataRow.createCell(7);
			indscell7.setCellValue(allSearch.getGlobalElementCrosswalkGrpNme());
			
		}
	}
	
}
