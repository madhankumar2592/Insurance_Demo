/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.web.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.entity.XmlSchemaElementLabelDetails;
import com.dnb.dsc.refdata.core.interceptor.TransactionLogger;
import com.dnb.dsc.refdata.core.util.CommonUtil;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.core.vo.XmlSchemaSearchVO;
import com.dnb.dsc.refdata.web.proxy.XmlSchemaLabelProxy;
import com.dnb.dsc.refdata.web.util.UserRoleMapper;

/**
 * The Controller class for XML Schema Label Domain.The methods in the class
 * will be mapped as per the UI requests.The UI front controller will redirect
 * to the respective methods based on the request and the request parameter.
 *
 * @author Cognizant
 * @version last updated : Apr 12, 2012
 * @see
 *
 */
@Controller
@SessionAttributes("xmlSchemaElement")
public class XmlSchemaLabelController {

    /**
     * The instance variable for Logging
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(XmlSchemaLabelController.class);

    @Autowired
    private XmlSchemaLabelProxy xmlProxy;

    @Autowired
    private HomeController homeController;

    @Autowired
	private TransactionLogger transactionLogger;
    
	@Autowired
	private UserRoleMapper roleMapper;

    private final String[] xmlSearchColumns = { "xmlSchemaElementId", "dataElementName", "dataElementDescription" };

    /**
     * The method will load the xml schema label search home page.
     *
     * @param model
     * @return
     */
    @RequestMapping(value = "/xmlSchemaLabelHome.form", method = RequestMethod.GET)
    public ModelAndView getXmlSchemaLabelHome() {
        LOGGER.info("entering XmlSchemaLabelController | getXmlSchemaLabelHome");
        ModelAndView xmlSchemaLabelHome = new ModelAndView("xmlSchemaLabelSearch");
        LOGGER.info("exiting XmlSchemaLabelController | getXmlSchemaLabelHome");
        return xmlSchemaLabelHome;
    }


    /**
     * The method is to search the xml schema element by xml element name or xml element description.
     * The method is invoked when the user hits the search button in the Data Element Name/Description
     * search page.The return will be a Map object
     *
     * @param request
     * @param session
     * @return
     */
    @RequestMapping(value = "/xmlSearchAjaxResults.form", method = RequestMethod.GET)
    public @ResponseBody
    Map<String, Object> getXmlSearchAjaxResults(HttpServletRequest request, HttpSession session) {
        LOGGER.info("entering XmlSchemaLabelController | getXmlSearchAjaxResults");
		// audit variables
		Date startTime = new Date();
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		
        List<XmlSchemaElement> elementInfo = null;
        XmlSchemaSearchVO xmlSchemaSearchVO = getXmlSchemaSearchVO(request);
		if (xmlSchemaSearchVO.getElementName() == null
				|| (xmlSchemaSearchVO.getElementName() != null && xmlSchemaSearchVO.getElementName().trim().isEmpty())) {
			return homeController.getJsonMap(request, new ArrayList<Object>(), 0L, xmlSearchColumns);
		}

		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		Long countResults = (Long) session
				.getAttribute("countSearchXmLSchemaResults");
		if ((countResults == null) || (xmlSchemaSearchVO.getRowIndex() == 0)) {
			countResults = xmlProxy.countSearchXmLSchemaLabels(xmlSchemaSearchVO);
			session.setAttribute("countSearchXmLSchemaResults", countResults);
		}

        // invoking the proxy to fetch the element info details
        elementInfo = xmlProxy.searchXmLSchemaLabels(xmlSchemaSearchVO);
		// transaction logging
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS,
				"getXmlSchemaSearchResults", 0L, xmlSchemaSearchVO, 0L);
		
        return homeController.getJsonMap(request, elementInfo, countResults, xmlSearchColumns);
    }

    /**
     *
     * The method to populate the xmlSchemaSearchVO
     *
     * @param request
     * @return xmlSchemaSearchVO
     */
    private XmlSchemaSearchVO getXmlSchemaSearchVO(HttpServletRequest request) {
        XmlSchemaSearchVO xmlSchemaSearchVO = new XmlSchemaSearchVO();
        xmlSchemaSearchVO.setStartIndex(homeController.getStartIndex(request));
        xmlSchemaSearchVO.setMaxResults(homeController.getMaxResults(request));
        xmlSchemaSearchVO.setSortBy(homeController.getSortBy(request, xmlSearchColumns));
        // sorting order � asc or desc.
        xmlSchemaSearchVO.setSortOrder(homeController.getSortOrder(request));
        xmlSchemaSearchVO.setElementName(homeController.getSearchString(request));
        xmlSchemaSearchVO.setElementDescription(homeController.getSearchString(request));
        LOGGER.info("XmlSchemaLabelController | getXmlSchemaSearchVO | xmlSchemaSearchVO : " + xmlSchemaSearchVO);
        return xmlSchemaSearchVO;
    }

    /**
     * The method is to search the xml schema element by xml element id.
     * The method is invoked when the user clicks on any of the element id link in the list
     * .The return will be a Map object
     *
     * @param elementId
     * @param model
     * @return
     */
    @RequestMapping(value = "/xmlSchemaLabelSearchView.form", method = RequestMethod.GET)
    public ModelAndView xmlSchemaLabelsSearchView(@RequestParam("elementId") final String elementId,
    	@RequestParam("taskId") final String taskId,Model model, HttpSession session) {
        LOGGER.info("entering XmlSchemaLabelController | getXmlSchemaLabelSearchView");

        ModelAndView xmlSchemaLabelSearchView = new ModelAndView("xmlSchemaLabelSearchView");

        XmlSchemaElement xmlSchemaElement =null;
        if ((taskId != null) && !taskId.trim().isEmpty()) {
        	xmlSchemaElement= xmlProxy.reviewXmlSchemaByXmlElementChanges(elementId);
        } else {
        	xmlSchemaElement= xmlProxy.retrieveXmlSchemaByXmlElementId(elementId);
        }

        // adding details to model object
        xmlSchemaLabelSearchView.addObject("xmlSchemaElement", xmlSchemaElement);
        xmlSchemaLabelSearchView.addObject("xmlSchemaElementLabelDetails",
                xmlSchemaElement.getXmlSchemaElementLabelDetails());
        xmlSchemaLabelSearchView.addObject("xmlSchemaElementXPath", xmlSchemaElement.getXmlSchemaElementXPath());

        // Populating request object with code values
        List<Integer> codeTableIds = new ArrayList<Integer>();
        codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
        Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
        xmlSchemaLabelSearchView.addObject("languageCodeValues",
                tempCodeValueMap.get(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));

        session.setAttribute("xmlSchemaElementInDb", getXmlSchemaInDB(xmlSchemaElement));
        model.addAttribute("xmlSchemaElement", xmlSchemaElement);
        session.setAttribute("taskId", taskId);
        
        LOGGER.info("exiting XmlSchemaLabelController | getXmlSchemaLabelSearchView");
        return xmlSchemaLabelSearchView;
    }
    /**
	 *
	 * The method will validate the Xml Schema Element for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param xmlSchemaElement
	 * @return boolean
	 */
	@RequestMapping(value = "lockXmlSchemaForEdit.form", method = RequestMethod.GET)
	public @ResponseBody
	Boolean lockXmlSchema(
			@ModelAttribute("xmlSchemaElement") XmlSchemaElement xmlSchemaElement,
			HttpSession session) {
		LOGGER.info("entering  XmlSchemaLabelController | lockXmlSchema");
		if (((String) session.getAttribute("taskId") != null) &&
		((String) session.getAttribute("taskId")).length() > 0) {
			return false;
		} else {
			String xmlSchemaElementId = xmlSchemaElement.getXmlSchemaElementId();
			return this.xmlProxy.lockXmlSchemaElement(xmlSchemaElementId);
        }
	}
	/**
	 *
	 * The method will persist the edited XmlSchemaElement in the Transactional DB.
	 * Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param xmlSchemaElement
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/updateXmlSchemaElement.form", method = RequestMethod.POST)
	public View updateXmlSchemaElement(
			@ModelAttribute("xmlSchemaElement") XmlSchemaElement xmlSchemaElement,
			Model model, SessionStatus sessionStatus, HttpSession session, HttpServletRequest request)
			throws ParseException {
		LOGGER.info("entering XmlSchemaLabelController | updateXmlSchemaElement | xmlSchemaElement : " + xmlSchemaElement);
		//audit variables
		Date startTime = new Date();
		
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = (userContextVO == null ? "" : userContextVO.getUserIdentifier());
		
		XmlSchemaElement xmlSchemaElementInDb= (XmlSchemaElement)session.getAttribute("xmlSchemaElementInDb");
		session.removeAttribute("xmlSchemaElementInDb");
		XmlSchemaElement forUpdate = prepareForXmlSchemaElementUpdate(
				xmlSchemaElement,
				xmlSchemaElementInDb, 
				loggedInUser);
		
		LOGGER.info("XmlSchemaLabelController | updateXmlSchemaElement : " + forUpdate);
		String xmlSchemaElementId = xmlProxy.updateXmlSchemaElement(forUpdate);
		
		String taskId = (String)session.getAttribute("taskId");
		if ((taskId != null) && !taskId.trim().isEmpty()) {
			homeController
					.reSubmitTaskRequest(
							userContextVO,
							taskId,
							RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS,
							RefDataPropertiesConstants.XML_SCHEMA_ELEMENT_SUBMITTER_GROUP_ID);
		} else {
			createXmlSchemaWorkflowTask(
					xmlSchemaElementId,
					RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_XML_SCHEMA_LABEL,
					loggedInUser);
		}
		session.removeAttribute("taskId");
		sessionStatus.setComplete();
		
		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS,
				"updateXmlSchemaElement", 0L, xmlSchemaElementId, 0L, forUpdate);

		return new RedirectView("submitterWorkQueueHome.form?domainName=XML Schema Labels");
	}
	/**
	 *
	 * The method to prepare xmlSchemaElement for the update operation
	 *
	 * @param xmlSchemaElement
	 * @param loggedInUser
	 * @return xmlSchemaElement
	 */
	private XmlSchemaElement prepareForXmlSchemaElementUpdate(
			XmlSchemaElement xmlSchemaElement,XmlSchemaElement xmlSchemaElementInDB, String loggedInUser) {

		String truncatedUserId = CommonUtil.truncate(loggedInUser, 
				RefDataPropertiesConstants.USER_EMAIL_ADDRESS_MAX_LENGTH);
		
		xmlSchemaElement.setModifiedUser(truncatedUserId);
		xmlSchemaElement.setModifiedDate(new Date());
		Long idCounter = 0L;
		List<XmlSchemaElementLabelDetails> newDetailList = new ArrayList<XmlSchemaElementLabelDetails>();
		if (xmlSchemaElement.getXmlSchemaElementLabelDetails() != null) {
			for (XmlSchemaElementLabelDetails eleLabelDetails : xmlSchemaElement.getXmlSchemaElementLabelDetails()) {
				if (eleLabelDetails.getXmlSchemaElementLabelDetailsId() < 0) {
					eleLabelDetails.setXmlSchemaElementLabelDetailsId(idCounter--);
					eleLabelDetails.setXmlSchemaElementId(xmlSchemaElement.getXmlSchemaElementId());
					eleLabelDetails.setXmlSchemaRecordTypeCd(RefDataPropertiesConstants.CODE_DATA_STORES_GSRL);
					eleLabelDetails.setWriteScrpCd(RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
					eleLabelDetails.setCreatedUser(truncatedUserId);
					eleLabelDetails.setCreatedDate(new Date());
					eleLabelDetails.setModifiedUser(truncatedUserId);
					eleLabelDetails.setModifiedDate(new Date());
					newDetailList.add(eleLabelDetails);
				} else if (containsLiteralsChange(eleLabelDetails, xmlSchemaElementInDB)) {
					eleLabelDetails.setModifiedUser(truncatedUserId);
					eleLabelDetails.setModifiedDate(new Date());
					newDetailList.add(eleLabelDetails);
				}
			}
			xmlSchemaElement.setXmlSchemaElementLabelDetails(null);
			xmlSchemaElement.setXmlSchemaElementLabelDetails(newDetailList);
		}
		LOGGER.info("exiting XmlSchemaLabelController | prepareForXmlSchemaElementUpdate" +
				" | xmlSchemaElement : " + xmlSchemaElement);
		return xmlSchemaElement;
	}

	/**
	 *
	 * The method to create new task with work-flow.
	 *
	 * @param scotsDomainId
	 * @param requestType
	 * @param userContextVO
	 */
	private void createXmlSchemaWorkflowTask(
			String xmlSchemaElementId,
			String changeTypeId,
			String loggedInUser) {

		homeController.createReferenceData(
				xmlSchemaElementId,
				RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS,
				Long.valueOf(changeTypeId),
				loggedInUser,
				"Element ID: " + xmlSchemaElementId,
				RefDataPropertiesConstants.XML_SCHEMA_ELEMENT_APPROVER_GROUP_ID,
				RefDataPropertiesConstants.XML_SCHEMA_ELEMENT_SUBMITTER_GROUP_ID );
	}
	/**
	 * 
	 * To check if there are any changes in the business literals
	 * 
	 * @param XmlSchemaElementLabelDetail
	 * @param xmlSchemaElementInDB
	 * @return boolean
	 */
	private boolean containsLiteralsChange(
			XmlSchemaElementLabelDetails xmlSchemaElementLabelDetail,
			XmlSchemaElement xmlSchemaElementInDB) {
		if (xmlSchemaElementInDB == null || xmlSchemaElementLabelDetail == null) {
			return false;
		}
		if (xmlSchemaElementInDB.getXmlSchemaElementLabelDetails() == null) {
			return false;
		}
			if(RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED.equals(xmlSchemaElementLabelDetail.getChangeIndicator())){
				return true;
			}
		for (XmlSchemaElementLabelDetails currXmlSchemaElementLabelDetails : xmlSchemaElementInDB
				.getXmlSchemaElementLabelDetails()) {
			
			if (xmlSchemaElementLabelDetail.getXmlSchemaElementLabelDetailsId()
					.longValue() == currXmlSchemaElementLabelDetails
					.getXmlSchemaElementLabelDetailsId().longValue()) {
				if (xmlSchemaElementLabelDetail.getLanguageCd().longValue() != currXmlSchemaElementLabelDetails
						.getLanguageCd().longValue()) {
					return true;
				}
				if (!xmlSchemaElementLabelDetail.getDataElementLabelName()
						.equalsIgnoreCase(currXmlSchemaElementLabelDetails
						.getDataElementLabelName())) {
					return true;
				}
				if (!xmlSchemaElementLabelDetail.getDataElementLabelDescription()
						.equalsIgnoreCase(
								currXmlSchemaElementLabelDetails
										.getDataElementLabelDescription())) {
					return true;
				}
				return false;
			}
		}
		return false;
	}
	
	
	/**
	 * 
	 * TODO
	 * 
	 * @param industryCodeById
	 * @return industryCodeInDB
	 */
	private XmlSchemaElement getXmlSchemaInDB(XmlSchemaElement xmlSchemaElement) {
		XmlSchemaElement xmlSchemaElementInDB = new XmlSchemaElement();
		xmlSchemaElementInDB
				.setXmlSchemaElementLabelDetails(getDescriptionListInDB(xmlSchemaElement));
		return xmlSchemaElementInDB;
	}
	/**
	 * 
	 * TODO
	 * 
	 * @param industryCodeById
	 * @return descriptionListInDB
	 */
	private List<XmlSchemaElementLabelDetails> getDescriptionListInDB(
			XmlSchemaElement xmlSchemaElement) {
		List<XmlSchemaElementLabelDetails> descriptionListInDB = new ArrayList<XmlSchemaElementLabelDetails>();
		if (xmlSchemaElement.getXmlSchemaElementLabelDetails() != null) {
			for (XmlSchemaElementLabelDetails currXmlSchemaElementLabelDetail : xmlSchemaElement
					.getXmlSchemaElementLabelDetails()) {
				XmlSchemaElementLabelDetails newXmlSchemaElementLabelDetail = new XmlSchemaElementLabelDetails();
				newXmlSchemaElementLabelDetail
						.setXmlSchemaElementLabelDetailsId(currXmlSchemaElementLabelDetail
								.getXmlSchemaElementLabelDetailsId());
				newXmlSchemaElementLabelDetail
						.setLanguageCd(currXmlSchemaElementLabelDetail
								.getLanguageCd());
				newXmlSchemaElementLabelDetail
						.setDataElementLabelDescription(currXmlSchemaElementLabelDetail
								.getDataElementLabelDescription());
				newXmlSchemaElementLabelDetail
						.setDataElementLabelName(currXmlSchemaElementLabelDetail
								.getDataElementLabelName());
				descriptionListInDB.add(newXmlSchemaElementLabelDetail);
			}
		}
		return descriptionListInDB;
	}

}
