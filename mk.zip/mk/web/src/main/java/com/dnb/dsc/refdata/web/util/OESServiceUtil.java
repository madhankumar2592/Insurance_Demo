/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.web.util;

import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bea.security.AppConfig;
import com.bea.security.AuthenticIdentity;
import com.bea.security.AuthenticationService;
import com.bea.security.AuthorizationService;
import com.bea.security.ExtendedAccessResult;
import com.bea.security.IdentityNotAuthenticException;
import com.bea.security.InvalidAssertionTokenException;
import com.bea.security.ParameterException;
import com.bea.security.PolicyDomain;
import com.bea.security.ResourceAction;
import com.bea.security.RuntimeAction;
import com.bea.security.RuntimeResource;
import com.bea.security.SecurityRuntime;
import com.bea.security.ServiceNotAvailableException;
import com.bea.security.ServiceType;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.core.vo.UserRoleVO;

/**
 * The utility class for OES Integration
 *
 * @author Cognizant
 * @version last updated : Apr 25, 2012
 * @see
 *
 */
@Component
public class OESServiceUtil implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -552714872258708409L;

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(OESServiceUtil.class);

	private PolicyDomain policydomain = null;
	private AuthenticationService authnservice = null;
	private AuthorizationService authzservice = null;
	List<ExtendedAccessResult> extendedAccessResultLists = null;
	List<String> accessibleResourceName = null;
	private static Map<String, ArrayList<Long>> geoTypeMap = new HashMap<String, ArrayList<Long>>();
	
	static {
		
		ArrayList<Long> aboveCountyLiterals = new ArrayList<Long>();
		// Country
		aboveCountyLiterals.add(128L);
		//Continent
		aboveCountyLiterals.add(129L);
		//Country Group
		aboveCountyLiterals.add(130L);
		// D&B WWN Market
		aboveCountyLiterals.add(14000L);
		//WB Cntry Grpng
		aboveCountyLiterals.add(2002L);
		//WorldBase Primary Subdivision of Country
		aboveCountyLiterals.add(2111L);				
		//WB Scdy Subd
		aboveCountyLiterals.add(2222L);
		//WB Prim Subd
		aboveCountyLiterals.add(2111L);
		//D&B Rgn/Systm
		aboveCountyLiterals.add(329L);
		//Territory
		aboveCountyLiterals.add(5392L);
		geoTypeMap.put("ABOVE/COUNTY",aboveCountyLiterals);
		
		ArrayList<Long> countyLiterals = new ArrayList<Long>();
		// County
		countyLiterals.add(5153L);
		geoTypeMap.put("COUNTY",countyLiterals);
		
		ArrayList<Long> belowCountyLiterals = new ArrayList<Long>();
		//Minor Town
		belowCountyLiterals.add(125L);
		//Postal Town
		belowCountyLiterals.add(126L);
		//District
		belowCountyLiterals.add(127L);
		//Postal Code
		belowCountyLiterals.add(324L);
		//Congress Dstct
		belowCountyLiterals.add(325L);
		//Labour Surplus
		belowCountyLiterals.add(326L);
		//SMSA
		belowCountyLiterals.add(1333L);
		//MSA
		belowCountyLiterals.add(1444L);
		//Pst Cd Prfx Grp
		belowCountyLiterals.add(1666L);
		//Economic Group
		belowCountyLiterals.add(3836L);
		//Region
		belowCountyLiterals.add(3837L);
		//Street
		belowCountyLiterals.add(3838L);
		//County Comm Key
		belowCountyLiterals.add(7091L);
		//Org Post Code
		belowCountyLiterals.add(5224L);
		//Nielsen Geo Code
		belowCountyLiterals.add(7089L);
		//Freight Bar Code
		belowCountyLiterals.add(7090L);
		//Suburb
		belowCountyLiterals.add(7092L);
		//City of Reg
		belowCountyLiterals.add(7093L);
		//Sub Minor Town
		belowCountyLiterals.add(7789L);		

		geoTypeMap.put("BELOW/COUNTY",belowCountyLiterals);
		
	}

	@Autowired
	private RefDataConfigUtil refDataConfig;

	
	public static Map<String,ArrayList<Long>>  getGeoTypeMap(){
		return geoTypeMap;
	}

	/**
	 * The method to get the user role code values
	 *
	 * @param userContext
	 * @return
	 */
	public List<String> getRoleCodes(UserContextVO userContext) {
		LOGGER.info("entering OESServiceUtil | getRoleCodes ");
		List<UserRoleVO> userRoleVos = userContext.getUserRoles();
		List<String> userRoles = new ArrayList<String>();
		for (UserRoleVO userRoleVo : userRoleVos) {
			userRoles.add(userRoleVo.getRoleCode());
			LOGGER.info("userRoleVo.getRoleCode() is "
					+ userRoleVo.getRoleCode());
		}
		LOGGER.info("exiting OESServiceUtil | getRoleCodes ");
		return userRoles;
	}

	/**
	 * The method returns if a user role has access to a particular resource
	 *
	 * @param resources
	 * @param resourceName
	 * @return isAccessAllowed
	 */
	public boolean getUIComponentAccess(List<String> resources,
			String resourceName) {
		boolean isAccessAllowed = false;
		LOGGER.info("entering OESServiceUtil | getUIComponentAccess ");
		LOGGER.info("entering OESServiceUtil | getUIComponentAccess | resourceName::"+resourceName);
		for(String resourceArray : resourceName.split(RefDataUIConstants.ONELOGIN_HEADER_APPLICATION_SEPARATOR)){
			for (String resource : resources) {				
				if (resource.equals(resourceArray)) {
					isAccessAllowed = true;
					break;
				}
			}
		}
		LOGGER.info("entering OESServiceUtil | getUIComponentAccess | isAccessAllowed::"+isAccessAllowed);
		return isAccessAllowed;
	}

}
