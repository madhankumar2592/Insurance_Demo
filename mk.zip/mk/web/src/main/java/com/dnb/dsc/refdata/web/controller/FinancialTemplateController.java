/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.webflow.execution.RequestContext;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.FinancialStatementSchedule;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplate;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateInternalLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateOwnerLineItem;
import com.dnb.dsc.refdata.core.interceptor.TransactionLogger;
import com.dnb.dsc.refdata.core.vo.FinancialStatementVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.web.proxy.FinancialTemplateWebServiceProxy;
import com.dnb.dsc.refdata.web.util.UserRoleMapper;

/**
 * @author Cognizant
 * @version last updated : June 18, 2012
 * @see
 */
@Controller("financialTemplateController")
public class FinancialTemplateController {

	private static final Logger LOGGER = LoggerFactory.getLogger(FinancialTemplateController.class);
	
	@Autowired
	private FinancialTemplateWebServiceProxy ftProxy;
	
	@Autowired
	private HomeController homeController;

	@Autowired
	private TransactionLogger transactionLogger;
	
	@Autowired
	private UserRoleMapper roleMapper;

	/**
	 * 
	 * The method to retrieve the financial statement templates. The method will
	 * populate the Financial Template drop down in the UI. If a template is
	 * already selected then this method will fetch the details of the selected
	 * template from the Staging DB.
	 * 
	 * @param financialTemplateTypeCode
	 * @return FinancialStatementTemplateVO
	 */
	@SuppressWarnings("rawtypes")
	public FinancialStatementVO getFinancialTemplates(Long financialTemplateTypeCode,String taskId){
		LOGGER.info("entering FinancialTemplateController | getFinancialTemplates ");		
		// audit variables
		Date startTime = new Date();
		
		LOGGER.info("financialTemplateTypeCode : "+financialTemplateTypeCode);
		LOGGER.info("taskId : " + taskId);
		FinancialStatementVO fsVO = new FinancialStatementVO();
		/*
		 * Populate the Financial Template dropDown in the UI
		 */
		fsVO.setFinancialTemplateList(ftProxy
				.getFinancialTemplates(RefDataPropertiesConstants.CODE_TABLE_FINANCIAL_STATEMENT_TEMPLATES));
		/*
		 * If the financial statement template is selected from UI
		 */
		if ((financialTemplateTypeCode != null) && (financialTemplateTypeCode > 0)) {
			FinancialStatementTemplate existingFsTemplate = null;
			if ((taskId != null) && !taskId.trim().isEmpty()) {
				existingFsTemplate = ftProxy.retrieveFinancialStatementTemplateByTypeCode(
						financialTemplateTypeCode, false);
			} else {
				existingFsTemplate = ftProxy.retrieveFinancialStatementTemplateByTypeCode(financialTemplateTypeCode,
						true);
			}
			
			if (existingFsTemplate != null) {
				existingFsTemplate = populateDescForId(existingFsTemplate);
				List<Integer> scheduleCodeList = getScheduleCodeList(existingFsTemplate);
				List<CodeValueText> statementList = ftProxy.retrieveStatementForSchedules(scheduleCodeList);
				Iterator stmtItr = null;
				Map<Long, FinancialStatementTemplate> fsTemplateMap = new LinkedHashMap<Long, FinancialStatementTemplate>();
				FinancialStatementTemplate fsTemplate = null;
				List<FinancialStatementSchedule> scheduleList = null;
				Collections.sort(existingFsTemplate.getFinancialStatementScheduleList(), new ScheduleComparable());
				for (FinancialStatementSchedule schedule : existingFsTemplate.getFinancialStatementScheduleList()) {
					Collections.sort(schedule.getFinancialStatementTemplateLineItemList(), new LineItemComparable());
					stmtItr = statementList.iterator();
					while (stmtItr.hasNext()) {
						LinkedHashMap curr = (LinkedHashMap) stmtItr.next();
						if (schedule.getFinancialStatementScheduleCode() == ((Integer) curr.get("childCodeValueId"))
								.longValue()) {
							if (fsTemplateMap.containsKey(((Integer) curr.get("codeValueId")).longValue())) {
								fsTemplate = fsTemplateMap.get(((Integer) curr.get("codeValueId")).longValue());
							} else {
								fsTemplate = new FinancialStatementTemplate();
							}
							fsTemplate.setFinancialTemplateTypeCode(((Integer) curr.get("codeValueId")).longValue());
							fsTemplate.setTypeCodeDescription((String) curr.get("codeValueDescription"));
							break;
						}
					}
					scheduleList = fsTemplate.getFinancialStatementScheduleList();
					if (scheduleList == null) {
						scheduleList = new ArrayList<FinancialStatementSchedule>();
					}
					scheduleList.add(schedule);
					fsTemplate.setFinancialStatementScheduleList(scheduleList);
					if (!fsTemplateMap.containsKey(schedule.getFinancialStatementScheduleCode())) {
						fsTemplateMap.put(fsTemplate.getFinancialTemplateTypeCode(), fsTemplate);
					}
				}
				// Added to fix the UAT issue : Retest defect 4765 16 Oct - Fail $starts$
				if ((taskId != null) && !taskId.trim().isEmpty()) {
					fsVO.setFinancialStatementTemplateId(existingFsTemplate.getFinancialStatementTemplateId());
				} else {
					fsVO.setFinancialStatementTemplateId(null);
				}
				fsVO.setFinancialStatementTemplateList(fsTemplateMap);
				fsVO.setIsLocked(existingFsTemplate.getIsLocked());
				fsVO.setModifiedUser(existingFsTemplate.getLockedUser());
				// Added to fix the UAT issue : Retest defect 4765 16 Oct - Fail $ends$
			}
			fsVO = populateVOWithStatementTypes(fsVO);
		}
		fsVO.setFinancialStatementTypeCode(financialTemplateTypeCode);
		
		// transaction logging 
		List<String> roles = new ArrayList<String>();
		roles.add("CA_FT_Approver");
		roles.add("CA_FT_Basic");		
		transactionLogger.log(startTime, fsVO.getModifiedUser(), roles,
				RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES, "getFinancialTemplates", 0L,
				financialTemplateTypeCode, 0L, fsVO);
		
		LOGGER.info("FinancialTemplateController | getFinancialTemplates | returning " + fsVO);
		LOGGER.info("exiting FinancialTemplateController | getFinancialTemplates ");
		return fsVO;
	}

	public List<Integer> getScheduleCodeList(FinancialStatementTemplate existingFsTemplate){
		List<Integer> scheduleCodeList = new ArrayList<Integer>();
		for(FinancialStatementSchedule schedule : existingFsTemplate.getFinancialStatementScheduleList()){
			scheduleCodeList.add(schedule.getFinancialStatementScheduleCode().intValue());
		}
		return scheduleCodeList;
	}
	
	public FinancialStatementTemplate populateDescForId(FinancialStatementTemplate existingFsTemplate){
		List<Integer> codeValueIdList = new ArrayList<Integer>();
		codeValueIdList.add(existingFsTemplate.getFinancialTemplateTypeCode().intValue());
		for(FinancialStatementSchedule schedule : existingFsTemplate.getFinancialStatementScheduleList()){
			codeValueIdList.add(schedule.getFinancialStatementScheduleCode().intValue());
			for(FinancialStatementTemplateLineItem lineItem : schedule.getFinancialStatementTemplateLineItemList()){
				codeValueIdList.add(lineItem.getFinancialStatementLineItemCode().intValue());
			}
		}
		
		Map<Integer, String> descForIdMap = ftProxy.retrieveDescForId(codeValueIdList);
		existingFsTemplate.setTypeCodeDescription(descForIdMap.get(
				String.valueOf(existingFsTemplate.getFinancialTemplateTypeCode())));
		for(FinancialStatementSchedule schedule : existingFsTemplate.getFinancialStatementScheduleList()){
			schedule.setScheduleCodeDescription(
					descForIdMap.get(String.valueOf(schedule.getFinancialStatementScheduleCode())));
			for(FinancialStatementTemplateLineItem lineItem : schedule.getFinancialStatementTemplateLineItemList()){
				lineItem.setLineItemCodeDescription(
						descForIdMap.get(String.valueOf(lineItem.getFinancialStatementLineItemCode())));
			}
		}
		return existingFsTemplate;
	}
	
	/**
	 * 
	 * The method to populate the FinancialStatementTemplateVO with the
	 * Financial Statement Types. The statement types are retrieved from the the
	 * code table 632.
	 * 
	 * @param fstVO
	 * @return FinancialStatementTemplateVO
	 */
	@SuppressWarnings("rawtypes")
	public FinancialStatementVO populateVOWithStatementTypes(FinancialStatementVO fsVO) {
		LOGGER.info("entering FinancialTemplateController | populateVOWithStatementTypes");
		/*
		 * Retrieve the financial statement types from code table 632
		 */
		Iterator itr = ftProxy.getFinancialTemplates(RefDataPropertiesConstants.CODE_TABLE_FINANCIAL_STATEMENT_TYPE)
				.iterator();
		FinancialStatementTemplate fsTemplate = null;
		Map<Long, FinancialStatementTemplate> fsTemplateMap = fsVO.getFinancialStatementTemplateList();
		if (fsTemplateMap == null) {
			fsTemplateMap = new LinkedHashMap<Long, FinancialStatementTemplate>();
		}
		while (itr.hasNext()) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			if (fsTemplateMap.containsKey(Long.valueOf(curr.get("codeValueId").toString()))) {
				fsTemplate = fsTemplateMap.get(Long.valueOf(curr.get("codeValueId").toString()));
			} else {
				fsTemplate = new FinancialStatementTemplate();
			}
			fsTemplate.setFinancialTemplateTypeCode(Long.valueOf(curr.get("codeValueId").toString()));
			fsTemplate.setTypeCodeDescription(curr.get("codeValueDescription").toString());

			if (fsTemplate.getFinancialStatementScheduleList() == null) {
				// populate empty row for schedule and line item
				List<FinancialStatementSchedule> financialStatementScheduleList = new ArrayList<FinancialStatementSchedule>();
				FinancialStatementSchedule financialStatementSchedule = new FinancialStatementSchedule();
				List<FinancialStatementTemplateLineItem> financialStatementTemplateLineItemList = new ArrayList<FinancialStatementTemplateLineItem>();
				financialStatementTemplateLineItemList.add(new FinancialStatementTemplateLineItem());
				financialStatementSchedule
						.setFinancialStatementTemplateLineItemList(financialStatementTemplateLineItemList);
				financialStatementScheduleList.add(financialStatementSchedule);
				fsTemplate.setFinancialStatementScheduleList(financialStatementScheduleList);
				// populate empty row ends
			}
			fsTemplateMap.put(fsTemplate.getFinancialTemplateTypeCode(), fsTemplate);
		}
		fsVO.setFinancialStatementTemplateList(fsTemplateMap);
		LOGGER.info("exiting FinancialTemplateController | populateVOWithStatementTypes | returned " + fsVO);
		return fsVO;
	}
	
	// tableId should be 632. We are using 78 for testing purpose
	@RequestMapping(value = "getStatementType.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueText> getStatementType(
			@RequestParam("statementType") Long statementType) {
		LOGGER.info("entering FinancialTemplateController | getStatementType");
		return ftProxy.getFinancialTemplates(RefDataPropertiesConstants.CODE_TABLE_FINANCIAL_STATEMENT_TYPE);
	}
	
	@RequestMapping(value = "getSchedulesForStatementType.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueText> getSchedulesForStatementType(
			@RequestParam("statementType") Long statementType) {
		LOGGER.info("entering FinancialTemplateController | getSchedulesForStatementType");
		return ftProxy.getSchedulesForStatementType(statementType);
	}
	
	@RequestMapping(value = "getFinancialStatementTemplateById.form", method = RequestMethod.GET)
	public @ResponseBody
	FinancialStatementTemplate retrieveFinancialStatementTemplateById(
			@RequestParam("financialStatementTemplateId") Long financialStatementTemplateId) {
		LOGGER.info("entering FinancialTemplateController | retrieveFinancialStatementTemplateById");
		return ftProxy
				.retrieveFinancialStatementTemplateById(financialStatementTemplateId);
	}

	@RequestMapping(value = "getLineItemsForScheduleType.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueText> getLineItemsForScheduleType(
			@RequestParam("scheduleType") Long scheduleType) {
		LOGGER.info("entering FinancialTemplateController | getLineItemsForScheduleType");
		return ftProxy.getLineItemsForScheduleType(scheduleType);
	}
	
	/**
	 * 
	 * The method to update the Financial Template details in the Transaction DB
	 *
	 * @param financialStatementVO
	 * @param context
	 * @param isSave
	 * @return
	 */
	@RequestMapping(value = "/submitFinanceTemplate.form", method = RequestMethod.GET)
	public String financeTemplateUpdate(
			@ModelAttribute("financialStatementVO") FinancialStatementVO financialStatementVO,
			RequestContext context, Boolean isSave, String taskId) {
		LOGGER.info("entering FinancialTemplateController | financeTemplateUpdate");
		LOGGER.info("FinancialTemplateController | financeTemplateUpdate | " +
				"financialStatementVO : " + financialStatementVO);
		// audit variables
		Date startTime = new Date();

		HttpSession session = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();

		FinancialStatementTemplate fsTemplate = new FinancialStatementTemplate();
		fsTemplate.setFinancialStatementTemplateId(financialStatementVO.getFinancialStatementTemplateId());
		fsTemplate.setFinancialTemplateTypeCode(financialStatementVO.getFinancialStatementTypeCode());
		fsTemplate.setTemplateOwnerCode(RefDataPropertiesConstants.FINANCIAL_STMT_TEMPLATE_OWNER_CODE);		
		List<FinancialStatementSchedule> scheduleList = new ArrayList<FinancialStatementSchedule>();
		for (Map.Entry<Long, FinancialStatementTemplate> entry : financialStatementVO
				.getFinancialStatementTemplateList().entrySet()) {
			if (entry.getValue().getFinancialStatementScheduleList() != null) {
				scheduleList.addAll(entry.getValue().getFinancialStatementScheduleList());
			}
		}
		try {
			fsTemplate.setFinancialStatementScheduleList(scheduleList);
			Long fsTemplateId = ftProxy.updateFinancialStatementTemplate(prepareFinancialStatementTemplate(fsTemplate,
					loggedInUser, taskId));

			String fnStatus = null;
			// if the request is to update the FT details in the transaction db
			// then create a task with workflow
			if (!isSave) {
				// Invoke the Workflow service to create/resubmit the workflow
				// task for the update operation. This will be invoked as a web service
				// call.
				// String taskId = (String) session.getAttribute("taskId");
				LOGGER.info("task id || " + taskId);
				LOGGER.info("fsTemplateId id || " + fsTemplateId);
				if (taskId != null && !taskId.trim().isEmpty()) {
					homeController.reSubmitTaskRequest(userContextVO, taskId,
							RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
							RefDataPropertiesConstants.FINANCE_TEMPLATE_SUBMITTER_GROUP_ID);
				} else {
					homeController.createReferenceData(String.valueOf(fsTemplateId),
							RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
							Long.valueOf(RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_FINANCIAL_TEMPLATES),
							loggedInUser, "FT Id: " + fsTemplateId,
							RefDataPropertiesConstants.FINANCE_TEMPLATE_APPROVER_GROUP_ID,
							RefDataPropertiesConstants.FINANCE_TEMPLATE_SUBMITTER_GROUP_ID); 
					// Submitter group id and approved group id is
					// given for CA_FT for R1
				}
				fnStatus = "submit_success";
			} else {
				// update the save function in the ui_svd_rec table
				ftProxy.insertSavedRecord(fsTemplateId, RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
						RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_FINANCIAL_TEMPLATES, loggedInUser, "ID:"
								+ fsTemplateId);
				fnStatus = "save_success";
			}
			
			// transaction logging
			transactionLogger.log(
					startTime,
					userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
							userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
					"financeTemplateUpdate", 0L, fsTemplateId, 0L, fsTemplate);
			
			return fnStatus;
		} catch (Exception e) {
			LOGGER.error("Exception Occurred : while trying to update financial template | " + e.getMessage());
			// transaction logging
			transactionLogger.log(
					startTime,
					userContextVO.getUserIdentifier(),
					roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
							userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
					"financeTemplateUpdate", 1000L, 0L, 0L, fsTemplate);
		}
		LOGGER.info("exiting FinancialTemplateController | financeTemplateUpdate");
		return "";
	}
	/**
	 * 
	 * The method to prepare the financial statment template
	 *
	 * @param fsTemplate
	 * @param loggedInUser
	 * @return
	 */
	private FinancialStatementTemplate prepareFinancialStatementTemplate(FinancialStatementTemplate fsTemplate,
			String loggedInUser, String taskId) {
		if (fsTemplate.getFinancialStatementTemplateId() == null) {
			fsTemplate.setFinancialStatementTemplateId(-1L);
		}
		fsTemplate.setCreatedDate(new Date());
		fsTemplate.setCreatedUser(loggedInUser);
		fsTemplate.setModifiedDate(new Date());
		fsTemplate.setEffectiveFromDate(new Date());
		fsTemplate.setEffectiveToDate(null);
		fsTemplate.setModifiedUser(loggedInUser);
		for (FinancialStatementSchedule schedule : fsTemplate.getFinancialStatementScheduleList()) {
			if (schedule.getFinancialStatementScheduleId() == null || (taskId == null || taskId.isEmpty())) {
				schedule.setFinancialStatementScheduleId(-1L);
			}
			schedule.setCreatedDate(new Date());
			schedule.setCreatedUser(loggedInUser);
			schedule.setModifiedDate(new Date());
			schedule.setModifiedUser(loggedInUser);
			for (FinancialStatementTemplateLineItem lineItem : schedule.getFinancialStatementTemplateLineItemList()) {
				if (lineItem.getFinancialStatementTemplateLineItemId() == null || (taskId == null || taskId.isEmpty())) {
					lineItem.setFinancialStatementTemplateLineItemId(-1L);
				}					
				lineItem.setCreatedDate(new Date());
				lineItem.setCreatedUser(loggedInUser);
				lineItem.setModifiedDate(new Date());
				lineItem.setModifiedUser(loggedInUser);
				FinancialStatementTemplateInternalLineItem internalLineItem = lineItem
						.getFinancialStatementTemplateInternalLineItem();
				if(internalLineItem != null) {
					internalLineItem.setCreatedDate(new Date());
					internalLineItem.setCreatedUser(loggedInUser);
					internalLineItem.setModifiedDate(new Date());
					internalLineItem.setModifiedUser(loggedInUser);
				}
				FinancialStatementTemplateOwnerLineItem ownerLineItem = lineItem
						.getFinancialStatementTemplateOwnerLineItem();
				if(ownerLineItem != null) {
					ownerLineItem.setCreatedDate(new Date());
					ownerLineItem.setCreatedUser(loggedInUser);
					ownerLineItem.setModifiedDate(new Date());
					ownerLineItem.setModifiedUser(loggedInUser);
				}
			}
		}
		LOGGER.info("FinancialTemplateController | prepareFinancialStatementTemplate | fsTemplate " + fsTemplate);
		return fsTemplate;
	}

	/**
	 * 
	 * The method is to populate the financialStatementTemplate with the values
	 * selected in the manage financial template screen. The values will be
	 * appended and populated in the FinlTemplateModelAttribute field using
	 * jQuery. The values will be appended in the format:
	 * stmt-type-code1:stmt-type-desc1#schd-code1:schd-desc1#
	 * litm-code1:litm-desc1:litem-seq1#litm-code2:litm-desc2:litem-seq2
	 * @stmt-type-code2:stmt-type-desc2...
	 * 
	 * 
	 * @param financialStatementTemplate
	 * @return financialStatementTemplate
	 */
	public FinancialStatementVO populateFinancialStatmentTemplates(
			FinancialStatementVO fsVO) {
		LOGGER.info("entering FinancialTemplateController | populateFinancialStatmentTemplates");
		LOGGER.info("FinancialTemplateController | populateFinancialStatmentTemplates | fsVO : " + fsVO);
		
		String finlTemplateModelAttribute = fsVO.getFinlTemplateModelAttribute();
		LOGGER.info("finlTemplateModelAttribute : " + finlTemplateModelAttribute);

		Map<Long, FinancialStatementTemplate> financialStatementTemplates = new LinkedHashMap<Long, FinancialStatementTemplate>();
		if(finlTemplateModelAttribute != null) {
			
			String[] financialStatementTypes = finlTemplateModelAttribute.split("@");
			// tc:td#sc:sd#l1c:l1d:l1s#l2c:l2d:l2s@
			FinancialStatementTemplate newTemplate = null;
			List<FinancialStatementSchedule> financialStatementSchedules = null;
			for(int sIndx = 0; sIndx < financialStatementTypes.length; sIndx++) {	
				String[] schlds = financialStatementTypes[sIndx].split("#");
				FinancialStatementSchedule financialStatementSchedule = new FinancialStatementSchedule();
				financialStatementSchedule.setFinancialStatementScheduleCode(Long.valueOf(schlds[1].split(":")[0]));
				financialStatementSchedule.setScheduleCodeDescription(schlds[1].split(":")[1]);
				// Added to fix the UAT issue : Retest defect 4765 16 Oct - Fail $starts$
				financialStatementSchedule.setFinancialStatementScheduleId(schlds[1].split(":").length > 2 ? Long
						.valueOf(schlds[1].split(":")[2]) : null);
				// Added to fix the UAT issue : Retest defect 4765 16 Oct - Fail $ends$
				
				newTemplate = new FinancialStatementTemplate();
				newTemplate.setFinancialTemplateTypeCode(Long.valueOf(schlds[0].split(":")[0]));
				newTemplate.setTypeCodeDescription(schlds[0].split(":")[1]);
				financialStatementSchedules = new ArrayList<FinancialStatementSchedule>();
				List<FinancialStatementTemplateLineItem> lineItems = new ArrayList<FinancialStatementTemplateLineItem>();
								
				for(int lIndx = 2; lIndx < schlds.length; lIndx++) {
					FinancialStatementTemplateLineItem lineItem = new FinancialStatementTemplateLineItem();
					lineItem.setFinancialStatementLineItemCode(Long.valueOf(schlds[lIndx].split(":")[0]));
					lineItem.setLineItemCodeDescription(schlds[lIndx].split(":")[1]);
					lineItem.setLineItemSequenceNumber(Long.valueOf(schlds[lIndx].split(":")[2]));
					lineItem.setLineItemGroupLevel(Long.valueOf(schlds[lIndx].split(":")[3]));
					lineItem.setHeaderIndicator(Boolean.valueOf(schlds[lIndx].split(":")[4]));
					// Added to fix the UAT issue : Retest defect 4765 16 Oct - Fail $starts$
					lineItem.setFinancialStatementTemplateLineItemId(schlds[lIndx].split(":").length > 6
							? Long.valueOf(schlds[lIndx].split(":")[6]) : null);
					// Added to fix the UAT issue : Retest defect 4765 16 Oct - Fail $ends$
					// populate templateInternalLineItem
					FinancialStatementTemplateInternalLineItem templateInternalLineItem = 
						new FinancialStatementTemplateInternalLineItem();
					// QC# 4767: Internal line item code not displayed (in Step 3 of UI)
					templateInternalLineItem.setInternalLineItemCode(String.valueOf(schlds[lIndx].split(":").length > 5
							? schlds[lIndx].split(":")[5] : ""));
					lineItem.setFinancialStatementTemplateInternalLineItem(templateInternalLineItem);
					// populate templateOwnerLineItem
					FinancialStatementTemplateOwnerLineItem templateOwnerLineItem = 
						new FinancialStatementTemplateOwnerLineItem();
					lineItem.setFinancialStatementTemplateOwnerLineItem(templateOwnerLineItem);
					
					lineItems.add(lineItem);
				}
				financialStatementSchedule.setFinancialStatementTemplateLineItemList(lineItems);
				financialStatementSchedules.add(financialStatementSchedule);
				newTemplate.setFinancialStatementScheduleList(financialStatementSchedules);
				if (financialStatementTemplates.containsKey(newTemplate.getFinancialTemplateTypeCode())) {
					financialStatementTemplates.get(newTemplate.getFinancialTemplateTypeCode())
							.getFinancialStatementScheduleList()
							.addAll(newTemplate.getFinancialStatementScheduleList());
				} else {
					financialStatementTemplates.put(newTemplate.getFinancialTemplateTypeCode(), newTemplate);
				}
			}
			fsVO.setFinancialStatementTemplateList(financialStatementTemplates);
			
		}
		LOGGER.info("exiting FinancialTemplateController | populateFinancialStatmentTemplates | returning : " + fsVO);
		return fsVO ;
	}	
	
	/**
     * The method return the finance template type code for a given finance template id
     * @param financeTemplateId
     * @return
     */
	@RequestMapping(value = "retrieveFinanceTemplateCodeById.form", method = RequestMethod.GET)
	public @ResponseBody Long retrieveFinanceTemplateCodeById(@RequestParam(value = "financeTemplateId") Long financeTemplateId){
		  return ftProxy.retrieveFinanceTemplateCodeById(financeTemplateId);
	}

	/**
	 * 
	 * The method to retrieve the sign codes in the financial template page. The
	 * system will search for the code table 634 and retun the code values.
	 * 
	 * @return codeValues
	 */
	@SuppressWarnings({"unchecked", "rawtypes"})
	public List<CodeValue> getSignCodes() {
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_NUMERIC_SIGN_CODE);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);

		List codeValues = tempCodeValueMap.get(String.valueOf(
				RefDataPropertiesConstants.CODE_TABLE_ID_NUMERIC_SIGN_CODE));
		return codeValues;
	}
	
	public String savefinanceTemplate(
			@ModelAttribute("financialStatementVO") FinancialStatementVO financialStatementVO,
			RequestContext context){
		LOGGER.info("entering FinancialTemplateController | savefinanceTemplate");
		//audit variables
		Date startTime = new Date();
		
		HttpSession session = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();
		
		FinancialStatementTemplate fsTemplate = new FinancialStatementTemplate();
		fsTemplate.setFinancialTemplateTypeCode(financialStatementVO.getFinancialStatementTypeCode());
		fsTemplate.setTemplateOwnerCode(RefDataPropertiesConstants.FINANCIAL_STMT_TEMPLATE_OWNER_CODE);
		List<FinancialStatementSchedule> scheduleList = new ArrayList<FinancialStatementSchedule>();
		for(Map.Entry<Long,FinancialStatementTemplate> entry:financialStatementVO.getFinancialStatementTemplateList().entrySet()){
			if(entry.getValue().getFinancialStatementScheduleList() != null){
				scheduleList.addAll(entry.getValue().getFinancialStatementScheduleList());
			}
		}
		
		fsTemplate.setFinancialStatementScheduleList(scheduleList);
		Long financeTemplateId = ftProxy.updateFinancialStatementTemplate(prepareFinancialStatementTemplate(fsTemplate,
				loggedInUser, null));

		// transaction logging
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES,
				"savefinanceTemplate", 0L, financeTemplateId, 0L, fsTemplate);
		
		LOGGER.info("exiting FinancialTemplateController | savefinanceTemplate");
		return "saveSucess";			
	}
	
	/**
	 * 
	 * The class to implement the comparator for Financial Statement Template line item
	 *  
	 * @author	Cognizant
	 * @version	last updated : Jul 7, 2012 
	 * @see  
	 *
	 */
	public class LineItemComparable implements Comparator<FinancialStatementTemplateLineItem> {
		@Override
		public int compare(FinancialStatementTemplateLineItem lineItem1, 
				FinancialStatementTemplateLineItem lineItem2) {
			return ((Integer)lineItem1.getLineItemSequenceNumber().intValue())
					.compareTo((Integer) lineItem2.getLineItemSequenceNumber().intValue());
		}
	}	
	/**
	 * 
	 * The class to implement the comparator for Financial Statement Schedule
	 *  
	 * @author	Cognizant
	 * @version	last updated : Jul 7, 2012 
	 * @see  
	 *
	 */
	public class ScheduleComparable implements Comparator<FinancialStatementSchedule> {
		@Override
		public int compare(FinancialStatementSchedule schedule1, 
				FinancialStatementSchedule schedule2) {
			return ((Integer)schedule1.getFinancialStatementScheduleId().intValue())
					.compareTo((Integer) schedule2.getFinancialStatementScheduleId().intValue());
		}
	}
}
