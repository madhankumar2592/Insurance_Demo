/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.util;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dnb.dsc.refdata.core.entity.GeoDefaultConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoHierarchy;
import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;

/**
 * The Cache is to provide EhCache support for the Reference Data application.
 * 
 * @author Cognizant
 * @version last updated : Mar 8, 2012
 * @see
 * 
 */
@Component
public class EhCacheProvider {
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(EhCacheProvider.class);
	
	@Autowired
	private GeographyWebServiceProxy wsProxy;

	/**
	 * 
	 * The method will retrieve all hierarchies for a geography domain. The data
	 * will be cached on screen load and the method will fetch the details from
	 * the EhCache.
	 * 
	 * @return geoHierarchies
	 */
	public List<GeoHierarchy> retrieveAllGeoHierarchies() {
		LOGGER.info("entering EhCacheProvider | retrieveAllGeoHierarchies");
		return wsProxy.retrieveAllGeoHierarchies();
	}
	
	/**
	 * 
	 * The method will retrieve all default configurations for a geography
	 * domain. The data will be cached on screen load and the method will fetch
	 * the details from the EhCache.
	 * 
	 * @return geoDefaultConfigurations
	 */
	public List<GeoDefaultConfiguration> retrieveAllGeoConfigurations() {
		LOGGER.info("entering EhCacheProvider | retrieveAllGeoConfigurations");
		return wsProxy.retrieveAllGeoConfigurations();
	}
}
