/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.interceptor.TransactionLogger;
import com.dnb.dsc.refdata.core.util.CommonUtil;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;
import com.dnb.dsc.refdata.web.util.OAMServiceUtil;
import com.dnb.dsc.refdata.web.util.OESServiceUtil;
import com.dnb.dsc.refdata.web.util.UserRoleMapper;
import com.dnb.dsc.refdata.web.util.WorkFlowWebServiceUtil;

/**
 * The Controller class for Home page. The methods of this class will be invoked
 * if the user hits the Home link.
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@Controller
public class HomeController {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(HomeController.class);

	@Autowired
	private GeographyWebServiceProxy wsProxy;

	@Autowired
	private WorkFlowWebServiceUtil webServiceUtil;

	@Autowired
	private OAMServiceUtil oneLoginUtil;

	@Autowired
	private OESServiceUtil oesUtil;

	@Autowired
	private RefDataConfigUtil refDataConfigUtil;

	@Autowired
	private TransactionLogger transactionLogger;

	@Autowired
	private UserRoleMapper roleMapper;



	/**
	 * Method to redirect to home page
	 * 
	 * @param request
	 * @param session
	 * @return ModelAndView
	 * @throws IOException 
	 */
	@RequestMapping(value = "/home.form", method = RequestMethod.GET)
	public ModelAndView redirect(HttpServletRequest request, HttpServletResponse response,HttpSession session)
			throws IOException {
		Date startTime = new Date();    	    	
		LOGGER.info("Reference Data Home Page | Start Time ::",startTime.getTime());
		// retrieve the OneLogin header information.
		UserContextVO userContext = oneLoginUtil.getUserContext(request);

		// User Context with test data is applicable only if OAM integration 
		// is not applicable. While developer unit testing.
		if (userContext.getUserIdentifier() == null) {
			LOGGER.info("Reference Data Home Page | Validating UserContext");
			LOGGER.error("ERROR! OAM Header information not accesible!");
			userContext = oneLoginUtil.populateUserContextWithTestData();
		}
		session.setAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT, userContext);

		// OES Component Initialization start
		List<String> accessibleResourceName = new ArrayList<String>();
		if (RefDataUIConstants.REFDATA_APP_DEPLOY_ENV_LOCAL.equals(refDataConfigUtil
				.getValue(RefDataPropertiesConstants.REFDATA_APP_DEPLOY_ENVIRONMENT))) {
			accessibleResourceName.add("GE_Basic");		
			accessibleResourceName.add("Industry_Approver");
			accessibleResourceName.add("Geo_Approver");
			accessibleResourceName.add("SCoTS_Approver");	
			accessibleResourceName.add("CW_Approver");
			accessibleResourceName.add(""
					+ "");				
		} else {
			Date oesStartTime = new Date();
			String role = CommonUtil.getCookieValue(request, "CAMS_SID_MYCAMSCLUSTER_REFDOMAIN");
			/*
			 * The code added to resolve the BIG IP redirection issue. It is
			 * confirmed from the web-server logs that refData calls in PreProd
			 * are directly called from BIG-IP redirections and the requests are
			 * NOT passed to the PreProd web-server. This is a application
			 * loop-hole. Whenever OBSSOCookie is not available, we need to
			 * redirect to the login page again.
			 * 
			 * Note: LOCAL environment will not contain OneLogin Header info
			 */
			if (role == null || role.length() <= 0) {
				LOGGER.info("Reference Data Home Page | Validating Cookie | Checking roles");
				LOGGER.error("ERROR! Cookie information not accesible!");
				response.sendRedirect("/dscuilogin.html");
			} else {
				List<String> userRoles = oesUtil.getRoleCodes(userContext);

				for(String userRole : userRoles){
					accessibleResourceName.add(userRole);
				}

			}

			// transaction logging for OES Integration
			transactionLogger.log(
					oesStartTime, userContext.getUserIdentifier(),
					roleMapper.getAllGroupNamesForUser(userContext.getUserRoles()), 
					null, "initializeOESElement", 0L, null, 0L, 
					accessibleResourceName == null ? "accessibleResourceName : null" : accessibleResourceName.size());
		}
		session.setAttribute("accessibleResourceName", accessibleResourceName);
		//session.setAttribute("oesUtil", oesUtil);
		// OES Component Initialization end

		// initialize the cache. load the data from DB
		loadCache(userContext.getUserIdentifier());

		// transaction logging for load home page
		transactionLogger.log(
				startTime, userContext.getUserIdentifier(),
				roleMapper.getAllGroupNamesForUser(userContext.getUserRoles()), 
				null, "loadHomePage", 0L, null, 0L);

		// return to home page
		final ModelAndView mav = new ModelAndView("home");
		return mav;
	}    

	/**
	 * Method to redirect to home page without loading the initial configuration
	 * 
	 * @return ModelAndView
	 */
	public ModelAndView redirect() {
		// return to home page
		final ModelAndView mav = new ModelAndView("home");
		return mav;
	}

	/**
	 * Method to redirect to home page from other tabs
	 * 
	 * @param
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/backToHome.form", method = RequestMethod.GET)
	public ModelAndView redirectHome() {
		final ModelAndView mav = new ModelAndView("backToHome");
		return mav;
	}

	/**
	 * 
	 * The method will contact the web service proxy class to retrieve code
	 * values and will return the map with table id as the key and the list of
	 * CodeValue objects as value.
	 * 
	 * @param codeTableIds
	 * @return
	 */
	public Map<String, List<CodeValue>> retrieveCodeValues(
			List<Integer> codeTableIds) {

		Map<Integer, List<CodeValue>> codeValueMap = wsProxy
				.retrieveCodeValues(codeTableIds,
						RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		for (Map.Entry<Integer, List<CodeValue>> entry : codeValueMap
				.entrySet()) {
			tempCodeValueMap.put(String.valueOf(entry.getKey()),
					entry.getValue());
		}

		return tempCodeValueMap;
	}
	public List<CodeValue> retrieveCodeValuesScores(
			List<Integer> codeTableIds) {

		List<CodeValue> codeValueMap = wsProxy
				.retrieveCodeValuesScores(codeTableIds,
						RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);		


		return codeValueMap;
	}
	public List<CodeValue> retrieveMktGrpCodes(
			) {

		List<CodeValue> codeValueMap = wsProxy.retrieveMktGrpCodes();		


		return codeValueMap;
	}


	public Map<String, List<CodeValue>> retrieveCodeValuesScr(
			List<Integer> codeTableIds) {

		Map<Integer, List<CodeValue>> codeValueMap = wsProxy
				.retrieveCodeValuesScr(codeTableIds,
						RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		for (Map.Entry<Integer, List<CodeValue>> entry : codeValueMap
				.entrySet()) {
			tempCodeValueMap.put(String.valueOf(entry.getKey()),
					entry.getValue());
		}

		return tempCodeValueMap;
	}
	/**
	 * 
	 * The method will load the cache mechanism. All details which are to be
	 * stored in the cache will be retrieved on screen load. There will be
	 * separate configuration files to maintain the cache time period. This is
	 * configured using the EH Cache
	 * 
	 * @param userIdentifier
	 */
	public void loadCache(String userIdentifier) {
		LOGGER.info("entering HomeController | loadCache");
		Date cacheStartTime = new Date();

		// retrieve Geography Hierarchies
		wsProxy.retrieveAllGeoHierarchies();
		// retrieve Geography Default Configurations
		wsProxy.retrieveAllGeoConfigurations();
		// retrieve User Group Mapping
		wsProxy.retrieveAllUserGroupMappings();

		// transaction logging for load cache
		transactionLogger.log(
				cacheStartTime, userIdentifier,
				new ArrayList<String>(), null, "loadCache", 0L, null, 0L);

		LOGGER.info("exiting HomeController | loadCache");
	}

	/**
	 * 
	 * The method will return the search results as a json map for the data
	 * table for display in the UI. 
	 * 
	 * @param request
	 * @param geographySearchList
	 * @param countResults
	 * @return geographySearchMap
	 */
	public Map<String, Object> getJsonMap(
			HttpServletRequest request,
			List<?> resultList,
			Long countResults, String[] columnArray) {
		LOGGER.info("invoked the count query | total number of items : " + countResults + "\n");
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		jsonMap.put("sEcho", request.getParameter("sEcho"));
		jsonMap.put("iTotalRecords", countResults);
		jsonMap.put("iTotalDisplayRecords", countResults);
		jsonMap.put("aaData",getDataTableRows(request, resultList, columnArray));
		return jsonMap;
	}

	/**
	 * 
	 * The method will return the list of rows which are to be displayed in the
	 * data table. The list will be constructed from the search results returned
	 * from the DB.
	 * 
	 * @param request
	 * @param geographySearchList
	 * @return rows
	 */
	@SuppressWarnings("rawtypes")
	private List<Object> getDataTableRows(HttpServletRequest request,
			List<?> resultList, String[] columnArray) {

		List<Object> rows = new ArrayList<Object>();
		Iterator itr = resultList.iterator();
		while (itr.hasNext()) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			Object[] row = new Object[columnArray.length];
			for (int i = 0; i < columnArray.length; i++) {
				if ("currencyExchangeDate".equalsIgnoreCase(columnArray[i])) {
					row[i] = getDateInDefaultFormat((Long)curr.get(columnArray[i]));
				} else {
					row[i] = curr.get(columnArray[i]);
				}
			}
			rows.add(row);
		}
		return rows;
	}
	/**
	 * 
	 * The method will convert the long date value in the default date format
	 *
	 * @param lDate
	 * @return date
	 */
	private String getDateInDefaultFormat(Long lDate){
		DateFormat defaultFormatter = new SimpleDateFormat(
				RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT);
		Date inputDate = new Date(lDate);
		return defaultFormatter.format(inputDate);
	}
	/**
	 * 
	 * TODO
	 *
	 * @param request
	 * @return
	 */
	public String getSearchString(HttpServletRequest request){
		return request.getParameter("sSearch");
	}
	/**
	 * 
	 * TODO
	 *
	 * @param request
	 * @return
	 */
	public int getStartIndex(HttpServletRequest request){
		String strartParam = request.getParameter("iDisplayStart");
		if(strartParam != null && !strartParam.trim().isEmpty()){
			return Integer.valueOf(strartParam);
		}else{
			return 0;
		}
	}
	/**
	 * 
	 * TODO
	 *
	 * @param request
	 * @return
	 */
	public int getMaxResults(HttpServletRequest request){
		String maxResultsParam = request.getParameter("iDisplayLength");
		if(maxResultsParam != null && !maxResultsParam.trim().isEmpty()){
			return Integer.valueOf(maxResultsParam);
		}else{
			return 10;
		}
	}
	/**
	 * 
	 * TODO
	 *
	 * @param request
	 * @param columnArray
	 * @return
	 */
	public String getSortBy(HttpServletRequest request, String[] columnArray) {
		String columnIndexParam = request.getParameter("iSortCol_0");
		if (columnIndexParam == null || columnIndexParam.trim().isEmpty()) {
			return columnArray[0];
		}
		int columnIndex = Integer.valueOf(columnIndexParam);
		if (columnIndex < columnArray.length) {
			return columnArray[columnIndex];
		} else {
			return columnArray[0];
		}
	}
	/**
	 * 
	 * TODO
	 *
	 * @param request
	 * @return
	 */
	public String getSortOrder(HttpServletRequest request) {
		String sortOrder = request.getParameter("sSortDir_0");
		if (sortOrder == null || sortOrder.trim().isEmpty()) {
			return "asc";
		} else {
			return sortOrder;
		}
	}

	/**
	 * 
	 * Triggers the work flow for any real time request received via the DSC UI.
	 * <p>
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeTypeId
	 * @param submitterEmailAddress
	 * @param notes
	 * @param approverGroupId
	 * @param submitterGroupId
	 */
	public void createReferenceData(
			String domainId, 
			String domainName, 
			Long changeTypeId, 
			String submitterEmailAddress,
			String notes,
			Long approverGroupId,
			Long submitterGroupId) {
		LOGGER.info("Entering HomeController | createReferenceData");
		createReferenceData(domainId, domainName, changeTypeId, submitterEmailAddress, notes, approverGroupId,
				submitterGroupId, RefDataUIConstants.WRKFLW_USER_ROLE_ID_SUBMITTER);		
		LOGGER.info("Exiting HomeController | createReferenceData");
	}

	/**
	 * 
	 * Triggers the work flow for any real time request received via the DSC UI.
	 * <p>
	 * The method will accepts an extra argument with user role identifier. The
	 * method is mainly used for Control Words domain where we have Auto Approve
	 * functionality.
	 * 
	 * @param domainId
	 * @param domainName
	 * @param changeTypeId
	 * @param submitterEmailAddress
	 * @param notes
	 * @param approverGroupId
	 * @param submitterGroupId
	 * @param userRoleId
	 */
	public void createReferenceData(
			String domainId, 
			String domainName, 
			Long changeTypeId, 
			String submitterEmailAddress,
			String notes,
			Long approverGroupId,
			Long submitterGroupId,
			Long userRoleId) {
		LOGGER.info("Entering HomeController | createReferenceData");
		try {
			webServiceUtil.createProcessInstance(
					domainId,
					domainName, 
					changeTypeId.longValue(),
					submitterEmailAddress,
					submitterGroupId.intValue(),
					approverGroupId.intValue(),
					notes,
					userRoleId
					);
		} catch (MalformedURLException e) {
			e.printStackTrace();
			LOGGER.error("Error in triggering work flow::",e);
		} catch (ServiceException e) {
			e.printStackTrace();
			LOGGER.error("Error in triggering work flow::",e);
		} catch (RemoteException e) {
			e.printStackTrace();
			LOGGER.error("Error in triggering work flow::",e);
		} catch(Exception e){
			e.printStackTrace();
			LOGGER.error("Error in triggering work flow::",e);
		}
		LOGGER.info("Exiting HomeController | createReferenceData");
	}

	/**
	 * 
	 * Triggers the work flow for any bulk request received via the DSC UI.
	 * <p>
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeTypeId
	 * @param submitterEmailAddress
	 * @param notes
	 * @param fileName
	 * @param approverGroupId
	 * @param submitterGroupId
	 */
	public void createCurrencyBulkUploadReferenceData(
			String domainId, 
			String domainName, 
			Long changeTypeId, 
			String submitterEmailAddress,
			String notes,
			String fileName,
			Long approverGroupId,
			Long submitterGroupId) {
		LOGGER.info("Entering HomeController | createCurrencyBulkUploadReferenceData");

		try {
			webServiceUtil.createProcessCurrencyBulkUploadInstance(
					domainId,
					domainName, 
					changeTypeId.longValue(),
					submitterEmailAddress,
					fileName,
					submitterGroupId.intValue(),
					approverGroupId.intValue(),
					notes);
		} catch (MalformedURLException e) {
			LOGGER.error("Error in triggering work flow for Currency BulkUpload request::",e);
		} catch (ServiceException e) {
			LOGGER.error("Error in triggering work flow for Currency BulkUpload request::",e);
		} catch (RemoteException e) {
			LOGGER.error("Error in triggering work flow for Currency BulkUpload request::",e);
		} catch(Exception e){
			LOGGER.error("Error in triggering work flow for Currency BulkUpload request::",e);
		}

		LOGGER.info("Exiting HomeController | createCurrencyBulkUploadReferenceData");
	}

	/**
	 * 
	 * The work-flow interface method to be invoked for any re-submit action.
	 *
	 * @param userContextVO
	 * @param taskId
	 * @param domainName
	 * @param submitterGroupId
	 */
	public void reSubmitTaskRequest(
			UserContextVO userContextVO, 
			String taskId,
			String domainName,
			Long submitterGroupId) {
		LOGGER.info("Entering HomeController | reSubmitTaskRequest");
		try {
			webServiceUtil.reSubmitTaskRequest(
					userContextVO.getUserIdentifier(),
					submitterGroupId.intValue(), 
					Integer.valueOf(taskId));
		} catch (MalformedURLException e) {
			LOGGER.error("Error in re-submitting the request::",e);
		} catch (ServiceException e) {
			LOGGER.error("Error in re-submitting the request::",e);
		} catch (RemoteException e) {
			LOGGER.error("Error in re-submitting the request::",e);
		} catch(Exception e){
			LOGGER.error("Error in re-submitting the request::",e);
		}
		LOGGER.info("Exiting HomeController | reSubmitTaskRequest");

	}


	/**
	 * 
	 * Triggers the work flow for any Industry Code BulkUpload ReferenceData request received via the DSC UI.
	 * <p>
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeTypeId
	 * @param submitterEmailAddress
	 * @param notes
	 * @param fileName
	 * @param approverGroupId
	 * @param submitterGroupId
	 */
	public void createIndustryCodeBulkUploadReferenceData(
			String domainId, 
			String domainName, 
			Long changeTypeId, 
			String submitterEmailAddress,
			String notes,
			String fileName,
			Long approverGroupId,
			Long submitterGroupId) {
		LOGGER.info("Entering HomeController | createIndustryCodeBulkUploadReferenceData");

		try {
			webServiceUtil.createProcessIndustryCodeBulkUploadInstance(
					domainId,
					domainName, 
					changeTypeId.longValue(),
					submitterEmailAddress,
					fileName,
					submitterGroupId.intValue(),
					approverGroupId.intValue(),
					notes);
		} catch (MalformedURLException e) {
			LOGGER.error("Error in triggering work flow for Industry Code BulkUpload request::",e);
		} catch (ServiceException e) {
			LOGGER.error("Error in triggering work flow for Industry Code BulkUpload request::",e);
		} catch (RemoteException e) {
			LOGGER.error("Error in triggering work flow for Industry Code BulkUpload request::",e);
		} catch(Exception e){
			LOGGER.error("Error in triggering work flow for Industry Code BulkUpload request::",e);
		}

		LOGGER.info("Exiting HomeController | createIndustryCodeBulkUploadReferenceData");
	}
	/**
	 * 
	 * Triggers the work flow for any real time request received via the DSC UI.
	 * <p>
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeTypeId
	 * @param submitterEmailAddress
	 * @param notes
	 * @param fileName
	 * @param approverGroupId
	 * @param submitterGroupId
	 */
	public void createGeoBulkUploadReferenceData(
			String domainId, 
			String domainName, 
			Long changeTypeId, 
			String submitterEmailAddress,
			String notes,
			String fileName,
			Long approverGroupId,
			Long submitterGroupId) {
		LOGGER.info("Entering HomeController | createIndustryCodeBulkUploadReferenceData");

		createIndustryCodeBulkUploadReferenceData(domainId, domainName, changeTypeId, submitterEmailAddress, notes,
				fileName, approverGroupId, submitterGroupId);

		LOGGER.info("Exiting HomeController | createIndustryCodeBulkUploadReferenceData");
	}

	/**
	 * 
	 * Triggers the work flow for any real time request received via the DSC UI.
	 * <p>
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeTypeId
	 * @param submitterEmailAddress
	 * @param notes
	 * @param fileName
	 * @param approverGroupId
	 * @param submitterGroupId
	 */
	public void createScotsBulkUploadReferenceData(
			String domainId, 
			String domainName, 
			Long changeTypeId, 
			String submitterEmailAddress,
			String notes,
			String fileName,
			Long approverGroupId,
			Long submitterGroupId) {
		LOGGER.info("Entering HomeController | createScotsBulkUploadReferenceData");

		createGeoBulkUploadReferenceData(domainId, domainName, changeTypeId, submitterEmailAddress, notes, fileName,
				approverGroupId, submitterGroupId);

		LOGGER.info("Exiting HomeController | createScotsBulkUploadReferenceData");
	}
	/**
	 * 
	 * Triggers the work flow for any real time request received via the DSC UI.
	 * <p>
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeTypeId
	 * @param submitterEmailAddress
	 * @param notes
	 * @param fileName
	 * @param approverGroupId
	 * @param submitterGroupId
	 */
	public void createCtrlWrdsBulkUploadReferenceData(
			String domainId, 
			String domainName, 
			Long changeTypeId, 
			String submitterEmailAddress,
			String notes,
			String fileName,
			Long approverGroupId,
			Long submitterGroupId) {
		LOGGER.info("Entering HomeController | createIndustryCodeBulkUploadReferenceData");

		createScotsBulkUploadReferenceData(domainId, domainName, changeTypeId, submitterEmailAddress, notes, fileName,
				approverGroupId, submitterGroupId);

		LOGGER.info("Exiting HomeController | createIndustryCodeBulkUploadReferenceData");
	}

	@RequestMapping(value = "/errorHanlder.form", method = RequestMethod.GET)
	public ModelAndView errorHanlder() {
		ModelAndView mav = new ModelAndView("refDataError");
		ReferenceDataExceptionVO exception = new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, "Ajax call ended in error");
		LOGGER.info("exception:::",exception); 
		mav.addObject("exception", exception);
		return mav;
	}



	/**
	 * extend session
	 */    
	@RequestMapping(value = "/extendSession.form", method = RequestMethod.GET)
	public void extendSession() {		
		LOGGER.info("Extending session");

	}

	@RequestMapping(value = "/myLinks.form", method = RequestMethod.GET)
	public @ResponseBody
	ModelAndView downloadUserGuide(@RequestParam("fileName") String fileName,
			HttpServletResponse response) {
		LOGGER.info("Inside HomeController || downloadUserGuide ");
		File file = null;
		file = new File(
				refDataConfigUtil
				.getValue(RefDataPropertiesConstants.REFDATA_USERGUIDE_LOCATION)
				+ fileName);
		FileInputStream fin;
		try {
			fin = new FileInputStream(file);
			response.setContentType("application/docx");
			response.setContentLength((int) file.length());
			response.setHeader("Content-Disposition", "attachment; filename=\""
					+ fileName + "\"");
			FileCopyUtils.copy(fin, response.getOutputStream());
			response.getOutputStream().close();
			fin.close();
			response.flushBuffer();
		} catch (FileNotFoundException e) {
			LOGGER.error("Error in opening UserGuide/FAQ files"+e);
		} catch (Exception e) {
			LOGGER.error("Error in opening UserGuide/FAQ files"+e);
		}

		return null;
	}

	@RequestMapping("/logout.form")
	public void logout(HttpSession session,HttpServletResponse response) throws IOException{
		session.invalidate();
		response.sendRedirect("/logout.html");
		//  return new ModelAndView("/logout.html");//if you have two differenet web pages for login and logout else you can redirect to login.jsp
	}

	/**
	 * 
	 * Downmload Bulk file Templates  via the DSC UI.
	 * <p>
	 *
	 * @param fileName
	 * @throws FileNotFoundException 
	 * 
	 * 
	 */

	@RequestMapping(value = "/fileDownload.form", method = RequestMethod.GET)
	public @ResponseBody ModelAndView downloadBulkTemplate(@RequestParam("fileName") String fileName,
			HttpServletResponse response) throws FileNotFoundException{

		LOGGER.info("Inside HomeController || DownloadBulkTemplate ");


		File file=new File(refDataConfigUtil
				.getValue(RefDataPropertiesConstants.REFDATA_BLK_TEMPLATE_DOWNLOAD_LOCATION)
				+ fileName);
		FileInputStream fin=new FileInputStream(file);

		try {

			response.setContentType("xlsx/docx");			
			response.setContentLength((int) file.length());
			response.setHeader("Content-Disposition", "attachment; filename=\""
					+ fileName + "\"");
			FileCopyUtils.copy(fin, response.getOutputStream());
			response.getOutputStream().close();
			fin.close();
			response.flushBuffer();			
		} catch (IOException e) {
			System.out.println("Inside");
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_BULK_NOT_FOUND, e);

		}finally {

			try {
				fin.close();
			} catch (IOException e) {
				LOGGER.error("Error in Downloading files"+e);
			}

		}

		LOGGER.info("Exiting HomeController || DownloadBulkTemplate ");
		return null;

	}

}
