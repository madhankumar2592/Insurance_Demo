/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.proxy;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.SCoTSSearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.ScotsBulkDowloadVO;
import com.dnb.dsc.refdata.web.util.RestWebServiceUtil;

/**
 * The web service proxy class will handle the mapping between the UI web
 * requests and the respective service end point class. The class will construct
 * the REST WS requests and exchange the request with the service end point for
 * the response.
 * <p>
 *
 * The web service proxy class will handle all the service requests within the
 * SCoTS domain.
 * <p>
 *
 * @author Cognizant
 * @version last updated : Mar 23, 2012
 * @see
 *
 */
@Component
public class SCoTSWebServiceProxy {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SCoTSWebServiceProxy.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private RefDataConfigUtil refDataConfigUtil;

	@Autowired
	private RestWebServiceUtil restWSUtil;

	/**
	 *
	 * Retrieves the SCoTS Code Table search Results.
	 * <p>
	 * The search will be done on the STG db based on the search criteria the
	 * user had provided.
	 * <p>
	 *
	 * @param searchCriteriaVO
	 * @return list of CodeTable
	 */
	@SuppressWarnings("unchecked")
	public List<CodeTable> searchCodeTables(
			SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTSWebServiceProxy | searchCodeTables");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/searchCodeTables.service";
		HttpEntity<SCoTSSearchCriteriaVO> entity = new HttpEntity<SCoTSSearchCriteriaVO>(
				searchCriteriaVO);
		LOGGER.info("exiting SCoTSWebServiceProxy | searchCodeTables");
		return (List<CodeTable>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}

	/**
	 *
	 * Retrieves the SCoTS Code Value search Results.
	 * <p>
	 * The search will be done on the STG db based on the search criteria the
	 * user had provided.
	 * <p>
	 *
	 * @param searchCriteriaVO
	 * @return list of CodeValue
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValue> searchCodeValues(
			SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTSWebServiceProxy | searchCodeValues" + searchCriteriaVO);

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/retrieveCodeValuesByTableId.service";
		HttpEntity<SCoTSSearchCriteriaVO> entity = new HttpEntity<SCoTSSearchCriteriaVO>(
				searchCriteriaVO);
		LOGGER.info("exiting SCoTSWebServiceProxy | searchCodeValues");
		return (List<CodeValue>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}

	/**
	 *
	 * The method will count the records in the hierarchy search of code values
	 * on the search db. The search will be done on the flat db based on the
	 * search criteria the user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return count of search results
	 */
	public Long countCodeValuesByTableId(SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTSWebServiceProxy | countCodeValuesByTableId");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/countCodeValuesByTableId.service";
		HttpEntity<SCoTSSearchCriteriaVO> entity = new HttpEntity<SCoTSSearchCriteriaVO>(
				searchCriteriaVO);
		LOGGER.info("exiting SCoTSWebServiceProxy | countCodeValuesByTableId ");
		return (Long) this.restTemplate.postForObject(serviceURL, entity,
				Long.class, new Object[0]);
	}

	/**
	 * The method will retrieve all Code Tables from the Search DB
	 * The return type is a VO which contains the Code Table Id and the Code Table Name.
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveCodeTableList() {
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveCodeTableList");
		String serviceURL = "/retrieveCodeTableList.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL);
	}

	/**
	 * The method will retrieve all Code Languages from the Search DB.
	 * The return type is a VO which contains the Code Value Id and the Code Value Description.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveCodeLanguages() {
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveCodeLanguages");
		String serviceURL = "/retrieveCodeLanguages.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL);
	}

	/**
	 * The method will retrieve all applicable systems from the Search DB.
	 * The return type is a VO which contains the Code Value Id and the Code Value Description.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveSystemApplicability(Long codeTableId, int applicabilityIndicator) {
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveSystemApplicability");
		String serviceURL = "/{codeTableId}/{applicabilityIndicator}/retrieveSystemApplicability.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL, codeTableId,applicabilityIndicator);
	}

	/**
	 * 
	 * The method to retrieve all system applicability
	 *
	 * @param applicability
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllSystemApplicability(String applicability) {
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveAllSystemApplicability");
		String serviceURL = "/{applicability}/retrieveAllSystemApplicability.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL, applicability);
	}

	/**
	 * The method will retrieve all applicable countries from the Search DB.
	 * The return type is a VO which contains the Code Value Id and the Code Value Description.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveCountryApplicability(Long codeTableId, int applicabilityIndicator) {
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveCountryApplicability");
		String serviceURL = "/{codeTableId}/{applicabilityIndicator}/retrieveCountryApplicability.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL, codeTableId,applicabilityIndicator);
	}

	/**
	 * The method will search the Staging SoR for the Code Table based on the Code Table
	 * Id and will return the CodeTable entity.
	 *
	 * @param codeTableId
	 * @return
	 */
	public CodeTable retrieveCodeTableById(Long codeTableId) {
		return retrieveCodeTable(codeTableId, "/{codeTableId}/retrieveCodeTableById.service");
	}

	/**
	 * The method will search the Transaction SoR for the Code Table based on the Code Table
	 * Id and will return the CodeTable entity.
	 *
	 * @param codeTableId
	 * @return
	 */
	public CodeTable reviewCodeTableChanges(Long codeTableId) {
		return retrieveCodeTable(codeTableId, "/{codeTableId}/reviewCodeTableChanges.service");
	}
	/**
	 * 
	 * The generic method to retrieve the code table details passing the code table id
	 *
	 * @param codeTableId
	 * @param deployURL
	 * @return
	 */
	private CodeTable retrieveCodeTable(Long codeTableId, String deployURL) {
		HttpEntity<CodeTable> entity = new HttpEntity<CodeTable>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + deployURL;
		ResponseEntity<CodeTable> result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
				CodeTable.class, codeTableId);
		return result != null ? result.getBody() : null;
	}
	/**
	 * The method will search the Transaction SoR for the Code Table based on the Code Value
	 * Id and will return the CodeTable entity.
	 *
	 * @param codeValueId
	 * @return
	 */
	public CodeValue reviewCodeValueChanges(Long codeValueId) {
		LOGGER.info("entering SCoTSWebServiceProxy | reviewCodeValueChanges");

		HttpEntity<CodeValue> entity = new HttpEntity<CodeValue>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{codeValueId}/reviewCodeValueChanges.service";
		ResponseEntity<CodeValue> result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
				CodeValue.class, codeValueId);
		LOGGER.info("exiting SCoTSWebServiceProxy | reviewCodeValueChanges ||result: " + result);
		return result != null ? result.getBody() : null;
	}
	/**
	 *
	 * The method to fetch the count of Code Value details based on the filter
	 * condition. The Code Value will be searched based on description or on the
	 * business description.
	 *
	 * @param searchCriteriaVO
	 * @return countCodeValues
	 */
	public Long countOfSearchCodeValues(SCoTSSearchCriteriaVO searchCriteriaVO) {
		return countSCoTS(searchCriteriaVO, "/countOfSearchCodeValues.service");
	}

	/**
	 *
	 * The method will count the records in the hierarchy search of code tables
	 * on the search db. The search will be done on the flat db based on the
	 * search criteria the user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return count of search results
	 */
	public Long countSearchCodeTables(SCoTSSearchCriteriaVO searchCriteriaVO) {
		return countSCoTS(searchCriteriaVO, "/countSearchCodeTables.service");
	}
	/**
	 * 
	 * The method will count the records in the code value/ table. This is
	 * generic for the search with SCoTSSearchCriteriaVO as the argument
	 * 
	 * @param searchCriteriaVO
	 * @param deployURL
	 * @return
	 */
	private Long countSCoTS(SCoTSSearchCriteriaVO searchCriteriaVO, String deployURL) {
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + deployURL;
		HttpEntity<SCoTSSearchCriteriaVO> entity = new HttpEntity<SCoTSSearchCriteriaVO>(searchCriteriaVO);
		return (Long) this.restTemplate.postForObject(serviceURL, entity, Long.class, new Object[0]);
	}

	/**
	 *
	 * The method to fetch the Code Value details based on the filter condition.
	 * The Code Value will be searched based on description or on the business
	 * description.
	 *
	 * @param searchCriteriaVO
	 * @return codeValues
	 */
	@SuppressWarnings("unchecked")
	public List<CodeTable> searchSCoTSCodeValues(
			SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTSWebServiceProxy | searchSCoTSCodeValues");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/searchCodeValues.service";
		HttpEntity<SCoTSSearchCriteriaVO> entity = new HttpEntity<SCoTSSearchCriteriaVO>(
				searchCriteriaVO);
		LOGGER.info("exiting SCoTSWebServiceProxy | searchSCoTSCodeValues");
		return (List<CodeTable>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}

	/**
	 * Searches the Staging DB for the Code Value based on the codeValueId and will return the CodeValue entity.<p>
	 *
	 * @param codeValueId
	 * @return CodeValue
	 */
	public CodeValue retrieveCodeValueByCodeValueId(Long codeValueId) {
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveCodeValueByCodeValueId");
		HttpEntity<CodeValue> entity = new HttpEntity<CodeValue>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{codeValueId}/retrieveCodeValueByCodeValueId.service";
		ResponseEntity<CodeValue> result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
				CodeValue.class, codeValueId);
		LOGGER.info("exiting SCoTSWebServiceProxy | retrieveCodeValueByCodeValueId || result: "
				+ result);
		return result != null ? result.getBody() : null;
	}

	/**
	 *
	 * The method to retrieve all codeValue associations from database. The
	 * method will accept the parent and child code table Id s and will return
	 * all associations having the relationship between the specified parent and
	 * child code tables.
	 *
	 * @param parentCodeTableId
	 * @param childCodeTableId
	 * @return List<CodeValueAssociation>
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueAssociation> retrieveCodeValueAssociations(
			Long parentCodeTableId, Long childCodeTableId, Boolean isStagingDB) {
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveCodeValueAssociations");
		LOGGER.info("parentCodeTableId : " + parentCodeTableId);
		LOGGER.info("childCodeTableId : " + childCodeTableId);
		String serviceURL = "/{parentCodeTableId}/{childCodeTableId}/{isStagingDB}/retrieveCodeValueAssociations.service";
		return restWSUtil.exchangeForList(CodeValueAssociation.class, serviceURL, parentCodeTableId,
				childCodeTableId, isStagingDB);
	}

	/**
	 *
	 * The method to retrieve all alternate schema code types from the database.
	 * The method will invoke the web-service to retrieve the data.
	 *
	 * @return List<CodeValueVO>
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllAlternateSchemeCodes() {
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveAllAlternateSchemeCodes");
		String serviceURL = "/retrieveAllAlternateSchemeCodes.service";
		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL);
	}
	/**
	 * The method will retrieve all applicable systems from the Search DB.
	 * The return type is a list of SystemApplicability
	 *
	 */
	@SuppressWarnings("rawtypes")
	public List retrieveSystemForCode(String applicability, Long applicabilityCode,
			Boolean isStagingDB) {
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveSystemForCode");

		HttpEntity<List> entity = new HttpEntity<List>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{applicability}/{applicabilityCode}/{isStagingDB}/retrieveSystemForCode.service";
		ResponseEntity<List> result = this.restTemplate.exchange(serviceURL, HttpMethod.GET,
				entity, List.class, new Object[] { applicability, applicabilityCode, isStagingDB});
		LOGGER.info("exiting SCoTSWebServiceProxy | retrieveSystemForCode");
		return result != null ? (List) result.getBody() : null;
	}


	/**
	 *
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the staging
	 * DB to fetch all alternate scheme codes matching the scheme type code
	 * selected by the user.
	 *
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueAlternateScheme> retrieveAlternateSchemeCodes(
			Long schemeTypeCode) {
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveAlternateSchemeCodes");
		String serviceURL = "/{schemeTypeCode}/retrieveAlternateSchemeCodes.service";
		return restWSUtil.exchangeForList(CodeValueAlternateScheme.class, serviceURL, schemeTypeCode);
	}

	/**
	The method will persist the edited code table in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * @param codeTable
	 */
	public Long updateCodeTable(CodeTable codeTable) {
		LOGGER.info("entering SCoTSWebServiceProxy | updateCodeTable");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/updateCodeTable.service";
		HttpEntity<CodeTable> entity = new HttpEntity<CodeTable>(
				codeTable);
		LOGGER.info("exiting SCoTSWebServiceProxy | updateCodeTable");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}

	/**
	 *
	 * The method will validate the Code Table for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param codeTableId
	 * @return
	 */
	public String lockCodeTable(Long codeTableId) {
		LOGGER.info("entering SCoTSWebServiceProxy | lockCodeTable");

		HttpEntity<String> entity = new HttpEntity<String>(
				restWSUtil.constructRequestHeader());
		String serviceURL =refDataConfigUtil.getServiceDeployURL() + "/{codeTableId}/lockCodeTable.service";
		ResponseEntity<String> result = this.restTemplate.exchange(serviceURL, HttpMethod.GET,
				entity, String.class, new Object[] { codeTableId });
		LOGGER.info("exiting SCoTSWebServiceProxy | lockCodeTable");
		return result != null ? (String) result.getBody() : null;
	}




	/**
	 * 
	 * The method will validate the Code Value for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param codeValueId
	 * @return
	 */
	public String lockCodeValue(Long codeValueId) {
		LOGGER.info("entering SCoTSWebServiceProxy | lockCodeValue");

		HttpEntity<String> entity = new HttpEntity<String>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{codeValueId}/lockCodeValue.service";
		ResponseEntity<String> result = this.restTemplate.exchange(serviceURL, HttpMethod.GET,
				entity, String.class, new Object[] { codeValueId });
		LOGGER.info("exiting SCoTSWebServiceProxy | lockCodeValue");
		return result != null ? (String) result.getBody() : null;
	}

	/**
	 * 
	 * The method will validate the Alternate Scheme Codes for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param alternateSchemeTypeCode
	 * @return
	 */
	public String lockAltSchemeCode(Long alternateSchemeTypeCode) {
		LOGGER.info("entering SCoTSWebServiceProxy | lockAltSchemeCode");

		HttpEntity<String> entity = new HttpEntity<String>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{alternateSchemeTypeCode}/lockAltSchemeCode.service";
		ResponseEntity<String> result = this.restTemplate.exchange(serviceURL, HttpMethod.GET,
				entity, String.class, new Object[] { alternateSchemeTypeCode });
		LOGGER.info("exiting SCoTSWebServiceProxy | lockAltSchemeCode");
		return result != null ? (String) result.getBody() : null;
	}
	/**
	 * 
	 * The method to update the applicability information
	 *
	 * @param codeTable
	 * @param isSystemApplicability
	 * @return
	 */
	public Long updateApplicability(CodeTable codeTable, Boolean isSystemApplicability) {
		LOGGER.info("entering SCoTSWebServiceProxy | updateApplicability");

		String queryParams = "/{isSystemApplicability}/updateApplicability.service";
		HttpEntity<CodeTable> entity = new HttpEntity<CodeTable>(codeTable);
		LOGGER.info("exiting SCoTSWebServiceProxy | updateApplicability");
		return restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Long.class, isSystemApplicability);
	}
	/**
	The method will persist the edited code Value in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * @param codeValue
	 */
	public Long updateCodeValue(CodeValue codeValue) {
		LOGGER.info("entering SCoTSWebServiceProxy | updateCodeValue");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/updateCodeValue.service";
		HttpEntity<CodeValue> entity = new HttpEntity<CodeValue>(
				codeValue);
		LOGGER.info("exiting SCoTSWebServiceProxy | updateCodeValue");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}

	/**
	The method will persist the edited Code Value association in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * @param SCoTSSearchCriteriaVO
	 */
	public Long updateCodeValueAssociation(SCoTSSearchCriteriaVO sCoTSSearchCriteriaVO) {
		return updateCodeValueChildren(sCoTSSearchCriteriaVO, "/updateCodeValueAssociation.service");
	}

	/**
	The method will persist the edited Code Value Alternate Scheme in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * @param SCoTSSearchCriteriaVO
	 */
	public Long updateCodeValueAlternateScheme(SCoTSSearchCriteriaVO sCoTSSearchCriteriaVO) {
		return updateCodeValueChildren(sCoTSSearchCriteriaVO, "/updateCodeValueAlternateScheme.service");
	}
	/**
	 * 
	 * The method to update the codeValue child entities.
	 *
	 * @param sCoTSSearchCriteriaVO
	 * @param deployURL
	 * @return
	 */
	private Long updateCodeValueChildren(SCoTSSearchCriteriaVO sCoTSSearchCriteriaVO, String deployURL) {
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + deployURL;
		HttpEntity<SCoTSSearchCriteriaVO> entity = new HttpEntity<SCoTSSearchCriteriaVO>(
				sCoTSSearchCriteriaVO);
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}

	/**
	 *
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the staging
	 * DB to fetch all alternate scheme codes matching the scheme type code
	 * selected by the user.
	 *
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueAlternateScheme> reviewAlternateSchemeCodeChanges(
			Long schemeTypeCode) {
		LOGGER.info("entering SCoTSWebServiceProxy | reviewAlternateSchemeCodeChanges");
		String serviceURL = "/{schemeTypeCode}/reviewAlternateSchemeCodeChangess.service";
		return restWSUtil.exchangeForList(CodeValueAlternateScheme.class, serviceURL, schemeTypeCode);
	}
	/**
	 * The method will down load the scots code based on the 
	 * IndustryCode type, languages and description length code.
	 * 
	 * @param scotsBulkDowloadVO
	 * @return 
	 */

	public Boolean scotsBulkDownload(ScotsBulkDowloadVO scotsBulkDowloadVO) {
		LOGGER.info("entering SCoTSWebServiceProxy | industryCodeBulkDownload");		
		String serviceURL = refDataConfigUtil.getBatchDeployURL()+ "/codeTableBulkDownload.service";			
		HttpEntity<ScotsBulkDowloadVO> entity = new HttpEntity<ScotsBulkDowloadVO>(scotsBulkDowloadVO);		
		LOGGER.info("exiting SCoTSWebServiceProxy | scotsBulkDownload");
		return restTemplate.postForObject(serviceURL, entity, Boolean.class);
	}

	/**
	 * The method will add UiBulkDownload data in the Transactional 
	 * 	 * DB. 
	 * 
	 * @param UiBulkDownload
	 * @return insert status
	 */
	public Long addUIBulkDownload(UiBulkDownload uiBulkDownload) {
		LOGGER.info("entering SCoTSWebServiceProxy | addUIBulkDownload");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/addUIBulkDownload.service";

		HttpEntity<UiBulkDownload> entity = new HttpEntity<UiBulkDownload>(uiBulkDownload);
		LOGGER.info("exiting SCoTSWebServiceProxy | addUIBulkDownload");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}

	/**
	 * 
	 * The method to retrieve all valid industry code group levels
	 *
	 * @return validIndustryCodeGroupLevels
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveValidIndustryCodeGroupLevels() {
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveValidIndustryCodeGroupLevels");
		String queryParams = "/retrieveValidIndustryCodeGroupLevels.service";
		return restWSUtil.exchangeForList(CodeValue.class, queryParams);
	}

	/**
	 * If applicability is "System", value of dnbSystemCode will be dnbSystemCode
	 * in sys_appy table. If it is "Market", value of dnbSystemCode will be 
	 * ctry_geo_unit_id in ctry_appy table. This method checks if the applicability 
	 * with given dnbSystemCode is already present in transactional db. If it exists, 
	 * the return map will contain isLocked=true and username=modifiedUser. Else the 
	 * map will contain isLocked=false and username="".
	 * 
	 * @param dnbSystemCode
	 * @param applicability
	 * @return map
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<String, Object> lockApplicabilityForEdit(Long dnbSystemCode, String applicability){
		LOGGER.info("entering SCoTSWebServiceProxy | lockApplicabilityForEdit");
		HttpEntity<Map<String, Object>> entity = new HttpEntity<Map<String, Object>>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{dnbSystemCode}/{applicability}/lockApplicabilityForEdit.service";
		ResponseEntity<Map> result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
				Map.class, dnbSystemCode, applicability);
		LOGGER.info("exiting SCoTSWebServiceProxy | lockApplicabilityForEdit");
		return result != null ? result.getBody() : null;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<String, List<SavedRecord>> retrieveSavedRecordsByDomainName(String domainName){
		LOGGER.info("entering SCoTSWebServiceProxy | retrieveSavedRecordsByDomainName");
		HttpEntity<Map<String, List<SavedRecord>>> entity = new HttpEntity<Map<String, List<SavedRecord>>>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{domainName}/retrieveSavedRecordByDomainName.service";
		ResponseEntity<Map> result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
				Map.class, domainName);
		LOGGER.info("exiting SCoTSWebServiceProxy | retrieveSavedRecordsByDomainName");
		return result != null ? result.getBody() : null;
	}

	/** Implemented to fix 209048785 -Edit SCoTS Approval Page**/
	@SuppressWarnings({"unused" })
	public Boolean editApprovalCodeValue(String reasonText,
			String businessDescription, Long cdvalid, String ApproverId) {
		LOGGER.info("entering SCoTSWebServiceProxy | editApprovalCodeValue");
		HttpEntity<Boolean> entity = new HttpEntity<Boolean>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{reasonText}/{businessDescription}/{cdvalid}/{ApproverId}/update.service";
		ResponseEntity<Boolean> result = restTemplate.exchange(serviceURL,
				HttpMethod.GET, entity, Boolean.class, reasonText,
				businessDescription, cdvalid, ApproverId);
		LOGGER.info("exiting SCoTSWebServiceProxy | editApprovalCodeValue");
		return true;

	}

	/**
	 *
	 * The method will validate the Code Table for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param codeTableId
	 * @return
	 */
	public String lockCodeRelationship(Long parentCodeTableId,Long childCodeTableId) {
		
		LOGGER.info("entering SCoTSWebServiceProxy | lockCodeRelationship");
		HttpEntity<String> entity = new HttpEntity<String>(
				restWSUtil.constructRequestHeader());
		String serviceURL =refDataConfigUtil.getServiceDeployURL() + "/{parentCodeTableId}/{childCodeTableId}/lockCodeRelationship.service";
		ResponseEntity<String> result = this.restTemplate.exchange(serviceURL, HttpMethod.GET,
				entity, String.class, new Object[] { parentCodeTableId ,childCodeTableId});	
		
		LOGGER.info("exiting SCoTSWebServiceProxy | lockCodeRelationship");
		return result != null ? (String) result.getBody() : null;		
		
	}
}
