/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;

/**
 * The Cache is to provide EhCache support for the Reference Data application.
 * 
 * @author Cognizant
 * @version last updated : Mar 8, 2012
 * @see
 * 
 */
@Component
public class RestWebServiceUtil {
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(RestWebServiceUtil.class);
	
	@Autowired
	private RefDataConfigUtil refDataConfigUtil;
	
	@Autowired
	private RestTemplate restTemplate;
	
	/**
	 * The method will construct the REST web service request headers. The
	 * header media type is set to JSON.
	 * 
	 * @return headers
	 */
	public HttpHeaders constructRequestHeader() {

		List<MediaType> acceptableMediaTypes = new ArrayList<MediaType>();
		acceptableMediaTypes.add(MediaType.APPLICATION_JSON);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(acceptableMediaTypes);
		return headers;
	}
	
	/**
	 * 
	 * The method to obtain the service URL for a given query String
	 *
	 * @param queryParams
	 * @return serviceURL
	 */
	public String getServiceURL(String queryParams) {
		LOGGER.info("queryParams : " + queryParams);
		return refDataConfigUtil.getServiceDeployURL() + queryParams;
	}
	
	/**
	 * 
	 * The method to obtain the Batch URL for a given query String
	 *
	 * @param queryParams
	 * @return BatchURL
	 */
	public String getBatchURL(String queryParams) {
		LOGGER.info("queryParams : " + queryParams);
		return refDataConfigUtil.getBatchDeployURL() + queryParams;
	}
	
	/**
	 * 
	 * The generic method for the exchange method. The method will exchange the
	 * request for list response.
	 * 
	 * @param T
	 * @param queryParams
	 * @param varArguments
	 * @return responseEntity
	 */
	@SuppressWarnings("rawtypes")
	public List exchangeForList(Class T, String queryParams, Object... varArguments) {
		HttpEntity<List<?>> entity = new HttpEntity<List<?>>(constructRequestHeader());
		ResponseEntity<List> result = null;

		try {
			result = restTemplate.exchange(getServiceURL(queryParams), HttpMethod.GET, entity, List.class,
					varArguments);
		} catch (Exception e) {
			LOGGER.error("Exception occurred in exchangeForList method " + e);
		}
		return result != null ? result.getBody() : null;
	}
}
