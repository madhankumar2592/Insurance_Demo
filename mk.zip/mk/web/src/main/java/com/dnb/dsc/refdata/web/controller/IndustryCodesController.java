/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.controller;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeDescription;
import com.dnb.dsc.refdata.core.entity.IndustryCodeMap;
import com.dnb.dsc.refdata.core.entity.IndustryCodeMapPK;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.interceptor.TransactionLogger;
import com.dnb.dsc.refdata.core.util.CommonUtil;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.IndusCodeBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.IndusCodeBulkUploadVO;
import com.dnb.dsc.refdata.core.vo.InduscodeMappingBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.IndustryCodesSearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.web.proxy.IndustryCodesWebServiceProxy;
import com.dnb.dsc.refdata.web.util.IndsExportToExcel;
import com.dnb.dsc.refdata.web.util.UserRoleMapper;

/**
 * The Controller class for Industry Codes Domain. The methods in the class will
 * be mapped as per the UI requests. The UI front controller will redirect to
 * the respective methods based on the request and the request parameters.
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Controller
@SessionAttributes("industryCode")
public class IndustryCodesController {

	@Autowired
	private HomeController homeController;

	@Autowired
	private IndustryCodesWebServiceProxy wsProxy;

	@Autowired
	private WorkQueueController workQueueController;

	@Autowired
	private SCoTSController scotsController;

	@Autowired
	private RefDataConfigUtil refdataConfig;

	@Autowired
	private UserRoleMapper roleMapper;

	@Autowired
	private TransactionLogger transactionLogger;

	private final String[] industrySearchColumns = { "industryCode",
			"industryCodeDescription", "languageCode", "industryCodeId",
			"languageDescription" };
	private final String[] industryCrosswalkSearchColumns = { "industryCode",
			"industryCodeDescription", "crosswalkIndustryCode",
			"crosswalkIndustryDescription", "preferredMapIndicator",
			"fromIndustryCodeId", "toIndustryCodeId" };

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(IndustryCodesController.class);

	/**
	 * Loads the Industry Codes search home page.
	 * <p>
	 * 
	 * Retrieves all industry codes information to be populated in the screen.
	 * <p>
	 * 
	 * @param model
	 * @param session
	 * @return indsCodesSearchHome, the ModelAndView object
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/indsCodeSearchHome.form", method = RequestMethod.GET)
	public ModelAndView getIndustryCodesSearchHome(HttpSession session) {
		LOGGER.info("entering IndustryCodesController | getIndustryCodesSearchHome");
		ModelAndView indsCodesSearchHome = new ModelAndView("indsCodeSearch");

		// Retrieving the Lists for Industry Codes
		Map<String, List<CodeValue>> tempCodeValueMap = wsProxy
				.retrieveIndustryCodeValues(Long
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE));

		List codeValues = tempCodeValueMap
				.get(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING);
		/*UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		boolean hasApproverRole = roleMapper.hasDomainApproverRoleForUser(
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
				userContextVO.getUserRoles());
		indsCodesSearchHome.addObject("UserRole", hasApproverRole);*/
		// sort the codeValues based on the Code Value Id
		Collections.sort(codeValues, new IndustryCodeValueIdComparable());

		LOGGER.info("IndustryCodesController | getIndustryCodesSearchHome | industryCodeTypes : "
				+ codeValues);
		session.setAttribute(
				RefDataUIConstants.INDUSTRY_CODES_SEARCH_INDUSTRY_CODE_TYPES_SESSION,
				codeValues);

		LOGGER.info("exiting IndustryCodesController | getIndustryCodesSearchHome");
		return indsCodesSearchHome;
	}

	/**
	 * 
	 * Retrieves the Industry Code search details.
	 * <p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param industryCodesSearchCriteria
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @param session
	 * @return indsCodeSearch, the ModelAndView
	 */
	@RequestMapping(value = "/indsCodeSearchAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getIndustryCodesSearchAjaxResults(
			HttpServletRequest request, HttpSession session) {
		LOGGER.info("entering IndustryCodesController | getIndustryCodesSearchAjaxResults");
		// audit variable - start time
		Date startTime = new Date();

		IndustryCodesSearchCriteriaVO industryCodesSearchCriteria = getIndustryCodesSearchCriteria(request);
		if (industryCodesSearchCriteria.getIndustryCodeTypeCode() == null
				|| (industryCodesSearchCriteria.getIndustryCodeTypeCode() != null && industryCodesSearchCriteria
						.getIndustryCodeTypeCode().trim().isEmpty())) {
			return homeController.getJsonMap(request, new ArrayList<Object>(),
					0L, industrySearchColumns);
		}

		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		Long countIndustryCodesResults = (Long) session
				.getAttribute("countIndustryCodesResults");
		if ((countIndustryCodesResults == null)
				|| (industryCodesSearchCriteria.getRowIndex() == 0)) {
			countIndustryCodesResults = wsProxy
					.countSearchIndustryCodes(industryCodesSearchCriteria);
			session.setAttribute("countIndustryCodesResults",
					countIndustryCodesResults);
		}

		Map<String, Object> map = homeController.getJsonMap(request,
				wsProxy.searchIndustryCodes(industryCodesSearchCriteria),
				countIndustryCodesResults, industrySearchColumns);

		LOGGER.info("IndustryCodesController | getIndustryCodesSearchAjaxResults | returned after searchIndustryCodes");
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		// transaction logging
		transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
						userContextVO.getUserRoles()),
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
				"searchIndustryCodes", 0L, industryCodesSearchCriteria, 0L);

		LOGGER.info("exiting IndustryCodesController | getIndustryCodesSearchAjaxResults");
		return map;
	}

	/**
	 * 
	 * Retrieves the Industry Code search details.
	 * <p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param industryCodesSearchCriteria
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @param session
	 * @return indsCodeSearch, the ModelAndView
	 */
	@RequestMapping(value = "/indsCodeCrosswalkSearchAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getIndustryCodesCrosswalkSearchAjaxResults(
			HttpServletRequest request, HttpSession session) {
		LOGGER.info("entering IndustryCodesController | getIndustryCodesCrosswalkSearchAjaxResults");
		// audit variables
		Date startTime = new Date();

		IndustryCodesSearchCriteriaVO industryCodesSearchCriteria = getIndustryCodesSearchCriteria(request);

		if (industryCodesSearchCriteria.getIndustryCodeTypeCode() == null
				|| (industryCodesSearchCriteria.getIndustryCodeTypeCode() != null && industryCodesSearchCriteria
						.getIndustryCodeTypeCode().trim().isEmpty())
				|| (industryCodesSearchCriteria.getIndustryCodeCrosswalk() == null)
				|| (industryCodesSearchCriteria.getIndustryCodeCrosswalk() != null && industryCodesSearchCriteria
						.getIndustryCodeCrosswalk().trim().isEmpty())) {
			return homeController.getJsonMap(request, new ArrayList<Object>(),
					0L, industryCrosswalkSearchColumns);
		}

		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		Long countIndustryCodesCrosswalkResults = (Long) session
				.getAttribute("countIndustryCodesCrosswalkResults");
		if ((countIndustryCodesCrosswalkResults == null)
				|| (industryCodesSearchCriteria.getRowIndex() == 0)) {
			countIndustryCodesCrosswalkResults = wsProxy
					.countSearchIndustryCodes(industryCodesSearchCriteria);
			session.setAttribute("countIndustryCodesCrosswalkResults",
					countIndustryCodesCrosswalkResults);
		}

		Map<String, Object> map = homeController.getJsonMap(request,
				wsProxy.searchIndustryCodes(industryCodesSearchCriteria),
				countIndustryCodesCrosswalkResults,
				industryCrosswalkSearchColumns);

		LOGGER.info("IndustryCodesController | getIndustryCodesCrosswalkSearchAjaxResults"
				+ " | returned after searchIndustryCodes");
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		// transaction logging
		transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
						userContextVO.getUserRoles()),
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
				"searchIndustryCodesCrossWalk", 0L,
				industryCodesSearchCriteria, 0L);
		LOGGER.info("exiting IndustryCodesController | getIndustryCodesCrosswalkSearchAjaxResults");
		return map;
	}

	/**
	 * 
	 * The method to populate the IndustryCodesSearchCriteriaVO
	 * 
	 * @param request
	 * @return IndustryCodesSearchCriteriaVO
	 */
	private IndustryCodesSearchCriteriaVO getIndustryCodesSearchCriteria(
			HttpServletRequest request) {
		LOGGER.info("entering IndustryCodesController | getIndustryCodesSearchCriteria");

		IndustryCodesSearchCriteriaVO industryCodesSearchCriteria = new IndustryCodesSearchCriteriaVO();
		industryCodesSearchCriteria.setSortOrder(homeController
				.getSortOrder(request));
		industryCodesSearchCriteria.setMaxResults(homeController
				.getMaxResults(request));
		industryCodesSearchCriteria.setRowIndex(homeController
				.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);
		// Search string will be in the format
		// code#~text#~desc#~code#~text
		String searchCriteriaDelimiter = "~";
		if (compositeSearchString != null) {
			String[] splitCriteria = compositeSearchString
					.split(searchCriteriaDelimiter);
			if (splitCriteria.length > 0) {
				if (!(splitCriteria[0].replace("#", "").trim().isEmpty())) {
					industryCodesSearchCriteria
							.setIndustryCodeTypeCode(splitCriteria[0].replace(
									"#", "").trim());
				}
			}
			if (splitCriteria.length > 1) {
				if (!(splitCriteria[1].replace("#", "").trim().isEmpty())) {
					industryCodesSearchCriteria
							.setIndustryCodeTypeCodeLiteralDescription(splitCriteria[1]
									.replace("#", "").trim());
				}
			}
			if (splitCriteria.length > 2) {
				if (!(splitCriteria[2].replace("#", "").trim().isEmpty())) {
					String description = splitCriteria[2].replace("#", "")
							.trim();
					industryCodesSearchCriteria.setIndustryCode(description);
					industryCodesSearchCriteria
							.setIndustryCodeDescription(description);
				}
			}
			if (splitCriteria.length > 3) {
				if (!(splitCriteria[3].replace("#", "").trim().isEmpty())) {
					if (splitCriteria[3].replace("#", "").trim()
							.equals("undefined")) {
						industryCodesSearchCriteria
								.setIndustryCodeCrosswalk("");
					} else {
						industryCodesSearchCriteria
								.setIndustryCodeCrosswalk(splitCriteria[3]
										.replace("#", "").trim());
					}

				}
			}
			if (splitCriteria.length > 4) {
				if (!(splitCriteria[4].replace("#", "").trim().isEmpty())) {
					industryCodesSearchCriteria
							.setIndustryCodeCrosswalkLiteralDescription(splitCriteria[4]
									.replace("#", "").trim());
				}
			}
			if (splitCriteria.length > 5) {
				if (!(splitCriteria[5].replace("#", "").trim().isEmpty())) {
					industryCodesSearchCriteria
							.setIndustryGroupLevelCodes(getIndustryGroupLevelSearchCodes(splitCriteria[5]
									.replace("#", "").trim()));
				}
			}
			if (splitCriteria.length > 6) {
				if (!(splitCriteria[6].replace("#", "").trim().isEmpty())
						&& !"null".equals(splitCriteria[6].replace("#", ""))) {
					industryCodesSearchCriteria
							.setIndustryCodeLanguageCode(Long
									.valueOf(splitCriteria[6].replace("#", "")
											.trim()));
				}
			}
			if (splitCriteria.length > 7) {

				if (!splitCriteria[7].replace("#", "").trim().isEmpty()
						&& !(splitCriteria[7].replace("#", "").trim()
								.equals("undefined"))
						&& !"null".equals(splitCriteria[7].replace("#", ""))) {
					industryCodesSearchCriteria
							.setIndustryCrossWalkLanguageCode(Long
									.valueOf(splitCriteria[7].replace("#", "")
											.trim()));
				}
			}
		}
		// Issue fix QC defect #56
		if (industryCodesSearchCriteria.getIndustryCodeCrosswalk() != null) {
			industryCodesSearchCriteria.setSortBy(homeController.getSortBy(
					request, industryCrosswalkSearchColumns));
		} else {
			industryCodesSearchCriteria.setSortBy(homeController.getSortBy(
					request, industrySearchColumns));
		}

		LOGGER.info("IndustryCodesController | getIndustryCodesSearchCriteria | industryCodesSearchCriteria : "
				+ industryCodesSearchCriteria);
		LOGGER.info("exiting IndustryCodesController | getIndustryCodesSearchCriteria");
		return industryCodesSearchCriteria;
	}

	/**
	 * The method will retrieve Industry code CrossWalks for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 * 
	 * @param industryCodeTypeCode
	 * @param session
	 * @return list of codeValueVO
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "retrieveCrossWalksForIndsCodeType.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveCrossWalksForIndsCodeType(
			@RequestParam(value = "industryCodeType", required = true) Long industryCodeTypeCode,
			HttpSession session) {
		LOGGER.info("entering IndustryCodesController | retrieveCrossWalksForIndsCodeType");
		// audit variables
		Date startTime = new Date();

		List codeValueVOs = this.wsProxy
				.retrieveCrossWalksForIndsCodeType(industryCodeTypeCode);
		// sort the list of codeValueVOs based on the description
		if (codeValueVOs != null) {
			Collections.sort(codeValueVOs,
					new IndustryCodeTypeLiteralComparable());
			LOGGER.info("IndustryCodesController | retrieveCrossWalksForIndsCodeType | "
					+ "sorted crossWalks for inds code type : " + codeValueVOs);
		}

		// transaction logging
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
						userContextVO.getUserRoles()),
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
				"retrieveCrossWalksForIndsCodeType", 0L, codeValueVOs, 0L,
				industryCodeTypeCode);

		LOGGER.info("exiting IndustryCodesController | retrieveCrossWalksForIndsCodeType");
		return codeValueVOs;
	}

	/**
	 * The method will retrieve Industry code Group Levels for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 * 
	 * @param industryCodeTypeCode
	 * @param session
	 * @return list of codeValueVO
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "retrieveGroupLevelCodes.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveGroupLevelCodes(
			@RequestParam(value = "industryCodeType", required = true) Long industryCodeTypeCode,
			@RequestParam(value = "languageCode", required = true) Long languageCode,
			HttpSession session) {
		LOGGER.info("entering IndustryCodesController | retrieveGroupLevelCodes");
		// audit variables
		Date startTime = new Date();

		List codeValueVOs = this.wsProxy.retrieveGroupLevelCodes(
				industryCodeTypeCode, languageCode);
		// sort the list of codeValueVOs based on the description
		if (codeValueVOs != null) {
			Collections.sort(codeValueVOs,
					new IndustryCodeTypeLiteralComparable());
			LOGGER.info("IndustryCodesController | retrieveGroupLevelCodes | sorted group level codes : "
					+ codeValueVOs);
		}

		// transaction logging
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
						userContextVO.getUserRoles()),
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
				"retrieveGroupLevelCodes", 0L, codeValueVOs, 0L,
				industryCodeTypeCode, languageCode);

		LOGGER.info("exiting IndustryCodesController | retrieveGroupLevelCodes");
		return codeValueVOs;
	}

	/**
	 * 
	 * The method will fetch the language codes available for the selected
	 * Industry Code Type. The method will be invoked when the user selects the
	 * Industry Code type value.
	 * 
	 * @param industryCodeTypeCode
	 * @param groupLevelCode
	 * @param session
	 * @return list of codeValueVO
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "retrieveLanguageForIndsCodeType.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveLanguageForIndsCodeType(
			@RequestParam(value = "industryCodeType", required = true) Long industryCodeTypeCode,
			@RequestParam(value = "groupLevelCode", required = true) String groupLevelCode,
			HttpSession session) {
		LOGGER.info("entering IndustryCodesController | retrieveLanguageForIndsCodeType");
		LOGGER.info("IndustryCodesController | retrieveLanguageForIndsCodeType | "
				+ "industryCodeTypeCode : "
				+ industryCodeTypeCode
				+ " | groupLevelCode : " + groupLevelCode);
		// audit variables
		Date startTime = new Date();

		List codeValueVOs = this.wsProxy.retrieveIndustryCodeLanguages(
				industryCodeTypeCode,
				getIndustryGroupLevelSearchCodes(groupLevelCode));
		// sort the list of codeValueVOs based on the description
		if (codeValueVOs != null) {
			Collections.sort(codeValueVOs, new IndustryCodeComparable());
			LOGGER.info("IndustryCodesController | retrieveLanguageForIndsCodeType | sorted language codes : "
					+ codeValueVOs);
		}

		LOGGER.info("exiting IndustryCodesController | retrieveLanguageForIndsCodeType");
		// transaction logging
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
						userContextVO.getUserRoles()),
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
				"retrieveLanguageForIndsCodeType", 0L, codeValueVOs, 0L,
				industryCodeTypeCode, groupLevelCode);

		return codeValueVOs;
	}

	/**
	 * 
	 * The method to toggle the Industry Code Table drop down values
	 * 
	 * @param toggleIndicator
	 * @param session
	 * @return model
	 * @return codeValues
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "toggleIndsCodeTable.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> toggleIndsCodeTable(
			@RequestParam(value = "toggleIndicator", required = true) String toggleIndicator,
			HttpSession session, Model model) {
		LOGGER.info("entering IndustryCodesController | toggleIndsCodeTable | toggleIndicator : "
				+ toggleIndicator);

		List codeValues = (List) session
				.getAttribute(RefDataUIConstants.INDUSTRY_CODES_SEARCH_INDUSTRY_CODE_TYPES_SESSION);

		if (codeValues != null) {
			if (RefDataUIConstants.TOGGLE_INDICATOR_CODE
					.equals(toggleIndicator)) {
				Collections.sort(codeValues,
						new IndustryCodeValueIdComparable());
				model.addAttribute("toggleIndicator",
						RefDataUIConstants.TOGGLE_INDICATOR_VALUE);

			} else if (RefDataUIConstants.TOGGLE_INDICATOR_VALUE
					.equals(toggleIndicator)) {
				Collections.sort(codeValues,
						new IndustryCodeLiteralComparable());
				model.addAttribute("toggleIndicator",
						RefDataUIConstants.TOGGLE_INDICATOR_CODE);
			}
		}
		LOGGER.info("exiting IndustryCodesController | toggleIndsCodeTable | returned : "
				+ codeValues);
		return codeValues;
	}
	
	/**
	 * 
	 * The method to toggle the Language Code Table drop down values
	 * 
	 * @param toggleIndicator
	 * @param session
	 * @return model
	 * @return codeValues
	 */	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "toggleLanguageCode.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> toggleLanguageCode(
			@RequestParam(value = "toggleIndicator", required = true) String toggleIndicator,
			HttpSession session,Model model) {
		LOGGER.info("toggleIndicator : " + toggleIndicator);

		List codeValueList = (List) session
				.getAttribute(RefDataUIConstants.SCOTS_LIST_CODE_LANGUAGE_SESSION);
		LOGGER.info("language list before toggle: " + codeValueList);
		
		if (codeValueList != null) {
			if (RefDataUIConstants.TOGGLE_INDICATOR_CODE.equals(toggleIndicator)) {
				Collections.sort(codeValueList,
						new IndustryCodeValueIdComparable());
				model.addAttribute("toggleIndicator",
						RefDataUIConstants.TOGGLE_INDICATOR_VALUE);

			} else if (RefDataUIConstants.TOGGLE_INDICATOR_VALUE
					.equals(toggleIndicator)) {
				Collections.sort(codeValueList,
						new IndustryCodeLiteralComparable());
				model.addAttribute("toggleIndicator",
						RefDataUIConstants.TOGGLE_INDICATOR_CODE);
			}
		}

		LOGGER.info("language list after toggle: " + codeValueList);
		return codeValueList;
	}
	
	/**
	 * 
	 * The method to toggle the Description Length Code Table drop down values
	 * 
	 * @param toggleIndicator
	 * @param session
	 * @return model
	 * @return codeValues
	 */	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "toggleLengthCode.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> toggleLengthCode(
			@RequestParam(value = "toggleIndicator", required = true) String toggleIndicator,
			HttpSession session,Model model) {
		LOGGER.info("toggleIndicator : " + toggleIndicator);

		List codeValueList = (List) session
				.getAttribute(RefDataUIConstants.INDUSTRY_CODES_DESC_LENGTH_CODE_SESSION);
		LOGGER.info("LengthCode before toggle: " + codeValueList);
		
		if (codeValueList != null) {
			if (RefDataUIConstants.TOGGLE_INDICATOR_CODE.equals(toggleIndicator)) {
				Collections.sort(codeValueList,
						new IndustryCodeValueIdComparable());
				model.addAttribute("toggleIndicator",
						RefDataUIConstants.TOGGLE_INDICATOR_VALUE);

			} else if (RefDataUIConstants.TOGGLE_INDICATOR_VALUE
					.equals(toggleIndicator)) {
				Collections.sort(codeValueList,
						new IndustryCodeLiteralComparable());
				model.addAttribute("toggleIndicator",
						RefDataUIConstants.TOGGLE_INDICATOR_CODE);
			}
		}

		LOGGER.info("language list after toggle: " + codeValueList);
		return codeValueList;
	}
	
	

	/**
	 * 
	 * The Comparator class will sort the CodeValue based on the codeValueId
	 * 
	 * @author Cognizant
	 * @version last updated : Mar 12, 2012
	 * @see
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public class IndustryCodeValueIdComparable implements
			Comparator<LinkedHashMap> {

		@Override
		public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
			return ((Integer) codeValue1.get("codeValueId"))
					.compareTo((Integer) codeValue2.get("codeValueId"));
		}
	}

	/**
	 * 
	 * The Comparator class will sort the CodeValue based on the code
	 * 
	 * @author Cognizant
	 * @version last updated : Mar 12, 2012
	 * @see
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public class IndustryCodeComparable implements Comparator<LinkedHashMap> {

		@Override
		public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
			return ((Integer) codeValue1.get("code"))
					.compareTo((Integer) codeValue2.get("code"));
		}
	}

	/**
	 * 
	 * The Comparator class will sort the CodeValue based on the
	 * codeValueDescription
	 * 
	 * @author Cognizant
	 * @version last updated : Mar 12, 2012
	 * @see
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public class IndustryCodeLiteralComparable implements
			Comparator<LinkedHashMap> {

		@Override
		public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
			return ((String) codeValue1.get("codeValueDescription"))
					.compareTo((String) codeValue2.get("codeValueDescription"));
		}
	}

	/**
	 * 
	 * The Comparator class will sort the CodeValueVO based on the description
	 * 
	 * @author Cognizant
	 * @version last updated : Mar 12, 2012
	 * @see
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public class IndustryCodeTypeLiteralComparable implements
			Comparator<LinkedHashMap> {

		@Override
		public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
			return ((String) codeValue1.get("description"))
					.compareTo((String) codeValue2.get("description"));
		}
	}

	/**
	 * Loads the Industry Codes detail page.
	 * <p>
	 * 
	 * @return indsCodesDetail, the ModelAndView object
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/indsCodeDetail.form", method = RequestMethod.GET)
	public ModelAndView getIndustryCodesDetail(
			@RequestParam(value = "industryCodeId", required = true) Long industryCodeId,
			@RequestParam("taskId") final String taskId, Model model,
			HttpSession session) {
		LOGGER.info("entering IndustryCodesController | getIndustryCodesDetail");
		ModelAndView indsCodesDetail = new ModelAndView("indsCodesDetail");
		session.setAttribute("taskId", taskId);

		Map<String, List<CodeValue>> tempCodeValueMap = setSessionValuesForCodeValues(session);

		List industryCodeTypeCodeValues = tempCodeValueMap
				.get(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING);
		Collections.sort(industryCodeTypeCodeValues,
				new MsaCodeValueIdComparable());
		indsCodesDetail.addObject("industryCodeTypeCodeValues",
				industryCodeTypeCodeValues);

		indsCodesDetail
				.addObject(
						"industryCodeGroupLevelValues",
						tempCodeValueMap.get(String
								.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_GROUP_LEVEL)));

		List industryCodeLanguageValues = tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE));
		Collections.sort(industryCodeLanguageValues,
				new MsaCodeValueIdComparable());
		indsCodesDetail.addObject("industryCodeLanguageValues",
				industryCodeLanguageValues);
		indsCodesDetail
				.addObject(
						"industryCodeDescLengthValues",
						tempCodeValueMap.get(String
								.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE)));

		LOGGER.info("IndustryCodesController | getIndustryCodesDetail | after initializing the view page");
		IndustryCode industryCodeById = null;
		String userMode = (String) session.getAttribute("userMode");

		LOGGER.info("IndustryCodesController | getIndustryCodesDetail | userMode : "
				+ userMode);
		LOGGER.info("IndustryCodesController | getIndustryCodesDetail | taskId : "
				+ taskId);
		if (userMode == null) {
			if ((taskId != null) && !taskId.trim().isEmpty()) {
				industryCodeById = wsProxy
						.reviewIndustryCodeChanges(industryCodeId);
			} else {
				industryCodeById = wsProxy
						.retrieveIndustryCodeByIndustryCodeId(Long
								.valueOf(industryCodeId));
			}
			if (isEmptyDescriptionList(industryCodeById)) {
				indsCodesDetail.addObject("emptyDescriptionList", "yes");
			}
			if (isEmptyMappingList(industryCodeById)) {
				indsCodesDetail.addObject("emptyMappingList", "yes");
			}
			populateMapToIndustryCode(industryCodeById);
			session.setAttribute("industryCodeInDB",
					getIndustryCodeInDB(industryCodeById));
			model.addAttribute("industryCode",
					populateEmptyDescriptionMappingRows(industryCodeById));
		} else {
			industryCodeById = (IndustryCode) session
					.getAttribute("industryCode");
			if (isEmptyDescriptionList(industryCodeById)) {
				indsCodesDetail.addObject("emptyDescriptionList", "yes");
			}
			if (isEmptyMappingList(industryCodeById)) {
				indsCodesDetail.addObject("emptyMappingList", "yes");
			}
		}

		LOGGER.info("IndustryCodesController | getIndustryCodesDetail | returned : "
				+ indsCodesDetail);
		LOGGER.info("exiting IndustryCodesController | getIndustryCodesDetail");
		return indsCodesDetail;
	}

	/**
	 * 
	 * The method to populate the industry code mapping
	 * 
	 * @param industryCodeById
	 */
	private void populateMapToIndustryCode(IndustryCode industryCodeById) {
		LOGGER.info("entering IndustryCodesController | populateMapToIndustryCode | industryCodeById : "
				+ industryCodeById);
		if (industryCodeById.getIndustryCodeMaps() != null) {
			for (IndustryCodeMap currMap : industryCodeById
					.getIndustryCodeMaps()) {
				currMap.setToIndustryCode(wsProxy
						.retrieveIndustryCodeByIndustryCodeId(currMap
								.getIndustryCodeMapPK().getToIndustryCodeId()));
				if ((currMap.getToIndustryCode() != null)
						&& (currMap.getToIndustryCode()
								.getIndustryCodeDescriptions() != null)) {
					for (IndustryCodeDescription currIndustryCodeDescription : currMap
							.getToIndustryCode().getIndustryCodeDescriptions()) {
						if (currIndustryCodeDescription.getLanguageCode() != null
								&& currIndustryCodeDescription
										.getLanguageCode().longValue() == RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH
										.longValue()) {
							currMap.getToIndustryCode()
									.setIndustryCodeDescription(
											currIndustryCodeDescription
													.getIndustryDescription());
						}
					}
				}
			}
		}
		LOGGER.info("exiting IndustryCodesController | populateMapToIndustryCode | returned : "
				+ industryCodeById);
	}

	/**
	 * The method will persist the existing IndustryCode data in the Transaction
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param IndustryCode
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/indsCodeUpdate.form", method = RequestMethod.POST)
	public ModelAndView indsCodeUpdate(
			@ModelAttribute("industryCode") IndustryCode industryCode,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session) throws ParseException {
		LOGGER.info("entering IndustryCodesController | indsCodeUpdate");

		// audit variables
		Date startTime = new Date();

		IndustryCode industryCodeInDB = (IndustryCode) session
				.getAttribute("industryCodeInDB");
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		IndustryCode industryCodeForUpdate = removeEmptyList(industryCode,
				industryCodeInDB, userContextVO.getUserIdentifier());
		String userModeErrorMessage = isIndustryCodesInvalid(industryCode);

		LOGGER.info("IndustryCodesController | indsCodeUpdate | userModeErrorMessage : "
				+ userModeErrorMessage);
		if (userModeErrorMessage != null
				&& !userModeErrorMessage.trim().isEmpty()) {
			session.setAttribute("userMode", "edit");
			session.setAttribute("userModeErrorMessage", userModeErrorMessage);
			return getIndustryCodesDetail(industryCode.getIndustryCodeId(),
					null, model, session);
		} else {
			session.removeAttribute("userMode");
			session.removeAttribute("userModeErrorMessage");
		}

		session.removeAttribute("industryCodeInDB");
		session.removeAttribute("tempCodeValueMap");

		LOGGER.info("IndustryCodesController | indsCodeUpdate | industryCodeForUpdate : "
				+ industryCodeForUpdate);
		Long workflowTrackingId = wsProxy
				.updateIndustryCode(industryCodeForUpdate);

		// Invoke the WorkFlow service to create the workFlow task for the
		// update operation. This will be invoked as a web service call.
		String taskId = (String) session.getAttribute("taskId");
		LOGGER.info("IndustryCodesController | indsCodeUpdate | updated industryCodeId : "
				+ workflowTrackingId);
		LOGGER.info("IndustryCodesController | indsCodeUpdate | taskId : "
				+ taskId);
		if ((taskId != null) && !taskId.trim().isEmpty()) {
			// Invoke the WorkFlow service to create the workFlow task for the
			// update operation. This will be invoked as a web service call.
			homeController
					.reSubmitTaskRequest(
							userContextVO,
							taskId,
							RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
							RefDataPropertiesConstants.INDUSTRY_CODE_SUBMITTER_GROUP_ID);
		} else {
			homeController
					.createReferenceData(
							String.valueOf(industryCode.getIndustryCodeId()),
							RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
							Long.valueOf(RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_INDUSTRY_CODE),
							userContextVO.getUserIdentifier(),
							"Industry Code Id: "
									+ workflowTrackingId,
							RefDataPropertiesConstants.INDUSTRY_CODE_APPROVER_GROUP_ID,
							RefDataPropertiesConstants.INDUSTRY_CODE_SUBMITTER_GROUP_ID);
		}
		sessionStatus.setComplete();

		// transaction logging
		transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
						userContextVO.getUserRoles()),
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
				"indsCodeUpdate", 0L, workflowTrackingId, 0L,
				industryCodeForUpdate);

		LOGGER.info("exiting IndustryCodesController | indsCodeUpdate");
		return workQueueController.getSubmitterWorkQueueHome(
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE, session);
	}

	/**
	 * 
	 * TODO
	 * 
	 * @param industryCode
	 * @return
	 */
	private String isIndustryCodesInvalid(IndustryCode industryCode) {
		LOGGER.info("entering IndustryCodesController | isIndustryCodesInvalid | industryCode : "
				+ industryCode);
		Long industryCodeId = null;

		for (IndustryCodeMap currMap : industryCode.getIndustryCodeMaps()) {
			if (currMap.getToIndustryCode().getIndustryCode() != null) {
				industryCodeId = getToIndustryCodeId(currMap
						.getToIndustryCode().getIndustryCodeTypeCode(), currMap
						.getToIndustryCode().getIndustryCode());
				if (industryCodeId.longValue() == 0L) {
					LOGGER.info("IndustryCodesController | isIndustryCodesInvalid  : true");
					return "Industry code type "
							+ currMap.getToIndustryCode()
									.getIndustryCodeTypeCode()
							+ " does not have industry code "
							+ currMap.getToIndustryCode().getIndustryCode();
				} else {
					LOGGER.info("IndustryCodesController | isIndustryCodesInvalid  : false");
					IndustryCodeMapPK industryCodeMapPK = currMap
							.getIndustryCodeMapPK() != null ? currMap
							.getIndustryCodeMapPK() : new IndustryCodeMapPK();
					industryCodeMapPK.setToIndustryCodeId(industryCodeId);
					currMap.setIndustryCodeMapPK(industryCodeMapPK);
					currMap.getToIndustryCode().setIndustryCodeId(
							industryCodeId);
				}
			}
		}
		return null;
	}

	/**
	 * 
	 * The method to remove the empty list from the IndustryCode entity
	 * 
	 * @param industryCode
	 * @param industryCodeInDB
	 * @param fUserIdentifier
	 * @return industryCode
	 */
	private IndustryCode removeEmptyList(IndustryCode industryCode,
			IndustryCode industryCodeInDB, String fUserIdentifier) {
		LOGGER.info("entering IndustryCodesController | removeEmptyList");

		String userIdentifier = CommonUtil.truncate(fUserIdentifier,
				RefDataPropertiesConstants.USER_EMAIL_ADDRESS_MAX_LENGTH);
		industryCode.setModifiedDate(new Date());
		industryCode.setModifiedUser(userIdentifier);

		if (industryCode.getIndustryCodeDescriptions() != null) {
			Long descriptionIndex = 0L;
			List<IndustryCodeDescription> newDescriptionList = new ArrayList<IndustryCodeDescription>();
			for (IndustryCodeDescription industryCodeDescription : industryCode
					.getIndustryCodeDescriptions()) {
				if (industryCodeDescription.getIndustryCodeDescriptionId() == null
						|| industryCodeDescription
								.getIndustryCodeDescriptionId() < 0) {
					industryCodeDescription
							.setIndustryCodeDescriptionId(descriptionIndex--);
					industryCodeDescription.setIndustryCodeId(industryCode
							.getIndustryCodeId());
					industryCodeDescription
							.setWritingScriptCode(RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
					industryCodeDescription.setCreatedDate(new Date());
					industryCodeDescription.setCreatedUser(userIdentifier);
					industryCodeDescription.setModifiedDate(new Date());
					industryCodeDescription.setModifiedUser(userIdentifier);
					newDescriptionList.add(industryCodeDescription);
				} else if (containsDescriptionChange(industryCodeDescription,
						industryCodeInDB)) {
					industryCodeDescription.setModifiedDate(new Date());
					industryCodeDescription.setModifiedUser(userIdentifier);
					newDescriptionList.add(industryCodeDescription);
				}
			}
			industryCode.setIndustryCodeDescriptions(newDescriptionList);
		}

		if (industryCode.getIndustryCodeMaps() != null
				&& industryCode.getIndustryCodeMaps().size() == 1) {
			IndustryCodeMap currIndustryMap = industryCode
					.getIndustryCodeMaps().get(0);
			if (currIndustryMap.getToIndustryCode() == null
					|| currIndustryMap.getToIndustryCode()
							.getIndustryCodeTypeCode() == null) {
				industryCode.getIndustryCodeMaps().remove(0);
			}
		}

		if (industryCode.getIndustryCodeMaps() != null
				&& industryCode.getIndustryCodeMaps().size() > 0) {
			List<IndustryCodeMap> newMapList = new ArrayList<IndustryCodeMap>();

			for (IndustryCodeMap industryCodeMap : industryCode
					.getIndustryCodeMaps()) {
				if ((industryCodeMap.getIndustryCodeMapPK() == null
						|| industryCodeMap.getIndustryCodeMapPK()
								.getFromIndustryCodeId() == null || industryCodeMap
						.getIndustryCodeMapPK().getToIndustryCodeId() == null)
						|| (industryCodeMap.getIndustryCodeMapPK() != null && industryCodeMap
								.getIndustryCodeMapPK().getToIndustryCodeId() > 0)) {
					IndustryCodeMapPK industryCodeMapPK = industryCodeMap
							.getIndustryCodeMapPK() != null ? industryCodeMap
							.getIndustryCodeMapPK() : new IndustryCodeMapPK();
					industryCodeMapPK.setFromIndustryCodeId(industryCode
							.getIndustryCodeId());
					if ((industryCodeMap.getToIndustryCode() != null)
							&& (industryCodeMap.getToIndustryCode()
									.getIndustryCode() != null && industryCodeMap
									.getToIndustryCode()
									.getIndustryCodeTypeCode() != null)) {
						industryCodeMapPK.setToIndustryCodeId(wsProxy
								.retrieveIndustryCodeIdByCodeTypeCode(
										industryCodeMap.getToIndustryCode()
												.getIndustryCodeTypeCode(),
										industryCodeMap.getToIndustryCode()
												.getIndustryCode()));
						industryCodeMap.setIndustryCodeMapPK(industryCodeMapPK);
						industryCodeMap.setCreatedDate(new Date());
						industryCodeMap.setCreatedUser(userIdentifier);
						industryCodeMap.setModifiedDate(new Date());
						industryCodeMap.setModifiedUser(userIdentifier);
						newMapList.add(industryCodeMap);
					}
				} else if (containsMapChange(industryCodeMap, industryCodeInDB)) {
					industryCodeMap.setModifiedDate(new Date());
					industryCodeMap.setModifiedUser(userIdentifier);
					newMapList.add(industryCodeMap);
				}
			}
			industryCode.setIndustryCodeMaps(newMapList);
		}

		LOGGER.info("exiting IndustryCodesController | removeEmptyList | returned : "
				+ industryCode);
		return industryCode;
	}

	/**
	 * 
	 * TODO
	 * 
	 * @param industryCodeMap
	 * @param industryCodeInDB
	 * @return boolean
	 */
	private boolean containsMapChange(IndustryCodeMap industryCodeMap,
			IndustryCode industryCodeInDB) {
		LOGGER.info("entering IndustryCodesController | containsMapChange");
		if (industryCodeInDB == null || industryCodeMap == null) {
			LOGGER.info("IndustryCodesController | containsMapChange | "
					+ "industryCodeInDB == null || industryCodeMap == null");
			return false;
		}
		if (industryCodeInDB.getIndustryCodeMaps() == null) {
			LOGGER.info("IndustryCodesController | containsMapChange | industryCodeInDB.getIndustryCodeMaps() == null");
			return false;
		}
		if (RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED
				.equals(industryCodeMap.getChangeIndicator())) {
			LOGGER.info("IndustryCodesController | containsMapChange | industryCodeMap.getChangeIndicator() == DELETED");
			return true;
		}
		for (IndustryCodeMap currIndustryCodeMap : industryCodeInDB
				.getIndustryCodeMaps()) {

			if (industryCodeMap.getChangeIndicator() == null
					|| industryCodeMap.getChangeIndicator().equals("DELETED")) {
				industryCodeMap.setChangeIndicator("DELETED");
			}

			if ((industryCodeMap.getIndustryCodeMapPK().getFromIndustryCodeId()
					.equals(currIndustryCodeMap.getIndustryCodeMapPK()
							.getFromIndustryCodeId()))
					&& (industryCodeMap.getIndustryCodeMapPK()
							.getToIndustryCodeId().equals(currIndustryCodeMap
							.getIndustryCodeMapPK().getToIndustryCodeId()))
					&& (industryCodeMap.getChangeIndicator().equals("NOCHANGE"))) {
				if (industryCodeMap.getPreferredMapIndicator().equals(
						currIndustryCodeMap.getPreferredMapIndicator())) {
					return false;
				}
				return true;
			}
		}
		LOGGER.info("exiting IndustryCodesController | containsMapChange");
		return true;
	}

	/**
	 * 
	 * TODO
	 * 
	 * @param industryCodeTypeCode
	 * @param industryCode
	 * @return industryCodeId
	 */
	private Long getToIndustryCodeId(Long industryCodeTypeCode,
			String industryCode) {
		LOGGER.info("entering IndustryCodesController | getToIndustryCodeId");
		// returns 0 if there is no industryCodeId
		return wsProxy.retrieveIndustryCodeIdByCodeTypeCode(
				industryCodeTypeCode, industryCode);
	}

	/**
	 * 
	 * TODO
	 * 
	 * @param industryCodeDescription
	 * @param industryCodeInDB
	 * @return boolean
	 */
	private boolean containsDescriptionChange(
			IndustryCodeDescription industryCodeDescription,
			IndustryCode industryCodeInDB) {
		LOGGER.info("entering IndustryCodesController | containsDescriptionChange");
		if (industryCodeInDB == null || industryCodeDescription == null) {
			return false;
		}
		if (industryCodeInDB.getIndustryCodeDescriptions() == null) {
			return false;
		}
		if (RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED
				.equals(industryCodeDescription.getChangeIndicator())) {
			return true;
		}
		for (IndustryCodeDescription currIndustryCodeDescription : industryCodeInDB
				.getIndustryCodeDescriptions()) {
			if (industryCodeDescription.getIndustryCodeDescriptionId()
					.longValue() == currIndustryCodeDescription
					.getIndustryCodeDescriptionId().longValue()) {
				if (industryCodeDescription.getLanguageCode().longValue() != currIndustryCodeDescription
						.getLanguageCode().longValue()) {
					return true;
				}
				if (industryCodeDescription.getDescriptionLengthCode()
						.longValue() != currIndustryCodeDescription
						.getDescriptionLengthCode().longValue()) {
					return true;
				}
				if (!industryCodeDescription.getIndustryDescription()
						.equalsIgnoreCase(
								currIndustryCodeDescription
										.getIndustryDescription())) {
					return true;
				}
				return false;
			}
		}
		LOGGER.info("exiting IndustryCodesController | containsDescriptionChange");
		return false;
	}

	/**
	 * 
	 * TODO
	 * 
	 * @param industryCodeById
	 * @return descriptionListInDB
	 */
	private List<IndustryCodeDescription> getDescriptionListInDB(
			IndustryCode industryCodeById) {
		List<IndustryCodeDescription> descriptionListInDB = new ArrayList<IndustryCodeDescription>();
		if (industryCodeById.getIndustryCodeDescriptions() != null) {
			for (IndustryCodeDescription currIndustryCodeDescription : industryCodeById
					.getIndustryCodeDescriptions()) {
				IndustryCodeDescription newIndustryCodeDescription = new IndustryCodeDescription();
				newIndustryCodeDescription
						.setIndustryCodeDescriptionId(currIndustryCodeDescription
								.getIndustryCodeDescriptionId());
				newIndustryCodeDescription
						.setLanguageCode(currIndustryCodeDescription
								.getLanguageCode());
				newIndustryCodeDescription
						.setDescriptionLengthCode(currIndustryCodeDescription
								.getDescriptionLengthCode());
				newIndustryCodeDescription
						.setIndustryDescription(currIndustryCodeDescription
								.getIndustryDescription());
				descriptionListInDB.add(newIndustryCodeDescription);
			}
		}
		return descriptionListInDB;
	}

	/**
	 * 
	 * TODO
	 * 
	 * @param industryCodeById
	 * @return mapListInDB
	 */
	private List<IndustryCodeMap> getMapListInDB(IndustryCode industryCodeById) {
		List<IndustryCodeMap> mapListInDB = new ArrayList<IndustryCodeMap>();
		if (industryCodeById.getIndustryCodeMaps() != null) {
			for (IndustryCodeMap currIndustryCodeMap : industryCodeById
					.getIndustryCodeMaps()) {
				IndustryCodeMap newIndustryCodeMap = new IndustryCodeMap();
				IndustryCodeMapPK industryCodeMapPK = new IndustryCodeMapPK();
				industryCodeMapPK.setFromIndustryCodeId(currIndustryCodeMap
						.getIndustryCodeMapPK().getFromIndustryCodeId());
				industryCodeMapPK.setToIndustryCodeId(currIndustryCodeMap
						.getIndustryCodeMapPK().getToIndustryCodeId());
				newIndustryCodeMap.setIndustryCodeMapPK(industryCodeMapPK);
				newIndustryCodeMap.setPreferredMapIndicator(currIndustryCodeMap
						.getPreferredMapIndicator());
				mapListInDB.add(newIndustryCodeMap);
			}
		}
		return mapListInDB;
	}

	/**
	 * 
	 * TODO
	 * 
	 * @param industryCodeById
	 * @return industryCodeInDB
	 */
	private IndustryCode getIndustryCodeInDB(IndustryCode industryCodeById) {
		IndustryCode industryCodeInDB = new IndustryCode();
		industryCodeInDB
				.setIndustryCodeDescriptions(getDescriptionListInDB(industryCodeById));
		industryCodeInDB.setIndustryCodeMaps(getMapListInDB(industryCodeById));
		return industryCodeInDB;
	}

	/**
	 * 
	 * The method to populate empty descriptions for the Industry code mapping
	 * section in the UI.
	 * 
	 * @param industryCode
	 * @return industryCode
	 */
	public IndustryCode populateEmptyDescriptionMappingRows(
			IndustryCode industryCode) {
		if (isEmptyDescriptionList(industryCode)) {
			IndustryCodeDescription emptyIndustryCodeDescription = new IndustryCodeDescription();
			List<IndustryCodeDescription> emptyindustryCodeDescriptionList = new ArrayList<IndustryCodeDescription>();
			emptyindustryCodeDescriptionList.add(emptyIndustryCodeDescription);
			industryCode
					.setIndustryCodeDescriptions(emptyindustryCodeDescriptionList);
		}

		if (isEmptyMappingList(industryCode)) {
			IndustryCodeMap emptyIndustryCodeMap = new IndustryCodeMap();
			List<IndustryCodeMap> emptyIndustryCodeMapList = new ArrayList<IndustryCodeMap>();
			emptyIndustryCodeMapList.add(emptyIndustryCodeMap);
			industryCode.setIndustryCodeMaps(emptyIndustryCodeMapList);
		}

		return industryCode;
	}

	/**
	 * 
	 * The method to check whether the description field is empty
	 * 
	 * @param industryCode
	 * @return boolean
	 */
	public boolean isEmptyDescriptionList(IndustryCode industryCode) {
		if (industryCode.getIndustryCodeDescriptions() == null
				|| (industryCode.getIndustryCodeDescriptions() != null && industryCode
						.getIndustryCodeDescriptions().isEmpty())) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 
	 * The method to check whether the mapping field is empty
	 * 
	 * @param industryCode
	 * @return boolean
	 */
	public boolean isEmptyMappingList(IndustryCode industryCode) {
		if (industryCode.getIndustryCodeMaps() == null
				|| (industryCode.getIndustryCodeMaps() != null && industryCode
						.getIndustryCodeMaps().isEmpty())) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 
	 * The method will extract the industry group level filter conditions for
	 * search. The jQuery will append the group level codes with a '/' character
	 * which has to be split and added to the list for search.
	 * 
	 * @param groupLevelFilter
	 * @return groupLevelSearchCodes
	 */
	private List<Long> getIndustryGroupLevelSearchCodes(String groupLevelFilter) {
		LOGGER.info("entering IndustryCodesController | getIndustryGroupLevelSearchCodes");
		LOGGER.info("IndustryCodesController | getIndustryGroupLevelSearchCodes "
				+ "| groupLevelFilter : " + groupLevelFilter);

		List<Long> groupLevelSearchCodes = null;
		// the jQuery will append the group level codes with a '/'
		String[] grpArr = groupLevelFilter.split("/");
		if (grpArr != null && grpArr.length > 0) {
			// Iterate through the array of group level codes and add to list
			groupLevelSearchCodes = new ArrayList<Long>();
			for (int index = 0; index < grpArr.length; index++) {
				if (!grpArr[index].isEmpty()) {
					groupLevelSearchCodes.add(Long.valueOf(grpArr[index]));
				}
			}
		}
		LOGGER.info("IndustryCodesController | getIndustryGroupLevelSearchCodes "
				+ "| groupLevelSearchCodes : " + groupLevelSearchCodes);
		LOGGER.info("exiting IndustryCodesController | getIndustryGroupLevelSearchCodes");
		return groupLevelSearchCodes;
	}

	/**
	 * The method will retrieve industry code and description for given industry
	 * code type code
	 * 
	 * @param industryCodeTypeCode
	 */
	@RequestMapping(value = "retrieveDescriptionForIndsCodeTypeCode.form", method = RequestMethod.GET)
	public @ResponseBody
	String retrieveDescriptionForIndsCodeTypeCode(
			@RequestParam(value = "industryCodeTypeCode") Long industryCodeTypeCode,
			@RequestParam(value = "industryCode") String industryCode) {
		LOGGER.info("entering IndustryCodesController | retrieveDescriptionForIndsCodeTypeCode");
		LOGGER.info("IndustryCodesController | retrieveDescriptionForIndsCodeTypeCode | "
				+ "industryCode : "
				+ industryCode
				+ " | industryCodeTypeCode : " + industryCodeTypeCode);
		String description = this.wsProxy
				.retrieveDescriptionForIndsCodeTypeCode(industryCodeTypeCode,
						industryCode);
		String jsonString = "{\"description\" : \"" + description + "\"}";
		return jsonString;
	}

	/**
	 * This method checks whether the industry code has already been submitted
	 * by another user for edit
	 * 
	 * @param industryCode
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "lockIndustryCodeForEdit.form", method = RequestMethod.GET)
	public @ResponseBody
	String lockIndustryCodeForEdit(
			@ModelAttribute("industryCode") IndustryCode industryCode,
			HttpSession session) {
		LOGGER.info("entering IndustryCodesController | lockIndustryCodeForEdit ");
		Long lockIndustryCodeId = industryCode.getIndustryCodeId();
		String taskId = (String) session.getAttribute("taskId");
		if ((taskId != null) && !taskId.trim().isEmpty()) {
			return "false";
		} else {
			return this.wsProxy.lockIndustryCode(lockIndustryCodeId);
		}
	}

	/**
	 * 
	 * The method to fetch the code value details from the sCots and populate in
	 * session
	 * 
	 * @param session
	 * @return tempCodeValueMap
	 */
	@SuppressWarnings("unchecked")
	private Map<String, List<CodeValue>> setSessionValuesForCodeValues(
			HttpSession session) {
		LOGGER.info("entering IndustryCodesController | setSessionValuesForCodeValues ");
		Map<String, List<CodeValue>> tempCodeValueMap = (Map<String, List<CodeValue>>) session
				.getAttribute("tempCodeValueMap");
		//if (tempCodeValueMap == null) {
			// Retrieve data from SCOTS
			List<Integer> codeTableIds = new ArrayList<Integer>();
			codeTableIds
					.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE);
			// codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_GROUP_LEVEL);
			codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
			codeTableIds
					.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE);

			tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);

			// retrieve the group level codes
			tempCodeValueMap
					.put(String
							.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_GROUP_LEVEL),
							scotsController
									.retrieveValidIndustryCodeGroupLevels());

			session.setAttribute("tempCodeValueMap", tempCodeValueMap);
		//}

		LOGGER.info("exiting IndustryCodesController | setSessionValuesForCodeValues | returned : "
				+ tempCodeValueMap);
		return tempCodeValueMap;
	}

	/**
	 * Loads the Industry Codes Add page.
	 * <p>
	 * 
	 * @return indsCodesAdd, the ModelAndView object
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/indsCodeAdd.form", method = RequestMethod.GET)
	public ModelAndView getIndustryCodesAdd(Model model, HttpSession session) {
		LOGGER.info("entering IndustryCodesController | getIndustryCodesAdd");
		ModelAndView indsCodesAdd = new ModelAndView("indsCodesAdd");

		Map<String, List<CodeValue>> tempCodeValueMap = setSessionValuesForCodeValues(session);
		List indsTypeCodes = tempCodeValueMap
				.get(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING);
		Collections.sort(indsTypeCodes, new MsaCodeValueIdComparable());
		indsCodesAdd.addObject("industryCodeTypeCodeValues", indsTypeCodes);

		List indsGroupLevels = tempCodeValueMap
				.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_GROUP_LEVEL));
		Collections.sort(indsGroupLevels, new MsaCodeValueIdComparable());
		indsCodesAdd.addObject("industryCodeGroupLevelValues", indsGroupLevels);

		List languages = tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE));
		Collections.sort(languages, new MsaCodeValueIdComparable());
		indsCodesAdd.addObject("industryCodeLanguageValues", languages);

		List indsCodeDescLenCodes = tempCodeValueMap
				.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE));
		Collections.sort(indsCodeDescLenCodes, new MsaCodeValueIdComparable());
		indsCodesAdd.addObject("industryCodeDescLengthValues",
				indsCodeDescLenCodes);

		String userMode = (String) session.getAttribute("userMode");
		if (userMode == null) {
			model.addAttribute("industryCode",
					populateEmptyDescriptionMappingRows(new IndustryCode()));
		}

		LOGGER.info("exiting IndustryCodesController | getIndustryCodesAdd | returned : "
				+ indsCodesAdd);
		return indsCodesAdd;
	}

	/**
	 * The method will persist the new IndustryCode data in the Transaction DB.
	 * 
	 * @param IndustryCode
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/indsCodeAddToDB.form", method = RequestMethod.POST)
	public ModelAndView indsCodeAddToDB(
			@ModelAttribute("industryCode") IndustryCode industryCode,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session) throws ParseException {
		LOGGER.info("entering IndustryCodesController | indsCodeAddToDB | industryCode: "
				+ industryCode);
		// audit variables
		Date startTime = new Date();

		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();

		populateIndustryCodeMandatoryFields(industryCode, loggedInUser);
		removeEmptyList(industryCode, new IndustryCode(), loggedInUser);
		String userModeErrorMessage = isIndustryCodesInvalid(industryCode);
		if (userModeErrorMessage != null
				&& !userModeErrorMessage.trim().isEmpty()) {
			session.setAttribute("userMode", "edit");
			session.setAttribute("userModeErrorMessage", userModeErrorMessage);
			return getIndustryCodesAdd(model, session);
		} else {
			session.removeAttribute("userMode");
			session.removeAttribute("userModeErrorMessage");
		}
		session.removeAttribute("tempCodeValueMap");

		LOGGER.info("IndustryCodesController | indsCodeAddToDB | updating industryCode as: "
				+ industryCode);
		Long trackingId = wsProxy.updateIndustryCode(industryCode);

		createIndsCodesWorkflowTask(trackingId.toString(),
				RefDataChangeTypeConstants.CHANGE_TYPE_ADD_INDUSTRY_CODE,
				loggedInUser);
		sessionStatus.setComplete();

		// transaction logging
		transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
						userContextVO.getUserRoles()),
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
				"indsCodeAdd", 0L, trackingId, 0L, industryCode);

		LOGGER.info("exiting IndustryCodesController | indsCodeAddToDB");
		return workQueueController.getSubmitterWorkQueueHome("Industry Codes",
				session);
	}

	/**
	 * 
	 * The method to populate the mandatory fields
	 * 
	 * @param industryCode
	 * @param loggedInUser
	 */
	private void populateIndustryCodeMandatoryFields(IndustryCode industryCode,
			String loggedInUser) {
		industryCode.setIndustryCodeId(-1L);
		industryCode.setCreatedDate(new Date());
		industryCode.setCreatedUser(loggedInUser);
		industryCode.setModifiedDate(new Date());
		industryCode.setModifiedUser(loggedInUser);

		if (industryCode.getIndustryCodeDescriptions() != null) {
			for (IndustryCodeDescription description : industryCode
					.getIndustryCodeDescriptions()) {
				description.setCreatedDate(new Date());
				description.setCreatedUser(loggedInUser);
				description.setModifiedDate(new Date());
				description.setModifiedUser(loggedInUser);
			}
		}

		if (industryCode.getIndustryCodeMaps() != null) {
			for (IndustryCodeMap codeMap : industryCode.getIndustryCodeMaps()) {
				codeMap.setCreatedDate(new Date());
				codeMap.setCreatedUser(loggedInUser);
				codeMap.setModifiedDate(new Date());
				codeMap.setModifiedUser(loggedInUser);
			}
		}
	}

	/**
	 * 
	 * The Comparator class will sort the CodeValue based on the codeValueId
	 * property
	 * 
	 * @author Cognizant
	 * @version last updated : Apr 09, 2012
	 * @see
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public class MsaCodeValueIdComparable implements Comparator<LinkedHashMap> {

		@Override
		public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
			return ((Integer) codeValue1.get("codeValueId"))
					.compareTo((Integer) codeValue2.get("codeValueId"));
		}
	}

	/**
	 * 
	 * The Comparator class will sort the CodeValue based on the
	 * codeValueDescription property
	 * 
	 * @author Cognizant
	 * @version last updated : Apr 9, 2012
	 * @see
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public class MsaCodeDescriptionComparable implements
			Comparator<LinkedHashMap> {

		@Override
		public int compare(LinkedHashMap codeValue1, LinkedHashMap codeValue2) {
			return ((String) codeValue1.get("codeValueDescription"))
					.compareTo((String) codeValue2.get("codeValueDescription"));
		}
	}

	/**
	 * The method will populate the existing IndustryCode data from the
	 * Transaction DB. The service method need to retrieve the values from the
	 * DB and populate the UI.
	 * 
	 * @param industryCodeBulkDownloadVO
	 *            model attribute
	 * @return ModelAndView
	 * 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/industryCodeBulkDownload.form")
	public ModelAndView industryCodeBulkDownloadForm(Model model,
			HttpSession session) {
		LOGGER.info("entering IndustryCodeController | industryCodeBulkDownload");

		ModelAndView indsCodesBulkDownload = new ModelAndView(
				"industryCodeBulkDownload");
		IndusCodeBulkDownloadVO industryCodeBulkDownloadVO = new IndusCodeBulkDownloadVO();
		model.addAttribute("industryCodeBulkDownload",
				industryCodeBulkDownloadVO);

		// Retrieving the Lists for currency Code and Data Provider
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds
				.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		codeTableIds
				.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValues(codeTableIds);
		List codeValues = tempCodeValueMap
				.get(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING);
		List languages = tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE));
		List indsCodeDescLenCodes = tempCodeValueMap
				.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE));

		// sort the codeValues based on the Code Value Id
		Collections.sort(codeValues, new IndustryCodeValueIdComparable());
		Collections.sort(languages, new MsaCodeValueIdComparable());
		Collections.sort(indsCodeDescLenCodes, new MsaCodeValueIdComparable());
		session.setAttribute(
				RefDataUIConstants.INDUSTRY_CODES_SEARCH_INDUSTRY_CODE_TYPES_SESSION,
				codeValues);
		session.setAttribute(RefDataUIConstants.SCOTS_LIST_CODE_LANGUAGE_SESSION, languages);
		
		session.setAttribute(RefDataUIConstants.INDUSTRY_CODES_DESC_LENGTH_CODE_SESSION, indsCodeDescLenCodes);
		
		indsCodesBulkDownload
				.addObject("industryCodeLanguageValues", languages);
		indsCodesBulkDownload.addObject("industryCodeDescLengthValues",
				indsCodeDescLenCodes);
		
		

		LOGGER.info("IndustryCodeController | industryCodeBulkDownload | returned : "
				+ indsCodesBulkDownload);
		LOGGER.info("exiting IndustryCodesController | industryCodeBulkDownload");
		return indsCodesBulkDownload;

	}

	/**
	 * The method will populate the existing IndustryCode data from the
	 * Transaction DB. The service method need to retrive the values from the DB
	 * based on the user selection
	 * 
	 * @param industryCodeBulkDownloadVO
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/industryMyDownLoad.form", method = RequestMethod.POST)
	public View industryCodeBulkDownload(
			@ModelAttribute("industryCodeBulkDownload") IndusCodeBulkDownloadVO industryCodeBulkDownloadVO,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session) throws ParseException {

		LOGGER.info("entering IndustryCodesController | indusCodeBulkdownload");
		Date startTime = new Date();
		UiBulkDownload uiBulkDownload = new UiBulkDownload();
		uiBulkDownload.setDwnloadStartTime(startTime);
		uiBulkDownload.setFileType(industryCodeBulkDownloadVO.getFileType());
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		uiBulkDownload.setUserId(userContextVO.getUserIdentifier());
		uiBulkDownload
				.setDomainName(RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE);
		uiBulkDownload
				.setBulkDownloadStatus(RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_FILE_STATUS);
		Long uiBlkDwnldTrackingId = wsProxy.addUIBulkDownload(uiBulkDownload);
		industryCodeBulkDownloadVO.setUiBlkDwnldId(uiBlkDwnldTrackingId);
		String fileType = null;
		if (uiBulkDownload.getFileType().equalsIgnoreCase(
				"Industry Code and Description")) {
			fileType = "Inds_Cd_And_Desc";
		} else if (uiBulkDownload.getFileType().equalsIgnoreCase(
				"Industry Code Crosswalk")) {
			fileType = "Inds_Cd_CrossWalk";
		}

		String indusCodeDownLoadFileName = refdataConfig
				.getValue(RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_LOCATION)
				+ fileType
				+ RefDataPropertiesConstants.UNDERSOCRE
				+ uiBlkDwnldTrackingId
				+ RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_FILE_FORMAT;
		industryCodeBulkDownloadVO
				.setIndusCodeDownLoadFileName(indusCodeDownLoadFileName);

		LOGGER.info("IndustryCodesController | indusCodeBulkdownload "
				+ "| industryCodeBulkDownloadVO : "
				+ industryCodeBulkDownloadVO);
		wsProxy.industryCodeBulkDownload(industryCodeBulkDownloadVO);

		return new RedirectView("workQueueDownload.form");
	}

	/**
	 * The method will populate the existing IndustryCode data from the
	 * Transaction DB. The service method need to retrieve the values from the
	 * DB and populate the UI.
	 * 
	 * @param indusCodeBulkUploadVO
	 *            model attribute
	 * @return ModelAndView
	 * 
	 */

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/industryCodeBulkUpload.form")
	public ModelAndView industryCodeBulkUploadForm(Model model,
			HttpSession session) {
		LOGGER.info("entering industryCodeController | industryCodeBulkUpload");
		ModelAndView industryCodeBulkUpload = new ModelAndView();
		IndusCodeBulkUploadVO indusCodeBulkUploadVO = new IndusCodeBulkUploadVO();
		model.addAttribute("industryCodeBulkUpload", indusCodeBulkUploadVO);
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds
				.add(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValues(codeTableIds);
		List codeValues = tempCodeValueMap
				.get(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING);
		Collections.sort(codeValues, new IndustryCodeValueIdComparable());
		session.setAttribute(
				RefDataUIConstants.INDUSTRY_CODES_SEARCH_INDUSTRY_CODE_TYPES_SESSION,
				codeValues);

		LOGGER.info("exiting industryCodeController | industryCodeBulkUpload");
		return industryCodeBulkUpload;
	}

	/**
	 * The method will populate the existing IndustryCode data from the
	 * Transaction DB. The service method need to retrive the values from the DB
	 * based on the user selection
	 * 
	 * @param indusCodeBulkUploadVO
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/industryCodeUpLoad.form", method = RequestMethod.POST)
	public View industryCodeBulkUpload(
			@ModelAttribute("industryCodeBulkUpload") IndusCodeBulkUploadVO indusCodeBulkUploadVO,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session) throws ParseException {
		LOGGER.info("entering IndustryCodesController | indusCodeUpload");

		String fileName = refdataConfig
				.getValue(RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_UPLOAD_LOCATION)
				+ indusCodeBulkUploadVO.getFile().getOriginalFilename();
		File f = new File(fileName);
		LOGGER.info("IndustryCodesController | indusCodeUpload | File Name"+fileName);
		MultipartFile multipartFile = indusCodeBulkUploadVO.getFile();

		try {
			multipartFile.transferTo(f);
		} catch (IllegalStateException e) {
			LOGGER.error("Error in Industry Code Upload",e);
		} catch (IOException e) {
			LOGGER.error("Error in Industry Code Upload",e);
		}catch(Exception e){
			LOGGER.error("Error in Industry Code Upload",e);
		}

		if (result.hasErrors()) {
			for (ObjectError error : result.getAllErrors()) {
				LOGGER.error("Error: " + error.getCode() + " - "
						+ error.getDefaultMessage());
			}
		}

		createNewIndustryCodeBulkUploadWorkflowTask(
				indusCodeBulkUploadVO,
				RefDataChangeTypeConstants.CHANGE_TYPE_BULK_UPLOAD_INDUSTRY_CODE,
				(UserContextVO) session
						.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT));

		sessionStatus.setComplete();
		LOGGER.info("exiting  IndustryCodesController | indusCodeUpload");
		return new RedirectView(
				"submitterWorkQueueHome.form?domainName=Industry Codes");

	}

	/**
	 * 
	 * The method to create new task with work-flow for Industry bulk upload.
	 * 
	 * @param indusCodeBulkUploadVO
	 * @param requestType
	 * @param userContextVO
	 */
	private void createNewIndustryCodeBulkUploadWorkflowTask(
			IndusCodeBulkUploadVO indusCodeBulkUploadVO, String requestType,
			UserContextVO userContextVO) {

		String domainId = null;
		String fileName = indusCodeBulkUploadVO.getFile().getOriginalFilename();
		if (indusCodeBulkUploadVO.getFileType().equalsIgnoreCase(
				"Industry Code/Description")) {
			domainId = Long.toString(indusCodeBulkUploadVO
					.getIndustryCodeTypeCode());

		} else {
			domainId = Long.toString(indusCodeBulkUploadVO
					.getFromIndusCodeTypeCode())
					+ ";"
					+ Long.toString(indusCodeBulkUploadVO
							.getToIndusCodeTypeCode());

		}

		LOGGER.info("params for createNewCurrencyWorkflowTaskForCrcyBulkUpload : "
				+ indusCodeBulkUploadVO
				+ " : "
				+ requestType
				+ " : "
				+ userContextVO
				+ " : "
				+ RefDataPropertiesConstants.INDUSTRY_CODE_APPROVER_GROUP_ID
				+ " : "
				+ RefDataPropertiesConstants.INDUSTRY_CODE_SUBMITTER_GROUP_ID);

		homeController.createIndustryCodeBulkUploadReferenceData(domainId,
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
				Long.valueOf(requestType), userContextVO.getUserIdentifier(),
				"Industry Code Bulk Upload Reference Data" + 401, fileName,
				RefDataPropertiesConstants.INDUSTRY_CODE_APPROVER_GROUP_ID,
				RefDataPropertiesConstants.INDUSTRY_CODE_SUBMITTER_GROUP_ID);
	}

	/**
	 * 
	 * The method to create new task with work-flow.
	 * 
	 * @param infermentTextId
	 * @param requestType
	 * @param userContextVO
	 */
	private void createIndsCodesWorkflowTask(String industryCodeId,
			String changeTypeId, String loggedInUser) {

		homeController.createReferenceData(industryCodeId,
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
				Long.valueOf(changeTypeId), loggedInUser,
				"Industry Code Id: " + industryCodeId,
				RefDataPropertiesConstants.INDUSTRY_CODE_APPROVER_GROUP_ID,
				RefDataPropertiesConstants.INDUSTRY_CODE_SUBMITTER_GROUP_ID);
	}

	/**
	 * 
	 * The method to delete an existing Industry Code. After delete the control
	 * will be navigated to the Submitter view page.
	 * 
	 * @param industryCode
	 * @param session
	 * @param sessionStatus
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "/indsCodeDelete.form", method = RequestMethod.GET)
	public ModelAndView indsCodeDelete(
			@ModelAttribute("industryCode") IndustryCode industryCode,
			HttpSession session, SessionStatus sessionStatus)
			throws ParseException {
		LOGGER.info("entering IndustryCodesController | indsCodeDelete");
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);

		// audit variables
		Date startTime = new Date();

		wsProxy.deleteIndustryCode(industryCode.getIndustryCodeId(),
				userContextVO.getUserIdentifier());

		// Invoke the WorkFlow service to create the workFlow task for the
		// update operation. This will be invoked as a web service call.
		String taskId = (String) session.getAttribute("taskId");
		if ((taskId != null) && !taskId.trim().isEmpty()) {
			homeController
					.reSubmitTaskRequest(
							userContextVO,
							taskId,
							RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
							RefDataPropertiesConstants.INDUSTRY_CODE_SUBMITTER_GROUP_ID);
		} else {
			// Invoke the WorkFlow service to create the workFlow task for the
			// update operation. This will be invoked as a web service call.
			homeController
					.createReferenceData(
							String.valueOf(industryCode.getIndustryCodeId()),
							RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
							Long.valueOf(RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_INDUSTRY_CODE),
							userContextVO.getUserIdentifier(),
							"Industry Code Id: "
									+ industryCode.getIndustryCodeId(),
							RefDataPropertiesConstants.INDUSTRY_CODE_APPROVER_GROUP_ID,
							RefDataPropertiesConstants.INDUSTRY_CODE_SUBMITTER_GROUP_ID);
		}
		sessionStatus.setComplete();
		LOGGER.info("exiting IndustryCodesController | indsCodeDelete");

		// transaction logging
		transactionLogger.log(startTime, userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
						userContextVO.getUserRoles()),
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
				"indsCodeDelete", 0L, industryCode, 0L);

		return workQueueController.getSubmitterWorkQueueHome(
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE, session);
	}

	/**
	 * This method checks whether the industry code description entered already
	 * exists
	 * 
	 * @param industryCode
	 * @param industryCodeTypeCode
	 * @param session
	 * @return isDuplicate
	 */
	@RequestMapping(value = "isDescriptionDuplicate.form", method = RequestMethod.GET)
	public @ResponseBody
	Boolean isDescriptionDuplicate(
			@RequestParam(value = "industryCode") final String industryCode,
			@RequestParam(value = "industryCodeTypeCode") final Long industryCodeTypeCode,
			@RequestParam(value = "industryDescription") final String industryDescription) {
		LOGGER.info("entering IndustryCodesController | isDescriptionDuplicate ");
		return this.wsProxy.isIndustryCodeDescriptionDuplicate(industryCode,
				industryCodeTypeCode, industryDescription);
	}

	/**
	 * 
	 * Export the Industry Code search details.
	 * <p>
	 * 
	 * The export will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param industryCodesSearchCriteria
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @param session
	 * @return indsCodeSearch, the ModelAndView
	 */
	@RequestMapping(value = "/indsCodeExportToExcelResults.form", method = RequestMethod.GET)
	public @ResponseBody
	void getIndustryCodesExportToExcelResults(HttpServletRequest request,
			HttpSession session, HttpServletResponse response) {
		LOGGER.info("entering IndustryCodesController | indsCodeExportToExcelResults");
		IndustryCodesSearchCriteriaVO industryCodesSearchCriteria = getIndustryCodesSearchCriteria(request);
		industryCodesSearchCriteria.setViewType(request.getParameter("type"));
		IndsExportToExcel indsExprtToExcel = null;
		if (request.getParameter("export").equals("IndsCode")) {
			indsExprtToExcel = new IndsExportToExcel(
					industryCodesSearchCriteria
							.getIndustryCodeTypeCodeLiteralDescription());
			indsExprtToExcel.insertIndsCodeData(wsProxy
					.searchIndustryCodes(industryCodesSearchCriteria));
		} else {
			indsExprtToExcel = new IndsExportToExcel(
					industryCodesSearchCriteria
							.getIndustryCodeTypeCodeLiteralDescription(),
					industryCodesSearchCriteria
							.getIndustryCodeCrosswalkLiteralDescription());
			indsExprtToExcel.insertIndsCodeDescData(wsProxy
					.searchIndustryCodes(industryCodesSearchCriteria));
		}
		response.setContentType("application/xlsx");
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ "SearchResult.xlsx" + "\"");
		try {
			indsExprtToExcel.write(response.getOutputStream());
		} catch (IOException e) {
			LOGGER.error("problem in IndustryCodesController |"
					+ e.getMessage());
		}

	}
	
	/**
	 * Industry Code Crosswalk Dashboard
	 * The dashboard will display the list of crosswalks available along with the count
	 * of records in each crosswalk
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/indsCrosswalkDashboard.form", method = RequestMethod.GET)
	public ModelAndView CrosswalkDashboard(HttpSession session) {
		
		LOGGER.info("entering IndustryCodesController | CrosswalkDashboard");
		ModelAndView indsCrosswalkDashboard = new ModelAndView("indsCrosswalkDashboard");		
		
		List<InduscodeMappingBulkDownloadVO> crosswalkDetails = wsProxy
				.retrieveCrosswalkDetails();		

		indsCrosswalkDashboard.addObject("crosswalkDetails", crosswalkDetails);

		LOGGER.info("exiting IndustryCodesController | CrosswalkDashboard");
		return indsCrosswalkDashboard;
	}

}
