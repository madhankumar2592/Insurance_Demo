/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.web.proxy;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.XmlSchemaSearchVO;
import com.dnb.dsc.refdata.web.util.RestWebServiceUtil;


/**
 * The Xml schema proxy class will handle the mapping between the UI web
 * requests and the respective service end point class.The class will construct
 * the REST WS requests and exchange the request with the service end point for 
 * the response.
 * @author Cognizant
 * @version last updated : Apr 13, 2012
 * @see
 * 
 */
@Component
public class XmlSchemaLabelProxy {

	@Autowired
	private RestWebServiceUtil restWSUtil;
	
    /**
     * The instance variable for Logging
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(XmlSchemaLabelProxy.class);

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private RefDataConfigUtil refDataConfigUtil;

    
    /**
     * The proxy method for search xml schema element by element name or description. The method will construct
     * the HTTP request for the service end point and returns the response to
     * the controller class.
     *
     * @param xmlSchemaSearchVO
     * @return
     */
    @SuppressWarnings("unchecked")
    public List<XmlSchemaElement> searchXmLSchemaLabels(XmlSchemaSearchVO xmlSchemaSearchVO) {
        LOGGER.info("entering XmlSchemaLabelProxy | searchXmLSchemaLabels");

        HttpEntity<XmlSchemaSearchVO> entity = new HttpEntity<XmlSchemaSearchVO>(xmlSchemaSearchVO);
        String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/schemaLabelSearch.service";
        LOGGER.info("exiting XmlSchemaLabelProxy | searchXmLSchemaLabels");
        return (List<XmlSchemaElement>) this.restTemplate.postForObject(serviceURL, entity, List.class,
                new Object[0]);
    }

    
	/**
	 * 
	 * The method will perform the table count of xml schema element on the
	 * staging db based on the specified filter conditions.
	 * 
	 * @param XmlSchemaSearchVO
	 * @return count of XmlSchemaElement
	 */
	public Long countSearchXmLSchemaLabels(XmlSchemaSearchVO xmlSchemaSearchVO) {
		LOGGER.info("entering XmlSchemaLabelProxy | countSearchXmLSchemaLabels");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/countSearchXmLSchemaLabels.service";
		HttpEntity<XmlSchemaSearchVO> entity = new HttpEntity<XmlSchemaSearchVO>(
				xmlSchemaSearchVO);
		LOGGER.info("exiting XmlSchemaLabelProxy | countSearchXmLSchemaLabels");
		return (Long) this.restTemplate.postForObject(serviceURL, entity,
				Long.class, new Object[0]);
	}
	/**
	 *
	 * The method will validate the XmlSchemaElement for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param xmlSchemaElementId
	 * @return
	 */
	public Boolean lockXmlSchemaElement(String xmlSchemaElementId) {
		LOGGER.info("entering XmlSchemaLabelProxy | lockXmlSchemaElement");

		HttpEntity<Boolean> entity = new HttpEntity<Boolean>(
				restWSUtil.constructRequestHeader());
		String serviceURL =refDataConfigUtil.getServiceDeployURL() + "/{xmlSchemaElementId}/lockXmlSchema.service";
		ResponseEntity<Boolean> result = this.restTemplate.exchange(serviceURL, HttpMethod.GET,
					entity, Boolean.class, new Object[] { xmlSchemaElementId });
		LOGGER.info("exiting XmlSchemaLabelProxy | lockXmlSchemaElement");
		return result != null ? (Boolean) result.getBody() : null;
	}
	/**
	The method will persist the edited xmlSchemaLabel in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * @param xmlSchemaElement
	 */
	public String updateXmlSchemaElement(XmlSchemaElement xmlSchemaElement) {
		LOGGER.info("entering XmlSchemaLabelProxy | updateXmlSchemaElement");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/updateXmlSchemaElement.service";
		HttpEntity<XmlSchemaElement> entity = new HttpEntity<XmlSchemaElement>(
				xmlSchemaElement);
		LOGGER.info("exiting XmlSchemaLabelProxy | updateXmlSchemaElement");
		return restTemplate.postForObject(serviceURL, entity, String.class);
	}
	
	  /**
     * The proxy method for search xml schema element by element id. The method will construct
     * the HTTP request for the service end point and returns the response to
     * the controller class.
     *
     * @param elementId
     * @return
     */
    public XmlSchemaElement reviewXmlSchemaByXmlElementChanges(String elementId) {
		return retrieveXmlSchemaElement(elementId, "/{elementId}/reviewXmlSchemaByXmlElementChanges.service");
    }
    
    /**
     * The proxy method for search xml schema element by element id. The method will construct
     * the HTTP request for the service end point and returns the response to
     * the controller class.
     *
     * @param elementId
     * @return
     */
    public XmlSchemaElement retrieveXmlSchemaByXmlElementId(String elementId) {
		return retrieveXmlSchemaElement(elementId, "/{elementId}/retrieveXmlSchemaByXmlElementId.service");
    }
    /**
     * 
     * The generic method to retrieve the Xml Schema Element details
     *
     * @param elementId
     * @param deployURL
     * @return
     */
    private XmlSchemaElement retrieveXmlSchemaElement(String elementId, String deployURL) {
        HttpEntity<XmlSchemaElement> entity = new HttpEntity<XmlSchemaElement>(restWSUtil.constructRequestHeader());

        String serviceURL = refDataConfigUtil.getServiceDeployURL() + deployURL;

        ResponseEntity<XmlSchemaElement> result = null;
        result = (ResponseEntity<XmlSchemaElement>) this.restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
                  XmlSchemaElement.class, elementId);
		return result != null ? result.getBody() : null;
    }
}
