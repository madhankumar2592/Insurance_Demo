package com.dnb.dsc.refdata.web.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GlobalElement;
import com.dnb.dsc.refdata.core.entity.GloblalElementCrossWalk;
import com.dnb.dsc.refdata.core.vo.AddCrosswalkVO;
import com.dnb.dsc.refdata.core.vo.AddGlobalElementVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementCrosswalkSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementDetailVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementSearchVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.web.proxy.GlobalElementWebServiceProxy;
import com.dnb.dsc.refdata.web.util.GlobalElementCrosswalkExport;
import com.dnb.dsc.refdata.web.util.GlobalElementExport;


@Controller
public class GlobalElementController {
	
	@Autowired
	private HomeController homeController;
	
	@Autowired
	private GlobalElementWebServiceProxy wsProxy;
	
	/**
	 * The constant for the allSearchColumns 
	 */
	
	private final String[] searchColumns = { "globalElementId","globalElementTopicCategoryCode","topicCategoryDescription",
			"globalElementName", 
			"globalElementMetadataCode","globalElementMetadataCodeDescription",			
			"globalElementMetadataValue","effectiveDate","expirationDate","globalElementComment","globalElementDetailComment"};
	
	private final String[] searchColumnsCrosswalk = { "globalElementId","globalElementCrosswalkId","globalElementMetadataCode",
			"globalElementMetadataCodeDescription","globalElementMetadataValue","globalElementPlatformCode","globalElementPlatformCodeDescription"
			,"globalElementCrosswalkGrpNme"};

	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GlobalElementController.class);

		
	
	/**
	 * Loads the Global Element Financial search page.
	 * <p>
	 * 	 
	 * <p>
	 * 
	 * @param model
	 * @param session
	 * @return FinancialSearch, the ModelAndView object
	 */
	
	
	@RequestMapping(value = "/allSearchBkp.form", method = RequestMethod.GET)
	public ModelAndView getFinancialSearch(HttpSession session,Boolean updateElmentSuccess) {
		
		LOGGER.info("entering GlobalElementController | getAllSearch");
		ModelAndView allSearchBkp = new ModelAndView("allSearchBkp");		
		

		List<Integer> codeTableIds = new ArrayList<Integer>();

		codeTableIds.add(725);
		
	
		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
		allSearchBkp.addObject("topicList",
				tempCodeValueMap.get(String.valueOf(725)));		
			
		allSearchBkp.addObject("updateElmentSuccess",updateElmentSuccess);

		
		LOGGER.info("exiting GlobalElementController | getAllSearch");
		return allSearchBkp;
	}
	
	
	
	
	
	/**
	 * 
	 * Retrieves the Global Element all search details.
	 * <p>
	 * 
	 * The search will be done on the  db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param allSearchCriteria
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @param session
	 * @return allSearch, the ModelAndView
	 */
	@RequestMapping(value = "/allSearchAjaxResultsBkp.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getGlblEleSearchAjaxResultsBkp(
			HttpServletRequest request, HttpSession session) {
LOGGER.info("entering GlobalElementController | getGlblEleSearchAjaxResults");
		
		String searchString = homeController.getSearchString(request);

		if (searchString == null || searchString.trim().isEmpty()) {
			return homeController.getJsonMap(request,
					new ArrayList<GlobalElementSearchVO>(), 0L, searchColumns);
		}
		
		GlobalElementSearchVOBkp globalElementSearchCriteria = getGlobalElementSearchCriteriaBkp(request);
		
		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		Long countGlblEleAllSearchResults = (Long) session
				.getAttribute("countGlblEleAllSearchResults");
		if ((countGlblEleAllSearchResults == null) || (globalElementSearchCriteria.getRowIndex() == 0)) {
			countGlblEleAllSearchResults = wsProxy.countSearchByTopicsBkp(globalElementSearchCriteria);
			session.setAttribute("countGlblEleAllSearchResults",
					countGlblEleAllSearchResults);
		}

		Map<String, Object> map = null;
		try {
			map = homeController.getJsonMap(request,
					wsProxy.searchByTopicsBkp(globalElementSearchCriteria),
					countGlblEleAllSearchResults, searchColumns);
		} catch (Exception e) {			
			e.printStackTrace();
		}

		LOGGER.info("GlobalElementController | getGlblEleSearchAjaxResults | returned after searchByTopics");
				
		LOGGER.info("exiting GlobalElementController | getGlblEleSearchAjaxResults");
		return map;
	}
	
	/**
	 * 
	 * The method to populate the GlobalElementSearchCriteriaVO
	 * 
	 * @param request
	 * @return GlobalElementSearchCriteriaVO
	 */
	private GlobalElementSearchVOBkp getGlobalElementSearchCriteriaBkp(
			HttpServletRequest request) {
		LOGGER.info("entering GlobalElementController | getGlobalElementSearchCriteria");

		GlobalElementSearchVOBkp globalElementSearchCriteria = new GlobalElementSearchVOBkp();
		globalElementSearchCriteria.setSortOrder(homeController
				.getSortOrder(request));		
		globalElementSearchCriteria.setSortBy(homeController.getSortBy(request, searchColumns));
		globalElementSearchCriteria.setMaxResults(homeController
				.getMaxResults(request));
		globalElementSearchCriteria.setRowIndex(homeController
				.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);
		// Search string will be in the format
		// code#~text#~desc#~code#~text
		String searchCriteriaDelimiter = "~";
		if (compositeSearchString != null) {
			String[] splitCriteria = compositeSearchString
					.split(searchCriteriaDelimiter);
			if (splitCriteria.length > 0) {
				if (!(splitCriteria[0].replace("#", "").trim().isEmpty())) {
					globalElementSearchCriteria
							.setGlobalElementId(Long
									.valueOf(splitCriteria[0]
									.replace("#", "").trim()));
				}
			}
			if (splitCriteria.length > 1) {
				if (!(splitCriteria[1].replace("#", "").trim().isEmpty())) {
					globalElementSearchCriteria
							.setGlobalElementTopicCategoryCode(Long
									.valueOf(splitCriteria[1].replace(
									"#", "").trim()));
				}
			}			
			if (splitCriteria.length > 2) {
				if (!(splitCriteria[2].replace("#", "").trim().isEmpty())) {
					globalElementSearchCriteria
							.setGlobalElementName(splitCriteria[2]
									.replace("#", "").trim());
				}
			}
			if (splitCriteria.length > 3) {
				if (!(splitCriteria[3].replace("#", "").trim().isEmpty())) {
					globalElementSearchCriteria
							.setGlobalElementMetadataValue((splitCriteria[3]
									.replace("#", "").trim()));
					
					
				}
			}
			if (splitCriteria.length > 4) {
				if (!(splitCriteria[4].replace("#", "").trim().isEmpty())) {
					globalElementSearchCriteria
							.setGlobalElementMetadataValue(splitCriteria[4]
									.replace("#", "").trim());
					
				}
			}
		
		}		

		LOGGER.info("GlobalElementController | getGlobalElementSearchCriteria | globalElementSearchCriteria : "
				+ globalElementSearchCriteria);
		LOGGER.info("exiting GlobalElementController | getGlobalElementSearchCriteria");
		return globalElementSearchCriteria;
	}
	
	/**
	 * 
	 * Export the All search details.
	 * <p>
	 * 
	 * The export will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param allSearchCriteria
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @param session
	 * @return allSearch, the ModelAndView
	 */
	@RequestMapping(value = "/allSearchExportToExcelResultsBkp.form", method = RequestMethod.GET)
	public @ResponseBody
	void getAllSearchExportToExcelResultsBkp(HttpServletRequest request,
			HttpSession session, HttpServletResponse response) {
		LOGGER.info("entering GlobalElementController | getAllSearchExportToExcelResults");
		GlobalElementSearchVOBkp globalElementSearchCriteria = getGlobalElementSearchCriteriaBkp(request);
		globalElementSearchCriteria.setViewType(request.getParameter("type"));
		GlobalElementExport globalElementExport = null; 
		globalElementExport = new GlobalElementExport("");
		
		try {
			globalElementExport.insertAllSearchData(wsProxy
						.searchByTopicsBkp(globalElementSearchCriteria));
		} catch (Exception e) {
			LOGGER.error("problem in GlobalElementController |getAllSearchExportToExcelResults", e);
		}
		UserContextVO userContextVO = (UserContextVO) session
		.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserFirstName();
		String dateAppend = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date());
		response.setContentType("application/xlsx");
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ "GlobalElement_" + loggedInUser + "_"
				+ dateAppend + ".xlsx" + "\"");
		try {
			globalElementExport.write(response.getOutputStream());
		} catch (IOException e) {
			LOGGER.error("problem in GlobalElementController |getAllSearchExportToExcelResults",e);
		}catch (Exception e) {
			LOGGER.error("problem in GlobalElementController |getAllSearchExportToExcelResults",e);
		}

	}
	
	
	/**
	 * Loads the Global Element search home page.
	 * <p>
	 * 
	 * Retrieves all topic information to be populated in the screen.
	 * <p>
	 * 
	 * @param model
	 * @param session
	 * @return allSearch, the ModelAndView object
	 */
	@SuppressWarnings({"rawtypes" })
	@RequestMapping(value = "/glblHome.form", method = RequestMethod.GET)
	public ModelAndView glblHome(HttpSession session) {
		LOGGER.info("entering GlobalElementController | getAllSearch");
		ModelAndView glblHome = new ModelAndView("glblHome");

		// Retrieving the Lists of Hints		
		List hintsTypeList = retrieveAllHints();	
		
		//Retrieving the list of Hins desc
		List hintsTypeDescList = retrieveAllHintsDesc();
		
		LOGGER.info("GlobalElementController | getAllSearch | hintsTypeList : "+ hintsTypeList +"\n hintsTypeDescList"+hintsTypeDescList);
		
		glblHome.addObject("hintsTypeList", hintsTypeList);
		glblHome.addObject("hintsTypeDescList", hintsTypeDescList);
		
		LOGGER.info("exiting GlobalElementController | getAllSearch");
		return glblHome;
	}
	
	/**
	 * This method will retrieve the Topic details from the DB. The return
	 * is a VO that contains all Topics.
	 */
	private List<GlobalElementVO> retrieveAllHints() {
		return this.wsProxy.retrieveHints();
	}
	
	/**
	 * This method will retrieve the Topic details from the DB. The return
	 * is a VO that contains all Topics.
	 */
	private List<GlobalElementVO> retrieveAllHintsDesc() {
		return this.wsProxy.retrieveHintsDesc();
	}
	
	
	@RequestMapping(value = "/glblEleAdd.form", method = RequestMethod.GET)
	public ModelAndView AddNewGlobalElement(Model model, HttpSession session,Boolean addGlblEleSuccess,Long globalElementId) {
		LOGGER.info("entering GlobalElementController | AddNewGlobalElement");
		ModelAndView addNewGlobalElement = new ModelAndView("addNewGlobalElement");
	
		
		List<Integer> codeTableIds = new ArrayList<Integer>();

		codeTableIds.add(726);// Element Type
		codeTableIds.add(725);// Topic Category
		codeTableIds.add(3);// Language
				
		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
		
		addNewGlobalElement.addObject("elementType",tempCodeValueMap.get(String.valueOf(726)));
		addNewGlobalElement.addObject("topicCategory",tempCodeValueMap.get(String.valueOf(725)));
		addNewGlobalElement.addObject("language",tempCodeValueMap.get(String.valueOf(3)));
		addNewGlobalElement.addObject("globalElementId",globalElementId);
		addNewGlobalElement.addObject("addGlblEleSuccess",addGlblEleSuccess);
		//addNewGlobalElement.addObject("elementName",elementNameList);
		
		AddGlobalElementVO addGlobalElementVO = new AddGlobalElementVO();
		model.addAttribute("globalElement",
				populateEmptyDescriptionMappingRows(session,addGlobalElementVO));
		
		LOGGER.info("exiting GlobalElementController | AddNewGlobalElement");
		return addNewGlobalElement;
		
	}
	
	/**
	 * 
	 * The method to populate the Global Element VO for display in UI. The method
	 * will populate the required/mandatory fields for the Global Element.
	 * 
	 * @param session
	 * @return addGlobalElementVO
	 */
	public  AddGlobalElementVO populateEmptyDescriptionMappingRows(HttpSession session,
			AddGlobalElementVO addGlobalElementVO) {
		
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		Date currentDate = new Date();
		
		addGlobalElementVO = addGlobalElementVO != null ? addGlobalElementVO : new AddGlobalElementVO();
		if (addGlobalElementVO.getGlobalElementId() == null) {
			addGlobalElementVO.setGlobalElementId(-1L);
			if (addGlobalElementVO.getEffectiveDate() == null) {
				addGlobalElementVO.setEffectiveDate(currentDate);
			}
			addGlobalElementVO.setCreatedDate(currentDate);
			addGlobalElementVO.setCreatedUser(userContextVO.getUserIdentifier());
		}
		addGlobalElementVO.setModifiedDate(currentDate);
		addGlobalElementVO.setModifiedUser(userContextVO.getUserIdentifier());

		List<GlobalElementDetailVO> globalElementDetailVO = addGlobalElementVO.getGlobalElementDetailVO() != null ? addGlobalElementVO
				.getGlobalElementDetailVO() : new ArrayList<GlobalElementDetailVO>();

		if (globalElementDetailVO.size() == 0) {
			GlobalElementDetailVO globalElementDetail = new GlobalElementDetailVO();
			globalElementDetailVO.add(globalElementDetail);
		}
		int pkIndex = 0;
		for (GlobalElementDetailVO globalElementDetails : globalElementDetailVO) {
			if ((globalElementDetails.getGlobalElementDetailId() == null)
					|| (globalElementDetails.getGlobalElementDetailId() != null && globalElementDetails.getGlobalElementDetailId() <= 0)) {
				globalElementDetails.setGlobalElementDetailId(Long.valueOf(--pkIndex));					
				globalElementDetails.setCreatedDate(currentDate);
				globalElementDetails.setCreatedUser(userContextVO.getUserIdentifier());
				globalElementDetails.setGlobalElementMetadataLangCode(RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			}
			
			globalElementDetails.setModifiedDate(currentDate);
			globalElementDetails.setModifiedUser(userContextVO.getUserIdentifier());
		}
		addGlobalElementVO.setGlobalElementDetailVO(globalElementDetailVO);
		
		return addGlobalElementVO; 
	}
	
	
	/**
	 * 
	 * The method to insert the newly added Global Element to the database. The
	 * method will bind the UI values and construct the Global Element VO.
	 * 
	 * @param globalElementVO
	 * @param result
	 * @param session
	 * @param request
	 * @return RedirectView
	 */
	@RequestMapping(value = "/insertGlobalElement.form", method = RequestMethod.POST)
	public ModelAndView insertGlobalElement(
			@ModelAttribute("globalElement") AddGlobalElementVO addGlobalElementVO,
			BindingResult result, Model model,HttpSession session,
			HttpServletRequest request,Boolean addGlblEleSuccess) {
		LOGGER.info("entering GlobalElementController | insertGlobalElement");
		// audit variables
		

		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();
		populateNewGlobalElementMandatoryFields(addGlobalElementVO, loggedInUser);

		// merge the details to the code value table
		Long globalElementId = wsProxy.insertGlobalElement(addGlobalElementVO);
		LOGGER.info("GlobalElementController | insertGlobalElement | completed for globalElementId "
				+ globalElementId);
		addGlblEleSuccess = true;
		return AddNewGlobalElement(model,session,addGlblEleSuccess,globalElementId);
		
	}
	
	private void populateNewGlobalElementMandatoryFields(
			AddGlobalElementVO addGlobalElementVO, String loggedInUser) {
		LOGGER.info("entering GlobalElementController | populateNewGlobalElementMandatoryFields");
		addGlobalElementVO.setCreatedDate(new Date());
		addGlobalElementVO.setCreatedUser(loggedInUser);
		addGlobalElementVO.setModifiedDate(new Date());
		addGlobalElementVO.setModifiedUser(loggedInUser);

		if (addGlobalElementVO.getGlobalElementDetailVO() != null) {
			for (GlobalElementDetailVO glblEleDtl : addGlobalElementVO
					.getGlobalElementDetailVO()) {
				glblEleDtl.setCreatedDate(new Date());
				glblEleDtl.setCreatedUser(loggedInUser);
				glblEleDtl.setModifiedDate(new Date());
				glblEleDtl.setModifiedUser(loggedInUser);
			}
		}

		LOGGER.info("exiting GlobalElementController | populateNewGlobalElementMandatoryFields");

	}
		
	
	/**
	 * This method will retrieve the Element Names from the DB. The return
	 * is a VO that contains all Element Names.
	 */
	//private List<GlobalElement_Bkp> retrieveElementName() {
	//	return this.wsProxy.retrieveElementName();
	//}
	
	@RequestMapping(value = "/editGlobalElementSearch.form", method = RequestMethod.GET)
	public ModelAndView editGlobalElement(
			@RequestParam("elementID") final Long elementID, Model model,HttpSession session) {
		LOGGER.info("entering globalElementController | editGlobalElement");
		ModelAndView editGlobalElement = new ModelAndView("editGlobalElement");
		
		
		AddGlobalElementVO addGlobalElement = new AddGlobalElementVO();
		addGlobalElement.setGlobalElementId(elementID);
		
		//to retrieve details from Global Element table
		AddGlobalElementVO addGlobalElementVO = wsProxy.retrieveGlobalElement(addGlobalElement);
		
		List<Integer> codeTableIds = new ArrayList<Integer>();

		codeTableIds.add(726);// Element Type
		codeTableIds.add(725);// Topic Category
		codeTableIds.add(3);// Language
		
		
		
		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
		
		editGlobalElement.addObject("elementType",tempCodeValueMap.get(String.valueOf(726)));
		editGlobalElement.addObject("topicCategory",tempCodeValueMap.get(String.valueOf(725)));
		editGlobalElement.addObject("language",tempCodeValueMap.get(String.valueOf(3)));
				
		editGlobalElement.addObject("elementID",addGlobalElementVO.getGlobalElementId());
		addGlobalElementVO.setGlobalElementMetadataLangCode(RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);		
	
			model.addAttribute("editGlobalElement",addGlobalElementVO);
		
		return editGlobalElement;
	}

	
	@RequestMapping(value = "/editGlobalElement.form", method = RequestMethod.POST)
	public ModelAndView editElementValue(
			@ModelAttribute("editGlobalElement") AddGlobalElementVO addGlobalElementVO,
			BindingResult result, Model model, HttpSession session,
			HttpServletRequest request,Boolean updateElmentSuccess) {
		try {
			LOGGER.info("entering globalElementController | editElementValue");
			UserContextVO userContextVO = (UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
			String loggedInUser = userContextVO.getUserIdentifier();
			populateEditElementMandatoryFields(addGlobalElementVO, loggedInUser);

			session.removeAttribute("tempCodeValueMap");
			Long updatedGlobalElement = wsProxy.editGlobalElement(addGlobalElementVO);

			LOGGER.info("ProductController | addNewProductHome | editing addNewProductsVO : "
					+ updatedGlobalElement);
			updateElmentSuccess= true;
			LOGGER.info("exiting globalElementController | editElementValue");
		} catch (Exception e) {
			LOGGER.error("exiting globalElementController | editElementValue",e);
		}
		return getFinancialSearch(session,updateElmentSuccess);
	}
	
	private void populateEditElementMandatoryFields(
			AddGlobalElementVO addGlobalElementVO, String loggedInUser) {
		LOGGER.info("entering globalElementController | populateEditElementMandatoryFields");
		addGlobalElementVO.setCreatedDate(new Date());
		addGlobalElementVO.setCreatedUser(loggedInUser);
		addGlobalElementVO.setModifiedDate(new Date());
		addGlobalElementVO.setModifiedUser(loggedInUser);

		if (addGlobalElementVO.getGlobalElementDetailVO() != null) {
			for (GlobalElementDetailVO glblElemntDetail : addGlobalElementVO.getGlobalElementDetailVO()) {
				glblElemntDetail.setCreatedDate(new Date());
				glblElemntDetail.setCreatedUser(loggedInUser);
				glblElemntDetail.setModifiedDate(new Date());
				glblElemntDetail.setModifiedUser(loggedInUser);
			}
		}

		LOGGER.info("exiting globalElementController | populateEditElementMandatoryFields");

	}	

	
	@RequestMapping(value = "/isDuplicateElementName.form", method = RequestMethod.GET)
	public @ResponseBody
	Boolean isDuplicateElementName(
			@RequestParam("globalElementName") String globalElementName,HttpSession session) {
		LOGGER.info("entering GlobalElementController | isDuplicateElementName");	
		
		Boolean  eleName = wsProxy.isDuplicateElementName(globalElementName);			
		LOGGER.info("exiting GlobalElementController | isDuplicateElementName | eleName"+eleName);
		return eleName;
	}

	@RequestMapping(value = "/glblEleCrosswalk.form", method = RequestMethod.GET)
	public ModelAndView AddCrossWalk(Model model, HttpSession session) {
		LOGGER.info("entering GlobalElementController | AddCrossWalk");
		ModelAndView addCrossWalk = new ModelAndView("addCrosswalk");
		
		AddCrosswalkVO glblEleCrosswlk = new AddCrosswalkVO();		
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(729);// Data PlatForm
		
		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
		
		addCrossWalk.addObject("dataPlatform",tempCodeValueMap.get(String.valueOf(729)));
		
		model.addAttribute("addCrosswalk",populateEmptyMetadataRows(glblEleCrosswlk));		
		LOGGER.info("exiting GlobalElementController | AddCrossWalk");
		return addCrossWalk;
		
	}
	
	public AddCrosswalkVO populateEmptyMetadataRows(AddCrosswalkVO glblEleCrosswlk) {
		if (isEmptyGranularityList(glblEleCrosswlk)) {
			GloblalElementCrossWalk emptyGloblalElementCrossWalk = new GloblalElementCrossWalk();
			List<GloblalElementCrossWalk> emptyGloblalElementCrossWalkList = new ArrayList<GloblalElementCrossWalk>();
			emptyGloblalElementCrossWalkList.add(emptyGloblalElementCrossWalk);
			glblEleCrosswlk.setGloblalElementCrossWalk(emptyGloblalElementCrossWalkList);
		}
		return glblEleCrosswlk;
	}

	public boolean isEmptyGranularityList(AddCrosswalkVO glblEleCrosswlk) {
		if (glblEleCrosswlk.getGloblalElementCrossWalk() == null
				|| (glblEleCrosswlk.getGloblalElementCrossWalk() != null && glblEleCrosswlk.getGloblalElementCrossWalk().isEmpty())) {
			return true;
		} else {
			return false;
		}
	}
	
	
	// to check if Element ID exists in Element table and CrossWalk Table
	@RequestMapping(value = "checkElementID.form", method = RequestMethod.GET)
	public @ResponseBody
	String checkGlobalElementID(@RequestParam("globalElementId") Long globalElementId,HttpSession session) {
		LOGGER.info("entering GlobalElementController | checkGlobalElementID");
		// audit variables
		
		String result = null;	
		String glblEleName = wsProxy.retrieveGlobalElement(globalElementId);
				
		GloblalElementCrossWalk glblEleCroswlk = new GloblalElementCrossWalk();
		glblEleCroswlk.setGlobalElementId(globalElementId);
		
		Long countGlblElemntCrswlkId = wsProxy.checkGlblEleCrswlkId(glblEleCroswlk);
		
		if(glblEleName != "false" && countGlblElemntCrswlkId == 0){
			result = glblEleName;
		}
		else if(glblEleName != null && countGlblElemntCrswlkId > 0){
			result = glblEleName.concat(",GIED# exists in CrossWalk");
		}
		else if(glblEleName == "false" && countGlblElemntCrswlkId == 0){
			result = "false";
		}		
		
		LOGGER.info("exiting GlobalElementController | checkGlobalElementID");
		return result;
	}
	
	
	
	
		
	@RequestMapping(value = "retrieveDetails.form", method = RequestMethod.GET)
	public @ResponseBody
	List<AddCrosswalkVO> retrievePlatformDetails (@RequestParam("globalElementPlatformCode") Long globalElementPlatformCode,HttpSession session) {
		LOGGER.info("entering GlobalElementController | retrievePlatformDetails");	
		
		List<AddCrosswalkVO> addCrosswalkVO =  wsProxy.retrievePlatformDetails(globalElementPlatformCode);		 

		LOGGER.info("exiting GlobalElementController | retrievePlatformDetails");
		return addCrosswalkVO;
	}
	
	@RequestMapping(value = "/addCrosswalk.form", method = RequestMethod.POST)
	public ModelAndView SubmitAddCrosswalk(
			@ModelAttribute("addCrosswalk") AddCrosswalkVO addCrosswalkVO,
			Model model, HttpSession session,Boolean updateCroswalkSuccess) {
		LOGGER.info("entering ScoreController | ScoreMappingHome");

		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();

		populateNewCwlkMandatoryFields(addCrosswalkVO, loggedInUser);
		
				
		Long crosswalkId = wsProxy.addNewCrosswalk(addCrosswalkVO);

		LOGGER.info("GlobalElementController | SubmitAddCrosswalk | updating NewScoreTypeCode : "
				+ crosswalkId);
		updateCroswalkSuccess = true;
		LOGGER.info("exiting ScoreController | ScoreMappingHome");
		
		return SearchCrossWalk(model,session,updateCroswalkSuccess);
	}
	
	private void populateNewCwlkMandatoryFields(AddCrosswalkVO addCrosswalkVO,
			String loggedInUser) {
		LOGGER.info("entering GlobalElementController | populateNewCwlkMandatoryFields");		
		addCrosswalkVO.setCreatedDate(new Date());
		addCrosswalkVO.setCreatedUser(loggedInUser);
		addCrosswalkVO.setModifiedDate(new Date());
		addCrosswalkVO.setModifiedUser(loggedInUser);			
		LOGGER.info("exiting GlobalElementController | populateNewCwlkMandatoryFields");

	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "retrieveDetailsSearchCrosswalk.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveDetailsSearchCrosswalk(
			@RequestParam(value = "crosswalkAppliedParam", required = true) Long crosswalkAppliedCode,
			HttpSession session) {
		
		LOGGER.info("entering IndustryCodesController | retrieveCrossWalksForIndsCodeType");
		// audit variables
		List codeValueVOs = this.wsProxy
				.retrieveSearchCrossWalkCodeType(crosswalkAppliedCode);
		// sort the list of codeValueVOs based on the description
		LOGGER.info("exiting IndustryCodesController | retrieveCrossWalksForIndsCodeType");
		return codeValueVOs;
	}

	// to retrieve & populate Global Element Data Platform
	@RequestMapping(value = "retrieveGlobalEleDataPlatform.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveGlobalEleDataPlatform(HttpSession session) {
		LOGGER.info("entering GlobalElementController | retrieveGlobalEleDataPlatform");
		// audit variables
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(729);// Data Platform
		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValues(codeTableIds);
		List<CodeValue> CodeValues = new ArrayList<CodeValue>();
		CodeValues = tempCodeValueMap.get(String.valueOf(729));
		LOGGER.info("exiting GlobalElementController | retrieveGlobalEleDataPlatform");
		return CodeValues;
	}

	@RequestMapping(value = "/crosswalkSearchAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getCrosswalkSearchAjaxResults(
			HttpServletRequest request, HttpSession session) {
		LOGGER.info("entering GlobalElementController | getCrosswalkSearchAjaxResults");
		String searchString = homeController.getSearchString(request);
		if (searchString == null || searchString.trim().isEmpty()) {
			return homeController.getJsonMap(request,
					new ArrayList<GlobalElementCrosswalkSearchVOBkp>(), 0L,
					searchColumnsCrosswalk);
		}
		GlobalElementCrosswalkSearchVOBkp globalElementCrosswalkSearchCriteria = getGlobalElementCrosswalkSearchCriteria(request);
		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		Long countGlblEleCrosswalkSearchResults = (Long) session
				.getAttribute("countGlblEleCrosswalkSearchResults");
		if ((countGlblEleCrosswalkSearchResults == null)
				|| (globalElementCrosswalkSearchCriteria.getRowIndex() == 0)) {
			countGlblEleCrosswalkSearchResults = wsProxy
					.countSearchByCrosswlkBkp(globalElementCrosswalkSearchCriteria);
			session.setAttribute("countGlblEleCrosswalkSearchResults",
					countGlblEleCrosswalkSearchResults);
		}
		Map<String, Object> map = null;
		try {
			map = homeController.getJsonMap(request, wsProxy
					.searchByCrosswalk(globalElementCrosswalkSearchCriteria),
					countGlblEleCrosswalkSearchResults, searchColumnsCrosswalk);
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.info("GlobalElementController | getGlblEleSearchAjaxResults | returned after searchByTopics");
		LOGGER.info("exiting GlobalElementController | getGlblEleSearchAjaxResults");
		return map;
	}
	

	private GlobalElementCrosswalkSearchVOBkp getGlobalElementCrosswalkSearchCriteria(
			HttpServletRequest request) {
		LOGGER.info("entering GlobalElementController | getGlobalElementSearchCriteria");
		GlobalElementCrosswalkSearchVOBkp globalElementSearchCriteria = new GlobalElementCrosswalkSearchVOBkp();
		globalElementSearchCriteria.setSortOrder(homeController.getSortOrder(request));
		globalElementSearchCriteria.setSortBy(homeController.getSortBy(request,searchColumnsCrosswalk));
		globalElementSearchCriteria.setMaxResults(homeController.getMaxResults(request));
		globalElementSearchCriteria.setRowIndex(homeController.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);
		// Search string will be in the format
		// code#~text#~desc#~code#~text
		String searchCriteriaDelimiter = "~";
		if (compositeSearchString != null) {
			String[] splitCriteria = compositeSearchString
					.split(searchCriteriaDelimiter);
			if (splitCriteria.length > 0) {
				if (!(splitCriteria[0].replace("#", "").trim().isEmpty())) {
					globalElementSearchCriteria.setGlobalElementId(Long
							.valueOf(splitCriteria[0].replace("#", "").trim()));
				}
			}
			if (splitCriteria.length > 1) {
				if (!(splitCriteria[1].replace("#", "").trim().isEmpty())) {
					globalElementSearchCriteria
							.setGlobalElementPlatformCode(Long
									.valueOf(splitCriteria[1].replace("#", "")
											.trim()));
				}
			}
			if (splitCriteria.length > 2) {
				if (!(splitCriteria[2].replace("#", "").trim().isEmpty())) {
					globalElementSearchCriteria
							.setGlobalElementMetadataValue(String
									.valueOf(splitCriteria[2].replace("#", "")
											.trim()));
				}
			}
			if (splitCriteria.length > 3) {
				if (!(splitCriteria[3].replace("#", "").trim().isEmpty())) {
					globalElementSearchCriteria
							.setGlobalElementMetadataCode(Long
									.valueOf(splitCriteria[3].replace("#", "")
											.trim()));
				}
			}
			
		}
		LOGGER.info("GlobalElementController | getGlobalElementSearchCriteria | globalElementSearchCriteria : "
				+ globalElementSearchCriteria);
		LOGGER.info("exiting GlobalElementController | getGlobalElementSearchCriteria");
		return globalElementSearchCriteria;
	}
	/**
	 * Loads the Global Element Financial search page.
	 * <p>
	 * 	 
	 * <p>
	 * 
	 * @param model
	 * @param session
	 * @return FinancialSearch, the ModelAndView object
	 */
	
	
	@RequestMapping(value = "/glblEleSearchCrosswalk.form", method = RequestMethod.GET)
	public ModelAndView SearchCrossWalk(Model model, HttpSession session,Boolean updateCroswalkSuccess) {
	LOGGER.info("entering GlobalElementController | SearchCrossWalk");
	ModelAndView searchCrosswalk = new ModelAndView("searchCrosswalk");
	List<Integer> codeTableIds = new ArrayList<Integer>();
	codeTableIds.add(729);
	codeTableIds.add(726);
	Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
	searchCrosswalk.addObject("crosswalkApplied",
	tempCodeValueMap.get(String.valueOf(729)));
	 
	searchCrosswalk.addObject("searchCrossWlkElementType",
	tempCodeValueMap.get(String.valueOf(726)));
	searchCrosswalk.addObject("updateCroswalkSuccess",updateCroswalkSuccess);
	GloblalElementCrossWalk glblEleSearchCrosswlk = new GloblalElementCrossWalk();
	model.addAttribute("searchCrosswalk",glblEleSearchCrosswlk);
	
	LOGGER.info("exiting GlobalElementController | SearchCrossWalk");
	return searchCrosswalk;
	}

	@RequestMapping(value = "/editGlblEleCrosswalk.form", method = RequestMethod.GET)
	public ModelAndView EditCrossWalkHypLink(@RequestParam("crosswalkId") final Long crosswalkId,@RequestParam("elementID") final Long elementID,Model model, HttpSession session) {
		LOGGER.info("entering GlobalElementController | EditCrossWalk");
		ModelAndView editCrossWalk = new ModelAndView("editCrosswalk");
		AddCrosswalkVO glblEleCrosswlk = new AddCrosswalkVO();
		glblEleCrosswlk.setGlobalElementCrosswalkId(crosswalkId);
		glblEleCrosswlk.setGlobalElementId(elementID);
		//to retrieve details from Global Element table
		AddCrosswalkVO addGlobalElementCrosswalkVO = wsProxy.retrieveGlobalElementCrosswalk(glblEleCrosswlk);
		
		glblEleCrosswlk.setGloblalElementCrossWalk(addGlobalElementCrosswalkVO.getGloblalElementCrossWalk());
		
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(729);// Data PlatForm
		
		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
		
		glblEleCrosswlk.setGlobalElementPlatformCode(addGlobalElementCrosswalkVO.getGlobalElementPlatformCode());
		
		List<AddCrosswalkVO> metadataList = retrieveCwlkPlatformDetails(glblEleCrosswlk.getGlobalElementPlatformCode());	
		
		editCrossWalk.addObject("crosswalkId",glblEleCrosswlk.getGlobalElementCrosswalkId());
		editCrossWalk.addObject("dataPlatform",tempCodeValueMap.get(String.valueOf(729)));		
		editCrossWalk.addObject("metadataList",metadataList);
		editCrossWalk.addObject("elementID",glblEleCrosswlk.getGlobalElementId());	
		model.addAttribute("editCrosswalk",glblEleCrosswlk);	
		LOGGER.info("exiting GlobalElementController | EditCrossWalk");
		return editCrossWalk;
		
	}
	
	List<AddCrosswalkVO> retrieveCwlkPlatformDetails (Long globalElementPlatformCode) {
		LOGGER.info("entering GlobalElementController | retrievePlatformDetails");		
		List<AddCrosswalkVO> addCrosswalkVO =  wsProxy.retrievePlatformDetails(globalElementPlatformCode);	
		LOGGER.info("exiting GlobalElementController | retrievePlatformDetails");
		return addCrosswalkVO;
	}
	

	@RequestMapping(value = "retrieveCrosswalkDetails.form", method = RequestMethod.GET)
	public @ResponseBody
	List<AddCrosswalkVO> retrieveEditPlatformDetails (@RequestParam("globalElementPlatformCode") Long globalElementPlatformCode,
			@RequestParam("globalElementId") Long globalElementId,HttpSession session) {
		LOGGER.info("entering GlobalElementController | retrieveEditPlatformDetails");	
		
		List<AddCrosswalkVO> addCrosswalkVO =  wsProxy.retrieveEditPlatformDetails(globalElementPlatformCode,globalElementId);
		
	
		
		LOGGER.info("exiting GlobalElementController | retrieveEditPlatformDetails");
		return addCrosswalkVO;
	}	
	
	@RequestMapping(value = "/editCrosswalk.form", method = RequestMethod.POST)
	public ModelAndView SubmitEditAddCrosswalk(
			@ModelAttribute("editCrosswalk") AddCrosswalkVO addCrosswalkVO,
			Model model, HttpSession session,Boolean updateCroswalkSuccess) {
		LOGGER.info("entering ScoreController | ScoreMappingHome");

		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();

		populateNewCwlkMandatoryFields(addCrosswalkVO, loggedInUser);
				
		Long crosswalkId = wsProxy.addNewCrosswalk(addCrosswalkVO);

		LOGGER.info("GlobalElementController | SubmitAddCrosswalk | updating NewScoreTypeCode : "
				+ crosswalkId);
		updateCroswalkSuccess = true;
		LOGGER.info("exiting ScoreController | ScoreMappingHome");
		
		return SearchCrossWalk(model,session,updateCroswalkSuccess);
	}
	
	
	@RequestMapping(value = "/glblEleDashborad.form", method = RequestMethod.GET)
	public ModelAndView Dashboard(HttpSession session) {
		
		LOGGER.info("entering GlobalElementController | getAllSearch");
		ModelAndView dashborad = new ModelAndView("glblEleDashborad");		
		GloblalElementCrossWalk unMappedCount = new GloblalElementCrossWalk();
		
		
			
		List<GloblalElementCrossWalk> platformList = wsProxy.retrievePlatformList();
		
		List<GlobalElement> unMappedElements = wsProxy.retrieveUnMappedElementCount();
		
		Long unMappedElementCount = wsProxy.totalUnMappedElementCount(unMappedCount);
		
		
		LOGGER.info("GlobalElementController | Dashboard | unMappedElementCount : "
				+ unMappedElementCount);
		
		LOGGER.info("GlobalElementController | Dashboard | platformList : "
				+ platformList);
		
		dashborad.addObject("platformList", platformList);
		dashborad.addObject("unMappedElementCount",unMappedElementCount);	
		dashborad.addObject("unMappedElements",unMappedElements);
		

		
		LOGGER.info("exiting GlobalElementController | Dashboard");
		return dashborad;
	}
	
	@RequestMapping(value = "/allCrosswalkSearchExportToExcelResultsBkp.form", method = RequestMethod.GET)
	public @ResponseBody
	void getCrosswalkSearchExportToExcelResultsBkp(HttpServletRequest request,
			HttpSession session, HttpServletResponse response) {
		LOGGER.info("entering GlobalElementController | getAllSearchExportToExcelResults");
		GlobalElementCrosswalkSearchVOBkp globalElementCrosswalkSearchCriteria  = getGlobalElementCrosswalkSearchCriteria(request);
		globalElementCrosswalkSearchCriteria.setViewType(request.getParameter("type"));
		 
		GlobalElementCrosswalkExport globalElementExport = null; 
		globalElementExport = new GlobalElementCrosswalkExport("");
		
		try {
			globalElementExport.insertCrosswalkSearchData(wsProxy.searchByCrosswalk(globalElementCrosswalkSearchCriteria));
			
		} catch (Exception e) {
			LOGGER.error("problem in GlobalElementController |getAllSearchExportToExcelResults", e);
		}
		UserContextVO userContextVO = (UserContextVO) session
		.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserFirstName();
		String dateAppend = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date());
		response.setContentType("application/xlsx");
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ "GlobalCrosswalkElement_" + loggedInUser + "_"
				+ dateAppend + ".xlsx" + "\"");
		try {
			globalElementExport.write(response.getOutputStream());
		} catch (IOException e) {
			LOGGER.error("problem in GlobalElementController |getAllSearchExportToExcelResults",e);
		}catch (Exception e) {
			LOGGER.error("problem in GlobalElementController |getAllSearchExportToExcelResults",e);
		}

	}
	
	// to check if Element ID exists in Element table and CrossWalk Table
	@RequestMapping(value = "checkGroupName.form", method = RequestMethod.GET)
	public @ResponseBody
	String checkGroupName(@RequestParam("globalElementCrosswalkGrpNme") String globalElementCrosswalkGrpNme,HttpSession session) {
		LOGGER.info("entering checkGroupName | checkGroupName");
		// audit variables
		
		String result = null;	
		//String glblEleName = wsProxy.retrieveGlobalElement(globalElementCrosswalkGrpNme);
		Long countExisingGroupName = wsProxy.retrieveGroupName(globalElementCrosswalkGrpNme);
				
		if(countExisingGroupName>0){
			result = "false";
		}		
		LOGGER.info("exiting GlobalElementController | checkGlobalElementID");
		return result;
	}

	@RequestMapping(value = "checkGroupNameUnique.form", method = RequestMethod.POST)
    public @ResponseBody
    Boolean checkGroupName(@RequestParam("globalElementCrosswalkGrpNme") String globalElementCrosswalkGrpNme,@RequestParam("globalElementId") Long globalElementId,HttpSession session) {
          LOGGER.info("entering checkGroupName | checkGroupName");
          // audit variables
          Boolean result = true;   
          System.out.println("globalElementCrosswalkGrpNme"+globalElementCrosswalkGrpNme+"globalElementId"+globalElementId);          

         
         Long countExisingGroupName = wsProxy.retrieveGroupName(globalElementCrosswalkGrpNme,globalElementId);
                      
          if(countExisingGroupName>0){
                result = false;
          }          
          LOGGER.info("exiting GlobalElementController | checkGroupName ");
          return result;
    }


}
