/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.proxy;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.entity.GeoCurrency;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.AddGeoCurrencyVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.CurrencySearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.GeoCurrencySearchVO;
import com.dnb.dsc.refdata.web.util.RestWebServiceUtil;

/**
 * The web service proxy class will handle the mapping between the UI web
 * requests and the respective service end point class. The class will construct
 * the REST WS requests and exchange the request with the service end point for
 * the response.
 * <p>
 * 
 * The web service proxy class will handle all the service requests within the
 * Currency Exchange domain.
 * <p>
 * 
 * @author Cognizant
 * @version last updated : Mar 01, 2012
 * @see
 * 
 */
@Component
public class CurrencyExchangeWebServiceProxy {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CurrencyExchangeWebServiceProxy.class);

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private RestWebServiceUtil restWSUtil;
	
	@Autowired
	private RefDataConfigUtil refDataConfigUtil; 

	/**
	 * 
	 * Retrieves the Currency Exchange search Results.
	 * <p>
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param currencySearchCriteria
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<CurrencyExchange> searchCurrencyExchange(
			CurrencySearchCriteriaVO currencySearchCriteria) {
		LOGGER.info("entering CurrencyExchangeWebServiceProxy | searchCurrencyExchange");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/searchCurrencyExchange.service";
		HttpEntity<CurrencySearchCriteriaVO> entity = new HttpEntity<CurrencySearchCriteriaVO>(
				currencySearchCriteria);
		List<CurrencyExchange> result = null;
			result = (List<CurrencyExchange>) this.restTemplate.postForObject(
					serviceURL, entity, List.class, new Object[0]);
		LOGGER.info("exiting CurrencyExchangeWebServiceProxy | searchCurrencyExchange");
		return result;
	}

	/**
	 * The method to retrieve all data providers for the currency exchange data.
	 * The data will be fetched from the currency exchange tables.
	 * 
	 * @param languageCode
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveCurcyExchDataProviders(Long languageCode) {
		LOGGER.info("entering CurrencyExchangeWebServiceProxy | retrieveCurcyExchDataProviders");
		String serviceURL = "/{languageCode}/retrieveCurcyExchDataProviders.service";

		return restWSUtil.exchangeForList(CodeValueVO.class, serviceURL, languageCode);
	}

	/**
	 * 
	 * The method will count the records in the hierarchy search of currency
	 * units on the search db. The search will be done on the flat db based on
	 * the search criteria the user had provided.
	 * 
	 * @param currencySearchCriteriaVO
	 * @return countResults
	 */
	public Long countSearchCurrencyExchange(
			CurrencySearchCriteriaVO currencySearchCriteriaVO) {
		LOGGER.info("entering CurrencyExchangeWebServiceProxy | countSearchCurrencyExchange");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/countSearchCurrencyExchange.service";
		HttpEntity<CurrencySearchCriteriaVO> entity = new HttpEntity<CurrencySearchCriteriaVO>(
				currencySearchCriteriaVO);
		Long result = null;
		result = (Long) this.restTemplate.postForObject(serviceURL, entity,
					Long.class, new Object[0]);
		LOGGER.info("exiting CurrencyExchangeWebServiceProxy | countSearchCurrencyExchange");
		return result;
	}

	/**
	 * The method will persist the existing Currency Exchange data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param currencyExchange
	 */
	public Long updateExchangeRate(CurrencyExchange currencyExchange) {
		LOGGER.info("entering CurrencyExchangeWebServiceProxy | updateExchangeRate");

		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/updateExchangeRate.service";
		HttpEntity<CurrencyExchange> entity = new HttpEntity<CurrencyExchange>(
				currencyExchange);
		Long result = restTemplate.postForObject(serviceURL, entity, Long.class);
		LOGGER.info("exiting CurrencyExchangeWebServiceProxy | updateExchangeRate");
		return result;
	}
	/**
	 * 
	 * The method will validate the Currency Exchange for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param currencyExchangeId
	 * @return
	 */
	public String lockCurrencyExchange(Long currencyExchangeId) {
		LOGGER.info("entering CurrencyExchangeWebServiceProxy | lockCurrencyExchange");

		HttpEntity<String> entity = new HttpEntity<String>(
				restWSUtil.constructRequestHeader());
		String serviceURL =refDataConfigUtil.getServiceDeployURL() + "/{currencyExchangeId}/lockCurrencyExchange.service";
		ResponseEntity<String> result = this.restTemplate.exchange(serviceURL, HttpMethod.GET,
					entity, String.class, new Object[] { currencyExchangeId });
		LOGGER.info("exiting CurrencyExchangeWebServiceProxy | lockCurrencyExchange");
		return result != null ? (String) result.getBody() : null;
	}

    /**
	 * Invoked  when the the business owner reviews the
	 * changes submitted for his approval. The user reviews the changes and he
	 * could approve or reject the request.<p>
	 * 
	 * @param trackingId
	 * @return a Map of CurrencyExchange
	 */
	public CurrencyExchange reviewCurrencyExchangeChanges(Long trackingId) {
		LOGGER.info("entering CurrencyExchangeWebServiceProxy | reviewCurrencyExchangeChanges");

		HttpEntity<CurrencyExchange> entity = new HttpEntity<CurrencyExchange>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{trackingId}/reviewCurrencyExchangeChanges.service";
		ResponseEntity<CurrencyExchange> result = null;
		result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
					CurrencyExchange.class, trackingId);
		LOGGER.info("exiting CurrencyExchangeWebServiceProxy | reviewCurrencyExchangeChanges");
		return result != null ? result.getBody() : null;
	}

		/**
		 * 
		 * The method will count the records in the geo currency table based on
		 * user inputs in db. The search will be done on the SOR db based on
		 * the search criteria the user had provided.
		 * 
		 * @param geoCurrencySearchCriteria
		 * @return countResults
		 */
		public Long countSearchGeoCrcy(
				GeoCurrencySearchVO geoCurrencySearchCriteria) {
			LOGGER.info("entering CurrencyExchangeWebServiceProxy | countSearchGeoCrcy");

			String serviceURL = refDataConfigUtil.getServiceDeployURL()
					+ "/countSearchGeoCurrency.service";
			HttpEntity<GeoCurrencySearchVO> entity = new HttpEntity<GeoCurrencySearchVO>(
					geoCurrencySearchCriteria);
			Long result = null;
			result = (Long) this.restTemplate.postForObject(serviceURL, entity,
						Long.class, new Object[0]);
			LOGGER.info("exiting CurrencyExchangeWebServiceProxy | countSearchGeoCrcy");
			return result;
		}

		/**
		 * 
		 * Retrieves the Geo Currency search Results.
		 * <p>
		 * The search will be done on the SOR db based on the search criteria the
		 * user had provided.
		 * <p>
		 * 
		 * @param geoCurrencySearchCriteria
		 * @param result
		 * @param model
		 * @param sessionStatus
		 * @return
		 */
		@SuppressWarnings("unchecked")
		public List<GeoCurrency> searchGeoCrcy(
				GeoCurrencySearchVO geoCurrencySearchCriteria) {
			LOGGER.info("entering CurrencyExchangeWebServiceProxy | searchCurrencyExchange");

			String serviceURL = refDataConfigUtil.getServiceDeployURL()
					+ "/searchGeoCurrency.service";
			HttpEntity<GeoCurrencySearchVO> entity = new HttpEntity<GeoCurrencySearchVO>(
					geoCurrencySearchCriteria);
			List<GeoCurrency> result = null;
				result = (List<GeoCurrency>) this.restTemplate.postForObject(
						serviceURL, entity, List.class, new Object[0]);
			LOGGER.info("exiting CurrencyExchangeWebServiceProxy | searchCurrencyExchange");
			return result;
		}

		/**
		 * @param addGeoCurrencyVO
		 * @return
		 */
		public Long insertGeoCurrency(AddGeoCurrencyVO addGeoCurrencyVO) {
			LOGGER.info("entering CurrencyExchangeWebServiceProxy | insertGeoCurrency");

			String serviceURL = refDataConfigUtil.getServiceDeployURL()
					+ "/insertGeoCurrency.service";
			HttpEntity<AddGeoCurrencyVO> entity = new HttpEntity<AddGeoCurrencyVO>(
					addGeoCurrencyVO);
			LOGGER.info("exiting CurrencyExchangeWebServiceProxy | insertGeoCurrency");
			Long result = (Long) restTemplate.postForObject(serviceURL, entity,
					Long.class, new Object[0]);
			return result;
		}
		
		
		
		/**
		 * @param geoCurrencyId
		 * @return
		 */
		public GeoCurrency reviewGeoCurrency(Long geoCurrencyId) {
			LOGGER.info("entering CurrencyExchangeWebServiceProxy | reviewGeoCurrency");

			HttpEntity<GeoCurrency> entity = new HttpEntity<GeoCurrency>(
					restWSUtil.constructRequestHeader());
			String serviceURL = refDataConfigUtil.getServiceDeployURL()
					+ "/{geoCurrencyId}/reviewGeoCurrency.service";
			ResponseEntity<GeoCurrency> result = null;
			result = restTemplate.exchange(serviceURL, HttpMethod.GET, entity,
					GeoCurrency.class, geoCurrencyId);
			LOGGER.info("exiting CurrencyExchangeWebServiceProxy | reviewGeoCurrency");
			return result != null ? result.getBody() : null;
		}
	
		            /*Added for Currency Enhancement*/
		/**
		 * @param geoCurrency
		 * @return
		 */
		public Long updateGeoCurrency(GeoCurrency geoCurrency) {
			LOGGER.info("entering CurrencyExchangeWebServiceProxy | updateGeoCurrency");

			String serviceURL = refDataConfigUtil.getServiceDeployURL()
					+ "/updateGeoCurrency.service";
			HttpEntity<GeoCurrency> entity = new HttpEntity<GeoCurrency>(
					geoCurrency);
			LOGGER.info("exiting CurrencyExchangeWebServiceProxy | updateGeoCurrency");
			Long result = (Long) restTemplate.postForObject(serviceURL, entity,
					Long.class, new Object[0]);
			return result;
		}
		
}
