/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.controller;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.entity.GeoCurrency;
import com.dnb.dsc.refdata.core.interceptor.TransactionLogger;
import com.dnb.dsc.refdata.core.util.CommonUtil;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.AddGeoCurrencyVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.CurrencySearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.CurrencyUploadItemVO;
import com.dnb.dsc.refdata.core.vo.GeoCurrencySearchVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.web.proxy.CurrencyExchangeWebServiceProxy;
import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;
import com.dnb.dsc.refdata.web.util.GeoCurrencyExportToExcel;
import com.dnb.dsc.refdata.web.util.UserRoleMapper;

/**
 * The Controller class for Currency Exchange Domain. The methods in the class
 * will be mapped as per the UI requests. The UI front controller will redirect
 * to the respective methods based on the request and the request parameters.
 * 
 * @author Cognizant
 * @version last updated : Feb 29, 2012
 * @see
 * 
 */
@Controller
@SessionAttributes("currencyExchangeForView")
public class CurrencyController {

	@Autowired
	private HomeController homeController;
	
	@Autowired
	private GeographyWebServiceProxy geoProxy;

	@Autowired
	private CurrencyExchangeWebServiceProxy wsProxy;
	
	@Autowired
	private UserRoleMapper roleMapper;
	
	@Autowired
	private RefDataConfigUtil refdataConfig;
	
	@Autowired
	private TransactionLogger transactionLogger;
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CurrencyController.class);

	private final String[] currencySearchColumns = {
					"fromCurrencyShortDescription", "toCurrencyShortDescription",
			"currencyExchangeDate", "currencyExchangeRate", "dataProvider",
			"fromCurrencyFullDescription", "toCurrencyFullDescription",
			"currencyExchangeId" };
	
	private final String[] geoCrcySearchColumns = { "geoCurrencyId","geoUnitId","countryName",
			"currencyCode", 
			"currencyCodeDescription","effectiveDate","endDate"};
	
	
	/**
	 * 
	 * Loads the Currency Exchange search home page.
	 * <p>
	 * 
	 * Retrieves all currency Exchange information to be populated in the
	 * screen.
	 * <p>
	 * 
	 * @param model
	 * @return currencyExchange, the ModelAndView
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/currencySearchHome.form", method = RequestMethod.GET)
	public ModelAndView getCurrencySearchHome(HttpSession session) {
		LOGGER.info("entering CurrencyController | getCurrencySearchHome");
		ModelAndView currencySearchHome = new ModelAndView("currencyExchange");

		// Retrieving the Lists for currency Code and Data Provider
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_CURRENCY);

		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValues(codeTableIds);
		currencySearchHome
				.addObject(
						"currencyCodeValues",
						tempCodeValueMap.get(String
								.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_CURRENCY)));
		
		List curcyExchDataProviders = wsProxy
				.retrieveCurcyExchDataProviders(RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		
		currencySearchHome.addObject("dataProviderCodeValues",
				curcyExchDataProviders);
		
		session.setAttribute("currencyCodeValues", tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_CURRENCY)));
		session.setAttribute("dataProviderCodeValues", curcyExchDataProviders);

		LOGGER.info("exiting CurrencyController | getCurrencySearchHome");
		return currencySearchHome;
	}

	/**
	 * 
	 * Retrieves the Currency search details.
	 * <p>
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param currencySearchCriteria
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @return
	 */
	@RequestMapping(value = "/currencySearchAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getCurrencySearchAjaxResults(
			HttpServletRequest request, HttpSession session) {
		LOGGER.info("entering CurrencyController | getCurrencySearchAjaxResults");
		Date startTime = new Date();
		
		CurrencySearchCriteriaVO currencySearchCriteria = getCurrencySearchCriteria(request);
		if ((currencySearchCriteria.getFromDate() != null && !(currencySearchCriteria.getFromDate().equals(currencySearchCriteria.getToDate())))
				&&((currencySearchCriteria.getFromCurrencyCode() == null && currencySearchCriteria
				.getToCurrencyCode() == null)
				|| ((currencySearchCriteria.getFromCurrencyCode() != null && currencySearchCriteria
						.getFromCurrencyCode().trim().isEmpty()) && (currencySearchCriteria
						.getToCurrencyCode() != null && currencySearchCriteria
						.getToCurrencyCode().trim().isEmpty())))) {
			return homeController.getJsonMap(request, new ArrayList<Object>(),
					0L, currencySearchColumns);
		}
		
		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		Long countCurrencyResults = (Long) session
				.getAttribute("countCurrencyResults");
		if ((countCurrencyResults == null)
				|| (currencySearchCriteria.getRowIndex() == 0)) {
			countCurrencyResults = wsProxy
					.countSearchCurrencyExchange(currencySearchCriteria);
			session.setAttribute("countCurrencyResults", countCurrencyResults);
		}

		List<CurrencyExchange> currencySearchList = wsProxy
				.searchCurrencyExchange(currencySearchCriteria);
		session.setAttribute("currencySearchList", currencySearchList);
		
		// transaction logging
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
				"getCurrencySearchResults", 0L, currencySearchCriteria, 0L);
		
		LOGGER.info("exiting CurrencyController | getCurrencySearchAjaxResults");
		return homeController.getJsonMap(request, currencySearchList,
				countCurrencyResults, currencySearchColumns);
	}
	
	/**
	 * 
	 * The method will construct the currencySearchCriteria
	 *
	 * @param request
	 * @return currencySearchCriteria
	 */
	private CurrencySearchCriteriaVO getCurrencySearchCriteria(
			HttpServletRequest request) {
		CurrencySearchCriteriaVO currencySearchCriteria = new CurrencySearchCriteriaVO();
		currencySearchCriteria.setSortOrder(homeController
				.getSortOrder(request));
		currencySearchCriteria.setSortBy(homeController.getSortBy(request,
				currencySearchColumns));
		currencySearchCriteria.setMaxResults(homeController
				.getMaxResults(request));
		currencySearchCriteria.setRowIndex(homeController
				.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);
		// Search string will be in the format
		// USD#~AUD#~12/15/2004#~12/15/2004#~Financial Times
		String searchCriteriaDelimiter = "~";
		if(compositeSearchString != null){
			String[] splitCriteria = compositeSearchString
					.split(searchCriteriaDelimiter);
			if(splitCriteria.length > 0){
				if(!(splitCriteria[0].replace("#", "").trim().isEmpty())){
					currencySearchCriteria.setFromCurrencyCode(splitCriteria[0]
							.replace("#", "").trim());
				}
			}
			if(splitCriteria.length > 1){
				if(!(splitCriteria[1].replace("#", "").trim().isEmpty())){
					currencySearchCriteria.setToCurrencyCode(splitCriteria[1]
							.replace("#", "").trim());
				}
			}
			if(splitCriteria.length > 2){
				if(!(splitCriteria[2].replace("#", "").trim().isEmpty())){
					currencySearchCriteria
							.setFromDate(getDateForString(splitCriteria[2]
									.replace("#", "").trim()));
				}
			}
			if(splitCriteria.length > 3){
				if(!(splitCriteria[3].replace("#", "").trim().isEmpty())){
					currencySearchCriteria
							.setToDate(getDateForString(splitCriteria[3]
							.replace("#", "").trim()));
				}
			}
			if(splitCriteria.length > 4){
				if(!(splitCriteria[4].replace("#", "").trim().isEmpty())){
					currencySearchCriteria
							.setDataProviderCode((splitCriteria[4].replace("#",
									"").trim()));
				}
			}
		}
		return currencySearchCriteria;
	}

	private Date getDateForString(String inputStr) {
		if (inputStr == null) {
			return null;
		}
		DateFormat formatter = new SimpleDateFormat(
				RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT);
		try {
			return (Date) formatter.parse(inputStr);
		} catch (ParseException e) {
			return null;
		}
	}
	
	/**
	 * Retrieves the CurrencyExchange Entity corresponds to the
	 * currencyExchangeId returned from the CurrencyExchange search page.
	 * <p>
	 * 
	 * The entity returned will be used to show the Currency Exchange details in
	 * the Currency View page.
	 * <p>
	 * 
	 * @param currencyExchangeId
	 * @param model
	 * @param session
	 * @param sessionStatus
	 * @return currencyExchangeView, the ModelAndView
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/currencyExchangeView.form", method = RequestMethod.GET)
	public ModelAndView viewCurrencyExchange(
			@RequestParam(RefDataUIConstants.CURRENCY_EXCHANGE_ID_REQ_PARAM) final String currencyExchangeId,
			@RequestParam("taskId") final String taskId, Model model,
			HttpSession session, SessionStatus sessionStatus) {
		LOGGER.info("entering CurrencyController | viewCurrencyExchange");

		ModelAndView currencyExchangeView = new ModelAndView("currencyView");
		CurrencyExchange currencyExchange = new CurrencyExchange();
		// Retrieving the Lists for Date Precision Code
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_DATA_PRECISION);

		if (null == session.getAttribute(RefDataUIConstants.CURRENCY_VIEW_DATE_PRECISION_CODE_SESSION)) {
			Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
			session.setAttribute(RefDataUIConstants.CURRENCY_VIEW_DATE_PRECISION_CODE_SESSION,
					tempCodeValueMap.get(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_DATA_PRECISION)));
		}
		List<CurrencyExchange> currencySearchList = (List<CurrencyExchange>) session.getAttribute("currencySearchList");
		session.removeAttribute("currencySearchList");
		// Iterate the list and gets the Currency Exchange Entity.
		
		if (currencySearchList != null) {
			Iterator itr = currencySearchList.iterator();
			while (itr.hasNext()) {
				LinkedHashMap linkedHashMap = (LinkedHashMap) itr.next();
				String curcyExchangeIdDb = String.valueOf(linkedHashMap.get("currencyExchangeId"));
				if (currencyExchangeId.equals(curcyExchangeIdDb)) {
					currencyExchange = populateCurrencyExchange(linkedHashMap);
					break;
				}
			}
		} else {
			currencyExchange = wsProxy.reviewCurrencyExchangeChanges(Long.valueOf(currencyExchangeId));
		}
		
		model.addAttribute("currencyExchangeForView", currencyExchange);
		LOGGER.info("CurrencyExchange for View : " + currencyExchangeId + "\n\n");
		session.setAttribute("taskId", taskId);
		LOGGER.info("exiting CurrencyController | viewCurrencyExchange");
		return currencyExchangeView;
	}

	/**
	 * 
	 * The method to populate the currencyExchange from the linked hash map
	 * returned by the web service
	 * 
	 * @param linkedHashMap
	 * @return currencyExchange
	 */
	@SuppressWarnings("rawtypes")
	private CurrencyExchange populateCurrencyExchange(LinkedHashMap linkedHashMap) {
		CurrencyExchange currencyExchange = new CurrencyExchange();
		currencyExchange.setCurrencyExchangeId(
				Long.valueOf((Integer)linkedHashMap.get("currencyExchangeId")));
		currencyExchange.setFromCurrencyCode(
				Long.valueOf((Integer) linkedHashMap.get("fromCurrencyCode")));
		currencyExchange.setToCurrencyCode(
				Long.valueOf((Integer) linkedHashMap.get("toCurrencyCode")));
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		try {

			Object createdDateObj = (Object) linkedHashMap.get("createdDate");
			if (createdDateObj instanceof Long) {
				currencyExchange.setCreatedDate(((Long) linkedHashMap
						.get("createdDate")) != null ? new Date(
						(Long) linkedHashMap.get("createdDate")) : null);
			} else if (createdDateObj instanceof String) {
				currencyExchange.setCreatedDate(((String) linkedHashMap
						.get("createdDate")) != null ? df
						.parse((String) linkedHashMap.get("createdDate")) : null);
			}

			Object modifiedDateObj = (Object) linkedHashMap.get("modifiedDate");
			if (modifiedDateObj instanceof Long) {
				currencyExchange.setModifiedDate(((Long) linkedHashMap
						.get("modifiedDate")) != null ? new Date(
						(Long) linkedHashMap.get("modifiedDate")) : null);
			} else if (modifiedDateObj instanceof String) {
				currencyExchange.setModifiedDate(((String) linkedHashMap
						.get("modifiedDate")) != null ? df
						.parse((String) linkedHashMap.get("modifiedDate")) : null);
			}
			currencyExchange.setCurrencyExchangeDate(new Date(
					(Long) linkedHashMap.get("currencyExchangeDate")));
		} catch (ParseException e) {
			LOGGER.error("Parse Exception occurred : ", e);
		}
		currencyExchange.setModifiedUser(
				(String) linkedHashMap.get("modifiedUser"));
		currencyExchange.setCreatedUser(
				(String) linkedHashMap.get("createdUser"));
		currencyExchange.setCurrencyExchangeDatePrcnCode(
				Long.valueOf((Integer) linkedHashMap.get("currencyExchangeDatePrcnCode")));
		currencyExchange.setCurrencyExchangeRate(
				(Double) linkedHashMap.get("currencyExchangeRate"));
		currencyExchange.setDataProviderCode(
				Long.valueOf((Integer) linkedHashMap.get("dataProviderCode")));
		currencyExchange.setFromCurrencyShortDescription(
				(String) linkedHashMap.get("fromCurrencyShortDescription"));
		currencyExchange.setFromCurrencyFullDescription(
				(String) linkedHashMap.get("fromCurrencyFullDescription"));
		currencyExchange.setToCurrencyShortDescription(
				(String) linkedHashMap.get("toCurrencyShortDescription"));
		currencyExchange.setToCurrencyFullDescription(
				(String) linkedHashMap.get("toCurrencyFullDescription"));
		
		return currencyExchange;
	}
	
	/**
	 * The method will persist the exchange rate in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param currencyExchange
	 *            model attribute
	 * @return View
	 * @throws ParseException 
	 */
	@RequestMapping(value = "/updateExchangeRate.form", method = RequestMethod.POST)
	public View exchangeRateUpdate(
			@ModelAttribute("currencyExchangeForView") CurrencyExchange currencyExchange,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session) throws ParseException {
		LOGGER.info("entering CurrencyController | exchangeRateUpdate | "
				+ currencyExchange);
		//audit variables
		Date startTime = new Date();
		
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		currencyExchange.setModifiedUser(CommonUtil.truncate(userContextVO.getUserIdentifier(),
				RefDataPropertiesConstants.USER_EMAIL_ADDRESS_MAX_LENGTH));
		currencyExchange.setModifiedDate(new Date());
		Long currencyExchangeId = wsProxy.updateExchangeRate(currencyExchange);
		String taskId = (String) session.getAttribute("taskId");
		if ((taskId != null) && !taskId.trim().isEmpty()) {
			homeController
					.reSubmitTaskRequest(
							userContextVO,
							taskId,
							RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
							roleMapper
									.getSubmitterUserGroupId(
											RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
											0L));
		} else {
		// Invoke the WorkFlow service to create the workFlow task for the
		// update operation. This will be invoked as a web service call.
		createNewCurrencyWorkflowTask(
				currencyExchange,
				RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_CURRENCY_EXCHANGE,
				(UserContextVO) session
						.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT));
		}
		sessionStatus.setComplete();
 
		// transaction logging
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
				"getCurrencySearchResults", 0L, currencyExchangeId, 0L, currencyExchange);

		LOGGER.info("exiting CurrencyController | exchangeRateUpdate");
		return new RedirectView("submitterWorkQueueHome.form?domainName=Currency Exchange");
	}

	/**
	 * 
	 * The method will validate the Currency Exchange for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param currencyExchange
	 * @return boolean
	 */
	@RequestMapping(value = "lockExchangeRateForEdit.form", method = RequestMethod.GET)
	public @ResponseBody
	String lockExchangeRate(
			@ModelAttribute("currencyExchangeForView") CurrencyExchange currencyExchange,
			HttpSession session) {

		LOGGER.info("entering CurrencyController | lockExchangeRate");
		if (((String) session.getAttribute("taskId") != null) &&
				((String) session.getAttribute("taskId")).length() > 0) {
					return "false";
				} else {
			Long lockCurrencyExchangeId = currencyExchange
					.getCurrencyExchangeId();
		return this.wsProxy.lockCurrencyExchange(lockCurrencyExchangeId);
		}

	}
	
	/**
	 * 
	 * The method to create new task with work-flow.
	 *
	 * @param crcyExchangeId
	 * @param requestType
	 * @param userContextVO
	 */
	private void createNewCurrencyWorkflowTask(
			CurrencyExchange currencyExchange,
			String requestType, 
			UserContextVO userContextVO) {
		
		Long submitterGroupId = roleMapper.getSubmitterUserGroupId(
				RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE, 
				getCurrencyCountry(currencyExchange));	
		
		Long approverGroupId = roleMapper.getApproverUserGroupId(submitterGroupId);
		
		LOGGER.info("params for createNewCurrencyWorkflowTask : " + 
				currencyExchange + " : " + 
				requestType + " : " + 
				userContextVO + " : " + 
				approverGroupId	+ " : " + 
				submitterGroupId);
		
		homeController
				.createReferenceData(
						String.valueOf(currencyExchange.getCurrencyExchangeId()),
						RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
						Long.valueOf(requestType),
						userContextVO.getUserIdentifier(),
						"Exch ID: " + currencyExchange.getCurrencyExchangeId(),
						approverGroupId,
						submitterGroupId);
	}

	/**
	 * 
	 * The method to identify whether the currency exchange update has happened
	 * for a US region or not. Based on the region the submitter has to be
	 * different.
	 * 
	 * @param currencyExchange
	 * @return isUSCurrency
	 */
	private Long getCurrencyCountry(CurrencyExchange currencyExchange) {
		Long crcyCountry = 0L;
		if (RefDataPropertiesConstants.CODE_CURRENCY_USDOLLAR
				.equals(currencyExchange.getFromCurrencyCode())
				|| RefDataPropertiesConstants.CODE_CURRENCY_USDOLLAR
						.equals(currencyExchange.getToCurrencyCode())) {
			crcyCountry = RefDataPropertiesConstants.CODE_GEOGRAPHY_UNITED_STATES;
		}

		return crcyCountry;
	}
	
	/**
	 * The method will show currency bulk upload form
	 *  
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/currencyBulkUpload.form")
	public ModelAndView currencyBulkUploadForm(){
		LOGGER.info("entering CurrencyController | currencyBulkUpload");

		ModelAndView currencyBulkUpload = new ModelAndView();
		return currencyBulkUpload;
	}
	
	/**
	 * The method will upload the currency bulk file into Naas Location.
	 * 
	 * @param currencyUploadItem
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/currencybulkload.form", method = RequestMethod.POST)
	public View currencyBulkUpload(CurrencyUploadItemVO currencyUploadItem,
			BindingResult result, SessionStatus sessionStatus,
			HttpSession session) throws ParseException {
		LOGGER.info("entering CurrencyController | currencyBulkUpload");		
		// audit variables
		Date startTime = new Date();
		String fileName = refdataConfig
				.getValue(RefDataPropertiesConstants.REFDATA_CRCY_BLK_UPLOAD_LOCATION)
				+ currencyUploadItem.getFile().getOriginalFilename();
		File f = new File(fileName);
		LOGGER.info("CurrencyController | currencyBulkUpload | File Name"+fileName);	
		MultipartFile multipartFile = currencyUploadItem.getFile();

		try {
			multipartFile.transferTo(f);
		} catch (IllegalStateException e) {
			LOGGER.error("Error in ControlWords Upload",e);
		} catch (IOException e) {
			LOGGER.error("Error in ControlWords Upload",e);
		} catch(Exception e){
			LOGGER.error("Error in ControlWords Upload",e);
		}

		if (result.hasErrors()) {
			for (ObjectError error : result.getAllErrors()) {
				LOGGER.error("Error: " + error.getCode() + " - "
						+ error.getDefaultMessage());
			}
		}

		// Invoke the WorkFlow service to create the workFlow task for the
		// bulk upload operation. This will be invoked as a web service call.
		createNewCurrencyBulkUploadWorkflowTask(
				currencyUploadItem,
				RefDataChangeTypeConstants.CHANGE_TYPE_BULK_UPLOAD_CURRENCY_EXCHANGE,
				(UserContextVO) session
						.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT));

		sessionStatus.setComplete();
		
		// transaction logging
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
				"getCurrencySearchResults", 0L, currencyUploadItem, 0L);
		
		LOGGER.info("exiting CurrencyController | currencyBulkUpload");
		return new RedirectView("submitterWorkQueueHome.form?domainName=Currency Exchange");
	}
	/**
	 * 
	 * The method to create new task with work-flow for currency bulk upload.
	 *
	 * @param currencyUploadItemVO
	 * @param requestType
	 * @param userContextVO
	 */
	private void createNewCurrencyBulkUploadWorkflowTask(
			CurrencyUploadItemVO currencyUploadItemVO,
			String requestType, 
			UserContextVO userContextVO) {
		
		Long submitterGroupId = 208L;
		Long approverGroupId = 210L;
		String fileName = currencyUploadItemVO.getFile().getOriginalFilename();
		
		LOGGER.info("params for createNewCurrencyWorkflowTaskForCrcyBulkUpload : " + 
				currencyUploadItemVO + " : " + 
				requestType + " : " + 
				userContextVO + " : " + 
				approverGroupId	+ " : " + 
				submitterGroupId);
		
		homeController.createCurrencyBulkUploadReferenceData("1",
				RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE,
				Long.valueOf(requestType), 
				userContextVO.getUserIdentifier(),
				"Currency Exchange Bulk Upload Reference Data" + 401, 
				fileName,
				approverGroupId, 
				submitterGroupId);
	}
	
	/**
	 * 	 
	 * Retrieves all geo currency information to be populated in the
	 * screen.
	 * <p>
	 * 
	 * @param model
	 * @return currencyExchange, the ModelAndView
	 * 
	 * 
	 * */	
	@RequestMapping(value = "/geoCurrencySearch.form", method = RequestMethod.GET)
	public ModelAndView geoCurrencySearch(HttpSession session) {
		LOGGER.info("entering CurrencyController | geoCurrencySearch");
		ModelAndView geoCurrenySearch = new ModelAndView("geoCurrencySearch");
		
		geoCurrenySearch.addObject(
				RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION,
				getCountryList());	
		
		LOGGER.info("exiting CurrencyController | geoCurrenySearch");
		return geoCurrenySearch;
	}
	
	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	private List<CodeValueVO> getCountryList() {
		return geoProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
	}
	
	/**
	 * 
	 * Retrieves the Geo Currency details.
	 * <p>
	 * 
	 * The search will be done on the  db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param geoCurrencySearchCriteria
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @param session
	 * @return geoCurrencySearch, the ModelAndView
	 */
	@SuppressWarnings("unused")
	@RequestMapping(value = "/geoCurrencySearchAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> geoCurrencySearchAjaxResults(
			HttpServletRequest request, HttpSession session) {
LOGGER.info("entering CurrencyController | geoCurrencySearchAjaxResults");
		
		String searchString = homeController.getSearchString(request);		
		
		GeoCurrencySearchVO geoCurrencySearchCriteria = getGeoCurrencySearchCriteria(request);
		
		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		Long countGeoCurrencySearchResults = (Long) session
				.getAttribute("countGlblEleAllSearchResults");
		if ((countGeoCurrencySearchResults == null) || (geoCurrencySearchCriteria.getRowIndex() == 0)) {
			countGeoCurrencySearchResults = wsProxy.countSearchGeoCrcy(geoCurrencySearchCriteria);
			session.setAttribute("countGeoCurrencySearchResults",
					countGeoCurrencySearchResults);
		}

		Map<String, Object> map = null;
		try {
			map = homeController.getJsonMap(request,
					wsProxy.searchGeoCrcy(geoCurrencySearchCriteria),
					countGeoCurrencySearchResults, geoCrcySearchColumns);
		} catch (Exception e) {			
			LOGGER.error("CurrencyController | geoCurrencySearchAjaxResults | returned after geoCurrencySearchAjaxResults",e);
		}

		LOGGER.info("CurrencyController | geoCurrencySearchAjaxResults | returned after geoCurrencySearchAjaxResults");
				
		LOGGER.info("exiting CurrencyController | geoCurrencySearchAjaxResults");
		return map;
	}
	
	
	/**
	 * 
	 * The method to populate the GeoCurrencySearchVO
	 * 
	 * @param request
	 * @return GeoCurrencySearchVO   
	 */
	private GeoCurrencySearchVO getGeoCurrencySearchCriteria(
			HttpServletRequest request) {
		LOGGER.info("entering CurrencyController | getGeoCurrencySearchCriteria");

		GeoCurrencySearchVO geoCurrencySearchCriteria = new GeoCurrencySearchVO();
		geoCurrencySearchCriteria.setSortOrder(homeController
				.getSortOrder(request));		
		geoCurrencySearchCriteria.setSortBy(homeController.getSortBy(request, geoCrcySearchColumns));
		geoCurrencySearchCriteria.setMaxResults(homeController
				.getMaxResults(request));
		geoCurrencySearchCriteria.setRowIndex(homeController
				.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);
		// Search string will be in the format
		// code#~text#~desc#~code#~text
		String searchCriteriaDelimiter = "~";
		if (compositeSearchString != null) {
			String[] splitCriteria = compositeSearchString
					.split(searchCriteriaDelimiter);
			if (splitCriteria.length > 0) {
				if (!(splitCriteria[0].replace("#", "").trim().isEmpty())) {
					geoCurrencySearchCriteria
							.setGeoUnitId(Long
									.valueOf(splitCriteria[0]
									.replace("#", "").trim()));
				}
			}
		
		}		

		LOGGER.info("CurrencyController | getGeoCurrencySearchCriteria | geoCurrencySearchCriteria : "
				+ geoCurrencySearchCriteria);
		LOGGER.info("exiting CurrencyController | getGeoCurrencySearchCriteria");
		return geoCurrencySearchCriteria;
	}
	

	/**
	 * The method will retrieve all Country and Currency details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id, the Country Name, the Currency codes and Currency Names.
	 * 
	 */
	@RequestMapping(value = "/geoCurrencyAdd.form", method = RequestMethod.GET)
	public ModelAndView geoCurrencyAdd(Model model,HttpSession session,Boolean addGeoCrcySuccess) {
		LOGGER.info("entering CurrencyController | geoCurrencyAdd");
		ModelAndView geoCurrenyAdd = new ModelAndView("geoCurrencyAdd");
		
		geoCurrenyAdd.addObject(
				RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION,
				getCountryList());	
		
		// Retrieving the Lists for currency Code and Data Provider
				List<Integer> codeTableIds = new ArrayList<Integer>();
				codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_CURRENCY);

				Map<String, List<CodeValue>> tempCodeValueMap = homeController
						.retrieveCodeValues(codeTableIds);
				geoCurrenyAdd
						.addObject(
								"currencyCodes",
								tempCodeValueMap.get(String
										.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_CURRENCY)));
				geoCurrenyAdd.addObject("addGeoCrcySuccess", addGeoCrcySuccess);
				AddGeoCurrencyVO addGeoCurrencyVO = new AddGeoCurrencyVO();
				model.addAttribute("geoCurrency",populateEmptyGeoCurrency(session,addGeoCurrencyVO));
		
		LOGGER.info("exiting CurrencyController | geoCurrencyAdd");
		return geoCurrenyAdd;
	}
	
	/**
	 * Populate empty rows for new Geo Currency addition
	 * 
	 * @param session
	 * @param addGeoCurrencyVO
	 * @return
	 */
	private Object populateEmptyGeoCurrency(HttpSession session,
			AddGeoCurrencyVO addGeoCurrencyVO) {
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		Date currentDate = new Date();
		
		addGeoCurrencyVO = addGeoCurrencyVO != null? addGeoCurrencyVO : new AddGeoCurrencyVO();
		
		if (addGeoCurrencyVO.getGeoCrcyId() == null) {
			addGeoCurrencyVO.setGeoCrcyId(-1L);
			if (addGeoCurrencyVO.getEffectiveDate() == null) {
				addGeoCurrencyVO.setEffectiveDate(currentDate);
			}
			addGeoCurrencyVO.setCreatedDate(currentDate);
			addGeoCurrencyVO.setCreatedUser(userContextVO.getUserIdentifier());
		}
		addGeoCurrencyVO.setModifiedDate(currentDate);
		addGeoCurrencyVO.setModifiedUser(userContextVO.getUserIdentifier());
		
		return addGeoCurrencyVO;
	}

	/**
	 * 
	 * The method to insert the newly added Geo Currency to the database. The
	 * method will bind the UI values and construct the AddGeoCurrency VO.
	 * 
	 * @param addGeoCurrencyVO
	 * @param result
	 * @param session
	 * @param request
	 * @return RedirectView
	 */
	@RequestMapping(value = "/insertGeoCurrency.form", method = RequestMethod.POST)
	public ModelAndView insertGeoCurrency(
			@ModelAttribute("geoCurrency") AddGeoCurrencyVO addGeoCurrencyVO,
			BindingResult result, Model model,HttpSession session,
			HttpServletRequest request,Boolean addGeoCrcySuccess) {
		LOGGER.info("entering CurrencyController | insertGeoCurrency");
		// audit variables
		

		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserIdentifier();
		populateNewGeoCurrencyMandatoryFields(addGeoCurrencyVO, loggedInUser);
		
		// merge the details to the code value table
		Long geoCrcyId = wsProxy.insertGeoCurrency(addGeoCurrencyVO);
		LOGGER.info("CurrencyController | insertGeoCurrency | geoCrcyId added ::"
				+ geoCrcyId);
		addGeoCrcySuccess = true;
		return geoCurrencyAdd(model,session,addGeoCrcySuccess);
	}

	/**
	 * This method will populate the audit columns in GEO_CRCY table  
	 * 
	 */
	private void populateNewGeoCurrencyMandatoryFields(
			AddGeoCurrencyVO addGeoCurrencyVO, String loggedInUser) {
		LOGGER.info("entering CurrencyController | populateNewGeoCurrencyMandatoryFields");
		addGeoCurrencyVO.setCreatedDate(new Date());
		addGeoCurrencyVO.setCreatedUser(loggedInUser);
		addGeoCurrencyVO.setModifiedDate(new Date());
		addGeoCurrencyVO.setModifiedUser(loggedInUser);		
		LOGGER.info("exiting CurrencyController | populateNewGeoCurrencyMandatoryFields");
	}
	
	
	/**
	 * 
	 * Export the Geo Currency search details.
	 * <p>
	 * 
	 * The export will be done on the SOR db GEO_CRCY table based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param getGeoCurrencySearchCriteria
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @param session
	 * @return geoCurrencySearch, the ModelAndView
	 */
	@RequestMapping(value = "/geoCurrencyExportToExcel.form", method = RequestMethod.GET)
	public @ResponseBody
	void geoCurrencyExportToExcel(HttpServletRequest request,
			HttpSession session, HttpServletResponse response) {
		LOGGER.info("entering CurrencyController | geoCurrencyExportToExcel");
		GeoCurrencySearchVO geoCurrencySearchCriteria = getGeoCurrencySearchCriteria(request);
		geoCurrencySearchCriteria.setViewType(request.getParameter("type"));
		GeoCurrencyExportToExcel geoCurrencyExportToExcel = new GeoCurrencyExportToExcel();
		
		try {
			geoCurrencyExportToExcel.geoCrcyWriteDataToExcel(wsProxy.searchGeoCrcy(geoCurrencySearchCriteria));
		} catch (Exception e) {
			LOGGER.error("problem in CurrencyController |geoCurrencyExportToExcel", e);
		}
		UserContextVO userContextVO = (UserContextVO) session
		.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		String loggedInUser = userContextVO.getUserFirstName();
		String dateAppend = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date());
		response.setContentType("application/xlsx");
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ "GeoCurrency_" + loggedInUser + "_"
				+ dateAppend + ".xlsx" + "\"");
		try {
			geoCurrencyExportToExcel.write(response.getOutputStream());
		} catch (IOException e) {
			LOGGER.error("problem in CurrencyController |geoCurrencyExportToExcel",e);
		}catch (Exception e) {
			LOGGER.error("problem in CurrencyController |geoCurrencyExportToExcel",e);
		}

	}

    /**
     * Retrieves the Geo Currency Entity corresponds to the
     * geoCurrencyId returned from the Geo Currency search page.
     * <p>
     * 
     * The entity returned will be used to show the Geo Currency details in
     * the Geo Currency View page.
     * <p>
     * 
     * @param geoCurrencyId
     * @param model
     * @param session
     * @param sessionStatus
     * @return geoCurrencyView, the ModelAndView
     */

   
    @RequestMapping(value = "/geoCurrencyView.form", method = RequestMethod.GET)
    public ModelAndView viewGeoCurrency(@RequestParam(RefDataUIConstants.GEO_CURRENCY_ID_REQ_PARAM)
    final Long geoCurrencyId, @RequestParam("taskId")
    final String taskId, Model model, HttpSession session, SessionStatus sessionStatus) {
        LOGGER.info("entering CurrencyController | viewGeoCurrency");

        ModelAndView geoCurrencyView = new ModelAndView("geoCurrencyView");
        GeoCurrency geoCurrency = new GeoCurrency();
        
        //Country List
        List<CodeValueVO> countryList = geoProxy.retrieveAllCountries(RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL, RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
        geoCurrencyView.addObject(RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION, countryList);

        /* Retrieving the Lists for Currency Code */
        List<Integer> codeTableIds = new ArrayList<Integer>();
        codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_CURRENCY);

        Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);
        geoCurrencyView.addObject("currencyCodes", tempCodeValueMap.get(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_CURRENCY)));

        geoCurrency = wsProxy.reviewGeoCurrency(geoCurrencyId);

        geoCurrencyView.addObject("geoCurrencyId", geoCurrencyId);

        model.addAttribute("geoCurrencyView", geoCurrency);
        LOGGER.info("CurrencyExchange for View : " + geoCurrencyId + "\n\n");
        session.setAttribute("taskId", taskId);
        LOGGER.info("exiting CurrencyController | viewCurrencyExchange");
        return geoCurrencyView;
    }

    /**
     * The method will persist the Geo Currency updates(end date) in the DB. Only
     * the changed relational data will be updated. 
     * 
     * @param geoCurrency
     * @param result
     * @param session
     * @param request
     */
    @RequestMapping(value = "/updateGeoCurrency.form", method = RequestMethod.POST)
    public ModelAndView updateGeoCurrency(@ModelAttribute("geoCurrencyView") GeoCurrency geoCurrency, BindingResult result, Model model, HttpSession session, HttpServletRequest request) {
        LOGGER.info("entering CurrencyController | updateGeoCurrency");      
        session.removeAttribute("tempCodeValueMap");

        UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
        
        //audit variables
        String loggedInUser = userContextVO.getUserIdentifier();
        geoCurrency.setModifiedUser(loggedInUser);
        geoCurrency.setModifiedDate(new Date());
        
        /* merge the details to the geo currency table */
        Long geoCrcyId = wsProxy.updateGeoCurrency(geoCurrency);
        LOGGER.info("CurrencyController | updateGeoCurrency | geoCrcyId updated ::" + geoCrcyId);

        return geoCurrencySearch(session); 
    }
	
}
