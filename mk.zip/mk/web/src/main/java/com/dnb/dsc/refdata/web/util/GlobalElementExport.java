package com.dnb.dsc.refdata.web.util;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dnb.dsc.refdata.core.entity.GlobalElement;

public class GlobalElementExport extends SXSSFWorkbook{
	/** The inds_code_sheet. */
	private Sheet all_search;

	/** The inds cd row count. */
	private Integer searchRowCount = 0;
	
	private static final Logger LOGGER = LoggerFactory
	.getLogger(GlobalElementExport.class);

	
	/**
	 * Instantiates a new inds export to excel.
	 *
	 * @param exportType the export type
	 */
	public GlobalElementExport(String geAllDesc) {
		super(300);		
		all_search = createSheet("All Search Rslts");
		all_srch_sheet_header(geAllDesc);
		
			
		

	}
	


	/**
	 * Inds_code_sheet_header.
	 */
	private void all_srch_sheet_header(String sheetName) {
		LOGGER.info("entering GlobalElementExport | all_srch_sheet_header | Writing Header");
		Row indusCdHeader = all_search.createRow(0);

			
		Cell headerCell0 = indusCdHeader.createCell(0);
		headerCell0.setCellValue("Global Element Id");
		
		Cell headerCell1 = indusCdHeader.createCell(1);
		headerCell1.setCellValue("Global Element Topic Category Code");
		
		Cell headerCell2 = indusCdHeader.createCell(2);
		headerCell2.setCellValue("Global Element Topic Category Name");

		Cell headerCell3 = indusCdHeader.createCell(3);
		headerCell3.setCellValue("Global Element Name");
		
		Cell headerCell4 = indusCdHeader.createCell(4);
		headerCell4.setCellValue("Global Element Metadata Code");
		
		Cell headerCell5 = indusCdHeader.createCell(5);
		headerCell5.setCellValue("Global Element Metadata Code Description");

		Cell headerCell6 = indusCdHeader.createCell(6);
		headerCell6.setCellValue("Global Element Metadata Value");	
		
		Cell headerCell7 = indusCdHeader.createCell(7);
		headerCell7.setCellValue("Effective Date");
		
		Cell headerCell8 = indusCdHeader.createCell(8);
		headerCell8.setCellValue("Expiration Date");
		
		Cell headerCell9 = indusCdHeader.createCell(9);
		headerCell9.setCellValue("Global Element Comment");
		
		Cell headerCell10 = indusCdHeader.createCell(10);
		headerCell10.setCellValue("Global Element Detail Comment");
		
		LOGGER.info("exiting GlobalElementExport | all_srch_sheet_header | Finished Writing Header");

	}

	

	/**
	 * Insert all search data.
	 *
	 * 
	 * private final String[] allSearchColumns = { "globalElementTopicCategoryName","globalElementId",
			"globalElementName", "globalElementShortDescription", 
			"globalElementLongDescription"};
	 */
	@SuppressWarnings("rawtypes")
	public void insertAllSearchData(List<GlobalElement> globalElement) {
		
		LOGGER.info("entering GlobalElementExport | insertAllSearchData | Writing data");
		List<GlobalElement> rows = new ArrayList<GlobalElement>();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		Iterator itr = globalElement.iterator();
		while (itr.hasNext()) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			GlobalElement row = new GlobalElement();

			row.setGlobalElementId(Long.valueOf((curr.get("globalElementId").toString())));
			row.setGlobalElementTopicCategoryCode(Long.valueOf((curr.get("globalElementTopicCategoryCode").toString())));			
			row.setTopicCategoryDescription((String)(curr.get("topicCategoryDescription")));
			row.setGlobalElementName((String)(curr.get("globalElementName")));
			row.setGlobalElementMetadataCode(Long.valueOf((curr.get("globalElementMetadataCode").toString())));
			row.setGlobalElementMetadataCodeDescription((String)(curr.get("globalElementMetadataCodeDescription").toString()));			
			row.setGlobalElementMetadataValue((String)(curr.get("globalElementMetadataValue").toString()));			
			try {
				Long effcDt = (Long) curr.get("effectiveDate");
				Date d1 = new Date(effcDt);
				String efctvDate = formatter.format(d1);
				row.setEffectiveDate((Date) formatter.parse(efctvDate));
				if(curr.get("expirationDate") != null){
				Long expDt = (Long) curr.get("expirationDate");
				Date d2 = new Date(expDt);
				String expDate = formatter.format(d2);				
				row.setExpirationDate((Date) formatter.parse(expDate));
				}else{
					row.setExpirationDate((Date) curr.get("expirationDate"));
				}
			} catch (Exception ex) {
				LOGGER.error("entering GlobalElementExport | Error in parsing date ", ex);
			}
			row.setGlobalElementComment((String)(curr.get("globalElementComment")));
			row.setGlobalElementDetailComment((String)(curr.get("globalElementDetailComment")));
			rows.add(row);
		}
		for (GlobalElement allSearch : rows) {
			searchRowCount++;
			Row dataRow = all_search.createRow(searchRowCount);
			
			Cell indscell0 = dataRow.createCell(0);
			indscell0.setCellValue(allSearch.getGlobalElementId());
			
			Cell indscell1 = dataRow.createCell(1);
			indscell1.setCellValue(allSearch.getGlobalElementTopicCategoryCode());
			
			Cell indscell2 = dataRow.createCell(2);
			indscell2.setCellValue(allSearch.getTopicCategoryDescription());			
			
			Cell indscell3 = dataRow.createCell(3);
			indscell3.setCellValue(allSearch.getGlobalElementName());
			
			Cell indscell4 = dataRow.createCell(4);
			indscell4.setCellValue(allSearch.getGlobalElementMetadataCode());

			Cell indscell5 = dataRow.createCell(5);
			indscell5.setCellValue(allSearch.getGlobalElementMetadataCodeDescription());	
			
			Cell indscell6 = dataRow.createCell(6);
			indscell6.setCellValue(allSearch.getGlobalElementMetadataValue());
			
			Cell indscell7 = dataRow.createCell(7);
			indscell7.setCellValue(formatter.format(allSearch.getEffectiveDate()));
			
			Cell indscell8 = dataRow.createCell(8);
			if(allSearch.getExpirationDate()!= null){
				indscell8.setCellValue(formatter.format(allSearch.getExpirationDate()));
			}else{
				indscell8.setCellValue("");
			}
			
			Cell indscell9 = dataRow.createCell(9);
			indscell9.setCellValue(allSearch.getGlobalElementComment());
			
			Cell indscell10 = dataRow.createCell(10);
			indscell10.setCellValue(allSearch.getGlobalElementDetailComment());
			
			LOGGER.info("entering GlobalElementExport | insertAllSearchData | Finished Writing data");

		}

	}


}
