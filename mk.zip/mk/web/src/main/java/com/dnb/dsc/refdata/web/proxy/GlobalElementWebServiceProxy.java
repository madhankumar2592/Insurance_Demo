package com.dnb.dsc.refdata.web.proxy;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GlobalElement;
import com.dnb.dsc.refdata.core.entity.GloblalElementCrossWalk;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.AddCrosswalkVO;
import com.dnb.dsc.refdata.core.vo.AddGlobalElementVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementCrosswalkSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementVO;
import com.dnb.dsc.refdata.web.util.RestWebServiceUtil;


@Component
public class GlobalElementWebServiceProxy {
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GlobalElementWebServiceProxy.class);
	
	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private RefDataConfigUtil refDataConfigUtil;

	@Autowired
	private RestWebServiceUtil restWSUtil;
	
	
	
	
	public Long countSearchByTopicsBkp(GlobalElementSearchVOBkp globalElementSearchCriteria) {
		return countSearchTopicsBkp(globalElementSearchCriteria, "/countAllSearchBkp.service");
	}
	
	private Long countSearchTopicsBkp(GlobalElementSearchVOBkp globalElementSearchCriteria, String deployURL) {
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + deployURL;
		HttpEntity<GlobalElementSearchVOBkp> entity = new HttpEntity<GlobalElementSearchVOBkp>(globalElementSearchCriteria);
		return (Long) this.restTemplate.postForObject(serviceURL, entity, Long.class, new Object[0]);
	}
	
	
	@SuppressWarnings("unchecked")
	public List<GlobalElement> searchByTopicsBkp(
			GlobalElementSearchVOBkp globalElementSearchCriteria)throws Exception {
		LOGGER.info("entering ScoreWebServiceProxy | SearchFailure");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/allSearchResultBkp.service";
		HttpEntity<GlobalElementSearchVOBkp> entity = new HttpEntity<GlobalElementSearchVOBkp>(
				globalElementSearchCriteria);
		LOGGER.info("exiting ScoreWebServiceProxy | searchScores");
		return (List<GlobalElement>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}

	@SuppressWarnings("unchecked")
	public List<GlobalElementVO> retrieveHints() {
		LOGGER.info("entering GlobalElementWebServiceProxy | retrieveHints");
		String serviceURL = "/retrieveHints.service";
		return restWSUtil.exchangeForList(GlobalElementVO.class, serviceURL);
	}

	@SuppressWarnings("unchecked")
	public List<GlobalElementVO> retrieveHintsDesc() {
		LOGGER.info("entering GlobalElementWebServiceProxy | retrieveHints");
		String serviceURL = "/retrieveHintsDesc.service";
		return restWSUtil.exchangeForList(GlobalElementVO.class, serviceURL);
	}

	public Long insertGlobalElement(AddGlobalElementVO addGlobalElementVO) {
		LOGGER.info("entering GlobalElementWebServiceProxy | insertGlobalElement");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/insertGlobalElement.service";
		HttpEntity<AddGlobalElementVO> entity = new HttpEntity<AddGlobalElementVO>(
				addGlobalElementVO);
		LOGGER.info("exiting GlobalElementWebServiceProxy | insertGlobalElement");
		Long result = (Long) restTemplate.postForObject(serviceURL, entity,
				Long.class, new Object[0]);
		return result;
	}

	
	public AddGlobalElementVO retrieveGlobalElement(
			AddGlobalElementVO addGlobalElement) {
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/retrieveGlobalELement.service";
		HttpEntity<AddGlobalElementVO> entity = new HttpEntity<AddGlobalElementVO>(addGlobalElement);
		LOGGER.info("exiting GlobalElementWebServiceProxy | retrieveGlobalElement");
		return restTemplate.postForObject(serviceURL, entity, AddGlobalElementVO.class);
		
	}
	public AddCrosswalkVO retrieveGlobalElementCrosswalk(
			AddCrosswalkVO addGlobalElement) {
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/retrieveGlobalELementCrosswalk.service";
		HttpEntity<AddCrosswalkVO> entity = new HttpEntity<AddCrosswalkVO>(addGlobalElement);
		LOGGER.info("exiting GlobalElementWebServiceProxy | retrieveGlobalElement");
		return restTemplate.postForObject(serviceURL, entity, AddCrosswalkVO.class);
		
	}
	public Long editGlobalElement(AddGlobalElementVO addGlobalElementVO) {
		LOGGER.info("entering GlobalElementWebServiceProxy | editGlobalElement");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/editGlobalElement.service";
		HttpEntity<AddGlobalElementVO> entity = new HttpEntity<AddGlobalElementVO>(
				addGlobalElementVO);
		LOGGER.info("exiting GlobalElementWebServiceProxy | editGlobalElement");
		Long res = (Long) restTemplate.postForObject(serviceURL, entity,
				Long.class, new Object[0]);
		return res;
	}
	
	public Boolean isDuplicateElementName(String globalElementName) {
		LOGGER.info("entering GlobalElementWebServiceProxy | isDuplicateElementName");
		HttpEntity<Boolean> entity = new HttpEntity<Boolean>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{globalElementName}/isDuplicateElementName.service";
		ResponseEntity<Boolean> result = this.restTemplate.exchange(serviceURL, HttpMethod.GET,
					entity, Boolean.class, globalElementName );
		LOGGER.info("exiting GlobalElementWebServiceProxy | isDuplicateElementName");
		return result != null ? (Boolean) result.getBody() : null;
	}
	
	public String retrieveGlobalElement(Long globalElementId) {
		LOGGER.info("entering GlobalElementWebServiceProxy | isDuplicateElementName");
		HttpEntity<String> entity = new HttpEntity<String>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{globalElementId}/retrieveGlobalElement.service";
		ResponseEntity<String> result = this.restTemplate.exchange(serviceURL, HttpMethod.GET,
					entity, String.class, new Object[] { globalElementId });
		LOGGER.info("exiting GlobalElementWebServiceProxy | isDuplicateElementName");
		return result != null ? (String) result.getBody() : null;
	}
	
	
	public Long checkGlblEleCrswlkId(GloblalElementCrossWalk crosswlk) {
		LOGGER.info("entering GlobalElementWebServiceProxy | editGlobalElement");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/checkGlblEleCrswlkId.service";
		HttpEntity<GloblalElementCrossWalk> entity = new HttpEntity<GloblalElementCrossWalk>(
				crosswlk);
		LOGGER.info("exiting GlobalElementWebServiceProxy | editGlobalElement");
		Long res = (Long) restTemplate.postForObject(serviceURL, entity,
				Long.class, new Object[0]);
		return res;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<AddCrosswalkVO> retrievePlatformDetails(
			Long globalElementPlatformCode) {
		LOGGER.info("entering GlobalElementWebServiceProxy | retrievePlatformDetails");
		AddCrosswalkVO addCrosswalkVO = new AddCrosswalkVO();
		addCrosswalkVO.setPlatformCode(globalElementPlatformCode);		
		String serviceURL = refDataConfigUtil.getServiceDeployURL()+"/{globalElementPlatformCode}/retrievePlatformDetails.service";
		HttpEntity<AddCrosswalkVO> entity = new HttpEntity<AddCrosswalkVO>(addCrosswalkVO);
		List result = (List<AddCrosswalkVO>) restTemplate.postForObject(serviceURL, entity, List.class,new Object[]{globalElementPlatformCode});
		
		List<AddCrosswalkVO> addCrosswalkVOs = new ArrayList<AddCrosswalkVO>();
		for (int i = 0; i < result.size(); i++) {
			AddCrosswalkVO newCrosswalkVOs = new AddCrosswalkVO();
			LinkedHashMap<String, Integer> lhm = (LinkedHashMap<String, Integer>) result.get(i);
			for(Entry<String, Integer> t : lhm.entrySet()) {
				
				if(t.getValue()!=null){
					try{						
						if(t.getKey().equalsIgnoreCase("metadataCode")){							
								newCrosswalkVOs.setMetadataCode(new Long(t.getValue()));
						}	
						else if(t.getKey().equalsIgnoreCase("metadataValue")){
							newCrosswalkVOs.setMetadataValue(String.valueOf(t.getValue()));
						}
					}
					catch(Exception e){
						
						e.printStackTrace();
					}
				}
		    }
			addCrosswalkVOs.add(newCrosswalkVOs);
		}
		 
		LOGGER.info("exiting GlobalElementWebServiceProxy | retrievePlatformDetails");
		return addCrosswalkVOs;
	}

	public Long addNewCrosswalk(AddCrosswalkVO addCrosswalkVO) {
		LOGGER.info("entering GlobalElementWebServiceProxy | addCrosswalk");
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/addNewCrosswalk.service";
		HttpEntity<AddCrosswalkVO> entity = new HttpEntity<AddCrosswalkVO>(addCrosswalkVO);
		LOGGER.info("exiting GlobalElementWebServiceProxy | addCrosswalk");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}
	
		
	public Long addGlobalElementCrosswalk(
			GloblalElementCrossWalk addGlblEleCrosswalk) {
		LOGGER.info("entering GlobalElementWebServiceProxy | addGlobalElementCrosswalk");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/addGlobalElementCrosswalk.service";
		HttpEntity<GloblalElementCrossWalk> entity = new HttpEntity<GloblalElementCrossWalk>(
				addGlblEleCrosswalk);
		LOGGER.info("exiting GlobalElementWebServiceProxy | addGlobalElementCrosswalk");
		Long res = (Long) restTemplate.postForObject(serviceURL, entity,
				Long.class, new Object[0]);
		return res;
	}

	@SuppressWarnings( "unchecked")
	public List<CodeValue> retrieveSearchCrossWalkCodeType(Long crosswalkApplied) {
		
		LOGGER.info("entering IndustryCodesWebServiceProxy | retrieveCrossWalksForIndsCodeType");
		String serviceURL = "/{crosswalkApplied}/retrieveSearchCrossWalkCodeType.service";
		return restWSUtil.exchangeForList(CodeValue.class, serviceURL, crosswalkApplied);
	}
	
	@SuppressWarnings("unchecked")
	public List<GloblalElementCrossWalk> searchByCrosswalk(
			GlobalElementCrosswalkSearchVOBkp globalElementSearchCriteria)throws Exception {
		LOGGER.info("entering ScoreWebServiceProxy | SearchFailure");

		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/allCrosswalkSearchResult.service";
		HttpEntity<GlobalElementCrosswalkSearchVOBkp> entity = new HttpEntity<GlobalElementCrosswalkSearchVOBkp>(
				globalElementSearchCriteria);
		LOGGER.info("exiting ScoreWebServiceProxy | searchScores");
		return (List<GloblalElementCrossWalk>) this.restTemplate.postForObject(
				serviceURL, entity, List.class, new Object[0]);
	}
	
	public Long countSearchByCrosswlkBkp(GlobalElementCrosswalkSearchVOBkp globalElementSearchCriteria) {
		return countSearchCrosswlkBkp(globalElementSearchCriteria, "/countCrosswalkSearchResult.service");
	}
	
	private Long countSearchCrosswlkBkp(GlobalElementCrosswalkSearchVOBkp globalElementSearchCriteria, String deployURL) {
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + deployURL;
		HttpEntity<GlobalElementCrosswalkSearchVOBkp> entity = new HttpEntity<GlobalElementCrosswalkSearchVOBkp>(globalElementSearchCriteria);
		return (Long) this.restTemplate.postForObject(serviceURL, entity, Long.class, new Object[0]);
	}

	@SuppressWarnings("unchecked")
	public List<AddCrosswalkVO> retrieveEditPlatformDetails(
			Long globalElementPlatformCode, Long globalElementId) {
		LOGGER.info("entering GlobalElementWebServiceProxy | retrievePlatformDetails");
		AddCrosswalkVO addCrosswalkVO = new AddCrosswalkVO();
		addCrosswalkVO.setPlatformCode(globalElementPlatformCode);
		addCrosswalkVO.setGlobalElementId(globalElementId);
		String serviceURL = refDataConfigUtil.getServiceDeployURL()+"/{globalElementPlatformCode}/{globalElementId}/retrievePlatformDetails.service";
		HttpEntity<AddCrosswalkVO> entity = new HttpEntity<AddCrosswalkVO>(addCrosswalkVO);
		List<AddCrosswalkVO> result = (List<AddCrosswalkVO>) restTemplate.postForObject(serviceURL, entity, List.class,new Object[]{globalElementPlatformCode,globalElementId});
				
		LOGGER.info("exiting GlobalElementWebServiceProxy | retrievePlatformDetails");
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<GloblalElementCrossWalk> retrievePlatformList() {
		LOGGER.info("entering GlobalElementWebServiceProxy | retrievePlatformList");
		String serviceURL = "/retrievePlatformList.service";
		return restWSUtil.exchangeForList(GloblalElementCrossWalk.class, serviceURL);
	}

	@SuppressWarnings("unchecked")
	public List<GlobalElement> retrieveUnMappedElementCount() {		
		LOGGER.info("entering GlobalElementWebServiceProxy | retrieveUnMappedElementCount");
		String serviceURL = "/unMappedElementCount.service";
		return restWSUtil.exchangeForList(GlobalElement.class, serviceURL);
	}

	public Long totalUnMappedElementCount(
			GloblalElementCrossWalk unMappedCount) {
		String serviceURL = refDataConfigUtil.getServiceDeployURL()+ "/totalUnMappedElementCount.service";
		HttpEntity<GloblalElementCrossWalk> entity = new HttpEntity<GloblalElementCrossWalk>(unMappedCount);
		return (Long) this.restTemplate.postForObject(serviceURL, entity, Long.class, new Object[0]);
	}

	public Long retrieveGroupName(String globalElementCrosswalkGrpNme) {
		String serviceURL = refDataConfigUtil.getServiceDeployURL() + "/retrieveGroupName.service";
		HttpEntity<String> entity = new HttpEntity<String>(globalElementCrosswalkGrpNme);
		LOGGER.info("exiting GlobalElementWebServiceProxy | retrieveGlobalElement");
		return restTemplate.postForObject(serviceURL, entity, Long.class);
	}

	public Long retrieveGroupName(String globalElementCrosswalkGrpNme,
			Long globalElementId) {

		HttpEntity<String> entity = new HttpEntity<String>(
				restWSUtil.constructRequestHeader());
		String serviceURL = refDataConfigUtil.getServiceDeployURL()
				+ "/{globalElementCrosswalkGrpNme}/{globalElementId}/retrieveGroupName.service";
		ResponseEntity<Long> result = this.restTemplate.exchange(serviceURL,
				HttpMethod.GET, entity, Long.class, new Object[] {
						globalElementCrosswalkGrpNme, globalElementId });
		LOGGER.info("exiting GlobalElementWebServiceProxy | isDuplicateElementName");
		return result != null ? result.getBody() : null;
	}




}
