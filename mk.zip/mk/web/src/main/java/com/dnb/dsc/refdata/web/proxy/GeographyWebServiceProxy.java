/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.proxy;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GeoDefaultConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoHierarchy;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.entity.GeographySearch;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.entity.UserGroupMapping;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.GeoCodeBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.GeoSearchCriteriaVO;
import com.dnb.dsc.refdata.web.util.RestWebServiceUtil;

/**
 * The web service proxy class will handle the mapping between the UI web
 * requests and the respective service end point class. The class will construct
 * the REST WS requests and exchange the request with the service end point for
 * the response.
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@Component
public class GeographyWebServiceProxy {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GeographyWebServiceProxy.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private RestWebServiceUtil restWSUtil;

	
	/**
	 * The proxy method for search geo unit by name. The method will construct
	 * the HTTP request for the service end point and returns the response to
	 * the controller class.
	 * 
	 * @param nameFilter
	 * @param languageCode
	 * @return list the response List
	 */
	@SuppressWarnings({ "unchecked"})
	public List<GeoUnitName> searchGeoUnitByName(String nameFilter,
			int startIndex, int maxResults, String sortBy, String sortOrder,
			Long languageCode) {
		LOGGER.info("entering GeographyWebServiceProxy | searchGeoUnitByName");
		String queryParams = "/{nameFilter}/{startIndex}/{maxResults}/{sortBy}/" +
				"{sortOrder}/{languageCode}/searchGeoUnitByName.service";
		return restWSUtil.exchangeForList(GeoUnitName.class, queryParams, nameFilter, startIndex, maxResults, sortBy,
				sortOrder, languageCode);
	}

	/**
	 * The proxy method for search geo unit by code. The method will construct
	 * the HTTP request for the service end point and returns the response to
	 * the controller class.
	 * 
	 * @param codeFilter
	 * @param languageCode
	 * @return list the response List
	 */
	@SuppressWarnings("unchecked")
	public List<GeoUnitCode> searchGeoUnitByCode(String codeFilter, int startIndex, int maxResults, String sortBy,
			String sortOrder, Long languageCode) {
		LOGGER.info("entering GeographyWebServiceProxy | searchGeoUnitByCode");

		String queryParams = "/{codeFilter}/"
				+ "{startIndex}/{maxResults}/{sortBy}/{sortOrder}/{languageCode}/searchGeoUnitByCode.service";

		return restWSUtil.exchangeForList(GeoUnitCode.class, queryParams, codeFilter, startIndex, maxResults, sortBy,
				sortOrder, languageCode);
	}

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 * 
	 * @param geoUnitId
	 * @return
	 */
	public GeoUnit retrieveGeoUnitByGeoUnitId(Long geoUnitId) {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveGeoUnitByGeoUnitId");

		HttpEntity<GeoUnit> entity = new HttpEntity<GeoUnit>(
				restWSUtil.constructRequestHeader());
		String queryParams = "/{geoUnitId}/retrieveGeoUnitByGeoUnitId.service";
		ResponseEntity<GeoUnit> result = null;
		result = restTemplate.exchange(
				restWSUtil.getServiceURL(queryParams), HttpMethod.GET,
				entity, GeoUnit.class, geoUnitId);
		LOGGER.info("exiting GeographyWebServiceProxy | retrieveGeoUnitByGeoUnitId");
		return result != null ? result.getBody() : null;
	}

	/**
	 * 
	 * The method will retrieve the SCoTS data for all the tables given as
	 * parameter from the Staging SoR. The input will be list of Code Table IDs
	 * and the user preferred language. The return will be a map with key as
	 * Code table ID and value as list of CodeValue. The method is invoked to
	 * populate the following drop downs in Add Geo Unit UI: - Geo Unit Type -
	 * Name Type - Language - Data Provider - Code Type
	 * 
	 * @param codeTableIds
	 * @param languageCode
	 * @return
	 */
	@SuppressWarnings({ "unchecked" })
	public Map<Integer, List<CodeValue>> retrieveCodeValues(
			List<Integer> codeTableIds, Long languageCode) {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveCodeValues");

		String queryParams = "/{languageCode}/retrieveCodeValues.service";
		HttpEntity<List<Integer>> entity = new HttpEntity<List<Integer>>(
				codeTableIds);
		Map<Integer, List<CodeValue>> result = null;
		result = restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Map.class,
				languageCode);
		LOGGER.info("exiting GeographyWebServiceProxy | retrieveCodeValues");
		return result;
	}
	@SuppressWarnings({ "unchecked" })
	public List<CodeValue> retrieveCodeValuesScores(
			List<Integer> codeTableIds, Long languageCode) {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveCodeValuesScores");

		String queryParams = "/{languageCode}/retrieveCodeValuesScores.service";
		HttpEntity<List<Integer>> entity = new HttpEntity<List<Integer>>(
				codeTableIds);
		List<CodeValue> result = null;
		result = restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, List.class,
				languageCode);
		LOGGER.info("exiting GeographyWebServiceProxy | retrieveCodeValuesScores");
		return result;
	}
	@SuppressWarnings({ "unchecked" })
	public List<CodeValue> retrieveMktGrpCodes() {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveMktGrpCodes");
			CodeValue codeValue = new CodeValue();
		String queryParams = "/retrieveMktGrpCodes.service";
		HttpEntity<CodeValue> entity = new HttpEntity<CodeValue>(codeValue);
		List<CodeValue> result = null;
		result = restTemplate.postForObject(restWSUtil.getServiceURL(queryParams),entity,List.class);
		LOGGER.info("exiting GeographyWebServiceProxy | retrieveMktGrpCodes");
		return result;
	}
	@SuppressWarnings({ "unchecked" })
	public Map<Integer, List<CodeValue>> retrieveCodeValuesScr(
			List<Integer> codeTableIds, Long languageCode) {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveCodeValues");

		String queryParams = "/{languageCode}/retrieveCodeValuesScr.service";
		HttpEntity<List<Integer>> entity = new HttpEntity<List<Integer>>(
				codeTableIds);
		Map<Integer, List<CodeValue>> result = null;
		result = restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Map.class,
				languageCode);
		LOGGER.info("exiting GeographyWebServiceProxy | retrieveCodeValues");
		return result;
	}
	/**
	 * Deletes the geoUnit corresponds to the geoUnitId passed from the
	 * GeoUnitView page
	 * <p>
	 * Acts as web service proxy method for delete geo unit service.
	 * <p>
	 * 
	 * @param geoUnitId
	 * @return a workflowTrackingId
	 */
	public Long deleteGeoUnitById(GeoUnit geoUnit) {
		LOGGER.info("entering GeographyWebServiceProxy | deleteGeoUnitById");
		Long result = null;
		HttpEntity<GeoUnit> entity = new HttpEntity<GeoUnit>(geoUnit);
		String queryParams = "/deleteGeoUnitById.service";
		result = restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Long.class);
		LOGGER.info("exiting GeographyWebServiceProxy | deleteGeoUnitById");
		return result;
	}

	/**
	 * 
	 * The method to retrieve the geography search details. The method will
	 * perform a hierarchy search of geo units on the search db. The search will
	 * be done on the flat db based on the search criteria the user had
	 * provided.
	 * 
	 * @param geoSearchCriteria
	 * @param result
	 * @param model
	 * @param sessionStatus
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<GeographySearch> searchGeographies(
			GeoSearchCriteriaVO geoSearchCriteriaVO) {
		LOGGER.info("entering GeographyWebServiceProxy | searchGeographies");

		String queryParams = "/searchGeographies.service";
		HttpEntity<GeoSearchCriteriaVO> entity = new HttpEntity<GeoSearchCriteriaVO>(
				geoSearchCriteriaVO);
		List<GeographySearch> result = null;
		result = (List<GeographySearch>) this.restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, List.class,
				new Object[0]);
		LOGGER.info("exiting GeographyWebServiceProxy | searchGeographies");
		return result;
	}

	/**
	 * 
	 * The method will count the records in the hierarchy search of geo units on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param geoSearchCriteria
	 * @return countResults
	 */
	public Long countSearchGeographies(GeoSearchCriteriaVO geoSearchCriteriaVO) {
		LOGGER.info("entering GeographyWebServiceProxy | countSearchGeographies");

		String queryParams = "/countSearchGeographies.service";
		HttpEntity<GeoSearchCriteriaVO> entity = new HttpEntity<GeoSearchCriteriaVO>(
				geoSearchCriteriaVO);
		Long result = null;
		result = (Long) this.restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Long.class,
				new Object[0]);
		LOGGER.info("exiting GeographyWebServiceProxy | countSearchGeographies");
		return result;
	}

	/**
	 * 
	 * The method will count the records in the name search of geo units on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchString
	 * @return countResults
	 */
	public Long countSearchGeoUnitByName(String searchString) {
		return countSearchGeoUnit(searchString, "/countSearchGeoUnitByName.service");
	}

	/**
	 * 
	 * The method will count the records in the code search of geo units on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchString
	 * @return countResults
	 */
	public Long countSearchGeoUnitByCode(String searchString) {
		return countSearchGeoUnit(searchString, "/countSearchGeoUnitByCode.service");
	}
	/**
	 * 
	 * The generic method to count the GeoUnit details - Geo Name/Code Search
	 *
	 * @param searchString
	 * @param queryParams
	 * @return
	 */
	private Long countSearchGeoUnit(String searchString, String queryParams) {
		HttpEntity<String> entity = new HttpEntity<String>(searchString);
		Long result = null;
		result = (Long) this.restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Long.class,
				new Object[0]);
		return result;
	}

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllCountries(Long nameType,
			Long languageCode) {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveAllCountries");
		String queryParams = "/{nameType}/{languageCode}/retrieveAllCountries.service";

		return restWSUtil.exchangeForList(CodeValueVO.class, queryParams, nameType, languageCode);
	}

	/**
	 * The method will retrieve all Continent details from the Search DB based
	 * on the name type code and the user preferred language code. The return
	 * type is a VO which contains the Continent Geo Unit Id and the Continent
	 * Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllContinents(Long nameType,
			Long languageCode) {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveAllContinents");
		String queryParams = "/{nameType}/{languageCode}/retrieveAllContinents.service";

		return restWSUtil.exchangeForList(CodeValueVO.class, queryParams, nameType, languageCode);
	}

	/**
	 * Retrieves all Country group details from the Search DB based on the name
	 * type code and the user preferred language code. The return type is a VO
	 * which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 * @return a List of CodeValueVO
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllCountryGroups(Long nameType,
			Long languageCode) {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveAllCountryGroups");
		String queryParams = "/{nameType}/{languageCode}/retrieveAllCountryGroups.service";

		return restWSUtil.exchangeForList(CodeValueVO.class, queryParams, nameType, languageCode);
	}

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveChildGeoUnitsByType(Long languageCode,
			Long geoUnitType, Long parentGeoUnitId, Long nameType) {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveChildGeoUnitsByType");
		String queryParams = "/{languageCode}/{geoUnitType}/{parentGeoUnitId}/{nameType}/retrieveChildGeoUnitsByType.service";

		return restWSUtil.exchangeForList(CodeValueVO.class, queryParams, languageCode, geoUnitType, parentGeoUnitId,
				nameType);		
	}

	/**
	 * The method will be invoked by the when the the business owner reviews the
	 * changes submitted for his approval. The user reviews the changes and he
	 * could approve or reject the request.
	 * 
	 * @param trackingId
	 */
	public GeoUnit reviewGeoUnitChanges(Long domainId) {
		LOGGER.info("entering GeographyWebServiceProxy | reviewGeoUnitChanges");

		HttpEntity<GeoUnit> entity = new HttpEntity<GeoUnit>(
				restWSUtil.constructRequestHeader());
		String queryParams = "/{domainId}/reviewGeoUnitChanges.service";
		ResponseEntity<GeoUnit> result = null;
		result = restTemplate.exchange(
				restWSUtil.getServiceURL(queryParams), HttpMethod.GET,
				entity, GeoUnit.class, domainId);
		LOGGER.info("exiting GeographyWebServiceProxy | reviewGeoUnitChanges");
		return result != null ? result.getBody() : null;
	}

	/**
	 * 
	 * 
	 * @param langCode
	 * @param writingScriptCode
	 * @param nameTypeCode
	 * @param geoUnitId
	 * @return a List of GeoUnitName
	 */
	@SuppressWarnings("unchecked")
	public List<GeoUnitName> searchCountryGroups(Long langCode, Long writingScriptCode, Long nameTypeCode,
			Long geoUnitId) {
		LOGGER.info("entering GeographyWebServiceProxy | searchCountryGroups");
		String queryParams = "/{langCode}/{writingScriptCode}/{nameTypeCode}/{geoUnitId}/searchCountryGroups.service";

		return restWSUtil.exchangeForList(GeoUnitName.class, queryParams, langCode, writingScriptCode, nameTypeCode,
				geoUnitId);
	}

	/**
	 * The method will persist new Geo Unit data in the Transactional DB.
	 * 
	 * @param GeoUnit
	 * @return update status
	 */
	public Long insertGeoUnit(GeoUnit geoUnit) {
		return saveGeoUnit(geoUnit, "/insertGeoUnit.service");
	}

	/**
	 * The method will persist the existing Geo Unit data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param GeoUnit
	 * @return update status
	 */
	public Long updateGeoUnit(GeoUnit geoUnit) {
		return saveGeoUnit(geoUnit, "/updateGeoUnit.service");
	}
	/**
	 * 
	 * The generic method to insert/update the GeoUnit entity
	 *
	 * @param geoUnit
	 * @param deployURL
	 * @return
	 */
	private Long saveGeoUnit(GeoUnit geoUnit, String deployURL) {
		HttpEntity<GeoUnit> entity = new HttpEntity<GeoUnit>(geoUnit);
		Long result = null;
		result = restTemplate.postForObject(
			restWSUtil.getServiceURL(deployURL), entity, Long.class);
		return result;
	}

	/**
	 * 
	 * The method will retrieve all geography hierarchies
	 * 
	 * @return geoHierarchies
	 */
	@SuppressWarnings("unchecked")
	public List<GeoHierarchy> retrieveAllGeoHierarchies() {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveAllGeoHierarchies");
		String queryParams = "/retrieveAllGeoHierarchies.service";

		return restWSUtil.exchangeForList(GeoHierarchy.class, queryParams);		
	}

	/**
	 * 
	 * The method will retrieve all geography default configurations
	 * 
	 * @return geoDefaultConfigurations
	 */
	@SuppressWarnings("unchecked")
	public List<GeoDefaultConfiguration> retrieveAllGeoConfigurations() {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveAllGeoConfigurations");
		String queryParams = "/retrieveAllGeoConfigurations.service";

		return restWSUtil.exchangeForList(GeoDefaultConfiguration.class, queryParams);
	}
	/**
	 * 
	 * The method will validate the Geo Unit for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param geoUnitId
	 * @return
	 */
	public String lockGeoUnit(Long geoUnitId) {		
		HttpEntity<String> entity = new HttpEntity<String>(
				restWSUtil.constructRequestHeader());
		ResponseEntity<String> result = null;
		result = this.restTemplate.exchange(restWSUtil.getServiceURL("/{geoUnitId}/lockGeoUnit.service"), HttpMethod.GET,
				entity, String.class, new Object[] { geoUnitId });
		return result != null ? (String) result.getBody() : null;		
	}
	/**
	 * 
	 * The method to check for child geo units
	 * 
	 * @param geoUnitId
	 * @return
	 */
	public Boolean checkForChildGeoUnit(Long geoUnitId) {
		return checkForBoolean(geoUnitId, "/{geoUnitId}/checkForChildGeoUnit.service");
	}
	/**
	 * 
	 * The method to check for boolean value passing the geoUnitId
	 *
	 * @param geoUnitId
	 * @param queryParams
	 * @return
	 */
	private Boolean checkForBoolean(Long geoUnitId, String queryParams) {
		HttpEntity<Boolean> entity = new HttpEntity<Boolean>(
				restWSUtil.constructRequestHeader());
		ResponseEntity<Boolean> result = null;
		result = this.restTemplate.exchange(restWSUtil.getServiceURL(queryParams), HttpMethod.GET,
				entity, Boolean.class, new Object[] { geoUnitId });
		return result != null ? (Boolean) result.getBody() : null;
	}

	/**
	 * 
	 * The method will retrieve all user group mappings available within
	 * refdata.
	 * 
	 * @return userGroupMappings
	 */
	@SuppressWarnings("unchecked")
	public List<UserGroupMapping> retrieveAllUserGroupMappings() {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveAllUserGroupMappings");
		String queryParams = "/retrieveAllUserGroupMappings.service";

		return restWSUtil.exchangeForList(UserGroupMapping.class, queryParams);
	}

	/**
	 * 
	 * TODO
	 * 
	 * @param geoUnitId
	 * @param geoUnitTypeCode
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Long, String> getHierarchyByGeoUnitId(Long geoUnitId,
			Long geoUnitTypeCode) {
		LOGGER.info("entering GeographyWebServiceProxy | getHierarchyByGeoUnitId");

		HttpEntity<Map<Long, String>> entity = new HttpEntity<Map<Long, String>>(
				restWSUtil.constructRequestHeader());
		String queryParams = "/{geoUnitId}/{geoUnitTypeCode}/getHierarchyByGeoUnitId.service";
		ResponseEntity<Map> result = null;
		result = restTemplate.exchange(
				restWSUtil.getServiceURL(queryParams), HttpMethod.GET,
				entity, Map.class, geoUnitId, geoUnitTypeCode);
		LOGGER.info("exiting GeographyWebServiceProxy | retrieveGeoUnitByGeoUnitId");
		return result != null ? result.getBody() : null;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String getOfficialNameByGeoUnitIdAndTypeCode(Long parentGeoUnitId,
			Long geoUnitId, Long geoUnitTypeCode) {
		LOGGER.info("entering GeographyWebServiceProxy | getOfficialNameByGeoUnitIdAndTypeCode");

		HttpEntity entity = new HttpEntity(restWSUtil.constructRequestHeader());
		String queryParams = "/{parentGeoUnitId}/{geoUnitId}/{geoUnitTypeCode}/getOfficialNameByGeoUnitIdAndTypeCode.service";
		ResponseEntity<String> result = null;
		result = restTemplate.exchange(
				restWSUtil.getServiceURL(queryParams), HttpMethod.GET,
				entity, String.class, parentGeoUnitId, geoUnitId,
				geoUnitTypeCode);
		LOGGER.info("exiting GeographyWebServiceProxy | getOfficialNameByGeoUnitIdAndTypeCode");
		return result != null ? result.getBody() : null;
	}

	/**
	 * 
	 * The method will retrieve list of GeoUnits for the given geounit ids.
	 * 
	 */
	@SuppressWarnings({ "unchecked" })
	public Map<Long, List<GeoUnit>> retrieveGeoUnitsByIdList(List<Long> geoUnitIds) {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveGeoUnitsByIdList");

		String queryParams = "/retrieveGeoUnitsByIdList.service";
		HttpEntity<List<Long>> entity = new HttpEntity<List<Long>>(geoUnitIds);
		Map<Long, List<GeoUnit>> result = null;
		result = restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Map.class);
		LOGGER.info("exiting GeographyWebServiceProxy | retrieveGeoUnitsByIdList");
		return result;
	}
	/**
	 * The method will search the Staging SoR for the UiBulkDownload based on the 
	 * userId and will return the UiBulkDownload entity.
	 * 
	 * @param userId
	 * @return UiBulkDownload
	 */
	@SuppressWarnings("unchecked")
	public List<GeoHierarchy> retrieveGeoUnitType(Long  geoUnitId) {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveGeoUnitType");
		String queryParams = "/{geoUnitId}/retrieveGeoUnitType.service";
		
		return restWSUtil.exchangeForList(GeoHierarchy.class, queryParams, geoUnitId);
	}
	/**
	 * The method will add UiBulkDownload data in the Transactional 
	 * 	 * DB. 
	 * 
	 * @param UiBulkDownload
	 * @return insert status
	 */
	public Long addUIBulkDownload(UiBulkDownload uiBulkDownload) {
		LOGGER.info("entering GeographyWebServiceProxy | addUIBulkDownload");
			
		String queryParams = "/addGeoUIBulkDownload.service";
	
		HttpEntity<UiBulkDownload> entity = new HttpEntity<UiBulkDownload>(uiBulkDownload);
		Long result = null;
		result = restTemplate.postForObject(
				restWSUtil.getServiceURL(queryParams), entity, Long.class);			
		LOGGER.info("exiting GeographyWebServiceProxy | addUIBulkDownload");
		return result;
	}
	
	/**
	 * The method will down load the Geography Batch Service.
	 * 
	 * 
	 * @return 
	 */
	
	public Boolean geographyBulkDownload(GeoCodeBulkDownloadVO geoCodeBulkDownloadVO) {
		LOGGER.info("entering GeographyWebServiceProxy | geographyBulkDownload");
		String queryParams = "/geographyBulkDownload.service";
					
		HttpEntity<GeoCodeBulkDownloadVO> entity = new HttpEntity<GeoCodeBulkDownloadVO>(geoCodeBulkDownloadVO);		
		Boolean result = null;		
		result = restTemplate.postForObject(
				restWSUtil.getBatchURL(queryParams), entity, Boolean.class);	
		LOGGER.info("exiting GeographyWebServiceProxy | geographyBulkDownload");
		return result;
	}
	
	/**
	 * The method will search the Staging SoR for the UiBulkDownload based on the 
	 * userId and will return the UiBulkDownload entity.
	 * 
	 * @param userId
	 * @return UiBulkDownload
	 */
	@SuppressWarnings("unchecked")
	public List<GeoHierarchy> retrieveGeoUnitHierarchies(Long  geoUnitId) {
		LOGGER.info("entering GeographyWebServiceProxy | retrieveGeoUnitType");
		String queryParams = "/{geoUnitId}/retrieveGeoUnitHierarchies.service";
		
		return restWSUtil.exchangeForList(GeoHierarchy.class, queryParams, geoUnitId);
	}
	
	/**
	 * the method to return all geoUnit Types
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveAllGeoUnitTypes(){
		LOGGER.info("entering GeographyWebServiceProxy | retrieveAllGeoUnitTypes");
		String queryParams = "/retrieveAllGeoUnitTypes.service";
		return restWSUtil.exchangeForList(CodeValue.class, queryParams);
	}
	/**
	 * 
	 * The method to retrieve all applicable GeoUnit Names
	 *
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveApplicableGeoNameTypes(){
		LOGGER.info("entering GeographyWebServiceProxy | retrieveApplicableGeoNameTypes");
		return restWSUtil.exchangeForList(CodeValue.class, "/retrieveApplicableGeoNameTypes.service");
	}
}
