/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;


import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GeoHierarchy;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.entity.GeographySearch;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.GeoBulkUploadVO;
import com.dnb.dsc.refdata.core.vo.GeoCodeBulkDownloadVO;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.interceptor.TransactionLogger;
import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.GeoSearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;
import com.dnb.dsc.refdata.web.util.EhCacheProvider;
import com.dnb.dsc.refdata.web.util.OESServiceUtil;
import com.dnb.dsc.refdata.web.util.UserRoleMapper;

/**
 * The Controller class for Geography Domain. The methods in the class will be
 * mapped as per the UI requests. The UI front controller will redirect to the
 * respective methods based on the request and the request parameters.
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@Controller
@SessionAttributes("geoUnit")
public class GeographyController {

	@Autowired
	private HomeController homeController;

	@Autowired
	private GeographyWebServiceProxy wsProxy;

	@Autowired
	private EhCacheProvider cacheProvider;

	@Autowired
	private UserRoleMapper roleMapper;

	@Autowired
	private RefDataConfigUtil refdataConfig;

	@Autowired
	private TransactionLogger transactionLogger;

	@Autowired
	private SCoTSController scotsController;

	private final String[] geoSearchColumns = { "countryName", "stateName",
			"countyName", "postTownName", "postCode", "countryGeoCode",
			"stateGeoCode", "countyGeoCode", "postTownGeoCode",
	"postCodeGeoCode" };

	private final String[] geoSearchNameColumns = { "geoName",
			"nameTypeDescription", "languageDescription", "geoUnitId" };

	private final String[] geoSearchCodeColumns = { "officialGeoName",
			"geoCode", "geoCodeTypeDescription", "geoUnitId" ,"geoUnitType"};

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(GeographyController.class);

	/**
	 * 
	 * The method is to search the geo unit by name or code. The method will be
	 * invoked when the user hits the Search button in the Geo Name/Code Search
	 * page. The return will be the modelView.
	 *
	 * @param geoType
	 * @param geoSearchString
	 * @param session
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/geoNameCodeSearch.form", method = RequestMethod.GET)
	public ModelAndView geoNameCodeSearch() {
		LOGGER.info("entering and exiting GeographyController | geoNameCodeSearch");
		return new ModelAndView("geoNameCodeSearch");
	}

	/**
	 * The method will search for the Geo Unit based on the Geo Unit Id and will
	 * return the GeoUnit entity.
	 * 
	 * @param geoUnitId
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/geoUnitView.form", method = RequestMethod.GET)
	public ModelAndView geoUnitView(
			@RequestParam(RefDataUIConstants.GEO_UNIT_ID_REQ_PARAM) final String geoUnitId,
			@RequestParam("taskId") final String taskId,
			@RequestParam("source") final String source,
			Model model, HttpSession session) {

		LOGGER.info("entering GeographyController | geoUnitView");
		ModelAndView geoUnitView = new ModelAndView("geoUnitView");
		session.setAttribute("taskId", taskId);
		GeoUnit geoUnitById = null;

		if((taskId != null) && !taskId.trim().isEmpty()){
			geoUnitById = wsProxy.reviewGeoUnitChanges(Long.valueOf(geoUnitId));
		} else {
			geoUnitById = wsProxy.retrieveGeoUnitByGeoUnitId(Long.valueOf(geoUnitId));
		}	

		LOGGER.info("GeographyController | geoUnitView | geoUnit : " + geoUnitById);

		// sort the associations based on the GeoHierarchy
		if (geoUnitById.getParentGeoUnitAssociations() != null 
				&& geoUnitById.getParentGeoUnitAssociations().size() > 0) {
			populateGeoUnitAssociationParentGeoUnit(geoUnitById);
			geoUnitById.setParentGeoUnitAssociations(
					sortGeoUnitAssociations(geoUnitById.getParentGeoUnitAssociations()));
		}

		if(isEmptyCodeList(geoUnitById)){
			geoUnitView.addObject("emptyCodeList", "yes");
		}
		if(isEmptyNameList(geoUnitById)){
			geoUnitView.addObject("emptyNameList", "yes");
		}		
		model.addAttribute("geoUnit",populateEmptyNameCodeRows(geoUnitById));
		getGeoSearchCountryList(session);		

		// Populating request object with code values
		List<Integer> codeTableIds = new ArrayList<Integer>();
		// codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_INFO_SOURCES);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_UNIT_TYPE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_CODE_TYPE);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);

		tempCodeValueMap.put(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE),
				wsProxy.retrieveApplicableGeoNameTypes());

		// set the code values to the view object
		geoUnitView.addObject(
				"nameTypeCodeValue",
				tempCodeValueMap.get(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE)));
		geoUnitView.addObject(
				"languageCodeValues", 
				tempCodeValueMap.get(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));
		geoUnitView.addObject(
				"dataProviderCodeValues",
				tempCodeValueMap.get(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INFO_SOURCES)));
		geoUnitView.addObject(
				"geoUnitTypeCodeValues",
				tempCodeValueMap.get(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_UNIT_TYPE)));
		geoUnitView.addObject(
				"geoCodeTypeCodeValues",
				tempCodeValueMap.get(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_CODE_TYPE)));

		populateGeoUnitWithCodeValDescriptions(geoUnitById, tempCodeValueMap);
		session.setAttribute("geoUnitInDB", getGeoUnitInDB(geoUnitById));
		session.setAttribute("tempCodeValueMap", sortCodeValuesById(tempCodeValueMap));

		// setting the default language for the GeoUnit
		geoUnitView.addObject("geoDefaultLanguage", findGeoDefaultLanguageCode(geoUnitById));
		geoUnitView.addObject("geoRange",OESServiceUtil.getGeoTypeMap());
		model.addAttribute("controlFlow", "country");
		model.addAttribute("source", source);
		return geoUnitView;
	}

	/**
	 * 
	 * The method to populate the code values in the GeoUnit entity with the
	 * respective descriptions. This is added to improve the performance of the page rendering.
	 * 
	 * @param geoUnitById
	 * @param tempCodeValueMap
	 */
	@SuppressWarnings("rawtypes")
	private void populateGeoUnitWithCodeValDescriptions(GeoUnit geoUnitById,
			Map<String, List<CodeValue>> tempCodeValueMap) {
		LOGGER.info("entering GeographyController | populateGeoUnitWithCodeValDescriptions");
		List<CodeValue> languages = tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE));
		List<CodeValue> nameTypes = tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE));
		List<CodeValue> infoSrces = tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INFO_SOURCES));
		List<CodeValue> codeTypes = tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_CODE_TYPE));

		// iterating through the list of geo unit names and comparing the code table entries
		if (geoUnitById.getGeoUnitNames() != null) {
			for (GeoUnitName geoUnitName : geoUnitById.getGeoUnitNames()) {
				// language field
				Iterator languageItr = languages.iterator();
				while (languageItr.hasNext()) {
					LinkedHashMap langHashMap = (LinkedHashMap) languageItr.next();
					if (geoUnitName.getLanguageCode().equals(Long.valueOf((Integer) langHashMap.get("codeValueId")))) {
						geoUnitName.setLanguageDescription(String.valueOf(langHashMap.get("codeValueDescription")));
					}
				}
				// name type code field
				Iterator nameTypeItr = nameTypes.iterator();
				while (nameTypeItr.hasNext()) {
					LinkedHashMap nmeTypeHashMap = (LinkedHashMap) nameTypeItr.next();
					if (geoUnitName.getNameTypeCode().equals(Long.valueOf((Integer) nmeTypeHashMap.get("codeValueId")))) {
						geoUnitName.setNameTypeDescription(String.valueOf(nmeTypeHashMap.get("codeValueDescription")));
					}
				}
				// data provider field
				Iterator infoSrcItr = infoSrces.iterator();
				while (infoSrcItr.hasNext()) {
					LinkedHashMap infoSrcHashMap = (LinkedHashMap) infoSrcItr.next();
					if (geoUnitName.getDataProviderCode().equals(
							Long.valueOf((Integer) infoSrcHashMap.get("codeValueId")))) {
						geoUnitName.setDataProviderDescription(String.valueOf(infoSrcHashMap
								.get("codeValueDescription")));
					}
				}
			}
		}

		if (geoUnitById.getGeoUnitCodes() != null) {		
			for (GeoUnitCode geoUnitCode : geoUnitById.getGeoUnitCodes()) {
				// geo code type field
				if(codeTypes != null) {
					Iterator codeTypeItr = codeTypes.iterator();
					while (codeTypeItr.hasNext()) {
						LinkedHashMap cdTypeHashMap = (LinkedHashMap) codeTypeItr.next();
						if (geoUnitCode.getGeoCodeTypeCode() != null && geoUnitCode.getGeoCodeTypeCode().equals(
								Long.valueOf((Integer) cdTypeHashMap.get("codeValueId")))) {
							geoUnitCode.setGeoCodeTypeDescription(String
									.valueOf(cdTypeHashMap.get("codeValueDescription")));
						}
					}
				}
				// data provider field
				Iterator infoSrcItr = infoSrces.iterator();
				while (infoSrcItr.hasNext()) {
					LinkedHashMap infoSrcHashMap = (LinkedHashMap) infoSrcItr.next();
					if (geoUnitCode.getDataProviderCode() != null && geoUnitCode.getDataProviderCode().equals(
							Long.valueOf((Integer) infoSrcHashMap.get("codeValueId")))) {
						geoUnitCode.setDataProviderDescription(String.valueOf(infoSrcHashMap
								.get("codeValueDescription")));
					}
				}
			}
		}
		LOGGER.info("GeographyController | populateGeoUnitWithCodeValDescriptions | returning : " + geoUnitById);
		LOGGER.info("exiting GeographyController | populateGeoUnitWithCodeValDescriptions ");
	}

	/**
	 * 
	 * The method to populate the Code Tables drop down in the Geo Unit View page
	 *
	 * @param session
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "retrieveCodeValuesForGeoView.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, List<CodeValue>> retrieveCodeValuesForGeoView(HttpSession session) {
		return (Map<String, List<CodeValue>>)session.getAttribute("tempCodeValueMap");
	}

	/**
	 * 
	 * The method to retrieve the parent geo unit associations for a geo unit. 
	 *
	 * @param geoUnitById
	 */
	@SuppressWarnings("rawtypes")
	public void populateGeoUnitAssociationParentGeoUnit(GeoUnit geoUnitById) {
		LOGGER.info("entering GeographyController | populateGeoUnitAssociationParentGeoUnit");

		List<Long> parentGeoUnitIdList = new ArrayList<Long>();
		for(GeoUnitAssociation currAssn : geoUnitById.getParentGeoUnitAssociations()){
			parentGeoUnitIdList.add(currAssn.getParentGeoUnitId());
		}

		Map<Long, ?> parentGeoUnitMap = wsProxy.retrieveGeoUnitsByIdList(parentGeoUnitIdList);
		Long defaultLanguageCode = findGeoDefaultLanguageCode(geoUnitById);
		LinkedHashMap linkedHashMapGeoUnit = null;
		List geoUnitListById = null;
		Long officialLanguageCode = null; 

		for (GeoUnitAssociation currAssn : geoUnitById.getParentGeoUnitAssociations()) {

			GeoUnit parentGeoUnit = null;
			geoUnitListById = (List) parentGeoUnitMap.get(String.valueOf(currAssn.getParentGeoUnitId()));
			Iterator geoUnitIterator = geoUnitListById.iterator();
			/*
			 * Iterate through the list of parent associations and identify the
			 * parent GeoUnit in the country's official language
			 */
			while (geoUnitIterator.hasNext()) {
				linkedHashMapGeoUnit = (LinkedHashMap) geoUnitIterator.next();
				officialLanguageCode = Long.valueOf((Integer) linkedHashMapGeoUnit.get("officialLanguageCode"));
				if (officialLanguageCode.equals(defaultLanguageCode)) {
					parentGeoUnit = populateParentGeoUnit(linkedHashMapGeoUnit);
					break;
				}
			}

			/*
			 * If no entry with default language identified then Iterate through
			 * the list of parent associations and identify the parent GeoUnit
			 * in the English language
			 */
			if (parentGeoUnit == null) {
				geoUnitIterator = geoUnitListById.iterator();
				while (geoUnitIterator.hasNext()) {
					linkedHashMapGeoUnit = (LinkedHashMap) geoUnitIterator.next();
					officialLanguageCode = Long.valueOf((Integer) linkedHashMapGeoUnit.get("officialLanguageCode"));
					if (officialLanguageCode.equals(RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH)) {
						parentGeoUnit = populateParentGeoUnit(linkedHashMapGeoUnit);
						break;
					}
				}
			}
			/*
			 * If the parentGeoUnit is still null then fetch the details for any
			 * language code.
			 */
			if (parentGeoUnit == null) {
				geoUnitIterator = geoUnitListById.iterator();
				while (geoUnitIterator.hasNext()) {
					linkedHashMapGeoUnit = (LinkedHashMap) geoUnitIterator.next();
					parentGeoUnit = populateParentGeoUnit(linkedHashMapGeoUnit);
					break;
				}
			}
			currAssn.setParentGeoUnit(parentGeoUnit);
		}
	}

	/**
	 * 
	 * The method to populate the parent geo unit
	 *
	 * @param linkedHashMapGeoUnit
	 * @return GeoUnit
	 */
	@SuppressWarnings({"rawtypes"})
	private GeoUnit populateParentGeoUnit(LinkedHashMap linkedHashMapGeoUnit) {
		return new GeoUnit(
				Long.valueOf(linkedHashMapGeoUnit.get("geoUnitId").toString()),
				((Integer)linkedHashMapGeoUnit.get("geoUnitTypeCode")).longValue(),
				(String)linkedHashMapGeoUnit.get("officialGeoName"),
				((Integer)linkedHashMapGeoUnit.get("officialLanguageCode")).longValue()
				);
	}

	/**
	 * The method will persist the existing Geo Unit data in the Transaction DB.
	 * Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param geoUnit
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/geoUnitUpdate.form", method = RequestMethod.POST)
	public View geoUnitUpdate(@ModelAttribute("geoUnit") GeoUnit geoUnit,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session, HttpServletRequest request)
					throws ParseException {

		LOGGER.info("entering GeographyController | geoUnitUpdate");
		System.out.println( geoUnit); 

		//audit variables
		Date startTime = new Date();

		UserContextVO userContextVO = (UserContextVO) session.getAttribute(
				RefDataUIConstants.REFDATA_USER_CONTEXT);
		GeoUnit geoUnitInDB = (GeoUnit)session.getAttribute("geoUnitInDB");
		session.removeAttribute("geoUnitInDB");

		// For updating Country Group details, it is needed to set geo unit
		// codes and parent geo unit associations to null.
		if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY_GROUP
				.equals(geoUnit.getGeoUnitTypeCode())) {
			LOGGER.info("Setting list of geo unit codes to null for Country group... ");
			geoUnit.setGeoUnitCodes(null);
			geoUnit.setParentGeoUnitAssociations(null);
		}

		Long countryGeoUnitId = findCountryGeoUnitId(geoUnit);
		Long domainId = wsProxy.updateGeoUnit(removeEmptyList(geoUnit, geoUnitInDB, userContextVO.getUserIdentifier()));

		System.out.println(  geoUnit); 
		// Invoke the Workflow service to create/resubmit the workflow task for
		// the update operation. This will be invoked as a web service call.
		String taskId = (String) session.getAttribute("taskId");
		if (taskId != null && !taskId.trim().isEmpty()) {
			Long submitterGroupId = roleMapper.getSubmitterUserGroupId(
					RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
					countryGeoUnitId);
			submitterGroupId = submitterGroupId.equals(0L) ? 
					roleMapper.getSubmitterUserGroupId(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY, 0L)
					: submitterGroupId;	
					homeController.reSubmitTaskRequest(
							userContextVO,
							taskId, RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
							submitterGroupId);
		} else {
			createNewGeoWorkflowTask(
					domainId,
					countryGeoUnitId,
					RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_GEO_UNIT,
					(UserContextVO) session
					.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT), 
					findOfficialGeoName(geoUnitInDB, countryGeoUnitId));
		}
		sessionStatus.setComplete();		
		LOGGER.info("exiting GeographyController | geoUnitUpdate");

		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				"geoUnitUpdate", 0L, domainId, 0L, geoUnit);

		return new RedirectView("submitterWorkQueueHome.form?domainName=Geography");
	}

	private List<GeoUnitCode> getCodeListInDB(GeoUnit geoUnitById){
		List<GeoUnitCode> codeListInDB = new ArrayList<GeoUnitCode>();
		if(geoUnitById.getGeoUnitCodes() != null){
			for(GeoUnitCode currGeoUnitCode : geoUnitById.getGeoUnitCodes()){
				GeoUnitCode newGeoUnitCode = new GeoUnitCode();
				newGeoUnitCode.setGeoUnitCodeId(currGeoUnitCode.getGeoUnitCodeId());
				newGeoUnitCode.setExpiredByDate(currGeoUnitCode.getExpiredByDate());
				codeListInDB.add(newGeoUnitCode);
			}
		}
		return codeListInDB;
	}

	private List<GeoUnitName> getNameListInDB(GeoUnit geoUnitById){		
		List<GeoUnitName> nameListInDB = new ArrayList<GeoUnitName>();
		if(geoUnitById.getGeoUnitNames() != null){
			for(GeoUnitName currGeoUnitName : geoUnitById.getGeoUnitNames()){
				GeoUnitName newGeoUnitName = new GeoUnitName();
				newGeoUnitName.setGeoUnitNameId(currGeoUnitName.getGeoUnitNameId());
				newGeoUnitName.setNameTypeCode(currGeoUnitName.getNameTypeCode());
				newGeoUnitName.setGeoName(currGeoUnitName.getGeoName());
				newGeoUnitName.setLanguageCode(currGeoUnitName.getLanguageCode());
				newGeoUnitName.setExpiredByDate(currGeoUnitName.getExpiredByDate());
				nameListInDB.add(newGeoUnitName);
			}
		}
		return nameListInDB;
	}
	/**
	 * 
	 * TODO
	 *
	 * @param geoUnitById
	 * @param isParent
	 * @return
	 */
	private List<GeoUnitAssociation> getAssociationListInDB(GeoUnit geoUnitById, boolean isParent){		
		List<GeoUnitAssociation> parentListInDB = new ArrayList<GeoUnitAssociation>();
		List<GeoUnitAssociation> iterableAssociation = null;
		if(isParent) {
			if(geoUnitById.getParentGeoUnitAssociations() != null){
				iterableAssociation = geoUnitById.getParentGeoUnitAssociations();
			}
		} else {
			if(geoUnitById.getChildGeoUnitAssociations() != null){
				iterableAssociation = geoUnitById.getChildGeoUnitAssociations();
			}
		}
		if(iterableAssociation != null) {
			for(GeoUnitAssociation currGeoUnitAssociation : iterableAssociation){
				GeoUnitAssociation newGeoUnitAssociation = new GeoUnitAssociation();
				newGeoUnitAssociation.setGeoUnitAssociationId(currGeoUnitAssociation.getGeoUnitAssociationId());
				newGeoUnitAssociation.setParentGeoUnitId(currGeoUnitAssociation.getParentGeoUnitId());
				newGeoUnitAssociation.setChildGeoUnitId(currGeoUnitAssociation.getChildGeoUnitId());
				newGeoUnitAssociation.setEffectiveDate(currGeoUnitAssociation.getEffectiveDate());
				newGeoUnitAssociation.setExpiredByDate(currGeoUnitAssociation.getExpiredByDate());
				parentListInDB.add(newGeoUnitAssociation);
			}
		}
		return parentListInDB;
	}

	private GeoUnit getGeoUnitInDB(GeoUnit geoUnitById){
		GeoUnit geoUnitInDB = new GeoUnit();
		geoUnitInDB.setGeoUnitCodes(getCodeListInDB(geoUnitById));
		geoUnitInDB.setGeoUnitNames(getNameListInDB(geoUnitById));
		geoUnitInDB.setParentGeoUnitAssociations(getAssociationListInDB(geoUnitById, true));
		geoUnitInDB.setChildGeoUnitAssociations(getAssociationListInDB(geoUnitById, false));
		return geoUnitInDB;
	}

	/**
	 * Deletes the geoUnit entity corresponds to the geoUnitId passed from the
	 * ViewGeoUnit page.
	 * <p>
	 * 
	 * @param geoUnit
	 * @param result
	 *            , BindlingResult
	 * @param model
	 * @param session
	 * 
	 */
	@RequestMapping(value = "/geoUnitDelete.form", method = RequestMethod.POST)
	public View geoUnitDelete(
			@ModelAttribute("geoUnit") GeoUnit geoUnit,
			BindingResult result, Model model, HttpSession session, SessionStatus sessionStatus) {

		LOGGER.info("entering GeographyController | geoUnitDelete");
		LOGGER.info("Geo Unit ID : " + geoUnit.getGeoUnitId());
		//audit variables
		Date startTime = new Date();

		// For updating Country Group details, it is needed to set geo unit
		// codes and parent GeoUnit associations to null.
		if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY_GROUP
				.equals(geoUnit.getGeoUnitTypeCode())) {
			LOGGER.info("Setting list of geo unit codes to null for Country group... ");
			geoUnit.setGeoUnitCodes(null);
			geoUnit.setParentGeoUnitAssociations(null);
		}

		Long countryGeoUnitId = findCountryGeoUnitId(geoUnit);	

		Long geoUnitId = wsProxy.deleteGeoUnitById(geoUnit);
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);

		// Invoke the Workflow service to create the workflow task for the
		// update operation. This will be invoked as a web service call.
		createNewGeoWorkflowTask(geoUnit.getGeoUnitId(), countryGeoUnitId,
				RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_GEO_UNIT,
				userContextVO, findOfficialGeoName(geoUnit, countryGeoUnitId));

		sessionStatus.setComplete();

		LOGGER.info("exiting GeographyController | geoUnitDelete");

		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				"geoUnitDelete", 0L, geoUnitId, 0L, geoUnit);	

		return new RedirectView("submitterWorkQueueHome.form?domainName=Geography");
	}

	/**
	 * 
	 * The method will load the geography search home page. The method will
	 * retrieve all countries information to populate in the screen.
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/geoSearchHome.form", method = RequestMethod.GET)
	public ModelAndView getGeoSearchHome() {
		LOGGER.info("entering GeographyController | getGeoSearchHome");
		ModelAndView geoSearchHomeModelAndView = new ModelAndView(
				"geoSearchHome");
		geoSearchHomeModelAndView.addObject(
				RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION,
				getCountryList());		
		LOGGER.info("exiting GeographyController | getGeoSearchHome");
		return geoSearchHomeModelAndView;
	}

	/**
	 * 
	 * This method is invoked by datatables plugin through Ajax calls.
	 * Response is provided in JSON format.
	 * 
	 * @param geoSearchCriteria
	 * @param result
	 * @param response
	 * @param session
	 * @return List of GeographySearch
	 */
	@RequestMapping(value = "/geoSearchAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getGeoSearchAjaxResults(HttpServletRequest request, HttpSession session){
		LOGGER.info("entering GeographyController | getGeoSearchAjaxResults");		
		//audit variables
		Date startTime = new Date();

		GeoSearchCriteriaVO geoSearchCriteria = getGeoSearchCriteria(request);
		if(geoSearchCriteria.getCountryGeoCode() == null ||
				(geoSearchCriteria.getCountryGeoCode() != null &&
				geoSearchCriteria.getCountryGeoCode().trim().isEmpty())){
			return homeController.getJsonMap(request,new ArrayList<Object>(), 0L, geoSearchColumns);
		}
		// Get the count results from the session. The countResults will be
		// reset for all search button clicks
		Long countResults = (Long)session.getAttribute("countResults");
		if((countResults == null) || (geoSearchCriteria.getRowIndex() == 0)) {
			countResults = wsProxy.countSearchGeographies(geoSearchCriteria);
			session.setAttribute("countResults", countResults);
		}

		// transaction logging 
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);		
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				"getGeoSearchResults", 0L, geoSearchCriteria, 0L);	

		return homeController.getJsonMap(request, 
				wsProxy.searchGeographies(geoSearchCriteria), countResults, geoSearchColumns);
	}

	/**
	 * 
	 * The method will construct the geoSearchCriteria
	 *
	 * @param request
	 * @return geoSearchCriteria
	 */
	private GeoSearchCriteriaVO getGeoSearchCriteria(HttpServletRequest request){
		GeoSearchCriteriaVO geoSearchCriteria = new GeoSearchCriteriaVO();
		geoSearchCriteria.setSortOrder(homeController.getSortOrder(request));
		geoSearchCriteria.setSortBy(homeController.getSortBy(request, geoSearchColumns));
		geoSearchCriteria.setMaxResults(homeController.getMaxResults(request));
		geoSearchCriteria.setRowIndex(homeController.getStartIndex(request));
		String compositeSearchString = homeController.getSearchString(request);
		// Search string will be in the format
		// 1073#~999393379#~county#~town#~zip
		String searchCriteriaDelimiter = "~";
		if(compositeSearchString != null){
			compositeSearchString = compositeSearchString.replace('%', '*');
			String[] splitCriteria = compositeSearchString
					.split(searchCriteriaDelimiter);
			if(splitCriteria.length > 0){
				if(!(splitCriteria[0].replace("#", "").trim().isEmpty())){
					geoSearchCriteria.setCountryGeoCode(splitCriteria[0]
							.replace("#", "").trim());
				}
			}
			if(splitCriteria.length > 1){
				if(!(splitCriteria[1].replace("#", "").trim().isEmpty())){
					geoSearchCriteria.setStateGeoCode(splitCriteria[1].replace(
							"#", "").trim());
				}
			}
			if(splitCriteria.length > 2){
				if(!(splitCriteria[2].replace("#", "").trim().isEmpty())){
					geoSearchCriteria.setCountyName(splitCriteria[2].replace(
							"#", "").trim());
				}
			}
			if(splitCriteria.length > 3){
				if(!(splitCriteria[3].replace("#", "").trim().isEmpty())){
					geoSearchCriteria.setPostTownName((splitCriteria[3]
							.replace("#", "").trim()));
				}
			}
			if(splitCriteria.length > 4){
				if(!(splitCriteria[4].replace("#", "").trim().isEmpty())){
					geoSearchCriteria.setPostCode((splitCriteria[4].replace(
							"#", "").trim()));
				}
			}
		}
		LOGGER.info("GeographyController | getGeoSearchCriteria | geoSearchCriteria : " + geoSearchCriteria);		
		return geoSearchCriteria;
	}

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	private List<CodeValueVO> getCountryList() {
		return this.wsProxy.retrieveAllCountries(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
	}

	/**
	 * Loads the Geography Country Group search home page.
	 * <p>
	 * Retrieves all the country group information to be populated in the search
	 * page.
	 * <p>
	 * 
	 * @param model
	 * @param session
	 * @return Model and View
	 */
	@RequestMapping(value = "/countryGroupSearchHome.form", method = RequestMethod.GET)
	public ModelAndView getCountryGroupSearchHome(Model model,
			HttpSession session) {
		LOGGER.info("entering GeographyController | getCountryGroupSearchHome");
		ModelAndView countryGroupSearchHomeModelAndView = new ModelAndView(
				"countryGroupSearch");

		List<CodeValueVO> countryGroupList = null;
		if (session.getAttribute(RefDataUIConstants.GEO_SEARCH_COUNTRY_GROUP_LIST_SESSION) == null) {
			countryGroupList = wsProxy
					.retrieveAllCountryGroups(
							RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
							RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			session.setAttribute(
					RefDataUIConstants.GEO_SEARCH_COUNTRY_GROUP_LIST_SESSION,
					countryGroupList);
		}

		LOGGER.info("exiting GeographyController | getCountryGroupSearchHome");
		return countryGroupSearchHomeModelAndView;
	}

	/**
	 * Retrieves all the country groups search results.
	 * <p>
	 * The List of country groups will be displayed in the Search Results page.
	 * <p>
	 * 
	 * @param countryCode
	 * @param session
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/countryGroupSearch.form", method = RequestMethod.GET)
	public ModelAndView searchCountryGroups(
			@RequestParam(RefDataUIConstants.GEO_UNIT_ID_REQ_PARAM) final Long geoUnitId,
			HttpSession session) {
		LOGGER.info("entering GeographyController | searchCountryGroups");
		Date startTime = new Date();

		ModelAndView countryGroupModelAndView = new ModelAndView(
				"countryGroupSearch");
		List<CodeValueVO> countryGroupList = null;
		if (session.getAttribute(
				RefDataUIConstants.GEO_SEARCH_COUNTRY_GROUP_LIST_SESSION) == null) {
			countryGroupList = wsProxy
					.retrieveAllCountryGroups(
							RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
							RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			session.setAttribute(
					RefDataUIConstants.GEO_SEARCH_COUNTRY_GROUP_LIST_SESSION,
					countryGroupList);
		}
		countryGroupModelAndView
		.addObject("countryGroupList", countryGroupList);

		countryGroupModelAndView
		.addObject(
				"listOfCountryGroups",
				wsProxy.searchCountryGroups(
						RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH,
						RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN,
						RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
						geoUnitId));

		countryGroupModelAndView.addObject("geoUnitId", geoUnitId);

		// transaction logging 
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);		
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				"searchCountryGroups", 0L, geoUnitId, 0L);	

		LOGGER.info("exiting GeographyController | searchCountryGroups");
		return countryGroupModelAndView;
	}

	/**
	 * Displays all the Geographic information corresponds to the Country Group.
	 * <p>
	 * The user can edit the country group details using the information.
	 * <p>
	 * 
	 * @param geoUnitId
	 * @param model
	 * @return countryGroupView, the ModelAndView
	 */
	@RequestMapping(value = "/countryGroupView.form", method = RequestMethod.GET)
	public ModelAndView countryGroupView(
			@RequestParam(RefDataUIConstants.GEO_UNIT_ID_REQ_PARAM) final String geoUnitId,
			@RequestParam("taskId") final String taskId,
			@RequestParam("source") final String source,
			Model model, HttpSession session) {
		LOGGER.info("entering GeographyController | countryGroupView");

		ModelAndView countryGroupView = new ModelAndView("countryGroupView");
		GeoUnit geoUnitById = wsProxy.retrieveGeoUnitByGeoUnitId(Long
				.valueOf(geoUnitId));

		if (isEmptyCodeList(geoUnitById)) {
			countryGroupView.addObject("emptyCodeList", "yes");
		}
		if (isEmptyNameList(geoUnitById)) {
			countryGroupView.addObject("emptyNameList", "yes");
		}
		model.addAttribute("geoUnit", populateEmptyNameCodeRows(geoUnitById));
		getGeoSearchCountryList(session);

		// Populating request object with code values
		List<Integer> codeTableIds = new ArrayList<Integer>();
		//codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_INFO_SOURCES);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_UNIT_TYPE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_CODE_TYPE);
		Map<String, List<CodeValue>> tempCodeValueMap = 
				homeController.retrieveCodeValues(codeTableIds);


		tempCodeValueMap.put(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE),
				wsProxy.retrieveApplicableGeoNameTypes());

		// set the code values to the view object
		countryGroupView
		.addObject(
				"nameTypeCodeValue",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE)));
		countryGroupView
		.addObject(
				"languageCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));
		countryGroupView
		.addObject(
				"dataProviderCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INFO_SOURCES)));
		countryGroupView
		.addObject(
				"geoUnitTypeCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_UNIT_TYPE)));
		countryGroupView
		.addObject(
				"geoCodeTypeCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_CODE_TYPE)));

		// for OES integration
		countryGroupView.addObject("geoRange",OESServiceUtil.getGeoTypeMap());
		populateGeoUnitWithCodeValDescriptions(geoUnitById, tempCodeValueMap);
		session.setAttribute("geoUnitInDB", getGeoUnitInDB(geoUnitById));
		session.setAttribute("taskId", taskId);
		session.setAttribute("tempCodeValueMap", sortCodeValuesById(tempCodeValueMap));
		model.addAttribute("controlFlow", "countryGroup");
		model.addAttribute("source", source);

		LOGGER.info("Exiting GeographyController| countryGroupView");
		return countryGroupView;
	}

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@RequestMapping(value = "retrieveChildGeoUnitsForCountry.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveChildGeoUnitsForCountry(
			@RequestParam(value = "parentGeoUnitId", required = true) Long parentGeoUnitId) {
		LOGGER.info("entering GeographyController | retrieveChildGeoUnitsForCountry");
		return this.wsProxy.retrieveChildGeoUnitsByType(
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH,
				RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_TERRITORY,
				parentGeoUnitId,
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL);
	}

	/**
	 * 
	 * The method will retrieve all child details from the Search DB based on
	 * the parent id, name type code and the user preferred language code. The
	 * return type is a VO which contains the child Geo Unit Id and the Name.
	 * 
	 * @param parentGeoUnitId
	 * @param childGeoUnitType
	 * @param countryGeoUnitId
	 * @return,
	 */
	@RequestMapping(value = "retrieveChildGeoUnits.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveChildGeoUnits(
			@RequestParam(value = "parentGeoUnitId") Long parentGeoUnitId, 
			@RequestParam(value = "childGeoUnitType") Long childGeoUnitType,
			@RequestParam(value = "countryGeoUnitId") Long countryGeoUnitId, 
			HttpSession session) {
		LOGGER.info("entering GeographyController | retrieveChildGeoUnits");
		Date startTime = new Date();

		LOGGER.info("parentGeoUnitId : " + parentGeoUnitId);
		LOGGER.info("childGeoUnitType : " + childGeoUnitType);
		LOGGER.info("countryGeoUnitId : " + countryGeoUnitId);
		List<CodeValueVO> codeValueVOs = this.wsProxy.retrieveChildGeoUnitsByType(
				iterateCountryDefaultConfiguration(countryGeoUnitId),
				childGeoUnitType, parentGeoUnitId,
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL);

		// transaction logging 
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);		
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				"retrieveChildGeoUnits", 0L, codeValueVOs, 0L, parentGeoUnitId, childGeoUnitType, countryGeoUnitId);	

		LOGGER.info("exiting GeographyController | retrieveChildGeoUnits | returned : " + codeValueVOs);
		return codeValueVOs;
	}

	/**
	 * 
	 * The method will validate the Geo Unit for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param geoUnit
	 * @return boolean
	 */
	@RequestMapping(value = "lockGeoUnitForEdit.form", method = RequestMethod.GET)
	public @ResponseBody
	String lockGeoUnit(@ModelAttribute("geoUnit") GeoUnit geoUnit) {
		LOGGER.info("entering GeographyController | lockGeoUnit");
		Long lockGeoUnitId = geoUnit.getGeoUnitId();
		return this.wsProxy.lockGeoUnit(lockGeoUnitId);
	}

	/**
	 * 
	 * The method will load the Add Geo Unit page with the required drop down
	 * values. The method is invoked only on screen load.
	 * 
	 * @param model
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/loadAddGeoUnit.form", method = RequestMethod.GET)
	public ModelAndView loadAddGeoUnit(Model model) {
		LOGGER.info("entering GeographyController | addGeoUnit");
		ModelAndView geoUnitAddModelAndView = new ModelAndView("addGeoUnit");

		// Populating request object with code values
		List<Integer> codeTableIds = new ArrayList<Integer>();
		//codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_INFO_SOURCES);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_CODE_TYPE);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController.retrieveCodeValues(codeTableIds);

		tempCodeValueMap.put(String.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE),
				wsProxy.retrieveApplicableGeoNameTypes());

		// set the code values to the view object
		geoUnitAddModelAndView.addObject(
				"nameTypeCodeValue",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE)));
		geoUnitAddModelAndView.addObject("languageCodeValues", tempCodeValueMap.get(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));
		geoUnitAddModelAndView.addObject(
				"dataProviderCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INFO_SOURCES)));
		geoUnitAddModelAndView.addObject(
				"geoUnitTypeCodeValues",
				retrieveAllGeoUnitTypes());
		geoUnitAddModelAndView.addObject(
				"geoCodeTypeCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_CODE_TYPE)));
		geoUnitAddModelAndView.addObject("geoRange",OESServiceUtil.getGeoTypeMap());
		GeoUnit requestGeoUnit = new GeoUnit();
		requestGeoUnit.setGeoUnitId(0L);
		model.addAttribute("geoUnit", populateEmptyNameCodeRows(requestGeoUnit));

		LOGGER.info("exiting GeographyController | addGeoUnit");
		return geoUnitAddModelAndView;
	}

	/**
	 * 
	 * 
	 *
	 * @param geoUnit
	 * @return geoUnit
	 */
	private GeoUnit populateEmptyNameCodeRows(GeoUnit geoUnit) {
		if (isEmptyNameList(geoUnit)) {
			GeoUnitName emptyGeoUnitName = new GeoUnitName();
			List<GeoUnitName> emptyGeoUnitNameList = new ArrayList<GeoUnitName>();
			emptyGeoUnitNameList.add(emptyGeoUnitName);
			geoUnit.setGeoUnitNames(emptyGeoUnitNameList);
		}

		if (isEmptyCodeList(geoUnit)) {
			GeoUnitCode emptyGeoUnitCode = new GeoUnitCode();
			List<GeoUnitCode> emptyGeoUnitCodeList = new ArrayList<GeoUnitCode>();
			emptyGeoUnitCodeList.add(emptyGeoUnitCode);
			geoUnit.setGeoUnitCodes(emptyGeoUnitCodeList);
		}
		//		Commented as a fix to QC issue #72			
		//		if(isEmptyChildList(geoUnit)){
		//			GeoUnitAssociation emptyGeoUnitAssociation = new GeoUnitAssociation();
		//			List<GeoUnitAssociation> emptyGeoUnitAssociationList = new ArrayList<GeoUnitAssociation>();
		//			emptyGeoUnitAssociationList.add(emptyGeoUnitAssociation);
		//			geoUnit.setChildGeoUnitAssociations(emptyGeoUnitAssociationList);
		//		}
		//		Commented as a fix to QC issue #72		
		//		if(isEmptyParentList(geoUnit)){
		//			GeoUnitAssociation emptyGeoUnitAssociation = new GeoUnitAssociation();
		//			List<GeoUnitAssociation> emptyGeoUnitAssociationList = new ArrayList<GeoUnitAssociation>();
		//			emptyGeoUnitAssociationList.add(emptyGeoUnitAssociation);
		//			geoUnit.setParentGeoUnitAssociations(emptyGeoUnitAssociationList);
		//		}
		return geoUnit;
	}

	private boolean isEmptyNameList(GeoUnit geoUnit) {
		if(geoUnit.getGeoUnitNames() == null || 
				(geoUnit.getGeoUnitNames() != null && geoUnit.getGeoUnitNames().isEmpty())){
			return true;
		} else {
			return false;
		}
	}

	private boolean isEmptyCodeList(GeoUnit geoUnit) {
		if(geoUnit.getGeoUnitCodes() == null || 
				(geoUnit.getGeoUnitCodes() != null && geoUnit.getGeoUnitCodes().isEmpty())){
			return true;
		} else {
			return false;
		}
	}

	//	private boolean isEmptyChildList(GeoUnit geoUnit) {
	//		if (geoUnit.getChildGeoUnitAssociations() == null
	//				|| (geoUnit.getChildGeoUnitAssociations() != null && geoUnit
	//						.getChildGeoUnitAssociations().isEmpty())) {
	//			return true;
	//		} else {
	//			return false;
	//		}
	//	}
	//
	//	private boolean isEmptyParentList(GeoUnit geoUnit) {
	//		if (geoUnit.getParentGeoUnitAssociations() == null
	//				|| (geoUnit.getParentGeoUnitAssociations() != null && geoUnit
	//						.getParentGeoUnitAssociations().isEmpty())) {
	//			return true;
	//		} else {
	//			return false;
	//		}
	//	}

	/**
	 * The method will persist the Geo Unit data in the Transactional
	 * DB.
	 * 
	 * @param geoUnit
	 *            model attribute
	 * @param result
	 * @param session
	 * @return View
	 * @throws ParseException 
	 */
	@RequestMapping(value = "/saveGeoUnit.form", method = RequestMethod.POST)
	public View saveGeoUnit(@ModelAttribute("geoUnit") GeoUnit geoUnit,
			BindingResult result, HttpSession session){
		LOGGER.info("entering GeographyController | saveGeoUnit");

		//audit variables
		Date startTime = new Date();

		UserContextVO userContextVO = (UserContextVO) session.getAttribute(
				RefDataUIConstants.REFDATA_USER_CONTEXT);

		Long domainId = wsProxy.insertGeoUnit(removeEmptyList(geoUnit, null, userContextVO.getUserIdentifier()));

		geoUnit.setGeoUnitId(domainId);
		Long countryGeoUnitId = findCountryGeoUnitId(geoUnit);

		// Invoke the Workflow service to create the workflow task for the
		// insert operation.
		createNewGeoWorkflowTask(domainId, countryGeoUnitId, 
				RefDataChangeTypeConstants.CHANGE_TYPE_ADD_GEO_UNIT,
				userContextVO, findOfficialGeoName(geoUnit, countryGeoUnitId));	

		// transaction logging 		
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				"saveGeoUnit", 0L, domainId, 0L, geoUnit);			

		LOGGER.info("exiting GeographyController | saveGeoUnit");
		return new RedirectView("submitterWorkQueueHome.form?domainName=Geography");
	}

	/**
	 * The method will retrieve all Country details from the Search DB. The
	 * return type is a VO which contains the Country Geo Unit Id and the
	 * Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@RequestMapping(value = "retrieveCountryList.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveCountryList() {
		LOGGER.info("entering GeographyController | retrieveCountryList");
		return getCountryList();
	}

	/**
	 * The method will retrieve all Continent details from the Search DB. The
	 * return type is a VO which contains the Continent Geo Unit Id and the
	 * Continent Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@RequestMapping(value = "retrieveContinentList.form", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveContinentList() {
		LOGGER.info("entering GeographyController | retrieveContinentList");
		return this.wsProxy.retrieveAllContinents(
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL, 
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
	}

	/**
	 * 
	 * The method to remove the empty list from the GeoUnit entity
	 *
	 * @param geoUnit
	 * @param geoUnitInDB
	 * @param userId
	 * @return geoUnit
	 */
	private GeoUnit removeEmptyList(GeoUnit geoUnit, GeoUnit geoUnitInDB, String userId){
		if (geoUnit.getGeoUnitId() == 0) {
			geoUnit.setEffectiveDate(new Date());
			geoUnit.setCreatedDate(new Date());
			geoUnit.setCreatedUser(userId);
		}
		if (geoUnit.getParentGeoUnitAssociations() != null
				&& geoUnit.getParentGeoUnitAssociations().size() == 1) {
			GeoUnitAssociation currGeoUnitAssociation = geoUnit.getParentGeoUnitAssociations()
					.get(0);
			if (currGeoUnitAssociation.getParentGeoUnitId() == null) {
				geoUnit.getParentGeoUnitAssociations().remove(0);
			}
		}

		if (geoUnit.getChildGeoUnitAssociations() != null
				&& geoUnit.getChildGeoUnitAssociations().size() == 1) {
			GeoUnitAssociation currGeoUnitAssociation = geoUnit.getChildGeoUnitAssociations()
					.get(0);
			if (currGeoUnitAssociation.getChildGeoUnitId() == null) {
				geoUnit.getChildGeoUnitAssociations().remove(0);
			}
		}

		geoUnit.setModifiedDate(new Date());
		geoUnit.setModifiedUser(userId);

		Long geoIndex = 0L;		
		if (geoUnit.getChildGeoUnitAssociations() != null) {
			List<GeoUnitAssociation> newChildList = new ArrayList<GeoUnitAssociation>();
			for (GeoUnitAssociation currentChild : geoUnit.getChildGeoUnitAssociations()) {
				if (currentChild != null && currentChild.getChildGeoUnitId() != null) {
					if (currentChild.getGeoUnitAssociationId() == null) {
						currentChild.setGeoUnitAssociationId(geoIndex--);
						currentChild.setEffectiveDate(new Date());
						currentChild.setCreatedDate(new Date());
						currentChild.setCreatedUser(userId);
						currentChild.setModifiedDate(new Date());
						currentChild.setModifiedUser(userId);
						currentChild.setParentGeoUnitId(geoUnit.getGeoUnitId());
						newChildList.add(currentChild);
					} else {
						if (containsChildChange(currentChild, geoUnitInDB)) {
							currentChild.setParentGeoUnitId(geoUnit.getGeoUnitId());
							newChildList.add(currentChild);
						}
					}
				}
			}
			geoUnit.setChildGeoUnitAssociations(newChildList);
		}

		if (geoUnit.getParentGeoUnitAssociations() != null) {
			List<GeoUnitAssociation> newParentList = new ArrayList<GeoUnitAssociation>();	
			for (GeoUnitAssociation currentParent : geoUnit
					.getParentGeoUnitAssociations()) {
				if (currentParent.getGeoUnitAssociationId() == null) {
					currentParent.setGeoUnitAssociationId(geoIndex--);
					currentParent.setEffectiveDate(new Date());
					currentParent.setCreatedDate(new Date());
					currentParent.setCreatedUser(userId);
					currentParent.setModifiedDate(new Date());
					currentParent.setModifiedUser(userId);
					currentParent.setChildGeoUnitId(geoUnit.getGeoUnitId());
					currentParent.setParentGeoUnit(null);
					newParentList.add(currentParent);
				} else {
					if (containsParentChange(currentParent, geoUnitInDB)) {
						currentParent.setChildGeoUnitId(geoUnit.getGeoUnitId());
						currentParent.setParentGeoUnit(null);
						newParentList.add(currentParent);
					}
				}
			}
			geoUnit.setParentGeoUnitAssociations(newParentList);
		}

		if (geoUnit.getGeoUnitCodes() != null) {
			Long codeIndex = 0L;
			List<GeoUnitCode> newCodeList = new ArrayList<GeoUnitCode>();
			for (GeoUnitCode geoUnitCode : geoUnit.getGeoUnitCodes()) {
				if(geoUnitCode.getGeoCodeTypeCode() != null) {
					if (geoUnitCode.getGeoUnitCodeId() == null) {
						geoUnitCode.setGeoUnitCodeId(codeIndex--);
						/**
						 * 11/26/2013
						 * Commenting to fix issue reported in Ticket # 208397799
						 * This will enable future effective dates to be entered for GeoUnitName
						 * geoUnitCode.setEffectiveDate(new Date());
						 **/
						if(geoUnitCode.getEffectiveDate() == null){
							geoUnitCode.setEffectiveDate(new Date());
						}
						else{
							geoUnitCode.setEffectiveDate(geoUnitCode.getEffectiveDate());
							/*** END***/	
						}
						geoUnitCode.setCreatedDate(new Date());
						geoUnitCode.setCreatedUser(userId);
						geoUnitCode.setModifiedDate(new Date());
						geoUnitCode.setModifiedUser(userId);
						if(geoUnitCode.getGeoCodeTypeCode() != null) {
							newCodeList.add(geoUnitCode);
						}
					} else {
						if (containsCodeChange(geoUnitCode, geoUnitInDB)) {
							newCodeList.add(geoUnitCode);
						}
					}
				}
			}
			geoUnit.setGeoUnitCodes(newCodeList);
		}
		if (geoUnit.getGeoUnitNames() != null) {
			Long nameIndex = 0L;
			List<GeoUnitName> newNameList = new ArrayList<GeoUnitName>();
			for (GeoUnitName geoUnitName : geoUnit.getGeoUnitNames()) {
				if (geoUnitName.getGeoUnitNameId() == null) {
					geoUnitName.setGeoUnitNameId(nameIndex--);
					geoUnitName.setWritingScriptCode(RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
					/**
					 * 11/26/2013
					 * Commenting to fix issue reported in Ticket # 208397799
					 * This will enable future effective dates to be entered for GeoUnitName
					 * geoUnitName.setEffectiveDate(new Date());
					 **/
					if(geoUnitName.getEffectiveDate() == null){
						geoUnitName.setEffectiveDate(new Date());
					}
					else{
						geoUnitName.setEffectiveDate(geoUnitName.getEffectiveDate());
						/*** END***/
					}
					geoUnitName.setCreatedDate(new Date());
					geoUnitName.setCreatedUser(userId);
					geoUnitName.setModifiedDate(new Date());
					geoUnitName.setModifiedUser(userId);
					if(geoUnitName.getNameTypeCode() != null) {
						newNameList.add(geoUnitName);
					}
				} else {
					if (containsNameChange(geoUnitName, geoUnitInDB)) {
						newNameList.add(geoUnitName);
					}
				}

			}
			geoUnit.setGeoUnitNames(newNameList);
		}
		LOGGER.info("geoUnit : " + geoUnit);
		return geoUnit;
	}

	private boolean containsParentChange(GeoUnitAssociation geoUnitAssociation,
			GeoUnit geoUnitInDB) {
		if (geoUnitInDB == null || geoUnitAssociation == null) {
			return false;
		}
		if (geoUnitInDB.getParentGeoUnitAssociations() == null) {
			return false;
		}

		for (GeoUnitAssociation currParent : geoUnitInDB
				.getParentGeoUnitAssociations()) {
			if (geoUnitAssociation.getGeoUnitAssociationId().equals(
					currParent.getGeoUnitAssociationId())) {
				if (isParentIdDifferent(
						geoUnitAssociation.getParentGeoUnitId(),
						currParent.getParentGeoUnitId())) {
					return true;
				}
				if (isDateDifferent(geoUnitAssociation.getEffectiveDate(),
						currParent.getEffectiveDate())) {
					return true;
				}
				if (isDateDifferent(geoUnitAssociation.getExpiredByDate(),
						currParent.getExpiredByDate())) {
					return true;
				}else if (isDateDifferent(geoUnitAssociation.getExpirationDate(), currParent.getExpirationDate())) {
					return true;
				}
				return false;
			}
		}
		return false;
	}
	/**
	 * 
	 * TODO
	 *
	 * @param geoUnitAssociation
	 * @param geoUnitInDB
	 * @return
	 */
	private boolean containsChildChange(GeoUnitAssociation geoUnitAssociation, GeoUnit geoUnitInDB) {
		if (geoUnitInDB == null || geoUnitAssociation == null) {
			return false;
		}
		if (geoUnitInDB.getChildGeoUnitAssociations() == null) {
			return false;
		}
		for (GeoUnitAssociation currChild : geoUnitInDB.getChildGeoUnitAssociations()) {
			if (geoUnitAssociation.getGeoUnitAssociationId().equals(currChild.getGeoUnitAssociationId())) {
				if (isParentIdDifferent(geoUnitAssociation.getChildGeoUnitId(), currChild.getChildGeoUnitId())) {
					return true;
				}
				if (isDateDifferent(geoUnitAssociation.getEffectiveDate(), currChild.getEffectiveDate())) {
					return true;
				}				
				if (isDateDifferent(geoUnitAssociation.getExpiredByDate(), currChild.getExpiredByDate())) {
					return true;
				}else if (isDateDifferent(geoUnitAssociation.getExpirationDate(), currChild.getExpirationDate())) {
					return true;
				}

				return false;
			}
		}
		return false;
	}

	private boolean isParentIdDifferent(Long firstParentId, Long secondParentId) {
		if (! firstParentId.equals(secondParentId)) {
			return true;
		} else {
			return false;
		}
	}

	private boolean isDateDifferent(Date firstDate, Date secondDate) {
		if (firstDate == null && secondDate == null) {
			return false;
		}
		if ((firstDate != null && secondDate == null)
				|| (secondDate != null && firstDate == null)) {
			return true;
		}
		return !isEqualDates(getCalendarForDate(firstDate),
				getCalendarForDate(secondDate));
	}

	private Calendar getCalendarForDate(Date inputDate) {
		if (inputDate == null) {
			return null;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(inputDate);
		return calendar;
	}

	private boolean containsCodeChange(GeoUnitCode geoUnitCode,
			GeoUnit geoUnitInDB) {
		if (geoUnitInDB == null || geoUnitCode == null) {
			return false;
		}
		if (geoUnitInDB.getGeoUnitCodes() == null) {
			return false;
		}

		for (GeoUnitCode currGeoUnitCode : geoUnitInDB.getGeoUnitCodes()) {
			if (geoUnitCode.getGeoUnitCodeId().equals(
					currGeoUnitCode.getGeoUnitCodeId())) {
				if (isDateDifferent(geoUnitCode.getExpiredByDate(),	currGeoUnitCode.getExpiredByDate())) {
					return true;
				}else if (isDateDifferent(geoUnitCode.getExpirationDate(),currGeoUnitCode.getExpirationDate())){
					return true;
				}
				return false;
			}
		}
		return false;
	}

	private boolean containsNameChange(GeoUnitName geoUnitName,
			GeoUnit geoUnitInDB) {
		if (geoUnitInDB == null || geoUnitName == null) {
			return false;
		}
		if (geoUnitInDB.getGeoUnitNames() == null) {
			return false;
		}

		for (GeoUnitName currGeoUnitName : geoUnitInDB.getGeoUnitNames()) {
			if (geoUnitName.getGeoUnitNameId().equals(
					currGeoUnitName.getGeoUnitNameId())) {
				if (isDateDifferent(geoUnitName.getExpiredByDate(),	currGeoUnitName.getExpiredByDate())) {
					return true;
				}else if (isDateDifferent(geoUnitName.getExpirationDate(),currGeoUnitName.getExpirationDate())){
					return true;
				}
				return false;
			}
		}
		return false;
	}

	/**
	 * 
	 * This method is invoked by dataTable plug-in through Ajax calls. Response
	 * is provided in JSON format.
	 * 
	 */
	@RequestMapping(value = "/geoSearchNameAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getGeoSearchNameAjaxResults(HttpServletRequest request,
			HttpSession session){
		LOGGER.info("entering GeographyController | getGeoSearchNameAjaxResults");
		Date startTime = new Date();

		String searchString = homeController.getSearchString(request);
		int startIndex = homeController.getStartIndex(request);
		int maxResults = homeController.getMaxResults(request);
		String sortBy = homeController.getSortBy(request, geoSearchNameColumns);
		String sortOrder = homeController.getSortOrder(request);

		if(searchString.trim().isEmpty()){
			return homeController.getJsonMap(
					request,new ArrayList<GeographySearch>(), 0L, geoSearchNameColumns);
		}

		Long countNameResults = (Long)session.getAttribute("countNameResults");
		if((countNameResults == null) || (startIndex == 0)) {
			countNameResults = wsProxy.countSearchGeoUnitByName(searchString);
			session.setAttribute("countNameResults", countNameResults);
		}

		List<GeoUnitName> unitnames = wsProxy.searchGeoUnitByName(
				searchString, startIndex, maxResults, sortBy,
				sortOrder, RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		// transaction logging 
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				"getGeoSearchNameResults", 0L, unitnames, 0L, searchString, startIndex, maxResults, sortBy, sortOrder,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		return homeController.getJsonMap(request, unitnames, countNameResults, geoSearchNameColumns);
	}

	/**
	 * 
	 * This method is invoked by datatables plugin through Ajax calls. Response
	 * is provided in JSON format.
	 * 
	 */
	@RequestMapping(value = "/geoSearchCodeAjaxResults.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> getGeoSearchCodeAjaxResults(HttpServletRequest request,
			HttpSession session){
		LOGGER.info("entering GeographyController | getGeoSearchCodeAjaxResults");
		Date startTime = new Date();
		String searchString = homeController.getSearchString(request);
		int startIndex = homeController.getStartIndex(request);
		int maxResults = homeController.getMaxResults(request);
		String sortBy = homeController.getSortBy(request, geoSearchCodeColumns);
		String sortOrder = homeController.getSortOrder(request);

		if(searchString.trim().isEmpty()){
			return homeController.getJsonMap(request,new ArrayList<GeographySearch>(), 0L, geoSearchCodeColumns);
		}

		Long countCodeResults = (Long)session.getAttribute("countCodeResults");
		if((countCodeResults == null) || (startIndex == 0)) {
			countCodeResults = wsProxy.countSearchGeoUnitByCode(searchString);
			session.setAttribute("countCodeResults", countCodeResults);
		}

		List<GeoUnitCode> unitCodes = wsProxy.searchGeoUnitByCode(
				searchString, startIndex, maxResults, sortBy,
				sortOrder, RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		// transaction logging 
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				"getGeoSearchCodeResults", 0L, unitCodes, 0L, searchString, startIndex, maxResults, sortBy, sortOrder,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		return homeController.getJsonMap(request, unitCodes, countCodeResults, geoSearchCodeColumns);
	}

	private boolean isEqualDates(Calendar c1, Calendar c2) {
		if (c1.get(Calendar.YEAR) != c2.get(Calendar.YEAR)) {
			return false;
		}
		if (c1.get(Calendar.MONTH) != c2.get(Calendar.MONTH)) {
			return false;
		}
		if (c1.get(Calendar.DAY_OF_MONTH) != c2.get(Calendar.DAY_OF_MONTH)) {
			return false;
		}
		return true;
	}

	/**
	 * 
	 * The method to identify the default language code for a GeoUnit. If the
	 * GeoUnit is not a Country then identify the country and then get the
	 * default language code for the country.
	 * 
	 * @param geoUnit
	 * @return defaultLanguageCode
	 */
	public Long findGeoDefaultLanguageCode(GeoUnit geoUnit) {
		LOGGER.info("entering GeographyController | findGeoDefaultLanguageCode");
		Long geoUnitId = findCountryGeoUnitId(geoUnit);
		Long defaultLanguageCode = iterateCountryDefaultConfiguration(geoUnitId);
		LOGGER.info("exiting GeographyController | findGeoDefaultLanguageCode");
		return defaultLanguageCode;
	}

	/**
	 * 
	 * The method to iterate the default country language configurations
	 *
	 * @param geoUnitId
	 * @return defaultLanguageCode
	 */
	@SuppressWarnings("rawtypes")
	private Long iterateCountryDefaultConfiguration(Long geoUnitId) {
		Long defaultLanguageCode = 0L;
		// Retrieve the default configurations
		Iterator itr = cacheProvider.retrieveAllGeoConfigurations().iterator();
		while (itr.hasNext()) {
			LinkedHashMap dfltConfig = (LinkedHashMap) itr.next();
			Integer geoUnitIdDb = (Integer) dfltConfig.get("geoUnitId");
			// Iterate through the default configurations and if geoUnitId
			// matches fetch the language code for the country
			if (Long.valueOf(geoUnitIdDb).equals(geoUnitId)) {
				defaultLanguageCode = Long.valueOf((Integer) dfltConfig.get("defaultLanguageCode"));
			}
		}
		// If no configuration found use default language as English
		if (defaultLanguageCode == 0) {
			defaultLanguageCode = RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH;
		}

		LOGGER.info("default language for GeoUnit Id : " + geoUnitId + " is : " + defaultLanguageCode);
		return defaultLanguageCode;
	}

	/**
	 * The method to identify the Country's geoUnitId for the respective
	 * GeoUnit. If the GeoUnit for view is a country the find the geoUnitId
	 * directly from the GeoUnit entity else iterate the parent GeoUnit
	 * associations
	 * 
	 * @param geoUnit
	 * @return geoUnitId for the geoUnit's Country
	 */
	private Long findCountryGeoUnitId(GeoUnit geoUnit) {
		LOGGER.info("entering GeographyController | findCountryGeoUnitId");
		Long geoUnitId = 0L;

		if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY.equals(geoUnit.getGeoUnitTypeCode())) {
			geoUnitId = geoUnit.getGeoUnitId();
		} else {
			if (geoUnit.getParentGeoUnitAssociations() != null) {
				for (GeoUnitAssociation association : geoUnit.getParentGeoUnitAssociations()) {
					GeoUnit parentGeoUnit = association.getParentGeoUnit();
					LOGGER.info("GeographyController | findCountryGeoUnitId | parentGeoUnit : " + parentGeoUnit);
					if (parentGeoUnit != null && RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY
							.equals(parentGeoUnit.getGeoUnitTypeCode())) {
						geoUnitId = parentGeoUnit.getGeoUnitId();
						break;
					}
				}
			}
		}		
		LOGGER.info("exiting GeographyController | findCountryGeoUnitId");
		return geoUnitId;
	}

	/**
	 * 
	 * The method will construct the GeoHierarchies map. The map will be
	 * constructed based on the hierarchies retrieved from the cache.
	 * 
	 * @param countryGeoUnitId
	 * @return hierarchyMap
	 */
	private LinkedHashMap<String, String> findGeoHierarchy(Long countryGeoUnitId) {
		LOGGER.info("entering GeographyController | findGeoHierarchy");
		Long geoUnitId = countryGeoUnitId;
		Long childGeoUnitTypeCode = 0L;
		String childGeoUnitTypeDescription = null;
		List<GeoHierarchy> geoHierarchies = getGeoHierarchies(geoUnitId);
		// if no hierarchy defined for the country then use the default
		// configuration as United States
		if(geoHierarchies == null || geoHierarchies.size() == 0) {
			geoHierarchies = getGeoHierarchies(RefDataUIConstants.CODE_GEO_UNIT_ID_UNITED_STATES);
		}
		LinkedHashMap<String, String> hierarchyMap = new LinkedHashMap<String, String>();
		String countryPos = null;
		String territoryPos = null;
		String countyPos = null;
		String postTownPos = null;
		String postCodePos = null;

		for (GeoHierarchy geoHierarchy : geoHierarchies) {
			if (geoHierarchy.getIsRootIndicator()) {

				countryPos = geoHierarchy.getParentGeoUnitTypeCode() + "~"
						+ RefDataUIConstants.HIERARCHY_COUNTRY_TEXT;
				childGeoUnitTypeCode = geoHierarchy.getChildGeoUnitTypeCode();
				childGeoUnitTypeDescription = geoHierarchy
						.getChildGeoUnitTypeDescription();
			}
		}
		for (GeoHierarchy geoHierarchy : geoHierarchies) {				
			for(GeoHierarchy innerGeoHierarchy : geoHierarchies) {
				if (childGeoUnitTypeCode.equals(
						innerGeoHierarchy.getParentGeoUnitTypeCode())) {
					if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_TERRITORY
							.equals(childGeoUnitTypeCode)) {

						territoryPos = childGeoUnitTypeCode + "~"
								+ childGeoUnitTypeDescription;
					} else if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTY
							.equals(childGeoUnitTypeCode)) {

						countyPos = childGeoUnitTypeCode + "~"
								+ childGeoUnitTypeDescription;
					} else if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_POST_TOWN
							.equals(childGeoUnitTypeCode)) {

						postTownPos = childGeoUnitTypeCode + "~"
								+ childGeoUnitTypeDescription;
					}
					childGeoUnitTypeCode = innerGeoHierarchy.getChildGeoUnitTypeCode();
					childGeoUnitTypeDescription = innerGeoHierarchy
							.getChildGeoUnitTypeDescription();
					break;
				}
			}
			LOGGER.info("geoHierarchy : " + geoHierarchy);
		}
		if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_POST_CODE
				.equals(childGeoUnitTypeCode)) {
			postCodePos = childGeoUnitTypeCode + "~"
					+ childGeoUnitTypeDescription;
		} else if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_POST_TOWN
				.equals(childGeoUnitTypeCode)) {
			postTownPos = childGeoUnitTypeCode + "~"
					+ childGeoUnitTypeDescription;
		}

		hierarchyMap.put(RefDataUIConstants.HIERARCHY_COUNTRY_TEXT, countryPos);
		hierarchyMap.put(RefDataUIConstants.HIERARCHY_TERRITORY_TEXT, territoryPos);
		hierarchyMap.put(RefDataUIConstants.HIERARCHY_COUNTY_TEXT, countyPos);
		hierarchyMap.put(RefDataUIConstants.HIERARCHY_POSTTOWN_TEXT, postTownPos);
		hierarchyMap.put(RefDataUIConstants.HIERARCHY_POSTCODE_TEXT, postCodePos);

		LOGGER.info("Geo Hierarchy for " + geoUnitId + " is : " + hierarchyMap);
		LOGGER.info("exiting GeographyController | findGeoHierarchy");
		return hierarchyMap;
	}

	/**
	 * 
	 * The method will fetch the geoHierarchies and de-serialize to the List of
	 * GeoHierarchy objects.
	 * 
	 * @param geoUnitId
	 * @return geoHierarchies
	 */
	@SuppressWarnings("rawtypes")
	private List<GeoHierarchy> getGeoHierarchies(Long geoUnitId) {
		List<GeoHierarchy> geoHierarchies = new ArrayList<GeoHierarchy>();
		Iterator itr = cacheProvider.retrieveAllGeoHierarchies().iterator();

		while (itr.hasNext()) {
			LinkedHashMap hierarchies = (LinkedHashMap) itr.next();

			Integer geoUnitIdDb = (Integer) hierarchies.get("geoUnitId");
			// get the hierarchies for the specified GeoUnit
			if (Long.valueOf(geoUnitIdDb).equals(geoUnitId)) {
				Integer geoHierarchyId = (Integer) hierarchies
						.get("geoHierarchyId");
				Integer parentGeoUnitTypeCode = (Integer) hierarchies
						.get("parentGeoUnitTypeCode");
				Integer childGeoUnitTypeCode = (Integer) hierarchies
						.get("childGeoUnitTypeCode");
				String childGeoUnitTypeDescription = (String) hierarchies
						.get("childGeoUnitTypeDescription");
				Boolean isRootIndicator = (Boolean) hierarchies
						.get("isRootIndicator");

				GeoHierarchy geoHierarchy = new GeoHierarchy();
				geoHierarchy.setGeoHierarchyId(Long.valueOf(geoHierarchyId));
				geoHierarchy.setGeoUnitId(Long.valueOf(geoUnitIdDb));
				geoHierarchy.setParentGeoUnitTypeCode(Long
						.valueOf(parentGeoUnitTypeCode));
				geoHierarchy.setChildGeoUnitTypeCode(Long
						.valueOf(childGeoUnitTypeCode));
				geoHierarchy
				.setChildGeoUnitTypeDescription(childGeoUnitTypeDescription);
				geoHierarchy.setIsRootIndicator(isRootIndicator);
				geoHierarchies.add(geoHierarchy);
			}
		}
		return geoHierarchies;
	}

	/**
	 * 
	 * The method will fetch the GeoHierarchies for any change in Country in the
	 * screen. This method will be invoked from the UI on every change to
	 * Country drop down. This will populate the hierarchies in the form of a
	 * map and return to the UI
	 * 
	 * @param parentGeoUnitId
	 * @return list of hierarchy values
	 */
	@RequestMapping(value = "resetGeoHierarchies.form", method = RequestMethod.GET)
	public @ResponseBody
	Collection<String> resetGeoHierarchies(
			@RequestParam(value = "parentGeoUnitId", required = true) Long parentGeoUnitId) {
		LOGGER.info("entering GeographyController | resetGeoHierarchies");
		LinkedHashMap<String, String> hierarchies = findGeoHierarchy(parentGeoUnitId);
		return hierarchies.values();
	}

	/**
	 * 
	 * The method will sort the GeoUnitAssociations based on the GeoHierarchy.
	 * The hierarchy is defined as Country - Territory - County - Post Town
	 * -Post Code. All other unit types will be appended to the last of the list
	 * 
	 * @param associations
	 * @return unitAssociations - sorted list
	 */
	public List<GeoUnitAssociation> sortGeoUnitAssociations(List<GeoUnitAssociation> associations) {
		LinkedList<GeoUnitAssociation> unitAssociations = new LinkedList<GeoUnitAssociation>();
		LinkedList<GeoUnitAssociation> tAssociations = new LinkedList<GeoUnitAssociation>();
		LinkedHashMap<String, GeoUnitAssociation> hierarchyMap = new LinkedHashMap<String, GeoUnitAssociation>();
		// initialize the hash map with keys
		hierarchyMap.put(RefDataUIConstants.HIERARCHY_CONTINENT_TEXT, null);
		hierarchyMap.put(RefDataUIConstants.HIERARCHY_COUNTRY_TEXT, null);
		hierarchyMap.put(RefDataUIConstants.HIERARCHY_TERRITORY_TEXT, null);
		hierarchyMap.put(RefDataUIConstants.HIERARCHY_COUNTY_TEXT, null);
		hierarchyMap.put(RefDataUIConstants.HIERARCHY_POSTTOWN_TEXT, null);
		hierarchyMap.put(RefDataUIConstants.HIERARCHY_POSTCODE_TEXT, null);
		// iterate through the associations to form the hash map.
		for(GeoUnitAssociation association : associations) {
			if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_CONTINENT.equals(
					association.getParentGeoUnit().getGeoUnitTypeCode())) {
				hierarchyMap.put(RefDataUIConstants.HIERARCHY_CONTINENT_TEXT, association);
			} else if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY.equals(
					association.getParentGeoUnit().getGeoUnitTypeCode())) {
				hierarchyMap.put(RefDataUIConstants.HIERARCHY_COUNTRY_TEXT, association);
			} else if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_TERRITORY.equals(
					association.getParentGeoUnit().getGeoUnitTypeCode())) {
				hierarchyMap.put(RefDataUIConstants.HIERARCHY_TERRITORY_TEXT, association);
			} else if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTY.equals(
					association.getParentGeoUnit().getGeoUnitTypeCode())) {
				hierarchyMap.put(RefDataUIConstants.HIERARCHY_COUNTY_TEXT, association);
			} else if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_POST_TOWN.equals(
					association.getParentGeoUnit().getGeoUnitTypeCode())) {
				hierarchyMap.put(RefDataUIConstants.HIERARCHY_POSTTOWN_TEXT, association);
			} else if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_POST_CODE.equals(
					association.getParentGeoUnit().getGeoUnitTypeCode())) {
				hierarchyMap.put(RefDataUIConstants.HIERARCHY_POSTCODE_TEXT, association);
			} else {
				tAssociations.add(association);
			}
		}

		for(Entry<String, GeoUnitAssociation> entry : hierarchyMap.entrySet()) {
			if(entry.getValue() != null)
				unitAssociations.add(entry.getValue());
		}
		// if the hierarchy is empty then assuming the GeoUnit for view does not
		// fall under the hierarchy and hence adding all the parent GeoUnits to
		// the GeoUnit entity and returning to UI.
		unitAssociations.addAll(tAssociations);

		return unitAssociations;
	}

	/**
	 * 
	 * The method to retrieve the GeoUnit details based on the Geo Unit Id. If
	 * id value is present then system will navigate to the GeoUnit View page.
	 * 
	 * @param geoUnitId
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/geoUnitIdSearch.form", method = RequestMethod.GET)
	public ModelAndView geoUnitIdSearch(
			@RequestParam(RefDataUIConstants.GEO_UNIT_SEARCH_ID_REQ_PARAM) final String geoUnitId,
			Model model, HttpSession session) {
		LOGGER.info("entering GeographyController | geoUnitIdSearch");
		LOGGER.info("geoUnitId : " + geoUnitId);

		ModelAndView modelAndView = null;
		if (geoUnitId != null && geoUnitId.length() > 0) {
			try {
				modelAndView = geoUnitView(geoUnitId, null, 
						RefDataUIConstants.PAGE_NAVIGATE_SRC_GEO_UNIT_ID_SEARCH, model, session);
			} catch(Exception e) {
				LOGGER.error("Exception occured in geoUnitIdSearch method : " + e);
				LOGGER.info("geoUnitId " + geoUnitId + "does not exist");
				modelAndView = new ModelAndView("geoUnitIdSearch");
				modelAndView.addObject("geoUnitId", geoUnitId);
				modelAndView.addObject("resultsIndicator", false);
			}
		} else {
			modelAndView = new ModelAndView("geoUnitIdSearch");
		}

		return modelAndView;
	}

	@RequestMapping(value = "checkForChildGeoUnit.form", method = RequestMethod.GET)
	public @ResponseBody
	Boolean checkForChildGeoUnit(
			@RequestParam(RefDataUIConstants.GEO_UNIT_ID_REQ_PARAM) final Long geoUnitId) {
		LOGGER.info("entering GeographyController | checkForChildGeoUnit");
		return this.wsProxy.checkForChildGeoUnit(geoUnitId);
	}

	/**
	 * 
	 * The method to create new task with work-flow.
	 *
	 * @param domainId
	 * @param countryGeoUnitId
	 * @param changeType
	 * @param userContextVO
	 * @param officialGeoName
	 */
	private void createNewGeoWorkflowTask(Long domainId,
			Long countryGeoUnitId, String changeType,
			UserContextVO userContextVO, String officialGeoName) {

		Long approverGroupId = roleMapper.getApproverUserGroupId(
				RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				countryGeoUnitId);
		approverGroupId = approverGroupId.equals(0L) ? 
				roleMapper.getApproverUserGroupId(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY, 0L)
				: approverGroupId;

				Long submitterGroupId = roleMapper.getSubmitterUserGroupId(
						RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
						countryGeoUnitId);
				submitterGroupId = submitterGroupId.equals(0L) ? 
						roleMapper.getSubmitterUserGroupId(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY, 0L)
						: submitterGroupId;	

						homeController.createReferenceData(
								String.valueOf(domainId),
								RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
								Long.valueOf(changeType),
								userContextVO.getUserIdentifier(),
								"Geo Unit : " + officialGeoName + " : " + domainId,
								approverGroupId,
								submitterGroupId);
	}

	@RequestMapping(value = "getHierarchyByGeoUnitId.form", method = RequestMethod.GET)
	public @ResponseBody
	Map<Long, String> getHierarchyByGeoUnitId(@ModelAttribute("geoUnit") GeoUnit geoUnit) {
		LOGGER.info("entering GeographyController | getHierarchyByGeoUnitId");
		return this.wsProxy.getHierarchyByGeoUnitId(findCountryGeoUnitId(geoUnit), geoUnit.getGeoUnitTypeCode());
	}

	/**
	 * 
	 * The method to populate the GeoUnitName for a GeoUnit Id and Geo Unit Type Code. 
	 *
	 * @param newParentGeoUnitId
	 * @param newParentGeoUnitTypeCode
	 * @param geoUnit
	 * @return jsonString
	 */
	@RequestMapping(value = "getOfficialNameByGeoUnitIdAndTypeCode.form", method = RequestMethod.GET)
	public @ResponseBody
	String getOfficialNameByGeoUnitIdAndTypeCode(
			@RequestParam("newParentGeoUnitId") final Long newParentGeoUnitId,
			@RequestParam("newParentGeoUnitTypeCode") final Long newParentGeoUnitTypeCode,			
			@ModelAttribute("geoUnit") GeoUnit geoUnit) {
		LOGGER.info("entering GeographyController | getOfficialNameByGeoUnitIdAndTypeCode");
		String officialName = null;
		if(newParentGeoUnitId != null){
			officialName = this.wsProxy.getOfficialNameByGeoUnitIdAndTypeCode(
					findCountryGeoUnitId(geoUnit), newParentGeoUnitId, newParentGeoUnitTypeCode);
		}
		String jsonString = "{\"officialName\" : \"" + officialName + "\"}";		
		return jsonString;
	}

	/**
	 * The method will populate the existing geography data from the Transaction
	 * DB. The service method need to retrieve the values from the DB based on
	 * the user selection
	 * 
	 * @param geoCodeBulkDownloadVO
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/geoBulkDownload.form", method = RequestMethod.GET)
	public ModelAndView geoBulkDownload(Model model, HttpSession session) {
		LOGGER.info("entering GeographyController | geoBulkDownload");
		ModelAndView geoBulkDownload = new ModelAndView("geoBulkDownload");
		GeoCodeBulkDownloadVO geoCodeBulkDownloadVO = new GeoCodeBulkDownloadVO();
		model.addAttribute("geoBulkDownload", geoCodeBulkDownloadVO);

		// Populating request object with code values
		List<Integer> codeTableIds = new ArrayList<Integer>();
		codeTableIds
		.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_UNIT_TYPE);
		codeTableIds
		.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE);
		codeTableIds.add(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE);
		codeTableIds
		.add(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_CODE_TYPE);
		Map<String, List<CodeValue>> tempCodeValueMap = homeController
				.retrieveCodeValues(codeTableIds);

		// set the code values to the view object		
		geoBulkDownload
		.addObject(
				"nameTypeCodeValue",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE)));
		geoBulkDownload
		.addObject(
				"languageCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE)));
		geoBulkDownload
		.addObject(
				"geoCodeTypeCodeValues",
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_CODE_TYPE)));

		return geoBulkDownload;
	}

	/**
	 * The method will populate the existing geography data from the Transaction
	 * DB. The service method need to retrieve the values from the DB based on
	 * the user selection
	 * 
	 * @param geoCodeBulkDownloadVO
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */
	@RequestMapping(value = "/geographyMyDownLoad.form", method = RequestMethod.POST)
	public View geographyBulkDownload(
			@ModelAttribute("geoBulkDownload") GeoCodeBulkDownloadVO geoCodeBulkDownloadVO,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session) throws ParseException {
		LOGGER.info("entering GeographyController | geographyBulkDownload");

		Date startTime = new Date();
		UiBulkDownload uiBulkDownload = new UiBulkDownload();
		uiBulkDownload.setDwnloadStartTime(startTime);
		uiBulkDownload.setFileType(geoCodeBulkDownloadVO.getGeoFileType());
		UserContextVO userContextVO = (UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		uiBulkDownload.setUserId(userContextVO.getUserIdentifier());
		uiBulkDownload
		.setDomainName(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY);
		uiBulkDownload
		.setBulkDownloadStatus(RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_FILE_STATUS);
		Long uiBlkDwnldTrackingId = wsProxy.addUIBulkDownload(uiBulkDownload);
		geoCodeBulkDownloadVO.setUiBlkDwnldId(uiBlkDwnldTrackingId);
		String fileType = null;
		if (geoCodeBulkDownloadVO.getGeoFileType().equalsIgnoreCase(
				"Geo Unit Name/Geo Unit Code")) {
			fileType = "Geo_Name_And_Code";
		} else if (geoCodeBulkDownloadVO.getGeoFileType().equalsIgnoreCase(
				"Geo Unit Association")) {
			fileType = "Geo_Unit_Assn";
		}

		String geoDownLoadFileName = refdataConfig
				.getValue(RefDataPropertiesConstants.REFDATA_GEOGRAPHY_BLK_DOWNLOAD_LOCATION)
				+ fileType
				+ RefDataPropertiesConstants.UNDERSOCRE
				+ uiBlkDwnldTrackingId
				+ RefDataPropertiesConstants.REFDATA_INDUSTRY_BLK_DOWNLOAD_FILE_FORMAT;
		geoCodeBulkDownloadVO.setFileName(geoDownLoadFileName);
		wsProxy.geographyBulkDownload(geoCodeBulkDownloadVO);

		// transaction logging 
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				"geographyBulkDownload", 0L, geoCodeBulkDownloadVO, 0L, uiBulkDownload);

		return new RedirectView("workQueueDownload.form");
	}

	/**
	 * The method will retrieve GeoUnitType for the selected Geo Unit Id. The
	 * method will be invoked on change of the Country table drop down.
	 * 
	 * @param geographyUnitType
	 * @param session
	 * @return list of GeoHierarchy
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/retrieveGeoUnitType.form", method = RequestMethod.GET)
	public @ResponseBody
	List<GeoHierarchy> retrieveGeoUnitTypeById(
			@RequestParam(value = "geographyUnitType", required = true) Long geoUnitId,
			HttpSession session) {
		LOGGER.info("entering GeographyCodesController | retrieveGeoUnitTypeById");
		List geoUnitTypes = this.wsProxy.retrieveGeoUnitType(geoUnitId);

		LOGGER.info("exiting GeographyCodesController | retrieveGeoUnitTypeById");
		return geoUnitTypes;
	}

	/**
	 * The method will retrieve GeoUnit Hierarchies for the selected Geo Unit
	 * Id. The method will be invoked on change of the Country table drop down.
	 * 
	 * @param geographyUnitType
	 * @param session
	 * @return list of GeoHierarchy
	 */
	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = "/retrieveGeoUnitHierarchies.form", method = RequestMethod.GET)
	public @ResponseBody
	List<GeoHierarchy> retrieveGeoUnitHierarchiesById(
			@RequestParam(value = "geographyUnitType", required = true) Long geoUnitId,
			HttpSession session) {
		LOGGER.info("entering GeographyCodesController | retrieveGeoUnitHierarchies");

		List<GeoHierarchy> rows = new ArrayList<GeoHierarchy>();
		List<GeoHierarchy> geoUnitTypes =(List<GeoHierarchy>)this.wsProxy.retrieveGeoUnitHierarchies(geoUnitId);
		for (Iterator itr = geoUnitTypes.iterator(); itr.hasNext();) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			GeoHierarchy geoHierarchy = new GeoHierarchy();
			geoHierarchy.setParentGeoUnitTypeCode(((Integer) curr.get("parentGeoUnitTypeCode")).longValue());
			geoHierarchy.setChildGeoUnitTypeCode(((Integer) curr.get("childGeoUnitTypeCode")).longValue());
			if(geoHierarchy.getParentGeoUnitTypeCode()==128){
				geoHierarchy.setPrntGeoUnitTypeDescription("Country");
			}else if(geoHierarchy.getParentGeoUnitTypeCode()==5392){
				geoHierarchy.setPrntGeoUnitTypeDescription("Territory");
			}else if(geoHierarchy.getParentGeoUnitTypeCode()==5153){
				geoHierarchy.setPrntGeoUnitTypeDescription("County");
			}else if(geoHierarchy.getParentGeoUnitTypeCode()==126){
				geoHierarchy.setPrntGeoUnitTypeDescription("Postal Town");
			}else if(geoHierarchy.getParentGeoUnitTypeCode()==324){
				geoHierarchy.setPrntGeoUnitTypeDescription("Postal Code");
			}else if(geoHierarchy.getParentGeoUnitTypeCode()==1444){
				geoHierarchy.setPrntGeoUnitTypeDescription("MSA");
			}else if(geoHierarchy.getParentGeoUnitTypeCode()==1333){
				geoHierarchy.setPrntGeoUnitTypeDescription("SMSA");
			}else if(geoHierarchy.getParentGeoUnitTypeCode()==1666){
				geoHierarchy.setPrntGeoUnitTypeDescription("Post Code Prefix Group");
			}
			if(geoHierarchy.getChildGeoUnitTypeCode()==128){
				geoHierarchy.setChildGeoUnitTypeDescription("Country");
			}else if(geoHierarchy.getChildGeoUnitTypeCode()==5392){
				geoHierarchy.setChildGeoUnitTypeDescription("Territory");
			}else if(geoHierarchy.getChildGeoUnitTypeCode()==5153){
				geoHierarchy.setChildGeoUnitTypeDescription("County");
			}else if(geoHierarchy.getChildGeoUnitTypeCode()==126){
				geoHierarchy.setChildGeoUnitTypeDescription("Postal Town");
			}else if(geoHierarchy.getChildGeoUnitTypeCode()==324){
				geoHierarchy.setChildGeoUnitTypeDescription("Postal Code");
			}else if(geoHierarchy.getChildGeoUnitTypeCode()==1444){
				geoHierarchy.setChildGeoUnitTypeDescription("MSA");
			}else if(geoHierarchy.getChildGeoUnitTypeCode()==1333){
				geoHierarchy.setChildGeoUnitTypeDescription("SMSA");
			}else if(geoHierarchy.getChildGeoUnitTypeCode()==1666){
				geoHierarchy.setChildGeoUnitTypeDescription("Post Code Prefix Group");
			}
			rows.add(geoHierarchy);
		}

		LOGGER.info("exiting GeographyCodesController | retrieveGeoUnitHierarchies");
		return rows;
	}

	@RequestMapping(value = "/geoBulkUpload.form")
	public ModelAndView geoBulkUploadForm(Model model) {
		LOGGER.info("entering GeographyController | GeographyBulkUpload");
		ModelAndView geoBulkUpload = new ModelAndView();
		geoBulkUpload.addObject(
				RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION,
				getCountryList());
		GeoBulkUploadVO geoBulkUploadVO = new GeoBulkUploadVO();
		model.addAttribute("geoBulkUpload", geoBulkUploadVO);
		LOGGER.info("exiting GeographyController | getGeoSearchHome");
		return geoBulkUpload;
	}

	/**
	 * The method will populate the existing Geography data from the Transaction
	 * DB. The service method need to retrive the values from the DB based on
	 * the user selection
	 * 
	 * @param geoBulkUploadVO
	 *            model attribute
	 * @return View
	 * @throws ParseException
	 */

	@RequestMapping(value = "/geoBulkUploader.form", method = RequestMethod.POST)
	public View geoBulkUploaderForm(
			@ModelAttribute("geoBulkUpload") GeoBulkUploadVO geoBulkUploadVo,
			BindingResult result, Model model, SessionStatus sessionStatus,
			HttpSession session) {
		String fileName = null;
		Date startTime = new Date();
		LOGGER.info("entering GeographyController | geoBulkUploaderForm");
		fileName = refdataConfig
				.getValue(RefDataPropertiesConstants.REFDATA_GEOGRAPHY_BLK_UPLOAD_LOCATION)
				+ geoBulkUploadVo.getFile().getOriginalFilename();
		LOGGER.info("GeographyController | geoBulkUpload | File Name"+fileName);
		File f = new File(fileName);
		MultipartFile multipartFile = geoBulkUploadVo.getFile();
		try {
			multipartFile.transferTo(f);
		} catch (IllegalStateException e) {
			LOGGER.error("Error in Geography Upload",e);
		} catch (IOException e) {
			LOGGER.error("Error in Geography Upload",e);
		} catch(Exception e){
			LOGGER.error("Error in Geography Upload",e);
		}

		if (result.hasErrors()) {
			for (ObjectError error : result.getAllErrors()) {
				LOGGER.error("Error: " + error.getCode() + " - "
						+ error.getDefaultMessage());
			}
		}

		createNewGeoBulkUploadWorkflowTask(geoBulkUploadVo,
				RefDataChangeTypeConstants.CHANGE_TYPE_BULK_UPLOAD_GEOGRAPHY,
				(UserContextVO) session
				.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT));

		sessionStatus.setComplete();

		// transaction logging 
		UserContextVO userContextVO = (UserContextVO) session.getAttribute(RefDataUIConstants.REFDATA_USER_CONTEXT);
		transactionLogger.log(
				startTime,
				userContextVO.getUserIdentifier(),
				roleMapper.findDomainUserRoles(RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
						userContextVO.getUserRoles()), RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				"geoBulkUploaderForm", 0L, geoBulkUploadVo, 0L);

		LOGGER.info("exiting  GeographyController | geoBulkUploaderForm");
		return new RedirectView(
				"submitterWorkQueueHome.form?domainName=Geography");

	}

	private void createNewGeoBulkUploadWorkflowTask(
			GeoBulkUploadVO geoBulkUploadVo, String requestType,
			UserContextVO userContextVO) {

		Long submitterGroupId = 208L;
		Long approverGroupId = 201L;
		String domainId = null;
		String fileName = geoBulkUploadVo.getFile().getOriginalFilename();
		domainId = geoBulkUploadVo.getCountryName();
		if(geoBulkUploadVo.getFileType().equalsIgnoreCase(
				"Geo Unit Name/Geo Unit Code")){
			domainId = domainId+";"+"GEOUNIT";
		}
		if(geoBulkUploadVo.getFileType().equalsIgnoreCase(
				"Geo Unit Association")){
			domainId = domainId+";"+"GEOASSN";
		}
		LOGGER.info("params for createNewGeographyWorkflowTaskForGeoBulkUpload : "
				+ geoBulkUploadVo
				+ " : "
				+ requestType
				+ " : "
				+ userContextVO
				+ " : " + approverGroupId + " : " + submitterGroupId);

		homeController.createGeoBulkUploadReferenceData(domainId,
				RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY,
				Long.valueOf(requestType), userContextVO.getUserIdentifier(),
				"Geography Bulk Upload Reference Data" + 401, fileName,
				approverGroupId, submitterGroupId);
	}

	/**
	 * 
	 * The method to obtain the heirarchies for a given country geoUnit id.
	 * This function is used in the add geoUnit page when the user selects the
	 * country from the drop down.
	 * 
	 * @param countryGeoUnitId
	 * @return geoHierarchyMap
	 */
	@RequestMapping(value = "/retrieveGeoHierarchiesForCountry.form", method = RequestMethod.GET)
	public @ResponseBody Map<String, String> retrieveGeoHierarchiesForCountry(
			@RequestParam("countryGeoUnitId") Long countryGeoUnitId) {
		return (Map<String, String>) findGeoHierarchy(countryGeoUnitId);
	}

	/**
	 * 
	 * The method to populate the session with the countries list if empty
	 *
	 * @param session
	 */
	private void getGeoSearchCountryList(HttpSession session) {
		List<CodeValueVO> countryList = null;
		if (session.getAttribute(RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION) == null) {	
			countryList = getCountryList();
			session.setAttribute(
					RefDataUIConstants.GEO_SEARCH_COUNTRYLIST_SESSION,
					countryList);
		} 
	}
	/**
	 * the method to return all geoUnit Types
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	private List<CodeValue> retrieveAllGeoUnitTypes(){
		List<CodeValue> rows = new ArrayList<CodeValue>();
		List<CodeValue> geoUnitTypes =(List<CodeValue>)this.wsProxy.retrieveAllGeoUnitTypes();
		for (Iterator itr = geoUnitTypes.iterator(); itr.hasNext();) {
			LinkedHashMap curr = (LinkedHashMap) itr.next();
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((Integer)curr.get("codeValueId")).longValue());
			codeValue.setCodeTableId(((Integer)(curr.get("codeTableId"))));
			codeValue.setLiteralShortDescription((String)curr.get("literalShortDescription"));
			codeValue.setCodeValueDescription((String)curr.get("codeValueDescription"));
			rows.add(codeValue);
		}

		LOGGER.info("exiting GeographyCodesController | retrieveAllGeoUnitTypes");
		return rows;
	}
	/**
	 * 
	 * The method to sort the code value map 
	 *
	 * @param tempCodeValueMap
	 * @return tempCodeValueMap
	 */
	@SuppressWarnings({"rawtypes", "unchecked"})
	private Map<String, List<CodeValue>> sortCodeValuesById(Map<String, List<CodeValue>> tempCodeValueMap) {

		for(Entry<String, List<CodeValue>> entry : tempCodeValueMap.entrySet()) {
			if(entry.getValue() != null) {
				Collections.sort((List)entry.getValue(), scotsController.new CodeValueIdComparable());
			}
		}

		LOGGER.info("exiting GeographyCodesController | sortCodeValuesById | sorted map : " + tempCodeValueMap);
		return tempCodeValueMap;
	}
	/**
	 * 
	 * The method used to find the Official Geo Name
	 *
	 * @param geoUnit
	 * @param countryGeoUnitId
	 * @return officialGeoName
	 */
	private String findOfficialGeoName(GeoUnit geoUnit, Long countryGeoUnitId) {
		LOGGER.info("entering GeographyController | findOfficialGeoName");
		LOGGER.info("GeographyController | findOfficialGeoName | countryGeoUnitId : " + countryGeoUnitId);
		LOGGER.info("GeographyController | findOfficialGeoName | geoUnitNames : " + geoUnit.getGeoUnitNames());

		Long defLanguage = iterateCountryDefaultConfiguration(countryGeoUnitId);
		String officialGeoName = "";

		if(geoUnit.getGeoUnitNames() != null) {
			for(GeoUnitName geoUnitName : geoUnit.getGeoUnitNames()) {
				if(RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL.equals(geoUnitName.getNameTypeCode()) &&
						(RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH.equals(geoUnitName.getLanguageCode()) || 
								defLanguage.equals(geoUnitName.getLanguageCode()))) {
					officialGeoName = geoUnitName.getGeoName();
					break;
				}
			}
		}
		LOGGER.info("exiting GeographyController | findOfficialGeoName | returned : " + officialGeoName);
		return officialGeoName;
	}

	@RequestMapping(value = "/WDtoISO.form", method = RequestMethod.GET)
	public @ResponseBody
	ModelAndView downloadWDtoISOCodes(@RequestParam("fileName") String fileName,
			HttpServletResponse response) {
		LOGGER.info("Inside GeographyController || geoCrossWalk ");
		File file = null;
		file = new File(refdataConfig
				.getValue(RefDataPropertiesConstants.REFDATA_WDTOISOCODES_LOCATION)+ fileName);
		FileInputStream fin;
		try {
			fin = new FileInputStream(file);
			response.setContentType("application/xlsx");
			response.setHeader("Cache-Control","no-store");
			response.setHeader("Pragma", "private"); 	
			response.setContentLength((int) file.length());
			response.setHeader("Content-Disposition", "attachment; filename=\""
					+ fileName + "\"");
			FileCopyUtils.copy(fin, response.getOutputStream());
			response.getOutputStream().close();
			fin.close();
			response.flushBuffer();
		} catch (FileNotFoundException e) {
			LOGGER.error("Error in opening WDtoISOCodes file"+e);
		} catch (Exception e) {
			LOGGER.error("Error in opening WDtoISOCodes file"+e);
		}

		return null;
	}

	@RequestMapping(value = "/geoCrossWalk.form", method = RequestMethod.GET)
	public ModelAndView geoCrossWalk(Model model, HttpSession session) {
		LOGGER.info("entering GeographyController | geoCrossWalk");
		ModelAndView geoCrossWalk = new ModelAndView("geoCrossWalk");

		return geoCrossWalk;

	}
}
