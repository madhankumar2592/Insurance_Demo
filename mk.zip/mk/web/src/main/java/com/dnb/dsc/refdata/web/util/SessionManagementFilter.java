/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.web.util;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * Detects that a user has been authenticated since the start of the request
 * and, if they have, calls the configured {@link SessionAuthenticationStrategy}
 * to perform any session-related activity such as activating session-fixation
 * protection mechanisms or checking for multiple concurrent logins.
 * 
 * 
 * @author Cognizant Technology Solutions
 * @version last updated : Mar 8, 2012
 * @see Cognizant
 * 
 */
public class SessionManagementFilter implements Filter {
	
	private final Logger LOGGER = LoggerFactory.getLogger(SessionManagementFilter.class);
	
	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain fc) 
	throws IOException, ServletException {
		LOGGER.info("Inside SessionManagementFilter | doFilter");
		
		HttpServletRequest httpReq = (HttpServletRequest) req;
		HttpServletResponse httpResp = (HttpServletResponse) resp;
		String uri = httpReq.getRequestURI();
		if ((uri != null) && (uri.endsWith("logout.html"))) {	
			LOGGER.info("Inside SessionManagementFilter | doFilter | Checking URI");
			fc.doFilter(req, resp);
		} else {
			LOGGER.info("Inside SessionManagementFilter | doFilter | Validating URI");
			HttpSession session = httpReq.getSession(true);
			if ((session != null)) {
				fc.doFilter(req, resp);
			} else {
				LOGGER.info("Inside SessionManagementFilter | doFilter | Validating Session and redirecting to login");
				httpResp.sendRedirect("/logout.html");
			}
		}
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub		
	}
}
