$(document).ready(function(){
	
	bindScoreSearchEvents();	
	if($("#successGranValMap").val())	
	{
		alert("Granularity values are added in Reference Data SOR successfully");
	}
	 	
});

function bindScoreSearchEvents(){
var flag = false;
$('#scoreResetButton').bind('click', function(){
	location.href = "addScoreMappingHome.form";
	return false;
});
	
$('#scoreCancelButton').bind('click', function(){
	location.href = "addScoreMappingHome.form";
	return false;
});
	
$('#scoreTypeCode').change(function(){
		if(($.trim($('#scoreTypeCode').val()) != '')){
			var scoreType = $('#scoreTypeCode').val();
			populateMarketTypeCodes(scoreType);
		}
	});

$('#marketTypeCode').change(function(){
	if(($.trim($('#scoreTypeCode').val()) != '')&&($.trim($('#marketTypeCode').val()) != '')){
		var scoreType = $('#scoreTypeCode').val();
		var marketType = $('#marketTypeCode').val();
		flag = false;
		populatescoreVersion(scoreType,marketType);
	}
});

$(document).ajaxComplete(function() {
		if(!(flag) ) {
			if(($.trim($('#scoreVersion').val()) != '')){
				$('#attributeDetails').css("display","none");
				$('td.newClass1').remove();
				$('td.newClass').remove();				
				$('tr.txtbox').not(':first').remove();
				var scoreType = $('#scoreTypeCode').val();
				var marketType = $('#marketTypeCode').val();
				var scoreVersion = $('#scoreVersion').val();
				flag = true;
				populateAttributeDetails(scoreType,marketType,scoreVersion);
			}			
		}
});

$('#scoreVersion').change(function(){
	if(($.trim($('#scoreTypeCode').val()) != '')&&($.trim($('#marketTypeCode').val()) != '')&&($.trim($('#scoreVersion').val()) != '')){
		$('#attributeDetails').css("display","none");
		//$('tr.attributeDetailTable').not(':first').remove(); 
		//$("#attributeDetailTable").find('tr').slice(1,-1).remove()
		$('td.newClass1').remove();
		$('td.newClass').remove();				
		$('tr.txtbox').not(':first').remove();
		var scoreType = $('#scoreTypeCode').val();
		var marketType = $('#marketTypeCode').val();
		var scoreVersion = $('#scoreVersion').val();
		populateAttributeDetails(scoreType,marketType,scoreVersion);
	}
});
}

function populateMarketTypeCodes(scoreType) {
	$.getJSON('retrieveMarketTypeCodes.form', {
		scoreType : scoreType
	}, function(data) {
		$("#marketTypeCode").prop("disabled",false);
		$("#marketTypeCode").empty();
		$("#marketTypeCode").append('<option value="">--  Select Market Type Code  --</option>'); 
		$.each(data, function() {
			 $("#marketTypeCode").append('<option value="' + this.code + '">' + "["+ this.code +"] "+ this.value + '</option>'); 

		 }); 
	});
	
}

function populatescoreVersion(scoreType,marketType) {
	$.getJSON('retrievescoreVersions.form', {
		scoreType : scoreType,
		marketType : marketType
	}, function(data) {
		$("#scoreVersion").prop("disabled",false);
		$("#scoreVersion").empty();
		$.each(data, function() {
			 $("#scoreVersion").append('<option value="' + this.scoreVersion + '">' + this.scoreVersion + '</option>'); 
		 }); 
	});
	
}

function populateAttributeDetails(scoreType,marketType,scoreVersion) {
	$.getJSON('retrieveAttributeDetails.form', {
		scoreType : scoreType,
		marketType : marketType,
		scoreVersion : scoreVersion
	}, function(data) {
	$("#attributeDetails").css("display","block");	
	var cnt = 1;
		$.each(data, function() {
			$("#dynamicLabelTR").append(' <td class="newClass1" width="20%"><strong id="'+this.scoreMappingLabel+cnt+'">'+this.scoreMappingLabel+ '</strong></td>'); 
			$("#dynamicTxtBoxTR").append(' <td class="newClass" width="30%"><input onblur=\'if((this.value)==""){this.value=0;}\' type="text" maxlength=30 class="inputtxt" id="'+this.scoreMappingLabel+'_SCRID_'+this.scoreId+'_SCRGRUASSNID_'+this.scoreGranuAssnId+'_'+cnt+'""  /></td>');
			}); 
		if ($(".newClass1")[0]){		
			$("#dynamicTxtBoxTR").append('<td class="newClass" > <strong class="removeDescriptionRowLink"></strong> <strong	class="addDescriptionRowLink"> <a href="javascript:;" style="text-decoration: none;" onclick="addGranularityRow();">[+]</a>	</strong> </td>');
		}
		else{
			$("#attributeDetails").hide();
		}
		});
}

function addGranularityRow(){

	var nextIndex = $('#attributeDetailTable tr').length;
	 var clones = $('#attributeDetailTable tr:last').clone();
	 var index=$('#attributeDetailTable tr:last').attr('id');
	 var clonedInPuts=clones.find('input');
	 jQuery(clonedInPuts).each(function (){
	        jQuery(this).val("");
	        var inputId=jQuery(this).attr('id');
			var arr1 = inputId.substring(inputId.lastIndexOf('_')+1,inputId.length);
			var number = Number(arr1)+1;
			var idVal = inputId.substring(0,inputId.lastIndexOf('_')) +('_')+ (number);				
			jQuery(this).attr('id',idVal);
	 });
	 $('#attributeDetailTable').append(clones);
	var newlyAddedGranularityRow = $('#attributeDetailTable tr:last');
	$('#attributeDetailTable').find('tr:last').find('.removeDescriptionRowLink').
	html('<a href="javascript:;" style="text-decoration: none;" onclick="removeGranularityRow(this,' + nextIndex + ');">[-]</a>');
	newlyAddedGranularityRow.show();
	return false;

}

function removeGranularityRow(removeHandle, rowIndexToDelete){
	if($('#attributeDetailTable:visible').length ==3){
		alert("At least one row is mandatory");
		return false;
	}
	 else  {
		$(removeHandle).closest('tr').remove();
	}
	
	$('#attributeDetailTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			$(this).find('.removeDescriptionRowLink').html($(this).find('.removeDescriptionRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function validateFormFields() {
	var granLength = $('#attributeDetailTable tr:visible').length;
	
	if($('#scoreTypeCode').val()== '') {
		$('#errorMsg').text("Please select Score Type Code");
		$('#errorMsg').css("display","block");
	}else if ($('#marketTypeCode').val()== '') {
		$('#errorMsg').text("Please select Market Type Code");
		$('#errorMsg').css("display","block");
	}else if ($('#scoreVersion').val()== '') {
		$('#errorMsg').text("Please select Score Version");
		$('#errorMsg').css("display","block");
	}else if(granLength == 0) {
		$('#errorMsg').text("No granularity mapping is available for this Score Type Code and Score Market Code");
		$('#errorMsg').css("display", "block");				
	}else {
						var scrTypText = $('#scoreTypeCode :selected').text();
						var mktCdText = $('#marketTypeCode :selected').text();
						var versionText = $('#scoreVersion :selected').text();
							var granVal = new Array();
							$('.scoreGraCode :selected').each(function() 
							{					
								granVal.push($(this).text());
							});
								var retVal = confirm("Are you sure you want to map "+scrTypText+" to "+mktCdText+" with Version "+versionText+" to the entered Granularity Values?");
								if( retVal == true ){		
						var idData="";	
						var idArr="";
						$('#attributeDetailTable').each(function() {
							$("tr.txtbox:last").each(function() {
								$(this).find('input').each (function() {
									var $input = $( this );
									var id = $input.attr('id');
									idArr = id.split('_');
									idData = idData+"~#"+idArr[4];
								});	
							});
						});
					idData = idArr[2]+idData;
					var arrNew = new Array();
						arrNew.push(idData);
						$('#attributeDetailTable').each(function() {
							$("tr.txtbox:").each(function() {
								var tableData = "";
								$(this).find('input').each (function() {
									var $input = $( this );
									var value = $input.attr('value');
									if(value=="" || value==null) {
										value = "0";
									}
									tableData = tableData + value + "~#";
								});
								tableData = tableData.slice(0, -2);			
								arrNew.push(tableData);
							});
						});
						$('.scrGranuValueList').attr('value',arrNew);
						//alert("The records will be updated in the Reference Data SOR");
						$('#ScoreMappingHome').submit(); 		
						return true;
						}else{
												  return false;
								}
		
		
	}
}


function validateGranValue(evt) {
	
	  var regex = new RegExp("^[a-zA-Z0-9%]+$");
	    var key = String.fromCharCode(!evt.charCode ? evt.which : evt.charCode);
	    if (!regex.test(key)) {
	       evt.preventDefault();
	       return false;
	    }
		if(key == e.shiftKey && key == 53)
		{
		 return true;
		 }
}



