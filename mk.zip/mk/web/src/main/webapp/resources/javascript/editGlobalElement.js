$(document).ready(function(){
	bindAddGlobalElementEvents();			 
});


function bindAddGlobalElementEvents(){
	$('#addGlblEleEditButton').bind('click', function(){
		initializeAddCdValDatepicker();	
		$(".editable").prop("disabled",false);
		$('.cdValDatepickerTextBox').datepicker('enable');
		$('.geoDatepickerTextBox').datepicker('enable');
		
		$("#glblEleTypeCode").prop("disabled",false);
		$("#glblEleTopicCode").prop("disabled",false);	
		$("#glblEleName").prop("disabled",false);
		$("#glblEleComment").prop("disabled",false);
		$("#longDesc").prop("disabled",false);
		$("#detailComment").prop("disabled",false);
		$("#addGlblEleSubmitButton").show();
		$("#addGlblEleEditButton").hide();
	});
	
	$('#addGlblEleResetButton').bind('click',function(event){
		
		var elemntId = $('#elementID').val();
		
		if(confirm("Are you sure you want to reset the data?")) {
			event.preventDefault();
			location.href = "editGlobalElementSearch.form?elementID="+ elemntId + "";
			return false; // to prevent event bubbling
		}
	});
	
	$('#addGlblEleSubmitButton').bind('click',function(){
		
		$('#glblEleLangCode').val('39');
		
		var flag = validateComment();		
		var effectiveDate = $('#cdValEffectiveDate').val();
		
		var date1 = isValidDate($('#cdValEffectiveDate').val());
		var date2 = isValidDate($('#expirationDate').val());
		
		if($('#glblEleTypeCode').val() == ""){
			$('#errorMsg').html("Please select Global Element Type");
			$('#errorMsg').show();
		}else if($('#glblEleTopicCode').val() == ""){
			$('#errorMsg').html("Please select Topic Category");
			$('#errorMsg').show();
		}else if($.trim($('#glblEleName').val()) == ""){
			$('#errorMsg').html("Please enter Element Name");
			$('#errorMsg').show();
		}else if($('#cdValEffectiveDate').val() == ""){
			$('#errorMsg').html("Please enter Effective date");
			$('#errorMsg').show();
		}else if(($('#expirationDate').val() != "") && (($('#expirationDate').val() < effectiveDate) || (!date2))){
			$('#errorMsg').html("Expiration date should be greater than or equal to effective date and in yyyy-mm-dd format");
			$('#errorMsg').show();
		}else if(!date1){
			$('#errorMsg').html("Please enter Effective date in yyyy-mm-dd format");
			$('#errorMsg').show();
		}else if ($('#glblEleLangCode').val() == '') {				
			$('#errorMsg').html("Please select a Language");
			$('#errorMsg').show();
		}else if($.trim($('#shortDesc').val()) == ""){
			$('#errorMsg').html("Please provide Short Description value");
			$('#errorMsg').show();
		}else if($('#shortDesc').val().length > 4000){		
			$('#errorMsg').html("The short description entered should be of 4000 characters or less");
			$('#errorMsg').show();
		}else if($('#longDesc').val().length > 4000){		
			$('#errorMsg').html("The long description entered should be of 4000 characters or less");
			$('#errorMsg').show();				
		}else if(flag){
				$('#errorMsg').html("Global Element Comment is Mandatory if Expiration date is set");
				$('#errorMsg').show();
		}else {
				$('#errorMsg').hide();				
				if(confirm("Are you sure you want to Edit Global Element ")) {
					$('#editGlobalElementForm').submit();
				}
		}
		
	});
	
}

function validateComment(){
		if($('#expirationDate').val() != ""){
			if($.trim($('#glblEleComment').val()) == ""){
				return true;
			}
			return false;			
		}
}

function initializeAddCdValDatepicker(){
	$('.addCdValDatepickerTextBox').removeClass('hasDatepicker').datepicker(
			getDatepickerOptions(true));
	$('.addCdValDatepickerTextBox').datepicker('enable');
}

function isValidDate(dateString) {
	var regEx = /^\d{4}-\d{2}-\d{2}$/;
	var dtArray = dateString.match(regEx); 
	if (dtArray == null) {
        return false;
	}
	var splitdate = dateString.split('-');
	dtYear = splitdate[0];
	dtMonth = splitdate[1];
	dtDay = splitdate[2];
	
	if (dtMonth < 1 || dtMonth > 12) {
        return false;
    }else if (dtDay < 1 || dtDay> 31) {
        return false;
    }else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) {
        return false;
	}else if (dtMonth == 2) 
    {
		alert(isleap);
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
		alert(isleap);
        if (dtDay> 29 || (dtDay ==29 && !isleap)) {
            return false;
		}
    }
    return true;
}