/**
 * This file serves industryCodeSearch.jsp
 */
var indsCodeSearchResultsTable;
var indsCrosswalkSearchResultsTable;
var toggleIndc = 'VALUE';

$(document).ready(function() {
	bindIndustryCodesSearchEvents();
	initializeIndustryCodesSearchElements();
	configureIndsCodeSearchDataTable();
});

function bindIndustryCodesSearchEvents() {
// $('#indsCodeSearchLink').bind('click',function(event) {
// event.preventDefault();
// location.href = "indsCodeSearchHome.form";
// return false; // to prevent event bubbling
// });
	
	$('#indsCodeSearchBtn').bind('click',
		function(event) {
			if ($.trim($('#codeTable').val()) == "") {
				$('#indsCodeExportBtn').hide();
				$('#errorMsg').show();
				$('#indsCodeSearchResults').hide();
			} else {
				$('#errorMsg').hide();
				if (isValidationSuccess()) {					
					if ($.trim($('#codeCrosswalk').val()) == '') {						
						$('#indsCodeExportBtn').show();
						indsCodeSearchResultsTable
								.fnFilter(getIndustryCodeSearchCriteria());
						modifyIndustryCodeHeader();
						$('#indsCodeSearchResults').show();
						$('#indsCrosswalkSearchResults').hide();
					} else {	
						$('#indsCodeExportBtn').show();
						indsCrosswalkSearchResultsTable
								.fnFilter(getIndustryCodeSearchCriteria());
						modifyIndustryCodeCrosswalkHeaderOne();
						modifyIndustryCodeCrosswalkHeaderThree();
						$('#indsCrosswalkSearchResults').show();
						$('#indsCodeSearchResults').hide();
					}
				}
			}
		});
	
	
	
	$('#indsCodeExportBtn').bind('click',
			function(event) {		
		var criteriaString=encodeURIComponent(getIndustryCodeSearchCriteria());
		if ($.trim($('#codeCrosswalk').val()) == '') {
			location.href = "indsCodeExportToExcelResults.form?type=export&sSearch="+criteriaString+"&export=IndsCode";
		}else{	
			$('#agree').attr('checked', false); 
			$("#alertSection1").css("display","block");	
			$("#ok").click(function(event) {				
				if(document.getElementById("agree").checked)
				{
					$("#alertSection1").css("display","none");	
					location.href = "indsCodeExportToExcelResults.form?type=export&sSearch="+criteriaString+"&export=CrossWalk";	
				}
				else
				{
					alert("You are not allowed to download the industry code crosswalk");
					event.stopImmediatePropagation(); 
					return false;
				}
				});
						
		}
		return false; // to prevent event bubbling
	});	
	
	
	$('#codeTable').bind('change',function(){
		$('#indsCodeSearchResults').hide();
		$('#indsCodeExportBtn').hide();
		$("#codeTableLanguage").add("#codeCrosswalkLanguage").empty();
		$("#codeTableLanguage").add("#codeCrosswalkLanguage").attr('disabled','disabled');
		$("#codeCrosswalk").empty();
		$("#codeCrosswalk").append('<option value="">-- Select To Industry Type Code --</option>');
	if($.trim($(this).val()) != '') {
			$('#errorBlock').hide();
			populateGroupLevelCodes($(this).val(), 0);
			populateCrossWalk($(this).val());
			populateLanguage($(this).val(), $('#codeTableLanguage'), false);
		}
			
	});
	
	$('#codeCrosswalk').bind('change',function(){
		$('#indsCodeSearchResults').hide();
		$('#indsCodeExportBtn').hide();
		$("#codeCrosswalkLanguage").empty();
		$("#codeCrosswalkLanguage").attr('disabled','disabled');
		if($.trim($(this).val()) != '') {
			$('#errorBlock').hide();
			populateLanguage($(this).val(), $('#codeCrosswalkLanguage'), false);
		} 
			
	});
	
	$('#indsCodeToggleBtn').bind('click',function(event){
		toggleIndsCodeTable();
	});
	
	bindGroupLevelCheckBox();
	
	$('#codeTableLanguage').on('change', function(){
		$('#indsCodeExportBtn').hide();
		if(($.trim($('#codeTable').val()) != '') &&
			($.trim($(this).val()) != '')){
			populateGroupLevelCodes($('#codeTable').val(), $(this).val());
		}
	});
}

function bindGroupLevelCheckBox(){
	$('.grpLvlChk').on('change',function(event) {
		//populateLanguage($('#codeTable').val(), $('#codeTableLanguage'), true);
	});
}

function modifyIndustryCodeHeader(){
	var selectedText = $('#codeTable :selected').text();
	if(toggleIndc == 'VALUE') {
		$('#indsCodeSearchResultsTable thead tr th').eq(0).html("<span>"+
				selectedText.substring(selectedText.indexOf('[') + 1).replace("]","") + "</span>");
	} else {
		$('#indsCodeSearchResultsTable thead tr th').eq(0).html("<span>"+
				selectedText.substring(0, selectedText.indexOf('[')) + "</span>");
	}
}

function modifyIndustryCodeCrosswalkHeaderOne(){
	var selectedText = $('#codeTable :selected').text();
	if(toggleIndc == 'VALUE') {
		$('#indsCrosswalkSearchResultsTable thead tr th').eq(0).html("<span>"+
				selectedText.substring(selectedText.indexOf('[') + 1).replace("]","") + "</span>");
	} else {
		$('#indsCrosswalkSearchResultsTable thead tr th').eq(0).html("<span>"+
				selectedText.substring(0,selectedText.indexOf('[')) + "</span>");
	}
}

function getIndustryCodeDescription(industryCodeSelected){
	if(toggleIndc == 'VALUE') {
		return industryCodeSelected.substring(industryCodeSelected.indexOf('[') + 1).replace("]","");
	} else {
		return industryCodeSelected.substring(0,industryCodeSelected.indexOf('['));
	}
}

function modifyIndustryCodeCrosswalkHeaderThree(){
	var selectedText = $('#codeCrosswalk :selected').text();
	$('#indsCrosswalkSearchResultsTable thead tr th').eq(2).html("<span>" + 
			selectedText.substring(selectedText.indexOf('[') + 1).replace("]","") + "</span>");
}

function getIndustryCodeSearchCriteria() {
	var searchCriteriaDelimiter = "#~";
	var crosswalkText = "";
	if($.trim($('#codeCrosswalk').val()) != ''){
		crosswalkText = $('#codeCrosswalk :selected').text();
	}
	var searchCriteria = $('#codeTable').val() + searchCriteriaDelimiter + 
						 getIndustryCodeDescription($('#codeTable :selected').text()) + searchCriteriaDelimiter + 
						 $('#indsCodeDesc').val() + searchCriteriaDelimiter + 
						 $('#codeCrosswalk').val() + searchCriteriaDelimiter + 
						 crosswalkText + searchCriteriaDelimiter + 
						 getGroupLevelSearchCodes() + searchCriteriaDelimiter + 
						 $('#codeTableLanguage').val() + searchCriteriaDelimiter + 
						 $('#codeCrosswalkLanguage').val();
	
	return searchCriteria;
}

function getGroupLevelSearchCodes() {
	var groupLvlTbl = $('#groupLevelsTbl').find('tr:eq(0) td');
	var grpLvlCds = '';
	for(indx = 1; indx < groupLvlTbl.length;) {
		var chkbox = groupLvlTbl.eq(indx).find('.grpLvlChk');
		if(chkbox.attr('checked')) {
			grpLvlCds = grpLvlCds + chkbox.val() + '/';
		}
		indx = indx + 2;
	}
	return grpLvlCds;
}

function isValidationSuccess(){
	var dataStr = $.trim($('#indsCodeDesc').val());
	if(dataStr == ''){
		return true;
	}else{
// var validationStr = /^[A-Za-z0-9\s]+$/gi;
// if(!validationStr.test(dataStr)){
// alert('Only alphabets, numbers, and space are allowed in search criteria');
// return false;
// }else{
// return true;
// }
			return true;
		}
	}
function initializeIndustryCodesSearchElements() {
// to do
}

function configureIndsCodeSearchDataTable(){
	
	indsCodeSearchResultsTable = $("#indsCodeSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "indsCodeSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aoColumns": [null,null,null,{ "bVisible": false },{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnIndustryCodeColumns(nRow, aData);		
		   	return nRow;
        }
  });
	
	indsCrosswalkSearchResultsTable = $("#indsCrosswalkSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "indsCodeCrosswalkSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aoColumns": [null,null,null,null,null,{ "bVisible": false },{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnIndustryCodeCrosswalkColumns(nRow, aData);		
		   	return nRow;
        }
  });
	
}

function populateGroupLevelCodes(indsCodeType, languageCode) {
	$.getJSON('retrieveGroupLevelCodes.form', {
		industryCodeType : indsCodeType,
		languageCode : languageCode
	}, function(data) {
		if(data != '') {
			var tblTd = '<td><strong>Select Group Level : &nbsp;&nbsp;</strong></td>';
			$.each(data, function() {
				tblTd = tblTd + getGroupLevelsColumnHtml(this.code, this.value);			
			 });
			$('#groupLevelsTbl').find('tr:eq(0)').html(tblTd);
			$('#groupLevelsTbl').show();
			bindGroupLevelCheckBox();
		} else {
			$('#groupLevelsTbl').find('tr:eq(0)').html('');
			$('#groupLevelsTbl').hide();
		}
	});
}

function populateCrossWalk(indsCodeType) {
	$.getJSON('retrieveCrossWalksForIndsCodeType.form', {
		industryCodeType : indsCodeType,
		ajax : 'true'
	}, function(data) {
		$("#codeCrosswalk").empty();
		$("#codeCrosswalkLanguage").empty();
		$("#codeCrosswalk").append('<option value="">--  Select To Industry Type Code  --</option>'); 
		$.each(data, function() {
			 $("#codeCrosswalk").append('<option value="' + this.code + '">' + this.value + '</option>'); 
		 }); 
	});
}

function populateLanguage(indsCodeType, langObj, hasGrpLvlFilter) {
	var groupLevelCode = '';
	var hasEnglish=false;
	if(hasGrpLvlFilter) {
		groupLevelCode = getGroupLevelSearchCodes();
	}
	$.getJSON('retrieveLanguageForIndsCodeType.form', {
		industryCodeType : indsCodeType,
		groupLevelCode : groupLevelCode,
		ajax : 'true'
	}, function(data) {
		langObj.empty();
		$.each(data, function() {
			langObj.append('<option value="' + this.code + '">' + this.code + " [ " + this.value + " ] " + '</option>');
			langObj.removeAttr('disabled');
			if(this.code==39){
				hasEnglish= true;
			}
		 }); 
		if(hasEnglish) {
			langObj.val(39);
		}
	});
}

var globalIndx = 0;
function toggleIndsCodeTable() {
	if(globalIndx == 0) {
		globalIndx = globalIndx + 1;
	}
	$.getJSON('toggleIndsCodeTable.form', {
		toggleIndicator : toggleIndc,
		ajax : 'true'
	}, function(data) {
		$("#codeTable").empty();
		$("#codeTable").append('<option value="">--  Select Industry Code Table  --</option>'); 
		if(toggleIndc == 'CODE') {
			$.each(data, function() {			 
				 $("#codeTable").append('<option value="' + this.codeValueId + '">' + this.codeValueId + ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
			});
			toggleIndc = 'VALUE';
		} else {
			$.each(data, function() {			 
				 $("#codeTable").append('<option value="' + this.codeValueId + '">' + this.codeValueDescription + ' [ ' + this.codeValueId + ' ] ' + '</option>');
			});
			toggleIndc = 'CODE';
		}
	});
}

function setHyperLinkOnIndustryCodeColumns(nRow, aData){
	$('td:eq(0)', nRow).html(getIndustryCodeColumnHtml(aData[3], aData[0]));
	$('td:eq(1)', nRow).html(getIndustryCodeColumnHtml(aData[3], aData[1]));
	$('td:eq(2)', nRow).html(aData[2] + ' [' + aData[4] + ']');
}

function getIndustryCodeColumnHtml(code, value){
	return "<a href='indsCodeDetail.form?industryCodeId=" + code + "&taskId=' class='list'>" + value + "</a>";
}

function setHyperLinkOnIndustryCodeCrosswalkColumns(nRow, aData){	
	$('td:eq(0)', nRow).html(getIndustryCodeCrosswalkColumnHtml(aData[5], aData[0]));
	if(aData[1] != null) {
		$('td:eq(1)', nRow).html(getIndustryCodeCrosswalkColumnHtml(aData[5], aData[1]));
	} else {
		$('td:eq(1)', nRow).html("");
	}
	$('td:eq(2)', nRow).html(getIndustryCodeCrosswalkColumnHtml(aData[6], aData[2]));
	if(aData[3] != null) {
		$('td:eq(3)', nRow).html(getIndustryCodeCrosswalkColumnHtml(aData[6], aData[3]));
	} else {
		$('td:eq(3)', nRow).html("");
	}
	$('td:eq(4)', nRow).html(getPreferredIndicator(aData[4]));
}

function getIndustryCodeCrosswalkColumnHtml(code, value) {
	return "<a href='indsCodeDetail.form?industryCodeId=" + code + "&taskId=' class='list'>" + value + "</a>";
}

function getPreferredIndicator(indicator) {
	if (indicator == '1') {
		return '<input type="checkbox" disabled="disabled" checked="checked" />';
	} else {
		return '<input type="checkbox" disabled="disabled" />';
	}
}

function getGroupLevelsColumnHtml(code, value) {
	return '<td><input type="checkbox" checked="checked" class="grpLvlChk" value="' 
		+ code + '" /></td><td>' + value + '&nbsp;&nbsp;</td>';	
}




