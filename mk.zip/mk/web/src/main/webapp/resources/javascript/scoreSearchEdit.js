$(document).ready(function(){
	initializeScoreElements();
	$('#scoreMarketCodes').attr('disabled','disabled');
	var granValTblLength = $('#scoreGranularityTable tr:visible').length;
	if(granValTblLength == 3){
		$('#outerViewDivBoxIdGran').hide();
		$('#errorMsg').text("No Granularity values are there for this Score Type Code & Score Market Code");
		$('#errorMsg').css("display","block");	
		$('#scoreSearEditSaveButton').attr('disabled','disabled');
		}
	
});

function initializeScoreElements() {
	$('#scoreSearEditSaveButton').bind('click', function(){	
		var scrTypeCode = $('#scrTypCode').val().replace(/\D/g,'');
		var scrMarketCode = $('#scoreMarketCodes').val();
		var scrVersion = $('#scrVersion').val();
		var oldscoreVersion = $('#oldScrVersion').val();		
		var granValLength = $('#scoreGranularityTable tr:visible').length;
		
		if($('#scrVersion').val()== '') {
			$('#errorMsg').text("Please enter score version");
			$('#errorMsg').css("display","block");
		}else if ($('#scoreMarketCodes').val()== '') {
			$('#errorMsg').text("Please select Market Type Code");
			$('#errorMsg').css("display","block");
		}else if($('#scrVersion').val().split(".")[0] == '' || $('#scrVersion').val().split(".")[1] == ''){
			alert("Please enter a valid Version number");
		}else if($('#scrVersion').val().split(".")[0].length > 4){
			alert("Number of digits allowed in version before dot(.) is four");			
		}else if ($('#scrVersion').val()%1 != 0 && $('#scrVersion').val().split(".")[1].length > 2){	
			alert("Number of digits allowed in version after dot(.) is two");
		}else if (granValLength == 0) {
			$('#errorMsg').text("No Granularity values are present for the selected Score Market Code. Please check for other Score Market Code");
			$('#errorMsg').css("display","block");
		}else if(scrVersion != oldscoreVersion){			
			var isduplicate = isDuplicateScore(scrTypeCode,scrMarketCode,scrVersion);					
			if(isduplicate){
				$('#errorMsg').text("The Score with the same version is already present for the given Market. Please select different version");
				$('#errorMsg').css("display","block");
			}else{
				validateAndSubmit();
			}
		}else {
			validateAndSubmit();
		}
	});
	
	$('#scoreSearEditResetButton').bind('click', function(){
		var value1 = document.getElementById('scrID').value;
		var value2 = document.getElementById('scrTypCode').value.match(/\d+/);
		
		location.href = "editScoreSearch.form?scrID=" + value1 + "&scrTypCd="+value2+"";
		return false;
	});
	
	$('#scoreSearEditCancelButton').bind('click', function(){
		location.href = "scoreSearchHome.form";
		return false;
	});
	$("#scoreMarketCodes option").each(function() {
		var mktCd = $("#mktCd").val();
		  if($(this).val() == mktCd) {
		    $(this).attr('selected', 'selected');            
		  }                        
		});
}

function validateAndSubmit(){
		$('#errorMsg').hide();
		$('#scoreSearEditSaveButton').removeAttr('disabled');
		
		var scrTypText = $('#scrTypCode').val();
		var mktCdText = $('#scoreMarketCodes :selected').text();
		var versionText = $('#scrVersion').val();
		
		var granVal = new Array();
					$('.mapValues').each(function() 
					{					
						granVal.push($(this).text());
					});
						var retVal = confirm("Are you sure you want to map "+scrTypText+" to "+mktCdText+" with Version "+versionText+" , to the Granularities "+granVal+"?");
						if( retVal == true ){	
							$('#scoreMarketCodes').removeAttr('disabled');
							$('#scoreSearEditSaveButton').attr('disabled','disabled');
							$('#scoreEditForm').submit();
						  return true;
						}else{
						  return false;
						}		


}

function removeProductMetadataRow(removeHandle, rowIndexToDelete) {
	$('#errorMsg2').css("display","none");
	
		$(removeHandle).closest('.MetaRow').remove();
		$(".MetaRows").each(function() {
		  if($(this).attr('id') == rowIndexToDelete) {
		    $(this).remove();            
		  }                        
		});
	
	$('#scoreGranularityTable .MetaRow').each(
			function() {
				if (this.rowIndex > rowIndexToDelete) {
					
					$(this).find('.removeProductMetadataRowLink').html(
							$(this).find('.removeProductMetadataRowLink')
									.html().replace(/[0-9]+/,
											(this.rowIndex - 1)));
				}
			});
	return false;
}

function validateVersion(evt) {
 
	var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode == 46 && evt.srcElement.value.split('.').length>1) {
        return false;
    }
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function isDuplicateScore(scrTypeCode,scrMarketCode,scrVersion){
	var duplicateFlag = false;	
	var param = {scoreTypeCode: scrTypeCode, scoreMarketCode: scrMarketCode, scoreVersion: scrVersion};
	$.ajax({
        url : "checkForDuplicate.form",
		async: false,
        data : param,
        success : function(data) {			
      	  	if(data){      	  		
      	  		duplicateFlag = true;      	  		
      	  	}
        }
 });	
	return duplicateFlag;
}
