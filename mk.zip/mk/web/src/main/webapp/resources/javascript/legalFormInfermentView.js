/**
 * This JS file is for legalFormInfermentView.jsp
 */

$(document).ready(function() {
	bindLegalFormInfermentViewEvents();
});

function bindLegalFormInfermentViewEvents() {
	$("#legalFormInfermentEditButton").click(function() {
		if($(this).val()=="Edit") {
			$('#errorBlock').hide();
			$.getJSON('lockInfermentTextForEdit.form', {
				ajax : 'true'
			}, function(data) {
				if(data == true) {
					$('#errorMsg').html('The record is locked by another user due to a pending request on the Work Queue.');
					$('#errorMsg').show();
					return false; //to prevent event bubbling
				} else if(data!=null){
					$('#pageTitle').html('Legal Form Inferment - Edit');
					$('#bcktosrch').html('<a href="#" id="legalFormInfermentBack">Legal Form Inferment</a>&nbsp;&nbsp;>&nbsp;&nbsp;Legal Form Inferment Edit');
					document.title = "Legal Form Inferment - Edit";
					enableEditLegalFormInfermentText();
					return false; //to prevent event bubbling
				}
			});
		}
	});
	$('#legalFormInfermentCancelButton').bind('click',function(event) {
		event.preventDefault();
		location.href = "legalFormInferment.form";
		return false; // to prevent event bubbling
	});
	
	$('#legalFormInfermentBack').bind('click',function(event){
		event.preventDefault();
		location.href = "legalFormInferment.form";
		return false; // to prevent event bubbling
	});	
}

function enableEditLegalFormInfermentText() {
	$(".showable").show();
	$("#initialCountries").hide();
	$("#editCountries").show();
	$("#pageTitle").html('Legal Form Inferment - Edit');
	$("#legalFormInfermentEditButton").val('Update');
	$('.geoDatepickerTextBox.expirationDate').datepicker('enable');
	$(".editable").removeAttr("disabled");
	$("#legalFormInfermentEditButton").click(function() {
		if(isLegalFormDataCorrect()){
			$("#legalFormInfermentForm").submit();
		}
	});
}

function removeLegalFormInfermentRow(removeHandle, rowIndexToDelete){
		$('#legalFormInfermentTable tr').eq(rowIndexToDelete + 1).find('.effectiveDate').datepicker('destroy');
		$('#legalFormInfermentTable tr').eq(rowIndexToDelete + 1).find('.expiredByDate').datepicker('destroy');
		
		$(removeHandle).closest('tr').remove();
		
		$('#legalFormInfermentTable tr').each(function() {
			if(this.rowIndex > rowIndexToDelete){
				updateNames($(this).find('.legalFormCode'), (this.rowIndex - 1), 'legalFormInferments', 'legalFormCode');
				updateNames($(this).find('.legalFormClassCode'), (this.rowIndex - 1), 'legalFormInferments', 'legalFormClassCode');
				$(this).find('.effectiveDate').datepicker('destroy');
				updateNames($(this).find('.effectiveDate'), (this.rowIndex - 1), 'legalFormInferments', 'effectiveDate');
				$(this).find('.effectiveDate').removeClass('hasDatepicker');
				$(this).find('.effectiveDate').datepicker(getDatepickerOptions(false));
				
				$(this).find('.expirationDate').datepicker('destroy');
				updateNames($(this).find('.expirationDate'), (this.rowIndex - 1), 'legalFormInferments', 'expirationDate');
				$(this).find('.expirationDate').removeClass('hasDatepicker');
				$(this).find('.expirationDate').datepicker(getDatepickerOptions(false));
				$(this).find('.removeLegalFormRowLink').html($(this).find('.removeLegalFormRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
			}
		});
		return false;
	}
function addLegalFormInfermentNewRow() {
	var nextIndex = $(".legalFormClassCode").length;
	$('#legalFormInfermentTable').append($('#legalFormInfermentTable').find('.containerRow:last').clone());
	$('#legalFormInfermentTable').find('.containerRow:last').find('.removeLegalFormRowLink').
	html('<a href="javascript:;" style="text-decoration: none;" onclick="removeLegalFormInfermentRow(this,' + nextIndex + ');">[-]</a>');
	var newlyAddedChildRow = $('#legalFormInfermentTable tr:last');
	newlyAddedChildRow.find('.editOnAdd').removeAttr('disabled');
	newlyAddedChildRow.find('.ui-datepicker-trigger').remove();
	updateNamesOfNewRow(newlyAddedChildRow, '.legalFormCode', nextIndex,'legalFormInferments', 'legalFormCode', "false");
	updateNamesOfNewRow(newlyAddedChildRow, '.legalFormClassCode', nextIndex,'legalFormInferments', 'legalFormClassCode', "false");
	updateNamesOfNewRow(newlyAddedChildRow, '.expirationDate', nextIndex,'legalFormInferments', 'expirationDate', "false");
	updateNamesOfNewRow(newlyAddedChildRow, '.effectiveDate', nextIndex,'legalFormInferments', 'effectiveDate', "false");
	initializeNewRowDatePick(newlyAddedChildRow, '.effectiveDate');
	initializeNewRowDatePick(newlyAddedChildRow, '.expirationDate');
	newlyAddedChildRow.find('.editOnAdd').add('editable').val('');
	newlyAddedChildRow.find('.effectiveDate').val(getToday());
	
	$(".showable").show();
}

function isLegalFormDataCorrect() {
	if(isLegalFormClassCodeSelected() && isEffectiveDateSelected() && !isDuplicateLegalCodes()) {
		return true;
	} else {
		return false;
	} 
}
function isLegalFormClassCodeSelected() {
	var selected=0;
	$(".legalFormClassCode").each(function(){
		if($(this).val()==''){
			alert('Please select Legal Form Class Code');
			selected=1;
			$(this).focus();
			return false;
		}
	});
	if (selected==0){
		return true;
	}
}
function isEffectiveDateSelected(){
	var selected=0;
	$(".effectiveDate").each(function(){
		if(!$(this).val()){
			alert('Please select Effective Date');
			$(this).focus();
			selected=1;
			return false;
		}
	});
	if (selected==0){
		return true;
	}
}

function isDuplicateLegalCodes() {
	var selectedLglFormInfrs = [];
	$("#legalFormInfermentTable tr").each(function(){
		if($(this).find('.legalFormClassCode option:selected').length){
			if(($(this).find('.expirationDate').val() == '')||($(this).find('.expirationDate').val() == null)){
				selectedLglFormInfrs.push($(this).find('.legalFormClassCode option:selected').val()
						+ "~" + $(this).find('.legalFormCode option:selected').val());
			}
		}
	});

	for (var i = 0; i < selectedLglFormInfrs.length - 1; i++) {
		if (selectedLglFormInfrs[i + 1] == selectedLglFormInfrs[i]) {			
			alert('Duplicate Legal Form Inferment ');
			return true;
		}
	}
}
