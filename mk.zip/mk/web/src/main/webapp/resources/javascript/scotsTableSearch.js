/**
 * This file serves scotsTableSearch.jsp
 */
var codeTableSearchResultsTable;
$(document).ready(function(){
	bindCodeTableSearchEvents();
	configureCodeTableSearchDataTable();
});

function bindCodeTableSearchEvents(){
//	$('#scotsCodeTableLink').bind('click',function(event) {
//		event.preventDefault();
//		location.href = "showCodeTableSearch.form";
//		return false; // to prevent event bubbling
//	});
	
	$('#codeTblSearchBtn').bind('click',function(event) {
		codeTableSearchResultsTable.fnFilter(getCodeTableSearchCriteria());
		$('#codeTblSearchResults').show();
	});
	
	$("#cdTblSysAppyTogglebtn").bind('click', function() {
		toggleRetrieveCdTblSysApplicabilities();
		return false;
	});
}

function configureCodeTableSearchDataTable() {
	codeTableSearchResultsTable = $("#codeTblSearchResultsTable").dataTable(
			{
				"bServerSide" : true,
				"sAjaxSource" : "codeTableSearchAjaxResults.form",
				"bProcessing" : false,
				"sPaginationType" : "full_numbers",
				"oLanguage" : {
					"sEmptyTable" : "No data available",
					"sLengthMenu" : " _MENU_ items per page",
					"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
	                "sInfoEmpty": "No entries to show"
				},
				"sDom" : 'tlip',
				"aoColumns" : [ null, null, null ],
				"fnRowCallback" : function(nRow, aData, iDisplayIndex,
						iDisplayIndexFull) {
					setHyperLinkOnCodeTableColumns(nRow, aData);
					return nRow;
				}
			});
}

function setHyperLinkOnCodeTableColumns(nRow, aData){
	$('td:eq(0)', nRow).html(getCodeTableColumnHtml(aData[0], aData[0]));
	$('td:eq(1)', nRow).html(getCodeTableColumnHtml(aData[0], aData[1]));
	$('td:eq(2)', nRow).html(aData[2]);
	
	// adjusting the column width
	$('td:eq(0)', nRow).width("17%");
	$('td:eq(1)', nRow).width("32%");
	$('td:eq(2)', nRow).width("51%");
}

function getCodeTableColumnHtml(code, value){
	return "<a href='codeTableView.form?codeTableId=" + code + "&taskId=&search=CodeTableSearch'>" + value + "</a>";
}


function getCodeTableSearchCriteria() {
	var tblName = '';
	if($('#tableName').val() != '-- Enter Table Name/Description --') {
		tblName = $('#tableName').val()
	}
	
	var searchCriteriaDelimiter = "#~";
	var searchCriteria = tblName + searchCriteriaDelimiter + 
						 $('#countryAppyCode').val() + searchCriteriaDelimiter + 
						 $('#systemsAppyCode').val();
	return searchCriteria;
}


var cdTblSysAppyToggleInd = true;
function toggleRetrieveCdTblSysApplicabilities() {
	$.getJSON('toggleSystemApplicabilityByEntity.form', {
		toggleIndicator : cdTblSysAppyToggleInd,
		ajax : 'true'
	}, function(data) {
		$("#systemsAppyCode").empty();
		$("#systemsAppyCode").append('<option value="">-- Select System Applicability --</option>');
		if (cdTblSysAppyToggleInd) {
			$.each(data, function() {
				$("#systemsAppyCode").append(
						'<option value="' + this.dnbSystemCode + '">' + this.codeValueDescription
								+ ' [ ' + this.dnbSystemCode + ' ] ' + '</option>');
			});
		} else {
			$.each(data, function() {
				$("#systemsAppyCode").append(
						'<option value="' + this.dnbSystemCode + '">' + this.dnbSystemCode
								+ ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
			});
		}
		cdTblSysAppyToggleInd = !cdTblSysAppyToggleInd;
	});
}
