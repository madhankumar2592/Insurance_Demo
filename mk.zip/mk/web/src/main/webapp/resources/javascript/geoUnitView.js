/**
 * This file serves geoUnitView.jsp
 */

$(document).ready(function(){
	initializeGeoViewElements();
	bindGeoViewEvents();
});

function initializeGeoViewElements(){
	// initializeDatepicker();
	$('#geoUpdateButton').hide();
	configureEmptyNameCodeRows();
	
	if($('#emptyCodeList').length && $('#emptyCodeList').val()=='yes'){
		$('.outerGeoCodeDiv').hide();
	}
}
	
function getDatepickerOptions(isDisabled){
	return {
		showOn: "button",
		buttonImage: "./resources/images/cal.png",
		buttonImageOnly: true,
		disabled: isDisabled,
		dateFormat: "yy-mm-dd"
	}
}

function bindGeoViewEvents(){
	$('#goeSearchFromViewLink').bind('click',function(event){
		event.preventDefault();
		location.href = "geoSearchHome.form";
		return false; // to prevent event bubbling
	});
	$('#geoFromCtryGrpView').bind('click',function(event){
		event.preventDefault();
		location.href = "geoSearchHome.form";
		return false; // to prevent event bubbling
	});
	$('#searchFromCtryGrpView').bind('click',function(event){
		event.preventDefault();
		location.href = "countryGroupSearchHome.form";
		return false; // to prevent event bubbling
	});
	
	$('#geoEditButton').bind('click', function(){
		$('#errorBlock').hide();
		if($.trim($('#taskId').val()) == ''){
		$.get('lockGeoUnitForEdit.form',
			function(data) {			
			if(data != "false") {
				$('#errorBlock').html('The record is locked by '+data+' due to a pending request on the Work Queue.');
				$('#errorBlock').show();
			} else {
				$('#pageTitle').html('Geography - Edit Geo Unit');
				document.title = "Geography - Edit Geo Unit"
				enableEditableElements();
			}
		});		
		}else{
		 	$('#pageTitle').html('Geography - Edit Geo Unit');
			enableEditableElements();
		}		
		return false;
	});
	
	bindChildAssociations();
	
	$('#geoUpdateButton').bind('click', function(){
		updateGeoUnit();
		return false;
	});
	$('#geoCancelButton').bind('click', function(){
		var src = $('#source').val();
		if(src == 'GeographySearch') {
			location.href = "geoSearchHome.form";
		} else if(src == 'GeoNameCodeSearch') {
			location.href = "geoNameCodeSearch.form?geoType=&geoSearchString=&langCode=";
		} else if(src == 'GeoUnitIdSearch') {
			location.href = "geoUnitIdSearch.form?id=";
		} else if(src == 'GeoUnitIdSearch') {
			location.href = "geoUnitIdSearch.form?id=";
		} else if(src == 'CountryGroupSearch') {
			location.href = "countryGroupSearchHome.form";
		} else if(src == 'SubmitterQueue') {
			location.href = "submitterWorkQueueHome.form?domainName=Geography";
		}
		return false;
	});
	$('#proceedButton').bind('click', function(){
		proceedDelete();
		return false;
	});
	$('#proceedCancel').bind('click', function(){
		document.getElementById('alertSection').style.display = "none";
		return false;
	});
}

function bindParentGeoUnitId(){
	$('.parentGeoUnitId').on('focusout', function(){
		validateParentGeoUnitId($(this).closest('tr'));
		return false;
	});
}

function validateParentGeoUnitId(rowHandle){
	var newParentGeoUnitTypeCode =  rowHandle.find('.parentGeoUnitTypeCode').val();
	var newParentGeoUnitId = rowHandle.find('.parentGeoUnitId').val();
		
	$('#errorBlock').hide();
	if($.trim(geoUnitTypeCode) == '') {
		$('#errorBlock').html('Please select parent Geo Unit Type Code.');
		$('#errorBlock').show();
	} else if($.trim(geoUnitId) == '') {
		$('#errorBlock').html('Please enter parent Geo Unit Id.');
		$('#errorBlock').show();
	} else {
		$.getJSON('getOfficialNameByGeoUnitIdAndTypeCode.form', {
			newParentGeoUnitId : newParentGeoUnitId,
			newParentGeoUnitTypeCode : newParentGeoUnitTypeCode
		}, function(data) {
			if($.trim(data.officialName) == '') {
				rowHandle.find('.geoNamePrntRelationship').val('');
				$('#errorBlock').html('Invalid parent Geo Unit Type Code / Geo Unit Id.');
				$('#errorBlock').show();
			} else if(data.officialName != 'null'){
				rowHandle.find('.geoNamePrntRelationship').val(data.officialName);
			} else {
				rowHandle.find('.geoNamePrntRelationship').val('');
			}
		});		
	}
}

function bindChildAssociations(){
	$('.countrySelect').on('change',function(){
		$(this).closest('tr').find('.addChildGeoUnitId').text($(this).val());
	});
}

function enableEditableElements(){
	// for deleted geo unit only enable the expired date calendar field
	if($('#expiredByDateCrrnt').val() != '') {
		$('#expiredByDateCrrnt').datepicker('enable');
		$('#expirationDateCrrnt').datepicker('enable'); //Added for Enhancement
		$('#geoEditButton').hide();
		$('#geoUpdateButton').show();
	} else {
		$('.editable').attr("disabled",false);
		$('.countrySelect').attr("disabled", false);
		$('.showable').show();
		$('.geoDatepickerTextBox').datepicker('enable');
		$('.effectiveDate').datepicker('disable');
		$('#geoEditButton').hide();
		$('#geoUpdateButton').show();
		$('tr').each(function(){
			if($(this).find('.changeIndicator').val()=='NEW') {
				$(this).find('.dropdown').removeAttr('disabled');
				$(this).find('.textBox').removeAttr('disabled');
				$(this).find('.geoDatepickerTextBox').removeAttr('disabled');
				$(this).find('.geoNameTxtField').removeAttr('disabled');
			}	
		});
		enableEmptyNameCodeRows();
	}
}

function updateGeoUnit(){
	var geoUnitTypeSelected = $.trim($("#geoUnitTypeHdn").val());
	var oldExpdDate = $.trim($("#expiredByDateHdn").val());
	var oldExpnDate = $.trim($("#expirationDateHdn").val()); //Add for Enhancement
	var currentExpdDate = $.trim($("#expiredByDateCrrnt").val());
	var currentExpnDate = $.trim($("#expirationDateCrrnt").val());//Add for Enhancement
	if(oldExpdDate == currentExpdDate || oldExpnDate == currentExpnDate ){
		if(isEmpty()) {
			return false;
		}
		
		if(isInvalidDates()){
			return false;
		}
		
		if(isInvalidNumeric()){
			return false;
		}
		
		if(isGeoParentDuplicate()){
			return false;
		}
		if(isGeoNameDuplicate()){
			return false;
		}
		
		if(isGeoCodeDuplicate()){
			return false;
		}
		
		if(isOfficialSelected()){
			return false;
		}
		if(geoUnitTypeSelected == '130') {
			if(isChildCountryDuplicate()){
				return false;
			}
		}
		$('#geoUpdateButton').attr("disabled",true);
		$('#geoUnitForm').submit();
		alert("The changes will be available in Reference Data UI after Approval");
	} else {
		if(!isInvalidDatesInStatusTable($('#geoStatusTable'))){
			deleteGeoUnit();
		}
	}
}

function isInvalidNumeric(){
	var returnType = false;
	
	$('.numericField').each(function(){
		if(!isNumeric($.trim($(this).val()))){
			returnType = true;
			alert('Only Numbers are allowed for geoUnitId');
			$(this).focus();
			return false;
		}
	});
	
	return returnType;
}

function isNumeric(inputStr){
	var validRegex = /^[0-9]+$/;
	return validRegex.test(inputStr);
}

function isInvalidDates(){
	if(!isInvalidDatesInTable($('#geoParentTable tr'))){
		if(!isInvalidDatesInTable($('#geoNameTable tr'))){
			if(!isInvalidDatesInTable($('#geoCodeTable tr'))){
				return isInvalidDatesInStatusTable($('#geoStatusTable'));
			}else{
				return true;
			}
		}else{
			return true;
		}
	}else{
		return true;
	}
}

function isInvalidDatesInTable(rowHandle){
	var invalidDateStatus = false;
	rowHandle.each(function() {
		var effectiveDate;
		var expiredByDate;
		var dateFieldExists = false;
		if($(this).find('.effectiveDate').length){
			dateFieldExists = true;
			effectiveDate = $(this).find('.effectiveDate').datepicker('getDate');
		}else{
			dateFieldExists = false;
		}
		if($(this).find('.expiredByDate').length){
			dateFieldExists = true;
			expiredByDate = $(this).find('.expiredByDate').datepicker('getDate');
		}else{
			dateFieldExists = false;
		}
		if(dateFieldExists){
			if(effectiveDate != null && expiredByDate != null){
				if(effectiveDate > expiredByDate){
					alert('Expired date cannot be smaller than Effective date');
					invalidDateStatus = true;
				}
			}
		}
		if(invalidDateStatus){
			return false;
		}
	});
	return invalidDateStatus;
}

function isInvalidDatesInStatusTable(tableHandle){
	if(tableHandle.find('.effectiveDate').length && tableHandle.find('.expiredByDate').length){
		var effectiveDate = tableHandle.find('.effectiveDate').datepicker('getDate');
		var expiredByDate = tableHandle.find('.expiredByDate').datepicker('getDate');
		if(effectiveDate != null && expiredByDate != null){
			if(effectiveDate > expiredByDate){
				alert('Expired date cannot be smaller than Effective date');
				return true;
			}
		}
	}
	return false;
}

function addGeoNameRow(){
	var nextIndex = $(".nameTypeCode").length;
	$('.tableContainerRow:last').after($('.tableContainerRow:last').clone());
	//$('#geoNameTable').append($('#geoNameTable tr:last').clone());
	//var newlyAddedGeoNameRow = $('#geoNameTable tr:last');
	var newlyAddedGeoNameRow = $('.tableContainerRow:last');
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.nameTypeCode', nextIndex, 'geoUnitNames', 'nameTypeCode', "true");
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.languageCode', nextIndex, 'geoUnitNames', 'languageCode', "true");
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.nameDataProviderCode', nextIndex, 'geoUnitNames', 'dataProviderCode', "true");
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.NameTxtField', nextIndex, 'geoUnitNames', 'geoName', "true");
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.effectiveDate', nextIndex, 'geoUnitNames', 'effectiveDate', "true");
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.childExpiredDate', nextIndex, 'geoUnitNames', 'expiredByDate', "false");
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.childExpirationDate', nextIndex, 'geoUnitNames', 'expirationDate', "false");//latest
	
	newlyAddedGeoNameRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePicker(newlyAddedGeoNameRow, '.effectiveDate');
/*	initializeNewRowDatePicker(newlyAddedGeoNameRow, '.childExpiredDate');
	initializeNewRowDatePicker(newlyAddedGeoNameRow, '.childExpirationDate');*/
	
	
	populateGeoNameDropDowns(newlyAddedGeoNameRow);
	$(newlyAddedGeoNameRow).css('display', 'none');
	newlyAddedGeoNameRow.find('.removeGeoNameRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeGeoNameRow(this,' + nextIndex + ');">[-]</a>');
	
	return false;
}

function populateGeoNameDropDowns(rowHandler) {
	$.getJSON('retrieveCodeValuesForGeoView.form', {
		ajax : 'true'
	}, function(data) {
		populateGeoView(data['2'], rowHandler.find('.nameTypeCode'), 'Geo Name Type ');
		populateGeoView(data['3'], rowHandler.find('.languageCode'), 'Language');
		populateGeoView(data['29'], rowHandler.find('.nameDataProviderCode'), 'Data Provider');
		
		// QC# 3378 issue fix changes $starts$
		$(rowHandler).css('display', 'none');
		var newLangs = rowHandler.find('.languageCode').html();
		rowHandler.find('.languageCode').html('');
		rowHandler.find('.languageCode').html(newLangs);

		var newTypes = rowHandler.find('.nameTypeCode').html();
		rowHandler.find('.nameTypeCode').html('');
		rowHandler.find('.nameTypeCode').html(newTypes);
		
		var newProvs = rowHandler.find('.nameDataProviderCode').html();
		rowHandler.find('.nameDataProviderCode').html('');
		rowHandler.find('.nameDataProviderCode').html(newProvs);
		
		$(rowHandler).css('display', 'block');
		// QC# 3378 issue fix changes $ends$
	});
}

function populateGeoView(codeValueData, objHandler, display){
	objHandler.empty();
	objHandler.append('<option value="">-- Select ' + display + ' --</option>');
	$.each(codeValueData, function(index, codeValue) { 
		objHandler.append('<option value="' + codeValue.codeValueId + '">' + codeValue.codeValueId 
				+ ' ['	+ codeValue.codeValueDescription + ']</option>');
	});
}

function addChildRelationRow(){
	var nextIndex = $(".countrySelect").length;
	$('#childRelationTable').append($('#childRelationTable tr:last').clone());
	var newlyAddedChildRow = $('#childRelationTable tr:last');
	updateNamesOfNewRow(newlyAddedChildRow , '.countrySelect', nextIndex, 'childGeoUnitAssociations', 'childGeoUnitId', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.childGeoUnitTypeCode', nextIndex, 'childGeoUnitAssociations', 'geoUnitTypeCode', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.addChildGeoUnitId', nextIndex, 'childGeoUnitAssociations', 'childGeoUnitId', "false");
	bindChildAssociations();
	updateNamesOfNewRow(newlyAddedChildRow , '.childEffectiveDate', nextIndex, 'childGeoUnitAssociations', 'effectiveDate', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.childExpiredDate', nextIndex, 'childGeoUnitAssociations', 'expiredByDate', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.childExpirationDate', nextIndex, 'childGeoUnitAssociations', 'expirationDate', "false"); //Added for Enhancement
	$('.childGeoUnitTypeCode').val("128");
	newlyAddedChildRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePicker(newlyAddedChildRow, '.childEffectiveDate');
        //initializeNewRowDatePicker(newlyAddedChildRow, '.childExpiredDate'); //Disabled
	
	newlyAddedChildRow.find('.removeChildRelationRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeChildRelationRow(this,' + nextIndex + ');">[-]</a>');
	
	// clear the GeoUnit Id field for new row
	newlyAddedChildRow.find('.addChildGeoUnitId').text('');
	
	return false;
}


function addGeoCodeRow(){
	var nextIndex = $(".geoCodeTypeCode").length;
	$('#geoCodeTable').append($('#geoCodeTable tr:last').clone());
	var newlyAddedGeoCodeRow = $('#geoCodeTable tr:last');
	updateNamesOfNewRow(newlyAddedGeoCodeRow , '.geoCodeTypeCode', nextIndex, 'geoUnitCodes', 'geoCodeTypeCode', "true");
	updateNamesOfNewRow(newlyAddedGeoCodeRow , '.codeDataProviderCode', nextIndex, 'geoUnitCodes', 'dataProviderCode', "true");
	updateNamesOfNewRow(newlyAddedGeoCodeRow , '.geoCode', nextIndex, 'geoUnitCodes', 'geoCode', "true");
	updateNamesOfNewRow(newlyAddedGeoCodeRow , '.effectiveDate', nextIndex, 'geoUnitCodes', 'effectiveDate', "true");
	updateNamesOfNewRow(newlyAddedGeoCodeRow , '.childExpiredDate', nextIndex, 'geoUnitCodes', 'expiredByDate', "false");
	updateNamesOfNewRow(newlyAddedGeoCodeRow , '.childExpirationDate', nextIndex, 'geoUnitCodes', 'expirationDate', "false");//added for Enhancement
	
	newlyAddedGeoCodeRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePicker(newlyAddedGeoCodeRow, '.effectiveDate');
      /*initializeNewRowDatePicker(newlyAddedGeoCodeRow, '.childExpiredDate');
      	initializeNewRowDatePicker(newlyAddedGeoCodeRow, '.childExpirationDate');*/
	
	populateGeoCodeDropDowns(newlyAddedGeoCodeRow);
	$(newlyAddedGeoCodeRow).css('display', 'none');
	newlyAddedGeoCodeRow.find('.removeGeoCodeRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeGeoCodeRow(this,' + nextIndex + ');">[-]</a>');
	
	return false;
}

function populateGeoCodeDropDowns(rowHandler) {
	$.getJSON('retrieveCodeValuesForGeoView.form', {
		ajax : 'true'
	}, function(data) {
		populateGeoView(data['514'], rowHandler.find('.geoCodeTypeCode'), 'Geo Code Type ');
		populateGeoView(data['29'], rowHandler.find('.codeDataProviderCode'), 'Data Provider');
		
		// QC# 3378 issue fix changes $starts$
		$(rowHandler).css('display', 'none');
		var newTypes = rowHandler.find('.geoCodeTypeCode').html();
		rowHandler.find('.geoCodeTypeCode').html('');
		rowHandler.find('.geoCodeTypeCode').html(newTypes);
		
		var newProvs = rowHandler.find('.codeDataProviderCode').html();
		rowHandler.find('.codeDataProviderCode').html('');
		rowHandler.find('.codeDataProviderCode').html(newProvs);
		
		$(rowHandler).css('display', 'block');
		// QC# 3378 issue fix changes $ends$
	});
}

function removeGeoNameRow(removeHandle, rowIndexToDelete){
	//$('#geoNameTable tr').eq(rowIndexToDelete + 1).find('.effectiveDate').datepicker('destroy');
        //$('#geoNameTable tr').eq(rowIndexToDelete + 1).find('.expiredByDate').datepicker('destroy');
	
	$(removeHandle).closest('tr').eq(rowIndexToDelete + 1).find('.effectiveDate').datepicker('destroy');
	$(removeHandle).closest('tr').eq(rowIndexToDelete + 1).find('.expiredByDate').datepicker('destroy');
	$(removeHandle).closest('tr').eq(rowIndexToDelete + 1).find('.expirationDate').datepicker('destroy');
	//$(removeHandle).closest('tr').remove();
	
	//$('#geoNameTable tr').each(function() 
	
	$('#alternateCodesContainerTable .tableContainerRow').each(function(){
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.nameTypeCode'), (this.rowIndex - 1), 'geoUnitNames', 'nameTypeCode');
			updateNames($(this).find('.languageCode'), (this.rowIndex - 1), 'geoUnitNames', 'languageCode');
			updateNames($(this).find('.NameTxtField'), (this.rowIndex - 1), 'geoUnitNames', 'geoName');
			updateNames($(this).find('.nameDataProviderCode'), (this.rowIndex - 1), 'geoUnitNames', 'dataProviderCode');
			
			$(this).find('.effectiveDate').datepicker('destroy');
			updateNames($(this).find('.effectiveDate'), (this.rowIndex - 1), 'geoUnitNames', 'effectiveDate');
			$(this).find('.effectiveDate').removeClass('hasDatepicker');
			$(this).find('.effectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.expiredByDate').datepicker('destroy');
			updateNames($(this).find('.expiredByDate'), (this.rowIndex - 1), 'geoUnitNames', 'expiredByDate');
			$(this).find('.expiredByDate').removeClass('hasDatepicker');
			$(this).find('.expiredByDate').datepicker(getDatepickerOptions(false));
			/*Added for*/
			$(this).find('.expirationDate').datepicker('destroy');
			updateNames($(this).find('.expiredByDate'), (this.rowIndex - 1), 'geoUnitNames', 'expirationDate');
			$(this).find('.expirationDate').removeClass('hasDatepicker');
			$(this).find('.expirationDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeGeoNameRowLink').html($(this).find('.removeGeoNameRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	$(removeHandle).closest('.tableContainerRow').remove();
	return false;
}

function removeChildRelationRow(removeHandle, rowIndexToDelete){
	$('#childRelationTable tr').eq(rowIndexToDelete + 1).find('.childEffectiveDate').datepicker('destroy');
        //$('#childRelationTable tr').eq(rowIndexToDelete + 1).find('.childExpiredDate').datepicker('destroy');
	
	$(removeHandle).closest('tr').remove();
	
	$('#childRelationTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.countrySelect'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'childGeoUnitId');
			updateNames($(this).find('.childGeoUnitTypeCode'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'geoUnitTypeCode');
			updateNames($(this).find('.addChildGeoUnitId'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'childGeoUnitId');
			//updateNames($(this).find('.geoNameTxtField'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'geoName');
			$(this).find('.childEffectiveDate').datepicker('destroy');
			updateNames($(this).find('.childEffectiveDate'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'effectiveDate');
			$(this).find('.childEffectiveDate').removeClass('hasDatepicker');
			$(this).find('.childEffectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.childExpiredDate').datepicker('destroy');
			updateNames($(this).find('.childExpiredDate'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'expiredByDate');
			$(this).find('.childExpiredDate').removeClass('hasDatepicker');
			$(this).find('.childExpiredDate').datepicker(getDatepickerOptions(false));
			$(this).find('.childExpirationDate').datepicker('destroy');
			updateNames($(this).find('.childExpirationDate'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'expirationDate');
			$(this).find('.childExpirationDate').removeClass('hasDatepicker');
			$(this).find('.childExpirationDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeChildRelationRowLink').html($(this).find('.removeChildRelationRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function removeGeoCodeRow(removeHandle, rowIndexToDelete){
	$('#geoCodeTable tr').eq(rowIndexToDelete + 1).find('effectiveDate').datepicker('destroy');
	$('#geoCodeTable tr').eq(rowIndexToDelete + 1).find('expiredByDate').datepicker('destroy');
	
	$(removeHandle).closest('tr').remove();
	
	$('#geoCodeTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.geoCodeTypeCode'), (this.rowIndex - 1), 'geoUnitCodes', 'geoCodeTypeCode');
			updateNames($(this).find('.codeDataProviderCode'), (this.rowIndex - 1), 'geoUnitCodes', 'dataProviderCode');
			updateNames($(this).find('.geoCode'), (this.rowIndex - 1), 'geoUnitCodes', 'geoCode');
			$(this).find('.effectiveDate').datepicker('destroy');
			updateNames($(this).find('.effectiveDate'), (this.rowIndex - 1), 'geoUnitCodes', 'effectiveDate');
			$(this).find('.effectiveDate').removeClass('hasDatepicker');
			$(this).find('.effectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.expiredByDate').datepicker('destroy');
			updateNames($(this).find('.expiredByDate'), (this.rowIndex - 1), 'geoUnitCodes', 'expiredByDate');
			$(this).find('.expiredByDate').removeClass('hasDatepicker');
			$(this).find('.expiredByDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeGeoCodeRowLink').html($(this).find('.removeGeoCodeRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function isGeoParentDuplicate(){
	var selectedGeoParents = [];
	$("#geoParentTable tr").each(function(){
		if($(this).find('.parentGeoUnitTypeCode option:selected').length){
			if(($(this).find('.expiredByDate').val() == '')||($(this).find('.expiredByDate').val() == null)
					&& 
					($(this).find('.expirationDate').val() == '')||($(this).find('.expirationDate').val() == null)	 //Added for enhancemebt
			){
				selectedGeoParents.push($(this).find('.parentGeoUnitTypeCode option:selected').val());
			}
		}
	});
	var sortedGeoParents = selectedGeoParents.sort();
	for (var i = 0; i < sortedGeoParents.length - 1; i++) {
		if (sortedGeoParents[i + 1] == sortedGeoParents[i]) {
			var dParentType = $("#geoParentTable tr").eq(i+1).find('td:eq(0) .parentGeoUnitTypeCode option:selected').html();
			/**
			 * 11/25/2013
			 * Commenting to fix issue reported in CASD Ticket # 208477050 
			 * */
			//if(dParentType != 'Country Group' && dParentType != 'WB Cntry Grpng') {				
			//	alert('Duplicate Parent Geo Unit for the type ' + dParentType);
			//	return true;
			//}
			/***END***/
		}
	} 	
}	

/*DSCA-147 Bug Fix addedd expiration date in the if loop   --(($(this).find('.expirationDate').val() == '')||($(this).find('.expirationDate').val() == null))*/
function isGeoCodeDuplicate(){
	var selectedGeoCodes = [];
	$("#geoCodeTable tr").each(function(){
		if($(this).find('.geoCodeTypeCode option:selected').length){
			if((($(this).find('.expiredByDate').val() == '')||($(this).find('.expiredByDate').val() == null))
			&&
			(($(this).find('.expirationDate').val() == '')||($(this).find('.expirationDate').val() == null))){
				selectedGeoCodes.push($(this).find('.geoCodeTypeCode option:selected').val());
			}
		}
	});
	
	var sortedGeoCodes = selectedGeoCodes.sort();
	for (var i = 0; i < sortedGeoCodes.length - 1; i++) {
		if (sortedGeoCodes[i + 1] == sortedGeoCodes[i]) {
			alert('Geographic code types should be unique');
			return true;
		}
	} 	
}
function isOfficialSelected(){
	//alert('Inside Official')
	officialFlag=false;
	$(".tableContainerRow tr").each(function(){
		if($(this).find('.nameTypeCode option:selected').length){
			//alert("official Name type"+($(this).find('.nameTypeCode option:selected').val()));
			if($(this).find('.nameTypeCode option:selected').val()==32) {
				officialFlag=true;
			}
		}
	});
	if(!officialFlag) {
		alert("Please enter at least one Official Name Type");
		return true;
	}
	return false;
}	
function isGeoNameDuplicate(){
	alert('inside Duplicate');
	var selectedNames = [];
	$(".tableContainerRow").each(function(){
		if($(this).find('.nameTypeCode option:selected').length && ($(this).find('.nameTypeCode').val() != '7790')){
			
			if((($(this).find('.expiredByDate').val() == '')||($(this).find('.expiredByDate').val() == null))
			&& (($(this).find('.expirationDate').val() == null)||($(this).find('.expirationDate').val() == '')))
			{
				//alert('Pushoo InsideSelected Name Array '+ $(this).find('.nameTypeCode option:selected').val());
				//alert('Expiration Date'+$(this).find('.childExpiredDate').val());
				//alert('Expired Date'+$(this).find('.childExpirationDate').val());
				
				selectedNames.push($(this).find('.nameTypeCode option:selected').val());
			}	
		}
	});
	
	var selectedLanguages = [];
	$(".tableContainerRow").each(function(){
		if($(this).find('.languageCode option:selected').length && ($(this).find('.nameTypeCode').val() != '7790')){
			if((($(this).find('.expiredByDate').val() == '')||($(this).find('.expiredByDate').val() == null))&&
			   (($(this).find('.expirationDate').val() == null)||$(this).find('.expirationDate').val() == '')) {
					//alert('Pushoo InsideSelected Name Array '+ $(this).find('.nameTypeCode option:selected').val());

				selectedLanguages.push($(this).find('.languageCode option:selected').val());
			}
		}
		
	});
	
	
	
	
	var currentName = 0;
	var currentLanguage = 0;
	for(var i = 0; i < selectedNames.length; i++){
		currentName = selectedNames[i];
		currentLanguage = selectedLanguages[i];
		for(var j = i+1; j < selectedNames.length; j++){

		//alert('Inside Chcek');

			//alert('selected Name'+selectedNames[j]);
			//alert('Current Name'+currentName);
			//alert('Selected Language'+ selectedLanguages[j]);
			//alert('Current Language'+ currentLanguage);
			if(selectedNames[j] == currentName && selectedLanguages[j] == currentLanguage){
				
				alert('Geographic Name Type and Language combination should be unique');
				return true;
			}
		}
	}
}

function deleteGeoUnit(){
	if($.trim($("#dnbComment").val()) == ""){
		alert("Please provide Explanation Text to delete the record.");
		$("#dnbComment").focus();
		return false;
	} else {
		checkForChildGeoUnit();
	}
}

function proceedDelete(){
	$("#geoUnitForm").attr("action","geoUnitDelete.form");
	$('#geoUnitForm').submit();
	alert("The changes will be available in Reference Data UI 24 hours after Approval");
}

function checkForChildGeoUnit(){
	$('#errorBlock').hide();
	$.getJSON('checkForChildGeoUnit.form', {
		geoUnitId : $('#geoUnitId').html(),
		ajax : 'true'
	}, function(data) {
		if(data == true) {
			$('#errorBlock').html('This record has child geo units and hence could not be deleted.');
			$('#errorBlock').show();
		} else {
			document.getElementById('alertSection').style.display = "block";
		}
	});	
}

function configureEmptyNameCodeRows(){
	if($('#emptyCodeList').length && $('#emptyCodeList').val()=='yes'){
		$('#geoCodeTable tr:last').hide();
	}
	if($('#emptyNameList').length && $('#emptyNameList').val()=='yes'){
		$('#geoNameTable tr:last').hide();
	}
	if($('#emptyParentList').length && $('#emptyParentList').val()=='yes'){
		$('#geoParentTable tr:last').hide();
	}
}

function enableEmptyNameCodeRows(){
	if($('#emptyCodeList').length && $('#emptyCodeList').val()=='yes'){
		$('.outerGeoCodeDiv').show();
		$('#geoCodeTable tr:last').show();
		enableNewRow($('#geoCodeTable tr:last'));
		populateGeoCodeDropDowns($('#geoCodeTable tr:last'));
	}
	if($('#emptyNameList').length && $('#emptyNameList').val()=='yes'){
		$('#geoNameTable tr:last').show();
		enableNewRow($('#geoNameTable tr:last'));
	}
	if($('#emptyParentList').length && $('#emptyParentList').val()=='yes'){
		$('#geoParentTable tr:last').show();
		enableNewRow($('#geoParentTable tr:last'));
		$('#geoParentTable tr:last').find('.parentGeoUnitId').prop('disabled', true);
	}
}

function enableNewRow(rowHandle){
	enableClassInRow('.dropdown', rowHandle);
	enableClassInRow('.textBox', rowHandle);
	enableClassInRow('.geoNameTxtField', rowHandle);
	enableClassInRow('.geoDatepickerTextBox', rowHandle);
	rowHandle.find('.geoDatepickerTextBox').each(function(){
		$(this).datepicker('enable');
	});
}

function enableClassInRow(className, rowHandle){
	rowHandle.find(className).each(function(){
		if($(this).is(':disabled')){
			$(this).attr('disabled', false);
		}
	});
}

function isChildCountryDuplicate(){
	var selectedCountries = [];
	$("#childRelationTable tr").each(function(){
		$(this).find('.countrySelect option:selected').each(function(){
			selectedCountries.push($(this).val());
		});
	});
	var sortedCountries = selectedCountries.sort();
	for (var i = 0; i < sortedCountries.length - 1; i++) {
		if (sortedCountries[i + 1] == sortedCountries[i]) {
			alert('Child Countries should be unique');
			return true;
		}
	} 
}
function addParentRow(){
	var nextIndex = $(".parentGeoUnitTypeCode").length;
	$('#geoParentTable').append($('#geoParentTable tr:last').clone());
	$('#geoParentTable tr:last').find('.geoNamePrntRelationship').val('');
	$('#geoParentTable tr:last').find('.parentGeoUnitId').val('');
	var selectBoxHandler = $('#geoParentTable tr:last').find('.parentGeoUnitTypeCode');
	selectBoxHandler.prop('disabled', false);
	selectBoxHandler.empty();
	selectBoxHandler.append('<option value=""> -- Select -- </option>');
	getHierarchyByGeoUnitId(nextIndex);
	return false;
}

function populateParentRow(nextIndex){

	var newlyAddedParentRow = $('#geoParentTable tr:last');
	updateNamesOfNewRow(newlyAddedParentRow , '.parentGeoUnitTypeCode', nextIndex, 'parentGeoUnitAssociations', 'parentGeoUnit.geoUnitTypeCode', "true");
	updateNamesOfNewRow(newlyAddedParentRow , '.parentGeoUnitId', nextIndex, 'parentGeoUnitAssociations', 'parentGeoUnitId', "true");
	bindParentGeoUnitId();
	updateNamesOfNewRow(newlyAddedParentRow , '.effectiveDate', nextIndex, 'parentGeoUnitAssociations', 'effectiveDate', "true");
	updateNamesOfNewRow(newlyAddedParentRow , '.childExpiredDate', nextIndex, 'parentGeoUnitAssociations', 'expiredByDate', "false");
		updateNamesOfNewRow(newlyAddedParentRow , '.childExpirationDate', nextIndex, 'parentGeoUnitAssociations', 'expirationDate', "false");
	
	newlyAddedParentRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePicker(newlyAddedParentRow, '.effectiveDate');
        /*initializeNewRowDatePicker(newlyAddedParentRow, '.childExpiredDate');
		initializeNewRowDatePicker(newlyAddedParentRow, '.childExpirationDate');*/
	
	newlyAddedParentRow.find('.removeParentRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeParentRow(this,' + nextIndex + ');">[-]</a>');
}

function removeParentRow(removeHandle, rowIndexToDelete){
	$('#geoParentTable tr').eq(rowIndexToDelete + 1).find('.effectiveDate').datepicker('destroy');
       //$('#geoParentTable tr').eq(rowIndexToDelete + 1).find('.expiredByDate').datepicker('destroy');
	
	$(removeHandle).closest('tr').remove();
	
	$('#geoParentTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.parentGeoUnitTypeCode'), (this.rowIndex - 1), 'parentGeoUnitAssociations', 'parentGeoUnit.geoUnitTypeCode');
			updateNames($(this).find('.parentGeoUnitId'), (this.rowIndex - 1), 'parentGeoUnitAssociations', 'parentGeoUnitId');
			$(this).find('.effectiveDate').datepicker('destroy');
			updateNames($(this).find('.effectiveDate'), (this.rowIndex - 1), 'parentGeoUnitAssociations', 'effectiveDate');
			$(this).find('.effectiveDate').removeClass('hasDatepicker');
			$(this).find('.effectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.expiredByDate').datepicker('destroy');
			updateNames($(this).find('.expiredByDate'), (this.rowIndex - 1), 'parentGeoUnitAssociations', 'expiredByDate');
			$(this).find('.expiredByDate').removeClass('hasDatepicker');
			$(this).find('.expiredByDate').datepicker(getDatepickerOptions(false));
			$(this).find('.expirationDate').datepicker('destroy');
			updateNames($(this).find('.expirationDate'), (this.rowIndex - 1), 'parentGeoUnitAssociations', 'expirationDate');
			$(this).find('.expirationDate').removeClass('hasDatepicker');
			$(this).find('.expirationDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeParentRowLink').html($(this).find('.removeParentRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function getHierarchyByGeoUnitId(nextIndex){
	$.getJSON('getHierarchyByGeoUnitId.form', {
		ajax : 'true'
	}, function(data) {
		
		var selectBoxHandler = $('#geoParentTable tr:last').find('.parentGeoUnitTypeCode');
		$.each(data, function(index, value){
			selectBoxHandler.append('<option value=' + index + '>' + value + '</option>');
		});
		populateParentRow(nextIndex);
	});
}