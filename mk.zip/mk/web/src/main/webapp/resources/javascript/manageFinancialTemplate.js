/*This file serves manageFinancialTemplate.jsp*/

var scheduleTableHtml;
var lineItemTableHtml;
var fontArray = ["brown", "blue", "green", "red", "black", "indigo", "orange", "navy"];
$(document).ready(function(){
	bindFTEvents();
	backupScheduleAndLineItemTables();	
	var $tabs = $('#tabs').tabs();
	bindFinancialItemAssociationEvents();
});

function backupScheduleAndLineItemTables(){
	scheduleTableHtml = $('.scheduleTableTD').eq(0).html();
	lineItemTableHtml = $('.lineItemTableTD').eq(0).html();
}

function bindFTEvents(){

//	$('#manageFTLink').bind('click',function(event){		
//		event.preventDefault();
//		location.href = "finance?financialTemplateTypeCode=&taskId=";
//		return false;
//	});
	
	bindLineItemCheckboxClickEvent();
	
	if($('#financialTemplateDropdown').val() != ''){
		$('#financialTemplateDiv').show();
	}
	
	$('#financialTemplateDropdown').on('change', function(){
		if($(this).val() == ''){
			$('#financialTemplateDiv').hide();
			$("#errorMsg").hide();
		} else {
			location.href = "finance?financialTemplateTypeCode=" + $(this).val()+"&taskId=";
		}
	});
	
	$('#ftCancelBtn').on('click', function(){
		//location.href = "finance?financialTemplateTypeCode=" + $('#financialTemplateDropdown').val()+"&taskId=";
		location.href = "home.form";
		return false;
	});
	
	$('#page2Btn').on('click', function(){
		if(isValidSelections()){
			populateSelectItemModelAttribute();
		}else{
			return false;
		}
	});
	$('#ftSaveBtnpage1').on('click', function(){
		populateSelectItemModelAttribute();
	});
	
	bindStatementTypeCheckbox();
	bindScheduleTypeCheckbox();
	hideChildrenIfParentIsUnchecked();
	$('.lineItemTable tbody').sortable().disableSelection();
	if(($('.lineItemSpan').length == 1) &&
		($.trim($('.lineItemSpan').html()) == '')	
		){
		$('.lineItemTableTD').hide();
	}
	
	$('.statementLinkSpan').on('click', function(){
		populateSchedules($(this).closest('tr').find('.statementTypeCheckbox'), true);
	});
	
	$('.scheduleLinkSpan').on('click', function(){
		populateLineItems($(this).closest('tr').find('.scheduleCheckbox'), true, null);
	});
	
	bindSizeUnitCheckBoxValueToEntity();
	if($('#isLocked').val()=='true'){
		$("#errorMsg").show();
		$('.financial_btn').add('.scheduleLinkSpan').add('.statementLinkSpan')
		.add('.finCheckBox').attr("disabled","disabled");
	} else {
		$("#errorMsg").hide();
		$('.financial_btn').add('.scheduleLinkSpan').add('.statementLinkSpan')
		.add('.finCheckBox').removeAttr("disabled");
	}
	
	$('#wQCancelButton').bind('click', function(){
		var src = $('#sourceQueue').val();
		if(src == 'approver') {
			location.href = "approverWorkQueueHome.form?domainName=" + $('#domainName').val();
		} else {
			location.href = "submitterWorkQueueHome.form?domainName=" + $('#domainName').val();
		}
		return false;
	});
}

function bindLineItemCheckboxClickEvent() {
	$('.lineItemCheckbox').each(function(){
		$(this).on('click', function(){
			if(this.checked){
				$(this).closest('td').css('font-weight', 'bold');
			} else {
				$(this).closest('td').css('font-weight', 'normal');
			}
		});
	});
}

function bindSizeUnitCheckBoxValueToEntity(){
	$('.visibleSizeUnitExaminationIndicator').on('click', function(){
		var currentElement = $(this).closest('tr').find('.hiddenSizeUnitExaminationIndicator');
		if(this.checked){
			currentElement.val("1");
		}else{
			currentElement.val("0");
		}
	});
}

function isValidSelections(){
	var scheduleTableHandle;
	var lineItemTableHandle;
	var isStatementChecked = false;
	var isScheduleChecked = false;
	var isLineItemChecked = false;
	var isValidSoFar = true;
	$('.statementTypeCheckbox:checked').each(function(){
		isStatementChecked = true;
		scheduleTableHandle = $(this).closest('tr').find('.scheduleTable');
		isScheduleChecked = false;
		scheduleTableHandle.find('.scheduleCheckbox:checked').each(function(){
			isScheduleChecked = true;
			lineItemTableHandle = $(this).closest('tr').find('.lineItemTable');
			isLineItemChecked = false;
			lineItemTableHandle.find('.lineItemCheckbox:checked').each(function(){
				isLineItemChecked = true;
				return false;
			});
			if(!isLineItemChecked){
				alert('Please select at least one line item for selected schedule');
				isValidSoFar = false;
				return false;
			}
		});
		if(!isScheduleChecked && isValidSoFar){
			alert('Please select at least one schedule for selected statement type');
			isValidSoFar = false;
			return false;
		}
	});
	if(!isStatementChecked && isValidSoFar){
		alert('Please select at least one statement type');
		isValidSoFar = false;
	}
	return isValidSoFar;
}
	
function hideChildrenIfParentIsUnchecked(){
	$('.scheduleCheckbox').each(function(){
		if(!($(this).is(':checked'))){
			$(this).closest('tr').find('.lineItemTableTD').hide();
			if($(this).closest('tr').find('.scheduleSpan').html() == ''){
				$(this).closest('.statementTypeRow').find('.statementTypeCheckbox').prop('checked', false);
			}
		}
	});
	
	$('.statementTypeCheckbox').each(function(){
		if(!($(this).is(':checked'))){
			$(this).closest('tr').find('.scheduleTableTD').hide();
			$(this).closest('tr').find('.statementLinkSpan').hide();
			$(this).closest('tr').find('.scheduleLinkSpan').hide();
		}
	});
}

function bindStatementTypeCheckbox(){
	$('.statementTypeCheckbox').each(function(){
		$(this).on('click', function(){
			if(this.checked){
				populateSchedules($(this), false);
			} else {
				clearSchedules($(this));
			}
		});
	});
}

function bindScheduleTypeCheckbox(){
	$('.scheduleCheckbox').each(function(){
		$(this).on('click', function(){
			if(this.checked){
				populateLineItems($(this), false, null);
			}else{
				clearLineItems($(this));
			}
		});
	});
}
var fontIndx = 0;
function populateSchedules(checkboxHandle, isEditLink){
	var tableHandle = checkboxHandle.closest('tr').find('.scheduleTable');
	var selectedCodeValues;
	var selectedLineItems;	
	if(isEditLink){
		selectedCodeValues = getSelectedCheckboxValues(tableHandle, '.scheduleCheckbox');
		selectedLineItems = getSelectedCheckboxValues(tableHandle, '.lineItemCheckbox');
	}
	var lastRowHandle;
	checkboxHandle.closest('tr').find('.scheduleTableTD').hide();
	checkboxHandle.closest('tr').find('.scheduleTableTD').html(scheduleTableHtml);
	var scheduleTableHandle = checkboxHandle.closest('tr').find('.scheduleTable');
	scheduleTableHandle.find("tr:gt(0)").remove();
	
	$.getJSON('getSchedulesForStatementType.form', {
		statementType : checkboxHandle.val()
	}, function(data) {
		fontIndx = 0;
		$.each(data, function() {
			 scheduleTableHandle.append(scheduleTableHandle.find('.scheduleRow').last().clone());
			 lastRowHandle = scheduleTableHandle.find('.scheduleRow').last();			 
			 lastRowHandle.find('.scheduleCheckbox').val(this.codeValueId);
			 lastRowHandle.find('.scheduleCheckbox').prop('checked', false);	 
			 lastRowHandle.find('.scheduleCodeSpan').html(this.codeValueId);
			 lastRowHandle.find('.scheduleSpan').html(this.codeValueDescription);
			 bindScheduleCheckbox(lastRowHandle.find('.scheduleCheckbox'));	
			 bindRetrieveLineItemsLnk(lastRowHandle.find('.scheduleLinkSpan'));
			 
			 // setting the color
			 lastRowHandle.find('.scheduleOpenSpan').css('color', fontArray[fontIndx]);
			 lastRowHandle.find('.scheduleCodeSpan').css('color', fontArray[fontIndx]);
			 lastRowHandle.find('.scheduleSpan').css('color', fontArray[fontIndx]);
			 lastRowHandle.find('.scheduleCloseSpan').css('color', fontArray[fontIndx]);
			 fontIndx++;
		 }); 
		 scheduleTableHandle.find('.scheduleRow').first().remove(); 
		 if(isEditLink){
			 $.each(selectedCodeValues, function(index, codeValueId) { 
				checkBoxHandle = scheduleTableHandle.find(":checkbox[value=" + codeValueId + "]");
				checkBoxHandle.prop('checked', true);				
				populateLineItems(checkBoxHandle, true, selectedLineItems);
			 });
		 }
	});
	checkboxHandle.closest('tr').find('.scheduleTableTD').show();
}

function clearSchedules(checkboxHandle){
	checkboxHandle.closest('tr').find('.scheduleTableTD').html('');
}

function bindScheduleCheckbox(checkboxHandle){
	checkboxHandle.on('click', function(){
		if(this.checked){
			populateLineItems($(this), false, null);
		} else {
			clearLineItems($(this));
		}
	});	
}

function bindRetrieveLineItemsLnk(spanHandler) {
	spanHandler.on('click', function(){
		populateLineItems($(this).closest('tr').find('.scheduleCheckbox'), true, null);
	});	
}

function populateLineItems(checkboxHandle, isEditLink, selectedLineItems){
	var lineItemColor = checkboxHandle.next().css('color');	
	var tableHandle = checkboxHandle.closest('tr').find('.lineItemTable');
	var selectedCodeValues;
	var existingCodeValues = new Array();
	if(isEditLink){
		if(selectedLineItems == null) {
			selectedCodeValues = getSelectedCheckboxValues(tableHandle, '.lineItemCheckbox');
		} else {
			selectedCodeValues = selectedLineItems;
		}
		existingCodeValues = getExistingCheckboxValues(tableHandle, '.lineItemCheckbox');
	}

	var lastRowHandle;
	if(! isEditLink){
		checkboxHandle.closest('tr').find('.lineItemTableTD').hide();
		checkboxHandle.closest('tr').find('.lineItemTableTD').html(lineItemTableHtml);
	}
		var lineItemTableHandle = checkboxHandle.closest('tr').find('.lineItemTable');
		var lineItemTableSortableHandle = checkboxHandle.closest('tr').find('.lineItemTable tbody');
	if(! isEditLink){
		lineItemTableHandle.find("tr:gt(0)").remove();
	}
	
	$.getJSON('getLineItemsForScheduleType.form', {
		scheduleType : checkboxHandle.val()
	}, function(data) {
		 $.each(data, function() {
			 if(! isEditLink || (isEditLink && ! contains(existingCodeValues, this.codeValueId)) ) {
				 lineItemTableHandle.append(lineItemTableHandle.find('.lineItemRow').last().clone(true, true));
				 lastRowHandle = lineItemTableHandle.find('.lineItemRow').last();
				 lastRowHandle.find('.lineItemCheckbox').val(this.codeValueId);
				 lastRowHandle.find('.lineItemCheckbox').prop('checked', false);
				 lastRowHandle.find('.lineItemCodeSpan').html(this.codeValueId);
				 lastRowHandle.find('.lineItemSpan').html(this.codeValueDescription);			 
				 lastRowHandle.find('.lnItemGroupLevel').val("10");
				 lastRowHandle.find('.headerIndicator').val("false");
				
				 // setting the color
				 lastRowHandle.find('.lineItemOpenSpan').css('color', lineItemColor);
				 lastRowHandle.find('.lineItemCodeSpan').css('color', lineItemColor);
				 lastRowHandle.find('.lineItemSpan').css('color', lineItemColor);
				 lastRowHandle.find('.lineItemCloseSpan').css('color', lineItemColor);
				 lastRowHandle.find('td').css('font-weight', 'normal');
				 fontIndx++;
			 }
		 }); 
		 if(! isEditLink){
			 lineItemTableHandle.find('.lineItemRow').first().remove();
		 }
		 checkboxHandle.closest('tr').find('.lineItemTable tbody').sortable().disableSelection();
		 
		 if(isEditLink){
			 $.each(selectedCodeValues, function(index, codeValueId) { 
				 checkBoxHandle = lineItemTableHandle.find(":checkbox[value=" + codeValueId + "]");
				 checkBoxHandle.prop('checked', true);
				 checkBoxHandle.closest('td').css('font-weight', 'bold');
			 });		 
		 }
	});
	checkboxHandle.closest('tr').find('.lineItemTableTD').show();
	bindLineItemCheckboxClickEvent();
}

function clearLineItems(checkboxHandle){
	checkboxHandle.closest('tr').find('.lineItemTableTD').html('');
}

function populateSelectItemModelAttribute(){
	var scheduleTable;
	var lineItemTable;
	var hiddenModelAttributeField = "";

	$('.statementTypeTable tr').each(function(){
		if($(this).find('.statementTypeCheckbox').length 
				&& $(this).find('.statementTypeCheckbox').is(':checked')){
			// get the selected statement type
			var statementType = $(this).find('.statementTypeCheckbox').val() 
					+ ":" + $(this).find('.statementTypeSpan').text();

			if($(this).find('.scheduleTable').length) {
				scheduleTable = $(this).find('.scheduleTable');
				
				scheduleTable.find('tr').each(function() {
					// get the selected statement schedule
					if($(this).find('.scheduleCheckbox').length 
							&& $(this).find('.scheduleCheckbox').is(':checked')){
						var statementSchedule = $(this).find('.scheduleCheckbox').val() + ":" + 
												$(this).find('.scheduleSpan').text() + ":" + 
												$(this).find('.finlStatementscheduleId').val();
						hiddenModelAttributeField = hiddenModelAttributeField + statementType + "#" + statementSchedule;

					}
					// get the selected statement line item
					if($(this).find('.lineItemTable').length){
						lineItemTable = $(this).find('.lineItemTable');
						var lineItemIndex = 1;
						lineItemTable.find('tr').each(function(){
							if($(this).find('.lineItemCheckbox').length 
									&& $(this).find('.lineItemCheckbox').is(':checked')){
								var statementLineItem = $(this).find('.lineItemCheckbox').val()
										+ ":" + $(this).find('.lineItemSpan').text() 
										+ ":" + lineItemIndex
										+ ":" + getLineItemGroupLevel($(this))
										+ ":" + getHeaderIndicator($(this))
										+ ":" + $(this).find('.internalLineItemCode').val()
										+ ":" + $(this).find('.finlStatementLineItemId').val();
								hiddenModelAttributeField = hiddenModelAttributeField + "#" + statementLineItem;
								lineItemIndex++;								
							}
						});
					}
					var lastChar = hiddenModelAttributeField.substr(hiddenModelAttributeField.length-1);
					if(lastChar != "@") {
						hiddenModelAttributeField = hiddenModelAttributeField + "@";
					}
				});
			}
		}
	});
	var lastChar = hiddenModelAttributeField.substr(hiddenModelAttributeField.length-1);
	if(lastChar == "@") {
		hiddenModelAttributeField = hiddenModelAttributeField.substr(0, hiddenModelAttributeField.length-1);
	}
	$('#finlTemplateModelAttribute').val(hiddenModelAttributeField);
}

function getHeaderIndicator(thisHandle){
	if(thisHandle.find('.headerIndicator').length && (thisHandle.find('.headerIndicator').val() != '')){
		return thisHandle.find('.headerIndicator').val();
	}else{
		return "false";
	}
}

function getLineItemGroupLevel(thisHandle){
	if(thisHandle.find('.lnItemGroupLevel').length && (thisHandle.find('.lnItemGroupLevel').val() != '')){
		return thisHandle.find('.lnItemGroupLevel').val();
	}else{
		return "10";
	}
}

function bindFinancialItemAssociationEvents(){
	$('.lineItemEffectiveDate').datepicker('enable');
	
	$('label.third').bind('click',function(event){
		event.preventDefault();
		return false;
	});
	
	$('.intend_right').on('click', function(){
		var currentElement = $(this).closest('tr').find('.hiddenGroupLevel').val();	
		if(currentElement==''){
			currentElement = 10;
		}
		currentElement = parseInt(currentElement) +10;
		$(this).closest('tr').find('.hiddenGroupLevel').val(currentElement);
		currentElementPixel =currentElement+"px";		
		var labelText = $(this).closest('tr').find('.label').parent().css("text-indent",currentElementPixel);
		var prevElement = $(this).closest('tr').prev().find('.hiddenGroupLevel').val();			
		var nextElement = $(this).closest('tr').next().find('.hiddenGroupLevel').val();
		if(currentElement<nextElement){
			$(this).closest('tr').find('.label').css("font-weight","bold");
			$(this).closest('tr').find('.hiddenLineItemHeader').val(true)
		}else{
			$(this).closest('tr').find('.label').css("font-weight","normal");
			$(this).closest('tr').find('.hiddenLineItemHeader').val(false)
		}			
					
		if(prevElement<currentElement){
			$(this).closest('tr').prev().find('.label').css("font-weight","bold");
			$(this).closest('tr').prev().find('.hiddenLineItemHeader').val(true);
		}else{
			$(this).closest('tr').prev().find('.label').css("font-weight","normal");
			$(this).closest('tr').prev().find('.hiddenLineItemHeader').val(false);
		}
	});
	
	$('.intend_left').on('click', function(){
		var currentElement = $(this).closest('tr').find('.hiddenGroupLevel').val();
		if(parseInt(currentElement)!=10){
			currentElement = parseInt(currentElement) -10;
			$(this).closest('tr').find('.hiddenGroupLevel').val(currentElement);
			currentElementPixel =currentElement+"px";
			var labelText = $(this).closest('tr').find('.label').parent().css("text-indent",currentElementPixel);
			var prevElement = $(this).closest('tr').prev().find('.hiddenGroupLevel').val();			
			var nextElement = $(this).closest('tr').next().find('.hiddenGroupLevel').val();
			if(currentElement<nextElement){
				$(this).closest('tr').find('.label').css("font-weight","bold");
				$(this).closest('tr').find('.hiddenLineItemHeader').val(true)
			}else{
				$(this).closest('tr').find('.label').css("font-weight","normal");
				$(this).closest('tr').prev().find('.hiddenLineItemHeader').val(false);
			}
			if(prevElement<currentElement){
				$(this).closest('tr').prev().find('.label').css("font-weight","bold");
				$(this).closest('tr').find('.hiddenLineItemHeader').val(true)
			}else{
				$(this).closest('tr').prev().find('.label').css("font-weight","normal");
				$(this).closest('tr').prev().find('.hiddenLineItemHeader').val(false);
			}
		}
		
	});
	
	$('.bold').each(function(index) {
	   $(this).css("font-weight","bold");
	});
	
	$('.label').each(function(index){
		var currentElement = $(this).closest('tr').find('.hiddenGroupLevel').val();	
		if(currentElement==''){
			currentElement = 0;
		}
		currentElementPixel =currentElement+"px";		
		var labelText = $(this).closest('tr').find('.label').parent().css("text-indent",currentElementPixel);
	});

	var successString = $("#successIndicator").val();
	if(successString == "submit_success"){
		successString = "";
	  	location.href ="submitterWorkQueueHome.form?domainName=Financial Templates";		
	} else if(successString == "save_success") {		
		$("#successIndicator").val('');
		successString = '';
		alert('The Financial Template has been saved intermediately. Please complete all 4 steps and submit the update.');
	}
}

function getSelectedCheckboxValues(tableHandle, checkboxClassName){
	var selectedCodeValues = new Array();
	tableHandle.find(checkboxClassName).each(function(){
		if($(this).is(':checked')){
			selectedCodeValues.push($(this).val());	
		}
	});
	return selectedCodeValues;
}

function getExistingCheckboxValues(tableHandle, checkboxClassName){
	var existingCodeValues = new Array();
	tableHandle.find(checkboxClassName).each(function(){
		existingCodeValues.push($(this).val());	
	});
	return existingCodeValues;
}

function contains(arrayObj, obj) {
	for (var i = 0; i < arrayObj.length; i++) { 
		if (arrayObj[i] == obj) {             
			return true;         
		}     
	}     
	return false;
}