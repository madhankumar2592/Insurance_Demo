/**
 * This file serves manageAltSchemeCode.jsp
 */
$(document).ready(function() {
	bindManageAltSchemeEvents();	
	enableButtons();
});

function bindManageAltSchemeEvents() {
// $('#scotsAltSchemeLink').bind('click', function(event) {
// event.preventDefault();
// location.href = "manageAltSchemeCode.form";
// return false; // to prevent event bubbling
// });
	$('.geoDatepickerTextBox').each(function() {
		$(this).datepicker('disable');
	});
	if($("#location").val()=="altSchmCode")	{
		if ($.trim($('#sourceQueue').val())!="") {
			$('li').removeClass('active');
			$('#workQueueHomeLi').closest('li').addClass('active');
			$(".workQueueViewAltSchmCode").show();
			$(".userViewAltSchmCode").hide();
			$("#schemeCode").attr("disabled",true);
			if ($.trim($('#sourceQueue').val()) == 'approver') {
				$(".submitterWorkQueueAltSchmCode").hide();
				$(".approverWorkQueueAltSchmCode").show();

			} else if ($.trim($('#sourceQueue').val()) == 'submitter') {
				$(".submitterWorkQueueAltSchmCode").show();
				$(".approverWorkQueueAltSchmCode").hide();
			} 
		} else {
			$(".submitterWorkQueue").hide();
			$(".approverWorkQueue").hide();
			$(".userViewAltSchmCode").show();
			$("#manageAltSchemeSubmitButton").hide();
			$("#manageAltSchemeResetButton").hide();
		}
	}
	$('#altSchSearchBtn').bind(
			'click',
			function(event) {
				// $("#altSchemeCodeSection").show();
				if (isValidAltSchemeSearchCriteria()) {
					
					event.preventDefault();
					showSpinner();
					location.href = "retrieveAlternateSchemeCodes.form"
							+ "?schemeTypeCode=" + $('#schemeCode').val()
							+ "&taskId=";
					return false; // to prevent event bubbling
				}
			});

	$('#manageAltSchemeResetButton').bind('click', function(event) {
		location.href = "retrieveAlternateSchemeCodes.form"
			+ "?schemeTypeCode=" + $('#schemeCode').val()
			+ "&taskId=";
		return false; // to prevent event bubbling
	});
	
	$('#manageAltSchemeCancelButton').bind('click', function(event) {
		location.href = "home.form";
		return false; // to prevent event bubbling
	});
	
	$('#schemeCodeToggleBtn').bind('click', function(event) {
		toggleAltSchemeCodeTypes();
	});

// $('#manageAltSchemeResetButton').bind('click', function(event) {
// if ($('#schemeCode').val() == "") {
// return false;
// }
// });
//
// $("#manageAltSchemeResetButton").click(function() {
// $(".altSchemeTable").css("display", "none");
// $("#schemeCode").val("");
// });
	$("#manageAltSchemeEditButton").click(function() {
		$("#schemeCode").attr("disabled", "disabled");
		$("#schemeCodeToggleBtn").attr("disabled", "disabled");
		$("#altSchSearchBtn").attr("disabled", "disabled");
		if ($('#schemeCode').val() == "") {
			$('#errorMsg').show();
			$('#errorMsg').html('Please select Alternate Scheme Type Code');
			return false;
		}
		if ($(this).val() == "Edit") {
			$('#errorMsg').hide();
			$.get('lockAltSchemeCodeForEdit.form',
			{schemeCode : $("#schemeCode").val()},
			function(data) {				
				if (data != "false") {
					$('#errorMsg').html('The record is locked by '+data+ 'due to a pending request on the Work Queue.');
					$('#errorMsg').show();
					$('#errorMsg').focus();
					return false; // to prevent event bubbling
				} else {
					enableEditAltSchemeCodes();
				}
				return false; // to prevent event bubbling
			});
		}
	});

	$("#manageAltSchemeApproveButton").click(function() {
		completeTaskAjaxOthers(true);
	});
	
	$('#manageAltSchemeRejectButton').bind('click',function(event){
		if(($.trim($("#domainName").val()) == "Industry Code") 
			||($.trim($("#domainName").val()) == "SCoTS")
			||($.trim($("#domainName").val()) == "Currency Exchange")
			||($.trim($("#domainName").val()) == "XML Schema Labels")){
			$("#reasonDiv").show();
			$("#reason").focus();
			return false;
		} else if($.trim($("#dnbComment").val()) == "") {
	        $("#dnbComment").focus();
			return false;
		} else {
			$('#alertSection').show();
		}
	});	
	
	/*
	 * $(".mandatory").each(function(){ if(($(this).val()==null) ||
	 * ($(this).val()=="")) { $("#errorMsg").show(); $('#errorMsg').html('Please
	 * enter values in all mandatory fields'); $(this).focus(); } })
	 */
	bindNewAltSchmRow($('#codeTableId:last').closest('tr'));
	
	$("#manageAltSchemeSubmitButton").click(function() {
		$("#errorMsg").hide();
		populateRelModelAttribute();
		if(allMandatorySelected()){
			
			$("#alternateSchemeCodesForm").submit();
		}
		return false;
	});
	
	if ($('#schemeCode').val() == '') {
		$('#altSchemeCodeSection').hide();		
	}else{
		$('#altSchemeCodeSection').show();
	}
}
function bindNewAltSchmRow(rowHandle) {
	var codeTableSelectBoxHandle = rowHandle.find('#codeTableId');
	codeTableSelectBoxHandle.change(function() {
		if ($.trim($(this).val()) != '') {
			$('#errorMsg').hide();
			rowHandle.find('#codeValueId').empty();
			populateCodeValues($(this).val(),rowHandle);
		}
	}); 
}
function populateCodeValues(codeTableId,rowHandler) {
	$.getJSON('retrieveCodeValuesForTableId.form', {
		codeTableId : codeTableId,
		ajax : 'true'
	}, function(data) {
		populateCodeValuesForCodeTableId(data[codeTableId], rowHandler);
		
		// QC# 3378 issue fix changes $starts$
		$(rowHandler).closest('td').css('display', 'none');
		var newOpts = rowHandler.find('#codeValueId').html();
		rowHandler.find('#codeValueId').html('');
		rowHandler.find('#codeValueId').html(newOpts);
		$(rowHandler).closest('td').css('display', 'block');
		// QC# 3378 issue fix changes $ends$
	});
}
function populateCodeValuesForCodeTableId(codeValueData, rowHandler){
	rowHandler.find('#codeValueId').append('<option value="">-- Select Code Value --</option>');
	$.each(codeValueData, function(index, codeValue) { 
		rowHandler.find('#codeValueId').append('<option value="' + codeValue.codeValueId + '">' + codeValue.codeValueId 
				+ ' [ '	+ codeValue.codeValueDescription + ' ]</option>');
	});
}

function retrieveCodeTableValuesAltSchemes(rowHandler) {
	$.getJSON('retrieveCodeTablesForAltScheme.form', {
		ajax : 'true'
	}, function(data) {
		populateCodeTableValuesAltScheme(data, rowHandler);
		
		// QC# 3378 issue fix changes $starts$
		$(rowHandler).css('display', 'none');
		var newOpts = rowHandler.find('#codeTableId').html();
		rowHandler.find('#codeTableId').html('');
		rowHandler.find('#codeTableId').html(newOpts);
		$(rowHandler).css('display', 'block');
		// QC# 3378 issue fix changes $ends$
	});
}

function populateCodeTableValuesAltScheme(codeTableData, rowHandler){
	rowHandler.find('#codeTableId').empty();
	rowHandler.find('#codeTableId').append('<option value="">-- Select Code Table --</option>');
	$.each(codeTableData, function(index, codeTable) { 
		rowHandler.find('#codeTableId').append('<option value="' + codeTable.code + '">' + codeTable.code 
				+ ' ['	+ codeTable.value + ']</option>');
	});
}

function allMandatorySelected() {
	if(isCodeValueSelected()&&isSchemeTypeSelected()) {
		return true;
	} else {
		return false;
	} 
}
function isCodeValueSelected() {
	var selected=0;
	$(".codeValueId").each(function(){
		if($(this).val()==''){
			alert('Please select Code Value');
			selected=1;
			$(this).focus();
			return false;
		}
	});
	if (selected==0){
		return true;
	}
}
function isSchemeTypeSelected(){
	var selected=0;
	$(".alternateSchemeCodeValue").each(function(){
		if(!$(this).val()){
			alert('Please Enter Alternate Scheme Type Value');
			$(this).focus();
			selected=1;
			return false;
		}
	});
	if (selected==0){
		return true;
	}
}
function enableEditAltSchemeCodes() {
	var deleteScotsAlternateAccess =$('#deleteScotsAlternateAccess');
	
	if($('#deleteScotsAlternateAccess').val()=='true') {
		$('.expirationDate').each(function() {
			$(this).datepicker('enable');
		});
	}
	
	$(".showable").show();
	$("#newAltSchmDiv").show();
	$('#manageAltSchemeSubmitButton').show();
	$('#manageAltSchemeResetButton').show();
	$('#manageAltSchemeEditButton').hide();
	$('#manageAltSchemeCancelButton').show();
}

function isValidAltSchemeSearchCriteria() {
	
	if ($('#schemeCode').val() == '') {
		$('#errorMsg').show();
		$('#errorMsg').html('Please select Alternate Scheme Type Code');
		return false;
	} else {
		$('#errorMsg').hide();
		$("#manageAltSchemeEditButton").show();
		$("#manageAltSchemeCancelButton").show();	
		return true;
	}
}

var schmToggleIndc = 'VALUE';
function toggleAltSchemeCodeTypes() {
	$.getJSON('toggleAltSchemeCodeTypes.form',{
						toggleIndicator : schmToggleIndc,
						ajax : 'true'
			},function(data) {				
						$("#schemeCode").empty();
						$("#schemeCode").append('<option value="">-- Select Alternate Scheme Type Code --</option>');
						if (schmToggleIndc == 'CODE') {
							$.each(data, function() {
								$("#schemeCode").append(
										'<option value="' + this.codeValueId + '">'
												+ this.codeValueId + ' [ '
												+ this.codeValueDescription + ' ] '
												+ '</option>');
							});
							schmToggleIndc = 'VALUE';
						} else {
							$.each(data, function() {
								$("#schemeCode").append(
										'<option value="' + this.codeValueId + '">'
												+ this.codeValueDescription + ' [ '
												+ this.codeValueId + ' ] '
												+ '</option>');
							});
							schmToggleIndc = 'CODE';
						}
					});
}

function addAltCodeRow() {	
	$('.mandatoryFields').show();	
	var nextIndex = $(".newcodeTableId").length;
	$('.tableContainerRow:last').after($('.tableContainerRow:last').clone());
	$('.removeAltCodeRowLink:last')
			.html(
					'<a href="javascript:;" style="text-decoration: none;" onclick="removeAltCodeRow(this,'
							+ nextIndex + ');">[-]</a>');
	$('.showable').show();
	
	var newlyAddedChildRow = $('.alternateCodes:last').find('.newalternateSchemeCodeValue').closest('tr');	
	
	newlyAddedChildRow.find(".newalternateSchemeCodeValue").val('');
	newlyAddedChildRow.find(".newalternateSchemeCodeValueDescription").val('');
	newlyAddedChildRow.find(".cdValSchemeExpirationDate").val('');
	newlyAddedChildRow.find(".expirationDate").val('');
	newlyAddedChildRow.find('.cdValSchemeExpirationDate').removeAttr('id');
	newlyAddedChildRow.find('.newExpirationDate').removeAttr('id');
	newlyAddedChildRow.find('.ui-datepicker-trigger').remove();
	newlyAddedChildRow.find('.cdValSchemeExpirationDate').val(getToday());
	initializeNewRowDatePick(newlyAddedChildRow, '.cdValSchemeExpirationDate');
	initializeNewRowDatePick(newlyAddedChildRow, '.newExpirationDate');
	
	
	
	// newlyAddedChildRow.find('.expirationDate').datepicker('enable');
	// initializeNewRowDatePick(newlyAddedChildRow, '.newexpirationDate');

	var newlyAddedChildRow = $('.alternateCodes:last').find('.newcodeTableId').closest('tr');	
	
	newlyAddedChildRow.find('.newcodeValueId').removeAttr('disabled');	
	
	
	$(newlyAddedChildRow).css('display', 'none');
	retrieveCodeTableValuesAltSchemes(newlyAddedChildRow);
	
	newlyAddedChildRow.find(".newcodeValueId").empty();
	newlyAddedChildRow.find(".newcodeValueId").append('<option value=""> -- Select Code Value -- </option>');
	bindNewAltSchmRow(newlyAddedChildRow);
	return false;
}
function removeAltCodeRow(removeHandle, rowIndexToDelete) {
	$(removeHandle).closest('tr').eq(rowIndexToDelete + 1).find('.cdValSchemeExpirationDate').datepicker('destroy');
	$(removeHandle).closest('tr').eq(rowIndexToDelete + 1).find('.expirationDate').datepicker('destroy');
	
	$('#alternateCodesContainerTable .tableContainerRow').each(function() {
		if(this.rowIndex > rowIndexToDelete){			
			
			$(this).find('.cdValSchemeExpirationDate').datepicker('destroy');			
			$(this).find('.cdValSchemeExpirationDate').removeClass('hasDatepicker');
			$(this).find('.cdValSchemeExpirationDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.expirationDate').datepicker('destroy');			
			$(this).find('.expirationDate').removeClass('hasDatepicker');
			$(this).find('.expirationDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeAltCodeRowLink').html($(this).find('.removeAltCodeRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	$(removeHandle).closest('.tableContainerRow').remove();
	return false;	
	
}


function populateRelModelAttribute(){
	
	var modelIndex = 0;
	$('#alternateCodesContainerTableOld').find('.expirationDate').each(function(){
		// alert($.trim($(this).val()));
		if($.trim($(this).val()) != ''){			
			updateRelNames($(this).closest('tr'), modelIndex);
			updateNamesOfNewRelRow($(this).closest('tr') , '.existingHiddenEffectiveDate', modelIndex, 'codeValueAlternateSchemes', 'effectiveDate');
		} else {
			// alert("Entering Else");
			removeRelNames($(this).closest('tr'));
		}
		modelIndex++;
	});
	
	$('#alternateCodesContainerTable').find('.alternateCodes').each(function(){
		if($(this).find('.newcodeTableId').is(':visible')){
			updateRelNames($(this), modelIndex);
			updateNamesOfNewRelRow($(this) , '.newEffectiveDate', modelIndex, 'codeValueAlternateSchemes', 'effectiveDate');
			modelIndex++;
			
		}
	});
}

function updateRelNames(newlyAddedRelRow, nextIndex){	
	updateNamesOfNewRelRow(newlyAddedRelRow , '.newcodeTableId', nextIndex, 'codeValueAlternateSchemes', 'codeTableId');
	updateNamesOfNewRelRow(newlyAddedRelRow , '.newcodeValueId', nextIndex, 'codeValueAlternateSchemes', 'codeValueId');
	updateNamesOfNewRelRow(newlyAddedRelRow , '.newalternateSchemeCodeValue', nextIndex, 'codeValueAlternateSchemes', 'alternateSchemeCodeValue');
	updateNamesOfNewRelRow(newlyAddedRelRow , '.newalternateSchemeCodeValueDescription', nextIndex, 'codeValueAlternateSchemes', 'alternateSchemeCodeValueDescription');
	updateNamesOfNewRelRow(newlyAddedRelRow , '.cdValSchemeExpirationDate', nextIndex, 'codeValueAlternateSchemes', 'effectiveDate');	
}


function updateNamesOfNewRelRow(newlyAddedRow , className, rowIndex, bindArrayName, bindFieldName){
	var currentElement = newlyAddedRow.find(className);
	updateNames(currentElement, rowIndex, bindArrayName, bindFieldName);
}

function removeRelNames(rowHandle){	
	rowHandle.find('.newcodeTableId').removeAttr('id');	
	rowHandle.find('.newcodeTableId').removeAttr('name');	
	rowHandle.find('.newcodeValueId').removeAttr('id');	
	rowHandle.find('.newcodeValueId').removeAttr('name');	
	rowHandle.find('.newalternateSchemeCodeValue').removeAttr('id');	
	rowHandle.find('.newalternateSchemeCodeValue').removeAttr('name');	
	rowHandle.find('.newalternateSchemeCodeValueDescription').removeAttr('id');	
	rowHandle.find('.newalternateSchemeCodeValueDescription').removeAttr('name');
	rowHandle.find('.existingHiddenEffectiveDate').removeAttr('id');
	rowHandle.find('.existingHiddenEffectiveDate').removeAttr('name');
	
}

function enableButtons()
{
	
	if($("#schemeCode").val()== "")
	{		
		$("#altSchemeCodeSection").hide();
		$("#manageAltSchemeEditButton").hide();
		$("#manageAltSchemeCancelButton").hide();		
	}
	
}