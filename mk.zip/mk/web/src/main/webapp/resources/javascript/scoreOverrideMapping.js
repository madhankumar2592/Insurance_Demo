$(document).ready(function(){
	bindScoreOverrideEvents();
	
});

function bindScoreOverrideEvents(){
$('#scoreTypeCode').change(function(){
		if(($.trim($('#scoreTypeCode').val()) != '')){
			var scoreType = $('#scoreTypeCode').val();
			populateMarketTypeCodes(scoreType);
		}
	});

$('#marketTypeCode').change(function(){
	if(($.trim($('#scoreTypeCode').val()) != '')&&($.trim($('#marketTypeCode').val()) != '')){
		var scoreType = $('#scoreTypeCode').val();
		var marketType = $('#marketTypeCode').val();
		populatescoreVersion(scoreType,marketType);
	}
});

$('#scoreVersion').change(function(){	
	if(($.trim($('#scoreTypeCode').val()) != '')&&($.trim($('#marketTypeCode').val()) != '')&&($.trim($('#scoreVersion').val()) != '')){
		var scoreType = $('#scoreTypeCode').val();
		var marketType = $('#marketTypeCode').val();
		var scoreVersion = $('#scoreVersion').val();
		populateAttributeDetails(scoreType,marketType,scoreVersion);
	}
});

}

function populateMarketTypeCodes(scoreType) {
	$.getJSON('retrieveMarketTypeCodes.form', {
		scoreType : scoreType
	}, function(data) {
		$("#marketTypeCode").prop("disabled",false);
		$("#marketTypeCode").empty();
		$("#marketTypeCode").append('<option value="">--  Select Market Type Code  --</option>'); 
		$.each(data, function() {
			 $("#marketTypeCode").append('<option value="' + this.code + '">' + "["+ this.code +"] "+ this.value + '</option>'); 

		 }); 
	});
	
}

function populatescoreVersion(scoreType,marketType) {
	$.getJSON('retrievescoreVersions.form', {
		scoreType : scoreType,
		marketType : marketType
	}, function(data) {
		$("#scoreVersion").prop("disabled",false);
		$("#scoreVersion").empty();
		$("#scoreVersion").append('<option value="">--  Select Score Version  --</option>'); 
		$.each(data, function() {
			 $("#scoreVersion").append('<option value="' + this.scoreVersion + '">' + this.scoreVersion + '</option>'); 

		 }); 
	});
	
}

