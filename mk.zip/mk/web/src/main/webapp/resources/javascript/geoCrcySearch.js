/**
 * This file serves geoCurrencySearch.jsp
 */
var geoCurrencySearchResultsTable;
$(document).ready(function(){	
	configureGeoCurrencySearchDataTable();
	bindGeoCurrencySearchEvents();	
});


function bindGeoCurrencySearchEvents(){	
	
	$('#geoCurrencySearchBtn').bind('click',function(event){		
		$('#errorMsg').hide();			
		geoCurrencySearchResultsTable.fnFilter($('#geoCrcyCountry').val());
		$('#geoCurrencySearchResults').show();		
		$('#geoCrcyExport').show();	
	});
	
	$('#geoCrcyExport').bind('click',function(event) {		
		var criteriaString=encodeURIComponent($('#geoCrcyCountry').val());	
		location.href = "geoCurrencyExportToExcel.form?type=export&sSearch="+criteriaString+"&time="+new Date().getTime();	
		return false; // to prevent event bubbling
	});	
		
	
}

var effvDate;
function configureGeoCurrencySearchDataTable(){
	
	geoCurrencySearchResultsTable = $("#geoCurrencySearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "geoCurrencySearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "iDeferLoading": 0, 
        "aoColumns": [{ "bVisible": false},{ "bVisible": false},null,{ "bVisible": false},null,
         { 
			
            "aTargets": [5], 
            "bSearchable": false, 
            "sType": 'date',
			"sClass": "right",
            "fnRender": function ( oObj ) {				
				if(oObj.aData[5] != null){					
					var javascriptDate = new Date(oObj.aData[5]);					
					effvDate = getFormattedDate(javascriptDate);
					return "<div align='left'>"+effvDate+"<div>";
				}else{
					effvDate = "";
					return "<div align='left'>"+effvDate+"<div>";
				}
				
            }
        },
        { 			
            "aTargets": [6], 
            "bSearchable": false, 
            "sType": 'date',
			"sClass": "right",
            "fnRender": function ( oObj ) {				
				if(oObj.aData[6] != null){					
					var javascriptDate = new Date(oObj.aData[6]);					
					endDate = getFormattedDate(javascriptDate);
					return "<div align='left'>"+endDate+"<div>";
				}else{
					endDate = "";
					return "<div align='left'>"+endDate+"<div>";
				}
				
            }
        }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {        	        	
			setHyperLinkOnGeoCurrencyColumns(nRow, aData);
		   	return nRow;
        }
  });
}
function setHyperLinkOnGeoCurrencyColumns(nRow, aData){
	$('td:eq(0)', nRow).html(getCurrencyColumnHtml(aData[0], aData[2]));
	$('td:eq(1)', nRow).html(getCurrencyColumnHtml(aData[0], aData[4]));
	$('td:eq(2)', nRow).html(getCurrencyColumnHtml(aData[0], aData[5]));
	$('td:eq(3)', nRow).html(getCurrencyColumnHtml(aData[0], aData[6]));
}

function getCurrencyColumnHtml(code, value){
	return "<a href='geoCurrencyView.form?geoCurrencyId=" + code + "&taskId='>" + value + "</a>";
}

function getFormattedDate(dString) {
    var month = new Array();
     month[0] = "Jan";
     month[1] = "Feb";
     month[2] = "Mar";
     month[3] = "Apr";
     month[4] = "May";
     month[5] = "Jun";
     month[6] = "Jul";
     month[7] = "Aug";
     month[8] = "Sep";
     month[9] = "Oct";
     month[10] = "Nov";
     month[11] = "Dec";
     var d = new Date();
     var n = month[dString.getMonth()];
     d=dString.getDate()+"-"+n+"-"+dString.getFullYear();
     return d;
}