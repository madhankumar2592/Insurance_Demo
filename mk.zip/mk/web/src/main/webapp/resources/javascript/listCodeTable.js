/**
 * This page serves listCodeTable.jsp
 */

var listCodeTableSearchResults;
var systemFlag=false;
$(document).ready(function() {
					bindListCodeTableEvents();
					configureListCodeTableSearchDataTable();
					$("#listCodeTblDiv").add("#codeTableDescriptionDiv").hide();
					$("#sysApplicabilitySelect").empty();
					$("#sysApplicabilitySelect")
							.append(
					'<option value=""> -- Select System Applicability-- </option>');
					$("#ctryApplicabilitySelect").empty();
					$("#ctryApplicabilitySelect").append(
							'<option value="">--Select Country Applicability--</option>');
				});

function bindListCodeTableEvents() {
//	$("#listCodeTableLink").bind('click', function(event) {
//		event.preventDefault();
//		location.href = "listCodeTable.form";
//		return false; // to prevent event bubbling
//	});

	$('#codeTableSelect').bind('change', function() {
		$("#listCodeTblDiv").add("#codeTableDescriptionDiv").hide();
		if ($.trim($(this).val()) != '') {
			$('#errorMsg').hide();
			populateSystems($(this).val());
			populateCountries($(this).val());
		} else {
			initialSystemDropdownValues();
			initialCountryDropdownValues();
		}
	});

	$('#listcodeTableSearchBtn').bind('click',function(event) {
						if ($("#codeTableSelect").val() != "") {
							getCodeTableDescription($("#codeTableSelect").val());
			$("#listCodeTblDiv").add("#codeTableDescriptionDiv").find('tbody').empty();
			$("#listCodeTblDiv").add("#codeTableDescriptionDiv").show();
							listCodeTableSearchResults
									.fnFilter(getListCodeTableSearchCriteria());
						} else {
							$("#errorMsg").show();
						}

					});

	$("#codeToggleButton").bind('click', function() {
		toggleCodeTableList();
		return false;
	});
	$("#languageToggleButton").bind('click', function() {
		toggleLanguageList();
		return false;
	});
	$("#systemToggleButton").bind('click', function(event) {
		if(systemFlag){
			toggleSystemList();
			return false;
		}
		event.preventDefault();
		return false;
	});
	if(hasEnglish($('.languages'))) {
		$('#codeLanguageSelect').val(39);
	}
}
function initialSystemDropdownValues(){
	$("#sysApplicabilitySelect").empty();
	$("#sysApplicabilitySelect").append(
			'<option value="">--Select System Applicability--</option>');
}
function initialCountryDropdownValues(){
	$("#ctryApplicabilitySelect").empty();
	$("#ctryApplicabilitySelect").append(
			'<option value="">--Select Country Applicability--</option>');
}
function populateSystems(codeTableVal) {
	$.getJSON('retrieveSystemApplicabilityAjaxResults.form', {
		codeTableId : codeTableVal,
		ajax : 'true'
	}, function(data) {
		initialSystemDropdownValues();
		$.each(data, function() {
			$("#sysApplicabilitySelect").append(
					'<option value="' + this.dnbSystemCode + '">' + this.dnbSystemCode + ' ['
							+ this.codeValueDescription + ']</option>');
		});
		systemFlag=true;
	});
}
function populateCountries(codeTableVal) {
	$.getJSON('retrieveCountryApplicabilityAjaxResults.form', {
		codeTableId : codeTableVal,
		ajax : 'true'
	}, function(data) {
		initialCountryDropdownValues();
		$.each(data, function() {
			$("#ctryApplicabilitySelect").append(
					'<option value="' + this.countryGeoUnitId + '">' + this.geoName
							+ '</option>');
		});
	});
}

function getListCodeTableSearchCriteria() {
	var searchCriteria = '';
	var searchCriteriaDelimiter = "#~";
	searchCriteria = $('#codeTableSelect').val() + searchCriteriaDelimiter
			+ $('#ctryApplicabilitySelect').val() + searchCriteriaDelimiter
			+ $('#sysApplicabilitySelect').val() + searchCriteriaDelimiter
			+ $('#codeLanguageSelect').val();

	return searchCriteria;
}

function configureListCodeTableSearchDataTable() {
	listCodeTableSearchResults = $("#listCodeTblSearchResultsTable")
			.dataTable(
					{
						"bServerSide" : true,
						"sAjaxSource" : "codeValueSearchAjaxResults.form",
						"bProcessing" : false,
						"sPaginationType" : "full_numbers",
						"oLanguage" : {
							"sEmptyTable" : "No data available",
							"sLengthMenu" : " _MENU_ items per page",
							"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
			                "sInfoEmpty": "No entries to show"
						},
						"sDom" : 'tlip',
						"aoColumns" : [ null, null, null ],
						"fnRowCallback" : function(nRow, aData, iDisplayIndex,
								iDisplayIndexFull) {
							setHyperLinkOnCodeValueColumns(nRow, aData);
							alignSCoTSCodeTables(nRow);
							return nRow;
						}
					});
}

function getCodeTableDescription(codeTableVal) {
	$.getJSON('getCodeTableDescriptionAjaxResults.form', {
		codeTableId : codeTableVal,
		ajax : 'true'
	}, function(data) {
		$("#codeTableDescription > tbody").html(
				'<tr><td style="width: 17%;">'
						+ '<a href="codeTableView.form?codeTableId=' + data[0]
						+ '&taskId=&search=ListCodeTable" class="list">' + data[0] + '</a>'
						+ '</td><td style="width: 31%;">'
						+ '<a href="codeTableView.form?codeTableId=' + data[0]
						+ '&taskId=&search=ListCodeTable" class="list">' + data[1] + '</a>'
						+ '</td><td style="width: 52%;">' + data[2]
						+ '</td></tr>');
	});
}

function alignSCoTSCodeTables(nRow) {
	$('td:eq(0)', nRow).width("17%");
	$('td:eq(1)', nRow).width("32%");
	$('td:eq(2)', nRow).width("51%");

	// adjusting the column width
	var dtColumnHeader = $('#codeTableDescription').find('thead tr th');
	dtColumnHeader.eq(0).width("17%");
	dtColumnHeader.eq(1).width("31%");
	dtColumnHeader.eq(2).width("52%");
}

function setHyperLinkOnCodeValueColumns(nRow, aData) {
	$('td:eq(0)', nRow).html(getCodeValueColumnHtml(aData[0], aData[0]));
	$('td:eq(1)', nRow).html(getCodeValueColumnHtml(aData[0], aData[1]));
	$('td:eq(2)', nRow).html(aData[2]);
}

function getCodeValueColumnHtml(code, value) {
	return "<a href='codeValueView.form?codeValueId=" + code + "&taskId=&changeTypeId=&search=ListCodeTable' class='list'>" + value
			+ "</a>";
}

var listCodeTblToggleIndc = true;
function toggleCodeTableList() {
	$.getJSON('toggleCodeTableList.form', {
		toggleIndicator : listCodeTblToggleIndc,
		ajax : 'true'
	}, function(data) {
		$("#codeTableSelect").empty();
		$("#codeTableSelect").append(
				'<option value=""> -- Select Code Table-- </option>');
		if (listCodeTblToggleIndc) {
			$.each(data, function() {
				$("#codeTableSelect").append(
						'<option value="' + this.code + '">' + this.value
								+ ' [ ' + this.code + ' ] ' + '</option>');
			});
		} else {
			$.each(data, function() {
				$("#codeTableSelect").append(
						'<option value="' + this.code + '">' + this.code
								+ ' [ ' + this.value + ' ] ' + '</option>');
			});
		}
		
		listCodeTblToggleIndc = !listCodeTblToggleIndc;
	});
}

var languageToggleindc = true;
function toggleLanguageList() {
	$.getJSON('toggleLanguageList.form', {
		toggleIndicator : languageToggleindc,
		ajax : 'true'
	}, function(data) {
		$("#codeLanguageSelect").empty();
		$("#codeLanguageSelect").append(
				'<option value=""> -- Select Language-- </option>');
		if (languageToggleindc) {
			$.each(data, function() {
				$("#codeLanguageSelect").append(
						'<option value="' + this.code + '">' + this.value
								+ ' [ ' + this.code + ' ] ' + '</option>');
			});
		} else {
			$.each(data, function() {
				$("#codeLanguageSelect").append(
						'<option value="' + this.code + '">' + this.code
								+ ' [ ' + this.value + ' ] ' + '</option>');
			});
		}
		languageToggleindc = !languageToggleindc;
	});
}

var systemToggleIndc = true;
function toggleSystemList() {
	$.getJSON('toggleSystemList.form', {
		toggleIndicator : systemToggleIndc,
		ajax : 'true'
	}, function(data) {
		$("#sysApplicabilitySelect").empty();
		$("#sysApplicabilitySelect").append(
				'<option value=""> -- Select System Applicability-- </option>');
		if (systemToggleIndc) {
			$.each(data, function() {
				$("#sysApplicabilitySelect").append(
						'<option value="' + this.dnbSystemCode + '">' + this.codeValueDescription
								+ ' [ ' + this.dnbSystemCode + ' ] ' + '</option>');
			});
		} else {
			$.each(data, function() {
				$("#sysApplicabilitySelect").append(
						'<option value="' + this.dnbSystemCode + '">' + this.dnbSystemCode
								+ ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
			});
		}
		systemToggleIndc = !systemToggleIndc;
	});
}

function hasEnglish(dropDownHandle) {
	var hasEnglish=false;
	dropDownHandle.each(function(){
		if ($(this).val()==39){
			hasEnglish=true;
		}
	});
	return hasEnglish;
}
