/*This file serves addCodeTable.jsp*/

$(document).ready(function(){
	initializeCdValDatepicker();
	bindAddCodeTable();	
//	preSelectSystemsAndCountries();
});

function bindAddCodeTable()
{
//	$('#scotsAddCodeTableLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "scotsAddCodeTable.form";
//		return false;
//	});
	
	$('#addCdTblResetButton').bind('click',function(event){
		if(confirm("Are you sure you want to reset the data?")) {
			event.preventDefault();
			location.href = "scotsAddCodeTable.form";
			return false; // to prevent event bubbling
		}
	});
	$('#addCdTblCancelButton').bind('click',function(event){
		event.preventDefault();
		location.href = "home.form";
		return false; // to prevent event bubbling
	});
}

function selectallcheckboxes(ref)
{
	 if(ref.checked == true)
	 {
			$('input[type=checkbox][name=systemList]').each(function() 
			{ 
				this.checked = true;
			});
	 }
	 else if(ref.checked == false)
	 {
			$('input[type=checkbox][name=systemList]').each(function() 
			{ 
				this.checked = false;
			});	 
	 }
}

function selectallAddCdTblCountries(ref)
{
	 if(ref.checked == true)
	 {
			$('input[type=checkbox][name=countryList]').each(function() 
			{ 
				this.checked = true;
			});
	 }
	 else if(ref.checked == false)
	 {
			$('input[type=checkbox][name=countryList]').each(function() 
			{ 
				this.checked = false;
			});	 
	 }	
}

function clearScots() {

	$('#scotdetailsBox input[type=checkbox][name=systemList]').each(function() 
	{
		this.checked=false; 
	});
	$('#allsystems').attr('checked',false);
	$('#allcountries').attr('checked',false);
	$('#scotdetailsBox input[type=checkbox][name=countryList]').each(function() 
	{ 
		this.checked=false; 
	});	
			
	$("#codeTableName,#onBehalfOfName,#reasonText,#businessDescription").val('')
}

function limitText(limitField, limitNum) {
    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
    } 
}

function deselectAllSystem(system){
	if(!$(system).is(":checked")){
		$('#allsystems').attr('checked',false); 
	}
}
function deselectAllCountry(country){
	if(!$(country).is(":checked")){
		$('#allcountries').attr('checked',false); 
	}
}

function initializeCdValDatepicker(){
	$('.cdValDatepickerTextBox').datepicker(getDatepickerOptions(true));
}
function getDatepickerOptions(isDisabled){
	return {
		showOn: "button",
		buttonImage: "./resources/images/cal.png",
		buttonImageOnly: true,
		disabled: false,
		dateFormat: "yy-mm-dd"
	}
}

function preSelectSystemsAndCountries(){
//	$('.addSystems').each(function(){
//		$(this).attr('checked',true)
//	});
//	$('.addCountries').each(function(){
//		$(this).attr('checked',true)
//	});
}


function validateAddTable() {
	$('#addTableErrMsg').html('');
	var success = true;
	$('#codeTableName').val($.trim($('#codeTableName').val()));
	if ($('#codeTableName').val() == "") {
		$('#addTableErrMsg').html("Enter the Table Name</br>");
		$('#addTableErrMsg').show();
		success = false;
	}
	if ($.trim($('#businessDescription').val()) == "") {
		$('#addTableErrMsg').append("Enter the Business Description");
		$('#addTableErrMsg').show();
		success = false;
	}	
	

	if (success) {
		$('#codeTable').submit();
	} else {
		return success;
	}
}