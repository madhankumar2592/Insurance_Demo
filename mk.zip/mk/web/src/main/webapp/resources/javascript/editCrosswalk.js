$(document).ready(function(){
	 $.ajaxSetup({ cache: false });
	bindAddGlobalElementEvents();
});

function bindAddGlobalElementEvents(){
		$(".addMetadataRowRowLink").hide();
		$(".removeMetadataRowLink").hide();
	
			if($('#elementID').val() != ""){			
				var elemntName = checkElementID($('#elementID').val());			
			}	
				 $('#elementID').attr("style", "visibility: visible");;
				 $('#elementName').val(elemntName);
				 $('#elementName').attr("style", "visibility: visible");	
				 
						if(($.trim($('#elementID').val()) != '')&&($.trim($('#glblEleDataPlatfrm').val()) != '')){
							var glblDetaPlatfrm = $('#glblEleDataPlatfrm').val();
							populateMetadataCodes(glblDetaPlatfrm);
						}
						$('#addCwlkEditButton').bind('click', function(){
							$(".addMetadataRowRowLink").show();
							$(".removeMetadataRowLink").show();
							$(".globalElementMetadataCode").prop("disabled",false);
							$(".globalElementMetadataValue").prop("disabled",false);
							$(".globalElementCrosswalkGrpNme").prop("disabled",false);
							$("#addCwlkSubmitButton").show();
							$("#addCwlkEditButton").hide();
							$('#glblEleDataPlatfrm').removeAttr("disabled");
						});
						
						$('#editCwlkResetButton').bind('click',function(event){
							
							var elemntId = $('#elementID').val();
							var croswlkId = $('#crosswalkId').val();
							if(confirm("Are you sure you want to reset the data?")) {
								event.preventDefault();
								location.href = "editGlblEleCrosswalk.form?crosswalkId=" + croswlkId + "&elementID=" + elemntId + "";
								return false; // to prevent event bubbling
							}
						});
						
						
						$('#addCwlkSubmitButton').bind('click',function(){									
										validateAndSubmit();									
						});
};

function validateAndSubmit(){
	$('#errorMsg').hide();	
		
	if($('#glblEleDataPlatfrm').val() == ""){
		$('#errorMsg').html("Please select Platform code Type");
		$('#errorMsg').show();
		}else if($('#glblEleType').val() == ""){
		 $('#errorMsg').html("Please select Element Type");
		 $('#errorMsg').show();
	}else if(!isAddValueEmpty('.globalElementMetadataCode')) {
		$('#errorMsg').html("Please select the Metadata code");
		$('#errorMsg').show();
	}else if(!isAddValueEmpty('.globalElementMetadataValue')) {
		$('#errorMsg').html("Please enter the Metadata value");
		$('#errorMsg').show();
	}else if(!isGroupEmpty('.globalElementCrosswalkGrpNme')){
		$('#errorMsg').html("Please enter group name");
		$('#errorMsg').show();
	}else if(!isGroupNameExist('.globalElementCrosswalkGrpNme')){
		$('#errorMsg').html("Entered Group Name already exists for an Element");
		$('#errorMsg').show();
	}else{
	if(confirm("Are you sure you want to Update the Global Element ")) {
										
		$('#editCrosswalk').submit();
		}	
		return true;
	}
	
}

function isGroupEmpty(ele) {
	groupEmpty = true;

		$('#attributeDetailTable').find(ele).each(function() {
			if($(this).val() == '') {
				$(this).focus();
				groupEmpty = false;
				return false;
			} 
		});
		
	return groupEmpty;
}



function isGroupNameExist(ele){   
	var cnt = 0;	
	var result = true; 
	var checkGrpName = new Array();
  $('#attributeDetailTable').find(ele).each(function() { 
	  	cnt++;			
		var param = {globalElementCrosswalkGrpNme: $(this).val(), globalElementId: $('#elementID').val()};
		  $.ajax({
		        cache: false,
		        async: false,
				traditional : true,
		        type : "POST",
		        url : "checkGroupNameUnique.form",       
				data : param,
				success : function(data) { 					
		              checkGrpName.push(data);
		        }                 
		  });  
  });

 for(i=0;i<checkGrpName.length;i++){
	if(checkGrpName[i] == false){
		result = false;
	}
 }
  
  return result;
}


function isAddValueEmpty(ele) {
	var hasValue = true;
	$('#attributeDetailTable').find(ele).each(function() {
		if($.trim($(this).val()) == '' || $(this).val() == '') {
			$(this).focus();
			hasValue = false;
			return false;
		} 
	});
	return hasValue;
}


function checkElementID(elementId){
	var result;
	var param = {globalElementId: elementId}	
	 $.ajax({
		 cache: false,
		 async: false,
		 url : "checkElementID.form",		 
        data : param,
        success : function(data) {       	  	
			result = data;
		}			
	 });	
	 return result;
}



		

function populateMetadataCodes(glblDetaPlatfrm){
	
	$.getJSON('retrieveDetails.form',{
		globalElementPlatformCode: glblDetaPlatfrm
	}, function(data) {   			
        	var trHTML = '';
			$("#attributeDetails").css("display","block");	
			var cnt = 0;
			$.each(data, function() {
				//$('.globalElementMetadataCode').append('<option value="' + this.metadataCode + '">' + this.metadataCode + " [ " + this.metadataValue + " ] " + '</option>');
				
				//trHTML += '<tr><td width="5%" id="metacode'+cnt+'">' +this.metadataCode + '</td><td width="25%" id="desc'+cnt+'">' + this.metadataValue + '</td><td><input type="text" class="value'+cnt+'" /></td></tr><br><br><tr><td colspan="3">&nbsp;</td></tr>';
			});
			
		//$("#attributeDetailTable").append(trHTML);
		});
}


function addMetaDataRow(){
	var nextIndex = $(".globalElementMetadataCode").length;
	//scoreGranularity
	var max = null;
	$( "input[name^='globlalElementCrossWalk']" ).each(function() {
		var name =this.name.match(/\d+/);	
		//alert(name);		
		if (max === null || Number(name) > Number(max)){
			max = name;
			//max = Number(max)+1;
			}
	});
	//alert(max);
	nextIndex = Number(max)+1;
	//alert(nextIndex);
	$('#attributeDetailTable').append($('#attributeDetailTable tr:last').clone());
	var newlyAddedMetadataRow = $('#attributeDetailTable tr:last');
	updateNamesOfNewRow(newlyAddedMetadataRow , '.globalElementMetadataCode', nextIndex, 'globlalElementCrossWalk', 'globalElementMetadataCode', "true");	
	updateNamesOfNewRow(newlyAddedMetadataRow , '.globalElementMetadataValue', nextIndex, 'globlalElementCrossWalk', 'globalElementMetadataValue', "true");
	updateNamesOfNewRow(newlyAddedMetadataRow , '.globalElementCrosswalkGrpNme', nextIndex, 'globlalElementCrossWalk', 'globalElementCrosswalkGrpNme', "true");
	updateNamesOfNewRow(newlyAddedMetadataRow , '.changeIndicator', nextIndex, 'globlalElementCrossWalk', 'changeIndicator', "true");
	updateNamesOfNewRow(newlyAddedMetadataRow , '.globalElementCrosswalkId', nextIndex, 'globlalElementCrossWalk', 'globalElementCrosswalkId', "true");

	$('#attributeDetailTable').find('tr:last').find('.removeMetadataRowLink').
	html('<a href="javascript:;" style="text-decoration: none;" onclick="removeMetadataRow(this,' + nextIndex + ');">[-]</a>');
	newlyAddedMetadataRow.find('.globalElementCrosswalkId').val(-1);
	newlyAddedMetadataRow.find('.changeIndicator').val('NEW');

	newlyAddedMetadataRow.show();
	return false;

}

function removeMetadataRow(removeHandle, rowIndexToDelete){

	if($('.globalElementMetadataCode:visible').length ==1){
		alert("At least one Description is mandatory");
		return false;
	}
	
	if($(removeHandle).closest('tr').find('.globalElementCrosswalkId').val()>0) {
		$(removeHandle).closest('tr').find('.changeIndicator').val("DELETED");
		$(removeHandle).closest('tr').remove();
	}else if($(removeHandle).closest('tr').find('.changeIndicator').val()=='NEW') {
		$(removeHandle).closest('tr').remove();
	}
	
	
	$('#attributeDetailTable tr').each(function() {		
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.globalElementMetadataCode'), (this.rowIndex - 1), 'globlalElementCrossWalk', 'globalElementMetadataCode');
			updateNames($(this).find('.globalElementMetadataValue'), (this.rowIndex - 1), 'globlalElementCrossWalk', 'globalElementMetadataValue');
			updateNames($(this).find('.globalElementCrosswalkGrpNme'), (this.rowIndex - 1), 'globlalElementCrossWalk', 'globalElementCrosswalkGrpNme');
			updateNames($(this).find('.changeIndicator'), (this.rowIndex - 1), 'globlalElementCrossWalk', 'changeIndicator');
			

			$(this).find('.removeMetadataRowLink').html($(this).find('.removeMetadataRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}
