/**
 * This file serves scotsValueSearch.jsp
 */
var codeValueSearchResultsTable;
$(document).ready(function(){
	bindCodeValueSearchEvents();
	configureCodeValueSearchDataTable();
});

function bindCodeValueSearchEvents(){
//	$('#scotsCodeValueLink').bind('click',function(event) {
//		event.preventDefault();
//		location.href = "searchCodeValue.form";
//		return false; // to prevent event bubbling
//	});
	
	$('#codeValSearchBtn').bind('click',function(event) {
		if($("#codeValueSearchOpt").val() == "codeValue") {
			if($.isNumeric($("#codeValueTxt").val())) {
				getCodeValueSearchResults();
			} else {
				$("#errorMsg").html("Please enter a valid Code Value");
				$('#errorMsg').show();
			}
		} else {
			getCodeValueSearchResults();
		}
	});
	
	$('#bckToCodeValueSearchLnk').bind('click',function(event) {
		event.preventDefault();
		location.href = "searchCodeValue.form";
		return false; // to prevent event bubbling
	});
	
	if(hasEnglish($('.languages'))) {
		$('#codeValueLangOpt').val(39);
	}
}

function hasEnglish(dropDownHandle) {
	var hasEnglish=false;
	dropDownHandle.each(function(){
		if ($(this).val()==39){
			hasEnglish=true;
		}
	});
	return hasEnglish;
}

function configureCodeValueSearchDataTable() {
	codeValueSearchResultsTable = $("#codeValSearchResultsTable").dataTable(
			{
				"bServerSide" : true,
				"sAjaxSource" : "codeValueDescSearchAjaxResults.form",
				"bProcessing" : false,
				"sPaginationType" : "full_numbers",
				"oLanguage" : {
					"sEmptyTable" : "No data available",
					"sLengthMenu" : " _MENU_ items per page",
					"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
	                "sInfoEmpty": "No entries to show"
				},
				"sDom" : 'tlip',
				"aoColumns" : [ null, null, null, null, { "bVisible": false} ],
				"fnRowCallback" : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
					setHyperLinkOnCodeValueSearchColumns(nRow, aData);
					return nRow;
				}
			});
}

function setHyperLinkOnCodeValueSearchColumns(nRow, aData){
	$('td:eq(0)', nRow).html(getCodeValueSearchColumnHtml(aData[0], aData[0]));
	$('td:eq(1)', nRow).html(aData[1]);
	$('td:eq(2)', nRow).html(getCodeTableSearchColumnHtml(aData[2], aData[4]));
	$('td:eq(3)', nRow).html(aData[3]);
	
	$('td:eq(0)', nRow).width("13%");
	$('td:eq(1)', nRow).width("31%");
	$('td:eq(2)', nRow).width("23%");
	$('td:eq(3)', nRow).width("33%");
}

function getCodeTableSearchColumnHtml(code, value){
	return "<a href='codeTableView.form?codeTableId=" + code + "&taskId=&search=CodeValueSearch' class='list'>" + code + " [ " + value + " ] " + "</a>";
}

function getCodeValueSearchColumnHtml(code, value){
	return "<a href='codeValueView.form?codeValueId=" + code + "&taskId=&changeTypeId=&search=CodeValueSearch'>" + value + "</a>";
}

function getCodeValueSearchResults(){
	var searchCriteria = $("#codeValueSearchOpt").val();
	if(searchCriteria == "codeValue") {
		if($.trim($("#codeValueTxt").val()) != ""){
			if(isValidCodeValSearchCriteria($("#codeValueTxt").val())) {
				showSpinner();
				$('#codeValSearchResults').show();
				$('#errorMsg').hide();
				codeValueSearchResultsTable.fnFilter(
						$.trim($("#codeValueTxt").val()) + "#~" + searchCriteria + "#~" + $("#codeValueLangOpt").val());
			} else {
				$("#errorMsg").html("Only alphabets, numbers, space, hyphen, single quotes and underscore are allowed in Code Value search");
				$('#errorMsg').show();
			}
		} else {
			$("#errorMsg").html("Please enter a Code Value");
			$('#errorMsg').show();
		}
	} else if(searchCriteria == "codeValueDesc") {
		if($.trim($("#codeValueTxt").val()) != ""){			
			showSpinner();
			$('#codeValSearchResults').show();
			$('#errorMsg').hide();
			codeValueSearchResultsTable.fnFilter(
					$.trim($("#codeValueTxt").val()) + "#~" + searchCriteria + "#~" + $("#codeValueLangOpt").val());			
		} else {
			$("#errorMsg").html("Please enter a Code Value Description");
			$('#errorMsg').show();
		}		
	} else if (searchCriteria == "codeValBusDesc") {
		if($.trim($("#codeValueTxt").val()) != ""){			
			showSpinner();
			$('#codeValSearchResults').show();
			$('#errorMsg').hide();
			codeValueSearchResultsTable.fnFilter(
					$.trim($("#codeValueTxt").val()) + "#~" + searchCriteria + "#~" + $("#codeValueLangOpt").val());			
		} else {
			$("#errorMsg").html("Please enter a Code Value Business Description");
			$('#errorMsg').show();
		}	
	} else {
		$("#errorMsg").html("Please enter either Code Value Id, Code Value Description or Business Description");
		$('#errorMsg').show();
	}
}

function isValidCodeValSearchCriteria(inputStr){
//	var validRegex = /^[A-Za-z0-9\_\-\s\']+$/gi;
//	if(!validRegex.test($.trim(inputStr))) {
//		return false;
//	} else {
//		return true;
//	}
		return true;
	}
