/**
 * This JS file is from legalFormInferment.jsp
 */
var legalFormSearchResultsDataTable;
$(document).ready(function() {
	configureLegalFormSearchDataTable();
	bindLegalFormInfermentEvents();
});

function bindLegalFormInfermentEvents() {
//	$('#legalFormSearchLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "legalFormInferment.form";
//		return false; // to prevent event bubbling
//	});
	$(".searchResults").hide();
	$("#legalFormDescriptionDiv").hide();
	$("#legalFormSearchBtn").click(function(){
		if($("#activeCheck").attr("checked")){
			$("#activeCheck").val('true');
		} else {
			$("#activeCheck").val('false');
		}
		if($("#inactiveCheck").attr("checked")){
			$("#inactiveCheck").val('true');
		} else {
			$("#inactiveCheck").val('false');
		}
		$('#errorMsg').hide();
		$(".searchResults").show();
		$("#legalFormDescriptionDiv").show();
		legalFormSearchResultsDataTable.fnFilter(getLegalFormSearchCriteria());
	});
}
function configureLegalFormSearchDataTable(){
	legalFormSearchResultsDataTable = $("#legalFormSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "legalFormSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "iDeferLoading": 0, 
        "aoColumns": [null,null,null,null,null,null,{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnLegalFormColumns(nRow, aData);		
		   	return nRow;
        }
	});
	$("#legalLanguageToggleButton").bind('click', function() {
		toggleLegalLanguageList();
		return false;
	});
}
function setHyperLinkOnLegalFormColumns(nRow, aData) {
	$('td:eq(4)', nRow).html(getLegalFormColumnHtml(aData[10], aData[4]));
}

function getLegalFormColumnHtml(code, value) {
	return "<a href='legalFormInfermentView.form?infermentTextId=" + code + "&taskId=' class='list'>" + value
			+ "</a>";
}
function getLegalFormSearchCriteria(){
	var searchCriteriaDelimiter = "#~";
	var searchCriteria = $('#legalFormSearchString').val() + searchCriteriaDelimiter + 
						 $('#legalFormCountrySelect').val() + searchCriteriaDelimiter + 
						 $('#legalFormCodeSelect').val() + searchCriteriaDelimiter + 
						 $('#legalFormClassCodeSelect').val() + searchCriteriaDelimiter + 
						 $('#legalFormLanguageSelect').val()+ searchCriteriaDelimiter + 
						 $('#activeCheck').val() + searchCriteriaDelimiter + 
						 $('#inactiveCheck').val();
	return searchCriteria;
}

var languageToggleindc = true;
function toggleLegalLanguageList() {
	$.getJSON('toggleLegalFormLanguages.form', {
		toggleIndicator : languageToggleindc,
		ajax : 'true'
	}, function(data) {
		$("#legalFormLanguageSelect").empty();
		$("#legalFormLanguageSelect").append(
				'<option value=""> -- Select Language-- </option>');
		if (languageToggleindc) {
			$.each(data, function() {
				$("#legalFormLanguageSelect").append(
						'<option value="' + this.code + '">' + this.value
								+ ' [ ' + this.code + ' ] ' + '</option>');
			});
		} else {
			$.each(data, function() {
				$("#legalFormLanguageSelect").append(
						'<option value="' + this.code + '">' + this.code
								+ ' [ ' + this.value + ' ] ' + '</option>');
			});
		}
		languageToggleindc = !languageToggleindc;
	});
}