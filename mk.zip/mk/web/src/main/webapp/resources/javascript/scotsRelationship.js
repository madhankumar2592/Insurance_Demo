/**
 * This file serves manageSCoTsRelationship.jsp
 */
$(document).ready(function(){
	bindManageRelationshipEvents();
	initializeRelElements();
});

function bindManageRelationshipEvents(){
	//	$('#scotsRelationshipLink').bind('click',function(event) {
	//		event.preventDefault();
	//		location.href = "manageCodeRelationship.form";
	//		return false; // to prevent event bubbling
	//	});

	var addNewRelationship=false;
	var flag = true;

	$('#searchRelationshipBtn').bind('click',function(event) {
		if(isValidSearchReltnCriteria()) {
			event.preventDefault();
			showSpinner();
			location.href = "retrieveCodeRelationship.form" + 
			"?parentCodeTableId=" + $('#pscotstable').val() + 
			"&childCodeTableId=" + $('#cscotstable').val() +
			"&taskId=" +
			"&isStagingDB=true";
			return false; // to prevent event bubbling
		}
	});

	$('#prntRelnToggleBtn').bind('click',function(event) {
		toggleParentCodeTables();
	});

	$('#relResetBtn').bind('click',function(event){
		if(confirm("Are you sure you want to reset the data?")) {
			event.preventDefault();
			//			location.href = "retrieveCodeRelationship.form" + 
			//						"?parentCodeTableId=" + $('#pscotstable').val() + 
			//						"&childCodeTableId=" + $('#cscotstable').val() +
			//						"&taskId=" +
			//						"&isStagingDB=true";

			$('#pscotstable').val('');
			$('#cscotstable').val('');
			initializeRelElements();
			return false; // to prevent event bubbling
		}
	});

	$('#chldRelnToggleBtn').bind('click',function(event) {
		toggleChildCodeTables();
	});

	$('#relEditBtn').on('click', function(){
		var editFlag=false;
		$(this).hide();

		$.get("lockScotsRelationship.form", function(data){	


			if (data != "false") {

				$('#errorMsg').html('The record is locked by '+data+' due to a pending request on the Work Queue.');
				$('#errorMsg').show();
				return false; // to prevent event bubbling
			} else {					
				enableEditCodeRelation();

			}
			return false;
		});		



		/*if(editFlag==true){
		$('#relSaveBtn').show();
		$('#relSubmitBtn').show();
		$('#relResetBtn').show();
		$('.geoDatepickerTextBox').datepicker('enable');


		var deleteScotsRelationAccess = $('#deleteScotsRelationAccess');
		if(deleteScotsRelationAccess != null){
			if(deleteScotsRelationAccess.val() == 'false'){
				$('.newExpirationDate').datepicker('disable');
			}
		}
		$('#newRelDiv').show();
		$("#newRelTable").find("tr:gt(1)").hide();
		$('#pscotstable').prop("disabled",true);
		$('#cscotstable').prop("disabled",true);
		$('#prntRelnToggleBtn').prop("disabled",true);
		$('#chldRelnToggleBtn').prop("disabled",true);
		$('#searchRelationshipBtn').prop("disabled",true);
		}*/



	});

	$('#addRelBtn').on('click', function(){

		$("#newRelTable").find("tr:gt(1)").show();
		$(this).closest('tr').hide();
		addNewRelationship=true;


	});

	$('#relSubmitBtn').on('click', function(){		

		if (addNewRelationship==true){
			alert('Inside First loop--AddNewRelation  ');
			$('.newRelation').each(function(){

				alert('inside Submit');
				var count=0;


				//var newParent = $.trim($("#newParentCode option:selected").val()); 
				//var newChild = $.trim($("#newChildCode option:selected").val());  

				var newParent=$(this).find('#newParentCode').val();
				var newChild=$(this).find('#newChildCode').val();


				//var expnDate = $(".expirationDate").val();





				if (($('#newParentCode').val() != "")||($('#newChildCode').val() != "")||addNewRelationship==true)	{
					alert('Inside Second loop');

					if($('#newParentCode').val() == "") {

						// alert("Please select Parent Code Value");
						$('#editErrorMsg').show();
						$('#editErrorMsg').html('Please select Parent Code Value');
						flag=false;
					} else if($('#newChildCode').val() == "") 						{

						// alert("Please select Child Code Value");
						$('#editErrorMsg').show();
						$('#editErrorMsg').html('Please select Child Code Value');
						flag=false;
					} else 					{


						$(".existingTr").each(function() {	
								
								
								count++;
							var existingParent = $.trim($(this).find('#parentCode').val());   
							var existingChild = $.trim($(this).find('#childCode').val());	
							var expnDate = $.trim($(this).find('expirationDate').val());	

							alert('ep'+existingParent+'np'+newParent+'ec'+existingChild+'nc'+newChild+'expn'+expnDate);
							if(existingParent == newParent && existingChild == newChild && expnDate == "") {	
								
								 alert("The SCoTS Relationship already exists");							
								$('#editErrorMsg').show();
								$('#editErrorMsg').html('The SCoTS Code Relationship already exists');
								flag = false;

							}
						});

					}	

				}});} 

		if(flag) {
			populateRelModelAttribute();
			$('#editErrorMsg').hide();
				alert('Calling');
			$('#codeValueRelationshipForm').submit();
			return false;
		}		
	});

	$('#relCancelBtn').on('click', function(){
		if($.trim($('#sourceQueue').val()) == 'submitter'){
			location.href = "submitterWorkQueueHome.form?domainName=SCoTS";
		} else if($.trim($('#sourceQueue').val()) == 'approver') {
			location.href = "approverWorkQueueHome.form?domainName=SCoTS";
		} else {
			location.href = "home.form";
		}
		return false;
	});

	$('#relApproveButton').on('click', function(){
		completeTaskAjax(true);
	});

	$('#relRejectButton').on('click', function(){
		// completeTaskAjax(false);
		$("#reasonDiv").show();
		$("#reason").focus();
		return false;
	});
}

function isValidSearchReltnCriteria() {
	var parentCodeValue = $('#pscotstable').val();
	var childCodeValue = $('#cscotstable').val();
	if(parentCodeValue == '' || childCodeValue == '') {
		$('#errorMsg').show();
		$('#errorMsg').html('Please select Parent Code Table and Child Code Table');
		return false;
	} else if(parentCodeValue == childCodeValue) { 
		$('#errorMsg').show();
		$('#errorMsg').html('Parent Code Table and Child Code Table cannot be the same');
		return false;
	} else {
		$('#errorMsg').hide();
		return true;
	}
}

var prntToggleIndc = 'VALUE';
function toggleParentCodeTables() {

	$.getJSON('toggleCodeRelationshipTables.form', {
		toggleIndicator : prntToggleIndc,
		isParent: true,
		ajax : 'true'
	}, function(data) {
		$("#pscotstable").empty();
		$("#pscotstable").append(
		'<option value="">-- Select Parent Code Table --</option>');
		if (prntToggleIndc == 'CODE') {
			$.each(data, function() {
				$("#pscotstable").append(
						'<option value="' + this.code + '">' + this.code
						+ ' [ ' + this.value + ' ] ' + '</option>');
			});
			prntToggleIndc = 'VALUE';
		} else {
			$.each(data, function() {
				$("#pscotstable").append(
						'<option value="' + this.code + '">' + this.value
						+ ' [ ' + this.code + ' ] ' + '</option>');
			});
			prntToggleIndc = 'CODE';
		}
	});
}

var chldToggleIndc = 'VALUE';
function toggleChildCodeTables() {

	$.getJSON('toggleCodeRelationshipTables.form', {
		toggleIndicator : chldToggleIndc,
		isParent: false,
		ajax : 'true'
	}, function(data) {
		$("#cscotstable").empty();
		$("#cscotstable").append(
		'<option value="">-- Select Child Code Table --</option>');
		if (chldToggleIndc == 'CODE') {
			$.each(data, function() {
				$("#cscotstable").append(
						'<option value="' + this.code + '">' + this.code
						+ ' [ ' + this.value + ' ] ' + '</option>');
			});
			chldToggleIndc = 'VALUE';
		} else {
			$.each(data, function() {
				$("#cscotstable").append(
						'<option value="' + this.code + '">' + this.value
						+ ' [ ' + this.code + ' ] ' + '</option>');
			});
			chldToggleIndc = 'CODE';
		}
	});
}

function initializeRelElements(){

	if(($.trim($('#sourceQueue').val()) == 'submitter') || 
			($.trim($('#sourceQueue').val()) == 'approver')) {
		if ($.trim($('#sourceQueue').val()) == 'submitter') {
			$('#relApproveButton').hide();
			$('#relRejectButton').hide();
		} else if ($.trim($('#sourceQueue').val()) == 'approver') {
			$('#relApproveButton').show();
			$('#relRejectButton').show();
		}
		$('#relEditBtn').hide();
		$('#searchRelationshipBtn').hide();
		$('#pscotstable').prop('disabled', true);
		$('#cscotstable').prop('disabled', true);
		$('#prntRelnToggleBtn').hide();
		$('#chldRelnToggleBtn').hide();
	} else {
		$('#relApproveButton').hide();
		$('#relRejectButton').hide();

		$('#pscotstable').prop("disabled",false);
		$('#cscotstable').prop("disabled",false);
		$('#prntRelnToggleBtn').prop("disabled",false);
		$('#chldRelnToggleBtn').prop("disabled",false);
		$('#searchRelationshipBtn').prop("disabled",false);
	}

	$('#relSaveBtn').hide();
	$('#relSubmitBtn').hide();
	$('#relResetBtn').hide();
	$('#newRelDiv').hide();
	
	alert("inside Trim");
	if(($.trim($('#cscotstable').val()) == '') && 
			($.trim($('#pscotstable').val()) == '')){
		alert("inside Trim");
		alert('parent'+$('#pscotstable').val());
		alert('child'+$('#cscotstable').val());

		$('#existingRelDiv').hide();
		$('#relEditBtn').hide();
	}
}

function addRelRow(){
	$('#newRelTable').append($('#newRelTable tr:last').clone());
	var newlyAddedRelRow = $('#newRelTable tr:last');
	newlyAddedRelRow.find('.newParentCode').val('');
	newlyAddedRelRow.find('.newChildCode').val('');
	newlyAddedRelRow.find('.newEffectiveDate').val('');
	newlyAddedRelRow.find('.newExpirationDate').val('');
	newlyAddedRelRow.find('.newEffectiveDate').removeAttr('id');
	newlyAddedRelRow.find('.newExpirationDate').removeAttr('id');
	newlyAddedRelRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePicker(newlyAddedRelRow, '.newEffectiveDate');
	initializeNewRowDatePicker(newlyAddedRelRow, '.newExpirationDate');
	return false;
}

function removeRelRow(removeHandle){
	if($('#newRelTable').find('.newParentCode').length > 1){
		$(removeHandle).closest('tr').remove();
	}else{
		$("#newRelTable").find("tr:gt(1)").hide();
		$("#newRelTable").find("tr:eq(1)").show();
	}
}

function getNextRelIndex(){
	var existingIndex = $('#existingRelTable').find('.existingParentcode').length;
	var newIndex = $('#newRelTable').find('.newParentCode').length;
	return (existingIndex + newIndex);
}

function populateRelModelAttribute(){
	var modelIndex = 0;
	$('#existingRelTable').find('.existingExpirationDate').each(function()		{

		

		if($.trim($(this).val()) != ''){
			
			updateRelNames($(this).closest('tr'), modelIndex);		
			//updateNamesOfNewRelRow($(this).closest('tr') , '.existingHiddenEffectiveDate', modelIndex, 'codeValueAssociations', 'effectiveDate');
			updateNamesOfNewRelRow($(this).closest('tr') , '.existingExpirationDate', modelIndex, 'codeValueAssociations', 'expirationDate')		;
			alert('Inside Existing Table'+ $.trim($(this).val()));


		} else {
			removeRelNames($(this).closest('tr'));
		}
		modelIndex++;
	});

	$('#newRelTable').find('.newParentCode').each(function(){
		if($(this).is(':visible')){
			updateRelNames($(this).closest('tr'), modelIndex);
			updateNamesOfNewRelRow($(this).closest('tr') , '.newEffectiveDate', modelIndex, 'codeValueAssociations', 'effectiveDate');
			modelIndex++;
		}
	});
}

function removeRelNames(rowHandle){
	rowHandle.find('.newAssociationId').removeAttr('name');
	rowHandle.find('.newAssociationId').removeAttr('id');
	rowHandle.find('.newParentCode').removeAttr('name');
	rowHandle.find('.newParentCode').removeAttr('id');
	rowHandle.find('.newChildCode').removeAttr('name');
	rowHandle.find('.newChildCode').removeAttr('id');
	rowHandle.find('.existingHiddenEffectiveDate').removeAttr('name');
	rowHandle.find('.existingHiddenEffectiveDate').removeAttr('id');
	rowHandle.find('.newExpirationDate').removeAttr('name');
	rowHandle.find('.newExpirationDate').removeAttr('id');
	rowHandle.find('.createdUser').removeAttr('name');
	rowHandle.find('.createdUser').removeAttr('id');
	rowHandle.find('.createdDate').removeAttr('name');
	rowHandle.find('.createdDate').removeAttr('id');
}

function updateRelNames(newlyAddedRelRow, nextIndex){
	updateNamesOfNewRelRow(newlyAddedRelRow , '.newAssociationId', nextIndex, 'codeValueAssociations', 'codeValueAssociationId');
	updateNamesOfNewRelRow(newlyAddedRelRow , '.newParentCode', nextIndex, 'codeValueAssociations', 'parentCodeValueId');
	updateNamesOfNewRelRow(newlyAddedRelRow , '.newChildCode', nextIndex, 'codeValueAssociations', 'childCodeValueId');
	updateNamesOfNewRelRow(newlyAddedRelRow , '.newExpirationDate', nextIndex, 'codeValueAssociations', 'expirationDate');
	updateNamesOfNewRelRow(newlyAddedRelRow , '.createdUser', nextIndex, 'codeValueAssociations', 'createdUser');
	updateNamesOfNewRelRow(newlyAddedRelRow , '.createdDate', nextIndex, 'codeValueAssociations', 'createdDate');
}

function updateNamesOfNewRelRow(newlyAddedRow , className, rowIndex, bindArrayName, bindFieldName){
	var currentElement = newlyAddedRow.find(className);
	updateNames(currentElement, rowIndex, bindArrayName, bindFieldName);
}



function enableEditCodeRelation() {



	$('#relSaveBtn').show();
	$('#relSubmitBtn').show();
	$('#relResetBtn').show();
	$('.geoDatepickerTextBox').datepicker('enable');


	var deleteScotsRelationAccess = $('#deleteScotsRelationAccess');
	if(deleteScotsRelationAccess != null){
		if(deleteScotsRelationAccess.val() == 'false'){
			$('.newExpirationDate').datepicker('disable');
		}
	}
	$('#newRelDiv').show();
	$("#newRelTable").find("tr:gt(1)").hide();
	$('#pscotstable').prop("disabled",true);
	$('#cscotstable').prop("disabled",true);
	$('#prntRelnToggleBtn').prop("disabled",true);
	$('#chldRelnToggleBtn').prop("disabled",true);
	$('#searchRelationshipBtn').prop("disabled",true);

	return false;






}
