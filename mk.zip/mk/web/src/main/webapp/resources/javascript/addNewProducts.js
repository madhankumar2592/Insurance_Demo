/**
 * New Products
 */
var booFlag = false;
var booFlag2 = false;
var booFlag3 = false;
var booFlag4 = false;

$(document).ready(function() {
	
	if($("#addProductSuccess").val()){
		alert("New Product is added to Reference Data SOR successfully");
	}
	
	bindNewAddProductsEvents();
	
	$('#productVersion').forceNumeric();
	$('#resourceVersion0').forceNumeric();
	$('#salesVersion').forceNumeric();
			
	
	
});

function selectItemByValue(elmnt, value){	
	if(elmnt != null){	
    for(var i=0; i < elmnt.options.length; i++)
    {
      if(elmnt.options[i].value == value)
        elmnt.selectedIndex = i;
    }
	}
  }

 jQuery.fn.forceNumeric = function () {

             return this.each(function () {
                 $(this).keydown(function (e) {
                     var key = e.which || e.keyCode;

                     if (!e.shiftKey && !e.altKey && !e.ctrlKey &&
                     // numbers   
                         key >= 48 && key <= 57 ||
                     // Numeric keypad
                         key >= 96 && key <= 105 ||
                     // comma, period and minus, . on keypad
                        key == 190 || key == 188 || key == 109 || //key == 110 ||
                     // Backspace and Tab and Enter
                        key == 8 || key == 9 || key == 13 ||
                     // Home and End
                        key == 35 || key == 36 ||
                     // left and right arrows
                        key == 37 || key == 39 ||
                     // Del and Ins
                        key == 46 || key == 45)
                         return true;
					if(key == 110)
					//alert("You may not enter any decimals");
                     return false;
                 });
             });
         }


function bindNewAddProductsEvents() {
	var number = document.getElementById('salesChannelCode');
	selectItemByValue(number, 0);
	
	var billSys = document.getElementById('billingSysCode');
	selectItemByValue(billSys, 0);
	
	var rescTyp = document.getElementById('resourceType');
	selectItemByValue(rescTyp, 0);
	
	var rescGrpCd = document.getElementById('resourceGroupCode');
	selectItemByValue(rescGrpCd, 0);
	
	var prodGrpCd = document.getElementById('productGroupCode');
	selectItemByValue(prodGrpCd, 0);


	$('#newProdCancelBtn').bind('click', function(){
		location.href = "addNewProductHome.form";
		return false;
	});
	$('#newProdResetBtn').bind('click', function(){
		location.href = "addNewProductHome.form";
		return false;
	});
	$('#newProdSubmitBtn').bind('click', function(event) {
		
		var booFlags =  validateMetadata();
		var booFlags2 = validateSalesMetadata();
		var booFlags3 = validateResource();
		
		$('#errorMsg1,#errorMsg2,#errorMsg3,#errorMsg4').css("display","none");
		
			if ($('#productCode').val() == '') {
				$('#errorMsg1').text("Please select the Product Code");
				$('#errorMsg1').css("display","block");
				booFlag = false;
				booFlag3 = false;
				booFlag4 = false;
				booFlag2 = false;
			} else if ($('#productGroupCode').val() == '') {
				$('#errorMsg1').text("Please select the Product Group Code");
				$('#errorMsg1').css("display","block");
				booFlag = false;
				booFlag3 = false;
				booFlag4 = false;
				booFlag2 = false;
			} 
			
			else if (booFlag) {
			
				$('#errorMsg1').text("Please select the Product MetadataCode/Value");
				$('#errorMsg1').css("display","block");
				booFlag = false;
				booFlag3 = false;
				booFlag4 = false;
				booFlag2 = false;
			}else if (booFlag3){
				$('#errorMsg2').text("Please select the Resource Code/Resource Group Code/Billing System Code/enter valid Version");
				$('#errorMsg2').css("display","block");
				booFlag = false;
				booFlag3 = false;
				booFlag4 = false;
				booFlag2 = false;
			}else if(booFlag4){
				$('#errorMsg2').text("Please select the Resource MetadataCode/Value");
				$('#errorMsg2').css("display","block");
				booFlag = false;
				booFlag3 = false;
				booFlag4 = false;
				booFlag2 = false;				
			}else if ($('#salesChannelCode').val() == '') {
				$('#errorMsg3').text("Please select the Sales Channel Code");
				$('#errorMsg3').css("display","block");
				booFlag = false;
				booFlag3 = false;
				booFlag4 = false;
				booFlag2 = false;
				} 
							
				else if (booFlag2)	{
				$('#errorMsg3').text("Please select the Delivery MetadataCode/Value");
				$('#errorMsg3').css("display","block");
				booFlag = false;
				booFlag3 = false;
				booFlag4 = false;
				booFlag2 = false;
				}
				else if ($('.addCountries:checked').length == 0) {
				$('#errorMsg4').text("Please select atleast one Market Code");
				$('#errorMsg4').css("display","block");
				booFlag = false;
				booFlag3 = false;
				booFlag4 = false;
				booFlag2 = false;
			} else if ($('#marketGroupCode').val() == '') {
				$('#errorMsg4').text("Please select the Market Group Code");
				$('#errorMsg4').css("display","block");
				booFlag = false;
				booFlag3 = false;
				booFlag4 = false;
				booFlag2 = false;
			}else if($('#productVersion').val().indexOf(".") >= 0) {
				$('#errorMsg1').text("Please enter the valid Product version");
				$('#errorMsg1').css("display", "block");
				booFlag = false;
				booFlag2 = false;
				booFlag4 = false;
				booFlag3 = false;
			}else if ($('#salesVersion').val().indexOf(".") >= 0) {
				$('#errorMsg3').text("Please enter valid Delivery version");
				$('#errorMsg3').css("display", "block");
				booFlag = false;
				booFlag2 = false;
				booFlag4 = false;
				booFlag3 = false;
			} else {
				if(confirm("Are you sure you want to submit the product "+$('#productCode option:selected').text() +" with Version "+$('#productVersion').val()+" ,  Family code "+$('#productFamilyCode option:selected').text() +" , Group code "+$('#productGroupCode option:selected').text() +" , Metadata Code "+$('#productMetadataCode option:selected').text() +" , MetaData value "+$('#productMetadataValue').val()+"' and Sales '"+$('#salesChannelCode option:selected').text() +"' ,  with Version "+$('#salesVersion').val()+" , Metadata Code "+$('#salesMetadataCode option:selected').text() +", MetaData value "+$('#salesMetadataValue').val()+" and Markets "+getSelectedCountries()+" with  Group code "+$('#marketGroupCode option:selected').text() +"?")) {
					$('#addNewProductForm').submit();
				}
			}
		
	});
}

function validateResource(){
	
	$("[id^='resourceCode']").each(function() {	
		var name = this.id.match(/\d+/);
	
	if(!booFlag3){
		if ($('#resourceCode'+name+'').val() == '') {
			$('#errorMsg2').text("Please select Resource Code");
			$('#errorMsg2').css("display","block");
			booFlag3 = true;
		} else if ($('#billingSysCode'+name+'').val() == '') {
			$('#errorMsg2').text("Please select the Billing Sys Code");
			$('#errorMsg2').css("display","block");
			booFlag3 = true;
		}
		 else if ($('#resourceGroupCode'+name+'').val() == '') {
			$('#errorMsg2').text("Please select the Resource Group Code");
			$('#errorMsg2').css("display","block");
			booFlag3 = true;
		}else if($('#resourceVersion'+ name + '').val().indexOf(".") >= 0) {
			$('#errorMsg2').text("Please enter the valid resource version");
			$('#errorMsg2').css("display", "block");
			booFlag3 = true;
		}			
		}
		var booMeta = validateResrcMetadata(name);
		});
}

function validateMetadata() {

	
	$("[id^='productMetadataCode']").each(function() {
		var name = this.id.match(/\d+/);		
		if(!booFlag){		
			if ($('#productMetadataCode'+name+'').val() == '') {
				
				$('#errorMsg1').text("Please select Product Metadata Code/Value");
				$('#errorMsg1').css("display", "block");
				booFlag = true;
			}else if($('#productMetadataValue'+name+'').val() == '' || $.trim($('#productMetadataValue'+name+'').val()) == ''){		
				$('#errorMsg1').text("Please select Product Metadata Code/Value");
				$('#errorMsg1').css("display", "block");
				booFlag = true;
			}
			}
	});
}
function validateSalesMetadata() {

	

	$("[id^='salesMetadataCode']").each(function() {
		var name = this.id.match(/\d+/);
		
		if(!booFlag2){
		if ($('#salesMetadataCode'+name+'').val() == '') {
			$('#errorMsg3').text("Please select Delivery Metadata Code");
			$('#errorMsg3').css("display", "block");
			booFlag2 = true;
		} else if ($('#salesMetadataValue'+name+'').val() == '' || $.trim($('#salesMetadataValue'+name+'').val()) == '') {
			$('#errorMsg3').text("Please select the Delivery Metadata Value");
			$('#errorMsg3').css("display", "block");
			booFlag2 = true;
		}
		}
	});
}

function validateResrcMetadata(index) {

	
	$("[id^='resourceMetadataCode']").each(function() {
		var name = this.id.match(/\d+/);	
		if(!booFlag4)
		{
		if ($('#resc'+index+'').find('#resourceMetadataCode'+name+'').val() == '') {
			$('#errorMsg2').text("Please select Resource Metadata Code");
			$('#errorMsg2').css("display", "block");
			booFlag4 = true;
		} else if ($('#resc'+index+'').find('#resourceMetadataValue'+name+'').val() == '') {
			$('#errorMsg2').text("Please select the Resource Metadata Value");
			$('#errorMsg2').css("display", "block");
			booFlag4 = true;
		}else if ($('#resc'+index+'').find('#resourceMetadataValue'+name+'').val() != null && $('#resc'+index+'').find('#resourceMetadataValue'+name+'').val().replace(/\s/g, '').length==0){						
						$('#errorMsg2').text("Resource Metadata contains only space. Please enter valid Metadata value");
						$('#errorMsg2').css("display", "block");
						booFlag4 = true;
					}		
		}
});
}


function getSelectedCountries() { 
	var val = [];
	$('.addCountries:checked').each(function(i) { 
	val[i] = $(this).val(); 
	});
	return val; 
}

function uncheckallmarketList(ref) {
	if (ref.checked == false) {
		$("#allCountryList").prop("checked", false);
	}
}
function selectallAddCdTblCountries(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=countryList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=countryList]').each(function() {
			this.checked = false;
		});
	}
}
function deselectAllCountry(country) {
	if (!$(country).is(":checked")) {
		$('#allcountries').attr('checked', false);
	}
}
function selectonemarketList(ref) {
	var flag = false;
	if (ref == true) {
		$("#lhead,#lcontent").css("display", "block");
	} else {
		$('input[type=checkbox][name=countryList]').each(function() {
			if (this.checked == true)
				flag = true;
		});
		if (flag == false)
			$("#lhead,#lcontent").css('display', 'none');
	}
}

function addNewResource() {
	var nextIndex = $(".containerRow").length;
	var max = null;
	var max11 = null;
	$("input[name^='productResources']").each(function() {
		var name = this.name.match(/\d+/);
		if (max === null || Number(name) > Number(max)) {
			max = name;
		}
	});
	$("input[name*='resourceMetadata']").each(function() {
		var meta =this.name.split(".");		
		var pro = meta[0].match(/\d+/);
		if(max11 == null || Number(pro) > Number(max11)){
			max11 = pro;
		}
		
	});
	var proIndx = Number(max11) + 1;
	
	var metaIndex = 0;
	
	nextIndex = Number(max) + 1;
	$('#schemeTable').append($('#schemeTable .containerRow:last').clone());
	var newlyAddedResourceRow = $('#schemeTable .containerRow:last');
	updateNamesOfNewRow(newlyAddedResourceRow, '.resourceCode', nextIndex,
			'productResources', 'resourceCode', "true");
	updateNamesOfNewRow(newlyAddedResourceRow, '.resourceType', nextIndex,
			'productResources', 'resourceType', "true");
	updateNamesOfNewRow(newlyAddedResourceRow, '.billingSysCode', nextIndex,
			'productResources', 'billingSysCode', "true");
	updateNamesOfNewRow(newlyAddedResourceRow, '.billingSysType', nextIndex,
			'productResources', 'billingSysType', "true");
	updateNamesOfNewRow(newlyAddedResourceRow, '.ResrcMetaRow', nextIndex,
			'productResources', 'ResrcMetaRow', "true");
	updateNamesOfNewRow(newlyAddedResourceRow, '.resc', nextIndex,
			'productResources', 'resc', "true");
				updateNamesOfNewRow(newlyAddedResourceRow, '.resch', nextIndex,
			'productResources', 'resch', "true");
	updateNamesOfNewRow(newlyAddedResourceRow, '.resch', nextIndex,
			'productResources', 'resch', "true");
	updateNamesOfNewRow(newlyAddedResourceRow, '.resh', nextIndex,
			'productResources', 'resh', "true");
	updateNamesOfNewRow(newlyAddedResourceRow, '.remh', nextIndex,
			'productResources', 'remh', "true");
	
			
		var nxtIndx = $(newlyAddedResourceRow).find(".ResrcMetaRow").length;

		while(nxtIndx>1){
		$(newlyAddedResourceRow)
				.find('.ResrcMetaRow:last')
				.remove();
		nxtIndx--;
	}	
		updateNamesOfRescMetaRow(newlyAddedResourceRow, '.resourceMetadataCode', nextIndex,metaIndex, 'productResources' , 'resourceMetadata', 'resourceMetadataCode', "true");
		updateNamesOfRescMetaRow(newlyAddedResourceRow, '.resourceMetadataValue',nextIndex,metaIndex,'productResources' , 'resourceMetadata', 'resourceMetadataValue', "true");
	
	updateNamesOfNewRow(newlyAddedResourceRow, '.resourceGroupCode', nextIndex,
			'productResources', 'resourceGroupCode', "true");
	updateNamesOfNewRow(newlyAddedResourceRow, '.resourceVersion', nextIndex,
			'productResources', 'resourceVersion', "true");

	$('#schemeTable').find('.containerRow:last')
			.find('.removeNewResource')
			.html(
					'<a href="javascript:;" class="remh" name="remh'+nextIndex+'" id="remh'+nextIndex+'" style="text-decoration: none;" onclick="removeNewResource(this,'
							+ nextIndex + ');">[-]</a>');
	newlyAddedResourceRow.show();
	
	validVersion(nextIndex);
	
	return false;
}

function validVersion(index){
	$("[id=resc"+index+"]").find('#resourceVersion'+index+'').forceNumeric();

	var billSyss = document.getElementById('billingSysCode'+index+'');
		selectItemByValue(billSyss, 0);
		
	var rescTyps = document.getElementById('resourceType'+index+'');
	selectItemByValue(rescTyps, 0);
	
	var rescGrpCds = document.getElementById('resourceGroupCode'+index+'');
	selectItemByValue(rescGrpCds, 0);	
	}

function updateNamesOfRescMetaRow(newlyRescAddedMetadataRow, className , proIndex,  rowIndex, bindClassArrayName, 
bindArrayName, bindFieldName, editFlag){
	var currentElement = newlyRescAddedMetadataRow.find(className);
	updateRescMetaNames(currentElement, proIndex, rowIndex, bindClassArrayName, bindArrayName, bindFieldName);
	currentElement.val("");
	if(editFlag == "true"){
			currentElement.attr("disabled", false);
		}
}

function updateRescMetaNames(currentElement, proIndex, rowIndex, bindClassArrayName, bindArrayName, bindFieldName){
currentElement.attr('name', bindClassArrayName+'[' + proIndex + '].'+ bindArrayName+'[' + rowIndex + '].' + bindFieldName);
currentElement.attr('id', bindFieldName+rowIndex);

}


function removeNewResource(removeHandle, rowIndexToDelete) {
	$('#errorMsg2').css("display","none");
	if ($('.containerRow:visible').length == 1) {
		$('#errorMsg2').text("At least one Resource is mandatory");
		$('#errorMsg2').css("display","block");
		return false;
	} else {
		$(removeHandle).closest('.containerRow').remove();
	}
	
	//alert($(removeHandle).attr("id"));
	var rescRow = $(removeHandle).attr( "id" ).match(/\d+/);
	var rescIndx = Number(rescRow);
	//alert(rescIndx);
	
	$('#schemeTable .containerRow').each(
			function() {
				if (this.rowIndex > rowIndexToDelete) {
					updateNames($(this).find('.resourceCode'),
							(this.rowIndex - 1), 'productResources',
							'resourceCode');
					updateNames($(this).find('.resourceType'),
							(this.rowIndex - 1), 'productResources',
							'resourceType');
					updateNames($(this).find('.billingSysCode'),
							(this.rowIndex - 1), 'productResources',
							'billingSysCode');
					updateNames($(this).find('.billingSysType'),
							(this.rowIndex - 1), 'productResources',
							'billingSysType');
					updateNames($(this).find('.ResrcMetaRow'),
							(this.rowIndex - 1), 'productResources',
							'ResrcMetaRow');
							updateNames($(this).find('.resc'),
							(this.rowIndex - 1), 'productResources',
							'resc');
							updateNames($(this).find('.resch'),
							(this.rowIndex - 1), 'productResources',
							'resch');
							updateNames($(this).find('.resh'),
							(this.rowIndex - 1), 'productResources',
							'resh');
							
							updateNames($(this).find('.remh'),
							(this.rowIndex - 1), 'productResources',
							'remh');
					
					updateRescMetaNames($(this).find('.resourceMetadataCode'),rescIndx,(this.rowIndex - 1), 'productResources', 'resourceMetadata','resourceMetadataCode');
					updateRescMetaNames($(this).find('.resourceMetadataValue'),rescIndx,(this.rowIndex - 1), 'productResources', 'resourceMetadata','resourceMetadataValue');

					updateNames($(this).find('.resourceGroupCode'),
							(this.rowIndex - 1), 'productResources',
							'resourceGroupCode');
					updateNames($(this).find('.resourceVersion'),
							(this.rowIndex - 1), 'productResources',
							'resourceVersion');

					$(this).find('.removeNewResource').html(
							$(this).find('.removeNewResource').html().replace(
									/\d+/, (this.rowIndex - 1)));
				}
			});
	return false;
}
function updateNamesOfNewRow(newlyAddedRow , className, rowIndex, bindArrayName, bindFieldName, editFlag){
	var currentElement = newlyAddedRow.find(className);
	updateNames(currentElement, rowIndex, bindArrayName, bindFieldName);
	currentElement.val("");
	if(editFlag == "true"){
		currentElement.attr("disabled", false);
	}
}

function updateNames(currentElement, rowIndex, bindArrayName, bindFieldName){
	currentElement.attr('name', bindArrayName + '[' + rowIndex + '].' + bindFieldName);
	currentElement.attr('id', bindFieldName+rowIndex);
}	

//updatename function for rescourceMetadata
function updateNamesOfRescMetadataRow(newlyRescAddedMetadataRow, className , proIndex,  rowIndex, bindClassArrayName, 
bindArrayName, bindFieldName, editFlag){
	var currentElement = newlyRescAddedMetadataRow.find(className);
	updateRescMetadataNames(currentElement, proIndex, rowIndex, bindClassArrayName, bindArrayName, bindFieldName);
	currentElement.val("");
	if(editFlag == "true"){
			currentElement.attr("disabled", false);
		}
}

function updateRescMetadataNames(currentElement, proIndex, rowIndex, bindClassArrayName, bindArrayName, bindFieldName){
currentElement.attr('name', bindClassArrayName+'[' + proIndex + '].'+ bindArrayName+'[' + rowIndex + '].' + bindFieldName);
currentElement.attr('id', bindFieldName+rowIndex);

}	
//////////


function addMetaDataRow() {
	var nextIndex2 = $(".MetaRow").length;
	var max = null;
	$("input[name^='productMetaData']").each(function() {
		var name = this.name.match(/\d+/);
		if (max === null || Number(name) > Number(max)) {
			max = name;
		}
	});
	nextIndex2 = Number(max) + 1;
	$('#scotsTable').append($('#scotsTable .MetaRow:last').clone());
	var newlyAddedMetadataRow = $('#scotsTable .MetaRow:last');
	updateNamesOfNewRow(newlyAddedMetadataRow, '.productMetadataCode', nextIndex2, 'productMetaData', 'productMetadataCode', "true");
	updateNamesOfNewRow(newlyAddedMetadataRow, '.productMetadataValue',
			nextIndex2, 'productMetaData', 'productMetadataValue', "true");

	$('#scotsTable')
			.find('.MetaRow:last')
			.find('.removeProductMetadataRowLink')
			.html(
					'<a href="javascript:;" style="text-decoration: none;" onclick="removeProductMetadataRow(this,'
							+ nextIndex2 + ');">[-]</a>');

	newlyAddedMetadataRow.show();
	return false;

}

function removeProductMetadataRow(removeHandle, rowIndexToDelete) {
	$('#errorMsg2').css("display","none");
	if ($('.MetaRow:visible').length == 1) {
		alert("At least one Description is mandatory");
		$('#errorMsg2').css("display","block");
		return false;
	} else {
		$(removeHandle).closest('.MetaRow').remove();
	}
	// alert(rowIndexToDelete);
	// alert(this.rowIndex);
	$('#scotsTable .MetaRow').each(
			function() {
				if (this.rowIndex2 > rowIndexToDelete) {
					updateNames($(this).find('.productMetadataCode'),
							(this.rowIndex2 - 1), 'productMetaData',
							'productMetadataCode');
					updateNames($(this).find('.productMetadataValue'),
							(this.rowIndex2 - 1), 'productMetaData',
							'productMetadataValue');

					$(this).find('.removeProductMetadataRowLink').html(
							$(this).find('.removeProductMetadataRowLink')
									.html().replace(/[0-9]+/,
											(this.rowIndex2 - 1)));
				}
			});
	return false;
}

function addSalesMetaDataRow() {
	var nextIndex3 = $(".SalesMetaRow").length;
	var max = null;
	$("input[name^='salesMetadata']").each(function() {
		var name = this.name.match(/\d+/);
		if (max === null || Number(name) > Number(max)) {
			max = name;
		}
	});
	nextIndex3 = Number(max) + 1;
	$('#noaltschemeTable').append($('#noaltschemeTable .SalesMetaRow:last').clone());
	var newlyAddedMetadataRow = $('#noaltschemeTable .SalesMetaRow:last');
	updateNamesOfNewRow(newlyAddedMetadataRow, '.salesMetadataCode',
			nextIndex3, 'salesMetadata', 'salesMetadataCode', "true");
	updateNamesOfNewRow(newlyAddedMetadataRow, '.salesMetadataValue',
			nextIndex3, 'salesMetadata', 'salesMetadataValue', "true");

	$('#noaltschemeTable')
			.find('.SalesMetaRow:last')
			.find('.removeSalesMetadataRowLink')
			.html(
					'<a href="javascript:;" style="text-decoration: none;" onclick="removeSalesMetadataRow(this,'
							+ nextIndex3 + ');">[-]</a>');

	newlyAddedMetadataRow.show();
	return false;

}

function removeSalesMetadataRow(removeHandle, rowIndexToDelete) {
	$('#errorMsg2').css("display","none");
	if ($('.SalesMetaRow:visible').length == 1) {
		alert("At least one Description is mandatory");
		$('#errorMsg2').css("display","block");
		return false;
	} else {
		$(removeHandle).closest('.SalesMetaRow').remove();
	}
	$('#noaltschemeTable .SalesMetaRow').each(
			function() {
				if (this.rowIndex3 > rowIndexToDelete) {
					updateNames($(this).find('.salesMetadataCode'),
							(this.rowIndex3 - 1), 'salesMetadata',
							'salesMetadataCode');
					updateNames($(this).find('.salesMetadataValue'),
							(this.rowIndex3 - 1), 'salesMetadata',
							'salesMetadataValue');

					$(this).find('.removeSalesMetadataRowLink').html(
							$(this).find('.removeSalesMetadataRowLink')
									.html().replace(/[0-9]+/,
											(this.rowIndex3 - 1)));
				}
			});
	return false;
}

function addResrcMetaDataRow(nameValue) {


	var nextIndex1 = $(".ResrcMetaRow : last").length;
	var max = null;
	var max1 = null;
	var prodRsc1 =$(nameValue).parents("tr").attr("name").split(".");		
	var max1=null;
		var meta1 = prodRsc1[0].match(/\d+/);
		if(max1 == null || Number(meta1) > Number(max1)){
			max1 = meta1;
			}
	
	
	$("input[name^='productResources']").each(function() {
	
		var prodRscs =this.name.split(".");			
		
		
		var meta = prodRscs[1].match(/\d+/);
		if(max == null || Number(meta) > Number(max)){
			max = meta;
			}
	});
	
	prodIndex = Number(max1);
	nextIndex1 = Number(max) + 1;
	
	$("[id='resc"+prodIndex+"']").append($("[id='resc"+prodIndex+"'] .ResrcMetaRow:last").clone());
	
	
	var newlyRescAddedMetadataRow = $("[id='resc"+prodIndex+"'] .ResrcMetaRow:last");
	
	updateNamesOfRescMetadataRow(newlyRescAddedMetadataRow, '.ResrcMetaRow', prodIndex,
	nextIndex1, 'productResources' , 'ResrcMetaRow', 'ResrcMetaRow', "true");
	
	updateNamesOfRescMetadataRow(newlyRescAddedMetadataRow, '.resourceMetadataCode', prodIndex,
	nextIndex1, 'productResources' , 'resourceMetadata', 'resourceMetadataCode', "true");
	updateNamesOfRescMetadataRow(newlyRescAddedMetadataRow, '.resourceMetadataValue', prodIndex,
	nextIndex1, 'productResources' , 'resourceMetadata', 'resourceMetadataValue', "true");
	updateNamesOfRescMetadataRow(newlyRescAddedMetadataRow, '.resch', prodIndex,
	nextIndex1, 'productResources' , 'resourceMetadata', 'resch', "true");
	
	updateNamesOfRescMetadataRow(newlyRescAddedMetadataRow, '.resh', prodIndex,
	nextIndex1, 'productResources' , 'resourceMetadata', 'resh', "true");
			
	$("[id='resc"+prodIndex+"']")
			.find('.ResrcMetaRow:last')
			.find('.removeResrcMetadataRowLink')
			.html(
					'<a href="javascript:;" class="resh" name="resh'+nextIndex1+'" id="resh'+nextIndex1+'" style="text-decoration: none;" onclick="removeResrcMetadataRow(this,'
							+ nextIndex1 + ');">[-]</a>');

	newlyRescAddedMetadataRow.show();
	return false;

}

function removeResrcMetadataRow(removeHandle, rowIndexToDelete) {
	$('#errorMsg2').css("display","none");
	
	var prodRscs =$(removeHandle).parents("tr").attr("name").split(".");			
		var max=null;
		var meta = prodRscs[0].match(/\d+/);
		if(max == null || Number(meta) > Number(max)){
			max = meta;
			}
	
	var prodIndex = $(removeHandle).attr( "id" ).match(/\d+/);
	
	var prod = Number(max);	
	
	if ($("[id$='resc"+prod+"'] .ResrcMetaRow:visible").length == 1) {
		alert("At least one Description is mandatory");
		$('#errorMsg2').css("display","block");
		return false;
	} else {
		$(removeHandle).closest('.ResrcMetaRow').remove();
	}
	
	$("[id='resc"+prod+"'] .ResrcMetaRow").each(
			function() {
				if (this.rowIndex > rowIndexToDelete) {
					updateRescMetadataNames($(this).find('.resourceMetadataCode'), 
					prod,(this.rowIndex ),
					'productResources', 'resourceMetadata','resourceMetadataCode');
					updateRescMetadataNames($(this).find('.resourceMetadataValue'), 
					prod,(this.rowIndex ),
					'productResources', 'resourceMetadata','resourceMetadataValue');
					updateRescMetadataNames($(this).find('.resch'), 
					prod,(this.rowIndex ),
					'productResources', 'resourceMetadata','resch');
					updateRescMetadataNames($(this).find('.resh'), 
					prod,(this.rowIndex ),
					'productResources', 'resourceMetadata','resh');

					$(this).find('.removeResrcMetadataRowLink').html(
							$(this).find('.removeResrcMetadataRowLink')
									.html().replace(/\d+/,
											(this.rowIndex )));
				}
			});
	return false;
}

function validateVersion(evt) {
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode != 45 && (charCode != 46 || $(this).val().indexOf('.') != -1)
			&& (charCode < 48 || charCode > 57)){
		return false;
	}else{
		return true;
	}
	
}
