/**
 * This file serves the geoBulkDownload.jsp
 */
$(document).ready(function() {
	bindgeoBulkDownloadEvents();
	bindGeoCountryBulkDownloadEvents();
	bindGeoHierarchyDownloadEvents();
	if ($("#country").length) {
		populateCountryListDownload($("#country"));
	}
});

function bindgeoBulkDownloadEvents() {
	// $('#geoBulkDownloadLink').bind('click',function(event){
	// event.preventDefault();
	// location.href = "geoBulkDownload.form";
	// return false; // to prevent event bubbling
	// });
}

function checkgeoDownload() {
	if ($("#geoDomain").val() == "Geo Unit Name/Geo Unit Code") {
		$("#countryrow,#nametypeRow,#codetypeRow").css("display", "block");
		$(
				"#unithead,#unitcontent,#namehead,#nametypecontent,#codetypehead,#codetypecontent,#lhead,#lcontent,#lhead1,#lcontent1,#geohierarchyrow")
				.css("display", "none");
		populateCountryListDownload($("#country"));

	} else if ($("#geoDomain").val() == "Geo Unit Association") {
		$(
				"#unithead,#unitcontent,#namehead,#nametypecontent,#codetypehead,#codetypecontent,#lhead,#lcontent,#btnrow")
				.css("display", "none");
		$("#countryrow").css("display", "block");
		populateCountryListDownload($("#country"));
	}
	if ($("#geoDomain").val() == "") {
		$("#countryrow,#nametypeRow,#codetypeRow,#assnrow,#btnrow").css(
				"display", "none");
	}
}

function validategeodownload() {
	if ($("#geoDomain").val() == "") {
		alert("Please select Geo File Type");
	} else if ($("#geoDomain").val() == "Geo Unit Name/Geo Unit Code") {
		if ($("#country").val() == "") {
			alert("Please select a Country");
		} else if ($("#units").val() == "") {
			alert("Please select a GeoUnit");
		} else {
			$('#confirmMessageSelction').css('display', 'inline');
			$('#geoBulkDownload').submit();
		}
	} else if ($("#geoDomain").val() == "Geo Unit Association") {
		if ($("#country").val() == "") {
			alert("Please select a Country");
		} else if ($("#geoHierarchy").val() == "") {
			alert("Please select a GeoHierarchy");
		} else {
			$('#confirmMessageSelction').css('display', 'inline');
			$('#geoBulkDownload').submit();
		}
	}
}

function selectallcodetypecheckboxes(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=geoCodeTypeList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=geoCodeTypeList]').each(function() {
			this.checked = false;
		});
	}
}

function selectonecodetypecheckbox(ref) {

	if (!$(ref).is(":checked")) {
		$('#allcodetype').attr('checked', false);
	}
}

function selectallunittypecode(ref) {

	if (ref.checked == true) {
		$('input[name=geoUnitTypeList]').each(function() {
			$('#btnrow').css('display', 'block');
			$("#nameBtn").css("display", "block");
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[name=geoUnitTypeList]').each(function() {
			$('#btnrow').css('display', 'none');
			$("#nameBtn").css("display", "none");
			this.checked = false;
		});
	}
}

function selectoneunittypecode(ref) {
	var flag = false;
	if (ref == true) {
		$('#btnrow').css('display', 'block');
		$("#nameBtn").css("display", "block");
	} else {
		$('input[type=checkbox][name=geoUnitTypeList]').each(function() {
			if (this.checked == true)
				flag = true;
		});
		if (flag == false) {
			$('#btnrow').css('display', 'none');
			$("#nameBtn").css("display", "none");
		}
	}
}

function uncheckallunittypebox(ref) {

	if (ref.checked == false) {
		$('input[type=checkbox][name=units]').each(function() {
			if (this.checked == true) {
				if ($(":checked").val() == "All")
					this.checked = false;
			}
		});
	}
}

function populateCountryListDownload(countrySelectBox) {
	countrySelectBox.attr('disabled', true);
	countrySelectBox.empty();
	$.getJSON('retrieveCountryList.form', function(data) {
		countrySelectBox
				.append('<option value=""> --Select Country-- </option>');
		$.each(data, function() {
			countrySelectBox.append('<option value="' + this.code + '">'
					+ this.value + '</option>');
		});
		countrySelectBox.attr('disabled', false);
	});
}

function bindGeoCountryBulkDownloadEvents() {

	$('#country').bind('change', function() {
		$("#geoUnitCheckbox").empty();
		if ($.trim($(this).val()) != '') {
			populateGeoUnitType($(this).val());
		}
	});

}

function populateGeoUnitType(geoUnitId) {
	if ($("#geoDomain").val() == "Geo Unit Name/Geo Unit Code") {
		$
				.getJSON(
						'retrieveGeoUnitType.form',
						{
							geographyUnitType : geoUnitId,
							ajax : 'true'
						},
						function(data) {
							$("#geoUnitCheckbox").empty();
							$("#geoUnitCheckbox")
									.append(
											$('<label><input type="checkbox" value="All" name="units" onclick="selectallunittypecode(this);" id="allunits">All</label><br>'));
							$
									.each(
											data,
											function() {
												$("#geoUnitCheckbox")
														.append(
																$('<label><input type="checkbox" id="units" name="geoUnitTypeList" value="'
																		+ this.childGeoUnitTypeCode
																		+ '" onclick="uncheckallunittypebox(this);selectoneunittypecode(this.checked);" />'
																		+ this.childGeoUnitTypeCode
																		+ '['
																		+ this.childGeoUnitTypeDescription
																		+ ']</label><br>'));

											});
						});
	}
}

function bindGeoHierarchyDownloadEvents() {

	$('#country').bind('change', function() {
		$("#geoHierarchy").attr('disabled', true);
		$("#geoHierarchy").empty();
		if ($.trim($(this).val()) != '') {
			populateGeoUnitHierarchy($(this).val());
		}
	});

}

function populateGeoUnitHierarchy(geoUnitId) {
	if ($("#geoDomain").val() == "Geo Unit Association") {
		$.getJSON('retrieveGeoUnitHierarchies.form', {
			geographyUnitType : geoUnitId,
			ajax : 'true'
		}, function(data) {
			$("#geoHierarchy").append(
					'<option value=""> --Select Hierarchy-- </option>');
			$.each(data, function() {
				$("#geoHierarchy").append(
						'<option value="' + this.parentGeoUnitTypeCode + ':'
								+ this.childGeoUnitTypeCode + '">'
								+ this.prntGeoUnitTypeDescription + ' - '
								+ this.childGeoUnitTypeDescription
								+ '</option>');
			});
			$("#geoHierarchy").attr('disabled', false);
		});
	}
}

function selectonelanguagecheckbox(ref) {
	var flag = false;
	if (ref == true) {
		$("#codetypehead,#codetypecontent").css("display", "block");
	} else {
		$('input[type=checkbox][name=languageList]').each(function() {
			if (this.checked == true)
				flag = true;
		});
		if (flag == false)
			$("#codetypehead,#codetypecontent").css('display', 'none');
	}
}

function uncheckallanguages(ref) {

	if (ref.checked == false) {
		$("#alllanguage").prop("checked", false);
		$("#codetypehead,#codetypecontent").css("display", "none");
	}else{
		$("#codetypehead,#codetypecontent").css("display", "block");
	}
}

function selectallanguagecheckboxes(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=languageList]').each(function() {
			$("#codetypehead,#codetypecontent").css("display", "block");

			$("#languagezero").prop("checked", true);
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=languageList]').each(function() {
			$("#codetypehead,#codetypecontent").css("display", "none");
			$("#languagezero").prop("checked", false);
			this.checked = false;
		});
	}
}

function selectallnametypecheckboxes(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=geoNameTypeList]').each(function() {
			$("#lhead,#lcontent").css("display", "block");
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=geoNameTypeList]').each(function() {
			$("#lhead,#lcontent").css("display", "none");
			this.checked = false;
		});
	}
}

function uncheckallnametypebox(ref) {

	if (ref.checked == false) {
		$('input[type=checkbox][name=nametype]').each(function() {
			if (this.checked == true) {
				if ($(":checked").val() == "All")
					this.checked = false;
			}
		});
	}
}

function selectonenametypecheckbox(ref) {
	var flag = false;
	if (ref == true) {
		$("#lhead,#lcontent").css("display", "block");
	} else {
		$('input[type=checkbox][name=geoNameTypeList]').each(function() {
			if (this.checked == true)
				flag = true;
		});
		if (flag == false)
			$("#lhead,#lcontent").css('display', 'none');
	}
}

function populate() {
	if ($("#geoDomain").val() == "Geo Unit Name/Geo Unit Code") {
		// if(this.value)
		$('#unithead,#unitcontent').css('display', 'block');
		$('#geohierarchyrow').css('display', 'none');

	} else if ($("#geoDomain").val() == "Geo Unit Association") {
		// if(this.value)
		$('#unithead,#unitcontent').css('display', 'none');
		$('#geohierarchyrow').css('display', 'block');

	}
}
