$(document).ready(function(){
	bindWorkQueueDownload();	
	configureDwnldWorkQueueDataTable();
});

function bindWorkQueueDownload()
{	
	$('#refreshBtn').click( 
	        function() { 
	        	location.reload(); 
	 });
}

/*$("#myDownloadsTable tbody").delegate("tr", "click", function() {
	submitFromSubmitterQueue(this);
});
*/
function configureDwnldWorkQueueDataTable()
{
	$("#myDownloadsTable").dataTable({
		"sDom": 'tlip',
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
		"iDisplayLength": 10, 
		"aLengthMenu": [10, 25, 50, 100],
		"sPaginationType": "full_numbers",
		"aaSorting": [[1,'desc']], 
		"fnDrawCallback": function( oSettings ) {
			stopPropagationCheckbox();
		} 
	});
}
