var idVals=0;
var scoreSERSearchResultsTable;
var scoreFailureSearchResultsTable;
var flag1 = false;
var flag = false;
var flg = false;
$(document).ready(function(){
$.ajaxSetup({ cache: false });	
$('#scoreDtlSaveButton').bind('click', function(){
		if($('#scoreTyp').val()== '') {
				$('#errorMsg').text("Please select Score Type Code");
				$('#errorMsg').css("display","block");
			}else if ($('#scoreMarketCodes').val()== '') {
				$('#errorMsg').text("Please select Market Type Code");
				$('#errorMsg').css("display","block");
			}else if ($('#scoreVersion').val()== '') {
				$('#errorMsg').text("Please select Score Version");
				$('#errorMsg').css("display","block");
			}else if($('#productCode').val()== '') {
				$('#errorMsg').text("Please select Product  Code");
				$('#errorMsg').css("display","block");
			}else if (!($('input:checkbox[name=resc]:checked').length > 0)) {
				$('#errorMsg').text("Please select at least one Resource");
				$('#errorMsg').css("display","block");
			}else if(validateGranularity()){				
				alert("Please select granularity values");
			}else {		
				$('#errorMsg').css("display","none");
				var granValId =0;
				$('[id^="divId"]').each(function() {
				granValId = this.id.match(/\d+/);
				var arry = $('#divId'+granValId+' > input:checkbox[name=granularity]:checked').map(function() {if(!(this.value=="All"))return this.value}).toArray(); 
				
				if(arry.length > 0){
					$('[id^="granularityCodesString'+granValId+'"]').val("");
					$('[id^="granularityCodesString'+granValId+'"]').val(arry);
					
					$('[id^="granularityString'+granValId+'"]').val("");
					$('[id^="granularityString'+granValId+'"]').val(arry);
					
				}
			 });
			
			var arrResc = new Array();
			$('input:checkbox[name=resc]:checked').each(function() 
					{
				if($(this).val()=="All"){					
				}
				else{
					arrResc.push($(this).val());
				}				
			});
			
				if(arrResc.length > 0){
					$("#resourceString").val("");
					$("#resourceString").val(arrResc);
				}
				var scrTypText = $('#scoreTyp :selected').text();
				var productCodeText = $('#productCode :selected').text();
				var mktCdText = $('#scoreMarketCodes :selected').text();
				var versionText = $('#scoreVersion :selected').text();
					var granVal = new Array();
					$('.addGranularity :selected').each(function() 
					{					
						granVal.push($(this).text());
					});
					
						var retVal = confirm("Are you sure you want to map "+scrTypText+" to "+productCodeText+"?");
						if( retVal == true ){
						$("[id^='scoreTypeCode']").prop( "disabled", false );
						$("[id^='scoreMarketCode']").prop( "disabled", false );
						$("[id^='scoreVersion']").prop( "disabled", false );
						$(".isSearch").val("falsePSerch");						
							$('#scoreDtlForm').submit();
						  return true;
						}else{
						  return false;
						}
					
		}
	});
	
	$('#scoreDtlResetButton').bind('click', function(){
		var value2 = document.getElementById('rescMapId').value.match(/\d+/);
		location.href = "editProductScrMapping.form?rescMapId=" + value2 + "";
		return false;
	});
	
	$('#scoreDtlCancelButton').bind('click', function(){
		location.href = "productScoreRpt.form";
		return false;
	});
	loadScoreTypeValues();
	initializeScoreGranularityElements();
	
	if($('.containerRow:visible').length>1 && $('#isSearch').val()=="true"){
		$('#scoreMarketTable').find('.containerRow:last')
			.find('.removeNewScoreMap')
			.html(
					'<a href="javascript:;" style="text-decoration: none;" onclick="removeNewScoreMap(this,'
							+ $('.containerRow:visible').length + ');">[-]</a>');
	}
	
	$('[name$="scoreMarketCode"]').each(function() {
	$(this).prop( "disabled", true );
	});
	$('[name$="scoreVersion"]').each(function() {
	$(this).prop( "disabled", true );
	});
});

function loadScoreTypeValues(){
	for(var i=0;i<$('.containerRow:visible').length;i++){
		if($.trim($('#scoreTypeCode'+i).val()) != '') {
			$('#errorMsg').hide();
			$('[id^="scoregran'+i+'"]').prop( "disabled", true );
			$('#granularityDiv').css("display","none");
			$('tr.detailRowGran').not(':first').remove(); 
			$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
			populateMarketCodeOnLoad($('#scoreTypeCode'+i).val(), $('[id^="scoreMarketCode'+i+'"]'), false,$('#scoreMarketCodeSelected'+i).val(),i);
		}			
	}	
}
function populateMarketCodeOnLoad(scoreTyp, marketObj, hasGrpLvlFilter,scoreMarketCodeSelected,i) {
	flag = false;
	var groupLevelCode = '';
	var hasEnglish=false;
	if(hasGrpLvlFilter) {
		groupLevelCode = getGroupLevelSearchCodes();
	}
	$.getJSON('retrieveMarketCodesForScrType.form', {
		scoreType : scoreTyp,
		ajax : 'true'
	}, function(data) {
		marketObj.empty();
		$.each(data, function() {
		if(this.code==scoreMarketCodeSelected){
			marketObj.append('<option value="' + this.code + '" selected="selected">' + " [" + this.code + "] " + this.value +  '</option>');
		}else{
			marketObj.append('<option value="' + this.code + '">' + " [" + this.code + "] " + this.value +  '</option>');
		}
			
			if(this.code==39){
				hasEnglish= true;
			}
		 }); 
		if($.trim($('#scoreMarketCode'+i).val()) != '') {
			$('#errorMsg').hide();
		
			$('[id^="scoregran'+i+'"]').prop( "disabled", true );
			$('#granularityDiv').css("display","none");
			$('tr.detailRowGran').not(':first').remove(); 
			$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
			populateVersionOnLoad($('#scoreMarketCode'+i).val(), $('[id^="scoreVersion'+i+'"]'), false,$('[id^="scoreTypeCode'+i+'"]').val(),$('#scoreVersionSelected'+i).val(),i);
		}
		if(hasEnglish) {
			langObj.val(39);
		}
	});
}
function populateVersionOnLoad(scoreMkt, scrVerObj, hasGrpLvlFilter,scoreTyp,scoreVersionSelected,i) {
	var groupLevelCode = '';
	var hasEnglish=false;
	if(hasGrpLvlFilter) {
		groupLevelCode = getGroupLevelSearchCodes();
	}
	$.getJSON('retrieveVersionForScrMktAndType.form', {
		scoreMkt : scoreMkt,
		scoreType : scoreTyp,
		ajax : 'true'
		}, function(data) {
			scrVerObj.empty();
			$.each(data, function() {
				if(this.scoreVersion == scoreVersionSelected){
					scrVerObj.append('<option value="' + this.scoreVersion + '" selected="selected">' + this.scoreVersion +'</option>');
				}else{
					scrVerObj.append('<option value="' + this.scoreVersion + '">' + this.scoreVersion +'</option>');
				}
				
				if(this.code==39){
					hasEnglish= true;
				}
			});
			
			if($.trim(scrVerObj.val()) != '') {
				$('#errorMsg').hide();
				$('[id^="scoregran'+i+'"]').prop( "disabled", true );
				$('#granularityDiv').css("display","none");
				$('tr.detailRowGran').not(':first').remove(); 
				$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
				populateGranularityCodesOnLoad($('[id^="scoreTypeCode'+i+'"]').val(),$('[id^="scoreMarketCode'+i+'"]').val(),$('#scoreVersion'+i).val(),i,$('#granularityString'+i).val() );
			}
		$( "#scoregran" ).prop( "disabled", true );
		if(hasEnglish) {
			scrVerObj.val(39);
		}
	});
}
function populateGranularityCodesOnLoad(scoreType,scoreMkt,scoreVer,idVal,granularityString) {
	$.getJSON('retrieveGranularityCodes.form', {
		scoreVer : scoreVer,
		scoreType : scoreType,
		scoreMkt : scoreMkt,
		ajax : 'true'
	}, function(data) {
		$('[id^="divId'+idVal+'"]').empty();
		$('[id^="divId'+idVal+'"]').append('<label><input type="checkbox" value="All" name="granularity" onclick="selectallAddCdTblGranularity(this);" id="allGranularity" class="addGranularity gran'+idVal+' granAll'+idVal+'" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			if(this.indicator=="3"){    		 
				$('[id^="divId'+idVal+'"]').prop( "disabled", true );
				alert("No Matching Granularity available.Try selecting different version/Market code/Score Type Code...");
			}else{			
				$('[id^="divId'+idVal+'"]').append('<input type="checkbox" name="granularity"  class="addGranularity gran'+idVal+'" value="' + this.codeValueId + '" onclick="deselectAllGranularity(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
				$('[id^="divId'+idVal+'"]').removeAttr('disabled');
			}

		 }); 
		
		 if($.trim($('#productCode').val()) != '') {
			$('#errorMsg').hide();
			$( "#productFamilyCode" ).prop( "disabled", true );
			$( "#productVersion" ).prop( "disabled", true );
			$(".multiple_dropdown_resource").prop( "disabled", true );
			populateProdFamCodeOnLoad($('#productCode').val(), $('#productFamilyCode'),$('#productVersion'), false,$('#productFamilyCodeSelected').val(),$('#productVersionSelected').val(),$('#resourceString').val());
		}	
var granularity=granularityString.split(',');

				$('.gran'+idVal).each(function() {				
				if($(this).val()!="All"){
				for(var i=0;i<granularity.length;i++){
				if(Number(granularity[i]) == Number($(this).val())){
					$(this).prop('checked', true);
				}
				continue;
				}
				
				}
				});		
	});
	 
}
function populateProdFamCodeOnLoad(prodCode, famCodeObj,versionObj, hasGrpLvlFilter, productFamilyCodeSelected ,productVersionSelected, resourceStringSelected) {
	$.getJSON('retrieveProdFamCode.form', {
		prodCode : prodCode,
		ajax : 'true'
	}, function(data) {
		famCodeObj.empty();
		versionObj.empty();
		$( ".multiple_dropdown_resource" ).empty();
		$(".multiple_dropdown_resource").append('<label><input type="checkbox" value="All" name="resc" onclick="selectallresc(this);" id="allresc" class="resc" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			//Version
			if(this.indicator=="1"){
				if(this.codeValueId == productVersionSelected){
					versionObj.append('<option selected="selected" value="' + this.codeValueId + '">' + this.codeValueId + '</option>');
				}else{
					versionObj.append('<option value="' + this.codeValueId + '">' + this.codeValueId + '</option>');
				}
				
				$( "#productFamilyCode" ).prop( "disabled", true );
			}//Resource
			else if(this.indicator=="2"){
				var resource=resourceStringSelected.split(',');
				for(var i=0;i<resource.length;i++){
					 if(this.codeValueId == resource[i]){
						$(".multiple_dropdown_resource").append('<input type="checkbox" checked="checked" name="resc"  class="resc" value="' + this.codeValueId + '" onclick="deselectAllresc(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
					 }else{
						$(".multiple_dropdown_resource").append('<input type="checkbox" name="resc"  class="resc" value="' + this.codeValueId + '" onclick="deselectAllresc(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
					}
				}
				 
				 $( "#productFamilyCode" ).prop( "disabled", true );
				 $( "#productVersion" ).prop( "disabled", true );

			}//If no records present
			else if(this.indicator=="3"){
				 $(".multiple_dropdown_resource").prop( "disabled", true );
				 $( "#productFamilyCode" ).prop( "disabled", true );
				 $( "#productVersion" ).prop( "disabled", true );
				 alert("No Matching Resource available");

			}
			//Family Code
			else{
				if(this.codeValueId == productFamilyCodeSelected){
					famCodeObj.append('<option selected="selected" value="' + this.codeValueId + '">' + " [" + this.codeValueId + "] " + this.codeValueDescription +  '</option>');
				}else{
					famCodeObj.append('<option value="' + this.codeValueId + '">' + " [" + this.codeValueId + "] " + this.codeValueDescription +  '</option>');
				}
				
				$( "#productVersion" ).prop( "disabled", true );
				 $(".multiple_dropdown_resource").prop( "disabled", true );

			}
			
		 });
		if($.trim($('#productFamilyCode').val()) != '') {
			$('#errorMsg').hide();
			$( "#productVersion" ).prop( "disabled", true );
			$(".multiple_dropdown_resource").prop( "disabled", true );
			populateProdVersionOnLoad($('#productFamilyCode').val(),$('#productCode').val(), $('#productVersion'), false,$('#productVersionSelected').val(),$('#resourceString').val());
		}	 
		
	});
}
function populateProdVersionOnLoad(famCode,prodCode, versionObj, hasGrpLvlFilter,productVersionSelected, resourceStringSelected) {
	$.getJSON('retrieveFamProdVersion.form', {
		famCode : famCode,
		prodCode : prodCode,
		ajax : 'true'
	}, function(data) {
		versionObj.empty();
		$(".multiple_dropdown_resource").empty();
		$(".multiple_dropdown_resource").append('<label><input type="checkbox" value="All" name="resc" onclick="selectallresc(this);" id="allresc" class="resc" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			//Version
			if(this.indicator=="1"){
				flag1 = true;
				if(this.codeValueId == productVersionSelected){
					versionObj.append('<option selected="selected" value="' + this.codeValueId + '">' + this.codeValueId + '</option>');
				}else{
					versionObj.append('<option value="' + this.codeValueId + '">' + this.codeValueId + '</option>');
				}
				
				
			}//If no records present
			else if(this.indicator=="3"){
				 $(".multiple_dropdown_resource").prop( "disabled", true );
				 $( "#productVersion" ).prop( "disabled", true );
				 alert("No Matching Resource available");
			}
			//Resource
			else{
				var resource=resourceStringSelected.split(',');
				
				for(var i=0;i<resource.length;i++){
					if(this.codeValueId == resource[i]){
						$(".multiple_dropdown_resource").append('<input type="checkbox" checked="checked" name="resc"  class="resc" value="' + this.codeValueId + '" onclick="deselectAllresc(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
					 }else{
						$(".multiple_dropdown_resource").append('<input type="checkbox" name="resc"  class="resc" value="' + this.codeValueId + '" onclick="deselectAllresc(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
					}
				}
				
				 $( "#productVersion" ).prop( "disabled", true );
			}			
		 }); 
		if($.trim($('#productVersion').val()) != '') {
			$('#errorMsg').hide();
			flag1 = true;
			populateProdFamVerResourceOnLoad($('#productCode').val(),$('#productFamilyCode').val(),$('#productVersion').val(),$('#resourceString').val());
		}	
	});
}

function populateProdFamVerResourceOnLoad(prodCode,famCode, prodVer,resourceStringSelected) {
	$.getJSON('retrieveProdFamVerResource.form', {
		famCode : famCode,
		prodCode : prodCode,
		prodVer : prodVer,
		ajax : 'true'
	}, function(data) {
		$(".multiple_dropdown_resource").empty();
		$(".multiple_dropdown_resource").append('<label><input type="checkbox" value="All" name="resc" onclick="selectallresc(this);" id="allresc" class="resc" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			//If no records present
			if(this.indicator=="3"){
				 $(".multiple_dropdown_resource").prop( "disabled", true );
				 alert("No Matching Resource available");
			}else{				
					$(".multiple_dropdown_resource").append('<input type="checkbox" name="resc"  class="resc" value="' + this.codeValueId + '" onclick="deselectAllresc(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
				}
		 }); 
		var resource=resourceStringSelected.split(',');
				$('[name="resc"]').each(function() {
				
				if($(this).val()!="All"){
				for(var i=0;i<resource.length;i++){
				if(Number(resource[i]) == Number($(this).val())){
				$(this).prop('checked', true);
				}
				continue;
				}
				
				}
				});	
				
	});
}

function initializeScoreGranularityElements(){
	
	$('#productCode').bind('change',function(){
		if($.trim($(this).val()) != '') {
			$('#errorMsg').hide();
			$( "#productFamilyCode" ).prop( "disabled", true );
			$( "#productVersion" ).prop( "disabled", true );
			$(".multiple_dropdown_resource").prop( "disabled", true );
			populateProdFamCode($(this).val(), $('#productFamilyCode'),$('#productVersion'), false);
			}				
		});	
	
	$('#productFamilyCode').bind('change',function(){
		if($.trim($(this).val()) != '') {
			$('#errorMsg').hide();
			$( "#productVersion" ).prop( "disabled", true );
			$(".multiple_dropdown_resource").prop( "disabled", true );
			populateProdVersion($(this).val(),$('#productCode').val(), $('#productVersion'), false);
			}
				
		});	
	$('#productVersion').bind('change',function(){
		if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();
		flag1 = false;
		populateProdFamVerResource($('#productCode').val(),$('#productFamilyCode').val(),$('#productVersion').val());
			}
				
		});
	
	$("[id^='scoreTypeCode']").bind('change',function(){
	
	var idVal = this.id.match(/\d+/);
	if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();
		
		$('[id^="scoreVersion'+idVal+'"]').prop( "disabled", true );		
		$('[id^="scoregran'+idVal+'"]').prop( "disabled", true );

		
		$('[id^="scoreMarketCodes'+idVal+'"]').prop( "disabled", true );

		$('#granularityDiv').css("display","none");
		$('tr.detailRowGran').not(':first').remove(); 
		$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
		populateMarketCode($(this).val(), $('[id^="scoreMarketCode'+idVal+'"]'), false);
		}
			
	});
	
	
	$("[id^='scoreMarketCode']").bind('change',function(){
		var idVal = this.id.match(/\d+/);
		idVals=idVal;
	if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();		
		$('[id^="scoreVersion'+idVal+'"]').prop( "disabled", true );		
		$('[id^="scoregran'+idVal+'"]').prop( "disabled", true );
		$('#granularityDiv').css("display","none");
		$('tr.detailRowGran').not(':first').remove(); 
		$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
		flag = false;
		populateVersion($(this).val(), $('[id^="scoreVersion'+idVal+'"]'), false,$('[id^="scoreTypeCode'+idVal+'"]').val() );		}
			
	});
	
	
		$("[id^='scoreVersion']").bind('change',function(){
		var idVal = this.id.match(/\d+/);
		idVals=idVal;
		if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();		
		$('[id^="scoregran'+idVal+'"]').prop( "disabled", true );
		$('#granularityDiv').css("display","none");
		$('tr.detailRowGran').not(':first').remove(); 
		$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
		populateGranularityCodes($('[id^="scoreTypeCode'+idVal+'"]').val(),$('[id^="scoreMarketCode'+idVal+'"]').val(),$(this).val(),idVal);
			}
				
		});
	
	
	
	

}
function validateGranularity() {  
	var flagGran =  false;   
	var granValIds = 0;
	$('[id^="divId"]').each(function() {
		granValIds = this.id.match(/\d+/);							
		var arrys = $('input:checkbox:checked.gran'+granValIds).map(function () {  return this.value;}).get(); 
		//alert(arrys.length);
		while(arrys.length == 0){					
			flagGran = true;	
			break;
		}				
	});
 	return flagGran;		 
}

function getSelectedGranularity() { 
	var val = [];
	$('.addGranularity:checked').each(function(i) { 
	val[i] = $(this).val(); 
	});
	return val; 
}
function populateMarketCode(scoreTyp, marketObj, hasGrpLvlFilter) {
	var groupLevelCode = '';
	var hasEnglish=false;
	if(hasGrpLvlFilter) {
		groupLevelCode = getGroupLevelSearchCodes();
	}
	$.getJSON('retrieveMarketCodesForScrType.form', {
		scoreType : scoreTyp,
		ajax : 'true'
	}, function(data) {
		marketObj.empty();
		marketObj.append('<option>--Select Market Code--</option>');
		$.each(data, function() {
			marketObj.append('<option value="' + this.code + '">' + " [" + this.code + "] " + this.value +  '</option>');
			marketObj.removeAttr('disabled');
			if(this.code==39){
				hasEnglish= true;
			}
		 }); 
		
		if(hasEnglish) {
			langObj.val(39);
		}
	});
}
function populateVersion(scoreMkt, scrVerObj, hasGrpLvlFilter,scoreTyp) {
	var groupLevelCode = '';
	var hasEnglish=false;
	if(hasGrpLvlFilter) {
		groupLevelCode = getGroupLevelSearchCodes();
	}
	$.getJSON('retrieveVersionForScrMktAndType.form', {
		scoreMkt : scoreMkt,
		scoreType : scoreTyp,
		ajax : 'true'
	}, function(data) {
		scrVerObj.empty();
		scrVerObj.append('<option>--Select Version--</option>');
		$.each(data, function() {
			scrVerObj.append('<option value="' + this.scoreVersion + '">' + this.scoreVersion +'</option>');
			scrVerObj.removeAttr('disabled');
			if(this.code==39){
				hasEnglish= true;
			}
		 }); 
		$( "#scoregran" ).prop( "disabled", true );
		if(hasEnglish) {
			scrVerObj.val(39);
		}
	});
	
}

function selectallAddCdTblGranularity(ref){
var granVal = $(ref).closest('div').attr('id').match(/\d+/);

	if (ref.checked == true) {
		$('.gran'+granVal+'').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('.gran'+granVal+'').each(function() {
			this.checked = false;
		});
	}
}

function deselectAllGranularity(ref) {
if(ref != null){
var granVal = $(ref).closest('div').attr('id').match(/\d+/);

	if (ref.checked == false) {		
		$('.granAll'+granVal+'').each(function() {
			this.checked = false;
		});
}
}
}

function populateGranularityCodes(scoreType,scoreMkt,scoreVer,idVal) {
	$.getJSON('retrieveGranularityCodes.form', {
		scoreVer : scoreVer,
		scoreType : scoreType,
		scoreMkt : scoreMkt,
		ajax : 'true'
	}, function(data) {
		$('[id^="divId'+idVal+'"]').empty();
		$('[id^="divId'+idVal+'"]').append('<label><input type="checkbox" value="All" name="granularity" onclick="selectallAddCdTblGranularity(this);" id="allGranularity" class="addGranularity gran'+idVal+' granAll'+idVal+'" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			if(this.indicator=="3"){    		 
				$('[id^="divId'+idVal+'"]').prop( "disabled", true );
				alert("No Matching Granularity available.Try selecting different version/Market code/Score Type Code...");
			}
			else{
				$('[id^="divId'+idVal+'"]').append('<input type="checkbox" name="granularity"  class="addGranularity gran'+idVal+'" value="' + this.codeValueId + '" onclick="deselectAllGranularity(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
				$('[id^="divId'+idVal+'"]').removeAttr('disabled');
			}

		 }); 
	});
	
}
function populateProdFamCode(prodCode, famCodeObj,versionObj, hasGrpLvlFilter) {
	$.getJSON('retrieveProdFamCode.form', {
		prodCode : prodCode,
		ajax : 'true'
	}, function(data) {
		famCodeObj.empty();
		versionObj.empty();
		$( ".multiple_dropdown_resource" ).empty();
		$("#productFamilyCode").append('<option value="">--  Select Product Family Code  --</option>');
		$(".multiple_dropdown_resource").append('<label><input type="checkbox" value="All" name="resc" onclick="selectallresc(this);" id="allresc" class="resc" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			//Version
			if(this.indicator=="1"){
				versionObj.append('<option value="' + this.codeValueId + '">' + this.codeValueId + '</option>');
							versionObj.removeAttr('disabled');

				$( "#productFamilyCode" ).prop( "disabled", true );
			}//Resource
			else if(this.indicator=="2"){
				 $(".multiple_dropdown_resource").append('<input type="checkbox" name="resc"  class="resc" value="' + this.codeValueId + '" onclick="deselectAllresc(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
				 $(".multiple_dropdown_resource").removeAttr('disabled');
				 $( "#productFamilyCode" ).prop( "disabled", true );
					$( "#productVersion" ).prop( "disabled", true );

			}//If no records present
			else if(this.indicator=="3"){
				 $(".multiple_dropdown_resource").prop( "disabled", true );
				 $( "#productFamilyCode" ).prop( "disabled", true );
				 $( "#productVersion" ).prop( "disabled", true );
				 alert("No Matching Resource available");

			}
			//Family Code
			else{
			famCodeObj.append('<option value="' + this.codeValueId + '">' + " [" + this.codeValueId + "] " + this.codeValueDescription +  '</option>');
			famCodeObj.removeAttr('disabled');
			$( "#productVersion" ).prop( "disabled", true );
				 $(".multiple_dropdown_resource").prop( "disabled", true );

			}
			
		 }); 
		
	});
}
function selectallresc(ref){
	if (ref.checked == true) {
		$('input[type=checkbox][name=resc]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=resc]').each(function() {
			this.checked = false;
		});
	}
}

function deselectAllresc(country) {
	if (!$(country).is(":checked")) {
		$('#allresc').attr('checked', false);
	}
}
function populateProdVersion(famCode,prodCode, versionObj, hasGrpLvlFilter) {
	$.getJSON('retrieveFamProdVersion.form', {
		famCode : famCode,
		prodCode : prodCode,
		ajax : 'true'
	}, function(data) {
		versionObj.empty();
		$(".multiple_dropdown_resource").empty();
		$(".multiple_dropdown_resource").append('<label><input type="checkbox" value="All" name="resc" onclick="selectallresc(this);" id="allresc" class="resc" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			//Version
			if(this.indicator=="1"){
			flag1 = true;
				versionObj.append('<option value="' + this.codeValueId + '">' + this.codeValueId + '</option>');
				versionObj.removeAttr('disabled');
				
			}//If no records present
			else if(this.indicator=="3"){
				 $(".multiple_dropdown_resource").prop( "disabled", true );
				 $( "#productVersion" ).prop( "disabled", true );
				 alert("No Matching Resource available");
			}
			//Resource
			else{
				 $(".multiple_dropdown_resource").append('<input type="checkbox" name="resc"  class="resc" value="' + this.codeValueId + '" onclick="deselectAllresc(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
				 			$(".multiple_dropdown_resource").removeAttr('disabled');
					$( "#productVersion" ).prop( "disabled", true );
			}			
		 }); 
		
	});
}

function populateProdFamVerResource(prodCode,famCode, prodVer) {
	$.getJSON('retrieveProdFamVerResource.form', {
		famCode : famCode,
		prodCode : prodCode,
		prodVer : prodVer,
		ajax : 'true'
	}, function(data) {
		$(".multiple_dropdown_resource").empty();
		$(".multiple_dropdown_resource").append('<label><input type="checkbox" value="All" name="resc" onclick="selectallresc(this);" id="allresc" class="resc" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			//If no records present
			if(this.indicator=="3"){
				 $(".multiple_dropdown_resource").prop( "disabled", true );
				 alert("No Matching Resource available");
			}else{
			$(".multiple_dropdown_resource").append('<input type="checkbox" name="resc"  class="resc" value="' + this.codeValueId + '" onclick="deselectAllresc(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
			$(".multiple_dropdown_resource").removeAttr('disabled');
			}
		 }); 
		
	});
}
$(document).ajaxComplete(function() {
	for(var i=0;i<$('.containerRow:visible').length;i++){
		if(!(flag) ) {
			if($.trim($('[id^="scoreVersion'+i+'"]').val()) != '') {
			$('#errorMsg').hide();
			$('[id^="scoregran'+i+'"]').prop( "disabled", true );
			$('#granularityDiv').css("display","none");
			$('tr.detailRowGran').not(':first').remove(); 
			$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
			flag = true;
			populateGranularityCodesOnLoad($('[id^="scoreTypeCode'+i+'"]').val(),$('[id^="scoreMarketCode'+i+'"]').val(),$('#scoreVersion'+i).val(),i,$('#granularityString'+i).val() );

			}				
		}
		if((flag1)) {
			if($.trim($('#productVersion').val()) != '') {
			$('#errorMsg').hide();
			flag1 = false;
			populateProdFamVerResourceOnLoad($('#productCode').val(),$('#productFamilyCode').val(),$('#productVersion').val(),$('#resourceString').val());
			}				
		}
	}
});



function addNewScoreMap() {
	var nextIndex = $(".containerRow").length;
	var max = null;
	

	$("[name^='scoreMappingList']").each(function() {
	if(typeof this.name === 'undefined'){
	}else{
		var name = this.name.match(/\d+/);
			
		if (max==null || Number(name) > Number(max)) {
			max = name;
			
		}
		}
	});
		

	nextIndex = Number(max) + 1;
	
	
	
	$('#scoreMarketTable').append($('#scoreMarketTable .containerRow:last').clone());	
	var newlyAddedScoreRow = $('#scoreMarketTable .containerRow:last');
	updateNamesOfNewRow(newlyAddedScoreRow, '.scoreTypeCode', nextIndex,
			'scoreMappingList', 'scoreTypeCode', "true");
	updateNamesOfNewRow(newlyAddedScoreRow, '.scoreMarketCode', nextIndex,
			'scoreMappingList', 'scoreMarketCode', "false");
	updateNamesOfNewRow(newlyAddedScoreRow, '.scoreVersion', nextIndex,
			'scoreMappingList', 'scoreVersion', "false");
	updateNamesOfNewRow(newlyAddedScoreRow, '.divId', nextIndex,
			'scoreMappingList', 'divId', "false");
	updateNamesOfNewRow(newlyAddedScoreRow, '.granularityString', nextIndex,
			'scoreMappingList', 'granularityString', "false");
			updateNamesOfNewRow(newlyAddedScoreRow, '.granularityCodesString', nextIndex,
			'scoreMappingList', 'granularityCodesString', "false");
	updateNamesOfNewRow(newlyAddedScoreRow, '.rem', nextIndex,
			'scoreMappingList', 'rem', "false");
	
	$('#scoreMarketTable').find('.containerRow:last')
			.find('.removeNewScoreMap')
			.html(
					'<a href="javascript:;" style="text-decoration: none;" class="rem" name="scoreMappingList['+ nextIndex +'].rem" onclick="removeNewScoreMap(this,'
							+ nextIndex + ');">[-]</a>');
	newlyAddedScoreRow.show();
	initializeScoreGranularityElements();
	return false;
}

function removeNewScoreMap(removeHandle, rowIndexToDelete) {
	$('#errorMsg2').css("display","none");
	
	$(removeHandle).closest('.containerRow').remove();
	var res = $(removeHandle).attr('name').split(".")
	
	$( "input[name^='"+res[0]+"']" ).each(
			function() {
			
			$(this).remove();
			});
			$( "input[name^='scoreMappingList"+res[0].match(/\d+/)+"']" ).each(
			function() {
			
			$(this).remove();
			});
	
	
	
	

	return false;
}

function updateNamesOfNewRow(newlyAddedRow , className, rowIndex, bindArrayName, bindFieldName, editFlag){
if(!(className =='.scoreTypeCode')){
	var currentElement = newlyAddedRow.find(className);
	updateNames(currentElement, rowIndex, bindArrayName, bindFieldName);
	currentElement.val("");
	
	currentElement.empty();
	if(editFlag == "true"){
		currentElement.attr("disabled", false);
	}
	}
	else{
	
	var currentElement = newlyAddedRow.find(className);
	updateNames(currentElement, rowIndex, bindArrayName, bindFieldName);
	currentElement.val("");
	
	if(editFlag == "true"){
		currentElement.attr("disabled", false);
	}
	}
}

function updateNames(currentElement, rowIndex, bindArrayName, bindFieldName){
	currentElement.attr('name', bindArrayName + '[' + rowIndex + '].' + bindFieldName);
	currentElement.attr('id', bindFieldName+rowIndex);
}