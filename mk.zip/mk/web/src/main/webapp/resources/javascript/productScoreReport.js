$(document).ready(function(){
	bindScoreOverrideEvents();
	configureSearchDataTable();
	$('div.dataTables_wrapper').removeClass('dataTables_wrapper');
});

function bindScoreOverrideEvents(){
	
	
	$('#productSearchSaveButton').bind('click',function(event) {
		
		if(!($("input:checkbox[name=marketCodeScrList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Score Market Code");
			$('#errorMsg').css("display","block");
		}		
		else if(!($("input:checkbox[name=scrTypCdList]:checked").length > 0)){
			$('#errorMsg').text("Please select Score Type Code");
			$('#errorMsg').css("display","block");
		} 	
		else if(!($("input:checkbox[name=productList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Product");
			$('#errorMsg').css("display","block");
		}		
		else if(!($("input:checkbox[name=marketCodeList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Product Country");
			$('#errorMsg').css("display","block");
		}
		else{
		$('#errorMsg').hide();
		//Score - Start
		var arrScr = new Array();
		$('input:checkbox[name=marketCodeScrList]:checked').each(function() 
				{
			arrScr.push($(this).val());
				});
		var arrValScr = new Array();
		$('input:checkbox[name=scrTypCdList]:checked').each(function() 
				{
			arrValScr.push($(this).val());
				});
		
		var arrValsScr = new Array();
		$('input:checkbox[name=scrGruCdList]:checked').each(function() 
				{
			arrValsScr.push($(this).val());
				});	
		//Score - End
		
		var arr = new Array();
		$('input:checkbox[name=productList]:checked').each(function() 
				{
			arr.push($(this).val());
				});
		var arrVal = new Array();
		$('input:checkbox[name=marketCodeList]:checked').each(function() 
				{
			arrVal.push($(this).val());
				});
		
		var arrVals = new Array();
		$('input:checkbox[name=resourceList]:checked').each(function() 
				{
			arrVals.push($(this).val());
				});
		
		if(arrVals.length > 0){
			if(arrValsScr.length > 0){
			productSearchResultsTable.fnFilter("1" + "#~" +arrScr + "#~" + arrValScr+ "#~" + arrValsScr+ "#~" + arr + "#~" + arrVal + "#~" + arrVals);
			}
			else{
				productSearchResultsTable.fnFilter("1" + "#~" +arrScr + "#~" + arrValScr+ "#~" + arr + "#~" + arrVal + "#~" + arrVals);
			}
		}
		else{
			if(arrValsScr.length > 0){
				productSearchResultsTable.fnFilter("2" + "#~" +arrScr + "#~" + arrValScr+ "#~" + arrValsScr+ "#~" + arr + "#~" + arrVal);
				}
				else{
					productSearchResultsTable.fnFilter("2" + "#~" +arrScr + "#~" + arrValScr+ "#~" + arr + "#~" + arrVal);
				}
		}
		$('#productSearchResults').show();
		$('#productSearchResult').show();	
		}
		
});
	
	$('#productSearchResetBtn').bind('click', function(){
		location.href = "productScoreRpt.form";
		return false;
	});
	
	$('#productSearchExportBtn').bind('click',function(){
		if(!($("input:checkbox[name=marketCodeList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Score Market Code");
			$('#errorMsg').css("display","block");
		}
		else if(!($("input:checkbox[name=productList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Product");
			$('#errorMsg').css("display","block");
		}
		else if(!($("input:checkbox[name=marketCodeScrList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Score Market Code");
			$('#errorMsg').css("display","block");
		}
		else if(!($("input:checkbox[name=scrTypCdList]:checked").length > 0)){
			$('#errorMsg').text("Please select Score Type Code");
			$('#errorMsg').css("display","block");
		}
		else{
		var criteriaString='';
		$('#errorMsg').hide();
		//Score - Start
		var arrScr = new Array();
		$('input:checkbox[name=marketCodeScrList]:checked').each(function() 
				{
			arrScr.push($(this).val());
				});
		var arrValScr = new Array();
		$('input:checkbox[name=scrTypCdList]:checked').each(function() 
				{
			arrValScr.push($(this).val());
				});
		
		var arrValsScr = new Array();
		$('input:checkbox[name=scrGruCdList]:checked').each(function() 
				{
			arrValsScr.push($(this).val());
				});	
		//Score - End
		var arr = new Array();
		$('input:checkbox[name=marketCodeList]:checked').each(function() 
				{
			arr.push($(this).val());
				});
		var arrVal = new Array();
		$('input:checkbox[name=productList]:checked').each(function() 
				{
			arrVal.push($(this).val());
				});
		
		var arrVals = new Array();
		$('input:checkbox[name=resourceList]:checked').each(function() 
				{
			arrVals.push($(this).val());
				});
		
		if(arrVals.length > 0){
			$("#product_cd_export").val(arrVal);
			$("#mkt_cd_export").val(arr);
			$("#resc_cd_export").val(arrVals);
			//Score - Start
			if(arrValsScr.length > 0){
			$("#mkt_cd_scr_export").val(arrScr);
			$("#sr_typ_cd_export").val(arrValScr);
			$("#sr_gru_cd_export").val(arrValsScr);
			}
			else{
				$("#mkt_cd_scr_export").val(arrScr);
				$("#sr_typ_cd_export").val(arrValScr);	
			}
			//Score - End
			$("#exportIndc").val("1");
		}
		else{
			$("#product_cd_export").val(arrVal);
			$("#mkt_cd_export").val(arr);
			//Score - Start
			if(arrValsScr.length > 0){
			$("#mkt_cd_scr_export").val(arrScr);
			$("#sr_typ_cd_export").val(arrValScr);
			$("#sr_gru_cd_export").val(arrValsScr);
			}
			else{
				$("#mkt_cd_scr_export").val(arrScr);
				$("#sr_typ_cd_export").val(arrValScr);	
			}
			//Score - End
			$("#exportIndc").val("1");
		}
		
		}
		if(($("input:checkbox[name=marketCodeList]:checked").length > 0)){
			if(($("input:checkbox[name=productList]:checked").length > 0)){
				if(($("input:checkbox[name=marketCodeScrList]:checked").length > 0)){
					if(($("input:checkbox[name=scrTypCdList]:checked").length > 0)){
							$('#productSearchForm').submit();						 	
							hideSpinner();
					}
				}
			}
		}
	});

}

var productSearchResultsTable;
function configureSearchDataTable() {
	productSearchResultsTable = $("#productSearchResultsTable").dataTable(
			{
				"bServerSide" : true,
				"sAjaxSource" : "productScrReportAjaxResult.form",
				"bProcessing" : false,
				"bSort": false,
				"sPaginationType" : "full_numbers",
				"oLanguage" : {
					"sEmptyTable" : "No data available",
					"sLengthMenu" : " _MENU_ items per page",
					"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
	                "sInfoEmpty": "No entries to show"
				},
				"sDom" : 'tlip',
				"aoColumns" : [ null,null, null, null, null,null,null,null,null,null, null, null, null, null,null,null,null,null,null, null, null, null, null,null,null,null,null,null,null,null,null,null,null,{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false } ],
				"fnRowCallback" : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
					 $(nRow).children("td").css("overflow", "hidden");
					 $(nRow).children("td").css("white-space", "nowrap");
					 $(nRow).children("td").css("text-overflow", "ellipsis");
					 var updateCodeTableAccess = $('#updateCodeTableAccess');        	
			        	if(updateCodeTableAccess != null){
			        		if($('#updateCodeTableAccess').val() == 'true'){
			        			setHyperLinkOnProductSearchColumns(nRow, aData);
			        		}
			        	}
					return nRow;
				}
			});
}
function setHyperLinkOnProductSearchColumns(nRow, aData){
	//$('td:eq(0)', nRow).html(getCodeColumnHtml(aData[0],aData[25],aData[26],aData[27],aData[28],aData[29],aData[30],aData[31],aData[32],aData[33],aData[34],aData[35]));
	//$('td:eq(0)', nRow).width("50%");
	$('td:eq(0)', nRow).html(getCodeColumnHtml(aData[0],aData[36]));
	$('td:eq(0)', nRow).css('text-align', 'center');
	$('td:eq(1)', nRow).width("50%");
	$('td:eq(1)', nRow).css('text-align', 'center');
	$('td:eq(2)', nRow).width("50%");
	$('td:eq(2)', nRow).css('text-align', 'center');
	$('td:eq(3)', nRow).width("50%");
	$('td:eq(3)', nRow).css('text-align', 'center');
	$('td:eq(4)', nRow).width("50%");
	$('td:eq(4)', nRow).css('text-align', 'center');
	$('td:eq(5)', nRow).width("50%");
	$('td:eq(5)', nRow).css('text-align', 'center');
	$('td:eq(6)', nRow).width("50%");
	$('td:eq(6)', nRow).css('text-align', 'center');
	$('td:eq(7)', nRow).width("50%");
	$('td:eq(7)', nRow).css('text-align', 'center');
	//$('td:eq(0)', nRow).width("50%");
	$('td:eq(8)', nRow).width("50%");
	$('td:eq(8)', nRow).css('text-align', 'center');
	$('td:eq(9)', nRow).width("50%");
	$('td:eq(9)', nRow).css('text-align', 'center');
	$('td:eq(10)', nRow).width("50%");
	$('td:eq(10)', nRow).css('text-align', 'center');
	$('td:eq(11)', nRow).width("50%");
	$('td:eq(11)', nRow).css('text-align', 'center');
	$('td:eq(12)', nRow).width("50%");
	$('td:eq(12)', nRow).css('text-align', 'center');
	$('td:eq(13)', nRow).width("50%");
	$('td:eq(13)', nRow).css('text-align', 'center');
	$('td:eq(14)', nRow).width("50%");
	$('td:eq(14)', nRow).css('text-align', 'center');
	$('td:eq(15)', nRow).width("50%");
	$('td:eq(15)', nRow).css('text-align', 'center');
	$('td:eq(16)', nRow).width("50%");
	$('td:eq(16)', nRow).css('text-align', 'center');
	$('td:eq(17)', nRow).width("50%");
	$('td:eq(17)', nRow).css('text-align', 'center');
	$('td:eq(18)', nRow).width("50%");
	$('td:eq(18)', nRow).css('text-align', 'center');
	$('td:eq(19)', nRow).width("50%");
	$('td:eq(19)', nRow).css('text-align', 'center');
	$('td:eq(20)', nRow).width("50%");
	$('td:eq(20)', nRow).css('text-align', 'center');
	$('td:eq(21)', nRow).width("50%");
	$('td:eq(21)', nRow).css('text-align', 'center');
	$('td:eq(22)', nRow).width("50%");
	$('td:eq(22)', nRow).css('text-align', 'center');
	$('td:eq(23)', nRow).width("50%");
	$('td:eq(23)', nRow).css('text-align', 'center');
	$('td:eq(24)', nRow).width("50%");
	$('td:eq(24)', nRow).css('text-align', 'center');
	$('td:eq(25)', nRow).width("50%");
	$('td:eq(25)', nRow).css('text-align', 'center');
	$('td:eq(26)', nRow).width("50%");
	$('td:eq(26)', nRow).css('text-align', 'center');
	$('td:eq(27)', nRow).width("50%");
	$('td:eq(27)', nRow).css('text-align', 'center');
	$('td:eq(28)', nRow).width("50%");
	$('td:eq(28)', nRow).css('text-align', 'center');
	$('td:eq(29)', nRow).width("50%");
	$('td:eq(29)', nRow).css('text-align', 'center');
	$('td:eq(30)', nRow).width("50%");
	$('td:eq(30)', nRow).css('text-align', 'center');
	$('td:eq(31)', nRow).width("50%");
	$('td:eq(31)', nRow).css('text-align', 'center');
	$('td:eq(32)', nRow).width("50%");
	$('td:eq(32)', nRow).css('text-align', 'center');
}

function getCodeColumnHtml(value1,value2){
	return "<a href='editProductScrMapping.form?rescMapId=" + value2 + "'>" + value1 + "</a>";
}
function selectoneMktCodeList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallMktCodeList(ref) {
	if (ref.checked == false) {
		$("#allmktCode").prop("checked", false);
	}
}
function selectallMktCodeList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			this.checked = false;
		});
	}
}

function selectoneproductList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=productList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallproductList(ref) {
	if (ref.checked == false) {
		$("#allproduct").prop("checked", false);
	}
}
function selectallproductList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=productList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=productList]').each(function() {
			this.checked = false;
		});
	}
}

function selectoneresourceList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=resourceList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallresourceList(ref) {
	if (ref.checked == false) {
		$("#allresource").prop("checked", false);
	}
}
function selectallresourceList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=resourceList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=resourceList]').each(function() {
			this.checked = false;
		});
	}
}
function selectoneMktCodeScrList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=marketCodeScrList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallMktCodeScrList(ref) {
	if (ref.checked == false) {
		$("#allmktCodeScr").prop("checked", false);
	}
}
function selectallMktCodeScrList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=marketCodeScrList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=marketCodeScrList]').each(function() {
			this.checked = false;
		});
	}
}

function selectoneSrTypCdList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=scrTypCdList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallSrTypCdList(ref) {
	if (ref.checked == false) {
		$("#allSrTypCd").prop("checked", false);
	}
}
function selectallSrTypCdList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=scrTypCdList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=scrTypCdList]').each(function() {
			this.checked = false;
		});
	}
}

function selectoneSrGruCdList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=scrGruCdList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallSrGruCdList(ref) {
	if (ref.checked == false) {
		$("#allSrGruCd").prop("checked", false);
	}
}
function selectallSrGruCdList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=scrGruCdList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=scrGruCdList]').each(function() {
			this.checked = false;
		});
	}
}