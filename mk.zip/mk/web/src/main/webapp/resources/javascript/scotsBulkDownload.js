/*This file serves scotsBulkDownload.jsp*/
$(document).ready(function() {
	$(document).ready(function() {
		bindScotsBulkDownload();

	});
});

function bindScotsBulkDownload() {
	//	$('#scotsBulkDownloadLink').bind('click',function(event){
	//		event.preventDefault();
	//		location.href = "scotsBulkDownload.form";
	//		return false;
	//	});
}

function selectallcodetableattr(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=ctable]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=ctable]').each(function() {
			this.checked = false;
		});
	}
}

function selectonecodetableattr(ref) {

	if (!$(ref).is(":checked")) {
		$('#allctable').attr('checked', false);
	}
}

function checkscotsfileType() {
	if ($("#scotsDomain").val() == 'Code Table') {
		$("#codetableRow,#languageRow").css("display", "none");
	} else if ($("#scotsDomain").val() == 'Code Value') {
		$('#ctableRow').css('display', 'none');
		$("#codetableRow,#languageRow").css("display", "block");
	}
}

function validatescotsdownload() {
	if ($("#scotsDomain").val() == "") {
		alert("Please select a file type")
	}
	if ($("#scotsDomain").val() == 'Code Table') {
		$('#confirmMessageSelction').css('display', 'inline');
		$('#scotsBulkDownload').submit();

	}
	if ($("#scotsDomain").val() == 'Code Value') {

		if ($('input[type=checkbox][name=codeTableList]:checked').length > 0) {

			if ($('input[type=checkbox][name=languageList]:checked').length > 0) {

				$('#confirmMessageSelction').css('display', 'inline');
				$('#scotsBulkDownload').submit();
			} else {
				alert("Please select atleast one Language");
			}

		} else {
			alert("Please select Code Table Values");
		}

	}
}

function selectallcodeTableList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=codeTableList]').each(function() {
			$("#lhead,#lcontent").css("display", "block");
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=codeTableList]').each(function() {
			$("#lhead,#lcontent").css("display", "none");
			this.checked = false;
		});
	}
}

function uncheckallcodeTableList(ref) {
	if (ref.checked == false) {
		$("#allcodetables").prop("checked", false);
	}
}

function selectonecodeTableList(ref) {
	var flag = false;
	if (ref == true) {
		$("#lhead,#lcontent").css("display", "block");
	} else {
		$('input[type=checkbox][name=codeTableList]').each(function() {
			if (this.checked == true)
				flag = true;
		});
		if (flag == false)
			$("#lhead,#lcontent").css('display', 'none');
	}
}

function selectallcodelangcheckboxes(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=languageList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=languageList]').each(function() {
			this.checked = false;
		});
	}
}

function selectonecodelangcheckbox(ref) {

	if (!$(ref).is(":checked")) {
		$('#codelanguage').attr('checked', false);
	}
}
