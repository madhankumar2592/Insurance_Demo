$(document).ready(function(){
	if($("#successMsg").val()){
		alert("Score-Market-Granularity mapping is added in Reference Data SOR successfully");
	}	
	 $.ajaxSetup({ cache: false });	
	initializeScoreGranularityElements();	
	$('#scoreVersion').bind('change',function(){
		if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();
		$( "#scoregran" ).prop( "disabled", true );
		$('#granularityDiv').css("display","none");
		$('tr.detailRowGran').not(':first').remove(); 
		$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
		populateGranularity($(this).val(), $('#scoregran'), false,$('#scoreTyp').val(),$('#scoreMarketCodes').val());
			}
				
		});
});

	

function initializeScoreGranularityElements(){
//	$('#indsCodeAddLink').bind('click',function(event) {
//		event.preventDefault();
//		location.href = "indsCodeAdd.form";
//		return false; // to prevent event bubbling
//	});
	var flag = false;
	$('#scoreTyp').bind('change',function(){
	if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();
		$( "#scoreVersion" ).prop( "disabled", true );
		$( "#scoregran" ).prop( "disabled", true );
		$( "#scoreMarketCodes" ).prop( "disabled", true );
		$('#granularityDiv').css("display","none");
		$('tr.detailRowGran').not(':first').remove(); 
		$('#scoregran').val( $('#scoregran').prop('defaultSelected') );

		populateMarketCode($(this).val(), $('#scoreMarketCodes'), false);
		}
			
	});
	
	$('#scoreMarketCodes').bind('change',function(){
	if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();
		$( "#scoreVersion" ).prop( "disabled", true );
		$( "#scoregran" ).prop( "disabled", true );		
		$('#granularityDiv').css("display","none");
		$('tr.detailRowGran').not(':first').remove(); 
		$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
		flag = false;
		populateVersion($(this).val(), $('#scoreVersion'), false,$('#scoreTyp').val());		}
			
	});
	$(document).ajaxComplete(function() {
		if(!(flag) ) {
			if($.trim($('#scoreVersion').val()) != '') {
			$('#errorMsg').hide();
			$( "#scoregran" ).prop( "disabled", true );
			$('#granularityDiv').css("display","none");
			$('tr.detailRowGran').not(':first').remove(); 
			$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
			flag = true;
			populateGranularity($('#scoreVersion').val(), $('#scoregran'), false,$('#scoreTyp').val(),$('#scoreMarketCodes').val());
			}				
		}
});
	$('#scoreVersion').bind('change',function(){
//	if ($("#EventStartTimeMin").val() === "") {
		if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();
		$( "#scoregran" ).prop( "disabled", true );
		$('#granularityDiv').css("display","none");
		$('tr.detailRowGran').not(':first').remove(); 
		$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
		populateGranularity($(this).val(), $('#scoregran'), false,$('#scoreTyp').val(),$('#scoreMarketCodes').val());
			}
				
		});
	
	/*$('#scoreGranularitySaveButton').bind('click', function(){
		$('#scoreGranularityForm').submit();
		return false;
	});
	
	$('#scoreGranularityResetButton').bind('click', function(){
		location.href = "scoreGranularityMapping.form";
		return false;
	});
	
	$('#scoreGranularityCancelButton').bind('click', function(){
		location.href = "scoreGranularityMapping.form";
		return false;
	});*/
	
	$('#scoreDtlSaveButton').bind('click', function(){
		var granValTblLength = $('#scoreGranularityTable tr:visible').length;
	if($('#scoreTyp').val()== '') {
			$('#errorMsg').text("Please select Score Type Code");
			$('#errorMsg').css("display","block");
		}else if ($('#scoreMarketCodes').val()== '') {
			$('#errorMsg').text("Please select Market Type Code");
			$('#errorMsg').css("display","block");
		}else if ($('#scoreVersion').val()== '') {
			$('#errorMsg').text("Please select Score Version");
			$('#errorMsg').css("display","block");
		}else if (granValTblLength == 0) {
			$('#errorMsg').text("No granularity is mapped to the selected score type and market");
			$('#errorMsg').css("display","block");
		}else if(isDropDownEmpty($('.scoreGraCode'))) {
			$('#errorMsg').text("Please select Score Granularity");
			$('#errorMsg').css("display","block");							
		} 
		else {
			
				var scrTypText = $('#scoreTyp :selected').text();
				var mktCdText = $('#scoreMarketCodes :selected').text();
				var versionText = $('#scoreVersion :selected').text();
					var granVal = new Array();
					$('.scoreGraCode :selected').each(function() 
					{	
						
						granVal.push($(this).text());
						
					});
						if(isDuplicateGran(granVal)){
							alert("Please select unique Granularity values");
						}else{
						
						var retVal = confirm("Are you sure you want to map "+scrTypText+" to "+mktCdText+" with Version "+versionText+" , to the Granularities "+granVal+"?");
						if( retVal == true ){
							$('#scoreDtlForm').submit();
						  return true;
						}else{
						  return false;
						}
					}

		}
	});
	
	$('#scoreDtlResetButton').bind('click', function(){
		location.href = "scoreDetailsMap.form";
		return false;
	});
	
	$('#scoreDtlCancelButton').bind('click', function(){
		location.href = "scoreDetailsMap.form";
		return false;
	});
	

}
function populateMarketCode(scoreTyp, marketObj, hasGrpLvlFilter) {
	var groupLevelCode = '';
	var hasEnglish=false;
	
	if(hasGrpLvlFilter) {
		groupLevelCode = getGroupLevelSearchCodes();
	}
	$.getJSON('retrieveMarketCodesForScrType.form', {
		scoreType : scoreTyp,
		ajax : 'true'
	}, function(data) {
		marketObj.empty();
		$("#scoreMarketCodes").append('<option value="">--  Select Market Type Code  --</option>'); 
		$.each(data, function() {
			marketObj.append('<option value="' + this.code + '">' + " [" + this.code + "] " + this.value +  '</option>');
			marketObj.removeAttr('disabled');
			if(this.code==39){
				hasEnglish= true;
			}
		 }); 
		
		if(hasEnglish) {
			langObj.val(39);
		}
	});
}
function populateVersion(scoreMkt, scrVerObj, hasGrpLvlFilter,scoreTyp) {
	var groupLevelCode = '';
	var hasEnglish=false;
	if(hasGrpLvlFilter) {
		groupLevelCode = getGroupLevelSearchCodes();
	}
	$.getJSON('retrieveVersionForScrMktAndType.form', {
		scoreMkt : scoreMkt,
		scoreType : scoreTyp,
		ajax : 'true'
	}, function(data) {
		scrVerObj.empty();
		//$("#scoreVersion").append('<option value="">--  Select Version  --</option>'); 
		$.each(data, function() {
			scrVerObj.append('<option value="' + this.scoreVersion + '">' + this.scoreVersion +'</option>');
			scrVerObj.removeAttr('disabled');
			if(this.code==39){
				hasEnglish= true;
			}
		 }); 
		$( "#scoregran" ).prop( "disabled", true );
		if(hasEnglish) {
			scrVerObj.val(39);
		}
	});
	
}
function populateGranularity(scoreVer, scrGranObj, hasGrpLvlFilter,scoreTyp,scoreMkt) {
	var groupLevelCode = '';
	var hasEnglish=false;
	if(hasGrpLvlFilter) {
		groupLevelCode = getGroupLevelSearchCodes();
	}
	$.getJSON('retrieveGranularityForScrType.form', {
		scoreVer : scoreVer,
		scoreType : scoreTyp,
		scoreMkt : scoreMkt,
		ajax : 'true'		
	}, function(data) {
		scrGranObj.empty();
		$("#scoregran").append('<option value="">--  Select Granularity  --</option>'); 
		$.each(data, function() {
			scrGranObj.append('<option value="' + this.codeValueId + '">' + " [" + this.codeValueId + "] " + this.codeValueDescription +  '</option>');
			scrGranObj.removeAttr('disabled');
			$('#granularityDiv').css("display","block");
			if(this.code==39){
				hasEnglish= true;
			}
		 }); 
		if(hasEnglish) {
			scrGranObj.val(39);
		}
	});
}


function addGranularityRow(){
	var nextIndex = $(".scoreGraCode").length;
	//alert(nextIndex);
	//scoreGranularity
	var max = null;
	$( "input[name^='scoreGranularity']" ).each(function() {
		var name =this.name.match(/\d+/);	
		//alert(name);		
		if (max === null || Number(name) > Number(max)){
			max = name;
			//max = Number(max)+1;
			}
	});
	//alert(max);
	nextIndex = Number(max)+1;
	//alert(nextIndex);
	$('#scoreGranularityTable').append($('#scoreGranularityTable tr:last').clone());
	var newlyAddedGranularityRow = $('#scoreGranularityTable tr:last');
	updateNamesOfNewRow(newlyAddedGranularityRow , '.scoreGraCode', nextIndex, 'scoreGranularity', 'scoreGraCode', "true");
	updateNamesOfNewRow(newlyAddedGranularityRow , '.changeIndicator', nextIndex, 'scoreGranularity', 'changeIndicator', "true");
	updateNamesOfNewRow(newlyAddedGranularityRow , '.scoreGraId', nextIndex, 'scoreGranularity', 'scoreGraId', "true");

	$('#scoreGranularityTable').find('tr:last').find('.removeScoreGranularityRowLink').
	html('<a href="javascript:;" style="text-decoration: none;" onclick="removeGranularityRow(this,' + nextIndex + ');">[-]</a>');
	newlyAddedGranularityRow.find('.changeIndicator').val('NEW');

	newlyAddedGranularityRow.show();
	return false;

}

function removeGranularityRow(removeHandle, rowIndexToDelete){
	if($('.scoreGraCode:visible').length ==1){
		alert("At least one Description is mandatory");
		return false;
	}
	 if($(removeHandle).closest('tr').find('.changeIndicator').val()=='NEW') {
		$(removeHandle).closest('tr').remove();
	}
	//alert(rowIndexToDelete);
	//alert(this.rowIndex);
	$('#scoreGranularityTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.scoreGraCode'), (this.rowIndex - 1), 'scoreGranularity', 'scoreGraCode');
			updateNames($(this).find('.changeIndicator'), (this.rowIndex - 1), 'scoreGranularity', 'changeIndicator');
			updateNames($(this).find('.scoreGraId'), (this.rowIndex - 1), 'scoreGranularity', 'scoreGraId');

			$(this).find('.removeScoreGranularityRowLink').html($(this).find('.removeScoreGranularityRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}



function isDuplicateGran(granVal)
{	
	var flag = false;
	var sorted_arr = new Array();	
	sorted_arr = granVal.sort();  
	
	for (var i = 0; i < granVal.length - 1; i++) {  
           if (sorted_arr[i + 1] == sorted_arr[i]) {  
            flag = true;
         }
	} 		
		return flag;
	
}

function isDropDownEmpty(dropDownName) {
	var returnType = false;
	dropDownName.each(function(){
		if(!($(this).is(':disabled'))){
			if($(this).val() == ''|| $(this).val() == null){
				$(this).focus();
				returnType =true;
				return true;
			}
		}
	});
	return returnType;
	}
