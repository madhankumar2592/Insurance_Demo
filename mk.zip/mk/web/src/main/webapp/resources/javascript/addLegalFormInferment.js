/**
 * This JS file serves addLegalFormInferment.jsp
 */

$(document).ready(function(){
	bindAddLegalFormInfermentEvents();
	
});

function bindAddLegalFormInfermentEvents(){
	initializeAddLegalFormDatepicker();
//	$('#addLegalFormInfermentLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "addLegalFormInferment.form";
//		return false; // to prevent event bubbling
//	});
	$('#addLegalFormInfermentResetButton').bind('click',function(event){
		event.preventDefault();
		$(".reset").val("");
		$(".effectiveDate").val(getToday());
		$(":checkbox").removeAttr("checked");
		return false; // to prevent event bubbling
	});
	$('#addLegalFormInfermentCancelButton').bind('click',function(event){
		event.preventDefault();
		location.href = "legalFormInferment.form";
		return false; // to prevent event bubbling
	});
	$("#addLegalFormInfermentSubmitButton").click(function() {
		if(isValidLegalForm()) {
			$("#errorMsg").hide();
			$(".btn").attr("disabled");
			$("#addlegalFormInfermentForm").submit();
		}
	});
	$("#addLegalLanguageToggle").bind('click', function() {
		toggleAddLegalLanguageList();
		return false;
	});
}
function initializeAddLegalFormDatepicker(){
	if($("#location").val()== "addLegalForm") {
		$('.geoDatepickerTextBox').datepicker('enable'); 
	}
}
function isValidLegalForm() {
	if(!$("#infermentText").val()) {
		$("#errorMsg").html("Please Enter Inferment Text");
		$("#errorMsg").show();
		$("#infermentText").focus();
		return false;
	}
	if ($("#addLegalFormLanguageSelect").val()=="") {
		$("#errorMsg").html("Please Select Language Code");
		$("#errorMsg").show();
		$("#addLegalFormLanguageSelect").focus();
		return false;
	}
	var checked = 0;
	$(".legal_countries").each(function(){
		if($(this).attr("checked")) {
			checked = 1;
		}
	});
	if(checked==0) {
		$("#errorMsg").html("Please Select Country Applicability");
		$("#errorMsg").show();
		$("#allCountries").focus();
		return false;
	}
	var selected=1;

	$(".legalFormCode").each(function(){
		if($(this).val()==''){
			$("#errorMsg").html('Please select Legal Form Code');
			$("#errorMsg").show();
			selected=0;
			$(this).focus();
			//return false;
		}
	});
	$(".legalFormClassCode").each(function(){
		if($(this).val()==''){
			$("#errorMsg").html('Please select Legal Form Class Code');
			$("#errorMsg").show();
			selected=0;
			$(this).focus();
			//return false;
		}
	});

	if(isDuplicateLegalCodes()) {
		selected = 0;
		return false;
	} 
	else if (selected==1) {
		return true;
	} else {
		return false;
	}
	
}

var addLegalLanguageToggleindc = true;
function toggleAddLegalLanguageList() {
	$.getJSON('toggleAddLegalFormLanguages.form', {
		addLegalLanguageToggleindc : addLegalLanguageToggleindc,
		ajax : 'true'
	}, function(data) {
		$("#addLegalFormLanguageSelect").empty();
		$("#addLegalFormLanguageSelect").append(
				'<option value=""> -- Select Language-- </option>');
		if (addLegalLanguageToggleindc) {
			$.each(data, function() {
				$("#addLegalFormLanguageSelect").append(
						'<option value="' + this.codeValueId + '">' + this.codeValueDescription
								+ ' [ ' + this.codeValueId + ' ] ' + '</option>');
			});
		} else {
			$.each(data, function() {
				$("#addLegalFormLanguageSelect").append(
						'<option value="' + this.codeValueId + '">' + this.codeValueId
								+ ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
			});
		}
		addLegalLanguageToggleindc = !addLegalLanguageToggleindc;
	});
}
