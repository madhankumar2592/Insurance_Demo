/**
 * This file serves addGeoUnit.jsp
 * addGeoUnit.jsp uses many functions defined in geoUnitView.js also. 
 */
$(document).ready(function(){
	bindAddGeoUnitEvents();
	initializeAddGeoUnitElements();
});

var hierData;
function bindAddGeoUnitEvents(){
//	$('#geoAddLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "loadAddGeoUnit.form";
//		return false; // to prevent event bubbling
//	});
	
	$('#saveAddGeoUnitBtn').bind('click',function(){
		if(isValidEntry()){
			$('#addGeoUnitForm').submit();
		}
		return false; // to prevent event bubbling
	});
	
	$('#cancelAddGeoUnitBtn').bind('click',function(){
		showSpinner();
		location.href = "loadAddGeoUnit.form";
		return false; // to prevent event bubbling
	});
	
	$('#geoUnitTypeCode').bind('change',function(event){
		populateParentDropDowns();
		$('#saveAddGeoUnitBtn').show();
	});
	
	bindAddGeoUnitChildCountry();
	bindAddGeoUnitChildTerritory();
	
	 $("#addGeoParentCountry").bind('change',function(event){

		 var ctryGeoUnitId = $("#addGeoParentCountry").val();
		 // retrieve all country hierarchies when the user selects value in the country drop down
		 $.getJSON('retrieveGeoHierarchiesForCountry.form', {
			 	countryGeoUnitId : ctryGeoUnitId
			}, function(data) {	
				hierData = data;
				$.each(data, function(index, value){					
					if(index == "Territory") {
						if(value != null) {
							$('#territoryRow').show();
							if($('#addGeoParentTerritory').is(":visible")){
								disableChildSelectBoxes($('#countryRow'));
								populateChildSelectBox(ctryGeoUnitId, "5392",  $('#addGeoParentTerritory'), ctryGeoUnitId);
							}
							if($('.addGeoUnitChildTerritory').is(":visible")){
								populateChildSelectBox(ctryGeoUnitId, "5392",  $('.addGeoUnitChildTerritory'), ctryGeoUnitId);
							}
							$('#territoryRow td').eq(0).html('<strong><span class="mandatoryFields">*</span>&nbsp;' + value.split('~')[1] + ':</strong>');
						} else {
							$('#territoryRow').hide();
						}
					}
					else if(index == "County") {
						if(value != null) {
							$('#countyRow').show();
							$('#countyRow td').eq(0).html('<strong><span class="mandatoryFields">*</span>&nbsp;' + value.split('~')[1] + ':</strong>');
							if(!$('#territoryRow').is(':visible')) {
								disableChildSelectBoxes($('#territoryRow'));
								populateChildSelectBox($("#addGeoParentCountry").val(), "5153",  $('#addGeoParentCounty'), $("#addGeoParentCountry").val());						 								
							}
						} else {
							$('#countyRow').hide();
						}
					}
					else if(index == "PostTown") {
						if(value != null) {
							$('#ptownRow').show();
							$('#ptownRow td').eq(0).html('<strong><span class="mandatoryFields">*</span>&nbsp;' + value.split('~')[1] + ':</strong>');
							if(!$('#countyRow').is(':visible')) {
								var parentId = $("#addGeoParentCountry").val();
								if($('#territoryRow').is(':visible')) {
									parentId = $("#addGeoParentTerritory").val();
								}
								disableChildSelectBoxes($('#countyRow'));
								if(parentId != '' && parentId != null) {
									populateChildSelectBox(parentId, "126",  $('#addGeoParentPostalTown'), $("#addGeoParentCountry").val());
								}
							}
						} else {
							$('#ptownRow').hide();
						}
					}
				});
				
				hideParentsBasedOnType();
			});	
	 });
	 
	 $("#addGeoParentTerritory").bind('change',function(event){
		 $.each(hierData, function(index, value){
			 if(index == "County" && $('#addGeoParentCounty').is(":visible")) {
				if(value != null) {
					$('#countyRow').show();						 
					disableChildSelectBoxes($('#territoryRow'));
					populateChildSelectBox($("#addGeoParentTerritory").val(), "5153",  $('#addGeoParentCounty'), $("#addGeoParentCountry").val());						 
					$('#countyRow td').eq(0).html('<strong><span class="mandatoryFields">*</span>&nbsp;' + value.split('~')[1] + ':</strong>');
				} else {
					$('#countyRow').hide();
				}
			}
			if(index == "PostTown" && $('#addGeoParentPostalTown').is(":visible")) {
				if(value != null) {
					$('#ptownRow').show();
					if(!$('#countyRow').is(':visible')) {
						disableChildSelectBoxes($('#countyRow'));
						populateChildSelectBox($("#addGeoParentTerritory").val(), "126",  $('#addGeoParentPostalTown'), $("#addGeoParentCountry").val());
					}
					$('#ptownRow td').eq(0).html('<strong><span class="mandatoryFields">*</span>&nbsp;' + value.split('~')[1] + ':</strong>');
				} else {
					$('#ptownRow').hide();
				}
			}
		 });
	 });
	 
	 $("#addGeoParentCounty").bind('change',function(event){
		 disableChildSelectBoxes($('#countyRow'));
		 populateChildSelectBox($(this).val(), "126",  $('#addGeoParentPostalTown'), $("#addGeoParentCountry").val());
	 });
	
	 $("#addGeoUnitTerritory").bind('change',function(event){
		 populateChildSelectBox($(this).val(), "5153",  $('#addGeoUnitCounty'), $("#addGeoParentCountry").val());
	 });
	 
	 bindAddGeoUnitSelectElements();
}

function bindAddGeoUnitSelectElements(){
	 $('select').on('change',function(){
		 enableChildSections();
		 disableCountryIfMSA();
	 });
}

function disableCountryIfMSA(){
	var geoUnitTypeCode = $.trim($('#geoUnitTypeCode').val());
	if(geoUnitTypeCode == "1333" ||
		geoUnitTypeCode == "1444" ||
		geoUnitTypeCode == "24458" ||
		geoUnitTypeCode == "24457"){
		if(!($('#addGeoParentCountry').is(':disabled'))){
			$('#addGeoParentCountry').attr('disabled', true);
		}
	}
}

function bindAddGeoUnitChildCountry(){
	$('.addGeoUnitChildCountry').on('change',function(){
		$(this).closest('tr').find('.addGeoUnitCountryGeoRefId').text($(this).val());
	});
}

function bindAddGeoUnitChildTerritory(){
	$('.addGeoUnitChildTerritory').on('change',function(){
		populateChildSelectBox($(this).val(), "5153",  $(this).closest('tr').find('.addGeoUnitChildCounty'), $("#addGeoParentCountry").val());
	});
}

function isValidEntry(){
	if(isAddGeoUnitEmpty()){
		return false;
	}
	
	if(isGeoNameDuplicate()){
		return false;
	}
	
	if(isOfficialSelected()){
		return false;
	}
	
	if(isGeoCodeDuplicate()){
		return false;
	}
	
	springifyParentChildAssociations();
	$('#saveAddGeoUnitBtn').attr("disabled",true);
	return true;
}

function isGeoCodeDuplicate(){
	var selectedGeoCodes = [];
	$("#geoCodeTable tr").each(function(){
		if($(this).find('.geoCodeTypeCode option:selected').length){
			if(($(this).find('.expiredByDate').val() == '')||($(this).find('.expiredByDate').val() == null)){
				selectedGeoCodes.push($(this).find('.geoCodeTypeCode option:selected').val());
			}
		}
	});
	
	var sortedGeoCodes = selectedGeoCodes.sort();
	for (var i = 0; i < sortedGeoCodes.length - 1; i++) {
		if (sortedGeoCodes[i + 1] == sortedGeoCodes[i]) {
			alert('Geographic code types should be unique');
			return true;
		}
	} 	
}
function isOfficialSelected(){
	officialFlag=false;
	$("#geoNameTable tr").each(function(){
		if($(this).find('.nameTypeCode option:selected').length){
			if($(this).find('.nameTypeCode option:selected').val()==32) {
				officialFlag=true;
			}
		}
	});
	if(!officialFlag) {
		alert("Please enter at least one Official Name Type");
		return true;
	}
	return false;
}	

function isGeoNameDuplicate(){
	var selectedNames = [];
	$("#geoNameTable tr").each(function(){
		if($(this).find('.nameTypeCode option:selected').length && ($(this).find('.nameTypeCode').val() != '7790')){
			if(($(this).find('.expiredByDate').val() == '')||($(this).find('.expiredByDate').val() == null)){
				selectedNames.push($(this).find('.nameTypeCode option:selected').val());
			}
		}
	});
	
	var selectedLanguages = [];
	$("#geoNameTable tr").each(function(){
		if($(this).find('.languageCode option:selected').length && ($(this).find('.nameTypeCode').val() != '7790')){
			if(($(this).find('.expiredByDate').val() == '')||($(this).find('.expiredByDate').val() == null)){
				selectedLanguages.push($(this).find('.languageCode option:selected').val());
			}
		}
		
	});
	
	var currentName = 0;
	var currentLanguage = 0;
	for(var i = 0; i < selectedNames.length; i++){
		currentName = selectedNames[i];
		currentLanguage = selectedLanguages[i];
		for(var j = i+1; j < selectedNames.length; j++){
			if(selectedNames[j] == currentName && selectedLanguages[j] == currentLanguage){
				alert('Geographic Name Type and Language combination should be unique');
				return true;
			}
		}
	}
}

function isAddGeoUnitEmpty(){
	
	var returnType = isParentEmpty();
	if(!returnType){
		returnType = isChildEmpty();
	}
	if(!returnType){
		returnType = isEmptyInTable('geoNameTable', 'Geographic Unit Name');
	}
	/*if(!returnType){
		returnType = isEmptyInTable('geoCodeTable', 'Geographic Unit Code');
	}*/
	return returnType;
}

function isParentEmpty(){
	var parentEmpty = !isAllElementsSelected($('#geoSearch select:visible'));
	if(parentEmpty){
		alert('Please enter all required fields in Geo Unit Type and Parent Relationship section');
	}
	return parentEmpty;
}

function isChildEmpty(){
	var childEmpty;
	if($('#outerChildDivBox1').is(":visible")){
		childEmpty = !isAllElementsSelected($('#outerChildDivBox1 select:visible'));
	}else if($('#outerChildDivBox2').is(":visible")){
		childEmpty = !isAllElementsSelected($('#outerChildDivBox2 select:visible'));
	}
	if(childEmpty){
		alert('Please enter all required fields in child section');
	}
	return childEmpty;
}

function populateParentDropDowns() {
	var geoUnitTypeCode = $("#geoUnitTypeCode").val();

	$('#errorField').hide();
	$('#statusBox').show();

	if (geoUnitTypeCode == "128") { // for Country
		$('#parentrel, #continentRow, #outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox').show();
		$('#countryRow, #territoryRow, #countyRow, #ptownRow, #outerChildDivBox2, #outerChildDivBox1')
				.hide();
		populateContinentList($("#addGeoParentContinent"));
	
	} else if (geoUnitTypeCode == "5392") { // for Territory
		$('#parentrel, #countryRow, #outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox').show();
		$('#continentRow, #territoryRow, #countyRow, #ptownRow, #outerChildDivBox2, #outerChildDivBox1')
				.hide();
		populateCountryList($("#addGeoParentCountry"));
		
	} else if (geoUnitTypeCode == "5153") { // for County
		$('#parentrel, #countryRow, #territoryRow, #outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox').show();
		$('#continentRow, #countyRow, #ptownRow, #outerChildDivBox2, #outerChildDivBox1')
				.hide();
		disableChildSelectBoxes($('#countryRow'));
		populateCountryList($("#addGeoParentCountry"));
		
	} else if (geoUnitTypeCode == "126") { // for Postal Town
		$('#parentrel, #countryRow, #territoryRow, #countyRow, #outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox')
				.show();
		$('#continentRow, #ptownRow, #outerChildDivBox2, #outerChildDivBox1')
				.hide();
		disableChildSelectBoxes($('#countryRow'));
		populateCountryList($("#addGeoParentCountry"));
		
	} else if (geoUnitTypeCode == "324" || geoUnitTypeCode == "1666") { // for Postal Code or Post Code Prefix Group
		$('#parentrel, #countryRow, #territoryRow, #countyRow, #ptownRow, #outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox')
				.show();
		$('#continentRow, #outerChildDivBox2, #outerChildDivBox1')
				.hide();
		disableChildSelectBoxes($('#countryRow'));
		populateCountryList($("#addGeoParentCountry"));

	} else if (geoUnitTypeCode == "1333"
			|| geoUnitTypeCode == "1444" || geoUnitTypeCode == "24458"
			|| geoUnitTypeCode == "24457") { // for Standard Metropolitan Statistical Area (USA) or
							   // Metropolitan Statistical Area (USA) or CBSA Micro or CBSA Metro
		$('#parentrel,#countryRow').show();
		$('#outerChildDivBox1, #outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox').show();
		$('#continentRow, #territoryRow, #ptownRow, #countyRow, #outerChildDivBox2')
				.hide();
		populateUSTerritories();
		organizeDatePickers($('#addGeoUnitTerritoryTable'), $('#addGeoUnitCountryTable'));
		
	} else if (geoUnitTypeCode == "129" || geoUnitTypeCode == "130"
			|| geoUnitTypeCode == "2002"
			|| geoUnitTypeCode == "14000") { // for Continent or Country Group
																 // WorldBase Country Grouping
																 // for D&B Worldwide Network Geographic Market
		$('#outerChildDivBox2, #outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox').show();
		$('#parentrel, #continentRow, #countryRow, #territoryRow, #ptownRow, #countyRow, #outerChildDivBox1')
				.hide();
		populateCountryList($(".addGeoUnitChildCountry"));
		organizeDatePickers($('#addGeoUnitCountryTable'), $('#addGeoUnitTerritoryTable'));
		
	} else if(geoUnitTypeCode == "329") { // for D&B Region/System
		$('#outerNameDivBox, #outerStatusDivBox').show();
		$('#parentrel, #continentRow, #countryRow, #territoryRow, #ptownRow, #countyRow, #outerChildDivBox1, #outerChildDivBox2, #outerCodeDivBox').hide();
	
	} else {
		$('#outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox').show();
		$('#parentrel, #continentRow, #countryRow, #territoryRow, #countyRow, #ptownRow, #outerChildDivBox1, #outerChildDivBox2')
				.hide();
	}
}

function disableChildSelectBoxes(rowHandle){
	rowHandle.closest('tr').nextAll().find('select').val("");
	rowHandle.closest('tr').nextAll().find('select').attr('disabled', true);
}

function organizeDatePickers(enabledTable, disabledTable){
	enabledTable.find('.geoDatepickerTextBox').each(function(){
		$(this).removeAttr('id');
	});
	disabledTable.find('.geoDatepickerTextBox').each(function(){
		$(this).removeAttr('id');
	});
	disabledTable.find('.geoDatepickerTextBox').datepicker('destroy');
	enabledTable.find('.geoDatepickerTextBox').datepicker('destroy');

	enabledTable.find('.geoDatepickerTextBox').datepicker(getDatepickerOptions(false));
}

function populateUSTerritories(){
	populateCountryListWithUSSelected($("#addGeoParentCountry"));
}

function populateCountryList(countrySelectBox){
	countrySelectBox.attr('disabled', true);
	countrySelectBox.empty();
	$.getJSON('retrieveCountryList.form', 
		function(data) {
		countrySelectBox.append('<option value=""> -- Select Country -- </option>');
		 $.each(data, function() {
			  
		     if(this.code == '1073'){
		    	 var aboveCountyUSAccess = $('#aboveCountyUSAccess');
		    	 if(aboveCountyUSAccess !=null){
		    		 if($('#aboveCountyUSAccess').val()=='true'){
			 countrySelectBox.append('<option value="' + this.code + '">' + this.value + '</option>'); 
		    		 }
		    	 }		    	 
		     }else if(this.code =='1068' || this.code == '956'){
		    	 var aboveCountyUKAccess = $('#aboveCountyUKAccess');
		    	 if(aboveCountyUKAccess !=null){
		    		 if($('#aboveCountyUKAccess').val()=='true'){
		    			 countrySelectBox.append('<option value="' + this.code + '">' + this.value + '</option>');
		    		 }
		    	 }	 		    	 
		     }else if(this.code =='892'){
		    	 var aboveCountyCAAccess = $('#aboveCountyCAAccess');
		    	 if(aboveCountyCAAccess !=null){    		 
		    		 if($('#aboveCountyCAAccess').val()=='true'){
		    			 countrySelectBox.append('<option value="' + this.code + '">' + this.value + '</option>');
		    		 }
		    	 } 
		     }else{
		    	 var aboveCountyRowAccess = $('#aboveCountyRowAccess');
		    	 if(aboveCountyRowAccess !=null){
		    		 if($('#aboveCountyRowAccess').val()=='true'){
		    			 countrySelectBox.append('<option value="' + this.code + '">' + this.value + '</option>');
		    		 }
		    	 }		    	 
		     } 			 			  
		 }); 
		 countrySelectBox.attr('disabled', false);
	});
}

function populateCountryListWithUSSelected(countrySelectBox){
	countrySelectBox.attr('disabled', true);
	countrySelectBox.empty();
	$.getJSON('retrieveCountryList.form', 
		function(data) {
		countrySelectBox.append('<option value=""> --Select Country-- </option>');
		 $.each(data, function() {
			 countrySelectBox.append('<option value="' + this.code + '">' + this.value + '</option>'); 
		 }); 
		 countrySelectBox.val("1073");
		 enableChildSections();
		 countrySelectBox.attr('disabled', true);
		 populateChildSelectBox("1073", "5392", $('.addGeoUnitChildTerritory'), 1073 );
	});
}

function populateContinentList(continentSelectBox){
	continentSelectBox.attr('disabled', true);
	continentSelectBox.empty();
	$.getJSON('retrieveContinentList.form', 
		function(data) {
		continentSelectBox.append('<option value=""> --Select Continent-- </option>');
		 $.each(data, function() {
			 continentSelectBox.append('<option value="' + this.code + '">' + this.value + '</option>'); 
		 }); 
		 continentSelectBox.attr('disabled', false);
	});
}

function addGeoUnitCountryRow(){
	var nextIndex = $(".addGeoUnitChildCountry").length;
	$('#addGeoUnitCountryTable').append($('#addGeoUnitCountryTable tr:last').clone());
	var newlyAddedGeoCountryRow = $('#addGeoUnitCountryTable tr:last');
	updateNamesOfNewCountryRow(newlyAddedGeoCountryRow , '.addGeoUnitChildCountry', nextIndex, 'childGeoUnitAssociations', 'childGeoUnitId');
	bindAddGeoUnitChildCountry();
	bindAddGeoUnitSelectElements();
	updateNamesOfNewCountryRow(newlyAddedGeoCountryRow , '.addGeoUnitCountryEffectiveDate', nextIndex, 'childGeoUnitAssociations', 'effectiveDate');
	
	newlyAddedGeoCountryRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePicker(newlyAddedGeoCountryRow, '.addGeoUnitCountryEffectiveDate');
	
	newlyAddedGeoCountryRow.find('.removeAddGeoUnitCountryRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeGeoCountryRow(this,' + nextIndex + ');">[-]</a>');
	enableChildSections();
	return false;
}

function updateNamesOfNewCountryRow(newlyAddedRow , className, rowIndex, bindArrayName, bindFieldName){
	var currentElement = newlyAddedRow.find(className);
	updateCountryNames(currentElement, rowIndex, bindArrayName, bindFieldName);
}

function updateCountryNames(currentElement, rowIndex, bindArrayName, bindFieldName){
	currentElement.attr('name', bindArrayName + '[' + rowIndex + '].' + bindFieldName);
	currentElement.removeAttr('id');
}

function removeGeoCountryRow(removeHandle, rowIndexToDelete){
	$('#addGeoUnitCountryTable tr').eq(rowIndexToDelete + 1).find('.addGeoUnitCountryEffectiveDate').datepicker('destroy');
	
	$(removeHandle).closest('tr').remove();
	
	$('#addGeoUnitCountryTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateCountryNames($(this).find('.addGeoUnitChildCountry'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'childGeoUnitId');
			
			$(this).find('.addGeoUnitCountryEffectiveDate').datepicker('destroy');
			updateCountryNames($(this).find('.addGeoUnitCountryEffectiveDate'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'effectiveDate');
			$(this).find('.addGeoUnitCountryEffectiveDate').removeClass('hasDatepicker');
			$(this).find('.addGeoUnitCountryEffectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeAddGeoUnitCountryRowLink').html($(this).find('.removeAddGeoUnitCountryRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	enableChildSections();
	return false;
}

function addGeoUnitTerritoryRow(){
	var deleteMethodIndex = $(".addGeoUnitChildCounty").length;
	var territoryIndex = deleteMethodIndex * 2;
	var countyIndex = territoryIndex + 1;
	$('#addGeoUnitTerritoryTable').append($('#addGeoUnitTerritoryTable tr:last').clone());
	var newlyAddedGeoTerritoryRow = $('#addGeoUnitTerritoryTable tr:last');
	updateNamesOfNewRow(newlyAddedGeoTerritoryRow , '.addGeoUnitChildTerritory', territoryIndex, 'childGeoUnitAssociations', 'childGeoUnitId');
	bindAddGeoUnitChildTerritory();
	bindAddGeoUnitSelectElements();
	updateNamesOfNewRow(newlyAddedGeoTerritoryRow , '.addGeoUnitTerritoryEffectiveDate', territoryIndex, 'childGeoUnitAssociations', 'effectiveDate');
	updateNamesOfNewRow(newlyAddedGeoTerritoryRow , '.addGeoUnitChildCounty', countyIndex, 'childGeoUnitAssociations', 'childGeoUnitId');
	updateNamesOfNewRow(newlyAddedGeoTerritoryRow , '.addGeoUnitCountyEffectiveDate', countyIndex, 'childGeoUnitAssociations', 'effectiveDate');
	
	newlyAddedGeoTerritoryRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePicker(newlyAddedGeoTerritoryRow, '.addGeoUnitTerritoryEffectiveDate');
	
	newlyAddedGeoTerritoryRow.find('.removeAddGeoUnitTerritoryRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeGeoTerritoryRow(this,' + deleteMethodIndex + ');">[-]</a>');
	enableChildSections();
	return false;
}

function removeGeoTerritoryRow(removeHandle, territoryIndexToDelete){
	$('#addGeoUnitTerritoryTable tr').eq(territoryIndexToDelete + 1).find('.addGeoUnitTerritoryEffectiveDate').datepicker('destroy');
	
	$(removeHandle).closest('tr').remove();
	
	$('#addGeoUnitTerritoryTable tr').each(function() {
		if(this.rowIndex > territoryIndexToDelete){
			
			updateNames($(this).find('.addGeoUnitChildTerritory'), (this.rowIndex - 1)*2, 'childGeoUnitAssociations', 'childGeoUnitId');
			updateNames($(this).find('.addGeoUnitChildCounty'), ((this.rowIndex-1)*2) + 1, 'childGeoUnitAssociations', 'childGeoUnitId');
			$(this).find('.addGeoUnitTerritoryEffectiveDate').datepicker('destroy');
			updateNames($(this).find('.addGeoUnitTerritoryEffectiveDate'), (this.rowIndex - 1)*2, 'childGeoUnitAssociations', 'effectiveDate');
			updateNames($(this).find('.addGeoUnitCountyEffectiveDate'), ((this.rowIndex-1)*2) + 1, 'childGeoUnitAssociations', 'effectiveDate');
			$(this).find('.addGeoUnitTerritoryEffectiveDate').removeClass('hasDatepicker');
			$(this).find('.addGeoUnitTerritoryEffectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeAddGeoUnitTerritoryRowLink').html($(this).find('.removeAddGeoUnitTerritoryRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	enableChildSections();
	return false;
}

function springifyParentChildAssociations(){
	if(!$('.addGeoUnitChildTerritory').is(":visible")){
		$('#outerChildDivBox1').remove();
	}
	if(!$('.addGeoUnitChildCountry').is(":visible")){
		$('#outerChildDivBox2').remove();
	}
	var parentIndex = 0;
	if($('#continentRow').is(":visible")){
		$('#addGeoParentContinent').attr('name', 'parentGeoUnitAssociations['+ parentIndex  +'].parentGeoUnitId');
		parentIndex++;
	}else{
		$('#continentRow').remove();
	}
	if($('#countryRow').is(":visible")){
		$('#addGeoParentCountry').attr('name', 'parentGeoUnitAssociations['+ parentIndex  +'].parentGeoUnitId');
		parentIndex++;
	}else{
		$('#countryRow').remove();
	}
	if($('#territoryRow').is(":visible")){
		$('#addGeoParentTerritory').attr('name', 'parentGeoUnitAssociations['+ parentIndex  +'].parentGeoUnitId');
		parentIndex++;
	}else{
		$('#territoryRow').remove();
	}
	if($('#countyRow').is(":visible")){
		$('#addGeoParentCounty').attr('name', 'parentGeoUnitAssociations['+ parentIndex  +'].parentGeoUnitId');
		parentIndex++;
	}else{
		$('#countyRow').remove();
	}
	if($('#ptownRow').is(":visible")){
		$('#addGeoParentPostalTown').attr('name', 'parentGeoUnitAssociations['+ parentIndex  +'].parentGeoUnitId');
	}else{
		$('#ptownRow').remove();
	}
}

function initializeAddGeoUnitElements(){
	$('#outerChildDivBox1, #outerChildDivBox2, #outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox :input').attr('disabled', true);
	$('.showable').hide();
	$('#saveAddGeoUnitBtn').hide();
}

function reloadAddGeoUnitElements(){
	$('#outerChildDivBox1, #outerChildDivBox2, #outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox :input').attr('disabled', true);
	$('#outerNameDivBox .geoDatepickerTextBox').datepicker('disable');
	$('#outerCodeDivBox .geoDatepickerTextBox').datepicker('disable');
	$('#outerStatusDivBox .geoDatepickerTextBox').datepicker('disable');
	$('.showable').hide();
}

function enableChildSections(){
	if(isAllElementsSelected($('#geoSearch select:visible'))){
		if($('#outerChildDivBox1').is(":visible")){
			$('#outerChildDivBox1, :input').attr('disabled', false);
			$('#outerChildDivBox1 .geoDatepickerTextBox').datepicker('enable');
			$('#outerChildDivBox1 .showable').show();
			enableNameAndCodeSection($('#outerChildDivBox1 select:visible'));
		}else if($('#outerChildDivBox2').is(":visible")){
			$('#outerChildDivBox2, :input').attr('disabled', false);
			$('#outerChildDivBox2 .geoDatepickerTextBox').datepicker('enable');
			$('#outerChildDivBox2 .showable').show();
			enableNameAndCodeSection($('#outerChildDivBox2 select:visible'));
		}else{
			enableNameAndCodeSection($('#geoSearch select:visible'));
		}
	}else{
		reloadAddGeoUnitElements();
	}
}

function enableNameAndCodeSection(parentElementsHandle){
	if(isAllElementsSelected(parentElementsHandle)){
		$('#outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox :input').attr('disabled', false);
		$('#outerNameDivBox .geoDatepickerTextBox').datepicker('enable');
		$('#outerCodeDivBox .geoDatepickerTextBox').datepicker('enable');
		$('#outerNameDivBox .showable').show();
		$('#outerCodeDivBox .showable').show();
		$('#outerStatusDivBox .geoDatepickerTextBox').datepicker('enable');
	}else{
		$('#outerNameDivBox, #outerCodeDivBox, #outerStatusDivBox :input').attr('disabled', true);
		$('#outerNameDivBox .showable').hide();
		$('#outerCodeDivBox .showable').hide();
		$('#outerNameDivBox .geoDatepickerTextBox').datepicker('disable');
		$('#outerCodeDivBox .geoDatepickerTextBox').datepicker('disable');
		$('#outerStatusDivBox .geoDatepickerTextBox').datepicker('disable');
	}
	$('#activestatus').attr('disabled', true);
}

function isAllElementsSelected(elementsHandle){
	var allSelected = true;
	elementsHandle.each(function(){
		if($.trim($(this).val()) == ''){
			allSelected = false;
			return false;
		}
	});
	return allSelected;
}
function hideParentsBasedOnType() {
	var geoUnitTypeCode = $("#geoUnitTypeCode").val();

	if (geoUnitTypeCode == "128") { // for Country
		$('#countryRow, #territoryRow, #countyRow, #ptownRow, #outerChildDivBox2, #outerChildDivBox1')
				.hide();
	
	} else if (geoUnitTypeCode == "5392") { // for Territory
		$('#continentRow, #territoryRow, #countyRow, #ptownRow, #outerChildDivBox2, #outerChildDivBox1')
				.hide();
		
	} else if (geoUnitTypeCode == "5153") { // for County
		$('#continentRow, #countyRow, #ptownRow, #outerChildDivBox2, #outerChildDivBox1')
				.hide();
		
	} else if (geoUnitTypeCode == "126") { // for Postal Town
		$('#continentRow, #ptownRow, #outerChildDivBox2, #outerChildDivBox1')
				.hide();
		
	} else if (geoUnitTypeCode == "324" || geoUnitTypeCode == "1666") { // for Postal Code or Post Code Prefix Group
		$('#continentRow, #outerChildDivBox2, #outerChildDivBox1')
				.hide();

	} else if (geoUnitTypeCode == "1333"
			|| geoUnitTypeCode == "1444" || geoUnitTypeCode == "24458"
			|| geoUnitTypeCode == "24457") { // for Standard Metropolitan Statistical Area (USA) or
							   // Metropolitan Statistical Area (USA) or CBSA Micro or CBSA Metro
		$('#continentRow, #territoryRow, #ptownRow, #countyRow, #outerChildDivBox2')
				.hide();
		
	} else if (geoUnitTypeCode == "129" || geoUnitTypeCode == "130"
			|| geoUnitTypeCode == "329" || geoUnitTypeCode == "2002"
			|| geoUnitTypeCode == "14000") { // for Continent or Country Group
																 // for D&B Region/System or WorldBase Country Grouping
																 // for D&B Worldwide Network Geographic Market
		$('#parentrel, #continentRow, #countryRow, #territoryRow, #ptownRow, #countyRow, #outerChildDivBox1')
				.hide();
		
	} else {
		$('#parentrel, #continentRow, #countryRow, #territoryRow, #countyRow, #ptownRow, #outerChildDivBox1, #outerChildDivBox2')
				.hide();
	}
}

function addGeoNameRow(){
	var nextIndex = $(".nameTypeCode").length;
	$('#geoNameTable').append($('#geoNameTable tr:last').clone());
	var newlyAddedGeoNameRow = $('#geoNameTable tr:last');
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.nameTypeCode', nextIndex, 'geoUnitNames', 'nameTypeCode', "true");
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.languageCode', nextIndex, 'geoUnitNames', 'languageCode', "true");
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.nameDataProviderCode', nextIndex, 'geoUnitNames', 'dataProviderCode', "true");
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.geoNameTxtField', nextIndex, 'geoUnitNames', 'geoName', "true");
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.effectiveDate', nextIndex, 'geoUnitNames', 'effectiveDate', "false");
	updateNamesOfNewRow(newlyAddedGeoNameRow , '.childExpiredDate', nextIndex, 'geoUnitNames', 'expiredByDate', "false");
	
	newlyAddedGeoNameRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePicker(newlyAddedGeoNameRow, '.effectiveDate');
	initializeNewRowDatePicker(newlyAddedGeoNameRow, '.childExpiredDate');
	newlyAddedGeoNameRow.find('.removeGeoNameRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeGeoNameRow(this,' + nextIndex + ');">[-]</a>');
	
	return false;
}

function addGeoCodeRow(){
	var nextIndex = $(".geoCodeTypeCode").length;
	$('#geoCodeTable').append($('#geoCodeTable tr:last').clone());
	var newlyAddedGeoCodeRow = $('#geoCodeTable tr:last');
	updateNamesOfNewRow(newlyAddedGeoCodeRow , '.geoCodeTypeCode', nextIndex, 'geoUnitCodes', 'geoCodeTypeCode', "true");
	updateNamesOfNewRow(newlyAddedGeoCodeRow , '.codeDataProviderCode', nextIndex, 'geoUnitCodes', 'dataProviderCode', "true");
	updateNamesOfNewRow(newlyAddedGeoCodeRow , '.geoCode', nextIndex, 'geoUnitCodes', 'geoCode', "true");
	updateNamesOfNewRow(newlyAddedGeoCodeRow , '.effectiveDate', nextIndex, 'geoUnitCodes', 'effectiveDate', "true");
	updateNamesOfNewRow(newlyAddedGeoCodeRow , '.childExpiredDate', nextIndex, 'geoUnitCodes', 'expiredByDate', "true");
	
	newlyAddedGeoCodeRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePicker(newlyAddedGeoCodeRow, '.effectiveDate');
	initializeNewRowDatePicker(newlyAddedGeoCodeRow, '.childExpiredDate');
	newlyAddedGeoCodeRow.find('.removeGeoCodeRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeGeoCodeRow(this,' + nextIndex + ');">[-]</a>');
	
	return false;
}

function removeGeoNameRow(removeHandle, rowIndexToDelete){
	$('#geoNameTable tr').eq(rowIndexToDelete + 1).find('.effectiveDate').datepicker('destroy');
	$('#geoNameTable tr').eq(rowIndexToDelete + 1).find('.expiredByDate').datepicker('destroy');
	
	$(removeHandle).closest('tr').remove();
	
	$('#geoNameTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.nameTypeCode'), (this.rowIndex - 1), 'geoUnitNames', 'nameTypeCode');
			updateNames($(this).find('.languageCode'), (this.rowIndex - 1), 'geoUnitNames', 'languageCode');
			updateNames($(this).find('.nameDataProviderCode'), (this.rowIndex - 1), 'geoUnitNames', 'dataProviderCode');
			updateNames($(this).find('.geoNameTxtField'), (this.rowIndex - 1), 'geoUnitNames', 'geoName');
			$(this).find('.effectiveDate').datepicker('destroy');
			updateNames($(this).find('.effectiveDate'), (this.rowIndex - 1), 'geoUnitNames', 'effectiveDate');
			$(this).find('.effectiveDate').removeClass('hasDatepicker');
			$(this).find('.effectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.expiredByDate').datepicker('destroy');
			updateNames($(this).find('.expiredByDate'), (this.rowIndex - 1), 'geoUnitNames', 'expiredByDate');
			$(this).find('.expiredByDate').removeClass('hasDatepicker');
			$(this).find('.expiredByDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeGeoNameRowLink').html($(this).find('.removeGeoNameRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function removeChildRelationRow(removeHandle, rowIndexToDelete){
	$('#childRelationTable tr').eq(rowIndexToDelete + 1).find('.childEffectiveDate').datepicker('destroy');
	$('#childRelationTable tr').eq(rowIndexToDelete + 1).find('.childExpiredDate').datepicker('destroy');
	
	$(removeHandle).closest('tr').remove();
	
	$('#childRelationTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.countrySelect'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'childGeoUnitId');
			updateNames($(this).find('.childGeoUnitTypeCode'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'geoUnitTypeCode');
			updateNames($(this).find('.addChildGeoUnitId'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'childGeoUnitId');
			//updateNames($(this).find('.geoNameTxtField'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'geoName');
			$(this).find('.childEffectiveDate').datepicker('destroy');
			updateNames($(this).find('.childEffectiveDate'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'effectiveDate');
			$(this).find('.childEffectiveDate').removeClass('hasDatepicker');
			$(this).find('.childEffectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.childExpiredDate').datepicker('destroy');
			updateNames($(this).find('.childExpiredDate'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'expiredByDate');
			$(this).find('.childExpiredDate').removeClass('hasDatepicker');
			$(this).find('.childExpiredDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeChildRelationRowLink').html($(this).find('.removeChildRelationRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function removeGeoCodeRow(removeHandle, rowIndexToDelete){
	$('#geoCodeTable tr').eq(rowIndexToDelete + 1).find('effectiveDate').datepicker('destroy');
	$('#geoCodeTable tr').eq(rowIndexToDelete + 1).find('expiredByDate').datepicker('destroy');
	
	$(removeHandle).closest('tr').remove();
	
	$('#geoCodeTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.geoCodeTypeCode'), (this.rowIndex - 1), 'geoUnitCodes', 'geoCodeTypeCode');
			updateNames($(this).find('.codeDataProviderCode'), (this.rowIndex - 1), 'geoUnitCodes', 'dataProviderCode');
			updateNames($(this).find('.geoCode'), (this.rowIndex - 1), 'geoUnitCodes', 'geoCode');
			$(this).find('.effectiveDate').datepicker('destroy');
			updateNames($(this).find('.effectiveDate'), (this.rowIndex - 1), 'geoUnitCodes', 'effectiveDate');
			$(this).find('.effectiveDate').removeClass('hasDatepicker');
			$(this).find('.effectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.expiredByDate').datepicker('destroy');
			updateNames($(this).find('.expiredByDate'), (this.rowIndex - 1), 'geoUnitCodes', 'expiredByDate');
			$(this).find('.expiredByDate').removeClass('hasDatepicker');
			$(this).find('.expiredByDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeGeoCodeRowLink').html($(this).find('.removeGeoCodeRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function populateGeoCodes()
{
 
 	if($('.geoCodeTypeCode').val() == 23414)
 	{
 		$("#geoCodes").val('');
 		$("#geoCodes").attr("disabled", "disabled"); 
 		
 	}else
	{
		$("#geoCodes").removeAttr("disabled"); 

	}
}