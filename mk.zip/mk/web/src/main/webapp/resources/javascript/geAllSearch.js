/**
 * This file serves allSearch.jsp in globalElement
 */


$(document).ready(function() {
	bindGlobalElementSearchEvents();	
	configureGlblEleAllSearchDataTable();	
});

function bindGlobalElementSearchEvents(){

$('#allSearchBtn').bind('click',function(event) {			
			
				$('#errorMsg').hide();
				glblEleAllSearchResultsTable.fnFilter(getAllSearchCriteria());				
				$('#glblEleAllSearchResults').show();
				$('#allExportBtn').show();
				
				
		});



$('#allExportBtn').bind('click',function(event) {		
		var criteriaString=encodeURIComponent(getAllSearchCriteria());	
		location.href = "allSearchExportToExcelResults.form?type=export&sSearch="+criteriaString+"&time="+new Date().getTime();	
		return false; // to prevent event bubbling
});	

}

function getAllSearchCriteria(){
	var searchCriteriaDelimiter = "#~";
	var searchCriteria = $('#topic').val() + searchCriteriaDelimiter + 
						 $('#elementId').val() + searchCriteriaDelimiter + 
						 $('#elementName').val() + searchCriteriaDelimiter +
						 $('#shortdesc').val() + searchCriteriaDelimiter + 
						 $('#longdesc').val();
						 
	return searchCriteria;
	
}
var glblEleAllSearchResultsTable;
function configureGlblEleAllSearchDataTable(){
	
	glblEleAllSearchResultsTable = $("#glblEleAllSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "allSearchAjaxResults.form",
        "bProcessing": false,		
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aaSorting": [],
        "aoColumns": [null,null,null,null,{ "bVisible": false }],
		"fnRowCallback" : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
					if($('#elementName').val() != ""){
						$('td:eq(2)', nRow).highlight($('#elementName').val());
					}
					if($('#shortdesc').val() != ""){
						$('td:eq(3)', nRow).highlight($('#shortdesc').val());
					}
					return nRow;
				}
				
        
  });  
				
}