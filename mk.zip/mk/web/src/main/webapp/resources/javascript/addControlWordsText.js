// This serves for addControlWordsText.jsp

$(document).ready(function(){
	initializeControlWordsTextDatepicker();
	bindAddControlWordsText();
	drpDwnBind();
});

function bindAddControlWordsText()
{
//	$('#addCtrlWrdsLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "addControlWordsText.form";
//		return false;
//	});
}

function addunusabletext()
{
	var g = $("#dnbUnusGlsyTypCd").val();
	if(g)
	{
			$("#errorField").css("display","none");
			$("#statusBox,#industrydetailsBox").css("display","block");
			if(g == "24804")
			{
				$("#offensivewords").css("display","block");
				$("#indnamefilter,#orgnamefilter,#indnoiseword,#telecommunication,#addfilter,#phonecodenumber,#telexnumber").css("display","none");
				$("#heading").text("Offensive Word");
			}
			else if(g == "24808")
			{
				$("#indnamefilter").css("display","block");
				$("#offensivewords,#orgnamefilter,#indnoiseword,#telecommunication,#addfilter,#phonecodenumber,#telexnumber").css("display","none");
				$("#heading").text("Individual Name");
			}
			else if(g == "24803")
			{
				$("#orgnamefilter").css("display","block");
				$("#offensivewords,#indnamefilter,#indnoiseword,#telecommunication,#addfilter,#phonecodenumber,#telexnumber").css("display","none");
				$("#heading").text("Organization Name");
			}
			else if(g == "24799")
			{
				$("#indnoiseword").css("display","block");
				$("#offensivewords,#indnamefilter,#orgnamefilter,#telecommunication,#addfilter,#phonecodenumber,#telexnumber").css("display","none");
				$("#heading").text("Industry Code Inferrment Noise Word");
			}
			else if(g == "24806")
			{
				$("#telecommunication").css("display","block");
				$("#offensivewords,#indnamefilter,#orgnamefilter,#indnoiseword,#addfilter,#phonecodenumber,#telexnumber").css("display","none");
				$("#heading").text("Telephone Number");				
			}
			else if(g == "24802")
			{
				$("#addfilter").css("display","block");
				$("#offensivewords,#indnamefilter,#orgnamefilter,#indnoiseword,#telecommunication,#phonecodenumber,#telexnumber").css("display","none");
				$("#heading").text("Address");	
			}
			else if(g == "24801")
			{
				$("#phonecodenumber").css("display","block");
				$("#offensivewords,#indnamefilter,#orgnamefilter,#indnoiseword,#telecommunication,#addfilter,#telexnumber").css("display","none");
				$("#heading").text("Phone Area Code Number");	
			}
			
	}
	else
	{
		$("#errorField").html("Please Select Control Words File Type Code");
		$("#errorField").css("display","inline");
	    $("#offensivewords,#indnamefilter,#orgnamefilter,#indnoiseword,#telecommunication,#addfilter,#statusBox,#industrydetailsBox").css("display","none");
	}

}

function resetDate(){
	var currentTime = new Date();
    var month = currentTime.getMonth() + 1;
    var day = currentTime.getDate();
    var year = currentTime.getFullYear();
    if(day<10){day='0'+day;}
    if(month<10){month='0'+month;}
    document.getElementById("datepickeraddnew").value =(year+"-"+month +"-"+day);
}

function initializeControlWordsTextDatepicker(){
	$('.cdValDatepickerTextBox').datepicker(getDatepickerOptions(true));
}

function selectallcountrycheckboxes(ref,divId)
{
	 if(ref.checked == true)
	 {
			$('#'+divId+' input[type=checkbox][name=countryApplicabilityCheckboxValues]').each(function() 
			{ 
				this.checked = true;
			});
	 }
	 else if(ref.checked == false)
	 {
			$('#'+divId+' input[type=checkbox][name=countryApplicabilityCheckboxValues]').each(function() 
			{ 
				this.checked = false;
			});	 
	 }	
}
function deselectAllCountry(country,divId){
	if(!$(country).is(":checked")){
		$('#'+divId+' input[name=allcountries]').attr('checked',false); 
	}
}

function validateAddControlWords(){
	var success = true;
	$("#errorField").html('');
	if($("#dnbUnusGlsyTypCd").val() == ""){
		success = false;
	}else{
		switch(parseInt($("#dnbUnusGlsyTypCd").val())){
		case 24804: if($.trim($("#offensiveWrd").val())==""){
						$("#errorField").html("Please enter the Offensive Word<br/>");
						$("#errorField").css("display","inline");
						success = false;
					} break;
		case 24808: if($.trim($("#fullName").val())==""){
						$("#errorField").html("Please enter the Full Name<br/>");
						$("#errorField").css("display","inline");
						success = false;
					} 			
					if($("#fnme").val()==""){
						$("#errorField").append("Please enter the Fore Name<br/>");
						$("#errorField").css("display","inline");
						success = false;
					}
					if($("#snme").val()==""){
						$("#errorField").append("Please enter the Sur Name<br/>");
						$("#errorField").css("display","inline");
						success = false;
					}
					break;
		case 24803: if($.trim($("#orgName").val())==""){
						$("#errorField").html("Please enter the Organization Name<br/>");
						$("#errorField").css("display","inline");
						success = false;
					} break;
		case 24799: if($.trim($("#indCodeWrd").val())==""){
						$("#errorField").html("Please enter the Industry Code Inferment Noise Word<br/>");
						$("#errorField").css("display","inline");
						success = false;
					} break;
		case 24806: if($.trim($("#telNum").val())==""){
						$("#errorField").html("Please enter the Telephone Number<br/>");
						$("#errorField").css("display","inline");
						success = false;
					} break;
		case 24802: if($.trim($("#addrs").val())==""){
						$("#errorField").html("Please enter the Address<br/>");
						$("#errorField").css("display","inline");
						success = false;
					}
					if($("#adrCountryDrpDwn").val()==""){
					$("#errorField").append("Please select the country<br/>");
					$("#errorField").css("display","inline");
					success = false;
					}else{
					$("#adrCountryNme").val($("#adrCountryDrpDwn option:selected").text());
					}
					break;
		case 24801: if($.trim($("#areaCdNum").val())==""){
						$("#errorField").html("Please enter the Area Code Number<br/>");
						$("#errorField").css("display","inline");
						success = false;
					}
					if($('#phnCdCountryDrpDwn').val()==""){
						$("#errorField").append("Please select the country<br/>");
						$("#errorField").css("display","inline");
						success = false;
					}
					break;
		}
	}
	if(success){
	switch(parseInt($("#dnbUnusGlsyTypCd").val())){
		case 24804: $("#indnamefilter,#orgnamefilter,#indnoiseword,#telecommunication,#addfilter,#phonecodenumber").remove();break;
		case 24808: $("#offensivewords,#orgnamefilter,#indnoiseword,#telecommunication,#addfilter,#phonecodenumber").remove();break;			
		case 24803: $("#offensivewords,#indnamefilter,#indnoiseword,#telecommunication,#addfilter,#phonecodenumber").remove();break;
		case 24799: $("#offensivewords,#indnamefilter,#orgnamefilter,#telecommunication,#addfilter,#phonecodenumber").remove();break;
		case 24806: $("#offensivewords,#indnamefilter,#orgnamefilter,#indnoiseword,#addfilter,#phonecodenumber").remove();break;
		case 24802: $("#offensivewords,#indnamefilter,#orgnamefilter,#indnoiseword,#telecommunication,#phonecodenumber").remove();break;
		case 24801: $("#offensivewords,#indnamefilter,#orgnamefilter,#indnoiseword,#telecommunication,#addfilter").remove();break;
	}
	$('#dnbUnusGlsy').submit();
	}else{
	return success;
	}
	
}

function drpDwnBind(){

$('#phnCdCountryDrpDwn').on('change', function(){
	if($(this).val() != ''){
		populateChildSelectBox($(this).val(), "5392",  $('#phnCdTerritoryDrpDwn'),$(this).val());
	}else{
		$('#phnCdTerritoryDrpDwn').empty();
	}
	return false;
});

$('#adrCountryDrpDwn').on('change', function(){
	if($(this).val() != ''){
		populateChildSelectBox($(this).val(), "5392",  $('#adrTerritoryDrpDwn'), $(this).val());
	}else{
		$('#adrTerritoryDrpDwn').empty();
	}
	return false;
});

jQuery("input.allowNumeric").live('keydown',function (e){
	var key = e.which || e.keyCode;

    if (!e.shiftKey && !e.altKey && !e.ctrlKey &&
    	key >= 48 && key <= 57 ||
		key >= 96 && key <= 105 ||
		key == 8 || key == 9 || key == 13 ||
		key == 35 || key == 36 ||
		key == 37 || key == 39 ||
		key == 46 || key == 45)
        return true;
    return false;

});
}