/**
 * 
 */
$(document).ready(function(){
	if($("#addGeoCrcySuccess").val()){
		alert("New Geo Currency data is added in Reference Data successfully");
	}
	bindAddGeoCurrencyEvents();
	initializeAddCdValDatepicker();		
	 
});


function initializeAddCdValDatepicker(){
	$('.addCdValDatepickerTextBox').removeClass('hasDatepicker').datepicker(
			getDatepickerOptions(true));
	$('.addCdValDatepickerTextBox').datepicker('enable');
}

function bindAddGeoCurrencyEvents(){
	
	
	
	$('#addGeoCrcySubmitButton').bind('click',function(){
		if($('#geoCrcyCountry').val() == ""){
			$('#errorMsg').html("Please select a country");
			$('#errorMsg').show();
		}else if($('#currencyCode').val() == ""){
			$('#errorMsg').html("Please select a Currency");
			$('#errorMsg').show();
		}else if(!(isValidDate($('#cdValEffectiveDate').val()))){
			$('#errorMsg').html("Please enter valid Effective date");
			$('#errorMsg').show();
		}else{
			$('#errorMsg').hide();				
			if(confirm("Are you sure you want to add the Currency details")) {
				$('#addGeoCurrencyForm').submit();
			}
		}
		
	});
	
}

function isValidDate(dateString) {
	var regEx = /^\d{4}-\d{2}-\d{2}$/;
	var dtArray = dateString.match(regEx); 
	if (dtArray == null) {
        return false;
	}
	var splitdate = dateString.split('-');
	dtYear = splitdate[0];
	dtMonth = splitdate[1];
	dtDay = splitdate[2];
	
	if (dtMonth < 1 || dtMonth > 12) {
        return false;
    }else if (dtDay < 1 || dtDay> 31) {
        return false;
    }else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) {
        return false;
	}else if (dtMonth == 2) 
    {
		alert(isleap);
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
		alert(isleap);
        if (dtDay> 29 || (dtDay ==29 && !isleap)) {
            return false;
		}
    }
    return true;
}