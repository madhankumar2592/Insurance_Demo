/**
 * This file serves industryCodeDetail.jsp
 */

$(document).ready(function(){
	initializeIndustryAddElements();
	initializeAddUserMode();
});

function initializeAddUserMode(){
	if($('#userMode').length){
		if($.trim($('#userMode').val()) == 'edit'){
			$('#errorMsg').show();
		}
	}
}

function initializeIndustryAddElements(){
//	$('#indsCodeAddLink').bind('click',function(event) {
//		event.preventDefault();
//		location.href = "indsCodeAdd.form";
//		return false; // to prevent event bubbling
//	});
	
	$('#industrySaveButton').bind('click', function(){
		saveIndustry();
		return false;
	});
	
	$('#industryResetButton').bind('click', function(){
		location.href = "indsCodeAdd.form";
		return false;
	});
	
	$('#industryCancelButton').bind('click', function(){
		location.href = "indsCodeSearchHome.form";
		return false;
	});
	
	bindMapCheckBoxValueToEntity();
	bindDescriptionGroupLevelChange();
	setMaxLengthForFields();
}

function isEnglishDescAvail() {
	var selectedLanguages = [];
	$("#industryDescriptionTable tr").each(function(){
		if($(this).find('.languageCode').is(':visible') && $(this).find('.languageCode option:selected').length){
			selectedLanguages.push($(this).find('.languageCode option:selected').val());
		}
	});
	
	for(var j = 0; j < selectedLanguages.length; j++){		
		if(selectedLanguages[j] == '39'){	
			return true;
		}
	}
	alert('Description in English is mandatory for an Industry Code');
	return false;
}

function saveIndustry(){
	
	if(isIndustryEmpty()){
		
		return false;
	}
	if(!isEnglishDescAvail()){
		
		return false;
	}
	if(isDescriptionCodeDuplicate()){
				return false;
	}
	if(isTypeCodeDuplicate()){
		return false;
	}
	if( isPreferenceDuplicate()){
			return false;
	}
	setPrefferedMapindicator();

	$('#industrySaveButton').attr("disabled",true);
	alert("The new Record has been added to the Stage System");
	$('#industryCodeForm').submit();	
}
function setPrefferedMapindicator(){
	$(".mappingRows").each(function() {
		if($(this).find('.visibleMapIndicator').attr("checked")) {
			$(this).find('.hiddenMapIndicator').val(1);
		} else {
			$(this).find('.hiddenMapIndicator').val(0);
		}
	})
}

function setMaxLengthForFields() {
	$(".industryCodeGroupLevelCode").bind('change',function(event) {
		$('#industryCode').val('');
		if($('#industryCodeGroupLevelCode').val() != "") {
			var selectedGrpLevelCode = $('#industryCodeGroupLevelCode option:selected').html();
			var maxLmt = selectedGrpLevelCode.substring(
					selectedGrpLevelCode.indexOf('[') + 1, selectedGrpLevelCode.indexOf('[') + 2);
			$('#industryCode').attr("maxLength", maxLmt);
		} else {
			$('#industryCode').attr("maxLength", "12");
		}
	});
	
	if($('#industryCodeGroupLevelCode').val() == "") {
		$('#industryCode').attr("maxLength", "12");
	}
}