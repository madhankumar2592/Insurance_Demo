/*This file serves areaCodeNumbers.jsp*/

$(document).ready(function() {
	bindAreaCodeNumbersElements();
	configureAreaCodeSearchDataTable();
});

function bindAreaCodeNumbersElements() {
	if($.trim($('#phoneAreaCodeId').val()) != ''){
		$('#addAreaCodeNumbersSubmitButton').hide();
		$('#addAreaCodeNumbersResetButton').hide();
		$('#areaCodeNumber').attr('disabled', 'disabled');
		$('#areaCodeServiceDescription').attr('disabled', 'disabled');		
		$('#addAreaCodeNumbersCountry').attr('disabled', 'disabled');
		$('#addAreaCodeNumbersTerritory').attr('disabled', 'disabled');			
		$('#addAreaCodeEffectiveDate').attr('disabled', 'disabled');	
		
	}else{
		$('#addAreaCodeNumbersEditButton').hide();
		
	}
	
	if($.trim($('#areaCodeNumber').val()) == ''){
		$('#pageTitle').html("Add Area Code Numbers");
	}else{
		$('#pageTitle').html("Area Code Numbers - View");
		document.title = "Area Code Numbers - View";
	}
	
	$('#addAreaCodeNumbersEditButton').on('click', function(){
		$.getJSON('lockPhoneAreaCodeForEdit.form', {
			ajax : 'true'
		}, function(data) {
			if(data == true) {
				$('#errorMsg').html('The record is locked by another user due to a pending request on the Work Queue.');
				$('#errorMsg').show();
			} else {
				$('#pageTitle').html('Area Code Numbers - Edit');
				document.title = "Area Code Numbers - Edit";
				$('#errorMsg').html('');
				$('#errorMsg').hide();
				$('#areaCodeNumber').removeAttr('disabled');
				$('#areaCodeServiceDescription').removeAttr('disabled');	
				$('#addAreaCodeNumbersCountry').removeAttr('disabled');
				$('#addAreaCodeNumbersTerritory').removeAttr('disabled');	
				$('#addAreaCodeEffectiveDate').removeAttr('disabled');
				$('#addAreaCodeNumbersSubmitButton').show();
				$('#addAreaCodeNumbersResetButton').show();
				$('#addAreaCodeNumbersEditButton').hide();
			}
		});
	});
	
//	$('#areaCodeNumbersLink').bind('click', function(event) {
//		event.preventDefault();
//		location.href = "areaCodeNumbersHome.form";
//		return false;
//	});
//	
//	$('#addAreaCodeNumbersLink').on('click', function(event) {
//		location.href = "getAddAreaCodeNumbers.form?phoneAreaCodeId=&isStagingDB=true&taskId=";
//		return false;
//	});
	
	$('#areaCodeSearchBtn').bind('click',function(event){
		$('#errorMsg').hide();
		areaCodeSearchResultsTable.fnFilter(getAreaCodeSearchCriteria());
		$('#areaCodeSearchResults').show();
	});
	
	if($('#sourceQueue').val() == ''){
		$('.addAreaCodeNumbersEffectiveDate').datepicker('enable');
		$("#addAreaCodeEffectiveDate").val(getToday());
		$('#addAreaCodeEffectiveDate').attr('disabled', 'disabled');
	}
	
	$('#addAreaCodeNumbersCountry').on('change', function(){
		if($(this).val() != ''){
			populateChildSelectBox($(this).val(), "5392",  $('#addAreaCodeNumbersTerritory'),$(this).val());
		}else{
			$('#addAreaCodeNumbersTerritory').empty();
		}
		return false;
	});
	
	$('#areaCdCountryId').on('change', function(){
		if($(this).val() != ''){
			populateChildSelectBox($(this).val(), "5392",  $('#areaCdTerritoryId'),$(this).val());
		}else{
			$('#areaCdTerritoryId').empty();
		}
		return false;
	});
	
	$('#addAreaCodeNumbersSubmitButton').on('click', function(){		
		if(isAddAreaCodeNumbersValid()){			
			$('#addAreaCodeNumbersForm').submit();
		}
		return false;
	});
	
	if(($('#sourceQueue').val() == 'submitter') || ($('#sourceQueue').val() == 'approver')){
		$('.addAreaCodeNumbersMandatory').each(function(){
			$(this).prop('disabled', true);
		});
		$('#addAreaCodeNumbersSubmitButton').hide();
		$('#addAreaCodeNumbersResetButton').hide();
		$('#addAreaCodeNumbersTerritory').attr('disabled',true);
	}
	
	if($('#sourceQueue').val() != 'approver'){
		$('#addAreaCodeNumbersApproveButton').hide();
		$('#addAreaCodeNumbersRejectButton').hide();
	}
	
	$('#addAreaCodeNumbersResetButton').on('click', function(){
		location.href = "getAddAreaCodeNumbers.form?phoneAreaCodeId=" + $('#phoneAreaCodeId').val() + "&isStagingDB=true&taskId=";
		return false;
	});
	
	$('#addAreaCodeNumbersCancelButton').on('click', function(){
		if($('#sourceQueue').val() == 'submitter'){
			location.href = "submitterWorkQueueHome.form?domainName=Control Words";
		}else if($('#sourceQueue').val() == 'approver'){
			location.href = "approverWorkQueueHome.form?domainName=Control Words";
		}else{
			location.href = "home.form";
		}
		return false;
	});
	
	$('#addAreaCodeNumbersApproveButton').on('click', function(){
		completeTaskAjax(true);
	});
	
	$('#addAreaCodeNumbersRejectButton').on('click', function(){
		$("#reasonDiv").show();
		$("#reason").focus();
		return false;
	});
}

function isAddAreaCodeNumbersValid(){
	var isValid = true;
	$('.addAreaCodeNumbersMandatory').each(function(){
		if($.trim($(this).val()) == ''){
			$('#errorMsg').html('All fields marked (*) are mandatory.');
			$('#errorMsg').show();
			$(this).focus();
			isValid = false;
			return false;
		} else {
			$('#errorMsg').hide();
		}
	});
	return isValid;
}

var areaCodeSearchResultsTable;
function configureAreaCodeSearchDataTable(){
	areaCodeSearchResultsTable = $("#areaCodeSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "areaCodeSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "iDeferLoading": 0, 
		"aoColumns" : [ null, null, null, null, null, { "bVisible": false} ],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {	
        	setAreaCodeResultsColumn(nRow, aData);
		   	return nRow;
        }
  });
}

function setAreaCodeResultsColumn(nRow, aData){
	$('td:eq(0)', nRow).html(getAreaCodeColumnHtml(aData[5], aData[0]));
	$('td:eq(1)', nRow).html(aData[1]);
	$('td:eq(2)', nRow).html(getAreaCodeColumnHtml(aData[5], aData[2]));
	$('td:eq(3)', nRow).html(aData[3]);
	$('td:eq(4)', nRow).html(aData[4]);
}

function getAreaCodeColumnHtml(code, value){
	return "<a href='getAddAreaCodeNumbers.form?phoneAreaCodeId=" + code + "&isStagingDB=true&taskId='>" + value + "</a>";
}

function getAreaCodeSearchCriteria() {
	var searchCriteriaDelimiter = "#~";
	var searchCriteria = $('#areaCodeNumberTxt').val() + searchCriteriaDelimiter + 
						 $('#areaCdCountryId').val() + searchCriteriaDelimiter + 
						 $('#areaCdTerritoryId').val() + searchCriteriaDelimiter + 
						 $('#areaCodeActiveInd').val() + searchCriteriaDelimiter + 
						 $('#areaCodeInActiveInd').val(); 
	return searchCriteria;
}