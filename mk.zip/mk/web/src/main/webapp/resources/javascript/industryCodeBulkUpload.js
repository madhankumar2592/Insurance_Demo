/* Code for Bulk Upload */
$(document).ready(function(){
	bindIndustryCodeBulkUpload();	
	bindIndustryCodesUploadEvents();
});

function bindIndustryCodeBulkUpload()
{
//	$('#industryCodeBulkUploadLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "industryCodeBulkUpload.form";
//		return false; // to prevent event bubbling
//	});
}
function displayCrosswalkUpload()
{
	if($("#industryTableUpload").val() == "Standard Industry Code - 8 digit" ||$("#industryTablecode").val() == "Standard Industry Code - 8 digit" )
	{
		$("#toindustryTableName1").css("display","inline");
		$("#toindustryTableUpload").css("display","none");
		$("#toindustryTableUpload").val('');
	}
	else
	{
		$("#toindustryTableName1").css("display","none");
		$("#toindustryTableName1").val('');
		$("#toindustryTableUpload").css("display","inline");		
	}
}
function validateindUpload()
{
	
	if(document.getElementById('indupload').value == "" ||document.getElementById('indupload').value == null)
	{
		alert('Select a file to upload');
		document.getElementById('indupload').focus();
	}
	else
	{
		var fup = document.getElementById('indupload').value;	
		var ext = fup.substring(fup.lastIndexOf('.') + 1);
		if(ext == "xlsx")
		{
			
			/*$('#currencyBulkUploadForm').submit();*/			
			document.getElementById('indupload').focus();
			alert("The New records have been added to the stage system and should be routed for approval");	
			$('#industryCodeBulkUpload').submit();
			return true;
		} 
		else
		{						
			alert("Please upload only xlsx files");	
			document.getElementById('indupload').value="";
			document.getElementById('bulktext').value="";				
			return false;
		}			
	}
}

function toggleChangeUpload()
{
	if($("#industryTableUpload").css("display") == "inline")
	{
		$("#industryTableUpload").css("display","none");
		$("#industryTableUpload").val('');
		$("#industryTablecode").css("display","inline");
	}
	else if($("#industryTableUpload").css("display") == "none")
	{
		$("#industryTableUpload").css("display","inline");
		$("#industryTablecode").css("display","none");	
		$("#industryTablecode").val('');	
	}
}

function checkindDomain()
{
	if($('#indDomain').val() == "")
	{
			$('#indDomain').focus();
			alert('Select Industry Code Bulk File Type before Bulk Upload');
	}
	else
	{
		if($('#indDomain').val() == "Industry Code/Description")
		{
		$('#bulkuploadcrosswalkrow,').css("display","none");
		$('#labelcol').css("display","table-row");
		$('#bulkuploadrow').css("visibility","hidden"); 
		}
		else
		{
		$('#bulkuploadcrosswalkrow').css("display","table-row");
		$('#labelcol').css("display","none");
		$('#bulkuploadrow').css("visibility","hidden"); 
		}
	}	
}
function checkindsecondDomain()
{
	if($('#industry').val() != "" ||$('#industrycode').val() != "")
	$('#bulkuploadrow').css("visibility","visible");
	else
	$('#bulkuploadrow').css("visibility","hidden"); 	
}
function checkindthirdDomainUpload()
{
	if(($('#industryTableUpload').val() != "" ||$('#industryTablecode').val() != "") && ($('#toindustryTableUpload').val() != "" ||$('#toindustryTableName1').val() != "") )
	$('#bulkuploadrow').css("visibility","visible");
	else
	$('#bulkuploadrow').css("visibility","hidden"); 	
}

function bindIndustryCodesUploadEvents() {
	
	$('#industryTableUpload').bind('change',function(){	
	$("#toindustryTableUpload").empty();
	$("#toindustryTableUpload").append('<option value="">-- Select To Industry Type Code --</option>');	
	if($.trim($(this).val()) != '') {		
		populateCrossWalkUpload($(this).val());		
	}	
});
}



function populateCrossWalkUpload(indsCodeType) {
	$.getJSON('retrieveCrossWalksForIndsCodeType.form', {
		industryCodeType : indsCodeType,
		ajax : 'true'
	}, function(data) {
		$("#toindustryTableUpload").empty();		
		$("#toindustryTableUpload").append('<option value="">--  Select To Industry Type Code  --</option>'); 
		$.each(data, function() {
			 $("#toindustryTableUpload").append('<option value="' + this.code + '">' + this.value + '</option>'); 
		 }); 
	});
}
