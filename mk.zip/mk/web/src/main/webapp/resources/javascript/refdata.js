
// the spinner - processing : js functions $start$
$(document).ready(function() {
	
	$('body').on('contextmenu',function(e){     
		return false; 
	});  


	$('#frst').click(function(event){
		location.href = 'home.form';
	});
	
	$('#load').add('#loadImage').css('display', 'none');
	$('.list').click(function(event) {
		$('#load').add('#loadImage').css('display', 'inline');
	}).live("click", function(event) {
		$('#load').add('#loadImage').css('display', 'inline');
	});
	$('.nbdropdown').change(function(event) {
		$('#load').add('#loadImage').css('display', 'inline');
	});
	$('#load').add('#loadImage').ajaxStart(function() {
		$(this).css('display', 'inline');
	});
	$('#load').add('#loadImage').ajaxStop(function() {
		$(this).css('display', 'none');
	});
	$('#load').ajaxError(function(event, jqXHR, textStatus, errorThrown) {
		location.href = "errorHanlder.form";
	});	
	
	initializeDatepicker();
	bindclearExpirationDate();
	bindWorkQueueRejectBtn();
	bindWorkQueueApproveBtn();	
});





$(document).submit(function() {
	$('#load').add('#loadImage').css('display', 'inline');
});

function showSpinner() {
	$('#load').add('#loadImage').css('display', 'inline');
}
function hideSpinner() {
	$('#load').add('#loadImage').css('display', 'none');
}
//the spinner - processing : js functions $ends$

// the menu events
$(document).ready(function() {
	//Geography - Search Geography
	$('#geoSearchHomeLink').bind('click',function(event){
		event.preventDefault();
		location.href = "geoSearchHome.form";
		return false; // to prevent event bubbling
	});
	//Geography - Search Geo Name/ Code
	$('#geoNameCodeSearchLink').bind('click',function(event){
		event.preventDefault();
		location.href = "geoNameCodeSearch.form";
		return false; // to prevent event bubbling
	});
	//Geography - Search by Geo Unit ID
	$('#geoUnitIdSearchLink').bind('click',function(event){
		event.preventDefault();
		location.href = "geoUnitIdSearch.form?id=";
		return false; // to prevent event bubbling
	});
	//Geography - Search Country Groups
	$('#countryGroupsLink').bind('click',function(event){
		event.preventDefault();
		location.href = "countryGroupSearchHome.form";
		return false; // to prevent event bubbling
	});
	//Geography - Add Geo Unit
	$('#geoAddLink').bind('click',function(event){
		event.preventDefault();
		location.href = "loadAddGeoUnit.form";
		return false; // to prevent event bubbling
	});
	//Geography - Upload Bulk Files
	$('#geoBulkUploadLink').bind('click',function(event){
		event.preventDefault();
		location.href = "geoBulkUpload.form";
		return false;
	});
	//Geography - Download Bulk Files
	$('#geoBulkDownloadLink').bind('click',function(event){
		event.preventDefault();
		location.href = "geoBulkDownload.form";
		return false; // to prevent event bubbling
	});
	//Geography - Geography CrossWalk
	$('#geoCrossWalkLink').bind('click',function(event){
		event.preventDefault();
		location.href = "geoCrossWalk.form";
		return false; // to prevent event bubbling
	});
	//Financial Statement Template - Manage Financial Template
	$('#manageFTLink').bind('click',function(event){		
		event.preventDefault();
		location.href = "finance?financialTemplateTypeCode=&taskId=";
		return false;
	});
	
	//Currency Exchange - Search Currency Exchange
	$('#currencyLink').bind('click',function(event){
		event.preventDefault();
		location.href = "currencySearchHome.form";
		return false; // to prevent event bubbling
	});
	//Currency Exchange - Upload Bulk Files
	$('#currencyBulkUploadLink').bind('click',function(event){
		event.preventDefault();
		location.href = "currencyBulkUpload.form";
		return false; // to prevent event bubbling
	});
	
	//Currency Exchange - Geo Currency Search
	$('#geoCurrencyLink').bind('click',function(event){
		event.preventDefault();
		location.href = "geoCurrencySearch.form";
		return false; // to prevent event bubbling
	});
	
	//Currency Exchange - Geo Currency Add
	$('#geoCurrencyAddLink').bind('click',function(event){
		event.preventDefault();
		location.href = "geoCurrencyAdd.form";
		return false; // to prevent event bubbling
	});
	
	
	//SCoTS - Retrieve Code Tables 
	$('#scotsCodeTableLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "showCodeTableSearch.form";
		return false; // to prevent event bubbling
	});
	//SCoTS - Search Codes by Table 
	$("#listCodeTableLink").bind('click', function(event) {
		event.preventDefault();
		location.href = "listCodeTable.form";
		return false; // to prevent event bubbling
	});
	//SCoTS - Search Codes by Code Value
	$('#scotsCodeValueLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "searchCodeValue.form";
		return false; // to prevent event bubbling
	});
	//SCoTS - Add Code Table
	$('#scotsAddCodeTableLink').bind('click',function(event){
		event.preventDefault();
		location.href = "scotsAddCodeTable.form";
		return false;
	});
	//SCoTS - Add Code Value
	$('#addScotsCodeValueLink').bind('click',function(event){
		event.preventDefault();
		location.href = "showAddCodeValueHome.form";
		return false; // to prevent event bubbling
	});	
	//SCoTS - View System Applicability 
	$('#manageSystemApplicabilityLink').bind('click', function(){
		location.href = "getManageSystemApplicability.form?applicability=System&domainId=&taskId=&dnbSystemCode=";
		return false;
	});
	//SCoTS - Manage Market Applicability 
	$('#manageMarketApplicabilityLink').bind('click', function(){
	location.href = "getManageSystemApplicability.form?applicability=Market&domainId=&taskId=&dnbSystemCode=";
		return false;
	});
	//SCoTS - Manage SCoTS Relationship 
	$('#scotsRelationshipLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "manageCodeRelationship.form";
		return false; // to prevent event bubbling
	});
	//SCoTS - Manage Alt Scheme Code
	$('#scotsAltSchemeLink').bind('click', function(event) {
		event.preventDefault();
		location.href = "manageAltSchemeCode.form";
		return false; // to prevent event bubbling
	});
	//SCoTS - Download Bulk Files 
	$('#scotsBulkDownloadLink').bind('click',function(event){
		event.preventDefault();
		location.href = "scotsBulkDownload.form";
		return false;
	});
	//SCoTS - Upload Bulk Files 
	$('#scotsBulkUploadLink').bind('click',function(event){
		event.preventDefault();
		location.href = "scotsBulkUpload.form";
		return false; // to prevent event bubbling
	});
	
	//Industry Codes - Search Industry Code Data
	$('#indsCodeSearchLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "indsCodeSearchHome.form";
		return false; // to prevent event bubbling
	});
	//Industry Codes - Add Industry Code
	$('#indsCodeAddLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "indsCodeAdd.form";
		return false; // to prevent event bubbling
	});
	//Industry Codes - Upload Bulk Files 
	$('#industryCodeBulkUploadLink').bind('click',function(event){
		event.preventDefault();
		location.href = "industryCodeBulkUpload.form";
		return false; // to prevent event bubbling
	});
	//Industry Codes - Download Bulk Files 
	$('#industryCodeBulkDownloadLink').bind('click',function(event){
		event.preventDefault();
		location.href = "industryCodeBulkDownload.form";
		return false; // to prevent event bubbling
	});
	
	//Industry Codes - Crosswalk Dashboard
	$('#crosswalkDashboardLink').bind('click',function(event){
		event.preventDefault();
		location.href = "indsCrosswalkDashboard.form";
		return false; // to prevent event bubbling
	});
	
	
	//Control Words - Search Industry Code Inferment 
	$('#industryCodeInfermentLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "indsCodeInfermentSearchHome.form";
		return false; // to prevent event bubbling
	});
	//Control Words - Search Legal Form Inferment 
	$('#legalFormSearchLink').bind('click',function(event){
		event.preventDefault();
		location.href = "legalFormInferment.form";
		return false; // to prevent event bubbling
	});
	//Control Words - Search Control Words 
	$('#ctrlWrdsLink').on('click',function(event){
		location.href = "showControlWordsSearch.form";
		return false;
	});
	//Control Words - Search Area Code Numbers
	$('#areaCodeNumbersLink').bind('click', function(event) {
		event.preventDefault();
		location.href = "areaCodeNumbersHome.form";
		return false;
	});
	//Control Words - Add Area Code Numbers
	$('#addAreaCodeNumbersLink').on('click', function(event) {
		location.href = "getAddAreaCodeNumbers.form?phoneAreaCodeId=&isStagingDB=true&taskId=";
		return false;
	});
	//Control Words - Add Control Words Text
	$('#addCtrlWrdsLink').bind('click',function(event){
		event.preventDefault();
		location.href = "addControlWordsText.form";
		return false;
	});
	//Control Words - Add Industry Code Inferment 
	$('#addIndustryCodeInfermentLink').bind('click',function(event){
		event.preventDefault();
		location.href = "addIndsCodeInfermentHome.form";
		return false; // to prevent event bubbling
	});
	//Control Words - Add Legal Form Inferment 
	$('#addLegalFormInfermentLink').bind('click',function(event){
		event.preventDefault();
		location.href = "addLegalFormInferment.form";
		return false; // to prevent event bubbling
	});
	//Control Words - Upload Bulk Files 
	$('#ctrlWrdsBulkUploadLink').bind('click',function(event){
		event.preventDefault();
		location.href = "ctrlWrdsBulkUpload.form";
		return false;
	});
	//Control Words - Download Bulk Files 
	$('#bulkDownloadCtrlWrdsLink').bind('click',function(event){
		event.preventDefault();
		location.href = "controlWordsBulkDownload.form";
		return false; // to prevent event bubbling
	});
	
	//XML Schema Labels - Search XML Schema Labels 
	$("#xmlScmaLabelsLink").bind('click', function(event) {
		event.preventDefault();
		location.href = "xmlSchemaLabelHome.form";
		$('li').removeClass('active');
		$('#xmlSchemaLabel').closest('li').addClass('active');
		return false;
	});
	//Product - Search 
	$('#productSearchLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "productSearchHome.form";
		return false; // to prevent event bubbling
	});
	//Scoring - Search Scores 
	$('#scoreSearchLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "scoreSearchHome.form";
		return false; // to prevent event bubbling
	});
	
	//Scoring - Search Scores 
	$('#scoreReportLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "scoreReportsHome.form";
		return false; // to prevent event bubbling
	});

	//Scoring - Score Product Mapping
	$('#scoreProductMappingLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "scoreProdMappingHome.form";
		return false; // to prevent event bubbling
	});
	
	$('#addNewProductLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "addNewProductHome.form";
		return false; // to prevent event bubbling
	});
	
	//Scoring - Products Reports 
	$('#productScrRptLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "productScoreRpt.form";
		return false; // to prevent event bubbling
	});
	//Score - Product Map 
	$('#productScrMapLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "prodScrMap.form";
		return false; // to prevent event bubbling
	});	
	$('#scoreGranuMappingLink').bind('click',function(event) {
		event.preventDefault();
		
		location.href = "scoreGranMappingHome.form";
		return false; // to prevent event bubbling
	});
	
	$('#addNewScoreLink').bind('click',function(event) {
		event.preventDefault();
		
		location.href = "addNewScoreHome.form";
		return false; // to prevent event bubbling
	});
	
	$('#scoreMappingLink').bind('click',function(event) {
		event.preventDefault();
		
		location.href = "addScoreMappingHome.form";
		return false; // to prevent event bubbling
	});
	//Scoring - Override Mapping Scores 
	$('#scoreDtlMapLink').bind('click',function(event) {
	
			event.preventDefault();
		location.href = "scoreDetailsMap.form";
		return false; // to prevent event bubbling
	});
	$('#scoreOverrideMappingLink').bind('click',function(event) {
		event.preventDefault();
		
		location.href = "addScoreOverrideMappingHome.form";
		return false; // to prevent event bubbling
	});
	
	$('#overrideLabelMappingLink').bind('click',function(event) {
		event.preventDefault();
		
		location.href = "overrideLabelMappingHome.form";
		return false; // to prevent event bubbling
	});
	
	//Global Element
		
	$('#globalElementBkpLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "allSearchBkp.form";
		return false; // to prevent event bubbling
	});
	
	$('#globalElementHomeLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "glblHome.form";
		return false; // to prevent event bubbling
	});
	
	$('#globalElementAddLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "glblEleAdd.form";
		return false; // to prevent event bubbling
	});
	
	/*$('#globalElementCrosswalkLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "glblEleCrosswalk.form";
		return false; // to prevent event bubbling
	});
	
	$('#globalElementSearchCrswalkLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "glblEleSearchCrosswalk.form";
		return false; // to prevent event bubbling
	});
	
	
	
	$('#globalElementCrosswalkDashLink').bind('click',function(event) {
		event.preventDefault();
		location.href = "glblEleDashborad.form";
		return false; // to prevent event bubbling
	});	*/
	
	
	
	
	
	
	//Work Queue - Approver Queue
	$('#approverWorkQueueLink').bind('click',function(event){
		event.preventDefault();
		location.href = "approverWorkQueueHome.form?domainName=";
		return false; // to prevent event bubbling
	});	
	//Work Queue - Submitter Queue
	$('#submitterWorkQueueLink').bind('click',function(event){
		event.preventDefault();
		location.href = "submitterWorkQueueHome.form?domainName=";
		return false; // to prevent event bubbling
	});	
	//Work Queue - Saved Records
	$('#savedRecordsLink').bind('click',function(event){
		event.preventDefault();
		location.href = "savedRecords.form?domainName=";
		return false; // to prevent event bubbling
	});	
	//Work Queue -	 My Downloads
	$('#workQueueDownloadLink').bind('click',function(event){
		event.preventDefault();
		location.href = "workQueueDownload.form";
		 	return false; // to prevent event bubbling
	});	
	//Work Queue -	 Bulk Template
	$('#bulkTemplate').bind('click',function(event){
		event.preventDefault();
		location.href = "bulkTemplate.form";
		 	return false; // to prevent event bubbling
	});
});

// the code for initializing the bulk uploads
var W3CDOM = (document.createElement && document.getElementsByTagName);
function initFileUploads() {
	if (!W3CDOM) return;
	var fakeFileUpload = document.createElement('div');
	fakeFileUpload.className = 'fakefile';	
	var image = document.createElement('img');
	image.src='./resources/images/browse_btn.png';
	image.border="0";
	fakeFileUpload.appendChild(image);
	var x = document.getElementsByTagName('input');
	for (var i=0;i<x.length;i++) {
		if (x[i].type != 'file') continue;
		if (x[i].parentNode.className != 'fileinputs') continue;
		x[i].className = 'file hidden';
		var clone = fakeFileUpload.cloneNode(true);
		x[i].parentNode.appendChild(clone);
		x[i].relatedElement = clone.getElementsByTagName('input')[0];		
	}
}


function updateNamesOfNewRow(newlyAddedRow , className, rowIndex, bindArrayName, bindFieldName, editFlag){
	var currentElement = newlyAddedRow.find(className);
	updateNames(currentElement, rowIndex, bindArrayName, bindFieldName);
	currentElement.val("");
	if(editFlag == "true"){
		currentElement.attr("disabled", false);
	}
}

function updateNames(currentElement, rowIndex, bindArrayName, bindFieldName){
	currentElement.attr('name', bindArrayName + '[' + rowIndex + '].' + bindFieldName);
	currentElement.attr('id', bindArrayName + rowIndex + '.' + bindFieldName);
}

function isEmpty(){
	
	var returnType = isEmptyInTable('geoParentTable', 'Parent Relationship');
	if( !returnType){
		returnType = isEmptyInTable('geoNameTable', 'Geographic Unit Name');
	}
	if( !returnType){
		returnType = isEmptyInTable('geoCodeTable', 'Geographic Unit Code');
	}
	return returnType;
}

function isEmptyInTable(tableName, displayLtrl){
	var returnType = false;
	$('#' + tableName + ' tr:visible').each(function(){
		$(this).find('.dropdown').each(function(){
			if(!($(this).is(':disabled'))){
				if($(this).val() == ''){
					returnType = true;
						$(this).focus();
						alert('Please enter all required fields for the ' + displayLtrl);
					return false;
				}
			}
		});

		if(!returnType){
			returnType = isElementOfClassEmpty($(this), '.textBox');
		}
		if(!returnType){
			returnType = isElementOfClassEmpty($(this), '.geoNameTxtField');
		}
		
		if(returnType){
			return false;
		}
	});

	return returnType;
}

function isElementOfClassEmpty(rowHandle, className){
	var returnType = false;
	var validRegex = /^[A-Za-z0-9\s'_,-.]+$/;
	rowHandle.find(className).each(function(){
		if(!($(this).is(':disabled'))){
			if($.trim($(this).val()) == ''){
				returnType = true;
				$(this).focus();
				if(className == '.geoNameTxtField')	{
					alert('Please enter all required fields for the Geographic Unit Name');
				}
				if(className == '.textBox')	{
				alert('Please enter all required fields for the Geographic Unit Code');
				}
				return false; 
			} 
		}	
	});
	return returnType;
}

function getDatepickerOptions(isDisabled){
	return {
		showOn: "button",
		buttonImage: "./resources/images/cal.png",
		buttonImageOnly: true,
		disabled: false,
		dateFormat: "yy-mm-dd"
	}
}

function selectallcheckboxes(ref){
	 if(ref.checked == true) {
			$('input[type=checkbox][name=systemList]').each(function() 	{ 
				this.checked = true;
			});
	 }
	 else if(ref.checked == false){
			$('input[type=checkbox][name=systemList]').each(function() { 
				this.checked = false;
			});	 
	 }
}

function selectallCountries(ref) {
	 if(ref.checked == true) {
		$('input[type=checkbox][name=countryList]').each(function()	{ 
				this.checked = true;
		});
	 }
	 else if(ref.checked == false) {
		$('input[type=checkbox][name=countryList]').each(function()	{ 
				this.checked = false;
		});	 
	 }	
}

function limitText(limitField, limitNum) {
    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
    } 
}

function deselectAllSystem(system){
	if(!$(system).is(":checked")){
		$('#allsystems').attr('checked',false); 
	}
}
function deselectAllCountry(country){
	if(!$(country).is(":checked")){
		$('#allcountries').attr('checked',false); 
	}
}
function deselectAllMarkets(country){
	if(!$(country).is(":checked")){
		$('#allMarkets').attr('checked',false); 
	}
}
function deSelectAllSystemAppys(system){
	if(!$(system).is(":checked")){
		$('#allSystems').attr('checked',false); 
	}
}
function deSelectAllCountryAppys(system){
	if(!$(system).is(":checked")){
		$('#allCountries').attr('checked',false); 
	}
}

function initializeNewRowDatePicker(newlyAddedGeoRow, className){
	newlyAddedGeoRow.find(className).removeClass('hasDatepicker');
	$(className).not('hasDatepicker').datepicker(getDatepickerOptions(false));
}

function initializeNewRowDatePick(newlyAddedGeoRow, className){
	newlyAddedGeoRow.find(className).removeClass('hasDatepicker');
	$(className).not('hasDatepicker').datepicker(getDatepickerOptions(false));
}

function getToday() {
	// On Screen load, default from and to date needs to be today
	var currentTime = new Date();
	var month = currentTime.getMonth() + 1;
	var day = currentTime.getDate();
	var year = currentTime.getFullYear();
	if (day < 10) {
		day = '0' + day;
	}
	if (month < 10) {
		month = '0' + month;
	}
	return year + "-" + month + "-" + day;
}

function populateChildSelectBox(parentGeoUnitId, childGeoUnitType,  childSelectBox, countryGeoUnitId){
	childSelectBox.attr('disabled', true);
	childSelectBox.empty();
	$.getJSON('retrieveChildGeoUnits.form', {
		parentGeoUnitId : parentGeoUnitId,
		childGeoUnitType : childGeoUnitType,
		countryGeoUnitId : countryGeoUnitId,
		ajax : 'true'
	}, function(data) {
		childSelectBox.append('<option value=""> -- Select -- </option>');
		 $.each(data, function() {
			 childSelectBox.append('<option value="' + this.code + '">' + this.value + '</option>');
		 }); 
		 childSelectBox.attr('disabled', false);
	});
}

function initializeDatepicker(){
	$('.geoDatepickerTextBox').removeClass('hasDatepicker').datepicker(getDatepickerOptions(true));
}

function bindclearExpirationDate(){
	$('.expirationDate').keydown(function(e){
		if (e.keyCode == 46 || e.keyCode == 8) {
			//Delete and backspace clear text
			$(this).val(''); //Clear text
		}
		//Prevent user from manually entering in a date - have to use the datepicker box         
		e.preventDefault();
	}); 
}

function convertDate(d) {
	var t = d.split(/\D+/) // splits on any character(s) between digits
	var dt = new Date();
	dt.setFullYear(t[0]);
	dt.setMonth(t[1]);
	dt.setDate(t[2]);
	return dt;
}

function showModalDialogForReject(){
	$('#reasonDiv').dialog({modal: true, resizable: false, 
		width: 225,
		beforeClose: function(event, ui) {
			$('#reason').val('');
		}
	});
}

function bindWorkQueueRejectBtn() {
	$('.showModalDialogForReject').on('click', function(){
		showModalDialogForReject();
	});
	
	$('#rejectProceedButton').bind('click', function(){
		if($("#reason").val()){
			completeTaskAjaxOthers(false);
			$('#reasonDiv').dialog('close');
			$('#alertSection').hide();
			$('#reasonDiv').hide();
		} else {
			alert('Reason for rejection is mandatory.');
			return false;
		}
	});
	
	$('#rejectCancelButton').bind('click', function(){
		$('#alertSection').hide();
		$('#reasonDiv').hide();
		$('#reasonDiv').dialog('close');
	});
	
	$('#rejectCancel').bind('click', function(){
		$('#alertSection').hide();
		$('#reasonDiv').hide();
		$('#reasonDiv').dialog('close');
	});
		
	$('#wQProceedButton').bind('click', function(){
		completeTaskAjax(false);
		$('#reasonDiv').dialog('close');
		return false;
	});
	
	$('#wQProceedCancel').bind('click', function(){
		$('#alertSection').hide();
		$('#reasonDiv').hide()
		$('#reasonDiv').dialog('close');
	});
}


function completeTaskAjax(approverDecision){
	$.getJSON('workQueueComplete.form', {
		taskId : $('#taskId').val(),
		trackingId : $('#trackingId').val(),
		submitterGroupId : $('#submitterGroupId').val(),
		approverDecision : approverDecision,
		approverComments : $('#dnbComment').val(),
		ajax : 'true'
	}, function(data) {
		if(data == true) {
			if(approverDecision){
				if($.trim($("#domainName").val()) == "Geography"){
					alert('The request has been Approved');
				}else{
					alert('The request has been Approved');
				}
			} else {
				alert('The request has been Rejected');
			}
			location.href = "approverWorkQueueHome.form?domainName=" + $('#domainName').val();
		} else {
			if (approverDecision) {
				alert('The Approve transaction failed');
			} else {
				alert('The Reject transaction failed');
			}
			location.href = "approverWorkQueueHome.form?domainName=" + $('#domainName').val();
		}
	});	
}

function completeTaskAjaxOthers(approverDecision){
	$.getJSON('workQueueComplete.form', {
		taskId : $('#taskId').val(),
		trackingId : $('#trackingId').val(),
		submitterGroupId : $('#submitterGroupId').val(),
		approverDecision : approverDecision,
		approverComments :  $('#reason').val()
	}, function(data) {
		if(data == true) {
			if(approverDecision){
				if($.trim($("#domainName").val()) == "Geography"){
					alert('The request has been Approved');
				}else{
					alert('The request has been Approved');
				}
			} else {
				alert('The request has been Rejected');
			}
			location.href = "approverWorkQueueHome.form?domainName=" + $('#domainName').val();
		} else {
			if (approverDecision) {
				alert('The Approve transaction failed');
			} else {
				alert('The Reject transaction failed');
			}
			location.href = "approverWorkQueueHome.form?domainName=" + $('#domainName').val();
		}
	});	
}

function bindWorkQueueApproveBtn() {
	$('#wQApproveButton').bind('click', function(){
		if(($.trim($("#domainName").val()) == "Industry Codes")
				||($.trim($("#domainName").val()) == "SCoTS")
			||($.trim($("#domainName").val()) == "Currency Exchange")
			||($.trim($("#domainName").val()) == "XML Schema Labels")
			||($.trim($("#domainName").val()) == "Control Words")
		                ||($.trim($("#domainName").val()) == "Financial Templates")
		                	||($.trim($("#domainName").val()) == "Geography")){
			completeTaskAjaxOthers(true)
		} else {
			completeTaskAjax(true);
		}
		return false;
	});
}

function calldscui(){	
    var base = document.URL;
    var dscuiServletContextPath = base.substr(0, base.indexOf(window.location.pathname)) + "/dscui-web";
    var dscuiUrl = dscuiServletContextPath + "/ajax/extendSession";
    $.ajax({
    	cache: false,
    	url : dscuiUrl,
    	dataType: "jsonp",
    	success: function () {
    		document.cookie = "lastInvokeTime" + "=" + new Date().getTime();    		
    	}    	
    }); 
    return false;
}
