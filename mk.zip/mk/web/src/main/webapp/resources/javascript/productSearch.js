$(document).ready(function(){
	bindScoreOverrideEvents();
	configureSearchDataTable();
	$('div.dataTables_wrapper').removeClass('dataTables_wrapper');	
	
});

function bindScoreOverrideEvents(){
	
	
	$('#productSearchSaveButton').bind('click',function(event) {
		
		if(!($("input:checkbox[name=marketCodeList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Product Market Code");
			$('#errorMsg').css("display","block");
		}
		else if(!($("input:checkbox[name=productList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Product");
			$('#errorMsg').css("display","block");
		}
		
		else{
		$('#errorMsg').hide();
		var arr = new Array();
		$('input:checkbox[name=productList]:checked').each(function() 
				{
			arr.push($(this).val());
				});
		var arrVal = new Array();
		$('input:checkbox[name=marketCodeList]:checked').each(function() 
				{
			arrVal.push($(this).val());
				});
		
		var arrVals = new Array();
		$('input:checkbox[name=resourceList]:checked').each(function() 
				{
			arrVals.push($(this).val());
				});
		
		if(arrVals.length > 0){
			productSearchResultsTable.fnFilter(arr + "#~" + arrVal + "#~" + arrVals);
		}
		else{
			productSearchResultsTable.fnFilter(arr + "#~" + arrVal);
		}
		$('#productSearchResults').show();
		$('#productSearchResult').show();	
		}
		
});
	
	$('#productSearchResetBtn').bind('click', function(){
		location.href = "productSearchHome.form";
		return false;
	});	
	
	$('#productSearchExportBtn').bind('click',function(){
		if(!($("input:checkbox[name=marketCodeList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Product Market Code");
			$('#errorMsg').css("display","block");
		}
		else if(!($("input:checkbox[name=productList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Product");
			$('#errorMsg').css("display","block");
		}		
		else{
		var criteriaString='';
		$('#errorMsg').hide();
		var arr = new Array();
		$('input:checkbox[name=marketCodeList]:checked').each(function() 
				{
			arr.push($(this).val());
				});
		var arrVal = new Array();
		$('input:checkbox[name=productList]:checked').each(function() 
				{
			arrVal.push($(this).val());
				});
		
		var arrVals = new Array();
		$('input:checkbox[name=resourceList]:checked').each(function() 
				{
			arrVals.push($(this).val());
				});
		
		if(arrVals.length > 0){
			$("#product_cd_export").val(arrVal);
			$("#mkt_cd_export").val(arr);
			$("#resc_cd_export").val(arrVals);
			$("#exportIndc").val("1");
		}
		else{
			$("#product_cd_export").val(arrVal);
			$("#mkt_cd_export").val(arr);
			$("#exportIndc").val("1");
		}
		
		}
		if(($("input:checkbox[name=marketCodeList]:checked").length > 0)){
			if(($("input:checkbox[name=productList]:checked").length > 0)){
				$('#productSearchForm').submit();
				hideSpinner();
			}
		}
	});

}

var productSearchResultsTable;
function configureSearchDataTable() {
	productSearchResultsTable = $("#productSearchResultsTable").dataTable(
			{
				"bServerSide" : true,
				"sAjaxSource" : "productSearchAjaxResult.form",
				"bProcessing" : false,
				"bSort": false,
				"sPaginationType" : "full_numbers",
				"oLanguage" : {
					"sEmptyTable" : "No data available",
					"sLengthMenu" : " _MENU_ items per page",
					"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
	                "sInfoEmpty": "No entries to show"
				},
				"sDom" : 'tlip',
				"aoColumns" : [ null, null, null, null, null,null,null,null,null,null, null, null, null, null,null,null,null,null,null, null, null, null, null,null,null,{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false } ],
				"fnRowCallback" : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
					 $(nRow).children("td").css("overflow", "hidden");
					 $(nRow).children("td").css("white-space", "nowrap");
					 $(nRow).children("td").css("text-overflow", "ellipsis");
					setHyperLinkOnProductSearchColumns(nRow, aData);
					return nRow;
				}
			});
}
function setHyperLinkOnProductSearchColumns(nRow, aData){
	$('td:eq(0)', nRow).html(getCodeColumnHtml(aData[0],aData[25],aData[26],aData[27],aData[28],aData[29],aData[30],aData[31],aData[32],aData[33],aData[34],aData[35]));
	$('td:eq(0)', nRow).css('text-align', 'center');
	//$('td:eq(0)', nRow).width("50%");
	$('td:eq(1)', nRow).width("50%");
	$('td:eq(1)', nRow).css('text-align', 'center');
	$('td:eq(2)', nRow).width("50%");
	$('td:eq(2)', nRow).css('text-align', 'center');
	$('td:eq(3)', nRow).width("50%");
	$('td:eq(3)', nRow).css('text-align', 'center');
	$('td:eq(4)', nRow).width("50%");
	$('td:eq(4)', nRow).css('text-align', 'center');
	$('td:eq(5)', nRow).width("50%");
	$('td:eq(5)', nRow).css('text-align', 'center');
	$('td:eq(6)', nRow).width("50%");
	$('td:eq(6)', nRow).css('text-align', 'center');
	$('td:eq(7)', nRow).width("50%");
	$('td:eq(7)', nRow).css('text-align', 'center');
	$('td:eq(8)', nRow).width("50%");
	$('td:eq(8)', nRow).css('text-align', 'center');
	$('td:eq(9)', nRow).width("50%");
	$('td:eq(9)', nRow).css('text-align', 'center');
	$('td:eq(10)', nRow).width("50%");
	$('td:eq(10)', nRow).css('text-align', 'center');
	$('td:eq(11)', nRow).width("50%");
	$('td:eq(11)', nRow).css('text-align', 'center');
	$('td:eq(12)', nRow).width("50%");
	$('td:eq(12)', nRow).css('text-align', 'center');
	$('td:eq(13)', nRow).width("50%");
	$('td:eq(13)', nRow).css('text-align', 'center');
	$('td:eq(14)', nRow).width("50%");
	$('td:eq(14)', nRow).css('text-align', 'center');
	$('td:eq(15)', nRow).width("50%");
	$('td:eq(15)', nRow).css('text-align', 'center');
	$('td:eq(16)', nRow).width("50%");
	$('td:eq(16)', nRow).css('text-align', 'center');
	$('td:eq(17)', nRow).width("50%");
	$('td:eq(17)', nRow).css('text-align', 'center');
	$('td:eq(18)', nRow).width("50%");
	$('td:eq(18)', nRow).css('text-align', 'center');
	$('td:eq(19)', nRow).width("50%");
	$('td:eq(19)', nRow).css('text-align', 'center');
	$('td:eq(20)', nRow).width("50%");
	$('td:eq(20)', nRow).css('text-align', 'center');
	$('td:eq(21)', nRow).width("50%");
	$('td:eq(21)', nRow).css('text-align', 'center');
	$('td:eq(22)', nRow).width("50%");
	$('td:eq(22)', nRow).css('text-align', 'center');
	$('td:eq(23)', nRow).width("50%");
	$('td:eq(23)', nRow).css('text-align', 'center');
	$('td:eq(24)', nRow).width("50%");
	$('td:eq(24)', nRow).css('text-align', 'center');
}

function getCodeColumnHtml(value1,value2,value3,value4,value5,value6,value7,value8,value9,value10,value11,value12){
	return "<a href='editProductSearch.form?prdID=" + value1 + "&prodAvailId="+value2+"&saleChnlid="+value3+"&prodMktId="+value4+"&rescMapId="+value5+"&rescId="+value6+"&prodGrpId="+value7+"&prodDtlId="+value8+"&mktGrpId="+value9+"&rescGrpId="+value10+"&rescDtlID="+value11+"&slsChnlDtlID="+value12+"'>" + value1 + "</a>";
}


function selectoneMktCodeList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallMktCodeList(ref) {
	if (ref.checked == false) {
		$("#allmktCode").prop("checked", false);
	}
}
function selectallMktCodeList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			this.checked = false;
		});
	}
}

function selectoneproductList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=productList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallproductList(ref) {
	if (ref.checked == false) {
		$("#allproduct").prop("checked", false);
	}
}
function selectallproductList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=productList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=productList]').each(function() {
			this.checked = false;
		});
	}
}

function selectoneresourceList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=resourceList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallresourceList(ref) {
	if (ref.checked == false) {
		$("#allresource").prop("checked", false);
	}
}
function selectallresourceList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=resourceList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=resourceList]').each(function() {
			this.checked = false;
		});
	}
}
