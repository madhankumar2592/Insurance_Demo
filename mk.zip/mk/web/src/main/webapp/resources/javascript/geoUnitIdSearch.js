/**
 * This file serves geoUnitIdSearch.jsp
 */
$(document).ready(function(){
	bindGeoUnitIdSearchEvents();
	initializeGeoUnitIdSearchElements();
});

function bindGeoUnitIdSearchEvents(){
//	$('#geoUnitIdSearchLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "geoUnitIdSearch.form?id=";
//		return false; // to prevent event bubbling
//	});
	
	$('#geoUnitIdSearchBtn').bind('click',function(event){
		getGeoUnitIdResults();
	});
}

function initializeGeoUnitIdSearchElements() {
	var searchId = $("#geoUnitIdValue").val();
	var resultsIndc = $('#resultsIndicator').val();
	if(resultsIndc == 'false') {
		$("#geoUnitIdText").val(searchId);
		$("#errorGeoMsg").html("No search results available for Geo Unit ID " + searchId);
		$('#errorGeoMsg').show();
	}
}

function getGeoUnitIdResults() {
	var geoUnitId = $.trim($("#geoUnitIdText").val());
	if(geoUnitId != ""){
		if(isValidGeoUnitId(geoUnitId)) {
			$('#errorGeoMsg').hide();
			showSpinner();
			location.href = "geoUnitIdSearch.form?id=" + geoUnitId;
			return false; // to prevent event bubbling			
		} else {
			$("#errorGeoMsg").html("Only numerics are allowed in Geo Unit ID field");
			$('#errorGeoMsg').show();
		}
	} else {
		$("#errorGeoMsg").html("Geo Unit ID is mandatory for search");
		$('#errorGeoMsg').show();
	}
}

function isValidGeoUnitId(inputStr) {
	var validRegex = /^[0-9]+$/gi;
	if (!validRegex.test($.trim(inputStr))) {
		return false;
	} else {
		return true;
	}
}

