/**
 * This file serves countryGroupSearch.jsp
 */

$(document).ready(function(){
	bindCountrySearchEvents();
	initializeCountryGrpElements();
	configureCountryGrpSearchDataTable();
});

function bindCountrySearchEvents(){
//	$('#countryGroupsLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "countryGroupSearchHome.form";
//		return false; // to prevent event bubbling
//	});
	$('#geoFromCtryGrpSearch').bind('click',function(event){
		event.preventDefault();
		location.href = "geoSearchHome.form";
		return false; // to prevent event bubbling
	});
	$('#countryGroupSearchBtn').bind('click',function(event){
		if($.trim($('#countryGroupSelect').val()) == ""){
			$('#errorMsg').css("display","inline");
			$('#searchResults').css("display","none");
		} else {
			showSpinner();
			var geoUnitId = $.trim($('#countryGroupSelect').val());
			$('#errorMsg').css("display","none");
			location.href = "countryGroupSearch.form?geoUnitId=" + geoUnitId;
		}
	});
}

function configureCountryGrpSearchDataTable(){
	$("#ctryGrpSearchResultsTable").dataTable({
		"sDom": 'tlip',
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
		"iDisplayLength": 10, 
		"aLengthMenu": [5, 10, 25, 50, 100],
		"sPaginationType": "full_numbers"
	});
}

function initializeCountryGrpElements(){
	if($.trim($('#geoUnitId').val()) == 0){
		($('#countryGroupSelect').val($.trim($('#geoUnitId').val())));
	}
	if($.trim($('#geoUnitId').val()) == ''){
		$('#searchResults').css("display","none");
	}else{
		$('#searchResults').css("display","inline");
	}
}
