$(document).ready(function(){
	headerFixer();
});

function headerFixer(){
	
	var tableOffset = $("#productSearchResultsTable").offset().top;
	var $header = $("#productSearchResultsTable > thead").clone();
	var $fixedHeader = $("#header").append($header);

	$(window).bind("scroll", function() {
	    var offset = $(this).scrollTop();
	    
	    if (offset >= tableOffset && $fixedHeader.is(":hidden")) {
	        $fixedHeader.show();
	    }
	    else if (offset < tableOffset) {
	        $fixedHeader.hide();
	    }
	});
}