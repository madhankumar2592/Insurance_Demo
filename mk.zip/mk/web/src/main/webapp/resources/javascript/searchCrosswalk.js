/**
 * This file serves allSearch.jsp in globalElement
 */

$(document).ready(function() {
	 $.ajaxSetup({ cache: false });
	configureCrosswlkSearchDataTable();	
	bindCrosswlkSearchEvents();
	if($("#updateCroswalkSuccess").val()){
		alert("Global Element Crosswalk is added in Reference Data successfully");
	}
});
	
function bindCrosswlkSearchEvents(){
	$('#crosswalkApplied').bind('change',function(){
	if($.trim($(this).val()) != '') {
		populateDataPlatformValues($(this).val());
		}
	});

	$('#crosswalkSearchBtn').bind('click',function(event) {		
		var regex=/^[0-9]+$/;
		if($('#elementId').val() != ""){
		
			if(!$('#elementId').val().match(regex)){
				$('#errorMsg').html("Element Id should contain only digits");
					 $('#errorMsg').show();
		}else{
			var searchCriteriaDelimiter = "#~";
			$('#errorMsg').hide();	
			crosswalkSearchResultsTable.fnFilter($('#elementId').val()+searchCriteriaDelimiter+$('#crosswalkApplied').val()+searchCriteriaDelimiter+$('#metadataValue').val()+searchCriteriaDelimiter+$('#dataPlatformCodeCrosswalk').val());
			$('#crosswalkSearchResults').show();	
			$('#crosswalkExportBtn').show();	
		}		
	}else{
			var searchCriteriaDelimiter = "#~";
			$('#errorMsg').hide();	
			crosswalkSearchResultsTable.fnFilter($('#elementId').val()+searchCriteriaDelimiter+$('#crosswalkApplied').val()+searchCriteriaDelimiter+$('#metadataValue').val()+searchCriteriaDelimiter+$('#dataPlatformCodeCrosswalk').val());
			$('#crosswalkSearchResults').show();	
			$('#crosswalkExportBtn').show();	
		}	
	
	});

	$('#crosswalkExportBtn').bind('click',function(event) {	
		var searchCriteriaDelimiter = "#~";
		var criteriaString=encodeURIComponent($('#elementId').val()+searchCriteriaDelimiter+$('#crosswalkApplied').val()+searchCriteriaDelimiter+$('#metadataValue').val()+searchCriteriaDelimiter+$('#dataPlatformCodeCrosswalk').val());	
		location.href = "allCrosswalkSearchExportToExcelResultsBkp.form?type=export&sSearch="+criteriaString+"&time="+new Date().getTime();	
		return false; // to prevent event bubbling
	});	
}
function populateDataPlatformValues(crosswalkApplied) {
	
	$.getJSON('retrieveDetailsSearchCrosswalk.form', {
		crosswalkAppliedParam : crosswalkApplied,
		ajax : 'true'
	}, function(data) {
		$("#dataPlatformCodeCrosswalk").removeAttr('disabled');
		$("#dataPlatformCodeCrosswalk").empty();
		$("#dataPlatformCodeCrosswalk").append('<option value="">-- Global Element Meta Data Platform --</option>');
		$.each(data, function() {
			 $("#dataPlatformCodeCrosswalk").append('<option value="' + this.codeValueId + '">' + "["+ this.codeValueId +"] "+ this.codeValueDescription + '</option>'); 
		});
	});
}

var crosswalkSearchResultsTable;
function configureCrosswlkSearchDataTable(){
	crosswalkSearchResultsTable = $("#crosswalkSearchResultsTable").dataTable({
	
        "bServerSide": true,
        "sAjaxSource": "crosswalkSearchAjaxResults.form",
        "bProcessing": false,		
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aaSorting": [],
        "aoColumns": [null,null, { "bVisible": false },null,null,{ "bVisible": false },null,null],
        "fnRowCallback" : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
			if($('#metadataValue').val() != ""){
				$('td:eq(3)', nRow).highlight($('#metadataValue').val());
			}				
			if($('#elementId').val() != ""){
				$('td:eq(0)', nRow).highlight($('#elementId').val());
			}
			setHyperLinkOnGlobalCrosswalkSearchColumns(nRow, aData);
			return nRow;
		}
  });
}

function setHyperLinkOnGlobalCrosswalkSearchColumns(nRow, aData){
	$('td:eq(0)', nRow).html(getElementEditColumnHtml(aData[0]));
	$('td:eq(0)', nRow).css('text-align', 'left');
	$('td:eq(1)', nRow).html(getCrosswalkColumnHtml(aData[0],aData[1]));
	$('td:eq(1)', nRow).css('text-align', 'left');		
	
}

function getElementEditColumnHtml(value1){
	return "<a href='editGlobalElementSearch.form?elementID=" + value1 + "'>" + value1 + "</a>";
}
function getCrosswalkColumnHtml(value1,value2){
	return "<a href='editGlblEleCrosswalk.form?crosswalkId=" + value2 + "&elementID=" + value1 + "'>" + value2 + "</a>";
}

function validateIsNumber(event){
	
	var charCode = (event.which) ? event.which : event.keyCode;
    if (charCode == 46 && event.srcElement.value.split('.').length>1) {
        return false;
    }
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    if(charCode == 13)
    	return false;
    return true;
}
