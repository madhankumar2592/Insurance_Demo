/**
 * 
 */
$(document).ready(function(){
	bindAddIndustryCodeInfermentEvents();
	setUserTypeAddIndustryCodeInfer();
	industryCodeFocusOut();
	
});

function setUserTypeAddIndustryCodeInfer(){
	if($(".location").val()=='addIndustryCodeInfer') {		
		if ($.trim($('#sourceQueue').val()) == 'approver') {
			$('.userViewIndsInfer').hide();
			$('.workQueueViewAddIndsInfer').add('#approverButtonsSectionLegal').show();
	} else if ($.trim($('#sourceQueue').val()) == 'submitter') {
			$('.userViewIndsInfer').hide();
			$('.workQueueViewAddIndsInfer').show();
	} else {
			$('.workQueueViewAddIndsInfer').hide();
		}
	}
}

function bindAddIndustryCodeInfermentEvents(){
	
//	$('#addIndustryCodeInfermentLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "addIndsCodeInfermentHome.form";
//		return false; // to prevent event bubbling
//	});
	
	$("#addIndustryCodeInfermentSubmitButton").click(function() {
		if(isValidIndustryCodeForm()) {
			$("#errorMsg").hide();
			$(".btn").attr("disabled");
			$("#addIndustryCodeInfermentForm").submit();
		}
	});
	
	$('#addIndustryCodeInfermentResetButton').bind('click',function(event){
		event.preventDefault();
		$(".reset").val("");
		$(":checkbox").removeAttr("checked");
		return false; // to prevent event bubbling
	});
}

function isValidIndustryCodeForm() {
	if(!$("#infermentText").val()) {
		$("#errorMsg").html("Please Enter Inferment Text");
		$("#errorMsg").show();
		$("#infermentText").focus();
		return false;
	}
	if ($("#addIndustryCodeInfermentLanguageSelect").val()=="") {
		$("#errorMsg").html("Please Select Language Code");
		$("#errorMsg").show();
		$("#addLegalFormLanguageSelect").focus();
		return false;
	}
	var checked = 0;
	$(".inferment_countries").each(function(){
		if($(this).attr("checked")) {
			checked = 1;
		}
	});
	if(checked==0) {
		$("#errorMsg").html("Please Select Country Applicability");
		$("#errorMsg").show();
		$("#allCountries").focus();
		return false;
	}
	var selected=1;

	$(".industryInfermentClassCode").each(function(){		
		if($(this).val()==''){
			$("#errorMsg").html('Please Select Industry Code Type');
			$("#errorMsg").show();
			selected=0;			
			$(this).focus();
			return false;
		}
		
	});
	
	if(selected == 0){
		return false;
	}
	
	$(".industryCode").each(function(){
		if($(this).val()==''){
		$("#errorMsg").html('Please select Industry Code');
		$("#errorMsg").show();
		selected=0;
		$(this).focus();
		return false;
		}
	});
	
	if (selected==1) {
		return true;
	}
}

function removeIndustryInfrRow(removeHandle, rowIndexToDelete){
	
	$(removeHandle).closest('tr').remove();
		$('#industryCodeinfermentTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.industryInfermentClassCode'), (this.rowIndex - 1), 'industryCodeList', 'industryCodeTypeCode');
			updateNames($(this).find('.industryCode'), (this.rowIndex - 1), 'industryCodeList', 'industryCode');
			updateNames($(this).find('.industryDescription'), (this.rowIndex - 1), 'industryCodeList', 'industryCodeDescriptions[0].industryDescription');
			
			$(this).find('.removeIndustryInfermentRowLink').html($(this).find('.removeIndustryInfermentRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function addIndustryCodeInfrNewRow(){
	var nextIndex = $(".industryInfermentClassCode").length;
	$('#industryCodeinfermentTable').append($('#industryCodeinfermentTable tr:last').clone());
	var newlyAddedInfermentRow = $('#industryCodeinfermentTable tr:last');	
	industryCodeFocusOut();
	
	updateNamesOfNewRow(newlyAddedInfermentRow , '.industryInfermentClassCode', nextIndex, 'industryCodeList', 'industryCodeTypeCode', "false");
	updateNamesOfNewRow(newlyAddedInfermentRow , '.industryCode', nextIndex, 'industryCodeList', 'industryCode', "false");
	updateNamesOfNewRow(newlyAddedInfermentRow , '.industryDescription', nextIndex, 'industryCodeList', 'industryCodeDescriptions[0].industryDescription', "false");
	
	newlyAddedInfermentRow.find('.removeIndustryInfermentRowLink').html('<a href="#" style="text-decoration: none;" onclick="removeIndustryInfrRow(this,' + nextIndex + ');">[-]</a>');
}

function industryCodeFocusOut(){
	$('.industryCode').on('focusout', function(){
		var industryCodeTypeCode = $(this).closest('tr').find('.industryInfermentClassCode').val();				
		var industryCode = $(this).val();
		if(($.trim(industryCode) == '') || ($.trim(industryCodeTypeCode) == '') ){
			return false;
		}
		getDescriptionForCodeTypeCodes(industryCodeTypeCode, 
				industryCode, $(this).closest('tr').find('.industryDescription'), $('#errorMsgIndustryCodeInfer'),$('#industryUpdateButton'),true);		
	});
}