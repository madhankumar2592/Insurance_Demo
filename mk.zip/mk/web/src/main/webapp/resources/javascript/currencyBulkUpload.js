/**
 * This file serves currencyBulkUpload.jsp
 *  
 */
$(document).ready(function(){
	bindCurrencybulkUpload();	
});

function bindCurrencybulkUpload()
{
//	$('#currencyBulkUploadLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "currencyBulkUpload.form";
//		return false; // to prevent event bubbling
//	});
}
function currencyvalidateUpload()
{
	
	if(document.getElementById('currencyupload').value == "" ||document.getElementById('currencyupload').value == null)
	{
		alert('Select a file to upload');
		document.getElementById('currencyupload').focus();
	}
	else
	{
		var fup = document.getElementById('currencyupload').value;	
		var ext = fup.substring(fup.lastIndexOf('.') + 1);
		if(ext == "xlsx")
		{
			
			$('#currencyBulkUploadForm').submit();			
			document.getElementById('currencyupload').focus();
			alert("The New records have been added to the stage system and should be routed for approval");	
			return true;
		} 
		else
		{						
			alert("Please upload only xlsx files");	
			document.getElementById('currencyupload').value="";
			document.getElementById('bulktext').value="";				
			return false;
		}			
	}
}
