$(document).ready(function(){
	bindScotsbulkUpload();	
});

function bindScotsbulkUpload()
{
//	$('#scotsBulkUploadLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "scotsBulkUpload.form";
//		return false; // to prevent event bubbling
//	});
}


function validatescotsUpload()
{
	var fup = document.getElementById('scotsupload').value;	
	var ext = fup.substring(fup.lastIndexOf('.') + 1);
	if(ext == "xlsx")
	{			
		$('#scotsBulkUpload').submit();			
		document.getElementById('scotsupload').focus();
		alert("The New records have been added to the stage system and should be routed for approval");	
		return true;
	} 
	else
	{						
		alert("Please upload only xlsx files");	
		document.getElementById('scotsupload').value="";
		document.getElementById('bulktext').value="";				
		return false;
	}	

}