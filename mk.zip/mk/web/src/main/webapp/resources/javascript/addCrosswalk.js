$(document).ready(function(){
	 $.ajaxSetup({ cache: false });
	bindAddGlobalElementEvents();
});

function bindAddGlobalElementEvents(){
	
	$('#searchElementID').bind('click',function() {
		$('#errorMsg').hide();
		var regex=/^[0-9]+$/;
		if($('#elementID').val() != ""){
			
		if(!$('#elementID').val().match(regex)){
			$('#errorMsg').html("This GEID# should contain only digits");
			 $('#errorMsg').show();
		}else{
		var elemntName = checkElementID($('#elementID').val());	
			 	 
		 if(elemntName != null && elemntName != "false"){
			 if(elemntName.indexOf(",") > -1){
				 var name = elemntName.split(',');
				 $('#elementName').val(name[0]);
				 $('#elementName').attr("style", "visibility: visible");
				 $('#eleName').attr("style", "visibility: visible");
				 $('#errorMsg').html("This GEID exists in the crosswalk table. Please use the edit screen to modify existing values or create new crosswalk data for this GEID");
				 $('#errorMsg').show();				
			 }else{
				 $('#elementName').val(elemntName);
				 $('#elementName').attr("style", "visibility: visible");	
				 $('#glblEleDataPlatfrm').removeAttr("disabled");
				 $('#glblEleType').removeAttr("disabled");				 
			 }			 
		 }
		 else{
			 $('#errorMsg').html("This GEID# does not exist, Please enter the valid Element ID");
			 $('#errorMsg').show();
		 }
		}
		}else{
			  $('#errorMsg').html("Please enter the Element ID");
				 $('#errorMsg').show();
		}
	});
	
	$('#glblEleDataPlatfrm').change(function(){
		if(($.trim($('#elementID').val()) != '')&&($.trim($('#glblEleDataPlatfrm').val()) != '')){
			var glblDetaPlatfrm = $('#glblEleDataPlatfrm').val();			
			populateMetadataCodes(glblDetaPlatfrm);
		}
	});
	
	$('#addCwlkResetButton').bind('click',function(event){
		
		var elemntId = $('#elementID').val();
		
		if(confirm("Are you sure you want to reset the data?")) {
			event.preventDefault();
			location.href = "glblEleCrosswalk.form?" ;
			return false; // to prevent event bubbling
		}
	});
	
		
}

function validateAndSubmit(){	
$('#errorMsg').hide();	
	

	if($('#glblEleDataPlatfrm').val() == ""){
		$('#errorMsg').html("Please select Data Platform");
		$('#errorMsg').show();
	}else if($('#glblEleType').val() == ""){
		 $('#errorMsg').html("Please select Element Type");
		 $('#errorMsg').show();
	}else if(!isAddValueEmpty('.globalElementMetadataCode')) {
		$('#errorMsg').html("Please select the Metadata code");
		$('#errorMsg').show();
	}else if(!isAddValueEmpty('.globalElementMetadataValue')) {
		$('#errorMsg').html("Please enter the Metadata value");
		$('#errorMsg').show();
	}else if(!isGroupEmpty('.globalElementCrosswalkGrpNme')){
		$('#errorMsg').html("Please enter group name");
		$('#errorMsg').show();
	}else if(!isGroupNameExist('.globalElementCrosswalkGrpNme')){
		$('#errorMsg').html("Entered Group Name already exists for an Element");
		$('#errorMsg').show();
	}else{
		if(confirm("Are you sure you want to Add Global Element ")) {
		$('#addCrosswalk').submit(); 	
		}
		return true;
	}
}

function isGroupEmpty(ele) {
groupEmpty = true;

	$('#attributeDetailTable').find(ele).each(function() {
		if($(this).val() == '') {
			$(this).focus();
			groupEmpty = false;
			return false;
		} 
	});
	
return groupEmpty;
}


/*function isGroupValid() {
validGrp = true;
var cnt = 0;
var checkGrpName = new Array();
	$('.globalElementCrosswalkGrpNme'+cnt+'').each(function() {
		cnt++;		
		checkGrpName.push($(this).val());			
		for(i=1;i<checkGrpName.length;i++){
			if(checkGrpName[i] != checkGrpName[i-1]){
				validGrp = false;
				$('#errorMsg').html("Group name should be same for a given Element");
				$('#errorMsg').show();
			}
		}
	});		
	
return validGrp;
}*/

function isGroupNameExist(ele){   
	var cnt = 0;	
	var result = true; 
	var checkGrpName = new Array();
  $('#attributeDetailTable').find(ele).each(function() { 
	  	cnt++;			
		var param = {globalElementCrosswalkGrpNme: $(this).val(), globalElementId: $('#elementID').val()};
		  $.ajax({
		        cache: false,
		        async: false,
				traditional : true,
		        type : "POST",
		        url : "checkGroupNameUnique.form",       
				data : param,
				success : function(data) { 					
		              checkGrpName.push(data);
		        }                 
		  });  
  });

 for(i=0;i<checkGrpName.length;i++){
	if(checkGrpName[i] == false){
		result = false;
	}
 }
  
  return result;
}




function checkElementID(elementId){
	var result;
	var param = {globalElementId: elementId}	
	 $.ajax({
		 cache: false,
		 async: false,
		 url : "checkElementID.form",		 
        data : param,
        success : function(data) {       	  	
			result = data;
		}			
	 });	
	 return result;
}
		

function populateMetadataCodes(glblDetaPlatfrm){
	$.getJSON('retrieveDetails.form',{
		globalElementPlatformCode: glblDetaPlatfrm
	}, function(data) {   			
        	var trHTML = '';
			$("#attributeDetails").css("display","block");	
			var cnt = 0;
			$.each(data, function() {
				$('#metadropdown').append('<option value="' + this.metadataCode + '">' + this.metadataCode + " [ " + this.metadataValue + " ] " + '</option>');
			});
		});
}


function addMetaDataRow(){
	var nextIndex = $(".globalElementMetadataCode").length;
	
	//scoreGranularity
	var max = null;
	$( "input[name^='globlalElementCrossWalk']" ).each(function() {
		var name =this.name.match(/\d+/);	
		//alert(name);		
		if (max === null || Number(name) > Number(max)){
			max = name;
			//max = Number(max)+1;
			}
	});
	//alert(max);
	nextIndex = Number(max)+1;
	
	$('#attributeDetailTable').append($('#attributeDetailTable tr:last').clone());
	var newlyAddedMetadataRow = $('#attributeDetailTable tr:last');
	updateNamesOfNewRow(newlyAddedMetadataRow , '.globalElementMetadataCode', nextIndex, 'globlalElementCrossWalk', 'globalElementMetadataCode', "true");	
	updateNamesOfNewRow(newlyAddedMetadataRow , '.globalElementMetadataValue', nextIndex, 'globlalElementCrossWalk', 'globalElementMetadataValue', "true");
	updateNamesOfNewRow(newlyAddedMetadataRow , '.globalElementCrosswalkGrpNme', nextIndex, 'globlalElementCrossWalk', 'globalElementCrosswalkGrpNme', "true");
	updateNamesOfNewRow(newlyAddedMetadataRow , '.changeIndicator', nextIndex, 'globlalElementCrossWalk', 'changeIndicator', "true");

	$('#attributeDetailTable').find('tr:last').find('.removeMetadataRowLink').
	html('<a href="javascript:;" style="text-decoration: none;" onclick="removeMetadataRow(this,' + nextIndex + ');">[-]</a>');
	newlyAddedMetadataRow.find('.changeIndicator').val('NEW');	
	newlyAddedMetadataRow.show();
	return false;

}

function removeMetadataRow(removeHandle, rowIndexToDelete){
	if($('.globalElementMetadataCode:visible').length ==1){
		alert("At least one Description is mandatory");
		return false;
	}
	 if($(removeHandle).closest('tr').find('.changeIndicator').val()=='NEW') {
		$(removeHandle).closest('tr').remove();
	}
	//alert(rowIndexToDelete);
	//alert(this.rowIndex);
	$('#attributeDetailTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.globalElementMetadataCode'), (this.rowIndex - 1), 'globlalElementCrossWalk', 'globalElementMetadataCode');
			updateNames($(this).find('.globalElementMetadataValue'), (this.rowIndex - 1), 'globlalElementCrossWalk', 'globalElementMetadataValue');
			updateNames($(this).find('.globalElementCrosswalkGrpNme'), (this.rowIndex - 1), 'globlalElementCrossWalk', 'globalElementCrosswalkGrpNme');
			updateNames($(this).find('.changeIndicator'), (this.rowIndex - 1), 'globlalElementCrossWalk', 'changeIndicator');
			

			$(this).find('.removeMetadataRowLink').html($(this).find('.removeMetadataRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function validateIsNumber(event){
	
	var charCode = (event.which) ? event.which : event.keyCode;
    if (charCode == 46 && event.srcElement.value.split('.').length>1) {
        return false;
    }
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    if(charCode == 13)
    	return false;
    return true;
}

function isAddValueEmpty(ele) {
	var hasValue = true;
	$('#attributeDetailTable').find(ele).each(function() {
		if($.trim($(this).val()) == '' || $(this).val() == '') {
			$(this).focus();
			hasValue = false;
			return false;
		} 
	});
	return hasValue;
}
