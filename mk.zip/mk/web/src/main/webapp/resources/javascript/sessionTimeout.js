//this timer handler is used for timeout dialog
var timeoutDialogTimerHandler;
// this time handler is used for user response for the dialog
var timeoutDialogRespTimerHandler;
// this is used to check that use clicks ok button from another tab/window
var timeoutDialogRespTimerHandlerChecker;

//this timeout value is used for timeout dialog
var timeoutDialogTimerVal;
//this timeout value is used for user response for the dialog
var timeoutDialogRespTimerVal;

var count;

function initSessionManagement(params){	
	timeoutDialogTimerVal = parseInt(params['maxSessionTimeoutValue']);	
	
	timeoutDialogRespTimerVal = 300000; // 5 minutes
	setCookie("lastInvokeTime", new Date().getTime());
	timeoutDialogTimerVal = parseInt(params['maxSessionTimeoutValue']) * 1000 - timeoutDialogRespTimerVal - 1000;
		
	// setup the timer for the dialog
	timeoutDialogTimerHandler = setTimeout(extendSessionDialog, timeoutDialogTimerVal);
	
	$(document).ajaxSend( // for all other ajax call, resetTimer
			  function(event,request,settings){
				if (!settings.url.match(/extendSession$/)) {
					// reset timer					
					clearTimeout(timeoutDialogTimerHandler);
					setCookie("lastInvokeTime", new Date().getTime());					
					timeoutDialogTimerHandler = setTimeout(extendSessionDialog, timeoutDialogTimerVal);
				}
			  }
		);
}

function extendSessionDialog() {	
	clearTimeout(timeoutDialogTimerHandler);
	
	// read last invoking time and current time millis
	var lastInvokeTime = parseInt(getCookie("lastInvokeTime"));	
	var interval = new Date().getTime() - lastInvokeTime;
	if (interval < timeoutDialogTimerVal) {
		// user invoked some actions before timeout dialog
		timeoutDialogTimerHandler = setTimeout(extendSessionDialog, timeoutDialogTimerVal - interval);
		return;
	}
	
	// setup timer for the response time
	timeoutDialogRespTimerHandler = setTimeout(timeoutLogout, timeoutDialogRespTimerVal);
	timeoutDialogRespTimerHandlerChecker = setInterval(function() {
		var lastInvokeTime = parseInt(getCookie("lastInvokeTime"));
		if (lastInvokeTime == 0) { // this means cancel and goes to login page
			$(".ui-dialog button:last").trigger('click');
		}
		else {
			var interval = new Date().getTime() - lastInvokeTime;
			if (interval < timeoutDialogTimerVal) {
				$(".ui-dialog button:first").trigger('click');
			}
		}
	}, 50);
	
	$( "#sessionTimeoutDiv" ).dialog({
        modal: true,
        resizable: false,
        closeOnEscape: false,
        width: '500px',
        position: ['center', 100],
		open: function() {
			if ($("#countdownTimer").size() == 0) {
				$('<span id="countdownTimer" style="position: absolute; right: 0.3em; padding: 1px; padding-right: 3px;"></span>').appendTo($(this).prev());
			}
        	
			count = timeoutDialogRespTimerVal / 1000;
			countDown();
        },
        buttons: [
                {
                    text: "Ok",
                    click: function() {
                        $( this ).dialog( "close" );                        
                        $.ajax({
                        	cache: false,
                        	url: "extendSession.form"
                        }).success(function () {   
                        	clearInterval(timeoutDialogRespTimerHandlerChecker);
                    		count = 0;
                    		// stop timer for response time
                	  		clearTimeout(timeoutDialogRespTimerHandler);
                	  		// setup the timer for the dialog
                	  		timeoutDialogTimerHandler = setTimeout(extendSessionDialog, timeoutDialogTimerVal);
                	  		setCookie("lastInvokeTime", new Date().getTime());   
                        });
                    	                                                  
                      return false;
                  }
              },
              {
			    text: "Cancel",
			    click: function() {
			    	clearInterval(timeoutDialogRespTimerHandlerChecker);
			        $( this ).dialog( "close" );			        
			        if (parseInt(getCookie("lastInvokeTime")) == 0) {			        	
			        	timeoutLogout();
			        }
			        else {
			        	setCookie("lastInvokeTime", "0"); // 0 means session is timesout			        	
			        	// logout
			        	timeoutLogout();
			        }
			        
			        return false;
			    }
			}
        ]
    });
}

function countDown() {
	if (count > 0) {
		setTimeout(countDown, 1000);
	}

	var minutes = Math.floor(count / 60);
	var seconds = count - minutes * 60;
	count --;
	
	var time = new Date();
	time.setMinutes(minutes);
	time.setSeconds(seconds);
	
	$("#countdownTimer").html(formatNumber(minutes) + ":" + formatNumber(seconds));	
}

function formatNumber(num) {
	if (num < 10) {
		return "0" + num;
	}
	
	return num;
}

function setCookie(c_name, c_value) {
	document.cookie=c_name + "=" + c_value;
}

function getCookie(c_name) {
	var i,x,y,ARRcookies=document.cookie.split(";");
	for (i=0;i<ARRcookies.length;i++) {
		x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
		y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
		x=x.replace(/^\s+|\s+$/g,"");
		if (x==c_name) {
			return unescape(y);
		}
	}
}

function timeoutLogout() {
	window.close();
}
