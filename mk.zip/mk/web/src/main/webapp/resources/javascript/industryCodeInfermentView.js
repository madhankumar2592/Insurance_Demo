/**
 * 
 */

$(document).ready(function() {
	bindIndustryCodeInfermentViewEvents();

});

function bindIndustryCodeInfermentViewEvents(){
	
	$("#industryCodeInfermentEditButton").click(function() {
		 if($(this).val()=="Edit") {
			$('#errorBlock').hide();
			$.getJSON('lockInfermentTextForEdit.form', {
				ajax : 'true'
			}, function(data) {
				if(data == true) {
					$('#errorMsg').html('The record is locked by another user due to a pending request on the Work Queue.');
					$('#errorMsg').show();
					return false; //to prevent event bubbling
				} else if(data!=null){
					enableEditInfermentText();
					return false; //to prevent event bubbling
				}
			});
		}
	});
	$('#industryCodeInfermentCancelButton').bind('click',function(event) {
		event.preventDefault();
		location.href = "indsCodeInfermentSearchHome.form";
		return false; // to prevent event bubbling
	});
	
	$('#industryCodeInfermentBack').bind('click',function(event){
		event.preventDefault();
		location.href = "indsCodeInfermentSearchHome.form";
		return false; // to prevent event bubbling
	});	
	
	
}

function enableEditInfermentText(){
	$(".showable").show();
	$("#initialCountries").hide();
	$("#editCountries").show();
	$("#pageTitle").html('Industry Code Inferment - Edit');
	$("#industryCodeInfermentEditButton").val('Update');
	$(".editable").removeAttr("disabled");	
	$("#industryCodeInfermentEditButton").click(function() {
		if(isIndustryCodeInfermentEmpty()){
			return false;
		}
		$("#industryFormInfermentForm").submit();
	});
	
}

function isIndustryCodeInfermentEmpty(){
	var returnType = false;
		if($('#industryCodeInfermentTable').find('.toIndustryCodeTypeCode').length > 1) {
			returnType = isEmptyInTable('industryCodeInfermentTable', 'Industry Code Inferment');
		} else if ($('#industryCodeInfermentTable').find('.industryCode').eq(0).val() != '') {
			returnType = isEmptyInTable('industryCodeInfermentTable', 'Industry Code Inferment');
		}
	 
	return returnType;
}


function removeIndustryInfermentRow(removeHandle, rowIndexToDelete){
	
	$(removeHandle).closest('tr').remove();
	
	$('#industryCodeInfermentTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.industryCodeTypeCode'), (this.rowIndex - 1), 'industryCodeList', 'industryCodeTypeCode');
			updateNames($(this).find('.industryCode'), (this.rowIndex - 1), 'industryCodeList', 'industryCode');
			updateNames($(this).find('.industryDescription'), (this.rowIndex - 1), 'industryCodeList', 'industryCodeDescriptions[0].industryDescription');
			
			$(this).find('.removeIndustryInfermentRowLink').html($(this).find('.removeIndustryInfermentRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	enableIndustryCodeInfermentUpdateButton();
	return false;
} 

function addIndustryCodeInfermentNewRow(){
	
	var nextIndex = $(".industryCodeTypeCode").length;
	$('#industryCodeInfermentTable').append($('#industryCodeInfermentTable tr:last').clone());
	var newlyAddedInfermentRow = $('#industryCodeInfermentTable tr:last');
	bindIndustryCodetypeLoseFocus();
	
	updateNamesOfNewRow(newlyAddedInfermentRow , '.industryCodeTypeCode', nextIndex, 'industryCodeList', 'industryCodeTypeCode', "false");
	updateNamesOfNewRow(newlyAddedInfermentRow , '.industryCode', nextIndex, 'industryCodeList', 'industryCode', "false");
	updateNamesOfNewRow(newlyAddedInfermentRow , '.industryDescription', nextIndex, 'industryCodeList', 'industryCodeDescriptions[0].industryDescription', "false");
	
	newlyAddedInfermentRow.find('.removeIndustryInfermentRowLink').html('<a href="#" style="text-decoration: none;" onclick="removeIndustryInfermentRow(this,' + nextIndex + ');">[-]</a>');	
}


function bindIndustryCodetypeLoseFocus(){
	$('.industryCode').on('focusout', function(){
		var industryCodeTypeCode = $(this).closest('tr').find('.industryCodeTypeCode').val();
		var industryCode = $(this).val();
		if(($.trim(industryCode) == '') || ($.trim(industryCodeTypeCode) == '') ){
			return false;
		}
		getDescriptionForCodeTypeCodes(industryCodeTypeCode,industryCode, $(this).closest('tr').find('.industryDescription'), $('#errorMsgIndustryCodeInfer'),$('#industryCodeInfermentEditButton'),false);		
		
	});
}

function getDescriptionForCodeTypeCodes(industryCodeTypeCode, industryCode, textBoxHandler, errorHandler,updateButton,flag){
	errorHandler.hide();
	if(textBoxHandler != null){
		textBoxHandler.val('');
	}
	updateButton.attr("disabled",'disabled');
	$.getJSON('retrieveDescriptionForIndsCodeTypeCode.form', {
		industryCodeTypeCode : industryCodeTypeCode,
		industryCode : industryCode,
		ajax : 'true'
	}, function(data) {
		if(industryCodeTypeCode == $('#industryCodeTypeCode').val()) {
			errorHandler.html("Industry Code that is already mapped to a scheme " +
					"cannot be mapped to another Industry Code within the same scheme");
			errorHandler.show();
		} else if(data.description == 'InvalidCodeTypeCodeCombination') {
			errorHandler.html("Industry Code " + industryCode + " is not valid for the industry " +
				"coding scheme " + industryCodeTypeCode);
			errorHandler.show();
		} else {
			if(textBoxHandler != null){
				textBoxHandler.val(data.description);
				if(flag) {
					enableUpdateButton();
				} else {
					enableIndustryCodeInfermentUpdateButton();
				}				
			}
		}
	});
}

function enableUpdateButton(){
	var isInvalidFlag= false;
	$(".industryCodeDescription").each(function(){
		if($(this).val()==null || $(this).val()==''){
			$('#industryUpdateButton').attr('disabled','disabled');
			isInvalidFlag=true;
			$(this).closest('tr').find('.toIndustryCode').trigger("focusout");
			return false;
		} 
	});
	if(!isInvalidFlag){
		$('#errorMsgMapping').hide();
		$('#industryUpdateButton').removeAttr('disabled');
	}
}

function enableIndustryCodeInfermentUpdateButton(){
	var isInvalidFlag= false;
	$(".industryDescription").each(function(){
		if($(this).val()==null || $(this).val()==''){
			$('#industryCodeInfermentEditButton').attr('disabled','disabled');
			isInvalidFlag=true;
			$(this).closest('tr').find('.industryCode').trigger("focusout");
			return false;
		} 
	});
	if(!isInvalidFlag){
		$('#errorMsgIndustryCodeInfer').hide();
		$('#industryCodeInfermentEditButton').removeAttr('disabled');		
	}
}
