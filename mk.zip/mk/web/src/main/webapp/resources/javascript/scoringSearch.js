$(document).ready(function(){
	bindScoreOverrideEvents();
	configureSearchDataTable();
});

function bindScoreOverrideEvents(){
		
	$('#scoreSearchResetButton').bind('click', function(){
		location.href = "scoreSearchHome.form";
		return false;
	});
	
	
	$('#scoreSearchExportBtn').bind('click',function(){
		if(!($("input:checkbox[name=marketCodeList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Score Market Code");
			$('#errorMsg').css("display","block");
		}
		else if(!($("input:checkbox[name=scrTypCdList]:checked").length > 0)){
			$('#errorMsg').text("Please select Score Type Code");
			$('#errorMsg').css("display","block");
		}
		else{
		var criteriaString='';
		$('#errorMsg').hide();
		var arr = new Array();
		$('input:checkbox[name=marketCodeList]:checked').each(function() 
				{
			arr.push($(this).val());
				});
		var arrVal = new Array();
		$('input:checkbox[name=scrTypCdList]:checked').each(function() 
				{
			arrVal.push($(this).val());
				});
		
		var arrVals = new Array();
		$('input:checkbox[name=scrGruCdList]:checked').each(function() 
				{
			arrVals.push($(this).val());
				});
		
		if(arrVals.length > 0){
			$("#sr_typ_cd_export").val(arrVal);
			$("#mkt_cd_export").val(arr);
			$("#sr_gru_cd_export").val(arrVals);
			$("#exportIndc").val("1");
			//exportToExcelWithGran($("#sr_typ_cd_export").val(),$("#mkt_cd_export").val(),$("#sr_gru_cd_export").val(),$("#exportIndc").val(), false);
		}
		else{
			$("#sr_typ_cd_export").val(arrVal);
			$("#mkt_cd_export").val(arr);
			$("#exportIndc").val("1");
			//exportToExcel($("#sr_typ_cd_export").val(),$("#mkt_cd_export").val(),$("#exportIndc").val(), false);
		}
		
		}
		if(($("input:checkbox[name=marketCodeList]:checked").length > 0)){
			if(($("input:checkbox[name=scrTypCdList]:checked").length > 0)){
			//location.href = "scoreSearchExportToExcelResults.form?type=export&sSearch="+criteriaString;
				$('#scoreSearchForm').submit();
				hideSpinner();
				//populateMarketCode(arrVal, $('#scoreMarketCodes'), false);
			}
		}
		//return false; // to prevent event bubbling
	});	
	$('#scoreSearchSaveButton').bind('click',function(event) {
		
		if(!($("input:checkbox[name=marketCodeList]:checked").length > 0)){
			$('#errorMsg').text("Please select at least one Score Market Code");
			$('#errorMsg').css("display","block");
		}
		else if(!($("input:checkbox[name=scrTypCdList]:checked").length > 0)){
			$('#errorMsg').text("Please select Score Type Code");
			$('#errorMsg').css("display","block");
		}
				
		else{
		//$('#scoreSearchExportBtn').css("display","block");	
		$('#errorMsg').hide();
		var arr = new Array();
		$('input:checkbox[name=marketCodeList]:checked').each(function() 
				{
			arr.push($(this).val());
				});
		var arrVal = new Array();
		$('input:checkbox[name=scrTypCdList]:checked').each(function() 
				{
			arrVal.push($(this).val());
				});
		
		var arrVals = new Array();
		$('input:checkbox[name=scrGruCdList]:checked').each(function() 
				{
			arrVals.push($(this).val());
				});		
		if(arrVals.length > 0){
			scoreSearchResultsTable.fnFilter(arr + "#~" + arrVal + "#~" + arrVals);
		}
		else{
			scoreSearchResultsTable.fnFilter(arr + "#~" + arrVal);
		}
		$('#scoreSearchResults').show();
		$('#scoreSearchResult').show();	
		}
		
});

}
function exportToExcelWithGran(scrTypCdList,marketCodeList,scrGruCdList,exportIndc, hasGrpLvlFilter) {
	

	$.getJSON(window.location.href('exportToExcelWithGran.form'), {
		scrTypCdList : scrTypCdList,
		marketCodeList : marketCodeList,
		scrGruCdList : scrGruCdList,
		exportIndc : exportIndc,
		ajax : 'true'
	});
}	
function exportToExcel(scrTypCdList,marketCodeList,exportIndc, hasGrpLvlFilter) {
	

	$.getJSON(window.location.href('exportToExcel.form'), {
		scrTypCdList : scrTypCdList,
		marketCodeList : marketCodeList,
		exportIndc : exportIndc,
		ajax : 'true'
	});
}	
function getSearchResults(){
	var arr = new Array();
	
$('input:checkbox[name=marketCodeList]:checked').each(function() 
			{
		arr.push($(this).val());
			});
				
				$('#errorMsg').hide();
				scoreSearchResultsTable.fnFilter(
						arr + "#~" + $("#scoreTyp").val() + "#~" + $("#scoreGru").val());
}
var scoreSearchResultsTable;
function configureSearchDataTable() {
	scoreSearchResultsTable = $("#scoreSearchResultsTable").dataTable(
			{
				"bServerSide" : true,
				"sAjaxSource" : "scoreSearchAjaxResult.form",
				"bProcessing" : false,
				"bSort": false,
				"sPaginationType" : "full_numbers",
				"oLanguage" : {
					"sEmptyTable" : "No data available",
					"sLengthMenu" : " _MENU_ items per page",
					"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
	                "sInfoEmpty": "No entries to show"
				},
				"sDom" : 'tlip',
				"aoColumns" : [ null, null, null, null, null,null,null,null ],
				"fnRowCallback" : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
					 $(nRow).children("td").css("overflow", "hidden");
					 $(nRow).children("td").css("white-space", "nowrap");
					 $(nRow).children("td").css("text-overflow", "ellipsis");
					setHyperLinkOnScoreSearchColumns(nRow, aData);
					return nRow;
				}
			});
}
function setHyperLinkOnScoreSearchColumns(nRow, aData){
//	$('td:eq(0)', nRow).width("13%");
	$('td:eq(0)', nRow).html(getAreaCodeColumnHtml(aData[0],aData[1]));
	$('td:eq(0)', nRow).css('text-align', 'center');
	$('td:eq(1)', nRow).width("15%");
	$('td:eq(1)', nRow).css('text-align', 'center');
	$('td:eq(2)', nRow).width("15%");
	$('td:eq(2)', nRow).css('text-align', 'center');
	$('td:eq(3)', nRow).width("10%");
	$('td:eq(3)', nRow).css('text-align', 'center');
	$('td:eq(4)', nRow).width("10%");
	$('td:eq(4)', nRow).css('text-align', 'center');
	$('td:eq(5)', nRow).width("15%");
	$('td:eq(5)', nRow).css('text-align', 'center');
	$('td:eq(6)', nRow).width("10%");
	$('td:eq(6)', nRow).css('text-align', 'center');
	$('td:eq(7)', nRow).width("20%");
	$('td:eq(7)', nRow).css('text-align', 'center');
}

function getAreaCodeColumnHtml(value1,value2){
	//return "<a href='editScoreSearch.form?scrID=" + value1 + "&scrTypCd="+value2+"&scrTypDesc="+value3+"&scrMktCd="+value4+"&countryName="+value5+"&scrGruCd="+value6+"&GruTypDesc="+value7+"'>" + value1 + "</a>";
	return "<a href='editScoreSearch.form?scrID=" + value1 + "&scrTypCd="+value2+"'>" + value1 + "</a>";
}
function selectoneMktCodeList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallMktCodeList(ref) {
	if (ref.checked == false) {
		$("#allmktCode").prop("checked", false);
	}
}
function selectallMktCodeList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			this.checked = false;
		});
	}
}

function selectoneSrTypCdList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=scrTypCdList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallSrTypCdList(ref) {
	if (ref.checked == false) {
		$("#allSrTypCd").prop("checked", false);
	}
}
function selectallSrTypCdList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=scrTypCdList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=scrTypCdList]').each(function() {
			this.checked = false;
		});
	}
}

function selectoneSrGruCdList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=scrGruCdList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function uncheckallSrGruCdList(ref) {
	if (ref.checked == false) {
		$("#allSrGruCd").prop("checked", false);
	}
}
function selectallSrGruCdList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=scrGruCdList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=scrGruCdList]').each(function() {
			this.checked = false;
		});
	}
}
