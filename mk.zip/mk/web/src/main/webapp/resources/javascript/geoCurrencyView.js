/**
 * 
 */
$(document).ready(function(){	
	bindGeoCurrencyViewEvents();	 
});


function initializeAddCdValDatepicker(){
	$('.cdValDatepickerTextBox').removeClass('hasDatepicker').datepicker(
			getDatepickerOptions(true));
	$('.cdValDatepickerTextBox').datepicker('enable');
}


function bindGeoCurrencyViewEvents(){
	
	$('#geoCrcyViewEditBtn').bind('click',function(){		
		initializeAddCdValDatepicker();	
		$('.editable').prop("disabled",false);		
		$(".editable").prop("disabled",false);
		$('.cdValDatepickerTextBox').datepicker('enable');		
		$('#geoCrcyViewEditBtn').hide();
		$('#geoCrcyViewUpdateBtn').show();
	});
	
	$('#geoCrcyViewUpdateBtn').bind('click',function(){
		if(!(isValidDate($('#cdValEndDate').val()))){
			$('#errorMsg').html("Please enter valid End date");
			$('#errorMsg').show();
		}else{
			$('#errorMsg').hide();				
			if(confirm("Are you sure you want to expire the Currency details")) {
				$('#geoCurrencyViewForm').submit();
			}
		}
		
	});
	
}

function isValidDate(dateString) {
	var regEx = /^\d{4}-\d{2}-\d{2}$/;
	var dtArray = dateString.match(regEx); 
	if (dtArray == null) {
        return false;
	}
	var splitdate = dateString.split('-');
	dtYear = splitdate[0];
	dtMonth = splitdate[1];
	dtDay = splitdate[2];
	
	if (dtMonth < 1 || dtMonth > 12) {
        return false;
    }else if (dtDay < 1 || dtDay> 31) {
        return false;
    }else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) {
        return false;
	}else if (dtMonth == 2) 
    {
		alert(isleap);
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
		alert(isleap);
        if (dtDay> 29 || (dtDay ==29 && !isleap)) {
            return false;
		}
    }
    return true;
}

