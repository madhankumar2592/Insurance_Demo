var idVals=0;
var flg = false;
var rescFlag = false;
var granFlag = false;
var granflg = false;

$(document).ready(function(){
	 $.ajaxSetup({ cache: false });	
	initializeScoreGranularityElements();
	
	$('#scoreDtlSaveButton').bind('click', function(){		
		if(isDropDownEmpty($('.scoreTypeCode'))) {
			$('#errorMsg').text("Please select Score Type Code");
			$('#errorMsg').css("display","block");
		}else if (isDropDownEmpty($('.scoreMarketCode'))) {
			$('#errorMsg').text("Please select Market Type Code");
			$('#errorMsg').css("display","block");
		}else if (isDropDownEmpty($('.scoreVersion'))) {
			$('#errorMsg').text("Please select Score Version");
			$('#errorMsg').css("display","block");
		}else if($('#productCode').val()== '') {
			$('#errorMsg').text("Please select Product Code");
			$('#errorMsg').css("display","block");
		}else if (!($('input:checkbox[name=resc]:checked').length > 0)) {
			$('#errorMsg').text("Please select at least one Resource");
			$('#errorMsg').css("display","block");
		}else if(validateGranularity()){	
			$('#errorMsg').text("Please select granularity values");
			$('#errorMsg').css("display","block");				
		}
		else {			
			var granValId =0;
			$('[id^="divId"]').each(function() {
				granValId = this.id.match(/\d+/);
				var arry = $('#divId'+granValId+' > input:checkbox[name=granularity]:checked').map(function() {if(!(this.value=="All"))return this.value}).toArray(); 
				if(arry.length > 0){
					$('[id^="granularityString'+granValId+'"]').val(arry);
				}
			 });
			
			var arrResc = new Array();
			$('input:checkbox[name=resc]:checked').each(function() 
					{
				if($(this).val()=="All"){					
				}
				else{
					arrResc.push($(this).val());
				}				
			});
			
			if(arrResc.length > 0){
				$("#resourceString").val(arrResc);
			}
				var scrTypText = $('#scoreTyp :selected').text();
				var productCodeText = $('#productCode :selected').text();
				var mktCdText = $('#scoreMarketCodes :selected').text();
				var versionText = $('#scoreVersion :selected').text();
					var granVal = new Array();
					$('.addGranularity :selected').each(function() 
					{					
						granVal.push($(this).text());
					});
					
						var retVal = confirm("Are you sure you want to map "+scrTypText+" to "+productCodeText+"?");
						if( retVal == true ){
							$('#scoreDtlForm').submit();
						  return true;
						}else{
						  return false;
						}
					
		}
	});
	
	
	
	
	
		$("[id^='scoreVersion']").bind('change',function(){
			var idVal = this.id.match(/\d+/);
			idVals=idVal;
		if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();
		$('[id^="scoregran'+idVal+'"]').prop( "disabled", true );
		$('#granularityDiv').css("display","none");
		$('tr.detailRowGran').not(':first').remove(); 
		$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
	granFlag = false;
		if(!(granFlag)){
		granFlag = true;		
populateGranularityCodes($('[id^="scoreTypeCode'+idVal+'"]').val(),$('[id^="scoreMarketCode'+idVal+'"]').val(),$(this).val(),idVal);
			}
			}
	
		});
});


var scoreSERSearchResultsTable;
var scoreFailureSearchResultsTable;
var flag1 = false;
var flag = false;

function initializeScoreGranularityElements(){
	
	
	
	$('#productCode').bind('change',function(){
		if($.trim($(this).val()) != '') {
			$('#errorMsg').hide();
			$( "#productFamilyCode" ).prop( "disabled", true );
			$( "#productVersion" ).prop( "disabled", true );
			$(".multiple_dropdown_resource").prop( "disabled", true );
			rescFlag = false;
			populateProdFamCode($(this).val(), $('#productFamilyCode'),$('#productVersion'), false);
			}				
		});	
	
	$('#productFamilyCode').bind('change',function(){
		if($.trim($(this).val()) != '') {
			$('#errorMsg').hide();
			$( "#productVersion" ).prop( "disabled", true );
			$(".multiple_dropdown_resource").prop( "disabled", true );
			rescFlag = false;
			populateProdVersion($(this).val(),$('#productCode').val(), $('#productVersion'), false);
			}
				
		});	
	$('#productVersion').bind('change',function(){
		if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();
		flag1 = true;
		rescFlag = false;
		populateProdFamVerResource($('#productCode').val(),$('#productFamilyCode').val(),$('#productVersion').val());
			}
				
		});
	
	$("[id^='scoreTypeCode']").bind('change',function(){
	
	var idVal = this.id.match(/\d+/);
	if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();
		$('[id^="scoreVersion'+idVal+'"]').prop( "disabled", true );
		$('[id^="scoregran'+idVal+'"]').prop( "disabled", true );

		$('[id^="scoreMarketCodes'+idVal+'"]').prop( "disabled", true );

		$('#granularityDiv').css("display","none");
		$('tr.detailRowGran').not(':first').remove(); 
		$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
		granFlag = false;
		populateMarketCode($(this).val(), $('[id^="scoreMarketCode'+idVal+'"]'), false);
		}
			
	});
	
	$("[id^='scoreMarketCode']").bind('change',function(){
		var idVal = this.id.match(/\d+/);
		idVals=idVal;
	if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();
		$('[id^="scoreVersion'+idVal+'"]').prop( "disabled", true );
		$('[id^="scoregran'+idVal+'"]').prop( "disabled", true );
		$('#granularityDiv').css("display","none");
		$('tr.detailRowGran').not(':first').remove(); 
		$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
		flag = false;
		granFlag = false;
		populateVersion($(this).val(), $('[id^="scoreVersion'+idVal+'"]'), false,$('[id^="scoreTypeCode'+idVal+'"]').val() );		}
			
	});
	
		$("[id^='scoreVersion']").bind('change',function(){
		var idVal = this.id.match(/\d+/);
		idVals=idVal;
		//alert("idVals : "+idVals);
		if($.trim($(this).val()) != '') {
		$('#errorMsg').hide();
		$('[id^="scoregran'+idVal+'"]').prop( "disabled", true );
		$('#granularityDiv').css("display","none");
		$('tr.detailRowGran').not(':first').remove(); 
		$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
		populateGranularityCodes($('[id^="scoreTypeCode'+idVal+'"]').val(),$('[id^="scoreMarketCode'+idVal+'"]').val(),$(this).val(),idVal);
	}
				
		});
	
	
	
	
	$('#scoreDtlResetButton').bind('click', function(){
		location.href = "prodScrMap.form";
		return false;
	});
	
	$('#scoreDtlCancelButton').bind('click', function(){
		location.href = "prodScrMap.form";
		return false;
	});
	

}


function validateGranularity() {  
var flagGran = false;
			var granValIds = 0;
			$('[id^="divId"]').each(function() {
				granValIds = this.id.match(/\d+/);							
				var arrys = $('input:checkbox:checked.gran'+granValIds).map(function () {  return this.value;}).get(); 
				//alert(arrys.length);
				while(arrys.length == 0){					
					flagGran = true;	
					break;
				}				
			 });
			 return flagGran;
}

function getSelectedGranularity() { 
	var val = [];
	var value = false;
	$('.addGranularity:checked').each(function(i) { 
	val[i] = $(this).val(); 
	});
	$('[id^="divId"]').each(function(i) { 
	$(this).find("input").each(function() 
					{
							if($(this).val=="All"){
							}
							else{
							value = true;
							}
					});
	});
	
	return val; 
}
function populateMarketCode(scoreTyp, marketObj, hasGrpLvlFilter) {
	var groupLevelCode = '';
	var hasEnglish=false;
	if(hasGrpLvlFilter) {
		groupLevelCode = getGroupLevelSearchCodes();
	}
	$.getJSON('retrieveMarketCodesForScrType.form', {
		scoreType : scoreTyp,
		ajax : 'true'
	}, function(data) {
		marketObj.empty();
		marketObj.append('<option value="">--  Select Market Type Code  --</option>'); 
		$.each(data, function() {
			marketObj.append('<option value="' + this.code + '">' + " [" + this.code + "] " + this.value +  '</option>');
			marketObj.removeAttr('disabled');
			if(this.code==39){
				hasEnglish= true;
			}
		 }); 
		
		if(hasEnglish) {
			langObj.val(39);
		}
	});
}
function populateVersion(scoreMkt, scrVerObj, hasGrpLvlFilter,scoreTyp) {
	var groupLevelCode = '';
	var hasEnglish=false;
	if(hasGrpLvlFilter) {
		groupLevelCode = getGroupLevelSearchCodes();
	}
	$.getJSON('retrieveVersionForScrMktAndType.form', {
		scoreMkt : scoreMkt,
		scoreType : scoreTyp,
		ajax : 'true'
	}, function(data) {
		scrVerObj.empty();
		$.each(data, function() {
			scrVerObj.append('<option value="' + this.scoreVersion + '">' + this.scoreVersion +'</option>');
			scrVerObj.removeAttr('disabled');
			if(this.code==39){
				hasEnglish= true;
			}
		 }); 
		$( "#scoregran" ).prop( "disabled", true );
		if(hasEnglish) {
			scrVerObj.val(39);
		}
	});
	
}
function populateGranularity(scoreVer, scrGranObj, hasGrpLvlFilter,scoreTyp,scoreMkt) {
	var groupLevelCode = '';
	var hasEnglish=false;
	if(hasGrpLvlFilter) {
		groupLevelCode = getGroupLevelSearchCodes();
	}
	$.getJSON('retrieveGranularityForScrType.form', {
		scoreVer : scoreVer,
		scoreType : scoreTyp,
		scoreMkt : scoreMkt,
		ajax : 'true'
	}, function(data) {
		scrGranObj.empty();
		$("#scoregran").append('<option value="">--  Select Granularity  --</option>'); 
		$.each(data, function() {
			scrGranObj.append('<option value="' + this.codeValueId + '">' + " [" + this.codeValueId + "] " + this.codeValueDescription +  '</option>');
			scrGranObj.removeAttr('disabled');
			$('#granularityDiv').css("display","block");
			if(this.code==39){
				hasEnglish= true;
			}
		 }); 
		if(hasEnglish) {
			scrGranObj.val(39);
		}
	});
	
	

}
function selectallAddCdTblGranularity(ref){

var granVal = $(ref).closest('div').attr('id').match(/\d+/);

	if (ref.checked == true) {
		$('.gran'+granVal+'').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('.gran'+granVal+'').each(function() {
			this.checked = false;
		});
	}
}

function deselectAllGranularity(ref) {
var granVal = $(ref).closest('div').attr('id').match(/\d+/);

	if (ref.checked == false) {		
		$('.grans'+granVal+'').each(function() {
			this.checked = false;
		});
}
}

function populateGranularityCodes(scoreType,scoreMkt,scoreVer,idVal) {
	$.getJSON('retrieveGranularityCodes.form', {
		scoreVer : scoreVer,
		scoreType : scoreType,
		scoreMkt : scoreMkt,
		ajax : 'true'
	}, function(data) {
		$('[id^="divId'+idVal+'"]').empty();
		$('[id^="divId'+idVal+'"]').append('<label><input type="checkbox" value="All" name="granularity" onclick="selectallAddCdTblGranularity(this);" id="allGranularity" class="addGranularity gran'+idVal+' grans'+idVal+'" disabled="disabled" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			if(this.indicator=="3"){   	
				if(!(granflg)){
					granflg = true;				
					$(".grans"+idVal).attr("disabled", true);
					alert("No Matching Granularity available.Try selecting different version/Market code/Score Type Code...");
				}
			}else{				 
				$('[id^="divId'+idVal+'"]').append('<input type="checkbox" name="granularity"  class="addGranularity gran'+idVal+'" value="' + this.codeValueId + '" onclick="deselectAllGranularity(this)">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
				granflg = false;	
				$(".grans"+idVal).removeAttr("disabled");
			}

		 }); 
	});
	
}
function populateProdFamCode(prodCode, famCodeObj,versionObj, hasGrpLvlFilter) {
	$.getJSON('retrieveProdFamCode.form', {
		prodCode : prodCode,
		ajax : 'true'
	}, function(data) {
		famCodeObj.empty();
		versionObj.empty();
		$( ".multiple_dropdown_resource" ).empty();
		$("#productFamilyCode").append('<option value="">--  Select Product Family Code  --</option>');
		$(".multiple_dropdown_resource").append('<label><input type="checkbox" value="All" name="resc" onclick="selectallresc(this);" id="allresc" class="resc" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			//Version
			if(this.indicator=="1"){
				versionObj.append('<option value="' + this.codeValueId + '">' + this.codeValueId + '</option>');
							versionObj.removeAttr('disabled');

				$( "#productFamilyCode" ).prop( "disabled", true );
			}//Resource
			else if(this.indicator=="2"){
				 $(".multiple_dropdown_resource").append('<input type="checkbox" name="resc"  class="resc" value="' + this.codeValueId + '" onclick="deselectAllresc(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
				 $(".multiple_dropdown_resource").removeAttr('disabled');
				 $( "#productFamilyCode" ).prop( "disabled", true );
					$( "#productVersion" ).prop( "disabled", true );

			}//If no records present
			else if(this.indicator=="3"){
				 $(".multiple_dropdown_resource").prop( "disabled", true );
				 $( "#productFamilyCode" ).prop( "disabled", true );
				 $( "#productVersion" ).prop( "disabled", true );
				 
				 alert("No Matching Resource available");
				 
			}
			//Family Code
			else{
			famCodeObj.append('<option value="' + this.codeValueId + '">' + " [" + this.codeValueId + "] " + this.codeValueDescription +  '</option>');
			famCodeObj.removeAttr('disabled');
			$( "#productVersion" ).prop( "disabled", true );
				 $(".multiple_dropdown_resource").prop( "disabled", true );

			}
			
		 }); 
		
	});
}
function selectallresc(ref){
	if (ref.checked == true) {
		$('input[type=checkbox][name=resc]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=resc]').each(function() {
			this.checked = false;
		});
	}
}

function deselectAllresc(country) {
	if (!$(country).is(":checked")) {
		$('#allresc').attr('checked', false);
	}
}
function populateProdVersion(famCode,prodCode, versionObj, hasGrpLvlFilter) {
	$.getJSON('retrieveFamProdVersion.form', {
		famCode : famCode,
		prodCode : prodCode,
		ajax : 'true'
	}, function(data) {
		versionObj.empty();
		$(".multiple_dropdown_resource").empty();
		$(".multiple_dropdown_resource").append('<label><input type="checkbox" value="All" name="resc" onclick="selectallresc(this);" id="allresc" class="resc" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			//Version
			if(this.indicator=="1"){
			flag1 = true;
				versionObj.append('<option value="' + this.codeValueId + '">' + this.codeValueId + '</option>');
				versionObj.removeAttr('disabled');
				
			}//If no records present
			else if(this.indicator=="3"){
				 $(".multiple_dropdown_resource").prop( "disabled", true );
				 $( "#productVersion" ).prop( "disabled", true );
				 				
				 alert("No Matching Resource available");
				

			}
			//Resource
			else{
				 $(".multiple_dropdown_resource").append('<input type="checkbox" name="resc"  class="resc" value="' + this.codeValueId + '" onclick="deselectAllresc(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
				 			$(".multiple_dropdown_resource").removeAttr('disabled');
					$( "#productVersion" ).prop( "disabled", true );
			}			
		 }); 
		
	});
}

function populateProdFamVerResource(prodCode,famCode, prodVer) {
	$.getJSON('retrieveProdFamVerResource.form', {
		famCode : famCode,
		prodCode : prodCode,
		prodVer : prodVer,
		ajax : 'true'
	}, function(data) {
		$(".multiple_dropdown_resource").empty();
		$(".multiple_dropdown_resource").append('<label><input type="checkbox" value="All" name="resc" onclick="selectallresc(this);" id="allresc" class="resc" tabindex="4"/> All</label><br>'); 
		$.each(data, function() {
			//If no records present
			if(this.indicator=="3"){
				 $(".multiple_dropdown_resource").prop( "disabled", true );
				 alert("No Matching Resource available");
			}else{
			$(".multiple_dropdown_resource").append('<input type="checkbox" name="resc"  class="resc" value="' + this.codeValueId + '" onclick="deselectAllresc(this);">' + this.codeValueId   +"  ["+  this.codeValueDescription +"] "+ '</option><br>');
			$(".multiple_dropdown_resource").removeAttr('disabled');
			}
		 }); 
		
	});
}
$(document).ajaxComplete(function() {
		if(!(flag) ) {
			if($.trim($('[id^="scoreVersion'+idVals+'"]').val()) != '') {
			$('#errorMsg').hide();
			
			$('[id^="scoregran'+idVals+'"]').prop( "disabled", true );
			$('#granularityDiv').css("display","none");
			$('tr.detailRowGran').not(':first').remove(); 
			$('#scoregran').val( $('#scoregran').prop('defaultSelected') );
			flag = true;
			populateGranularityCodes($('[id^="scoreTypeCode'+idVals+'"]').val(),$('[id^="scoreMarketCode'+idVals+'"]').val(),$('[id^="scoreVersion'+idVals+'"]').val(),idVals);
			
			}				
		}
		if((flag1)) {
			if($.trim($('#productVersion').val()) != '') {
			$('#errorMsg').hide();
			flag1 = false;
			if(!(rescFlag)){
			rescFlag = true;
			populateProdFamVerResource($('#productCode').val(),$('#productFamilyCode').val(),$('#productVersion').val());
			}
			}				
		}
});



function addNewScoreMap() {
	var nextIndex = $(".containerRow").length;
	
	var max = null;
	

	$("[name^='scoreMappingList']").each(function() {
	if(typeof this.name === 'undefined'){
	}else{
		var name = this.name.match(/\d+/);
			
		if (max==null || name > Number(max)) {
			max = name;
			
		}
		}
	});
		

	nextIndex = Number(max) + 1;
	
	
	
	$('#scoreMarketTable').append($('#scoreMarketTable .containerRow:last').clone());	
	var newlyAddedScoreRow = $('#scoreMarketTable .containerRow:last');
	updateNamesOfNewRow(newlyAddedScoreRow, '.scoreTypeCode', nextIndex,
			'scoreMappingList', 'scoreTypeCode', "true");
	updateNamesOfNewRow(newlyAddedScoreRow, '.scoreMarketCode', nextIndex,
			'scoreMappingList', 'scoreMarketCode', "false");
	updateNamesOfNewRow(newlyAddedScoreRow, '.scoreVersion', nextIndex,
			'scoreMappingList', 'scoreVersion', "false");
	updateNamesOfNewRow(newlyAddedScoreRow, '.divId', nextIndex,
			'scoreMappingList', 'divId', "false");
	updateNamesOfNewRow(newlyAddedScoreRow, '.granularityString', nextIndex,
			'scoreMappingList', 'granularityString', "false");
	
	$('#scoreMarketTable').find('.containerRow:last')
			.find('.removeNewScoreMap')
			.html(
					'<a href="javascript:;" style="text-decoration: none;" onclick="removeNewScoreMap(this,'
							+ nextIndex + ');">[-]</a>');
	newlyAddedScoreRow.show();
	granflg = false;
	initializeScoreGranularityElements();
	return false;
}

function removeNewScoreMap(removeHandle, rowIndexToDelete) {
	$('#errorMsg2').css("display","none");
	if ($('.containerRow:visible').length == 1) {
		$('#errorMsg2').text("At least one Resource is mandatory");
		$('#errorMsg2').css("display","block");
		return false;
	} else {
		$(removeHandle).closest('.containerRow').remove();
	}
	$('#scoreMarketTable .containerRow').each(
			function() {
				if (this.rowIndex > rowIndexToDelete) {
					updateNames($(this).find('.scoreTypeCode'),
							(this.rowIndex - 1), 'scoreMappingList',
							'scoreTypeCode');
					updateNames($(this).find('.scoreMarketCode'),
							(this.rowIndex - 1), 'scoreMappingList',
							'scoreMarketCode');
					updateNames($(this).find('.scoreVersion'),
							(this.rowIndex - 1), 'scoreMappingList',
							'scoreVersion');
					updateNames($(this).find('.divId'),
							(this.rowIndex - 1), 'scoreMappingList',
							'divId');
					updateNames($(this).find('.granularityString'),
							(this.rowIndex - 1), 'scoreMappingList',
							'granularityString');
					
					$(this).find('.removeNewScoreMap').html(
							$(this).find('.removeNewScoreMap').html().replace(
									/[0-9]+/, (this.rowIndex - 1)));
				}
			});
	return false;
}
//				updateNamesOfNewRow(newlyAddedScoreRow, '.scoreVersion', nextIndex,
			//  'scoreMappingList', 'scoreVersion', "false");
function updateNamesOfNewRow(newlyAddedRow , className, rowIndex, bindArrayName, bindFieldName, editFlag){
if(!(className =='.scoreTypeCode')){
	var currentElement = newlyAddedRow.find(className);
	updateNames(currentElement, rowIndex, bindArrayName, bindFieldName);
	currentElement.val("");
	currentElement.empty();
	if(editFlag == "true"){
		currentElement.attr("disabled", false);
	}
	}
	else{
	//alert(className);
	var currentElement = newlyAddedRow.find(className);
	updateNames(currentElement, rowIndex, bindArrayName, bindFieldName);
	//currentElement.val("");
	//currentElement.empty();
	//$('#lstCities option[value!="0"]').remove();
	if(editFlag == "true"){
		currentElement.attr("disabled", false);
	}
	}
}

function updateNames(currentElement, rowIndex, bindArrayName, bindFieldName){
	currentElement.attr('name', bindArrayName + '[' + rowIndex + '].' + bindFieldName);
	currentElement.attr('id', bindFieldName+rowIndex);
}

function isDropDownEmpty(dropDownName) {
	var returnType = false;
	dropDownName.each(function(){
		if(!($(this).is(':disabled'))){
			if($(this).val() == ''|| $(this).val() == null){
				$(this).focus();
				returnType =true;
				return true;
			}
		}
	});
	return returnType;
}


