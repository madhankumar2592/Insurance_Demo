/**
 * This file serves industryCodeDetail.jsp
 */

$(document).ready(function(){
	if($("#successMsg").val()){
		alert("Score Granularity Mapping is added in Reference Data SOR successfully");
	}
	initializeScoreGranuMapping();

});



function initializeScoreGranuMapping(){
	$('#granuSubmitButton').bind('click', function(){
			if($('#scoreTypeCode').val()== '') {
						$('#errorMsg').text("Please select Score Type Code");
						$('#errorMsg').css("display","block");
					}else if ($('#granularityCode').val()== '') {
						$('#errorMsg').text("Please select at least one Granularity Code");
						$('#errorMsg').css("display","block");
					}else if(isDropDownEmpty($('.granularityTypeCode'))) {
						alert('Please select Score Granularity Code from the drop-down list');					
					}else {					
						var scrTypText = $('#scoreTypeCode :selected').text();
						var granVal = new Array();
						$('.granularityTypeCode :selected').each(function() 
						{					
							granVal.push($(this).text());
						});
						if(isDuplicateGran(granVal)){
							alert("Please select unique Granularity values");
						}else{
						
							var retVal = confirm("Are you sure you want to map "+scrTypText+" to "+granVal+"?");
							if( retVal == true ){
								$('#scoreGranularityForm').submit();
							  return true;
							}else{
							  return false;
							}
						}
					}
	});
	
	$('#granuResetButton').bind('click', function(){
		location.href = "scoreGranMappingHome.form";
		return false;
	});
	
	$('#granuCancelButton').bind('click', function(){
		location.href = "scoreGranMappingHome.form";
		return false;
	});
	

}


function addGranularityRow(){
	var nextIndex = $(".granularityTypeCode").length;
	$('#granularityDetailTable').append($('#granularityDetailTable tr:last').clone());
	var newlyAddedGranularityRow = $('#granularityDetailTable tr:last');
	updateNamesOfNewRow(newlyAddedGranularityRow , '.granularityTypeCode', nextIndex, 'granularityDetailVO', 'granularityTypeCode', "true");
	
	$('#granularityDetailTable').find('tr:last').find('.removeDescriptionRowLink').
	html('<a href="javascript:;" style="text-decoration: none;" onclick="removeGranularityRow(this,' + nextIndex + ');">[-]</a>');
	newlyAddedGranularityRow.show();
	return false;

}

function removeGranularityRow(removeHandle, rowIndexToDelete){
	if($('.granularityTypeCode:visible').length ==1){
		alert("At least one Description is mandatory");
		return false;
	}
	 else  {
		$(removeHandle).closest('tr').remove();
	}
	
	$('#granularityDetailTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.granularityTypeCode'), (this.rowIndex - 1), 'granularityDetailVO', 'granularityTypeCode');
					
			$(this).find('.removeDescriptionRowLink').html($(this).find('.removeDescriptionRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}


function isDropDownEmpty(dropDownName) {
	var returnType = false;
	dropDownName.each(function(){
		if(!($(this).is(':disabled'))){
			if($(this).val() == ''|| $(this).val() == null){	
				returnType =true;
				return true;
			}
		}
	});
	return returnType;
}


function isDuplicateGran(granVal)
{	
	var flag = false;
	var sorted_arr = new Array();	
	sorted_arr = granVal.sort();  
	
	for (var i = 0; i < granVal.length - 1; i++) {  
           if (sorted_arr[i + 1] == sorted_arr[i]) {  
            flag = true;
         }
	} 		
		return flag;
	
}