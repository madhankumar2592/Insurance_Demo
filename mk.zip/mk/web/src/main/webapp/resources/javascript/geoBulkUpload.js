/*This file serves geoBulkUpload.jsp*/
$(document).ready(function(){
	$(document).ready(function(){
		bindGeoBulkUpload();
		
	});
});

function bindGeoBulkUpload()
{
//	$('#geoBulkUploadLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "geoBulkUpload.form";
//		return false;
//	});
}

function validateUpload()
{
		if(document.getElementById('geoDomain').value == "")
		{
			document.getElementById('geoDomain').focus();
			alert('Select File Type');
		}
		else if(document.getElementById('country').value == "")
		{
			document.getElementById('country').focus();
			alert('Select Country');			
		}
		else if(document.getElementById('geoupload').value == "" || document.getElementById('geoupload').value == null)
		{
			alert('Select file to upload');
			document.getElementById('geoupload').focus();
		}
		else
		{
			var fup = document.getElementById('geoupload').value;	
			var ext = fup.substring(fup.lastIndexOf('.') + 1);
			if(ext == "xlsx")
			{
				
					
				document.getElementById('geoupload').focus();
				alert("The New records have been added to the stage system and should be routed for approval");	
				$('#geoBulkUpload').submit();
				return true;
			} 
			else
			{						
				alert("Please upload only xlsx files");	
				document.getElementById('geoupload').value="";
				document.getElementById('bulktext').value="";				
				return false;
			}			
		
	}
}
function checkgeoDomain()
{
	if($('#geoDomain').val() == "" && $('#country').val() == "")
	{
			document.getElementById('geoDomain').focus();
			alert('Select Geograhy File Type and Country before Bulk Upload');
	}
	else
	{
		$('#bulkuploadrow').css("visibility","visible");
	}
}



