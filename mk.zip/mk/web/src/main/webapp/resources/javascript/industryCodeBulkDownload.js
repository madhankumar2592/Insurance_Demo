/**
 * 11/22/2013
 * Added to fix issue reported in CASD Ticket # 207844128
 * This replaces one global variable for all the drop down boxes
*/
var toggleIndc = 'VALUE';
var toggleIndcTableCrsWlk = 'VALUE';
var toggleIndcTableToCrsWlk = 'VALUE';
var toggleIndcFromLang = 'VALUE';
var toggleIndcToLang = 'VALUE';
var toggleIndcFromLengthCode = 'VALUE';
var toggleIndcToLengthCode = 'VALUE';

/*** END ***/

$(document).ready(function(){
	bindIndustryCodeBulkDownload();	
});

function bindIndustryCodeBulkDownload()
{
//	$('#industryCodeBulkDownloadLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "industryCodeBulkDownload.form";
//		return false; // to prevent event bubbling
//	});
	
	
	$('#indsCodeToggleBtn').bind('click',function(event){
		toggleIndsCodeTable();
	});
	
	$('#indsCodeToggleBtncrswlk').bind('click',function(event){
		toggleIndsCodeTableCrsWlk();
	});
	
	$('#indsCodeToggleBtnToCrsWlk').bind('click',function(event){
		toggleIndsCodeTableToCrsWlk();
	});
	
	$('#fromLangToggle').bind('click',function(event){
		toggleFromLang();
	});
	
	$('#toLangToggle').bind('click',function(event){
		toggleToLang();
	});
	
	$('#fromDescLengthToggle').bind('click',function(event){
		toggleFromLengthCode();
	});
	
	$('#toDescLengthToggle').bind('click',function(event){
		toggleToLengthCode();
	});
	
	
}

function checkindDownloadDomain()
{	
	if($('#indDomain').val() == "")
	{
			$('#indDomain').focus();
			alert('Select Industry Code File Type');
	}
	else
	{
		if($('#indDomain').val() == "Industry Code and Description")
		{
		$('#labelcol,#fieldcol').css("visibility","visible");
		$('#bulkuploadfirstrow').css("display","block");
		$('#bulkuploadcrosswalkrow,#bulkuploadcrosswalksecondrow,#bulkuploadcrosswalkthirdrow').css("display","none");
		}
		else
		{	
			$('#bulkuploadfirstrow').css("display","none");
			$('#labelcol,#fieldcol').css("visibility","hidden");	
			$("#alertSection1").css("display","block");					
		
		}
	}	
}


function validateindDownload()
{	
	languagecheck=$('#languagelist :checked').is(' :checked');
	lengthcodecheck=$('#lengthcodelist :checked').is(' :checked');
	if($('#indDomain').val() == "")
	{
			$('#indDomain').focus();
			alert('Select Industry Code File Type');
	}
	else
	{		
		if($('#indDomain').val() == "Industry Code and Description")
		{	
						
			if($('#industry').val() == "")
			{
					$('#industry').focus();
					alert('Select Industry Code Type');
			}
			else if(languagecheck == false)
			{
				alert('Please select any one or all the Languages');
			}
			else if(lengthcodecheck == false)
			{
				alert('Please select any one or all the Description Length Codes');
			}			
			else
			{
				if($('#indDomain').val() == "Industry Code and Description" && languagecheck == true && lengthcodecheck == true)
				{	
					if($("#bulkuploadfirstrow").css("display") != "none")
					$("#confirmMessageSelction").css("display","inline");
					$('#industryCodeBulkDownload').submit();
				}				
				
			}
		}
		else
		{
			if($('#indDomain').val() == "Industry Code Crosswalk")
			{				
					
				
				if($('#industryTable').val() == "")
				{
						$('#industryTable').focus();
						alert('Select From Industry Code');
				}
				else if($('#toindustryTableName').val() == "")
				{
					$('#toindustryTableName').focus();
					alert('Select To Industry Code');
				}
				else if($('#language').val() == "")
				{
					$('#language').focus();
					alert('Select From Industry Code Language');
				}
				else if($('#tolanguage').val() == "")
				{
					$('#tolanguage').focus();
					alert('Select To Industry Code Language');
				}
				else if($('#lengthcode').val() == "")
				{
					$('#lengthcode').focus();
					alert('Select From Industry Code Lengthcode');
				}
				else if($('#tolength').val() == "")
				{
					$('#tolength').focus();
					alert('Select To Industry Code lengthCode');
				}
				else
				{					
					$("#confirmMessageSelction").css("display","inline");	
					$('#industryCodeBulkDownload').submit();
					$("input[name=dwnlbutton][type=button]").attr("disabled", "disabled");
				}
		}
		
	}
}
}

function checkagreedownload()
{
	if(document.getElementById("agree").checked)
	{	
		$("#alertSection1").css("display","none");
		$('#bulkuploadcrosswalkrow,#bulkuploadcrosswalksecondrow,#bulkuploadcrosswalkthirdrow').css("display","block");
		$('#fromindustrycode,#fromcodedrop').css("display","block");	
		$('#bulkuploadfirstrow').css("display","none");
		$('#labelcol,#fieldcol').css("visibility","hidden");			
	}
	else
	alert("You are not allowed to download the industry code crosswalk");	
}

function checkagreedownload1()
{
	document.getElementById('alertSection1').style.display = 'none';
	document.getElementById('indDomain').value = "";
	
}

function displayCrosswalk()
{
	if($("#industryTable").val() == "Standard Industry Code - 8 digit" ||$("#industryTablecode").val() == "Standard Industry Code - 8 digit" )
	{
		$("#toindustryTableName1").css("display","inline");
		$("#toindustryTableName").css("display","none");
		$("#toindustryTableName").val('');
	}
	else
	{
		$("#toindustryTableName1").css("display","none");
		$("#toindustryTableName1").val('');
		$("#toindustryTableName").css("display","inline");		
	}
}

function toggleChange()
{
	if($("#industryTable").css("display") == "inline")
	{
		$("#industryTable").css("display","none");
		$("#industryTable").val('');
		$("#industryTablecode").css("display","inline");
	}
	else if($("#industryTable").css("display") == "none")
	{
		$("#industryTable").css("display","inline");
		$("#industryTablecode").css("display","none");	
		$("#industryTablecode").val('');	
	}
}


function toggleIndsCodeTable() {
	
	$.getJSON('toggleIndsCodeTable.form', {
		toggleIndicator : toggleIndc,
		ajax : 'true'
	}, function(data) {
		$("#industry").empty();
		$("#industry").append('<option value="">--  Select Industry Code Table  --</option>'); 
		if(toggleIndc == 'CODE') {
			$.each(data, function() {			 
				 $("#industry").append('<option value="' + this.codeValueId + '">' + this.codeValueId + ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
			});
			toggleIndc = 'VALUE';
		} else {
			$.each(data, function() {			 
				 $("#industry").append('<option value="' + this.codeValueId + '">' + this.codeValueDescription + ' [ ' + this.codeValueId + ' ] ' + '</option>');
			});
			toggleIndc = 'CODE';
		}
	});
}


function toggleIndsCodeTableCrsWlk() {

	$.getJSON('toggleIndsCodeTable.form', {
		toggleIndicator : toggleIndcTableCrsWlk,
		ajax : 'true'
	}, function(data) {
		$("#industryTable").empty();
		$("#industryTable").append('<option value="">--  Select Industry Code Table  --</option>'); 
		if(toggleIndcTableCrsWlk == 'CODE') {
			$.each(data, function() {			 
				 $("#industryTable").append('<option value="' + this.codeValueId + '">' + this.codeValueId + ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
			});
			toggleIndcTableCrsWlk = 'VALUE';
		} else {
			$.each(data, function() {			 
				 $("#industryTable").append('<option value="' + this.codeValueId + '">' + this.codeValueDescription + ' [ ' + this.codeValueId + ' ] ' + '</option>');
			});
			toggleIndcTableCrsWlk = 'CODE';
		}
	});
}



function toggleIndsCodeTableToCrsWlk() {

	$.getJSON('toggleIndsCodeTable.form', {
		toggleIndicator : toggleIndcTableToCrsWlk,
		ajax : 'true'
	}, function(data) {
		$("#toindustryTableName").empty();
		$("#toindustryTableName").append('<option value="">--  Select Industry Code Table  --</option>'); 
		if(toggleIndcTableToCrsWlk == 'CODE') {
			$.each(data, function() {			 
				 $("#toindustryTableName").append('<option value="' + this.codeValueId + '">' + this.codeValueId + ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
			});
			toggleIndcTableToCrsWlk = 'VALUE';
		} else {
			$.each(data, function() {			 
				 $("#toindustryTableName").append('<option value="' + this.codeValueId + '">' + this.codeValueDescription + ' [ ' + this.codeValueId + ' ] ' + '</option>');
			});
			toggleIndcTableToCrsWlk = 'CODE';
		}
	});
}


function toggleFromLang() {

	$.getJSON('toggleLanguageCode.form', {
		toggleIndicator : toggleIndcFromLang,
		ajax : 'true'
	}, function(data) {
		$("#language").empty();
		$("#language").append('<option value="">--  Select Language  --</option>'); 
		if(toggleIndcFromLang == 'CODE') {
			$.each(data, function() {			 
				 $("#language").append('<option value="' + this.codeValueId + '">' + this.codeValueId + ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
			});
			toggleIndcFromLang = 'VALUE';
		} else {
			$.each(data, function() {			 
				 $("#language").append('<option value="' + this.codeValueId + '">' + this.codeValueDescription + ' [ ' + this.codeValueId + ' ] ' + '</option>');
			});
			toggleIndcFromLang = 'CODE';
		}
	});
}


function toggleToLang() {

	$.getJSON('toggleLanguageCode.form', {
		toggleIndicator : toggleIndcToLang,
		ajax : 'true'
	}, function(data) {
		$("#tolanguage").empty();
		$("#tolanguage").append('<option value="">--  Select Language  --</option>'); 
		if(toggleIndcToLang == 'CODE') {
			$.each(data, function() {			 
				 $("#tolanguage").append('<option value="' + this.codeValueId + '">' + this.codeValueId + ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
			});
			toggleIndcToLang = 'VALUE';
		} else {
			$.each(data, function() {			 
				 $("#tolanguage").append('<option value="' + this.codeValueId + '">' + this.codeValueDescription + ' [ ' + this.codeValueId + ' ] ' + '</option>');
			});
			toggleIndcToLang = 'CODE';
		}
	});
}



function toggleFromLengthCode() {

	$.getJSON('toggleLengthCode.form', {
		toggleIndicator : toggleIndcFromLengthCode,
		ajax : 'true'
	}, function(data) {
		
		$("#lengthcode").empty();
		$("#lengthcode").append('<option value="">--  Select Lengthcode  --</option>'); 
		if(toggleIndcFromLengthCode == 'CODE') {
			$.each(data, function() {			 
				 $("#lengthcode").append('<option value="' + this.codeValueId + '">' + this.codeValueId + ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
			});
			toggleIndcFromLengthCode = 'VALUE';
		} else {
			$.each(data, function() {			 
				 $("#lengthcode").append('<option value="' + this.codeValueId + '">' + this.codeValueDescription + ' [ ' + this.codeValueId + ' ] ' + '</option>');
			});
			toggleIndcFromLengthCode = 'CODE';
		}
	});
}


function toggleToLengthCode() {

	$.getJSON('toggleLengthCode.form', {
		toggleIndicator : toggleIndcToLengthCode,
		ajax : 'true'
	}, function(data) {
		
		$("#tolength").empty();
		$("#tolength").append('<option value="">--  Select Lengthcode  --</option>'); 
		if(toggleIndcToLengthCode == 'CODE') {
			$.each(data, function() {			 
				 $("#tolength").append('<option value="' + this.codeValueId + '">' + this.codeValueId + ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
			});
			toggleIndcToLengthCode = 'VALUE';
		} else {
			$.each(data, function() {			 
				 $("#tolength").append('<option value="' + this.codeValueId + '">' + this.codeValueDescription + ' [ ' + this.codeValueId + ' ] ' + '</option>');
			});
			toggleIndcToLengthCode = 'CODE';
		}
	});
}

/*function commontoggleChange(first,second)
{
	if($("#"+first).css("display") == "inline")
	{
		$("#"+first).css("display","none");
		$("#"+first).val('');
		$("#"+second).css("display","inline");
	}
	else if($("#"+first).css("display") == "none")
	{
		$("#"+first).css("display","inline");
		$("#"+second).css("display","none");	
		$("#"+second).val('');	
	}		
}*/


function selectalllanguagecheckboxes(ref)
{
	
	if(ref.checked == true)
    {
                $('input[type=checkbox][name=languageCodeList]').each(function() 
                {  
                	$('#codeLength,#codeLengthCheck').css('display','block');
              	  this.checked = true;                      
                });
    }
    else if(ref.checked == false)
    {
                $('input[type=checkbox][name=languageCodeList]').each(function()                 		  
                { 
                	$('#codeLength,#codeLengthCheck').css('display','none');
              	  this.checked = false;                      
                });   
     }	
}

function selectonelangcheckbox(ref)
{
	
	var flag=false;
	if(ref == true)
	{
		$('#codeLength,#codeLengthCheck').css('display','block');		
	}
	else
	{
		$('input[type=checkbox][name=languageCodeList]').each(function() 
		{ 
			if(this.checked == true)
			flag=true;
		});	
		if(flag == false)		
			$('#codeLength,#codeLengthCheck').css('display','none');
	}
}

function selectalllengthcodecheckboxes(ref)
{	
	
	if(ref.checked == true)
    {
                $('input[type=checkbox][name=descLengthCodeList]').each(function() 
                {                  	
              	  this.checked = true;                      
                });
    }
    else if(ref.checked == false)
    {
                $('input[type=checkbox][name=descLengthCodeList]').each(function()                 		  
                {                 	
              	  this.checked = false;                      
                });   
     }	
	
}

function uncheckalllanguages(ref)
{
	
	if(ref.checked == false)
	{
			$('input[type=checkbox][name=language]').each(function() 
			{ 
				if(this.checked == true)
				{
					if($(":checked").val() == "All Languages")
					this.checked=false;
				}
			});
	}
}
function uncheckalllengthcode(ref)
{
	
	if(ref.checked == false)
	{
			$('input[type=checkbox][name=lengthcode]').each(function() 
			{ 
				if(this.checked == true)
				{
					if($(":checked").val() == "All Description Length Codes")
					this.checked=false;
				}
			});
	}
}

