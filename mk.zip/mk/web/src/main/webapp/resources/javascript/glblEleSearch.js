/**
 * This file serves allSearch.jsp in globalElement
 */

$(document).ready(function() {
	configureGlblEleAllSearchDataTable();	
	bindGlobalElementSearchEvents();
	if($("#updateElmentSuccess").val()){
		alert("Global Element is updated in Reference Data successfully");
	}
	
});

function bindGlobalElementSearchEvents(){
	
	


$('#financialSearchBtn').bind('click',function(event) {	
	var regex=/^[0-9]+$/;
	if($('#elementId').val() != ""){
	
		if(!$('#elementId').val().match(regex)){
			$('#errorMsg').html("Element Id should contain only digits");
				 $('#errorMsg').show();
		}else{
	
			var searchCriteriaDelimiter = "#~";
				$('#errorMsg').hide();			
				glblEleAllSearchResultsTable.fnFilter($('#elementId').val()+searchCriteriaDelimiter+$('#topicName').val()+searchCriteriaDelimiter+$('#elementName').val()+searchCriteriaDelimiter+$('#shortdesc').val());
				$('#glblEleAllSearchResults').show();	
				$('#allExportBtn').show();	
				
	}		
	}else{
	
			var searchCriteriaDelimiter = "#~";
				$('#errorMsg').hide();			
				glblEleAllSearchResultsTable.fnFilter($('#elementId').val()+searchCriteriaDelimiter+$('#topicName').val()+searchCriteriaDelimiter+$('#elementName').val()+searchCriteriaDelimiter+$('#shortdesc').val());
				$('#glblEleAllSearchResults').show();	
				$('#allExportBtn').show();	
				
	}	
	
		});

$('#allExportBtn').bind('click',function(event) {	
	var searchCriteriaDelimiter = "#~";
	var criteriaString=encodeURIComponent($('#elementId').val()+searchCriteriaDelimiter+$('#topicName').val()+searchCriteriaDelimiter+$('#elementName').val()+searchCriteriaDelimiter+$('#shortdesc').val());	
	location.href = "allSearchExportToExcelResultsBkp.form?type=export&sSearch="+criteriaString+"&time="+new Date().getTime();	
	return false; // to prevent event bubbling
});	
	
		
}


var glblEleAllSearchResultsTable;
var expnDate;
function configureGlblEleAllSearchDataTable(){
	glblEleAllSearchResultsTable = $("#glblEleAllSearchResultsTable").dataTable({
	
        "bServerSide": true,
        "sAjaxSource": "allSearchAjaxResultsBkp.form",
        "bProcessing": false,		
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aaSorting": [],
        "aoColumns": [null,{ "bVisible": false },null,null,{ "bVisible": false },{ "bVisible": false },null,{ "bVisible": false },
		{ 
			
            "aTargets": [8], 
            "bSearchable": false, 
            "sType": 'date',
			"sClass": "right",
            "fnRender": function ( oObj ) {				
				if(oObj.aData[8] != null){					
					var javascriptDate = new Date(oObj.aData[8]);
					//javascriptDate = javascriptDate.getDate()+"/"+(javascriptDate.getMonth()+1)+"/"+javascriptDate.getFullYear();
					expnDate = getFormattedDate(javascriptDate);
					return "<div align='center'>"+expnDate+"<div>";
				}else{
					expnDate = "";
					return "<div align='center'>"+expnDate+"<div>";
				}
				
            }
        }
,{ "bVisible": false },{ "bVisible": false }],
            "fnRowCallback" : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
				if($('#elementName').val() != ""){
					$('td:eq(2)', nRow).highlight($('#elementName').val());
				}
				if($('#shortdesc').val() != ""){
					$('td:eq(3)', nRow).highlight($('#shortdesc').val());
				}
				setHyperLinkOnGlobalElementSearchColumns(nRow, aData);			
				
				return nRow;
			}
        
  });
}

function getFormattedDate(dString) {
         var month = new Array();
          month[0] = "Jan";
          month[1] = "Feb";
          month[2] = "Mar";
          month[3] = "Apr";
          month[4] = "May";
          month[5] = "Jun";
          month[6] = "Jul";
          month[7] = "Aug";
          month[8] = "Sep";
          month[9] = "Oct";
          month[10] = "Nov";
          month[11] = "Dec";
          var d = new Date();
          var n = month[dString.getMonth()];
          d=dString.getDate()+"-"+n+"-"+dString.getFullYear();
          return d;
}


function setHyperLinkOnGlobalElementSearchColumns(nRow, aData){
//	$('td:eq(0)', nRow).width("13%");
	$('td:eq(0)', nRow).html(getAreaCodeColumnHtml(aData[0]));
	$('td:eq(0)', nRow).css('text-align', 'left');		
}

function getAreaCodeColumnHtml(value1){
	//return "<a href='editScoreSearch.form?scrID=" + value1 + "&scrTypCd="+value2+"&scrTypDesc="+value3+"&scrMktCd="+value4+"&countryName="+value5+"&scrGruCd="+value6+"&GruTypDesc="+value7+"'>" + value1 + "</a>";
	return "<a href='editGlobalElementSearch.form?elementID=" + value1 + "'>" + value1 + "</a>";
}


function validateIsNumber(event) {
	
	var charCode = (event.which) ? event.which : event.keyCode;
    if (charCode == 46 && event.srcElement.value.split('.').length>1) {
        return false;
    }
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    if(charCode == 13)
    	return false;
    return true;
}
