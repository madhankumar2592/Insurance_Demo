/**
 * This file serves allSearch.jsp in globalElement
 */

$(document).ready(function() {
	configureGlblEleAllSearchDataTable();	
	bindGlobalElementSearchEvents();
	var topic=$('#topicName').val();
	
	$('#pageTitle').html(topic+" Search");
	
	
});

function bindGlobalElementSearchEvents(){
	
	


$('#financialSearchBtn').bind('click',function(event) {		
	
			var searchCriteriaDelimiter = "#~";
				$('#errorMsg').hide();			
				glblEleAllSearchResultsTable.fnFilter($('#elementId').val()+searchCriteriaDelimiter+$('#topicName').val()+searchCriteriaDelimiter+$('#elementName').val()+searchCriteriaDelimiter+$('#shortdesc').val());
				$('#glblEleAllSearchResults').show();	
				$('#allExportBtn').show();	
				
			
		});

$('#allExportBtn').bind('click',function(event) {	
	var searchCriteriaDelimiter = "#~";
	var criteriaString=encodeURIComponent($('#elementId').val()+searchCriteriaDelimiter+$('#topicName').val()+searchCriteriaDelimiter+$('#elementName').val()+searchCriteriaDelimiter+$('#shortdesc').val());	
	location.href = "allSearchExportToExcelResultsBkp.form?type=export&sSearch="+criteriaString+"&time="+new Date().getTime();	
	return false; // to prevent event bubbling
});	
	
		
}


var glblEleAllSearchResultsTable;
function configureGlblEleAllSearchDataTable(){
	glblEleAllSearchResultsTable = $("#glblEleAllSearchResultsTable").dataTable({
	
        "bServerSide": true,
        "sAjaxSource": "allSearchAjaxResultsBkp.form",
        "bProcessing": false,		
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aaSorting": [],
        "aoColumns": [null,{ "bVisible": false },null,null,{ "bVisible": false },null,null,{ "bVisible": false },{ "bVisible": false }],
            "fnRowCallback" : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
				if($('#elementName').val() != ""){
					$('td:eq(2)', nRow).highlight($('#elementName').val());
				}				
				if($('#shortdesc').val() != ""){
					$('td:eq(4)', nRow).highlight($('#shortdesc').val());
				}
				return nRow;
			}
        
  });
}