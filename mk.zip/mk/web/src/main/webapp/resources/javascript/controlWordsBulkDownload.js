$(document).ready(function(){
	bindControlWordsBulkDownload();	
});

function bindControlWordsBulkDownload()
{
	$('#bulkDownloadCtrlWrdsLink').bind('click',function(event){
		event.preventDefault();
		location.href = "controlWordsBulkDownload.form";
		return false; // to prevent event bubbling
	});
}


function validateCtrlWrdsDownload()
{
	if($("#cwdomain").val() == "")
	{
		alert("Please select a file type");
	}
	else
	{
		$('#confirmMessageSelction').css('display','inline');
		$('#controlWordsBulkDownload').submit();
	}
	
}

function displaycountry()
{
	/*$('#country').attr('disabled',false);*/
	if($("#cwdomain").val() == 'Inferrment Text' || $("#cwdomain").val() == 'Telecommunication') 
	{
		$("#checkboxrow").css("display","block");
	}
	else 
	{
		$("#checkboxrow").css("display","block");
		$("#lancol,#lancolhead").css("display","none");
	}
}

function selectallctrlcountrycheckboxes(ref)
{
	if(ref.checked == true)
    {
		
                $('input[type=checkbox][name=countryList]').each(function() 
                { 
                	if(($("#cwdomain").val() == 'Inferrment Text' || $("#cwdomain").val() == 'Telecommunication'))
            		{
                	$("#lancol,#lancolhead").css("display","block");
            		}
              	  	this.checked = true; 
            		
                });
		
    }
    else if(ref.checked == false)
    {
                $('input[type=checkbox][name=countryList]').each(function()                 		  
                {  
                	$("#lancol,#lancolhead").css("display","none");
                	this.checked = false;                      
                });   
     }
}

function selectonectrlcountrycheckbox(ref)
{
	var flag=false;
	if(ref == true)
	{
		if(($("#cwdomain").val() == 'Inferrment Text' || $("#cwdomain").val() == 'Telecommunication'))
		{
		$("#lancol,#lancolhead").css("display","block");
		}
		else
		{
			$("#lancol,#lancolhead").css("display","none");
		}
	}
	else
	{
		$('input[type=checkbox][name=countryList]').each(function() 
		{ 
			if(this.checked == true)
			flag=true;
		});	
		if(flag == false)		
		{
			$("#lancol,#lancolhead").css("display","none");
		}
	}
}

function uncheckallctrlcountrycheckboxes(ref)
{
	
	if(ref.checked == false)
	{
			$('input[type=checkbox][name=country]').each(function() 
			{ 
				if(this.checked == true)
				{
					if($(":checked").val() == "All Countries")
					this.checked=false;
				}
			});
	}
}

function selectallctrllanguagecheckboxes(ref)
{
	if(ref.checked == true)
    {		
                $('input[type=checkbox][name=languageList]').each(function() 
                {                	
              	  	this.checked = true; 
            		
                });		
    }
    else if(ref.checked == false)
    {
                $('input[type=checkbox][name=languageList]').each(function()                 		  
                {  
                	this.checked = false;                      
                });   
     }

}

function selectonectrllanguagecheckbox(ref)
{ 
	
    if(!$(ref).is(" :checked"))
    {    	
         $('#alllanguages').attr('checked',false);           
    }      
}
