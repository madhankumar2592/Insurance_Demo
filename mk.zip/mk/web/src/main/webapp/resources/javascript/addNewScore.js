$(document).ready(function(){
	initializeScoreAddElements();
	if($("#successMsg").val()){
		alert("New Score is added in Reference Data SOR successfully");
	}
});

function initializeScoreAddElements() {
	
	$(window).keydown(function(event){
	    if(event.keyCode == 13) {
	      event.preventDefault();
	      return false;
	    }
	  });
	
	
	$('#scoreResetButton').bind('click', function(){
		location.href = "addNewScoreHome.form";
		return false;
	});
	
	$('#scoreCancelButton').bind('click', function(){
		location.href = "addNewScoreHome.form";
		return false;
	});
	$("#scoreMarketCodes option").each(function() {
		var mktCd = $("#mktCd").val();
		  if($(this).val() == mktCd) {
		    $(this).attr('selected', 'selected');            
		  }                        
		});
}
function uncheckallMktCodeList(ref) {
	if (ref.checked == false) {
		$("#allmktCode").prop("checked", false);
	}
}
function selectoneMktCodeList(ref) {
	var flag = false;
	if (ref == true) {
	} else {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			if (this.checked == true)
				flag = true;
		});		
	}
}
function selectallMktCodeList(ref) {
	if (ref.checked == true) {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			this.checked = true;
		});
	} else if (ref.checked == false) {
		$('input[type=checkbox][name=marketCodeList]').each(function() {
			this.checked = false;
		});
	}
}
function validateVersion(evt) {
		
	var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode == 46 && evt.srcElement.value.split('.').length>1) {
        return false;
    }
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    if(charCode == 13)
    	return false;
    return true;
}
	
function validateFormFields(){
		if($('#scoreTypeCode').val()== '') {
			$('#errorMsg').text("Please select Score Type Code");
			$('#errorMsg').css("display","block");
		}else if (!($("input:checkbox[name=marketCodeList]:checked").length > 0)) {
			$('#errorMsg').text("Please select Market Type Code");
			$('#errorMsg').css("display","block");
		}else if ($('#scoreVersion').val()== '') {
			$('#errorMsg').text("Please select Score Version");
			$('#errorMsg').css("display","block");
		}else if($('#scoreVersion').val().split(".")[0] == '' || $('#scoreVersion').val().split(".")[1] == ''){
			alert("Please enter a valid Version number");
		}else if($('#scoreVersion').val().split(".")[0].length > 4){
			alert("Number of digits allowed in version before dot(.) is four");			
		}else if ($('#scoreVersion').val()%1 != 0 && $('#scoreVersion').val().split(".")[1].length > 2){	
			alert("Number of digits allowed in version after dot(.) is two");
		}
		else {
			var scrTypVal = $('#scoreTypeCode').val();
			var scrTypText = $('#scoreTypeCode :selected').text();
			var marktSize = $('input:checkbox[name=marketCodeList]:checked').size();
			var marketVal = new Array();
			if($('#allmktCode').attr('checked')){				
				var retVal = confirm("Are you sure you want to add "+scrTypText+" to ALL Score Market Code with Version "+$('#scoreVersion').val()+"?");
					if( retVal == true ){
					  $('#newScoreMappingForm').submit();
					  return true;
					}else{
					  return false;
					}
			}else if(marktSize <= 30 )  {			
			
				$('input:checkbox[name=marketCodeList]:checked').each(function() 
				{
					marketVal.push($(this).attr("class"));
				});				
				var retVal = confirm("Are you sure you want to add "+scrTypText+" to "+marketVal+" with Version "+$('#scoreVersion').val()+"?");
				if( retVal == true ){
				  $('#newScoreMappingForm').submit();
				  return true;
				}else{
				  return false;
				}
		}else {
			$('input:checkbox[name=marketCodeList]:checked').each(function() 
					{
						marketVal.push($(this).attr("class"));
					});
					var retVal = confirm("Are you sure you want to add "+scrTypText+" to "+marktSize+" Score Market Codes with Version "+$('#scoreVersion').val()+"?");
					if( retVal == true ){
					  $('#newScoreMappingForm').submit();
					  return true;
					}else{
					  return false;
					}
				}
		}
		
	
	}