/**
 * This file serves gsrlliterals_search.html.jsp
 */
var xmlLabelSearchResultsDataTable;
$(document).ready(function() {
	bindXmlSchemaLabelsEvents();
	initializeXmlLabelElements();
	configureXmlLabelSearchDataTable();
});

function bindXmlSchemaLabelsEvents() {
//	$("#xmlScmaLabelsLink").bind('click', function(event) {
//		event.preventDefault();
//		location.href = "xmlSchemaLabelHome.form";
//		$('li').removeClass('active');
//		$('#xmlSchemaLabel').closest('li').addClass('active');
//		return false;
//	});

	$("#btnSearchXmlSchema").bind('click', function(event) {
		event.preventDefault();

		if ($("#elemdesc").val() != "") {
			$('#errorMsg').css("display", "none");
			xmlLabelSearchResultsDataTable.fnFilter($("#elemdesc").val());
			// location.href = "xmlSchemaLabelHome.form?elementName=" +
			// $("#elemdesc").val();
			$('#gsrlliteralsTable1').css("display", "block");
		} else {
			// $('#gsrlliteralsTable1').css('display','none');
			$('#errorMsg').css("display", "inline");
		}
		return false;
	});

}

function initializeXmlLabelElements() {

	if ($('#elemdesc').length) {
		$('li').removeClass('active');
		$('#xmlSchemaLabel').closest('li').addClass('active');
		if ($.trim($('#elemdesc').val()) != '') {
			$('#gsrlliteralsTable1').css('display', 'inline');
		}
	}

}

function configureXmlLabelSearchDataTable() {
	xmlLabelSearchResultsDataTable = $("#xmlSearchResultsTable").dataTable(
			{
				"bServerSide" : true,
				"sAjaxSource" : "xmlSearchAjaxResults.form",
				"bProcessing" : false,
				"sPaginationType" : "full_numbers",
				"oLanguage" : {
					"sEmptyTable" : "No data available",
					"sLengthMenu" : " _MENU_ items per page",
					"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
	                "sInfoEmpty": "No entries to show"
				},
				"sDom" : 'tlip',
				// "aoColumns": [null,null,null],
				"fnRowCallback" : function(nRow, aData, iDisplayIndex,
						iDisplayIndexFull) {
					setHyperLinkOnFirstColumn(nRow, aData);
					return nRow;
				}
			});
}

function setHyperLinkOnFirstColumn(nRow, aData) {
	$('td:eq(0)', nRow).html(
			"<a href='xmlSchemaLabelSearchView.form?elementId=" + aData[0]
					+ "&taskId='>" + aData[0] + "</a>");
}
