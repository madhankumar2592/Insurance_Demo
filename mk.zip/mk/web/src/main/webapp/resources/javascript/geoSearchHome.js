/**
 * This file serves geoSearchHome.jsp
 */
var geoSearchResultsDataTable;
var searchIndicator = false;
$(document).ready(function(){
	bindGeoSearchEvents();
	initializeGeoSearchElements();
	configureGeoSearchDataTable();
});

function bindGeoSearchEvents(){
//	$('#geoSearchHomeLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "geoSearchHome.form";
//		return false; // to prevent event bubbling
//	});
	
	$('#geoByCountry').bind('change',function(){
		searchIndicator=false;
		$("#geoSearchResultsTable").find('tbody').hide();
		$("#geoSearchResultsTable_length").hide();
		$("#geoSearchResultsTable_paginate").hide();
		resetGeoHierarchies($(this).val());
		if($.trim($(this).val()) != '' && isTerritoryFieldAvailable()){
			$('#errorBlock').hide();
			populateTerritory($(this).val());
		}
	});
	$('#geoSearchHomeSubmit').bind('click',function(){
		if(isValidSearchCriteria()){
			
			$("#geoSearchResultsTable").find('tbody').empty();
			$("#geoSearchResultsTable").find('tbody').show();
			searchIndicator=true;
			geoSearchResultsDataTable.fnFilter(getSearchCriteria());
		}		
		return false;
	});	
}

function isValidSearchCriteria(){	
	var validationSuccess = true;
	if($.trim($('#geoByCountry').val()) == ''){
		validationSuccess = false;
		alert('Please select country');
	}
	if(validationSuccess){
		validationSuccess = containsAllowedCharsOnly($('#geoByCounty').val());
	}
	if(validationSuccess){
		validationSuccess = containsAllowedCharsOnly($('#geoByPostalTown').val());
	}
	if(validationSuccess){
		validationSuccess = containsAllowedCharsOnly($('#geoByPostalCode').val());
	}
	return validationSuccess;
}

function containsAllowedCharsOnly(inputStr){
	if($.trim(inputStr) == ''){
		return true;
	}
		return true;
	}

function getSearchCriteria(){
	var searchCriteriaDelimiter = "#~";
	var searchCriteria = $('#geoByCountry').val() + searchCriteriaDelimiter + 
						 $('#geoByTerritory').val() + searchCriteriaDelimiter + 
						 $('#geoByCounty').val() + searchCriteriaDelimiter + 
						 $('#geoByPostalTown').val() + searchCriteriaDelimiter + 
						 $('#geoByPostalCode').val(); 
	return searchCriteria;
}

function configureGeoSearchDataTable(){
	geoSearchResultsDataTable = $("#geoSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "geoSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
		"oLanguage": {"sEmptyTable": "", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "iDeferLoading": 0, 
        "aoColumns": [null,null,null,null,null,
                      { "bVisible": false },{ "bVisible": false },
                      { "bVisible": false },{ "bVisible": false },{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnColumns(nRow, aData);		
        	if(searchIndicator) {
        		$("#geoSearchResultsTable_length").show();
        		$("#geoSearchResultsTable_paginate").show();
        	}
		   	return nRow;
        }
	});
}

function fnShowHideColumns() {
	/* Get the DataTables object again - this is not a recreation, just a get of the object */
	var oTable = $('#geoSearchResultsTable').dataTable();
	oTable.fnSetColumnVis( 1, true );
	oTable.fnSetColumnVis( 2, true );
	oTable.fnSetColumnVis( 3, true );
	oTable.fnSetColumnVis( 4, true );
	
	var aoColumns = $('#dynamicColumns').val();

	if(aoColumns != null) {
		var aoColumnArr = aoColumns.split(",");
		
		var nColumnHead = oTable.find('thead tr th');
		if(aoColumnArr[1] != '') { 		
			$(nColumnHead).eq(1).html("<span>"+aoColumnArr[1].split('~')[1]+"</span>");
		}
		if(aoColumnArr[2] != '') {
			$(nColumnHead).eq(2).html("<span>"+aoColumnArr[2].split('~')[1]+"</span>");
		}
		if(aoColumnArr[3] != '') {
			$(nColumnHead).eq(3).html("<span>"+aoColumnArr[3].split('~')[1]+"</span>");
		}		
		if(aoColumnArr[4] != '') {
			$(nColumnHead).eq(4).html("<span>"+aoColumnArr[4].split('~')[1]+"</span>");
		}
		
		if(aoColumnArr[1] == '') $('#geoHierarchySearch').find('tr td:eq(1)').hide(); 
			else $('#geoHierarchySearch').find('tr td:eq(1)').show();
		if(aoColumnArr[2] == '') $('#geoHierarchySearch').find('tr td:eq(2)').hide();
			else $('#geoHierarchySearch').find('tr td:eq(2)').show();
		if(aoColumnArr[3] == '') $('#geoHierarchySearch').find('tr td:eq(3)').hide();
			else $('#geoHierarchySearch').find('tr td:eq(3)').show();
		if(aoColumnArr[4] == '') $('#geoHierarchySearch').find('tr td:eq(4)').hide();
			else $('#geoHierarchySearch').find('tr td:eq(4)').show();
		
		oTable.fnSetColumnVis( 1, aoColumnArr[1] == '' ? false : true );
		oTable.fnSetColumnVis( 2, aoColumnArr[2] == '' ? false : true );
		oTable.fnSetColumnVis( 3, aoColumnArr[3] == '' ? false : true );
		oTable.fnSetColumnVis( 4, aoColumnArr[4] == '' ? false : true );
	}
}

function setHyperLinkOnColumns(nRow, aData){
	var aoColumns = $('#dynamicColumns').val();
	var aoColumnArr = aoColumns.split(",");
	
	$('td:eq(0)', nRow).html(getColumnHtml(aData[5], aData[0]));
	var cIndx = 1;
	for(var indx = 1; indx < 5; indx++) {
		if(aoColumnArr[indx] != '' &&(aData[indx + 5]!= null)) {
			$('td:eq(' + cIndx + ')', nRow).html(getColumnHtml(aData[indx + 5], aData[indx]));

		} else {
			$('td:eq(' + cIndx + ')', nRow).html("--NA--");
		}
		if(aoColumnArr[indx] != '') {
			cIndx = cIndx + 1;
		}
	}
}

function getColumnHtml(code, value){
	return "<a href='geoUnitView.form?geoUnitId=" + code + "&taskId=&source=GeographySearch' class='list'>" + value + "</a>";
}

function populateTerritory(countryVal){
	$.getJSON('retrieveChildGeoUnitsForCountry.form', {
		parentGeoUnitId :countryVal,
		ajax : 'true'
	}, function(data) {
		$("#geoByTerritory").empty();
		$("#geoByTerritory").append('<option value="">-- Select Territory --</option>'); 
		 $.each(data, function() {
			 $("#geoByTerritory").append('<option value="' + this.code + '">' + this.value + '</option>'); 
		 }); 
	});
}

function isProceedWithSubmit(){
	if($.trim($('#geoByCountry').val()) == ''){
		return false;
	}else{
		return true;
	}
}

function initializeGeoSearchElements(){
	if($.trim($('#geoByCountry').val()) != ''){
		populateTerritory($.trim($('#geoByCountry').val()));
	}
}

function isTerritoryFieldAvailable() {
	if($('#dynamicColumns').val() != null) {
		var aoColumns = $('#dynamicColumns').val().substring(1, $('#dynamicColumns').val().length - 1);
		if(aoColumns != null) {		
			var aoColumnArr = aoColumns.split(", ");
			if(aoColumnArr[1] == 'null') {
				return false;
			} else {
				return true;
			}
		}
	}
}

function resetGeoHierarchies(countryVal) {
	$.getJSON('resetGeoHierarchies.form', {
		parentGeoUnitId : countryVal,
		ajax : 'true'
	}, function(data) {
		$("#dynamicColumns").val(data);
		fnShowHideColumns();
    	syncColumnWidth();
	});
}

function syncColumnWidth() {
	var dtColumnHeader = $('#geoSearchResultsTable').find('thead tr th');
	var hFilters = $('#geoHierarchySearch').find('tr td');
	var hIndex = 0;
	
	for(var indx = 0; indx < 3; indx++) {
		hFilters.eq(indx).width(dtColumnHeader.eq(hIndex).width() + 2);
		hIndex = hIndex + 1;
	}
}

function clearGeoDataTableResults() {
	$('#geoSearchResultsTable').find('tbody').html(
		'<tr class="odd"><td colspan="5" class="dataTables_empty">No data available</td></tr>');
}

