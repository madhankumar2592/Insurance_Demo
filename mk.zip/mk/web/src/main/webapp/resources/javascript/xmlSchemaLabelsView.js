/**
 * 
 */

var globalcnt = 0;	
$(document).ready(function() {	
	bindXmlSchemaLabelsViewEvents();
});

function bindXmlSchemaLabelsViewEvents() {
	$("#xmlSchemaEditBtn").click(function() {
		if ($(this).val() == "Edit") {
			$('#errorMsg').hide();
			$.getJSON('lockXmlSchemaForEdit.form',
				{ajax : 'true'},
				function(data) {
					if (data == true) {
						$('#errorMsg').html('The record is locked by another user due to a pending request on the Work Queue.');
						$('#errorMsg').show();
						return false; // to prevent event bubbling
					} else {
						enableEditXmlSchemaElement();
					}
					return false; // to prevent event bubbling
			});
		}
	});
}
				
function enableEditXmlSchemaElement() {
	$('.showable').show();
	$(".pagetitle").html('GSRL Metadata - Edit');
	document.title = $(".pagetitle").html();
	$("#xmlSchemaEditBtn").val('Update');
	$(".editable").removeAttr("disabled");
	$("#xmlSchemaEditBtn").click(function() {
		if (!isValidValues() && !isXMLLiteralDuplicate()) {
			$("#errorMsg").hide();
			$("#xmlSchemaElementForm").submit();
		} else {
			$("#errorMsg").show();
		}
		return false; // to prevent event bubbling }
	});
}
		
function isValidValues(){
	var returnType = isEmptyCheck('businessLitarlsTable');
	return returnType;
}

function isEmptyCheck(tableName){
	var returnType = false;
	$('#' + tableName + ' tr:visible').each(function(){
		$(this).find('.dropdown').each(function(){
			if(!($(this).attr('disabled'))){
				if($(this).val() == ''){
					returnType = true;
					$(this).focus();
				}
				if(returnType){
					return false;
				}
			}
		});
		if(!returnType){
			returnType = isElementsEmpty($(this), '.textBox');
		}
		if(returnType){
			return returnType;
		}
	});
	return returnType;
}
		
function isElementsEmpty(rowHandle, className){
	var returnType = false;
	var validRegex = /^[A-Za-z0-9\s'_,-.]+$/;
	rowHandle.find(className).each(function(){
		if(!($(this).is(':disabled'))) {
			if($.trim($(this).val()) == '') {
				returnType = true;
					$(this).focus();
				alert('Please enter all required fields in text box');
				return false;
			} 
	//		else if(!validRegex.test($.trim($(this).val()))) {
	//			returnType = true;
	//				$(this).focus();
	//				alert('Only alphabets, numbers, space, hyphen, single quotes, underscore and comma are allowed in text boxes');
	//			return false;
	//		}
		}		
	});
	return returnType;
}

function addLiteralsRow() {
	var nextIndex = $(".languageCd").length;
	$('#businessLitarlsTable').append($('#businessLitarlsTable tr:last').clone());
	var newlyAddedXMLNameRow = $('#businessLitarlsTable tr:last');
	updateNamesOfNewRow(newlyAddedXMLNameRow , '.languageCd', nextIndex, 'xmlSchemaElementLabelDetails', 'languageCd', "true");
	updateNamesOfNewRow(newlyAddedXMLNameRow , '.xmlSchemaElementLabelDetailsId', nextIndex, 'xmlSchemaElementLabelDetails', 'xmlSchemaElementLabelDetailsId', "true");
	updateNamesOfNewRow(newlyAddedXMLNameRow , '.changeIndicator', nextIndex, 'xmlSchemaElementLabelDetails', 'changeIndicator', "true");
	updateNamesOfNewRow(newlyAddedXMLNameRow , '.textBox', nextIndex, 'xmlSchemaElementLabelDetails', 'dataElementLabelName', "true");
	updateNamesOfNewRow(newlyAddedXMLNameRow , '.textAreaDescription', nextIndex, 'xmlSchemaElementLabelDetails', 'dataElementLabelDescription', "true");
	$('#businessLitarlsTable').find('tr:last').find('.removeLiteralsRowLink').
	html('<a href="javascript:;" style="text-decoration: none;" onclick="removeLiteralsRow(this,' + nextIndex + ');">[-]</a>');
	newlyAddedXMLNameRow.find('.xmlSchemaElementLabelDetailsId').val(-1);
	newlyAddedXMLNameRow.find('.changeIndicator').val('NEW');
	newlyAddedXMLNameRow.show();
	return false;
}
function removeLiteralsRow(removeHandle, rowIndexToDelete){
	if(isLastRow()){
		alert("At least one Description is mandatory");
		return false;
	}
	if($(removeHandle).closest('tr').find('.xmlSchemaElementLabelDetailsId').val()>0) {
		$(removeHandle).closest('tr').find('.changeIndicator').val("DELETED");
		$(removeHandle).closest('tr').hide();
	} else if($(removeHandle).closest('tr').find('.changeIndicator').val()=='NEW') {
		$(removeHandle).closest('tr').remove();
	}
	
	$('#businessLitarlsTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
		updateNames($(this).find('.xmlSchemaElementLabelDetailsId'), (this.rowIndex - 1), 'xmlSchemaElementLabelDetails', 'xmlSchemaElementLabelDetailsId');
		updateNames($(this).find('.changeIndicator'), (this.rowIndex - 1), 'xmlSchemaElementLabelDetails', 'changeIndicator');
		updateNames($(this).find('.languageCd'), (this.rowIndex - 1), 'xmlSchemaElementLabelDetails', 'languageCd');
		updateNames($(this).find('.textBox'), (this.rowIndex - 1), 'xmlSchemaElementLabelDetails', 'dataElementLabelName');
		updateNames($(this).find('.textAreaDescription'), (this.rowIndex - 1), 'xmlSchemaElementLabelDetails', 'dataElementLabelDescription');
		$(this).find('.removeLiteralsRowLink').html($(this).find('.removeLiteralsRowLink').html().replace(/[0-9]+/, (this.rowIndex - 1)));
		}
	});
	return false;
}
				
function isLastRow(){
	var counter=0;
	$(".detailRow").each(function(){
		if($(this).is(':visible')) {
			counter++;
			}
		});
	if(counter>1){
		return false;
	}
	return true;
}

function isXMLLiteralDuplicate() {
	var selectedLiterals = [];
	var langDesc = [];
	var descRow = $('#businessLitarlsTable').find('.detailRow');
	descRow.each(function(){
		selectedLiterals.push($(this).find('.languageCd').val() + "~" + $(this).find('.dataElementLabelName').val());
	});
	
	var currentLiteral = 0;
	for(var i = 0; i < selectedLiterals.length; i++) {
		currentLiteral = selectedLiterals[i];
		for(var j = i+1; j < selectedLiterals.length; j++) {
			if(selectedLiterals[j] == currentLiteral){
				alert("Duplicate Business Literals");
				return true;
			}
		}
	}
	return false;
}