/**
 * This file serves industryCodeDetail.jsp
 */

$(document).ready(function(){
	initializeIndustryElements();
	configureEmptyDescriptionMappingRows();
	initializeUserMode();
	enableUnsavedMappingTypeCodes();
});

function enableUnsavedMappingTypeCodes(){
	$('#industryMappingTable tr').each(function(){
		if($(this).find('.fromIndustryCodeIdHidden').length){
			if($.trim($(this).find('.fromIndustryCodeIdHidden').val()) == ''){
				$(this).find('.toIndustryCodeTypeCode').attr('disabled', false);
			}
		}
	});
}

function initializeUserMode(){
	if($('#userMode').length){
		if($.trim($('#userMode').val()) == 'edit'){
			$('#industryEditButton').trigger('click');
			$('#errorMsg').show();
		}
	}
}

function getDescriptionForCodeTypeCodes(industryCodeTypeCode, industryCode, textBoxHandler, errorHandler,updateButton,flag){
	errorHandler.hide();
	if(textBoxHandler != null){
		textBoxHandler.val('');
	}
	updateButton.attr("disabled",'disabled');
	$.getJSON('retrieveDescriptionForIndsCodeTypeCode.form', {
		industryCodeTypeCode : industryCodeTypeCode,
		industryCode : industryCode,
		ajax : 'true'
	}, function(data) {
		if(industryCodeTypeCode == $('#industryCodeTypeCode').val()) {
			errorHandler.html("Industry Code that is already mapped to a scheme " +
					"cannot be mapped to another Industry Code within the same scheme");
			errorHandler.show();
		} else if(data.description == 'InvalidCodeTypeCodeCombination') {
			errorHandler.html("Industry Code " + industryCode + " is not valid for the industry " +
				"coding scheme " + industryCodeTypeCode);
			errorHandler.show();
		} else {
			if(textBoxHandler != null){
				textBoxHandler.val(data.description);
				if(flag) {
					enableUpdateButton();
				} else {
					enableIndustryCodeInfermentUpdateButton();
				}				
			}
		}
	});
}

function initializeIndustryElements(){
	$('#industryUpdateButton').hide();
	$('#industryDeleteButton').hide();
	$('#addMappingRow').hide();
	$('#industryEditButton').bind('click', function(){
		$('#errorMsg').hide();
		$.get('lockIndustryCodeForEdit.form', 
			function(data) {			
			if(data != "false") {
				$('#errorMsg').html('The record is locked by '+data+' due to a pending request on the Work Queue.');
				$('#errorMsg').show();
			} else {
				$('#pageTitle').html('Industry Code Data - Edit');
				$('#bcktosrch').html('<a href="#" id="backToIndsCodeSrch">Industry Codes</a>&nbsp;&nbsp;>&nbsp;&nbsp;Industry Code Data Edit');				
				document.title = "Industry Code Data - Edit";
				enableIndustryEditableElements();
			}
		});		
		return false;
	});
	
	$('#backToIndsCodeSrch').bind('click', function(){
		location.href = "indsCodeSearchHome.form";
		return false; // to prevent event bubbling
	});
	
	$('#industryUpdateButton').bind('click', function(){		
		updateIndustry();
		return false;
	});
	
	$('#industryDeleteButton').bind('click', function(){
		$('#alertSectionIndustry').dialog({modal: true, resizable: false, 
			width: 300			
		});
	});
	
	$('#industryCancelButton').bind('click', function(){
		if($("#sourceQueue").val()=="submitter") {
			location.href = "submitterWorkQueueHome.form?domainName=Industry Codes";
		} else if ($("#sourceQueue").val()=="approver") {
			location.href = "approverWorkQueueHome.form?domainName=Industry Codes";
		} else {
			location.href = "indsCodeSearchHome.form";
		}
		return false;
	});
	$('#industryProceedButton').bind('click', function(){
		location.href = "indsCodeDelete.form";
		return false; 
	});
	$('#industryProceedCancel').bind('click', function(){
		$('#alertSectionIndustry').dialog("close");
		$('#alertSectionIndustry').hide();
		return false;
	});
	
	bindIndustryCodeLoseFocus();
	bindMapIndustryCodeLoseFocus();
	bindMapCheckBoxValueToEntity();
	bindDescriptionGroupLevelChange();
	bindIndustryDescriptioinLoseFocus();
	bindIndustryCodeOnFocusOut();
	bindIndustryCodeTypeOnChange();
	$('#addMappingButton').on('click', function(){
		$('#addMappingRow').hide();
		$('#noMapping').hide();
		if($(".mainMapping").length==1){
			addMappingRow();
		}else {
			$('.mainMapping').find(".toIndustryCodeTypeCode").val("");
			$('.mainMapping').find(".toIndustryCode").val("");
			$('.mainMapping').find(".description").val("");
			$('.mainMapping').find(".changeIndicator").val("NEW");
			$('.mainMapping').find(".visibleMapIndicator").attr("checked",false);
		}
		$('.mainMapping').show();
		$('#industryMappingTable tr:last').show();
		$('#industryMappingTable tr:last .editableForNew').attr("disabled",false);
	});
	
	$("#indsAddApproveButton").click(function() {
		completeTaskAjaxOthers(true);
	});
	
	$('#indsAddRejectButton').bind('click',function(event) {
		if(($.trim($("#domainName").val()) == "Industry Codes")  
			||($.trim($("#domainName").val()) == "SCoTS")
			||($.trim($("#domainName").val()) == "Currency Exchange")
			||($.trim($("#domainName").val()) == "XML Schema Labels")){
			$("#reasonDiv").show();
			$("#reason").focus();
			return false;
		} else if($.trim($("#dnbComment").val()) == "") {
	        $("#dnbComment").focus();
			return false;
		} else {
			$('#alertSectionIndustry').show();
		}
	});
	
	$(".descriptionLengthCode").change(function(){
		var selectedRow = $(this).closest('tr');
		if($(this).val()==9120){
			selectedRow.find('industryDescription').attr('maxlength',240);
		}
		if($(this).val()==1441){
			selectedRow.find('industryDescription').attr('maxlength',41);
		}
		if($(this).val()==2121){
			selectedRow.find('industryDescription').attr('maxlength',21);
		}
		return false;
	});
	resetCodeOnChange();
}
function resetCodeOnChange(){
	$(".toIndustryCodeTypeCode").change(function(){
		var selectedRow = $(this).closest('tr');
		selectedRow.find('.industryCodeDescription').val("");
		selectedRow.find('.toIndustryCode').trigger("focusout");
	});
}

function bindMapCheckBoxValueToEntity(){
	$('input:checkbox').on('click', function(){
		var currentElement = $(this).closest('tr').find('.hiddenMapIndicator');
		if(this.checked){
			currentElement.val("1");
		} else{
			currentElement.val("0");
		}
	});
}

function updateIndustry(){
	if(isIndustryEmpty()){
		return false;
	}
	if(isDescriptionCodeDuplicate()){
			return false;
	}
	if(isTypeCodeDuplicate()){
		return false;
	}
	if( isPreferenceDuplicate()){
		return false;
	}
	if(!isEnglishDescAvail()){		
		return false;
	}
	setPrefferedMapindicator();
	
	if($('#addMappingButton').is(':visible')){
		$('.toIndustryCodeTypeCode').each(function(){
			$(this).closest('tr').remove();
		});
	}
	$('#industryUpdateButton').attr("disabled",true);
	$('#industryCodeForm').submit();	
}

function isEnglishDescAvail() {
	var selectedLanguages = [];
	$("#industryDescriptionTable tr").each(function(){
		if($(this).find('.languageCode').is(':visible') && $(this).find('.languageCode option:selected').length){
			selectedLanguages.push($(this).find('.languageCode option:selected').val());
		}
	});
	
	for(var j = 0; j < selectedLanguages.length; j++){		
		if(selectedLanguages[j] == '39'){	
			return true;
		}
	}
	alert('Description in English is mandatory for an Industry Code');
	return false;
}

function setPrefferedMapindicator(){
	$(".mappingRows").each(function() {
		if($(this).find('.visibleMapIndicator').attr("checked")) {
			$(this).find('.hiddenMapIndicator').val(1);
		} else {
			$(this).find('.hiddenMapIndicator').val(0);
		}
	})
}

function isIndustryEmpty(){
		var returnType = false;
	//returnType = 	isEmptyInTable('industryCodesTable');
	var industryCodeType = $('#industryCodeTypeCode').val();
	var industryCodeGroupLevelCode = $('#industryCodeGroupLevelCode').val();
	var industryCode = $('#industryCode').val();
	if(($.trim(industryCode) == '') || ($.trim(industryCodeType) == '') ){
		returnType= true;
	}
	if($.trim(industryCodeType) == '') {
		$("#errorMsgIndustryCode").html("Please Enter Industry Code Table");
		$("#errorMsgIndustryCode").show();
		$('#industryCodeTypeCode').focus();
		return true;
	} else if($.trim(industryCode) == '') {
		$("#errorMsgIndustryCode").html("Please Enter Industry Code");
		$("#errorMsgIndustryCode").show();
		$('#industryCode').focus();
		return true;
	} else	{
		$("#errorMsgIndustryCode").hide();
	}
	if(isDropDownEmpty($('.languageCode'))) {
		alert('Please select Language from the drop-down list');
		return true;
	} else if(isDropDownEmpty($('.descriptionLengthCode'))) {
		alert('Please select Description Length Code');
		return true;
	}else if(isDropDownEmpty($('.industryDescription'))) {
		alert('Please enter Industry Code Description');
		return true;
	}
	if( !returnType){
		if($('#industryMappingTable').find('.toIndustryCodeTypeCode').length > 1) {
			returnType = isIndsCodeMappingEmpty('industryMappingTable', 'Industry Code Mapping');
		} else if ($('#industryMappingTable').find('.toIndustryCodeTypeCode').eq(0).val() != '') {
			returnType = isIndsCodeMappingEmpty('industryMappingTable', 'Industry Code Mapping');
		}
	} 
	return returnType;
}

function isIndsCodeMappingEmpty(tableName, displayLtrl){
	var returnType = false;
	$('#' + tableName + ' tr:visible').each(function(){
		$(this).find('.dropdown').each(function(){
			if(!($(this).is(':disabled'))){
				if($(this).val() == ''){
					returnType = true;
					$(this).focus();
					alert('To add an Industry Code Mapping, please select Industry Code Type and enter Industry Code');
					return false;
				}
			}
		});

		if(!returnType) {
			returnType = isIndsCodeElementOfClassEmpty($(this), '.textBox');
		}		
		if(returnType) {
			return false;
		}
	});

	return returnType;
}

function isIndsCodeElementOfClassEmpty(rowHandle, className){
	var returnType = false;
	var validRegex = /^[A-Za-z0-9\s'_,-.]+$/;
	rowHandle.find(className).each(function(){
		if(!($(this).is(':disabled'))){
			if($.trim($(this).val()) == ''){
				returnType = true;
				$(this).focus();
				alert('To add an Industry Code Mapping, please enter Industry Code');
				return false; 
			} 
		}	
	});
	return returnType;
}

function enableIndustryEditableElements(){
	$('.showable').show();
	$('.editable').attr("disabled",false);
	$('#industryEditButton').hide();
	$('#industryUpdateButton').show();
	// fix for defect 4121
	if($('#sessionTaskId').val() == '') {
		$('#industryDeleteButton').show();
	} else {
		$('.removeMappingRowLink').hide();
		$('.removeDescriptionRowLink').hide();
	}
	
	enableEmptyDescriptionMappingRows();
	
	if($('#industryCodeGroupLvelCode').val() != "") {
		var selectedGrpLevelCode = $('#industryCodeGroupLvelCode option:selected').html();
		var maxLmt = selectedGrpLevelCode.substring(
				selectedGrpLevelCode.indexOf('[') + 1, selectedGrpLevelCode.indexOf('[') + 2);
		$('#industryCode').attr("maxLength", maxLmt);
	} else {
		$('#industryCode').attr("maxLength", "12");
	}
}

function configureEmptyDescriptionMappingRows(){
	if($('#emptyDescriptionList').length && $('#emptyDescriptionList').val()=='yes'){
		$('#industryDescriptionTable tr:last').hide();
	}
	if($('#emptyMappingList').length && $('#emptyMappingList').val()=='yes'){
		$('.mainMapping').hide();
	} else {
		$('#noMapping').hide();
	}
}

function enableEmptyDescriptionMappingRows(){
	if($('#emptyDescriptionList').length && $('#emptyDescriptionList').val()=='yes'){
		$('#industryDescriptionTable tr:last').show();		
	}
	if($('#emptyMappingList').length && $('#emptyMappingList').val()=='yes'){
		$('#noMapping').show();
		$('#addMappingRow').show();
	} else {
		$('#noMapping').hide();
		$('.mainMapping').show();
	}
}

function addDescriptionRow(){
	var nextIndex = $(".languageCode").length;
	$('#industryDescriptionTable').append($('#industryDescriptionTable tr:last').clone());
	var newlyAddedDescriptionRow = $('#industryDescriptionTable tr:last');
	updateNamesOfNewRow(newlyAddedDescriptionRow , '.languageCode', nextIndex, 'industryCodeDescriptions', 'languageCode', "true");
	updateNamesOfNewRow(newlyAddedDescriptionRow , '.industryCodeDescriptionId', nextIndex, 'industryCodeDescriptions', 'industryCodeDescriptionId', "true");
	updateNamesOfNewRow(newlyAddedDescriptionRow , '.changeIndicator', nextIndex, 'industryCodeDescriptions', 'changeIndicator', "true");
	updateNamesOfNewRow(newlyAddedDescriptionRow , '.descriptionLengthCode', nextIndex, 'industryCodeDescriptions', 'descriptionLengthCode', "true");
	updateNamesOfNewRow(newlyAddedDescriptionRow , '.industryDescription', nextIndex, 'industryCodeDescriptions', 'industryDescription', "true");
	
	$('#industryDescriptionTable').find('tr:last').find('.removeDescriptionRowLink').
	html('<a href="javascript:;" style="text-decoration: none;" onclick="removeDescriptionRow(this,' + nextIndex + ');">[-]</a>');
	
	newlyAddedDescriptionRow.find('.industryCodeDescriptionId').val(-1);
	newlyAddedDescriptionRow.find('.changeIndicator').val('NEW');
	newlyAddedDescriptionRow.show();
	bindDescriptionGroupLevelChange();
	bindIndustryDescriptioinLoseFocus()
	return false;

}

function removeDescriptionRow(removeHandle, rowIndexToDelete){
	if($('.languageCode:visible').length ==1){
		alert("At least one Description is mandatory");
		return false;
	}
	if($(removeHandle).closest('tr').find('.industryCodeDescriptionId').val()>0) {
		$(removeHandle).closest('tr').find('.changeIndicator').val("DELETED");
		$(removeHandle).closest('tr').hide();
	} else if($(removeHandle).closest('tr').find('.changeIndicator').val()=='NEW') {
		$(removeHandle).closest('tr').remove();
	}
	
	$('#industryDescriptionTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.languageCode'), (this.rowIndex - 1), 'industryCodeDescriptions', 'languageCode');
			updateNames($(this).find('.industryCodeDescriptionId'), (this.rowIndex - 1), 'industryCodeDescriptions', 'industryCodeDescriptionId');
			updateNames($(this).find('.changeIndicator'), (this.rowIndex - 1), 'industryCodeDescriptions', 'changeIndicator');
			updateNames($(this).find('.descriptionLengthCode'), (this.rowIndex - 1), 'industryCodeDescriptions', 'descriptionLengthCode');
			updateNames($(this).find('.industryDescription'), (this.rowIndex - 1), 'industryCodeDescriptions', 'industryDescription');
			
			$(this).find('.removeDescriptionRowLink').html($(this).find('.removeDescriptionRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function addMappingRow(isAdd){
	var nextIndex = $(".toIndustryCodeTypeCode").length;
	$('#industryMappingTable').append($('#industryMappingTable tr:last').clone());
	var newlyAddedMappingRow = $('#industryMappingTable tr:last');	
	updateNamesOfNewRow(newlyAddedMappingRow , '.toIndustryCodeIdHidden', nextIndex, 'industryCodeMaps', 'industryCodeMapPK.toIndustryCodeId', "true");
	updateNamesOfNewRow(newlyAddedMappingRow , '.changeIndicator', nextIndex, 'industryCodeMaps', 'changeIndicator', "true");
	updateNamesOfNewRow(newlyAddedMappingRow , '.fromIndustryCodeIdHidden', nextIndex, 'industryCodeMaps', 'industryCodeMapPK.fromIndustryCodeId', "true");
	updateNamesOfNewRow(newlyAddedMappingRow , '.toIndustryCodeTypeCode', nextIndex, 'industryCodeMaps', 'toIndustryCode.industryCodeTypeCode', "true");
	updateNamesOfNewRow(newlyAddedMappingRow , '.toIndustryCode', nextIndex, 'industryCodeMaps', 'toIndustryCode.industryCode', "true");
	updateNamesOfNewRow(newlyAddedMappingRow , '.industryCodeDescription', nextIndex, 'industryCodeMaps', 'toIndustryCode.industryCodeDescription', "true");
	updateNamesOfNewRow(newlyAddedMappingRow , '.hiddenMapIndicator', nextIndex, 'industryCodeMaps', 'preferredMapIndicator', "true");
	if(!isAdd){
		newlyAddedMappingRow.addClass('mainMapping');
	}
	newlyAddedMappingRow.find('.hiddenMapIndicator').val('0');
	newlyAddedMappingRow.find('.toIndustryCodeIdHidden').val(-1);
	newlyAddedMappingRow.find('.changeIndicator').val('NEW');
	newlyAddedMappingRow.find('.visibleMapIndicator').attr('checked', false);
	newlyAddedMappingRow.find('.industryCodeDescription').val('');
	newlyAddedMappingRow.find('.industryCodeDescription').attr('disabled',true);
	newlyAddedMappingRow.find('.removeMappingRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeMappingRow(this,' + nextIndex + ','+isAdd+');">[-]</a>');
	bindMapIndustryCodeLoseFocus();
	bindMapCheckBoxValueToEntity();
	resetCodeOnChange();
	return false;
}

function removeMappingRow(removeHandle, rowIndexToDelete,isAdd){
	var diffIndicator=0;
	if($('.mainMapping:visible').length <=2){
		$('.mainMapping').hide();
		$('#noMapping').show();
		$('#addMappingRow').show();
	}
	if(isAdd){
		if(rowIndexToDelete==0 && $('.mainMapping').length==2){
			$(removeHandle).closest('tr').hide();
		}else{
			$(removeHandle).closest('tr').remove();
		}
		diffIndicator=3;
	}
	else if($(removeHandle).closest('tr').find('.toIndustryCodeIdHidden').val()>0) {
		$(removeHandle).closest('tr').find('.changeIndicator').val("DELETED");
		$(removeHandle).closest('tr').removeClass('mainMapping');
		$(removeHandle).closest('tr').hide();
		diffIndicator=4;
		
	} else if($(removeHandle).closest('tr').find('.changeIndicator').val()=='NEW') {
		$(removeHandle).closest('tr').remove();
		diffIndicator=4;
	}
	
	$('.mappingRows').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.toIndustryCodeIdHidden'),  (this.rowIndex - diffIndicator), 'industryCodeMaps', 'industryCodeMapPK.toIndustryCodeId');
			updateNames($(this).find('.fromIndustryCodeIdHidden'),  (this.rowIndex - diffIndicator), 'industryCodeMaps', 'industryCodeMapPK.fromIndustryCodeId');
			updateNames($(this).find('.changeIndicator'),  (this.rowIndex - diffIndicator), 'industryCodeMaps', 'changeIndicator');
			
			updateNames($(this).find('.toIndustryCodeTypeCode'),  (this.rowIndex -diffIndicator), 'industryCodeMaps', 'toIndustryCode.industryCodeTypeCode');
			updateNames($(this).find('.toIndustryCode'),  (this.rowIndex - diffIndicator), 'industryCodeMaps', 'toIndustryCode.industryCode');
			updateNames($(this).find('.industryCodeDescription'),  (this.rowIndex - diffIndicator), 'industryCodeMaps', 'toIndustryCode.industryCodeDescription');
			updateNames($(this).find('.hiddenMapIndicator'),  (this.rowIndex - diffIndicator), 'industryCodeMaps', 'preferredMapIndicator');
			$(this).find('.removeMappingRowLink').html($(this).find('.removeMappingRowLink').html().replace(/[0-9]+/,(this.rowIndex - diffIndicator)));
			}
		});
	enableUpdateButton();
	return false;
}

function bindMapIndustryCodeLoseFocus(){
	$('.toIndustryCode').on('change', function(){
		var industryCodeTypeCode = $(this).closest('tr').find('.toIndustryCodeTypeCode').val();
		var industryCode = $(this).val();
		if(($.trim(industryCode) == '') || ($.trim(industryCodeTypeCode) == '') ){
			return false;
		}
		getDescriptionForCodeTypeCodes(industryCodeTypeCode, 
				industryCode, $(this).closest('tr').find('.industryCodeDescription'), $('#errorMsgMapping'),$('#industryUpdateButton'),true);
	});
}

function bindIndustryCodeLoseFocus(){
	$('#toIndustryCode.industryCode').on('change', function(){
		var industryCodeTypeCode = $('#industryCodeTypeCode').val();
		var industryCode = $(this).val();
		if(($.trim(industryCode) == '') || ($.trim(industryCodeTypeCode) == '') ){
			return false;
		}
		getDescriptionForCodeTypeCodes(industryCodeTypeCode,industryCode, null, $('#errorMsgIndustryCode'),$('#industryUpdateButton'),true);
	});
}

function isDescriptionCodeDuplicate(){
	var selectedNames = [];
	var selectedLanguages = [];
	$("#industryDescriptionTable tr").each(function(){
		if($(this).find('.languageCode option:selected').length){
			selectedLanguages.push($(this).find('.languageCode option:selected').val());
		}
		if($(this).find('.descriptionLengthCode option:selected').length){
			selectedNames.push($(this).find('.descriptionLengthCode option:selected').val());
	}
	});
	
	var currentName = 0;
	var currentLanguage = 0;
	for(var i = 0; i < selectedNames.length; i++){
		currentName = selectedNames[i];
		currentLanguage = selectedLanguages[i];
		for(var j = i+1; j < selectedNames.length; j++){
			if(selectedLanguages[j] == currentLanguage  & selectedNames[j] == currentName){
				alert('Language and Description Length Code combination should be unique');
				return true;
			}
		}
	}
}

function isTypeCodeDuplicate(){
	var selectedType = [];
	var selectedCode = [];
	$("#industryMappingTable tr").each(function(){
		if($(this).find('.toIndustryCodeTypeCode option:selected').length){
			selectedType.push($(this).find('.toIndustryCodeTypeCode option:selected').val());
		}
		if($(this).find('.toIndustryCode').length){
			selectedCode.push($(this).find('.toIndustryCode').val());
		}
	});
	
	var currentType = 0;
	var currentCode = 0;
	for(var i = 0; i < selectedType.length; i++){
		currentType = selectedType[i];
		currentCode = selectedCode[i];
		for(var j = i+1; j < selectedType.length; j++){
		
			if(selectedType[j] == currentType & selectedCode[j] == currentCode){
				alert('Duplicate Industry Code Mapping');
				return true;
			}
		}
	}
	
	var indsCdType = $('#industryCodeTypeCode').val();
	for(var i = 0; i < selectedType.length; i++){
		if(selectedType[i] == indsCdType) {
			alert('Invalid Industry Code Type ' + indsCdType + ' in the mapping');
			return true;
		}
	}
}


function isPreferenceDuplicate(){
	
	var selectedType = [];
	var selectedPreference = [];
	$("#industryMappingTable tr").each(function(){
		if($(this).find('.toIndustryCodeTypeCode option:selected').length){
			selectedType.push($(this).find('.toIndustryCodeTypeCode option:selected').val());
	}
	if($(this).find('.visibleMapIndicator').length){
		if($(this).find('.visibleMapIndicator').attr("checked")){
			selectedPreference.push(true);
		} else {
			selectedPreference.push(false);
		}
	}
		
	});
	
	var currentType = 0;
	var currentPreference = 0;
	for(var i = 0; i < selectedType.length; i++){
		currentType = selectedType[i];
		currentPreference = selectedPreference[i];
		if(currentPreference == true) {
			for(var j = i+1; j < selectedType.length; j++){
				if(selectedType[j] == currentType & selectedPreference[j] == currentPreference){
					alert('Industry Code Mapping preference for a type should be unique');
					return true;
				}
			}
		}
	}
}
function enableUpdateButton(){
	var isInvalidFlag= false;	
	$(".industryCodeDescription").each(function(){
		if($(this).val()==null || $(this).val()==''){
			$('#industryUpdateButton').attr('disabled','disabled');
			//isInvalidFlag=true;
			$(this).closest('tr').find('.toIndustryCode').trigger("focusout");
			return false;
		} 
	});
	if(!isInvalidFlag){
		$('#errorMsgMapping').hide();
		$('#industryUpdateButton').removeAttr('disabled');
	}
}
function bindDescriptionGroupLevelChange() {

	// this will be triggered on every screen load
	$(".descriptionLengthCode").each(function(){
		var descField = $(this).closest('tr').find('.industryDescription');
		var maxLmt = "255";
		if($(this).val() != "") {
			var selectedDescLenCode = $(this).val();
			if(selectedDescLenCode == "1441") {
				maxLmt = "41";
			} else if(selectedDescLenCode == "2121") {
				maxLmt = "21";
			} else if(selectedDescLenCode == "9120") {
				maxLmt = "240";
			}
			descField.attr("maxLength", maxLmt);
		} else {
			descField.attr("maxLength", maxLmt);
		}
	});
	
	// this will be triggered only on the change event
	$(".descriptionLengthCode").bind('change',function(event) {
		var descField = $(this).closest('tr').find('.industryDescription');
		descField.val('');
		if($(this).val() != "") {
			var selectedDescLenCode = $(this).val();
			var maxLmt = "255";
			if(selectedDescLenCode == "1441") {
				maxLmt = "41";
			} else if(selectedDescLenCode == "2121") {
				maxLmt = "21";
			} else if(selectedDescLenCode == "9120") {
				maxLmt = "240";
			}
			descField.attr("maxLength", maxLmt);
		}
	});
}
function isDropDownEmpty(dropDownName) {
	var returnType = false;
	dropDownName.each(function(){
		if(!($(this).is(':disabled'))){
			if($(this).val() == ''|| $(this).val() == null){
				$(this).focus();
				returnType =true;
				return true;
			}
		}
	});
	return returnType;
}
function bindIndustryCodeOnFocusOut(){
	$('#industryCode').on('change', function(){
		$('#industryUpdateButton').attr('disabled',true);
		$('#industrySaveButton').attr('disabled',true);
		$('#errorMsgIndustryCode').hide();
		$('#errorMsgDescription').hide();
		var industryCodeTypeCode = $('#industryCodeTypeCode').val();
		var industryCode = $(this).val();
		if(($.trim(industryCode) == '') || ($.trim(industryCodeTypeCode) == '')){
			return false;
		}
		$.getJSON('retrieveDescriptionForIndsCodeTypeCode.form', {
			industryCodeTypeCode : industryCodeTypeCode,
			industryCode : industryCode,
			ajax : 'true'
		}, function(data) {
			if(data.description == 'InvalidCodeTypeCodeCombination'){
				$('#errorMsgIndustryCode').hide();
				$('#industryUpdateButton').removeAttr('disabled');
				$('#industrySaveButton').removeAttr('disabled');
				
			} else {
				$('#errorMsgIndustryCode').html('The Industry Code '+ industryCode +' already exists in the system.' );
				$('#errorMsgIndustryCode').show();
				$('#industryUpdateButton').attr('disabled',true);
				$('#industrySaveButton').attr('disabled',true);
				$('.industryDescription').trigger('focusout');
			}
		});		
		return false;
	});
}
function bindIndustryCodeTypeOnChange(){
	$('#industryCodeTypeCode').on('change', function(){
		$('#industryCode').trigger('focusout');
		$('.industryDescription').trigger('focusout');
	});
}
function bindIndustryDescriptioinLoseFocus(){
	$('.industryDescription').on('focusout', function(){
		$('#errorMsgDescription').hide();
		var industryCodeTypeCode = $('#industryCodeTypeCode').val();
		var industryCode = $('#industryCode').val();
		var industryDescription = $(this).val();
		if(($.trim(industryCode) == '') || ($.trim(industryCodeTypeCode) == '')|| ($.trim(industryDescription) == '')){
			return false;
		}
		$.getJSON('isDescriptionDuplicate.form', {
			industryCode:industryCode,
			industryCodeTypeCode:industryCodeTypeCode,
			industryDescription:industryDescription,
			ajax : 'true'
		}, function(data) {
			if(data == true) {
				$('#errorMsgDescription').html('The description "'+industryDescription+'" is duplicate' );
				$('#errorMsgDescription').show();
			} else {
				$('#errorMsgDescription').hide();
			}
		});		
		return false;
	});
}