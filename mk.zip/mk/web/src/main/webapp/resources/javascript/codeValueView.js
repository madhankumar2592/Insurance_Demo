/**
 * This file serves codeValueView.jsp
 */

$(document).ready(function(){
	bindCodeValueViewEvents();
	bindExpirationDateValidation();
	$('.geoDatepickerTextBox').datepicker('disable');
	checkBoxEvents();
});


function bindCodeValueViewEvents(){
	$('#codeValueSearchLnk').bind('click',function(event){
		event.preventDefault();
		location.href = formReturnURL($("#searchSource").val());
		return false; // to prevent event bubbling
	});
	
	$("#codeValueEditButton").click(function() {
		if ($(this).val() == "Edit") {
			$('#errorMsg').hide();			
			$.get("lockCodeValueForEdit.form", function(data){					
				  if (data != "false") {
					  	$('#errorMsg').html('The record is locked by '+data+' due to a pending request on the Work Queue.');
						$('#errorMsg').show();
						return false; // to prevent event bubbling
					} else {
						enableEditCodeValue();
					}
					return false;
				});			
		}
	});
	
	$("#codeValueViewCancelBtn").click(function() {
		location.href = formReturnURL($("#searchSource").val());
		return false; // to prevent event bubbling
	});
	
	
	$(".associationTable tr").each(function(){
		bindCodeTable($(this));	
	});
}

function formReturnURL(searchSource) {
	if(searchSource == 'ListCodeTable') {
		return "listCodeTable.form";
	} else if(searchSource == 'CodeValueSearch'){
		return "searchCodeValue.form";
	} else if(searchSource == 'SubmitterQueue') {
		return "submitterWorkQueueHome.form?domainName=SCoTS";
	} else {
		return "home.form";
	}
}

function bindCodeTable(rowHandle){
	var tableSelectBoxHandle = rowHandle.find('.codeTableId');
	var valueSelectBoxHandle = rowHandle.find('.codeValueId');
	tableSelectBoxHandle.change(function(){
		valueSelectBoxHandle.empty();
		var codeTableId = $(this).val();
		if($.trim(codeTableId) != ''){
			$.getJSON('retrieveCodeValuesForTableId.form', {
				codeTableId :codeTableId
				}, function(data) {
					populateCodeValueDropDown(data[codeTableId], valueSelectBoxHandle);
			});
		}
	});
}

function populateCodeValueDropDown(codeValueData, selectBoxHandle){
	selectBoxHandle.append('<option value="">--Select--</option>');
	$.each(codeValueData, function(index, codeValue) { 
		selectBoxHandle.append('<option value=' + codeValue.codeValueId +'>' + 
				codeValue.codeValueId + '[' +codeValue.codeValueDescription +']</option>');
	});
}

function enableEditCodeValue() {
	$(".pagetitle").html('Code Table - Edit');
	$("#codeValueEditButton").val('Update');
	$(".editable").prop("disabled",false);
	$('.cdValDatepickerTextBox').datepicker('enable');
	$('.geoDatepickerTextBox').datepicker('enable');
	$('.cdValViewNonEditable').datepicker('disable');
	$('.enDescMsg').show();
	
	if($('#changeTypeId').val() == 411){
		$(".codeValueDescription").prop("disabled",false);
		$(".codeValueShortDescription").prop("disabled",false);
		$(".productLiteralDescription").prop("disabled",false);
		$(".productLiteralShortDescription").prop("disabled",false);
		$(".literalMasculineDescription").prop("disabled",false);
		$(".literalMasculineShortDescription").prop("disabled",false);
		$(".literalFeminineDescription").prop("disabled",false);
		$(".literalFeminineShortDescription").prop("disabled",false);
	}
	
	if($('#changeTypeId').val() == 412){
		$("#allSystems").prop("disabled",false);
		$(".systems_checkbox").prop("disabled",false);
		$("#allCountries").prop("disabled",false);
		$(".countries_checkbox").prop("disabled",false);		
	}
	
	var deleteScotsAccess = $('#deleteScotsAccess');
	
	if (deleteScotsAccess != null) {
		if ($('#deleteScotsAccess').val() == 'true') {		
			$('.expirationDate').datepicker('enable');
		} else {
			$('.expirationDate').datepicker('disable');
		}
	}
	
	$(".showable").show();
	var deleteAccess = $('#deleteAccess');
	if($('#deleteAccess').val() == 'true'){
	}
	
	$("#codeValueEditButton").click(function() {
			$("#errorMsg").hide();		
		if (isValidData() && isValidAddCodeValueEntries() && isAlternateSchemaCodeValid()) {
			populateAddCodeValueModel();
			 $("#codeValueViewForm").submit();
		} else {
			$("#errorMsg").show();
		}
		return false; // to prevent event bubbling }
	});
}

function isValidAddCodeValueEntries() {
	// valid codeValue entity elements
	if($("#codescotstable").val() == '') {
		return false;
	} else if($("#codeExplText").val() == '') {
		return false;
	}
	// validate the codeValueText entity elements
	if(!isAddCdValueDescriptionEmpty('.languageCode')) {
		alert("Please select Language");
		return false;
	} else if(!isAddCdValueDescriptionEmpty('.codeValueDescription')) {
		alert("Please enter Code Description");
		return false;
	} else if(!isAddCdValueDescriptionEmpty('.codeValueShortDescription')) {
		alert("Please enter Code Short Description");
		return false;
	} else if(!isAddCdValueDescriptionEmpty('.productLiteralDescription')) {
		alert("Please enter Product Literal Description");
		return false;
	} else if(isEnglishLiteralsAvailable()) {
		alert("Descriptions and Literals in English [39] language is mandatory for a Code Value");
		return false;
	} else if(isCdValLanguageDuplicate()) {
		return false;
	}
	return true;
}

function isCdValLanguageDuplicate(){
	var selectedLanguages = [];
	var langDesc = [];
	var descRow = $('#scotsDescriptionTable').find('.containerRow');
	descRow.each(function(){
		if($(this).find('.expirationDate').val() == '') {
			selectedLanguages.push($(this).find('.languageCode').val());
			langDesc.push($(this).find('.languageCode option:selected').html());
		}
	});
	
	var currentLanguage = 0;
	for(var i = 0; i < selectedLanguages.length; i++) {
		currentLanguage = selectedLanguages[i];
		for(var j = i+1; j < selectedLanguages.length; j++) {
			if(selectedLanguages[j] == currentLanguage){
				alert('Duplicate Language code "' + langDesc[i].substring(langDesc[i].indexOf('[') + 1, langDesc[i].indexOf(']')) + '" in the Descriptions and Literals');
				return true;
			}
		}
	}
}

function isAddCdValueDescriptionEmpty(ele) {
	var hasValue = true;
	$('#scotsDescriptionTable').find(ele).each(function() {
		if($(this).val() == '') {
			$(this).focus();
			hasValue = false;
			return false;
		} 
	});
	return hasValue;
}

function isAlternateSchemaCodeValid(){
	var returnResult = true;
	$('.cdSchemeDropdown').each(function(){
		if($(this).val() == ''){
			returnResult = false;
			alert("Alternate Scheme type code is mandatory field");
			$(this).focus();
			return false;
		}
	});
	
	if(returnResult){
		$('.altSchemeTypeValue').each(function(){
			if($(this).val() == ''){
				returnResult = false;
				alert("Alternate Scheme type Value is mandatory field");
				$(this).focus();
				return false;
			}
		});
	}
	return returnResult;
}
	
function addScotsAltSchemeRowNew(){
	var nextIndex = $(".cdSchemeDropdown").length;
	$('#alternateSchemeCodeTbl').append($('#alternateSchemeCodeTbl tr:last').clone());
	//$('.descTable:last').find($('.removeAlternateSchemeRowLink')).html('<a href="javascript:;" style="text-decoration: none;" onclick="removeAlternalteSchemeRow(this,' + nextIndex + ');">[-]</a>');
	//$('.showable').show();
	var newlyAddedChildRow = $('#alternateSchemeCodeTbl tr:last');
	updateNamesOfNewRow(newlyAddedChildRow , '.cdSchemeDropdown', nextIndex, 'codeValueSchemes', 'alternateSchemeTypeCode', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.altSchemeTypeValue', nextIndex, 'codeValueSchemes', 'alternateSchemeCodeValue', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.altSchemeDescription', nextIndex, 'codeValueSchemes', 'alternateSchemeCodeValueDescription', "false");
	//bindChildAssociations();
	updateNamesOfNewRow(newlyAddedChildRow , '.cdValSchemeEffectiveDate', nextIndex, 'codeValueSchemes', 'effectiveDate', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.cdValSchemeExpirationDate', nextIndex, 'codeValueSchemes', 'expirationDate', "false");
	newlyAddedChildRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePick(newlyAddedChildRow, '.cdValSchemeEffectiveDate');
	initializeNewRowDatePick(newlyAddedChildRow, '.cdValSchemeExpirationDate');
	newlyAddedChildRow.find('.removeAlternateSchemeRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeAlternalteSchemeRow(this,' + nextIndex + ');">[-]</a>');
	newlyAddedChildRow.find('.effectiveDate').val(getToday());
	newlyAddedChildRow.focus();
	bindCodeTable(newlyAddedChildRow.closest('tr'));
	return false;

}

function removeAlternalteSchemeRow(removeHandle, rowIndexToDelete){
	$('#alternateSchemeCodeTbl tr').eq(rowIndexToDelete + 1).find('.cdValDatepickerTextBox').datepicker('destroy');
	//$('#alternateSchemeCodeTbl tr').eq(rowIndexToDelete + 1).find('.cdValDatepickerTextBox').datepicker('destroy');
	
	$(removeHandle).closest('tr').remove();
	
	$('#alternateSchemeCodeTbl tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.cdSchemeDropdown'), (this.rowIndex - 1), 'codeValueSchemes', 'alternateSchemeTypeCode');
			updateNames($(this).find('.altSchemeTypeValue'), (this.rowIndex - 1), 'codeValueSchemes', 'alternateSchemeCodeValue');
			updateNames($(this).find('.altSchemeDescription'), (this.rowIndex - 1), 'codeValueSchemes', 'alternateSchemeCodeValueDescription');
			$(this).find('.cdValSchemeEffectiveDate').datepicker('destroy');
			updateNames($(this).find('.cdValSchemeEffectiveDate'), (this.rowIndex - 1), 'codeValueSchemes', 'effectiveDate');
			$(this).find('.cdValSchemeEffectiveDate').removeClass('hasDatepicker');
			$(this).find('.cdValSchemeEffectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.cdValSchemeExpirationDate').datepicker('destroy');
			updateNames($(this).find('.cdValSchemeExpirationDate'), (this.rowIndex - 1), 'codeValueSchemes', 'expirationDate');
			$(this).find('.cdValSchemeExpirationDate').removeClass('hasDatepicker');
			$(this).find('.cdValSchemeExpirationDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeAlternateSchemeRowLink').html($(this).find('.removeAlternateSchemeRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function addScotsDescRowNew() {
	var nextIndex = $(".languageCode").length;
	$('.descTable:last').after($('.descTable:last').clone());
	$('.descTable:last').find($('.removeNewCdValLiteral')).html('<a href="javascript:;" style="text-decoration: none;" onclick="removeDescriptions(this,' + nextIndex + ');">[-]</a>');
//	$('#codeValDescriptionsTbl').append($('#codeValDescriptionsTbl').find('.lastRow:first').clone());
	$('.showable').show();
	var newlyAddedChildRow = $('.descTable:last tr').eq(-10);
	updateNamesOfNewRow(newlyAddedChildRow , '.languageCode', nextIndex, 'codeValueTexts', 'languageCode', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.cdValTextEffectiveDate', nextIndex, 'codeValueTexts', 'effectiveDate', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.cdValTextExpirationDate', nextIndex, 'codeValueTexts', 'expirationDate', "false");
	newlyAddedChildRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePick(newlyAddedChildRow, '.cdValTextEffectiveDate');
	initializeNewRowDatePick(newlyAddedChildRow, '.cdValTextExpirationDate');
	
	var newlyAddedChildRow = $('.descTable:last tr').eq(-8);
	updateNamesOfNewRow(newlyAddedChildRow , '.codeValueDescription', nextIndex, 'codeValueTexts', 'codeValueDescription', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.codeValueShortDescription', nextIndex, 'codeValueTexts', 'codeValueShortDescription', "false");
	
	var newlyAddedChildRow = $('.descTable:last tr').eq(-6);
	updateNamesOfNewRow(newlyAddedChildRow , '.productLiteralDescription', nextIndex, 'codeValueTexts', 'productLiteralDescription', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.productLiteralShortDescription', nextIndex, 'codeValueTexts', 'productLiteralShortDescription', "false");

	var newlyAddedChildRow = $('.descTable:last tr').eq(-4);
	updateNamesOfNewRow(newlyAddedChildRow , '.literalMasculineDescription', nextIndex, 'codeValueTexts', 'literalMasculineDescription', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.literalMasculineShortDescription', nextIndex, 'codeValueTexts', 'literalMasculineShortDescription', "false");

	var newlyAddedChildRow = $('.descTable:last tr').eq(-2);
	updateNamesOfNewRow(newlyAddedChildRow , '.literalFeminineDescription', nextIndex, 'codeValueTexts', 'literalFeminineDescription', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.literalFeminineShortDescription', nextIndex, 'codeValueTexts', 'literalFeminineShortDescription', "false");
	
	return false;
}

function removeDescriptions(removeHandle, rowIndexToDelete){
	//$('.descTable tr').eq(rowIndexToDelete + 1).find('.cdValDatepickerTextBox').datepicker('destroy');
	
	$(removeHandle).prevUntil('.lastRow').remove();
	
	$('#childRelationTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.countrySelect'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'childGeoUnitId');
			updateNames($(this).find('.childGeoUnitTypeCode'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'geoUnitTypeCode');
			updateNames($(this).find('.addChildGeoUnitId'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'childGeoUnitId');
			$(this).find('.childEffectiveDate').datepicker('destroy');
			updateNames($(this).find('.childEffectiveDate'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'effectiveDate');
			$(this).find('.childEffectiveDate').removeClass('hasDatepicker');
			$(this).find('.childEffectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.childExpiredDate').datepicker('destroy');
			updateNames($(this).find('.childExpiredDate'), (this.rowIndex - 1), 'childGeoUnitAssociations', 'expiredByDate');
			$(this).find('.childExpiredDate').removeClass('hasDatepicker');
			$(this).find('.childExpiredDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeChildRelationRowLink').html($(this).find('.removeChildRelationRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}
function addParentCodeValueRow(){
	var nextIndex = $("#parentTable").length;
	$('#parentTable').append($('#parentTable tr:last').clone());
	var newlyAddedChildRow = $('#parentTable tr:last');
	updateNamesOfNewRow(newlyAddedChildRow , '.parentCodeTableId', nextIndex, 'parentCodeValueAssociations', 'parentCodeTableId', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.parentCodeValueId', nextIndex, 'parentCodeValueAssociations', 'parentCodeValueId', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.effectiveDate', nextIndex, 'parentCodeValueAssociations', 'effectiveDate', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.expirationDate', nextIndex, 'parentCodeValueAssociations', 'expirationDate', "false");
	newlyAddedChildRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePick(newlyAddedChildRow, '.effectiveDate');
	initializeNewRowDatePick(newlyAddedChildRow, '.expirationDate');
	newlyAddedChildRow.find('.removeParentCodeValueRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeParentCodeValueRowLink(this,' + nextIndex + ');">[-]</a>');
	newlyAddedChildRow.focus();
	newlyAddedChildRow.find('.effectiveDate').val(getToday());
	bindCodeTable(newlyAddedChildRow.closest('tr'));
	return false;
}

function removeParentCodeValueRow(removeHandle, rowIndexToDelete){
	$('#parentTable tr').eq(rowIndexToDelete + 1).find('.effectiveDate').datepicker('destroy');
	$('#parentTable tr').eq(rowIndexToDelete + 1).find('.expirationDate').datepicker('destroy');
	
	$(removeHandle).closest('tr').remove();
	
	$('#parentTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.parentCodeTableId'), (this.rowIndex - 1), 'parentCodeValueAssociations', 'parentCodeTableId');
			updateNames($(this).find('.parentCodeValueId'), (this.rowIndex - 1), 'parentCodeValueAssociations', 'parentCodeValueId');
			
			$(this).find('.effectiveDate').datepicker('destroy');
			updateNames($(this).find('.effectiveDate'), (this.rowIndex - 1), 'parentCodeValueAssociations', 'effectiveDate');
			$(this).find('.effectiveDate').removeClass('hasDatepicker');
			$(this).find('.effectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.expirationDate').datepicker('destroy');
			updateNames($(this).find('.expirationDate'), (this.rowIndex - 1), 'parentCodeValueAssociations', 'expirationDate');
			$(this).find('.expirationDate').removeClass('hasDatepicker');
			$(this).find('.expirationDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeParentCodeValueRowLink').html($(this).find('.removeParentCodeValueRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

function addChildAssociationRowNew() {
	var nextIndex = $(".childCodeTableId").length;
	$('#childTable').append($('#childTable tr:last').clone());
	var newlyAddedChildRow = $('#childTable tr:last');
	updateNamesOfNewRow(newlyAddedChildRow , '.childCodeTableId', nextIndex, 'childCodeValueAssociations', 'childCodeTableId', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.childCodeValueId', nextIndex, 'childCodeValueAssociations', 'childCodeValueId', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.effectiveDate', nextIndex, 'childCodeValueAssociations', 'effectiveDate', "false");
	updateNamesOfNewRow(newlyAddedChildRow , '.expirationDate', nextIndex, 'childCodeValueAssociations', 'expirationDate', "false");
	newlyAddedChildRow.find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePick(newlyAddedChildRow, '.effectiveDate');
	initializeNewRowDatePick(newlyAddedChildRow, '.expirationDate');
	newlyAddedChildRow.find('.removeChildRelationRowLink').html('<a href="javascript:;" style="text-decoration: none;" onclick="removeChildAssociationRowNew(this,' + nextIndex + ');">[-]</a>');
	newlyAddedChildRow.find('.effectiveDate').val(getToday());
	newlyAddedChildRow.focus();
	bindCodeTable(newlyAddedChildRow.closest('tr'));
	return false;

}

function removeChildAssociationRowNew(removeHandle, rowIndexToDelete){
	$('#childTable tr').eq(rowIndexToDelete + 1).find('.geoDatepickerTextBox').datepicker('destroy');
	
	$(removeHandle).closest('tr').remove();
	
	$('#childTable tr').each(function() {
		if(this.rowIndex > rowIndexToDelete){
			updateNames($(this).find('.childCodeTableId'), (this.rowIndex - 1), 'childCodeValueAssociations', 'childCodeTableId');
			updateNames($(this).find('.childCodeValueId'), (this.rowIndex - 1), 'childCodeValueAssociations', 'childCodeValueId');
			
			$(this).find('.effectiveDate').datepicker('destroy');
			updateNames($(this).find('.effectiveDate'), (this.rowIndex - 1), 'childCodeValueAssociations', 'effectiveDate');
			$(this).find('.effectiveDate').removeClass('hasDatepicker');
			$(this).find('.effectiveDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.expirationDate').datepicker('destroy');
			updateNames($(this).find('.expirationDate'), (this.rowIndex - 1), 'childCodeValueAssociations', 'expirationDate');
			$(this).find('.expirationDate').removeClass('hasDatepicker');
			$(this).find('.expirationDate').datepicker(getDatepickerOptions(false));
			
			$(this).find('.removeChildRelationRowLink').html($(this).find('.removeChildRelationRowLink').html().replace(/[0-9]+/,(this.rowIndex - 1)));
		}
	});
	return false;
}

var cTblLangToggleInd = true;
function toggleCdValLanguages(rowHandler) {
	if(! $(rowHandler).closest('tr').find(".languageCode").prop('disabled')) {
		$.getJSON('toggleLanguageCodeValueList.form', {
			toggleIndicator : cTblLangToggleInd,
			ajax : 'true'
		}, function(data) {
				$(rowHandler).closest('tr').find(".languageCode").empty();
				$(rowHandler).closest('tr').find(".languageCode").append(
					'<option value="">-- Select Language --</option>');
			if (cTblLangToggleInd) {
				$.each(data, function() {
						$(rowHandler).closest('tr').find(".languageCode").append(
							'<option value="' + this.codeValueId + '">' + this.codeValueDescription
									+ ' [ ' + this.codeValueId + ' ] ' + '</option>');
				});
			} else {
				$.each(data, function() {
						$(rowHandler).closest('tr').find(".languageCode").append(
							'<option value="' + this.codeValueId + '">' + this.codeValueId
									+ ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
				});
			}
			cTblLangToggleInd = !cTblLangToggleInd;
			// QC# 3378 issue fix changes $starts$
			$(rowHandler).closest('td').css('display', 'none');
			var newOpts = $(rowHandler).closest('tr').find(".languageCode").html();
			$(rowHandler).closest('tr').find(".languageCode").html('');
			$(rowHandler).closest('tr').find(".languageCode").html(newOpts);
			$(rowHandler).closest('td').css('display', 'block');
			// QC# 3378 issue fix changes $ends$
		});	
	}
}

function isEnglishLiteralsAvailable() {
	var descRow = $('#scotsDescriptionTable').find('.containerRow');
	var hasEn = false;
	descRow.each(function() {
		var lng = $(this).find('.languageCode').val();
		var exp = $(this).find('.expirationDate').val();
		if(lng == '39' && exp == '') {
			hasEn = true;
		}
	});
	
	if(!hasEn) 
		return true;
	else
		return false;
}

function removeCodeValueDescription(rowHandle){
	$(rowHandle).closest('.containerRow').remove();
	}

function addCodeValueDescription() {
	$('#scotsDescriptionTable').append($('#scotsDescriptionTable').find('.containerRow').last().clone());
	$('#scotsDescriptionTable').find('.containerRow').last().find('.removeNewCdValLiteral').html(
		'<strong><a href="javascript:;" style="text-decoration: none;" onclick="removeCodeValueDescription(this);">[-]</a></strong>'
	);
	$('#scotsDescriptionTable').find('.containerRow:last').find('.languageCode').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.effectiveDate').val(getToday());
	$('#scotsDescriptionTable').find('.containerRow:last').find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePick($('#scotsDescriptionTable').find('.containerRow:last'), '.effectiveDate');
	$('#scotsDescriptionTable').find('.containerRow:last').find('.expirationDate').val("");
	initializeNewRowDatePick($('#scotsDescriptionTable').find('.containerRow:last'), '.expirationDate');
	$('#scotsDescriptionTable').find('.containerRow:last').find('.codeValueDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.codeValueShortDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.productLiteralDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.literalMasculineDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.literalMasculineShortDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.literalFeminineDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.literalFeminineShortDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.editableInNew').attr("disabled",false);
	$('#scotsDescriptionTable').find('.containerRow:last').find('.cdValViewNonEditable').datepicker('enable');
	populateAddCodeValueModel();
	bindExpirationDateValidation();
}

function populateAddCodeValueModel(){
	var modelIndex = 0;
	$('#scotsDescriptionTable').find('.containerRow').each(function(){
		$(this).find('.languageCode').prop('name','codeValueTexts[' + modelIndex + '].languageCode');
		$(this).find('.effectiveDate').prop('name','codeValueTexts[' + modelIndex + '].effectiveDate');
		$(this).find('.expirationDate').prop('name','codeValueTexts[' + modelIndex + '].expirationDate');
		$(this).find('.codeValueDescription').prop('name','codeValueTexts[' + modelIndex + '].codeValueDescription');
		$(this).find('.codeValueShortDescription').prop('name','codeValueTexts[' + modelIndex + '].codeValueShortDescription');		
		$(this).find('.productLiteralDescription').prop('name','codeValueTexts[' + modelIndex + '].productLiteralDescription');
		$(this).find('.productLiteralShortDescription').prop('name','codeValueTexts[' + modelIndex + '].productLiteralShortDescription');
		$(this).find('.literalMasculineDescription').prop('name','codeValueTexts[' + modelIndex + '].literalMasculineDescription');
		$(this).find('.literalMasculineShortDescription').prop('name','codeValueTexts[' + modelIndex + '].literalMasculineShortDescription');		
		$(this).find('.literalFeminineDescription').prop('name','codeValueTexts[' + modelIndex + '].literalFeminineDescription');
		$(this).find('.literalFeminineShortDescription').prop('name','codeValueTexts[' + modelIndex + '].literalFeminineShortDescription');
		
		$(this).find('.effectiveDate').datepicker('destroy');
		updateNames($(this).find('.effectiveDate'), (modelIndex), 'codeValueTexts', 'effectiveDate');
		$(this).find('.effectiveDate').removeClass('hasDatepicker');
		$(this).find('.effectiveDate').datepicker(getDatepickerOptions(false));
		$(this).find('.expirationDate').datepicker('destroy');
		updateNames($(this).find('.expirationDate'), (modelIndex), 'codeValueTexts', 'expirationDate');
		$(this).find('.expirationDate').removeClass('hasDatepicker');
		$(this).find('.expirationDate').datepicker(getDatepickerOptions(false));
		modelIndex++;
	});
}

function isValidData() {
	
	if ($("#codeExplText").val() == "") {
		$('#errorMsg').html("Enter the Business Description ");
	} else if ($("#datePickerFrom").val() == "") {
		$('#errorMsg').html("Enter the Effective Date ");
	} else if ($("#codeExplText").val().length > 4000) {
		$("#errorMsg").html("Business Description is too long only 4000 characters are allowed");
	} else if ($("#reasonText").val().length > 4000) {
		$("#errorMsg").html("Reason text is too long only 4000 characters are allowed");
	} else if(isValidExpirationDate()) {
		$("#errorMsg").html("Expired Date can not be earlier than the Effective Date");
		$("#statusExpiry").focus();
	} else {
		$("#errorMsg").hide();
		return true;
	}
	$("#errorMsg").css("display", "inline");
	return false;
}


function bindExpirationDateValidation() {	
	$('#scotsDescriptionTable').find('.containerRow').each(function(){
		$(this).find('.expirationDate').bind('change', function(){
			var expDate = convertDate($(this).val());
			var effDate = convertDate($(this).closest('tr').find('.effectiveDate').val());
			
			if(expDate - effDate < 0) {
				alert('Expired Date can not be earlier than the Effective Date for the Description');
				$(this).val('');
				$(this).focus();
				return false;
			}
		});
	});
}

function isValidExpirationDate() {
	var cdValExpDt = convertDate($("#statusExpiry").val());
	var cdValEffDt = convertDate($("#statusEffective").val());
	
	if(cdValExpDt - cdValEffDt <= 0) {
		return true;
	} else {
		return false;
	}
}

/**
 * 11/25/2013
 * Added to fix issue reported in CASD Ticket # 208072481
 * This functiionality was missed in the js
*/

function checkBoxEvents() {
	var addSystems = new Array();
	$("#allSystems").click(
			function() {
				if ($(this).attr("disabled")) {
					return false;
				} else if ($("#allSystems").attr("checked")) {
					$("#allSystems").add(".systems_checkbox").attr("checked",
							"checked");
					$(".systems_checkbox").click(function() {
						if ($("#allSystems").attr("checked"))
						$("#allSystems").removeAttr("checked");
					});
				} else {
					$("#allSystems").add(".systems_checkbox").removeAttr(
							"checked");
				}
				
			});
	
	$("#allCountries").click(
			function() {
				if ($(this).attr("disabled")) {
					return false;
				} else if ($("#allCountries").attr("checked")) {
					$("#allCountries").add(".countries_checkbox").attr(
							"checked", "checked");
					$(".countries_checkbox").click(function() {
						if ($("#allCountries").attr("checked"))
						$("#allCountries").removeAttr("checked");
					});
				} else {
					$("#allCountries").add(".countries_checkbox").removeAttr(
							"checked");
				}
			});
}

/*** END***/