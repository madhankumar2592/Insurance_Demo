/**
 * This file serves geoSearchHome.jsp
 */

$(document).ready(function(){
	configureWorkQueueDataTable();
	bindWorkQueueEvents();
	initializeWorkQueueElements();
	configureEmptyDescriptionMappingRows();
});

function bindWorkQueueEvents(){

	//	$('#approverWorkQueueLink').bind('click',function(event){
	//	event.preventDefault();
	//	location.href = "approverWorkQueueHome.form?domainName=";
	//	return false; // to prevent event bubbling
	//	});	

	//	$('#submitterWorkQueueLink').bind('click',function(event){
	//	event.preventDefault();
	//	location.href = "submitterWorkQueueHome.form?domainName=";
	//	return false; // to prevent event bubbling
	//	});	

	//	$('#savedRecordsLink').bind('click',function(event){
	//	event.preventDefault();
	//	location.href = "savedRecords.form?domainName=";
	//	return false; // to prevent event bubbling
	//	});	




	$('#submitterWorkQueueDomainSelect').bind('change',function(){
		if($.trim($(this).val()) == ''){
			$('#tabularData').hide();
		}else{
			location.href = "submitterWorkQueueHome.form?domainName=" + $(this).val();
		}
		return false; // to prevent event bubbling
	});

	$('#savedRecordsDomainSelect').bind('change',function(){
		if($.trim($(this).val()) == ''){
			$('#tabularData').hide();
		}else{
			location.href = "savedRecords.form?domainName=" + $(this).val();
		}
		return false; // to prevent event bubbling
	});

	$('#apprWorkQueueDomainSelect').bind('change',function(){
		if($.trim($(this).val()) == ''){
			$('#tabularData').hide();
		}else{
			location.href = "approverWorkQueueHome.form?domainName=" + $(this).val();
		}
		return false; // to prevent event bubbling
	});


	$('#wQRejectButton').bind('click',function(event){
		if(($.trim($("#domainName").val()) == "Geography") 
				||($.trim($("#domainName").val()) == "Industry Codes") 
				||($.trim($("#domainName").val()) == "SCoTS")
				||($.trim($("#domainName").val()) == "Currency Exchange")
				||($.trim($("#domainName").val()) == "XML Schema Labels")
				||($.trim($("#domainName").val()) == "Control Words")
				||($.trim($("#domainName").val()) == "Financial Templates")){
			$("#reasonDiv").show();
			$("#reason").focus();
			return false;
		} else if($.trim($("#dnbComment").val()) == ""){
			$("#dnbComment").focus();
			return false;
		} else {
			$('#alertSection').show();
		}
	});

	//	$('#rejectProceedButton').bind('click', function(){
	//	if($("#reason").val()){
	//	completeTaskAjaxOthers(false);
	//	$('#reasonDiv').dialog('close');
	//	$('#alertSection').hide();
	//	$('#reasonDiv').hide();
	//	} else {
	//	alert('Reason for rejection is mandatory.');
	//	return false;
	//	}
	//	});

	//	$('#rejectCancelButton').bind('click', function(){
	//	$('#alertSection').hide();
	//	$('#reasonDiv').hide();
	//	$('#reasonDiv').dialog('close');
	//	});

	//	$('#rejectCancel').bind('click', function(){
	//	$('#alertSection').hide();
	//	$('#reasonDiv').hide();
	//	$('#reasonDiv').dialog('close');
	//	});

	//	$('#wQProceedButton').bind('click', function(){
	//	completeTaskAjax(false);
	//	$('#reasonDiv').dialog('close');
	//	return false;
	//	});
	//	$('#wQProceedCancel').bind('click', function(){
	//	$('#alertSection').hide();
	//	$('#reasonDiv').hide()
	//	$('#reasonDiv').dialog('close');
	//	});
	$('#wQCancelButton').bind('click', function(){
		var src = $('#sourceQueue').val();
		if(src == 'approver') {
			location.href = "approverWorkQueueHome.form?domainName=" + $('#domainName').val();
		} else {
			location.href = "submitterWorkQueueHome.form?domainName=" + $('#domainName').val();
		}
		return false;
	});

	/* Implemented to fix 209048785 -Edit SCoTS Approval Page*/

	$('#wQEditButton').bind(
			'click',
			function(event) {

				if ($('#wQEditButton').val() == 'Edit') {
					$("#wQEditButton").val('Update');

					$("#reasonText").attr("disabled", false);
					$("#businessDescription").attr("disabled", false);

					$('#wQApproveButton').hide();
					$('#wQRejectButton').hide();
				} else if ($('#wQEditButton').val() == 'Update') {

					var updatecdvalid = $('#updatecdvalid').val();
					var addcdvalid = $('#addcdvalid').val();
					var changTyp = $('#changTyp').val();

					if (changTyp == '411') {
						var cdvalid = addcdvalid;

					} else {
						var cdvalid = updatecdvalid;

					}

					var reason = $('#reasonText').val();
					var busdesc = $('#businessDescription').val();							  

					var param = {reasonText: reason, businessDescription: busdesc, codeValueId: cdvalid};

					$.ajax({
						url : "editApprovalCodeValue.form",
						data : param,
						success : function(data) {
							alert("Update is completed");
						}
					});

					$("#reasonText").attr("disabled", true);
					$("#businessDescription").attr("disabled", true);
					$('#wQApproveButton').show();
					$('#wQRejectButton').show();
					$('#wQEditButton').val('Edit');
				}

			});



	var backgroundColor;
	$(".colorChangeOnRowHover tbody tr").hover(function() {
		backgroundColor = $(this).css('background-color');
		$(this).css('background-color', '#fcf9db');
	},       
	function() {
		$(this).css('background-color', backgroundColor); 
	}); 

	// $("#unAssignedTaskTable tbody").delegate("tr", "click", function() {
	// submitFromUnAssignedTask(this);
	// });

	$("#myTaskTable tbody").delegate("tr", "click", function() {
		submitFromMyTask(this);
	}); 

	$("#submitterQueueTable tbody").delegate("tr", "click", function() {
		submitFromSubmitterQueue(this);
	});


	$("#savedRecordsTable tbody").delegate("tr", "click", function() {
		showSpinner();
		submitFromSavedRecords(this);
	});

	$('#workQFromViewLink').bind('click',function(event){
		event.preventDefault();
		location.href = "approverWorkQueueHome.form?domainName=";
		return false; // to prevent event bubbling
	});

	$('#workQFromSubmitterViewLink').bind('click',function(event){
		event.preventDefault();
		location.href = "submitterWorkQueueHome.form?domainName=";
		return false; // to prevent event bubbling
	});	

	$('#assignButton').bind('click', function(){
		assignTasksToUser();
		return false;
	});

	$('#unassignButton').bind('click', function(){
		unassignTasks();
		return false;
	});

	$('#downloadLink').bind('click', function(){
		var fileName=encodeURIComponent($('#fileName').val());
		location.href = "viewUploadedFile.form?domainName=" + $('#domainName').val() +"&fileName="+fileName;
		return false;
	});

	stopPropagationCheckbox();

	$('#refreshBtn').click( 
			function() { 
				location.reload(); 
			});
}

function stopPropagationCheckbox(){
	$(':checkbox').on('click', function(event){
		event.stopPropagation();
	});
}

function unassignTasks(){
	var taskIdArray = getSelectedTaskIds($('#myTaskTable'));
	if(taskIdArray.length <= 0){
		alert('Please select at least one task to be unassigned');
		return false;
	}
	$.getJSON('unassignTasks.form', {
		taskIdArray : taskIdArray,
		domainName : $('#domainName').val()
	}, function(data) {
		if(data == true) {
			alert('Selected tasks are unassigned successfully');
			location.href = "approverWorkQueueHome.form?domainName=" + $('#domainName').val();
		} else {
			alert('Unassign task transaction failed');
			location.href = "approverWorkQueueHome.form?domainName=" + $('#domainName').val();
		}
	});	
}

function assignTasksToUser(){
	if($.trim($('#assignTo').val()) == ''){
		alert('Please select an approver to whom the tasks are to be assigned');
		return false;
	}
	var taskIdArray = getSelectedTaskIds($('#unAssignedTaskTable'));
	if(taskIdArray.length <= 0){
		alert('Please select at least one task to be assigned');
		return false;
	}
	$.getJSON('assignTasksToAnotherUser.form', {
		taskIdArray : taskIdArray,
		approverEmailAddress : $.trim($('#assignTo').val()),
		domainName : $('#domainName').val()
	}, function(data) {
		if(data == true) {
			alert('Selected tasks are assigned successfully');
			location.href = "approverWorkQueueHome.form?domainName=" + $('#domainName').val();
		} else {
			alert('Assign task transaction failed');
			location.href = "approverWorkQueueHome.form?domainName=" + $('#domainName').val();
		}
	});	
}

function getSelectedTaskIds(tableHandle){
	var taskIdArray = new Array();
	tableHandle.find(':checkbox').each(function(){
		if($(this).is(':checked')){
			taskIdArray.push($(this).closest('tr').find('.taskId').val());
		}
	});
	return taskIdArray;
}

function submitFromUnAssignedTask(thisHandler){

	// If tracking Id is absent, then the row should be "No data available".
	// Hence do not take any action.
	if($.trim($("td:eq(5)", thisHandler).text()) == ''){
		return false;
	}

	$('#changeType').val($.trim($(".changeTypeId", thisHandler).val()));
	$('#changeTypeDesc').val($.trim($("td:eq(1)", thisHandler).text()));
	$('#dateSubmitted').val($.trim($("td:eq(3)", thisHandler).text()));
	$('#trackingId').val($.trim($("td:eq(5)", thisHandler).text()));
	$('#submitterId').val($.trim($("td:eq(2)", thisHandler).text()));
	$('#submitterRoleId').val($.trim($(".submitterRoleId", thisHandler).val()));
	$('#submitterGroupId').val($.trim($(".submitterGroupId", thisHandler).val()));
	$('#taskId').val($.trim($(".taskId", thisHandler).val()));
	$('#requestStatus').val($.trim($(".requestStatus", thisHandler).val()));
	$('#domainId').val($.trim($(".domainId", thisHandler).val()));
	$('#sourceQueue').val('approver');
	$('#fileName').val($.trim($(".fileName", thisHandler).val()));
	$('#workQueueForm').submit();
}

function submitFromMyTask(thisHandler){
	submitFromUnAssignedTask(thisHandler);
}

function submitFromSubmitterQueue(thisHandler){
	if($.trim($("td:eq(5)", thisHandler).text()) == ''){
		return false;
	}
	if(($.trim($("td:eq(2)", thisHandler).text())).toLowerCase() == 'waiting for resubmission'){
		if(($.trim($('#domainName').val())).toLowerCase() == 'geography'){
			location.href = 'geoUnitView.form?geoUnitId=' + $.trim($(".domainId", thisHandler).val()) +
			'&taskId=' + $.trim($(".taskId", thisHandler).val()) + '&source=SubmitterQueue';
		} else if(($.trim($('#domainName').val())).toLowerCase() == 'industry codes'){
			location.href = 'indsCodeDetail.form?industryCodeId=' + $.trim($(".domainId", thisHandler).val()) +
			'&taskId=' + $.trim($(".taskId", thisHandler).val());
		} else if(($.trim($('#domainName').val())).toLowerCase() == 'currency exchange'){
			location.href = 'currencyExchangeView.form?currencyExchangeId=' + $.trim($(".domainId", thisHandler).val()) +
			'&taskId=' + $.trim($(".taskId", thisHandler).val());
		} else if(($.trim($('#domainName').val())).toLowerCase() == 'xml schema labels'){
			location.href = 'xmlSchemaLabelSearchView.form?elementId=' + $.trim($(".domainId", thisHandler).val()) +
			'&taskId=' + $.trim($(".taskId", thisHandler).val());
		} else if(($.trim($('#domainName').val())).toLowerCase() == 'scots'){
			var chgType = $.trim($(".changeTypeId", thisHandler).val());
			if(chgType == '421') {
				location.href = 'getManageSystemApplicability.form?applicability=System&domainId='
					+ $.trim($(".domainId", thisHandler).val()) + '&taskId=' + $.trim($(".taskId", thisHandler).val()) 
					+ "&dnbSystemCode=" + $.trim($(".domainId", thisHandler).val());
			} else if(chgType == '431'){
				location.href = 'getManageSystemApplicability.form?applicability=Market&domainId='
					+ $.trim($(".domainId", thisHandler).val()) + '&taskId=' + $.trim($(".taskId", thisHandler).val());
			} else if(chgType == '412' || chgType == '411'){
				location.href = 'codeValueView.form?codeValueId='+ $.trim($(".domainId", thisHandler).val()) 
				+ '&taskId=' + $.trim($(".taskId", thisHandler).val()) 
				+ '&changeTypeId=' + $.trim($(".changeTypeId", thisHandler).val())+'&search=SubmitterQueue';
			} else if(chgType == '441'){
				var domainId = $.trim($(".domainId", thisHandler).val());
				var domainIdArray = domainId.split('~');
				location.href = 'retrieveCodeRelationship.form?parentCodeTableId='+ domainIdArray[0] 
				+ '&childCodeTableId='+ domainIdArray[1] 
				+ '&taskId=' + $.trim($(".taskId", thisHandler).val()) + '&isStagingDB=false';
			} else if(chgType == '402' || chgType == '401'){
				location.href = 'codeTableView.form?codeTableId=' + $.trim($(".domainId", thisHandler).val()) +
				'&taskId=' + $.trim($(".taskId", thisHandler).val()) + '&search=SubmitterQueue';
			} 
		} else if(($.trim($('#domainName').val())).toLowerCase() == 'control words'){
			if($.trim($(".changeTypeId").val()) == '512') {
				location.href = 'legalFormInfermentView.form?infermentTextId='
					+ $.trim($(".domainId", thisHandler).val()) + '&taskId=' + $.trim($(".taskId", thisHandler).val());
			} else if($.trim($(".changeTypeId").val()) == '502') {
				location.href = 'indsCodeInfermentSearchView.form?infermentTextId='
					+ $.trim($(".domainId", thisHandler).val()) + '&taskId=' + $.trim($(".taskId", thisHandler).val());
			} else if($.trim($(".changeTypeId").val()) == '591') {
				location.href = 'getAddAreaCodeNumbers.form?phoneAreaCodeId='
					+ $.trim($(".domainId", thisHandler).val())+'&isStagingDB=false'+ '&taskId=' + $.trim($(".taskId", thisHandler).val());
			}
		}else if(($.trim($('#domainName').val())).toLowerCase() == 'financial templates'){
			var financeTemplateId = $.trim($(".domainId", thisHandler).val());
			var taskId = $.trim($(".taskId", thisHandler).val());
			$.getJSON('retrieveFinanceTemplateCodeById.form', {
				financeTemplateId : financeTemplateId,				
				ajax : 'true'
			}, function(data) {
				location.href = "finance?financialTemplateTypeCode="+data+"&taskId="+taskId;				
			});									
		}
	} else {
		$('#changeType').val($.trim($(".changeTypeId", thisHandler).val()));
		$('#changeTypeDesc').val($.trim($("td:eq(0)", thisHandler).text()));
		$('#dateSubmitted').val($.trim($("td:eq(1)", thisHandler).text()));
		$('#requestStatus').val($.trim($("td:eq(2)", thisHandler).text()));
		$('#trackingId').val($.trim($("td:eq(5)", thisHandler).text()));
		$('#submitterId').val($.trim($(".submitterId", thisHandler).val()));
		$('#submitterRoleId').val($.trim($(".submitterRoleId", thisHandler).val()));
		$('#submitterGroupId').val($.trim($(".submitterGroupId", thisHandler).val()));
		$('#taskId').val($.trim($(".taskId", thisHandler).val()));
		$('#domainId').val($.trim($(".domainId", thisHandler).val()));
		$('#sourceQueue').val('submitter');
		$('#fileName').val($.trim($(".fileName", thisHandler).val()));
		$('#workQueueForm').submit();
	}
}


function initializeWorkQueueElements(){


	if($('#domainName').length){
		if($.trim($('#domainName').val()) != ''){
			$('#tabularData').css('display','inline');
		}
	}
	$('#workQueueTabs').tabs();	

	$('.geoDatepickerTextBox').each(function() {
		$(this).datepicker('disable');
	});
}

//select the All checkbox in case of SCoTS system and market applicabilities
function checkAllSystemsChkBox() {
	var allchkFlag = 1;
	$('.wQSysChkBox').each(function() {
		if (this.checked == false) {
			allchkFlag = 0;
		}
	});
	if(allchkFlag == 1) {
		$('.allSysChkBox').attr("checked", "checked");
	}
}
function checkAllCountriesChkBox() {
	var allchkFlag = 1;
	$('.wQCtryChkBox').each(function() {
		if (this.checked == false) {
			allchkFlag = 0;
		}
	});
	if(allchkFlag == 1) {
		$('.allCtryChkBox').attr("checked", "checked");
	}
}

function configureWorkQueueDataTable(){
	$("#unAssignedTaskTable").dataTable({
		"sDom": 'tlip',
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
			"sInfoEmpty": "No entries to show"},
			"iDisplayLength": 10, 
			"aLengthMenu": [10, 25, 50, 100],
			"sPaginationType": "full_numbers",
			"aaSorting": [],
			"fnDrawCallback": function( oSettings ) {
				stopPropagationCheckbox();
			} 
	});

	if($("#myTaskTable").length){
		$("#myTaskTable").dataTable({
			"sDom": 'tlip',
			"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
				"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
				"sInfoEmpty": "No entries to show"},
				"iDisplayLength": 10, 
				"aLengthMenu": [10, 25, 50, 100],
				"sPaginationType": "full_numbers",
				"aaSorting": [],
				"fnDrawCallback": function( oSettings ) {
					stopPropagationCheckbox();
				} 
		});		
	}

	$("#submitterQueueTable").dataTable({
		"sDom": 'tlip',
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
			"sInfoEmpty": "No entries to show"},
			"iDisplayLength": 10, 
			"aLengthMenu": [10, 25, 50, 100],
			"sPaginationType": "full_numbers",
			"aaSorting": [],
			"fnDrawCallback": function( oSettings ) {
				stopPropagationCheckbox();
			} 
	});
	$("#savedRecordsTable").dataTable({
		"sDom": 'tlip',
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
			"sInfoEmpty": "No entries to show"},
			"iDisplayLength": 10, 
			"aLengthMenu": [10, 25, 50, 100],
			"sPaginationType": "full_numbers",
			"fnDrawCallback": function( oSettings ) {
				stopPropagationCheckbox();
			} 
	});
}

function submitFromSavedRecords(thisHandler){
	if($.trim($("td:eq(0)", thisHandler).text()) == ''){
		return false;
	}

	if(($.trim($('#domainName').val())).toLowerCase() == 'financial templates'){
		var financeTemplateId = $.trim($(".domainId", thisHandler).val());
		var taskId = '000';
		$.getJSON('retrieveFinanceTemplateCodeById.form', {
			financeTemplateId : financeTemplateId,				
			ajax : 'true'
		}, function(data) {
			location.href = "finance?financialTemplateTypeCode="+data+"&taskId="+taskId;				
		});									
	}
}

function configureEmptyDescriptionMappingRows(){
	if($('#emptyDescriptionList').length && $('#emptyDescriptionList').val()=='yes'){
		$('#industryDescriptionTable tr:last').hide();
	}
	if($('#emptyMappingList').length && $('#emptyMappingList').val()=='yes'){
		$('.mainMapping').hide();
	} else {
		$('#noMapping').hide();
	}
}


function populateRequest(){

	var  trackingId =[];
	var  domainId =[];
	var changeTypeCodes=[];
	$('#submitterQueueTable tr').each(function(){

		if (($(this).find('.requestBox').prop("checked"))==true){

			trackingId.push($(this).find('.trackingId').val());
			domainId.push($(this).find('.domainId').val());
			changeTypeCodes.push($(this).find('.changeTypeId').val());
		}

	});;


	var domainName=$(".domainNames").val();
	
	
	
	if (trackingId.length!=0 && domainId.length!=0 && changeTypeCodes.length!=0 ){	
		showSpinner();
		var message = withdrawRequest(trackingId,domainName,domainId,changeTypeCodes);
	}else
	{
		alert("Please select a request to withdraw");

	}

}



function withdrawRequest(trackingId,domainName,domainId,changeTypeCodes){	

	var flag = true;
	var param = {trackingIds:trackingId,domainName:domainName,domainId:domainId,changeTypeCode:changeTypeCodes};
	var result="Request Will be removed within next 30 minutes";

	$.ajax({
		cache: false,
		async: false,
		url : "withdrawRequest.form",		 
		data : param,
		success : function(data) {  
			if(data==result){			
				alert(data);
				location.reload(); }
			else{
				$('#errorMsgWthDrwRqst').html('Error - Please Contact ReferenceDataSupport@DNB.com.');
				$('#errorMsgWthDrwRqst').show();	
			}


		},
		error : function(data){

			
			$('#errorMsgWthDrwRqst').html('Error - Please Contact ReferenceDataSupport@DNB.com.');
			$('#errorMsgWthDrwRqst').show();
		
		}                                               
	});	
	return flag;

}

