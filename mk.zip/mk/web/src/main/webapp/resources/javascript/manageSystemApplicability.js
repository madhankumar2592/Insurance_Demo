/**
 * This file serves industryCodeDetail.jsp
 */

var toggleIndicator = false;
var modelAttributeIndex = 0;
var mandatoryErrorMsg;
$(document).ready(function(){
	initializeMsaElements();
	if($('#hiddenDnbSystemCode').val() == '') {
		$('#msaResetButton').hide(); 	
		$('#msaEditButton').hide(); 
	}
	showbutton();
});

function initializeMsaElements(){
	
	mandatoryErrorMsg = $('#errorMsg').html();
	$('#codeTableDiv :checkbox').prop('disabled', true);
		if($.trim($('#sourceQueue').val()) == 'approver'){
			$('#systemApproveButton').show();
			$('#systemRejectButton').show();
		} else {
			$('#systemApproveButton').hide();
			$('#systemRejectButton').hide();
		}
		
	
	
	$('#dnbSystemCode').val($('#hiddenDnbSystemCode').val());
	if($('#dnbSystemCode').val() != ''){
		$('#codeTableDiv').show();
		$('#codeValueDiv').show();
	}
	
	$('.codeValueEditLink').on('click', function(event){
		event.preventDefault();
		retrieveCodeValuesForTableId($(this).closest('tr'));
	});
	
	initializeCodeValueTable();
	
		if($("#changeType").val()=='421' || $("#changeType").val()=='431') {
			if($.trim($('#sourceQueue').val()) != ''){
				$('#msaSaveButton').hide();
			$('#msaEditButton').hide();
				$('#msaResetButton').hide();
				bindCancelButton("submitterWorkQueueHome.form?domainName=SCoTS");
				$('#dnbSystemCode').val($('#domainId').val());
				$('#dnbSystemCode').prop('disabled', true);
				$('.codeValueEditLink').hide();
				$('.addCodeValueRowLink').hide();
			} else {
				bindCancelButton("home.form");
				if($.trim($('#domainId').val()) != ''){
					$('#dnbSystemCode').val($('#domainId').val());
				}
			}
		}
		
		$('#systemApproveButton').on('click', function(){
			completeTaskAjax(true);
		});
		
		$('#systemRejectButton').on('click', function(){
			$("#reasonDiv").show();
			$("#reason").focus();
			return false;
		});
		
//		$('#manageSystemApplicabilityLink').bind('click', function(){
//			location.href = "getManageSystemApplicability.form?applicability=System&domainId=&taskId=&dnbSystemCode=";
//			return false;
//		});
//		
//		$('#manageMarketApplicabilityLink').bind('click', function(){
//		location.href = "getManageSystemApplicability.form?applicability=Market&domainId=&taskId=&dnbSystemCode=";
//			return false;
//		});
		
		$('#msaResetButton').bind('click', function(){
		location.href = "getManageSystemApplicability.form?applicability=" + $('#applicability').val() + "&domainId=&taskId=&dnbSystemCode=";
			return false;
		});
		
		$('#systemApplicabilityToggleBtn').bind('click', function(){
			toggleSystemApplicability();
			return false;
		});
		
		$('#dnbSystemCode').bind('change', function(){
			if($.trim($(this).val()) == ''){
				$('#codeTableDiv').hide();
				$('#codeValueDiv').hide();
			} else {
				location.href = "getManageSystemApplicability.form?applicability=" + $('#applicability').val() +
					"&domainId=&taskId=&dnbSystemCode=" + $('#dnbSystemCode').val();
			}
			return false;
		});

		$('#msaSubmitButton').on('click', function(){
			if($('#dnbSystemCode').val() != '') {
				populateModelAttribute();
				$('#applicabilityForm').submit();
			} else {
				$('#errorMsg').show();
				$('#errorMsg').html('Please select applicability code');
				return false;
			}
			return false;
		});
	
	$('#msaEditButton').on('click', function(){
		if($.trim($('#dnbSystemCode').val()) == ''){
			$('#errorMsg').html('Please select applicability code');
			$('#errorMsg').show();
			return false
		}
		
		$.getJSON('lockApplicabilityForEdit.form', {
			dnbSystemCode : $('#dnbSystemCode').val(),
			applicability : $('#applicability').val()
		}, function(data) {
			// data.username will give the username who locked the record
			if(data.isLocked == true ){
				$('#errorMsg').html('The record is locked by '+data.username+' due to a pending request on the Work Queue.');
				$('#errorMsg').show();
			}else{
				$('#msaEditButton').hide();
				switchToEditMode();
			}				
		});
		return false;
	});
}

function switchToEditMode(){
	$('#errorMsg').hide();
	$('#msaSubmitButton').show();
	$('.codeValueEditLink').show();
	$('#codeTableDiv :checkbox').prop('disabled', false);
	$('.addCodeValueRowLink').show();
}

function initializeCodeValueTable(){
	if(($('.codeValueCodeTableDropdown').length == 1) &&
			($('.codeValueCodeTableDropdown').val() == '')){
		$('.codeValueCodeTableDropdown').hide();
		$('#codeValueParentTable').find('.fixedHeightDiv').hide();
		$('.codeValueEditLink').hide();
	}
}

function bindCancelButton(url){
	$('#msaCancelButton').bind('click', function(){
		location.href = url;
		return false;
	});
}

function bindCodeValueCodeTableDropdown(){
	$('.codeValueCodeTableDropdown').on('change', function(){
		if($.trim($(this).val()) == ''){
			return false;
		}else{
			retrieveCodeValuesForTableId($(this).closest('tr'));
		}
	});
}

function retrieveCodeValuesForTableId(rowHandle){
	var codeTableId = rowHandle.find('.codeValueCodeTableDropdown').val();
	$.getJSON('retrieveCodeValuesForTableId.form', {
		codeTableId :codeTableId
		}, function(data) {
			populateCodeValuesForTableId(data[codeTableId], rowHandle);
		});
}

function populateCodeValuesForTableId(codeValueData, rowHandle){
	var selectedCodeValues = getSelectedCodeValues(rowHandle);
	rowHandle.find("span:gt(0)").remove();
	var valueDivHandle = rowHandle.find('.fixedHeightDiv');
	$.each(codeValueData, function(index, codeValue) { 
		valueDivHandle.append(valueDivHandle.find('.codeValueCheckboxContainer').last().clone());
		valueDivHandle.find('.codeValueCheckbox').last().val(codeValue.codeValueId);
		valueDivHandle.find('.codeValueCheckbox').last().prop('checked', false);
		valueDivHandle.find('.codeValueCheckbox').last().prop('disabled', false);
		valueDivHandle.find('.applicabilityId').last().val('');
		valueDivHandle.find('.codeValueLabel').last().html(
				codeValue.codeValueId + ' [' + codeValue.codeValueDescription + '] ');
	});
	valueDivHandle.find('.codeValueCheckboxContainer').first().remove();
	
	var checkBoxHandle;
	$.each(selectedCodeValues, function(index, codeValueArray) { 
		checkBoxHandle = valueDivHandle.find(":checkbox[value=" + codeValueArray[1] + "]");
		checkBoxHandle.prop("checked", true);
		checkBoxHandle.closest('span').find('.applicabilityId').val(codeValueArray[0]);
	});
}

function getSelectedCodeValues(rowHandle){
	var selectedCodeValues = new Array();
	var codeValueArray;
	rowHandle.find('.codeValueCheckbox').each(function(){
		if($(this).is(':checked')){
			codeValueArray = new Array();
			codeValueArray.push($(this).closest('span').find('.applicabilityId').val());
			codeValueArray.push($(this).val());
			selectedCodeValues.push(codeValueArray);	
		}
	});
	return selectedCodeValues;
}

function toggleSystemApplicability() {
	$.getJSON('toggleSystemApplicability.form', {
		toggleIndicator : toggleIndicator,
		ajax : 'true'
	}, function(data) {
		$("#dnbSystemCode").empty();
		$("#dnbSystemCode").append('<option value=""> -- Select ' + $.trim($('#applicability').val()) + ' Applicability-- </option>'); 
		if(toggleIndicator) {
			$.each(data, function() {			 
				 $("#dnbSystemCode").append('<option value="' + this.code + '">' + this.value + ' [ ' + this.code + ' ] ' + '</option>');
			});
		} else {
			$.each(data, function() {	
				$("#dnbSystemCode").append('<option value="' + this.code + '">' + this.code + ' [ ' + this.value + ' ] ' + '</option>');
			});
		}
		toggleIndicator = !toggleIndicator;
	});
}
function addCodeValueRow(){
	if(($('#codeValueParentTable tr').length == 1) &&
			(!$('#codeValueParentTable').find('.codeValueCodeTableDropdown').is(':visible'))){
			$('#codeValueParentTable').find('.codeValueCodeTableDropdown').show();
			$('#codeValueParentTable').find('.fixedHeightDiv').show();
			$('#codeValueParentTable').find('.removeCodeValueRowLink').show();
	$('#codeValueParentTable').append($('#codeValueParentTable tr:last').clone());
			$('#codeValueParentTable tr:first').remove();
	}else{
		$('#codeValueParentTable').append($('#codeValueParentTable tr:last').clone());
	}
	
	var lastRowHandle = $('#codeValueParentTable tr:last');
	if(lastRowHandle.find('.codeValueEditLink').length){
		lastRowHandle.find('.codeValueEditLink').remove();
	}
	lastRowHandle.find('.removeCodeValueRowLink').html('<a href="#" style="text-decoration: none;" onclick="removeCodeValueRow(this);">[-]</a>');
	populateCodeValueCodeTableDropdown(lastRowHandle.find('.codeValueCodeTableDropdown'));
	bindCodeValueCodeTableDropdown();
	lastRowHandle.find('span:gt(0)').remove();
	lastRowHandle.find('.codeValueCheckbox').val('');
	lastRowHandle.find('.applicabilityId').val('');
	lastRowHandle.find('.codeValueCheckbox').prop('disabled', true);
	lastRowHandle.find('.codeValueCheckbox').prop('checked', false);
	lastRowHandle.find('.codeValueLabel').html('');
	return false;
}

function removeCodeValueRow(removeHandle){
	if($('#codeValueParentTable tr').length == 1){
			$('#codeValueParentTable').find('.codeValueCodeTableDropdown').hide();
			$('#codeValueParentTable').find('.fixedHeightDiv').hide();
			$('#codeValueParentTable').find('.removeCodeValueRowLink').hide();
	}else{
	$(removeHandle).closest('tr').remove();
}
}

function populateCodeValueCodeTableDropdown(selectBoxHandler){
	selectBoxHandler.prop('disabled', false);
	selectBoxHandler.empty();
	selectBoxHandler.append('<option value=""> -- Select Code Table -- </option>');
	$('#codeTable tr').each(function(){
		selectBoxHandler.append('<option value=' + $(this).find(':checkbox').val() + '>' +
				$(this).find('td:last').html() + '</option>');
	});
}

function populateModelAttribute(){
	var applicability = $.trim($('#applicability').val());
	var isSystemApplicability = true;
	var modelAttributeList;
	if(applicability.toLowerCase() == 'system'){
		modelAttributeList = 'systemApplicability';
		isSystemApplicability = true;
	}else if(applicability.toLowerCase() == 'market'){
		modelAttributeList = 'countryApplicability';
		isSystemApplicability = false;
	}

	$('#codeTable tr').each(function(){
		populateEachRecord(this, modelAttributeList, isSystemApplicability, "1", "");
	});
	
	var codeTableId;
	$('#codeValueParentTable tr').each(function(){
		codeTableId = $(this).find('.codeValueCodeTableDropdown').val();
		$(this).find('span').each(function(){
			populateEachRecord(this, modelAttributeList, isSystemApplicability, "0", codeTableId);
		});
	});
	$('#applicabilityTable tr:last').remove();
}

function populateEachRecord(recordHandle, modelAttributeList, isSystemApplicability,
		applicabilityIndicator, codeTableId){
	var dnbSystemCode = $.trim($('#dnbSystemCode').val());
	var applicabilityIdHandle = $(recordHandle).find('.applicabilityId');
	var checkBoxHandle = $(recordHandle).find(':checkbox');
	if((($.trim(applicabilityIdHandle.val()) != '') && (!checkBoxHandle.prop('checked'))) ||
			(($.trim(applicabilityIdHandle.val()) == '') && (checkBoxHandle.prop('checked')))){
		var lastRowHandle = $('#applicabilityTable tr:last');
		if(isSystemApplicability){
			lastRowHandle.find('.sysAppyId').prop('name', modelAttributeList + '['+ modelAttributeIndex  +'].sysAppyId');
			lastRowHandle.find('.sysAppyId').val(applicabilityIdHandle.val());
			lastRowHandle.find('.dnbSystemCode').prop('name', modelAttributeList + '['+ modelAttributeIndex  +'].dnbSystemCode');
			lastRowHandle.find('.dnbSystemCode').val(dnbSystemCode);
		}else{
			lastRowHandle.find('.ctryAppyId').prop('name', modelAttributeList + '['+ modelAttributeIndex  +'].ctryAppyId');
			lastRowHandle.find('.ctryAppyId').val(applicabilityIdHandle.val());
			lastRowHandle.find('.countryGeoUnitId').prop('name', modelAttributeList + '['+ modelAttributeIndex  +'].countryGeoUnitId');
			lastRowHandle.find('.countryGeoUnitId').val(dnbSystemCode);
		}
		lastRowHandle.find('.codeTableId').prop('name', modelAttributeList + '['+ modelAttributeIndex  +'].codeTableId');
		lastRowHandle.find('.codeValueId').prop('name', modelAttributeList + '['+ modelAttributeIndex  +'].codeValueId');
		if(applicabilityIndicator == '1'){
			lastRowHandle.find('.codeTableId').val(checkBoxHandle.val());
			lastRowHandle.find('.codeValueId').val('');
		}else if(applicabilityIndicator == '0'){
			lastRowHandle.find('.codeTableId').val(codeTableId);
			lastRowHandle.find('.codeValueId').val(checkBoxHandle.val());
		}
		lastRowHandle.find('.applicabilityIndicator').prop('name', modelAttributeList + '['+ modelAttributeIndex  +'].applicabilityIndicator');
		lastRowHandle.find('.applicabilityIndicator').val(applicabilityIndicator);
		modelAttributeIndex++;
		$('#applicabilityTable').append($('#applicabilityTable tr:last').clone());
	}
}

function showbutton() {
	if($('#dnbSystemCode').val() == '') {
		$('#msaResetButton').hide(); 	
		$('#msaEditButton').hide(); 
	}
	$(window).load(function(){		
		if($('#dnbSystemCode').val() == '') {
			$('#msaResetButton').hide(); 	
			$('#msaEditButton').hide(); 
		}
		else {			
			$('#msaResetButton').show(); 	
			$('#msaEditButton').show(); 
		}
	});
}