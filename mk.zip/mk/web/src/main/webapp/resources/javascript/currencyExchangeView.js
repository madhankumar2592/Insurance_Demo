/* This page serves currencyExchangeView.jsp */

$(document).ready(function() {
	bindCurrencyExchangeViewEvents();
	$('.geoDatepickerTextBox').datepicker('disable');
});

function bindCurrencyExchangeViewEvents() {
	$("#crcyViewEditBtn").click(function() {
		if($(this).val()=="Edit") {
			$('#errorBlock').hide();
			$.get('lockExchangeRateForEdit.form',				
			 function(data) {				
				if(data != "false") {
					$('#errorMsg').html('The record is locked by '+data+' due to a pending request on the Work Queue.');
					$('#errorMsg').show();
					return false; //to prevent event bubbling
				} else {
					enableEditExchangeRate();
					return false; //to prevent event bubbling
				}
			});
		}
	});
}

function enableEditExchangeRate() {
	$("#pageTitle").html('Currency Exchange - Edit');
	$("#crcyViewEditBtn").val('Update');
	$("#exchangeRate").removeAttr("disabled");
	$("#crcyViewEditBtn").click(function() {
		if(isValidExchangeRate($("#exchangeRate").val())) {
			$("#currencyViewForm").submit();
			return false; //to prevent event bubbling
		} else {
			return false; //to prevent event bubbling
		}		
	});
}
function isValidExchangeRate(exchangeRate){
	if($.trim(exchangeRate) == ''){
		alert("Exchange rate cannot be empty");
		return false;
	}
	if($.isNumeric(exchangeRate) && (exchangeRate > 0)){
		return isValidExchangeRateLength(exchangeRate);
	}else{
		alert("Please enter a valid numeric exchange rate greater than 0");
		return false;
	}
}

function isValidExchangeRateLength(exchangeRate){
	if(exchangeRate.length > 19){
		alert("Exchange rate can have a maximum of 18 digits and decimal point");
		return false;
	}
	var digitArray = exchangeRate.split(".");
	var beforeDecimal;
	var afterDecimal;
	if(digitArray.length > 0){
		beforeDecimal = digitArray[0];
		if(beforeDecimal.length > 9){
			alert("There should be maximum of only 9 digits before the decimal point in Exchange rate");
			return false;
		}
	}
	if(digitArray.length > 1){
		afterDecimal = digitArray[1];
		if(afterDecimal.length > 9){
			alert("There should be maximum of only 9 digits after the decimal point in Exchange rate");
			return false;
		}
	}
	return true;
}