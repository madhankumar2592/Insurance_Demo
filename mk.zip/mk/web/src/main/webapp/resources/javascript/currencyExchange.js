/**
 * This file serves currencyExchange.jsp
 */
var currencySearchResultsTable;
$(document).ready(function(){
	bindCurrencyExchangeSearchEvents();
	initializeCurrencyExchangeElements();
	configureCurrencySearchDataTable();
});


function bindCurrencyExchangeSearchEvents() {
//	$('#currencyLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "currencySearchHome.form";
//		return false; // to prevent event bubbling
//	});
	$('#currencySearchBtn').bind('click',function(event){
		if($.trim($('#fromDate').val()) != $.trim($('#toDate').val())) {
			if($.trim($('#fromcode').val()) == "" && $.trim($('#tocode').val()) == ""){
				$("#errorMsg").html("Please select at least either From Currency Code or To Currency Code");
				$('#errorMsg').show();
				$('#currencySearchResults').hide();
				return false;
			} 
//			Removing the validation as per business requirement			
//			else if($.trim($('#fromcode').val()) == $.trim($('#tocode').val())){
//				$("#errorMsg").html("From Currency Code and To Currency Code should not be same");
//				$('#errorMsg').show();
//				$('#currencySearchResults').hide();
//	
//			}
			var frmtFrmDate = convertDate($('#fromDate').val());
			var frmtToDate = convertDate($('#toDate').val());
			if(frmtFrmDate - frmtToDate > 0) {
				$("#errorMsg").html("From Date should be less than or equal to To Date");
				$('#errorMsg').show();
				$('#currencySearchResults').hide();
			} else {
				$('#errorMsg').hide();
				currencySearchResultsTable.fnFilter(getCurrencySearchCriteria());
				$('#currencySearchResults').show();
			} 
		} else {		
			$('#errorMsg').hide();
			currencySearchResultsTable.fnFilter(getCurrencySearchCriteria());
			$('#currencySearchResults').show();
		}
	});
	$('#crcyExchSearchLnk').bind('click',function(event){
		event.preventDefault();
		location.href = "currencySearchHome.form";
		return false; // to prevent event bubbling
	});	
}
function initializeCurrencyExchangeElements(){
	initializeCurrencyDatepicker();
	if($.trim($('#fromcode').val()) == "" && $.trim($('#tocode').val()) == "") {
		$('#currencySearchResults').hide();
	} else {
		$('#currencySearchResults').show();
	}
	
	if($('#fromcode').length) {
		$('li').removeClass('active');
		$('#currencyHomeLi').addClass('active');
	}
}

function initializeCurrencyDatepicker() {
	$('.currencyDatepickerTextBox').removeClass('hasDatepicker').datepicker(
			getDatepickerOptions(false));
	if($("#toDate").val() == '') {
		$("#toDate").val(getToday());
	}
	if($("#fromDate").val() == '') {		
		$("#fromDate").val(getToday());	
	}
}


function getDatepickerOptions(isDisabled){
	return {
		showOn: "button",
		buttonImage: "./resources/images/cal.png",
		buttonImageOnly: true,
		disabled: isDisabled,
		dateFormat: "yy-mm-dd"
	}
}

function configureCurrencySearchDataTable(){
	currencySearchResultsTable = $("#currencySearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "currencySearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "iDeferLoading": 0, 
        "aoColumns": [null,null,null,null,null,
                      { "bVisible": false},{ "bVisible": false },{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	var viewCurrencyAccess = $('#viewCurrencyAccess');        	
        	if(viewCurrencyAccess != null){
        		if($('#viewCurrencyAccess').val() == 'true'){
        			setHyperLinkOnCurrencyExchangeColumns(nRow, aData);		
                }	
        	}        	        	
		   	return nRow;
        }
  });
}

function setHyperLinkOnCurrencyExchangeColumns(nRow, aData){
	$('td:eq(0)', nRow).html(getCurrencyColumnHtml(aData[7], aData[0] + ' - ' + aData[5]));
	$('td:eq(1)', nRow).html(getCurrencyColumnHtml(aData[7], aData[1] + ' - ' + aData[6]));
	$('td:eq(2)', nRow).html(getCurrencyColumnHtml(aData[7], aData[2]));
	$('td:eq(3)', nRow).html(getCurrencyColumnHtml(aData[7], aData[3]));
	$('td:eq(4)', nRow).html(getCurrencyColumnHtml(aData[7], aData[4]));
}

function getCurrencyColumnHtml(code, value){
	return "<a href='currencyExchangeView.form?currencyExchangeId=" + code + "&taskId='>" + value + "</a>";
}

function getCurrencySearchCriteria(){
	var searchCriteriaDelimiter = "#~";
	var searchCriteria = $('#fromcode').val() + searchCriteriaDelimiter + 
						 $('#tocode').val() + searchCriteriaDelimiter + 
						 $('#fromDate').val() + searchCriteriaDelimiter + 
						 $('#toDate').val() + searchCriteriaDelimiter + 
						 $('#dataprovidercode').val(); 
	return searchCriteria;
}