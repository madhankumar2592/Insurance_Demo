/**
 * This page serves codeTableView.jsp
 */

$(document).ready(function() {
	bindCodeTableViewEvents();
	checkBoxEvents();
});

function bindCodeTableViewEvents() {
	$("#codeTableViewEditBtn").click(function() {
		if ($(this).val() == "Edit") {
			$('#errorMsg').hide();
			$.get('lockCodeTableForEdit.form',				
				function(data) {
					if (data != "false") {
						$('#errorMsg').html('The record is locked by '+data+' due to a pending request on the Work Queue.');
						$('#errorMsg').show();
						return false; // to prevent event bubbling
					} else {
						$('#pageTitle').html('Code Table - Edit');
						$('#bcktosrch').html('<a href="#" id="codeTableBack">Code Table</a>&nbsp;&nbsp;>&nbsp;&nbsp;Code Table Edit');
						
						document.title = "Code Table - Edit";						
						enableEditCodeTable();
					}
					return false; // to prevent event bubbling
			});
		}
	});

	bindclearExpirationDate();
	
	$("#codeTableBack").click(function() {
		location.href = formReturnURL($('#searchSource').val());
		return false; // to prevent event bubbling
	});
	
	$("#codeTableViewCancelBtn").click(function() {
		location.href = formReturnURL($('#searchSource').val());
		return false; // to prevent event bubbling
	});
}

function formReturnURL(searchSource) {
	if(searchSource == 'ListCodeTable') {
		return "listCodeTable.form";
	} else if(searchSource == 'CodeValueSearch'){
		return "searchCodeValue.form";
	} else if(searchSource == 'SubmitterQueue') {
		return "submitterWorkQueueHome.form?domainName=SCoTS";
	} else if(searchSource == 'CodeTableSearch') {
		return "showCodeTableSearch.form";
	} else {
		return "home.form";
	}
}

function bindclearExpirationDate(){
	$('.expirationDate').keydown(function(e){
		if (e.keyCode == 46 || e.keyCode == 8) {
			//Delete and backspace clear text
			$(this).val(''); //Clear text
		}
		//Prevent user from manually entering in a date - have to use the datepicker box         
		e.preventDefault();
	}); 
}
function enableEditCodeTable() {
	$(".pagetitle").html('Code Table - Edit');
	$("#codeTableViewEditBtn").val('Update');
	$(".editable").removeAttr("disabled");
	$('.geoDatepickerTextBox').datepicker('enable');
	var deleteAccess = $('#deleteAccess');
	if($('#deleteAccess').val() != 'true'){
		$('#codeTableExpiration').datepicker('disable');	
	}
	
	$("#codeTableViewEditBtn").click(function() {
		if (isValidData()) {
			$("#errorMsg").hide();
			 $("#codeTableViewForm").submit();
		} else {
			$("#errorMsg").show();
		}
		return false; // to prevent event bubbling }
	});
}

function checkBoxEvents() {
	var addSystems = new Array();
	$("#allSystems").click(
			function() {
				if ($(this).attr("disabled")) {
					return false;
				} else if ($("#allSystems").attr("checked")) {
					$("#allSystems").add(".systems_checkbox").attr("checked",
							"checked");
					$(".systems_checkbox").click(function() {
						if ($("#allSystems").attr("checked"))
						$("#allSystems").removeAttr("checked");
					});
				} else {
					$("#allSystems").add(".systems_checkbox").removeAttr(
							"checked");
				}
				
			});
	
	$("#allMarkets").click(			 
			function() {
				if ($(this).attr("disabled")) {
					return false;
				} else if ($("#allMarkets").attr("checked")) {					
					$("#allMarkets").add(".market_checkbox").attr("checked",
							"checked");
					$(".market_checkbox").click(function() {
						if ($("#allMarkets").attr("checked"))
						$("#allMarkets").removeAttr("checked");
					});
				} else {
					$("#allMarkets").add(".market_checkbox").removeAttr(
							"checked");
				}
				
			});
	
	$("#allCountries").click(
			function() {
				if ($(this).attr("disabled")) {
					return false;
				} else if ($("#allCountries").attr("checked")) {
					$("#allCountries").add(".countries_checkbox").attr(
							"checked", "checked");
					$(".countries_checkbox").click(function() {
						if ($("#allCountries").attr("checked"))
						$("#allCountries").removeAttr("checked");
					});
				} else {
					$("#allCountries").add(".countries_checkbox").removeAttr(
							"checked");
				}
			});
}

function isValidData() {

	if ($("#codeExplText").val() == "") {
		$('#errorMsg').html("Enter the Business Description ");
	} else if ($("#datePickerFrom").val() == "") {
		$('#errorMsg').html("Enter the Effective Date ");
	} else if ($("#codeExplText").val().length > 853) {
		$("#errorMsg").html("Business Description is too long");
	} else if ($("#reasonText").val().length > 853) {
		$("#errorMsg").html("Reason text is too long");
	} else {
		$("#errorMsg").hide();
		return true;
	}
	$("#errorMsg").css("display", "inline");
	return false;
}

