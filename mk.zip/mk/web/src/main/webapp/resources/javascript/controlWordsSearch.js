/*This file serves controlWords.jsp*/
var unusableAreaCodeSearchResultsDataTable;
var unusableAddressSearchResultsDataTable;
var unusableOrgNameSearchResultsDataTable;
var unusableOffWordSearchResultsDataTable;
var unusableTelNumberSearchResultsDataTable;
var unusableIndNameSearchResultsDataTable;
var noiseWordSearchResultsDataTable;
$(document).ready(function(){
	initializeControlWordsElements();
	configureUnusableOffWordsAjaxSearchDataTable();
	configureUnusableOrgNameAjaxSearchDataTable();
	configureUnusableAreaCodeAjaxSearchDataTable();
	configureUnusableAddressAjaxSearchDataTable();
	configureUnusableTelNumberAjaxSearchDataTable();
	configureUnusableIndNameAjaxSearchDataTable();
	configureNoiseWordAjaxSearchDataTable();
	bindControlWords();	
});

function bindControlWords(){
//	$('#ctrlWrdsLink').on('click',function(event){
//		location.href = "showControlWordsSearch.form";
//		return false;
//	});
	$('#ctrlWrdsLinkBreadCrumb').on('click',function(event){
		location.href = "showControlWordsSearch.form";
		return false;
	});
	
	$('#controlWordsTypeCode').change(function(){
		$(".dataTables").hide();
		if($(this).val()==24799){
			$("#searchTextLabel").html("Industry Code Inferment Noise Word");
		} else {
			$("#searchTextLabel").html("Search Text");
		}
	});
	
	$('#controlWordCancelButton').on('click', function(){
		if($.trim($('#sourceQueue').val()) == 'submitter'){
			location.href = "submitterWorkQueueHome.form?domainName=Control Words";
			return false;
		}else if($.trim($('#sourceQueue').val()) == 'approver'){
			location.href = "approverWorkQueueHome.form?domainName=Control Words";
			return false;
		}else{
			location.href = "showControlWordsSearch.form";
			return false;
		}
	});
	
	$('#controlWordsSearchButton').on('click', function(){		
		if($.trim($('#controlWordsTypeCode').val()) == ''){
			$('#errorMsg').html('Please Select Control Words Type Code');
			$('#errorMsg').show();
		}else if(($('#unusableAreaCodesAjaxSearchResultsTable').length == 0) && ($('#unusableAddressAjaxSearchResultsTable').length == 0)
				&& ($('#unusableOrgNameAjaxSearchResultsTable').length == 0) && ($('#unusableOffWordsSearchResultsTable').length == 0)
				&& ($('#unusableTelNumberSearchResultsTable').length == 0) && ($('#unusableIndNameSearchResultsTable').length == 0)
				&& ($('#noiseWordSearchResultsTable').length == 0)){
			$('#errorMsg').html('No Data Available. Please try with different search criteria.');
			$('#errorMsg').show();
		}else{
			if($("#controlWordsIsActive").attr("checked")){
				$("#controlWordsIsActive").val('true');
			} else {
				$("#controlWordsIsActive").val('false');
			}
			if($("#controlWordsIsInactive").attr("checked")){
				$("#controlWordsIsInactive").val('true');
			} else {
				$("#controlWordsIsInactive").val('false');
			}
			$('#errorMsg').hide();
			if($.trim($('#controlWordsTypeCode').val()) == 24801) {
				unusableAreaCodeSearchResultsDataTable.fnFilter(getCtrlWordsAjaxSearchCriteria());	
			} else if($.trim($('#controlWordsTypeCode').val()) == 24802) {
				unusableAddressSearchResultsDataTable.fnFilter(getCtrlWordsAjaxSearchCriteria());	
			} else if($.trim($('#controlWordsTypeCode').val()) == 24803) {
				unusableOrgNameSearchResultsDataTable.fnFilter(getCtrlWordsAjaxSearchCriteria());
			} else if($.trim($('#controlWordsTypeCode').val()) == 24804) {
				unusableOffWordSearchResultsDataTable.fnFilter(getCtrlWordsAjaxSearchCriteria());
			} else if($.trim($('#controlWordsTypeCode').val()) == 24806) {
				unusableTelNumberSearchResultsDataTable.fnFilter(getCtrlWordsAjaxSearchCriteria());
			} else if($.trim($('#controlWordsTypeCode').val()) == 24808) {
				unusableIndNameSearchResultsDataTable.fnFilter(getCtrlWordsAjaxSearchCriteria());
			} else if($.trim($('#controlWordsTypeCode').val()) == 24799) {
				noiseWordSearchResultsDataTable.fnFilter(getCtrlWordsAjaxSearchCriteria());
			}
		}
		return false;
	});
	$('#controlWordEditButton').on('click', function(){
		$(this).hide();
		$('#controlWordUpdateButton').show();
		$('.editable').prop('disabled', false);
		$('.geoDatepickerTextBox').datepicker('enable');
		populateCountryApplicability();
	});
	$('#controlWordUpdateButton').on('click', function(){
		$('#controlWordForm').submit();
	});
	$('#controlWordApproveButton').on('click', function(){
		completeTaskAjax(true);
	});
	
	$('#controlWordRejectButton').on('click', function(){
		$("#reasonDiv").show();
		$("#reason").focus();
		return false;
	});
}

function initializeControlWordsElements(){
	$('#controlWordUpdateButton').hide();
	$('.disableOnLoad').prop('disabled', true);	
	if($.trim($('#sourceQueue').val()) == 'approver'){
		$('#controlWordApproveButton').show();
		$('#controlWordRejectButton').show();
		$('#controlWordEditButton').hide();
	}else {
		$('#controlWordApproveButton').hide();
		$('#controlWordRejectButton').hide();
	}
	if($.trim($('#sourceQueue').val()) == 'submitter'){
		$('#controlWordEditButton').hide();
	}
	/*if($('#controlWordsSearchResultsTable').length){
		$('#controlWordsSearchResultsTable').dataTable({
	        "sPaginationType": "full_numbers",
			"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page"},
	        "sDom": 'tlp'
		});
	}*/
}

function populateCountryApplicability(){
	var existingCountryApplicabilities = getExistingCountryApplicabilities();	
	var checkBoxHandle;
	$.getJSON('retrieveCountryList.form', 
			function(data) {
			$('#countryApplicabilityTable tr').remove();
			$.each(data, function() {
				$('#countryApplicabilityTable').append(
						'<tr><td width="5%"><input type=checkbox class="countryApplicability" value="' +
						this.code +
						'" name="countryApplicabilityCheckboxValues"/></td><td width="95%">'+
						this.value +
						'</td></tr>'
				);
			}); 
			$.each(existingCountryApplicabilities, function(index, countryGeoUnitId) { 				
				checkBoxHandle = $('#countryApplicabilityTable').find(":checkbox[value=" + countryGeoUnitId + "]");
				checkBoxHandle.prop("checked", true);
			});
			
	});
}

function getExistingCountryApplicabilities(){
	var existingCountryApplicabilities = new Array();
	$('.countryApplicability').each(function(){
		existingCountryApplicabilities.push($(this).val());
	});
	return existingCountryApplicabilities;
}
function getCtrlWordsAjaxSearchCriteria(){
	var searchCriteriaDelimiter = "#~";
	var searchCriteria = $('#controlWordsTypeCode').val() + searchCriteriaDelimiter + 
						 $('#searchTextBox').val() + searchCriteriaDelimiter + 
						 $('#controlWordCountry').val() + searchCriteriaDelimiter + 
						 $('#controlWordsIsActive').val() + searchCriteriaDelimiter + 
						 $('#controlWordsIsInactive').val();
	return searchCriteria;
}
function configureUnusableOffWordsAjaxSearchDataTable(){
	unusableOffWordSearchResultsDataTable = $("#unusableOffWordsSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "controlWordsSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aoColumns": [null,null,null,null,null,{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnCtrlWrdColumns(nRow, aData);	
        	$('#offWordsTable').show();
		   	return nRow;
        }
	});
}
function configureUnusableOrgNameAjaxSearchDataTable(){
	unusableOrgNameSearchResultsDataTable = $("#unusableOrgNameAjaxSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "controlWordsSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aoColumns": [null,null,null,null,null,{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false },{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnCtrlWrdColumns(nRow, aData);
        	$('#orgNameTable').show();
		   	return nRow;
        }
	});
}
function configureUnusableAreaCodeAjaxSearchDataTable(){
	unusableAreaCodeSearchResultsDataTable = $("#unusableAreaCodesAjaxSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "controlWordsSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aoColumns": [null,null,null,null,null,null,null,
                      { "bVisible": false },{ "bVisible": false },{ "bVisible": false },
                      { "bVisible": false },{ "bVisible": false },{ "bVisible": false },
                      { "bVisible": false },{ "bVisible": false },{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnCtrlWrdColumns(nRow, aData);
        	$('#areCodeTable').show();
		   	return nRow;
        }
	});
}
function configureUnusableAddressAjaxSearchDataTable() {
	unusableAddressSearchResultsDataTable = $("#unusableAddressAjaxSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "controlWordsSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aoColumns": [null,null,null,null,null,null,null,null,null,null,
                      { "bVisible": false },{ "bVisible": false },{ "bVisible": false },
                      { "bVisible": false },{ "bVisible": false },{ "bVisible": false },
                      { "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnCtrlWrdColumns(nRow, aData);
        	$('#addressTable').show();
		   	return nRow;
        }
	});
}
function configureUnusableTelNumberAjaxSearchDataTable() {
	unusableTelNumberSearchResultsDataTable = $("#unusableTelNumberSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "controlWordsSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aoColumns": [null,null,null,null,null,null,
                      { "bVisible": false },{ "bVisible": false },{ "bVisible": false },
                      { "bVisible": false },{ "bVisible": false },
                      { "bVisible": false },{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnCtrlWrdColumns(nRow, aData);
        	$('#telNumberTable').show();
		   	return nRow;
        }
	});
}
function configureUnusableIndNameAjaxSearchDataTable() {
	unusableIndNameSearchResultsDataTable = $("#unusableIndNameSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "controlWordsSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aoColumns": [null,null,null,null,null,null,null,null,
                      { "bVisible": false },{ "bVisible": false },
                      { "bVisible": false },{ "bVisible": false },
                      { "bVisible": false },{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnCtrlWrdColumns(nRow, aData);
        	$('#indNameTable').show();
		   	return nRow;
        }
	});
}
function configureNoiseWordAjaxSearchDataTable() {
	noiseWordSearchResultsDataTable = $("#noiseWordSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "controlWordsSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
		"oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aoColumns": [null,null,null,null,
                      { "bVisible": false },{ "bVisible": false },
                      { "bVisible": false },{ "bVisible": false },
                      { "bVisible": false },{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnCtrlWrdColumns(nRow, aData);
        	$('#noiseWordTable').show();
		   	return nRow;
        }
	});
}
function setHyperLinkOnCtrlWrdColumns(nRow, aData) {
	var length= aData.length;
	if(aData[length-1]==24801){
		$('td:eq(2)', nRow).html(setHtmlForCtrlWords(aData[length-2], aData[2]));
		$('td:eq(1)', nRow).html(setCheckBoxes(aData[1]));
	}
	if(aData[length-1]==24803|| aData[length-1]==24804 || aData[length-1]==24799){
		$('td:eq(1)', nRow).html(setHtmlForCtrlWords(aData[length-2], aData[1]));
		$('td:eq(2)', nRow).html(setCheckBoxes(aData[2]));
		if(aData[length-1]==24803|| aData[length-1]==24804){
			$('td:eq(3)', nRow).html(setCheckBoxes(aData[3]));
		}
	}
	if(aData[length-1]==24802 || aData[length-1]==24806  || aData[length-1]==24808 ){
		$('td:eq(1)', nRow).html(setHtmlForCtrlWords(aData[length-2], aData[1]));
		$('td:eq(2)', nRow).html(setHtmlForCtrlWords(aData[length-2], aData[2]));
		$('td:eq(3)', nRow).html(setHtmlForCtrlWords(aData[length-2], aData[3]));
		$('td:eq(4)', nRow).html(setHtmlForCtrlWords(aData[length-2], aData[4]));
		if(aData[length-1]==24802  || aData[length-1]==24808 ){
			$('td:eq(5)', nRow).html(setHtmlForCtrlWords(aData[length-2], aData[5]));
		}
		if(aData[length-1]==24802){
			$('td:eq(6)', nRow).html(setHtmlForCtrlWords(aData[length-2], aData[6]));
			$('td:eq(7)', nRow).html(setHtmlForCtrlWords(aData[length-2], aData[7]));
			$('td:eq(8)', nRow).html(setHtmlForCtrlWords(aData[length-2], aData[8]));
		}
		if(aData[length-1]==24808){
			$('td:eq(6)', nRow).html(setCheckBoxes(aData[6]));
		}
	}
}
function setHtmlForCtrlWords(code, value) {
	if(value!=null){
		return "<a href='retrieveControlWordByIdAndTypeCode.form?dnbUnusGlsyId=" + code + 
		"&dnbUnusGlsyTypCdText=" + 
		$('#controlWordsTypeCode :selected').text().replace('&','ampersandSymbol') +
		"&taskId=' class='list'>" + value
		+ "</a>";
	}
	return false;
}
function setCheckBoxes(indicator) {
	if(indicator){
		return "<input type='checkbox' disabled='disabled' checked='checked' />";
	} else {
		return "<input type='checkbox' disabled='disabled' />";
	}
}
