/**
 * This file serves geoNameCodeSearch.jsp
 */
var geoSearchNameDataTable;
var geoSearchCodeDataTable;
$(document).ready(function(){
	bindEvents();
	initializeNameCodeSearchElements();
	configureDataTable();
});

function bindEvents(){
//	$('#geoNameCodeSearchLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "geoNameCodeSearch.form";
//		return false; // to prevent event bubbling
//	});
	
	$('#geoSearchFromNameCodeSearch').bind('click',function(event){
		event.preventDefault();
		location.href = "geoSearchHome.form";
		return false; // to prevent event bubbling
	});
	
	$('#geoNameRadio').bind('click',function(event){
		geoNameOnchange();
	});
	
	$('#geoCodeRadio').bind('click',function(event){
		geoCodeOnchange();
	});
	
	$('#geoNameCodeSearchBtn').bind('click',function(event){
		getGeoNameCodeAjaxResults();
	});
}

function initializeNameCodeSearchElements(){
	$('#geoSearchCodeDiv , #geoSearchNameDiv').hide();
}

function configureDataTable(){
	configureNameDataTable();
	configureCodeDataTable();
}

function configureNameDataTable(){
	geoSearchNameDataTable = $("#geoSearchNameTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "geoSearchNameAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aoColumns": [null,null,null,{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnNameColumn(nRow, aData);		
		   	return nRow;
        }
  });	
}

function configureCodeDataTable(){
	geoSearchCodeDataTable = $("#geoSearchCodeTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "geoSearchCodeAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "aoColumns": [null,null,null,{ "bVisible": false },null],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	setHyperLinkOnNameColumn(nRow, aData);		
		   	return nRow;
        }
  });	
}

function setHyperLinkOnNameColumn(nRow, aData){
	$('td:eq(0)', nRow).html(getNameColumnHtml(aData[3], aData[0]));
}

function getNameColumnHtml(code, value){
	return "<a href='geoUnitView.form?geoUnitId=" + code + "&taskId=&source=GeoNameCodeSearch' class='list'>" + value + "</a>";
}

function geoNameOnchange(){
	$('#errorMsg').hide();
	$('#geoCodeText').attr('disabled', 'disabled');
	$('#geoCodeText').val('');
	$('#geoNameText').removeAttr('disabled');
	$('#geoSearchCodeDiv').hide();
	$('#geoSearchNameDiv').show();
}

function geoCodeOnchange(){
	$('#errorMsg').hide();
	$('#geoCodeText').removeAttr('disabled');
	$('#geoCodeText').val('');
	$('#geoNameText').attr('disabled', 'disabled');
	$('#geoSearchCodeDiv').show();
	$('#geoSearchNameDiv').hide();
}

function getGeoNameCodeAjaxResults(){
	var searchCriteria = $("input:radio[name=geotype]:checked").val();
	if( searchCriteria == "geoNameRadio"){
		if($.trim($("#geoNameText").val()) != ""){
				showSpinner();
				$('#geoSearchCodeDiv').hide();
				$('#geoSearchNameDiv').show();
				$('#errorMsg').hide();
				geoSearchNameDataTable.fnFilter($.trim($("#geoNameText").val()));
			}else{
			$("#errorMsg").html("Please Enter Geography Name");
			$('#errorMsg').show();
		}
	}else if( searchCriteria == "geoCodeRadio"){
		if($.trim($("#geoCodeText").val()) != ""){
				showSpinner();
				$('#geoSearchCodeDiv').show();
				$('#geoSearchNameDiv').hide();
				$('#errorMsg').hide();
				geoSearchCodeDataTable.fnFilter($.trim($("#geoCodeText").val()));
			}else{
			$("#errorMsg").html("Please Enter Geography Code");
			$('#errorMsg').show();
		}		
	}else{
		$("#errorMsg").html("Please Enter required fields");
		$('#errorMsg').show();
	}
}
