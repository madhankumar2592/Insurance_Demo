/*This file serves controlWordsBulkUpload.jsp*/
$(document).ready(function(){
	$(document).ready(function(){
		bindctrlWrdsBulkUpload();
		
	});
});

function bindctrlWrdsBulkUpload()
{
//	$('#ctrlWrdsBulkUploadLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "ctrlWrdsBulkUpload.form";
//		return false;
//	});
}

function checkcwdomain()
{
	if($('#cwdomain').val() == "")
	{
			$('#cwdomain').focus();
			alert('Select Control Word File Type before Bulk Upload');
	}
	else
	{
		$('#bulkuploadrow').css("visibility","visible");
	}
}

function validateCtrlWrdsUpload()
{
	if($('#cwdomain').val() == "")
	{
			$('#cwdomain').focus();
			alert('Select Control Word File Type before Bulk Upload');
	}
	else if($('#cwupload').val() == "" ||$('#cwupload').val() == null)
	{
		alert('Select a file to upload');
		$('#cwupload').focus();
	}
	else
	{
		var fup = $('#cwupload').val();	
		var ext = fup.substring(fup.lastIndexOf('.') + 1);
		if(ext == "xlsx")
		{		
			alert("The New records have been added to the stage system and should be routed for approval");	
			$('#CtrlWrdsBulkUpload').submit();
			return true;
		} 
		else
		{				
			alert("Please upload only xlsx files");	
			$('#cwupload').val('');
			$('#bulktext').val('');				
			return false;
		}			
	}
}

