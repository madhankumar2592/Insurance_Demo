/**
 * 
 */
var toggleIndc = 'VALUE';
var langtoggleIndc = 'VALUE';
var indsCodeInfermentSearchResultsTable;
$(document).ready(function() {
	bindIndustryCodeInfermentSearchEvents();
	initializeIndustryCodesInfermentSearchElements();
	configureIndsCodeInfermentSearchDataTable();
});


function bindIndustryCodeInfermentSearchEvents(){
	
//	$('#industryCodeInfermentLink').bind('click',function(event) {
//		event.preventDefault();
//		location.href = "indsCodeInfermentSearchHome.form";
//		return false; // to prevent event bubbling
//	});
	
	$('#indsInfermentSearchBtn').bind('click',function(event){
		event.preventDefault();
		indsCodeInfermentSearchResultsTable.fnFilter(getIndustryCodeInfermentSearchCriteria());
		$('#indcodeInfermentTable').show();
	});
	
	$('#indsCodeTypeToggleBtn').bind('click',function(event){
		
		
		toggleIndsCodeTypeTable();
	});	
	
	$('#languageToggleBtn').bind('click',function(event){
	
		togglelanguageCodeTable();
	});
	
	$('#industryCodeType').bind('change',function(){		
				
		if($.trim($(this).val()) != '') {		 		 
			populateIndustryCodeDescription($(this).val(),$('#industryTablecode'),false);		 
		} else {
			$('#industryTablecode').val("");
		}
			
	});
}

function configureIndsCodeInfermentSearchDataTable(){
	
	indsCodeInfermentSearchResultsTable = $("#indcodeInfermentSearchResultsTable").dataTable({
        "bServerSide": true,
        "sAjaxSource": "indsCodeInfermentSearchAjaxResults.form",
        "bProcessing": false,
        "sPaginationType": "full_numbers",
        "oLanguage": {"sEmptyTable": "No data available", "sLengthMenu" :" _MENU_ items per page",
        	"sInfo": "Showing _START_ to _END_ of _TOTAL_ records",
            "sInfoEmpty": "No entries to show"},
        "sDom": 'tlip',
        "iDeferLoading": 0, 
        "aoColumns": [null,null,null,null,null,null,{ "bVisible": false }],
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
        	    	setHyperLinkOnIndustryCodeInfermentColumns(nRow, aData);		
		   	return nRow;
        }
  });
}


function setHyperLinkOnIndustryCodeInfermentColumns(nRow, aData){
	$('td:eq(5)', nRow).html(getIndustryCodeInfrColumnHtml(aData[6],aData[5]));
	
}

function getIndustryCodeInfrColumnHtml(code,value){
	return "<a href='indsCodeInfermentSearchView.form?infermentText=" + code+"&taskId=' class='list'>" + value + "</a>";
}


var globalIndx = 0;
function toggleIndsCodeTypeTable() {
	if(globalIndx == 0) {
		globalIndx = globalIndx + 1;
	}
	$.getJSON('toggleIndsCodeTypeTable.form', {
		toggleIndicator : toggleIndc,
		ajax : 'true'
	}, function(data) {
		$("#industryCodeType").empty();
		$("#industryCodeType").append('<option value="">--  Select Industry Code Table  --</option>'); 
		if(toggleIndc == 'CODE') {
			$.each(data, function() {			 
				 $("#industryCodeType").append('<option value="' + this.industryCodeTypeCode + '">' + this.industryCodeTypeCode + ' [ ' + this.codeValueShortDescription + ' ] ' + '</option>');
			});
			toggleIndc = 'VALUE';
		} else {
			$.each(data, function() {			 
				 $("#industryCodeType").append('<option value="' + this.industryCodeTypeCode + '">' + this.codeValueShortDescription + ' [ ' + this.industryCodeTypeCode + ' ] ' + '</option>');
			});
			toggleIndc = 'CODE';
		}
	});
}


function togglelanguageCodeTable() {
	if(globalIndx == 0) {
		globalIndx = globalIndx + 1;
	}
	$.getJSON('togglelanguageCodeTable.form', {
		toggleIndicator : langtoggleIndc,
		ajax : 'true'
	}, function(data) {
		$("#languageCode").empty();
		$("#languageCode").append('<option value="">--  Select Language --</option>'); 
		
		if(langtoggleIndc == 'CODE') {
			$.each(data, function() {				 
				 $("#languageCode").append('<option value="' + this.languageCode + '">' + this.languageCode + ' [ ' + this.codeValueShortDescription + ' ] ' + '</option>');
			});
			langtoggleIndc = 'VALUE';
		} else {
			$.each(data, function() {				
				 $("#languageCode").append('<option value="' + this.languageCode + '">' + this.codeValueShortDescription + ' [ ' + this.languageCode + ' ] ' + '</option>');
			});
			langtoggleIndc = 'CODE';
		}
	});
}


function initializeIndustryCodesInfermentSearchElements(){
	
}

function getIndustryCodeInfermentSearchCriteria(){
	var searchCriteriaDelimiter = "#~";	
	var searchCriteria = $('#infertext').val() + searchCriteriaDelimiter+
							$('#country :selected').val() + searchCriteriaDelimiter + 
							getIndustryCodeInfrDescription($('#industryCodeType :selected').text()) + searchCriteriaDelimiter +
							$('#industryTablecode :selected').val() + searchCriteriaDelimiter +
							getLanguageCodeInfrDescription($('#languageCode :selected').text()) + searchCriteriaDelimiter;
	
	return searchCriteria;
}

function getIndustryCodeInfrDescription(industryCodeSelected){
	if(toggleIndc == 'VALUE') {
				
			
				return industryCodeSelected.substring(0,industryCodeSelected.indexOf('['));
				
	} else {
		
		return industryCodeSelected.substring(industryCodeSelected.indexOf('[') + 1).replace("]","");
	}
}

function getLanguageCodeInfrDescription(languageCodeSelected){
	if(langtoggleIndc == 'VALUE') {
				return languageCodeSelected.substring(0,languageCodeSelected.indexOf('['));
				
	} else {
				return languageCodeSelected.substring(languageCodeSelected.indexOf('[') + 1).replace("]","");
	}
}

function populateIndustryCodeDescription(indsCodeType,indsCodeDescObj,flag){
		
	$.getJSON('retrieveIndustryCodeDescriptionForIndsCodeType.form', {
		industryCodeType :indsCodeType
	},function(data){
		indsCodeDescObj.empty();
		indsCodeDescObj.append('<option value="">-- Select Industry Code/Desc --</option>');
		$.each(data, function() {
			indsCodeDescObj.append('<option value="' + this.industryCode + '">' + this.industryCode + " [ " + this.industryCodeDescription + " ] " + '</option>');
			
		});		
	});
}
