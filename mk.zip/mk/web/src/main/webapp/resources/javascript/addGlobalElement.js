$(document).ready(function(){
//alert("inside");
//alert($('#elementName').val());
	if($("#addGlblEleSuccess").val()){
		alert("New Global Element is added in Reference Data successfully");
	}
	bindAddGlobalElementEvents();
	initializeAddCdValDatepicker();	
	
	/*$( "#glblEleName" ).autocomplete({ 
		source: '${pageContext. request. contextPath}/retrieveElementName.form' 
			});*/ 
	/*var elementArray = new Array();
	$('#elementName').each(function(){
		elementArray.push(${elementName.globalElementName});
});
alert(elementArray);

$('#glblEleName').autocomplete({
            source: elementArray,
            minLength: 3,                
        }); */
	/*var elementArray = new Array();
	 $.getJSON('retrieveElementName.form', function(data) {
	   $.each(data, function(){
	    elementArray.push(data.globalElementName);
	   });
	   alert(elementArray.length);
	  });
	 
	 alert(elementArray);*/
	 
});


function bindAddGlobalElementEvents(){
	
	if($('#globalElementId').val() != ""){
		$('#errorMsg').html("Generated Global Element Id : "+$('#globalElementId').val());
		$('#errorMsg').show();
	}
	
	/*$("#glblEleName").autocomplete({
		source: function(request,response) {
				$.getJSON("retrieveElementName.form",{term: request.term},function(data){
				response(data.Result);
		      })
		},
	    minLength: 4,
	});*/
	
	$('#addGlblEleResetButton').bind('click',function(event){
		if(confirm("Are you sure you want to reset the data?")) {
			event.preventDefault();
			location.href = "glblEleAdd.form";
			return false; // to prevent event bubbling
		}
	});
	
	$('#addGlblEleSubmitButton').bind('click',function(){
		
		$('#glblEleLangCode').val('39');
		
		var flag = validateComment();		
		var effectiveDate = $('#cdValEffectiveDate').val();
		
		var date1 = isValidDate($('#cdValEffectiveDate').val());
		var date2 = isValidDate($('#expirationDate').val());
		if($('#glblEleName').val() != ""){			
			var eleNameExists = isEleNameDuplicate($('#glblEleName').val());			
		}
		
		if($('#glblEleTypeCode').val() == ""){
			$('#errorMsg').html("Please select Global Element Type");
			$('#errorMsg').show();
		}else if($('#glblEleTopicCode').val() == ""){
			$('#errorMsg').html("Please select Topic Category");
			$('#errorMsg').show();
		}else if($.trim($('#glblEleName').val()) == ""){
			$('#errorMsg').html("Please enter Element Name");
			$('#errorMsg').show();
		}else if(eleNameExists){
			$('#errorMsg').html("Element Name already exists. Please enter valid Element Name");
			$('#errorMsg').show();
		}else if($('#cdValEffectiveDate').val() == ""){
			$('#errorMsg').html("Please enter Effective date");
			$('#errorMsg').show();
		}else if(($('#expirationDate').val() != "") && (($('#expirationDate').val() < effectiveDate) || (!date2))){
			$('#errorMsg').html("Expiration date should be greater than or equal to effective date and in yyyy-mm-dd format");
			$('#errorMsg').show();
		}else if(!date1){
			$('#errorMsg').html("Please enter valid Effective date");
			$('#errorMsg').show();
		}else if ($('#glblEleLangCode').val() == '') {				
			$('#errorMsg').html("Please select a Language");
			$('#errorMsg').show();
		}else if($.trim($('#shortDesc').val()) == ""){
			$('#errorMsg').html("Please provide Short Description value");
			$('#errorMsg').show();
		}else if($('#shortDesc').val().length > 4000){		
			$('#errorMsg').html("The short description entered should be of 4000 characters or less");
			$('#errorMsg').show();
		}else if($('#longDesc').val().length > 4000){		
			$('#errorMsg').html("The long description entered should be of 4000 characters or less");
			$('#errorMsg').show();				
		}else if(flag){
				$('#errorMsg').html("Global Element Comment is Mandatory if Expiration date is set");
				$('#errorMsg').show();
		}else {
				$('#errorMsg').hide();				
				if(confirm("Are you sure you want to add Global Element ")) {
					$('#addGlobalElementForm').submit();
				}
		}
		
	});
	
}

function validateComment(){
		if($('#expirationDate').val() != ""){
			if($.trim($('#glblEleComment').val()) == ""){
				return true;
			}
			return false;			
		}
}

function initializeAddCdValDatepicker(){
	$('.addCdValDatepickerTextBox').removeClass('hasDatepicker').datepicker(
			getDatepickerOptions(true));
	$('.addCdValDatepickerTextBox').datepicker('enable');
}

function isValidDate(dateString) {
	var regEx = /^\d{4}-\d{2}-\d{2}$/;
	var dtArray = dateString.match(regEx); 
	if (dtArray == null) {
        return false;
	}
	var splitdate = dateString.split('-');
	dtYear = splitdate[0];
	dtMonth = splitdate[1];
	dtDay = splitdate[2];
	
	if (dtMonth < 1 || dtMonth > 12) {
        return false;
    }else if (dtDay < 1 || dtDay> 31) {
        return false;
    }else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) {
        return false;
	}else if (dtMonth == 2) 
    {
		alert(isleap);
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
		alert(isleap);
        if (dtDay> 29 || (dtDay ==29 && !isleap)) {
            return false;
		}
    }
    return true;
}

function isEleNameDuplicate(elementName){	
	var flag = false;
	var param = {globalElementName: elementName}	
	 $.ajax({
		 cache: false,
		 async: false,
		 url : "isDuplicateElementName.form",		 
         data : param,
         success : function(data) {       	  	
			if(data){			
				flag = true;
			}
		}			
	 });	
	 return flag;
}
