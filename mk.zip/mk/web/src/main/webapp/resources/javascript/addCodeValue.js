/**
 * This file serves the addCodeValue.jsp
 */
$(document).ready(function(){
	bindAddCodeValueEvents();
	initializeAddCdValDatepicker();
	initializeCdValTextLanguageCode();
//	preSelectSystemsAndCountries();
});

function bindAddCodeValueEvents(){
//	$('#addScotsCodeValueLink').bind('click',function(event){
//		event.preventDefault();
//		location.href = "showAddCodeValueHome.form";
//		return false; // to prevent event bubbling
//	});	
	$('#addCdValResetButton').bind('click',function(event){
		if(confirm("Are you sure you want to reset the data?")) {
			event.preventDefault();
			location.href = "showAddCodeValueHome.form";
			return false; // to prevent event bubbling
		}
	});
	$('#addCdValCancelButton').bind('click',function(event){
		event.preventDefault();
		location.href = "home.form";
		return false; // to prevent event bubbling
	});
	$('#addCdValSubmitButton').bind('click',function(){
		if(isValidAddCodeValueEntries()){
			if(isValidEffectiveDate()) {
				$('#errorMsgAddCodeVal').html("Effective Date for Code Value can not be earlier than the effective date for Code Table");
				$('#errorMsgAddCodeVal').show();
				return false;
			} else {
				populateAddCodeValueModel();
				$('#intermediateSaveIndc').val('false');
				$('#addCodeValueForm').submit();
				$('#successIndicator').val('submit_scots_success');
			}
		} else {
			$('#errorMsgAddCodeVal').html('The fields marked (*) are mandatory.');
			$('#errorMsgAddCodeVal').show();
		}
		return false; // to prevent event bubbling
	});
	$('#addCdValSaveButton').bind('click',function(){
		if(isValidAddCodeValueEntries()){
			populateAddCodeValueModel();
			$('#intermediateSaveIndc').val('true');
			$('#addCodeValueForm').submit();
			$('#successIndicator').val('save_scots_success');
		} else {
			$('#errorMsgAddCodeVal').html('The fields marked (*) are mandatory.');
			$('#errorMsgAddCodeVal').show();
		}
		return false; // to prevent event bubbling
	});
	$("#addCdTblTogglebtn").bind('click', function() {
		toggleAddCdValCodeTables();
		return false;
	});
	
//	var successIndc = $('#successIndicator').val();
//	if(successIndc == "submit_scots_success") {
//		$("#successIndicator").val('');
//		successIndc = "";
//	  	location.href ="submitterWorkQueueHome.form?domainName=SCoTS";
//	} else if(successIndc == "save_scots_success") {		
//		$("#successIndicator").val('');
//		successIndc = "";
//		alert('Record has been saved intermediately. Please click on Submit button to submit the record.');
//	}
	
	$("#codescotstable").bind('change', function() {
		var cdTblId = $(this).val();
		if(cdTblId != "") {
			$.getJSON('getCodeTableDescriptionAjaxResults.form', {
				codeTableId : cdTblId,
				ajax : 'true'
			}, function(data) {
				$("#cdTableEffDateForCdVal").val(data[3]);
			});
		}
	});
	bindExpirationDateValidation();
}

function initializeCdValTextLanguageCode() {
	var descRow = $('#scotsDescriptionTable').find('.containerRow');
	if(descRow.length == 1) {
		descRow.find('.languageCode').val('39');
		// descRow.find('.languageCode').attr('disabled', true);
	}
}

function bindExpirationDateValidation() {	
	$('#scotsDescriptionTable').find('.containerRow').each(function(){
		$(this).find('.expirationDate').bind('change', function(){
			var expDate = convertDate($(this).val());
			var effDate = convertDate($(this).closest('tr').find('.effectiveDate').val());
			
			if(expDate - effDate < 0) {
				alert('Expired Date can not be earlier than the Effective Date for the Description');
				$(this).val('');
				$(this).focus();
				return false;
			}
		});
	});
}

function populateAddCodeValueModel(){
	var modelIndex = 0;
	$('#scotsDescriptionTable').find('.containerRow').each(function(){
		$(this).find('.languageCode').prop('name','codeValueTexts[' + modelIndex + '].languageCode');
		$(this).find('.effectiveDate').prop('name','codeValueTexts[' + modelIndex + '].effectiveDate');
		$(this).find('.expirationDate').prop('name','codeValueTexts[' + modelIndex + '].expirationDate');
		$(this).find('.codeValueDescription').prop('name','codeValueTexts[' + modelIndex + '].codeValueDescription');
		$(this).find('.codeValueShortDescription').prop('name','codeValueTexts[' + modelIndex + '].codeValueShortDescription');		
		$(this).find('.productLiteralDescription').prop('name','codeValueTexts[' + modelIndex + '].productLiteralDescription');
		$(this).find('.productLiteralShortDescription').prop('name','codeValueTexts[' + modelIndex + '].productLiteralShortDescription');
		$(this).find('.literalMasculineDescription').prop('name','codeValueTexts[' + modelIndex + '].literalMasculineDescription');
		$(this).find('.literalMasculineShortDescription').prop('name','codeValueTexts[' + modelIndex + '].literalMasculineShortDescription');		
		$(this).find('.literalFeminineDescription').prop('name','codeValueTexts[' + modelIndex + '].literalFeminineDescription');
		$(this).find('.literalFeminineShortDescription').prop('name','codeValueTexts[' + modelIndex + '].literalFeminineShortDescription');
		
		$(this).find('.effectiveDate').datepicker('destroy');
		updateNames($(this).find('.effectiveDate'), (modelIndex), 'codeValueTexts', 'effectiveDate');
		$(this).find('.effectiveDate').removeClass('hasDatepicker');
		$(this).find('.effectiveDate').datepicker(getDatepickerOptions(false));
		$(this).find('.expirationDate').datepicker('destroy');
		updateNames($(this).find('.expirationDate'), (modelIndex), 'codeValueTexts', 'expirationDate');
		$(this).find('.expirationDate').removeClass('hasDatepicker');
		$(this).find('.expirationDate').datepicker(getDatepickerOptions(false));
		modelIndex++;
		bindclearExpirationDate();
		bindExpirationDateValidation();
	});
}
		
function removeCodeValueDescription(rowHandle){
	$(rowHandle).closest('.containerRow').remove();
	}

function addCodeValueDescription() {
	$('#scotsDescriptionTable').append($('#scotsDescriptionTable').find('.containerRow').last().clone());
	$('#scotsDescriptionTable').find('.containerRow').last().find('.removeNewCdValLiteral').html(
		'<strong><a href="javascript:;" style="text-decoration: none;" onclick="removeCodeValueDescription(this);">[-]</a></strong>'
	);
	$('#scotsDescriptionTable').find('.containerRow:last').find('.languageCode').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.languageCode').attr("disabled", false);
	$('#scotsDescriptionTable').find('.containerRow:last').find('.effectiveDate').val(getToday());
	$('#scotsDescriptionTable').find('.containerRow:last').find('.ui-datepicker-trigger').remove();
	initializeNewRowDatePick($('#scotsDescriptionTable').find('.containerRow:last'), '.effectiveDate');
	$('#scotsDescriptionTable').find('.containerRow:last').find('.expirationDate').val("");
	initializeNewRowDatePick($('#scotsDescriptionTable').find('.containerRow:last'), '.expirationDate');
	$('#scotsDescriptionTable').find('.containerRow:last').find('.codeValueDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.codeValueShortDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.productLiteralDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.literalMasculineDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.literalMasculineShortDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.literalFeminineDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.literalFeminineShortDescription').val("");
	$('#scotsDescriptionTable').find('.containerRow:last').find('.editableInNew').attr("disabled",false);
	$('#scotsDescriptionTable').find('.containerRow:last').find('.cdValViewNonEditable').datepicker('enable');
	populateAddCodeValueModel();
}

function initializeAddCdValDatepicker(){
	$('.addCdValDatepickerTextBox').removeClass('hasDatepicker').datepicker(
			getDatepickerOptions(true));
	$('.addCdValDatepickerTextBox').datepicker('enable');
}

function isValidAddCodeValueEntries() {
	// valid codeValue entity elements
	if($("#codescotstable").val() == '') {
		return false;
	} else if($("#codeExplText").val() == '') {
		return false;
	}else if($('input[name="systemList"]:checked').length == 0){
		return false;
	}
		
	// validate the codeValueText entity elements
	if(!isAddCdValueDescriptionEmpty('.languageCode')) {
		alert("Please select Language");
		return false;
	} else if(!isAddCdValueDescriptionEmpty('.codeValueDescription')) {
		alert("Please enter Code Description");
		return false;
	} else if(!isAddCdValueDescriptionEmpty('.codeValueShortDescription')) {
		alert("Please enter Code Short Description");
		return false;
	} else if(!isAddCdValueDescriptionEmpty('.productLiteralDescription')) {
		alert("Please enter Product Literal Description");
		return false;
	} else if(isEnglishLiteralsAvailable()) {
		alert("Descriptions and Literals in English [39] language is mandatory for a Code Value");
		return false;
	} else if(isCdValLanguageDuplicate()) {
		return false;
	} 
//	else if(!isSystemApplicabilityEntered()) {
//		return false;
//	} 
	return true;
}

function isSystemApplicabilityEntered() {
	var isChecked = false;
	$('.addSystems').each(function(){
		if($(this).attr('checked')) {
			isChecked = true;
		}
	});
	return isChecked;
}

function isValidEffectiveDate() {
	var cdTblDate = convertDate($('#cdTableEffDateForCdVal').val());
	var cdValDate = convertDate($('#cdValEffectiveDate').val());

	if(cdTblDate - cdValDate > 0) {
		return true;
	}
	return false;
}

function isEnglishLiteralsAvailable() {
	var descRow = $('#scotsDescriptionTable').find('.containerRow');
	var hasEn = false;
	descRow.each(function() {
		var lng = $(this).find('.languageCode').val();
		var exp = $(this).find('.expirationDate').val();
		if(lng == '39' && exp == '') {
			hasEn = true;
		}
	});
	
	if(!hasEn) 
		return true;
	else
		return false;
}

function isAddCdValueDescriptionEmpty(ele) {
	var hasValue = true;
	$('#scotsDescriptionTable').find(ele).each(function() {
		if($(this).val() == '') {
			$(this).focus();
			hasValue = false;
			return false;
		} 
	});
	return hasValue;
}


var addCdTblToggleInd = true;
function toggleAddCdValCodeTables() {
	$.getJSON('toggleCodeTableList.form', {
		toggleIndicator : addCdTblToggleInd,
		ajax : 'true'
	}, function(data) {
		$("#codescotstable").empty();
		$("#codescotstable").append('<option value="">-- Select Code Table --</option>');
		if (addCdTblToggleInd) {
			$.each(data, function() {
				$("#codescotstable").append(
						'<option value="' + this.code + '">' + this.value
								+ ' [ ' + this.code + ' ] ' + '</option>');
			});
		} else {
			$.each(data, function() {
				$("#codescotstable").append(
						'<option value="' + this.code + '">' + this.code
								+ ' [ ' + this.value + ' ] ' + '</option>');
			});
		}
		addCdTblToggleInd = !addCdTblToggleInd;
	});
}


function toggleAddCdValLanguages(rowHandler) {
	var addCdValLangToggleInd = $(rowHandler).closest('tr').find('.toggleIndicator').val();
	$.getJSON('toggleLanguageCodeValueList.form', {
		toggleIndicator : addCdValLangToggleInd,
		ajax : 'true'
	}, function(data) {
		$(rowHandler).closest('tr').find(".languageCode").empty();
		$(rowHandler).closest('tr').find(".languageCode").append(
				'<option value="">-- Select Language --</option>');
		if (addCdValLangToggleInd == "true") {
			$.each(data, function() {
				$(rowHandler).closest('tr').find(".languageCode").append(
						'<option value="' + this.codeValueId + '">' + this.codeValueDescription
								+ ' [ ' + this.codeValueId + ' ] ' + '</option>');
				$(rowHandler).closest('tr').find('.toggleIndicator').val('false');
			});
		} else {
			$.each(data, function() {
				$(rowHandler).closest('tr').find(".languageCode").append(
						'<option value="' + this.codeValueId + '">' + this.codeValueId
								+ ' [ ' + this.codeValueDescription + ' ] ' + '</option>');
				$(rowHandler).closest('tr').find('.toggleIndicator').val('true');
			});
		}
		$(rowHandler).closest('td').css('display', 'none');
		var newOpts = $(rowHandler).closest('tr').find(".languageCode").html();
		$(rowHandler).closest('tr').find(".languageCode").html('');
		$(rowHandler).closest('tr').find(".languageCode").html(newOpts);
		$(rowHandler).closest('td').css('display', 'block');		
	});
}

function isCdValLanguageDuplicate(){
	var selectedLanguages = [];
	var langDesc = [];
	var descRow = $('#scotsDescriptionTable').find('.containerRow');
	descRow.each(function(){
		if($(this).find('.expirationDate').val() == '') {
			selectedLanguages.push($(this).find('.languageCode').val());
			langDesc.push($(this).find('.languageCode option:selected').html());
		}
	});
	
	var currentLanguage = 0;
	for(var i = 0; i < selectedLanguages.length; i++) {
		currentLanguage = selectedLanguages[i];
		for(var j = i+1; j < selectedLanguages.length; j++) {
			if(selectedLanguages[j] == currentLanguage){
				alert('Duplicate Language code "' + langDesc[i].substring(langDesc[i].indexOf('[') + 1, langDesc[i].indexOf(']')) + '" in the Descriptions and Literals');
				return true;
			}
		}
	}
}

function preSelectSystemsAndCountries(){
//	$('.addSystems').each(function(){
//		$(this).attr('checked',true)
//	});
//	$('.addCountries').each(function(){
//		$(this).attr('checked',true)
//	});
}