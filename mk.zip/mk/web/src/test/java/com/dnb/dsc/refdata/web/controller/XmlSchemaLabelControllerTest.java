package com.dnb.dsc.refdata.web.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.vo.XmlSchemaSearchVO;
import com.dnb.dsc.refdata.web.proxy.XmlSchemaLabelProxy;
import com.dnb.dsc.refdata.web.controller.XmlSchemaLabelController;

/**
 * Class to test the XmlSchemaLabelController Class
 *
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class XmlSchemaLabelControllerTest {

	@Mock
	private XmlSchemaLabelProxy xmlProxy;

	@Mock
	private HomeController homeController;

	@InjectMocks
	private XmlSchemaLabelController xmlSchemaLabelController = new XmlSchemaLabelController();

	/**
	 *
	 * Method to test getXmlSchemaLabelHome of XmlSchemaLabelController
	 *
	 */
	@Test
	public void testGetXmlSchemaLabelHome() {
		ModelAndView testModelAndView = xmlSchemaLabelController
				.getXmlSchemaLabelHome();
		Assert.assertEquals("xmlSchemaLabelSearch",
				testModelAndView.getViewName());
	}

	/**
	 *
	 * Method to test getXmlSchemaLabelHome of XmlSchemaLabelController
	 *
	 */
	@Test
	public void testGetXmlSearchAjaxResults() {
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		HttpServletRequest req =Mockito.mock(HttpServletRequest.class);
	    HttpSession session = Mockito.mock(HttpSession.class);
	    String[] string={"new","old"};
	    XmlSchemaSearchVO xmlSchemaSearchVO=Mockito.mock(XmlSchemaSearchVO.class);
		jsonMap.put("count", 10);
		((OngoingStubbing<Map<String,Object>>) Mockito.when(homeController.getJsonMap((HttpServletRequest)Mockito.any(),
				(List<?>)Mockito.any(),
				(Long)Mockito.any(),
				(String[])Mockito.any())))
		.thenReturn(jsonMap);
		Mockito.when(xmlProxy.countSearchXmLSchemaLabels(xmlSchemaSearchVO)).thenReturn(1L);
		Mockito.when(homeController.getStartIndex(req)).thenReturn(1);
		Mockito.when(homeController.getMaxResults(req)).thenReturn(10);
		Mockito.when(homeController.getSearchString(req)).thenReturn("New");
		Mockito.when(homeController.getSortBy(req,string)).thenReturn("1");
		Mockito.when(homeController.getSortOrder(req)).thenReturn("1");

		Map<String, Object> getXmlSearchAjaxResults=xmlSchemaLabelController.getXmlSearchAjaxResults(req,session);
		Assert.assertEquals(1,getXmlSearchAjaxResults.size());
	}



	/**
	 *
	 * Method to test xmlSchemaLabelsSearchView of XmlSchemaLabelController
	 *
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testXmlSchemaLabelsSearchView() {
		Model model = Mockito.mock(Model.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		String elementId="Element";
		Map<String, List<CodeValue>> tempCodeValueMap =null;
		List<Integer> codeTableIds = Mockito.mock(List.class);
		XmlSchemaElement xmlSchemaElement=new XmlSchemaElement();
		Mockito.when(xmlProxy.retrieveXmlSchemaByXmlElementId(Mockito.anyString())).thenReturn(xmlSchemaElement);
		Mockito.when(homeController.retrieveCodeValues(codeTableIds)).thenReturn(tempCodeValueMap);

		ModelAndView xmlSchemaLabelsSearchView = xmlSchemaLabelController.xmlSchemaLabelsSearchView(
				elementId, null, model, session);
		Assert.assertEquals("xmlSchemaLabelSearchView",xmlSchemaLabelsSearchView.getViewName());
	}
}
