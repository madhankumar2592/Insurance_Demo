package com.dnb.dsc.refdata.web.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
//import com.dnb.dsc.refdata.core.util.RefDataConfigUtil;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.CurrencySearchCriteriaVO;
//import com.dnb.dsc.refdata.core.vo.CurrencyUploadItemVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.web.proxy.CurrencyExchangeWebServiceProxy;
import com.dnb.dsc.refdata.web.util.UserRoleMapper;

/**
 * Class to test the CurrencyController Class
 *
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class CurrencyControllerTest {

	@Mock
	private UserRoleMapper roleMapper;

	@Mock
	private HomeController homeController;

	@Mock
	private CurrencyExchangeWebServiceProxy wsProxy;

//	@Mock
//	private RefDataConfigUtil refdataConfig;

	@InjectMocks
	private CurrencyController currencyController = new CurrencyController();

	/**
	 * Method to test getCurrencySearchHome of CurrencyController
	 *
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testGetCurrencySearchHome() {
		HttpSession session = Mockito.mock(HttpSession.class);

		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Long longValue = 1L;
		List<Integer> codeTableIds = Mockito.mock(List.class);
		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		List<CodeValue> codeValue = new ArrayList<CodeValue>();
		tempCodeValueMap.put("1", codeValue);
		Mockito.when(homeController.retrieveCodeValues(codeTableIds))
				.thenReturn(tempCodeValueMap);
		Mockito.when(wsProxy.retrieveCurcyExchDataProviders(longValue))
				.thenReturn(codeValueVOList);
		ModelAndView getCurrencySearchHome = currencyController
				.getCurrencySearchHome(session);
		Assert.assertEquals("currencyExchange",
				getCurrencySearchHome.getViewName());
	}

	/**
	 * Method to test getCurrencySearchAjaxResults of CurrencyController
	 *
	 */
	@Test
	public void testGetCurrencySearchAjaxResults() {
		HttpSession session = Mockito.mock(HttpSession.class);
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		String[] string = { "new", "old" };
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		((OngoingStubbing<Map<String, Object>>) Mockito.when(homeController
				.getJsonMap((HttpServletRequest) Mockito.any(),
						(List<?>) Mockito.any(), (Long) Mockito.any(),
						(String[]) Mockito.any()))).thenReturn(jsonMap);

		Mockito.when(
				wsProxy.countSearchCurrencyExchange(Mockito.any(CurrencySearchCriteriaVO.class)))
				.thenReturn(1L);
		Mockito.when(homeController.getStartIndex(request)).thenReturn(1);
		Mockito.when(homeController.getMaxResults(request)).thenReturn(10);
		Mockito.when(homeController.getSearchString(request)).thenReturn(" USD#~AUD#~2004-12-15#~2004-12-15#~Financial Times");
		Mockito.when(homeController.getSortBy(request, string)).thenReturn("1");
		Mockito.when(homeController.getSortOrder(request)).thenReturn("1");

		Map<String, Object> getCurrencySearchAjaxResults = currencyController
				.getCurrencySearchAjaxResults(request, session);
		Assert.assertEquals(0, getCurrencySearchAjaxResults.size());
	}

	/**
	 * Method to test viewCurrencyExchange of CurrencyController
	 *
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testViewCurrencyExchange() {
		HttpSession session = Mockito.mock(HttpSession.class);
		SessionStatus sessionStatus = Mockito.mock(SessionStatus.class);
		Model model = Mockito.mock(Model.class);
		String currencyExchangeId = "999";
		String taskId="2";
		List<Integer> codeTableIds = Mockito.mock(List.class);
		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		List<CodeValue> codeValue = new ArrayList<CodeValue>();
		tempCodeValueMap.put("1", codeValue);

		Mockito.when(homeController.retrieveCodeValues(codeTableIds))
				.thenReturn(tempCodeValueMap);

		ModelAndView viewCurrencyExchange = currencyController
				.viewCurrencyExchange(currencyExchangeId,taskId, model, session,
						sessionStatus);
		Assert.assertEquals("currencyView", viewCurrencyExchange.getViewName());
	}

	/**
	 * Method to test exchangeRateUpdate of CurrencyController
	 *
	 */
	@Test
	public void testExchangeRateUpdate() throws ParseException {
		HttpSession session = Mockito.mock(HttpSession.class);
		SessionStatus sessionStatus = Mockito.mock(SessionStatus.class);
		Model model = Mockito.mock(Model.class);
		CurrencyExchange currencyExchange = Mockito
				.mock(CurrencyExchange.class);
		BindingResult result = Mockito.mock(BindingResult.class);
		UserContextVO userContextVO =new UserContextVO();
		userContextVO.setUserIdentifier("Test");
		Mockito.when(session.getAttribute("REFDATA_USER_CONTEXT")).thenReturn(userContextVO);
		Mockito.when(session.getAttribute("taskId")).thenReturn("");
		Mockito.when(
				roleMapper.getSubmitterUserGroupId("CURRENCY EXCHANGE", 1037l))
				.thenReturn(1L);
		Mockito.when(roleMapper.getApproverUserGroupId(1L)).thenReturn(2L);
		Mockito.doNothing().when(homeController).createReferenceData((String) Mockito.any(),
				(String) Mockito.any(), (Long) Mockito.any(),
				(String) Mockito.any(), (String) Mockito.any(),
				(Long) Mockito.any(), (Long) Mockito.any());

		View exchangeRateUpdate = currencyController.exchangeRateUpdate(
				currencyExchange, result, model, sessionStatus, session);
		Assert.assertNotNull(exchangeRateUpdate);
	}

	/**
	 * Method to test lockExchangeRate of CurrencyController
	 *
	 */
	@Test
	public void testLockExchangeRate() {
		HttpSession session = Mockito.mock(HttpSession.class);
		CurrencyExchange currencyExchange = new CurrencyExchange();
		currencyExchange.setCurrencyExchangeId(1L);
		Mockito.when(wsProxy.lockCurrencyExchange(Mockito.anyLong()))
				.thenReturn("false");

		String lockExchangeRate = currencyController
				.lockExchangeRate(currencyExchange,session);
		Assert.assertEquals("false", lockExchangeRate);
	}

	/**
	 * Method to test currencyBulkUploadForm of CurrencyController
	 *
	 */
	@Test
	public void testCurrencyBulkUploadForm() {
		ModelAndView currencyBulkUploadForm = currencyController
				.currencyBulkUploadForm();
		Assert.assertNull(currencyBulkUploadForm.getView());
	}

	/**
	 * Method to test currencyBulkUpload of CurrencyController
	 *

	@Test
	public void testCurrencyBulkUpload() throws ParseException {
		HttpSession session = Mockito.mock(HttpSession.class);
		SessionStatus sessionStatus = Mockito.mock(SessionStatus.class);
		BindingResult result = Mockito.mock(BindingResult.class);
		CurrencyUploadItemVO currencyUploadItem = new CurrencyUploadItemVO();
		Mockito.when(currencyUploadItem.getFile().getOriginalFilename()).thenReturn("Test");
		Mockito.when(refdataConfig.getValue(Mockito.anyString())).thenReturn(
				"FileName");

		View currencyBulkUpload = currencyController.currencyBulkUpload(
				currencyUploadItem, result, sessionStatus, session);
	}*/
	@SuppressWarnings("unchecked")
	@Test
	public void testviewGeoCurrency() {
		HttpSession session = Mockito.mock(HttpSession.class);
		SessionStatus sessionStatus = Mockito.mock(SessionStatus.class);
		Model model = Mockito.mock(Model.class);
		Long geoCurrencyId = 999L;
		String taskId="2";
		List<Integer> codeTableIds = Mockito.mock(List.class);
		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		List<CodeValue> codeValue = new ArrayList<CodeValue>();
		tempCodeValueMap.put("1", codeValue);

		Mockito.when(homeController.retrieveCodeValues(codeTableIds))
				.thenReturn(tempCodeValueMap);

		ModelAndView viewCurrencyExchange = currencyController
				.viewGeoCurrency(999L,"3", model, session,sessionStatus);
		Assert.assertEquals("geoCurrencyView", viewCurrencyExchange.getViewName());
	}
}
