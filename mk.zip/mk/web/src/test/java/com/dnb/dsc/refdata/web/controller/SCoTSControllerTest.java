package com.dnb.dsc.refdata.web.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.ui.Model;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.SCoTSSearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;
import com.dnb.dsc.refdata.web.proxy.SCoTSWebServiceProxy;
//import com.dnb.dsc.refdata.web.util.UserRoleMapper;

/**
 * Class to test the CurrencyController Class
 * 
 * 
 */
@RunWith(MockitoJUnitRunner.class)
public class SCoTSControllerTest {

//	@Mock
//	private UserRoleMapper roleMapper;

	
	@Mock
	private GeographyWebServiceProxy geoWsProxy;
	
	@Mock
	private HomeController homeController;

	@Mock
	private SCoTSWebServiceProxy wsProxy;

	// @Mock
	// private RefDataConfigUtil refdataConfig;

	@InjectMocks
	private SCoTSController scotsController = new SCoTSController();

	/**
	 * Method to test showCodeTableSearch of SCoTSController
	 * 
	 */
	@Test
	public void testShowCodeTableSearch() {
		HttpSession session = Mockito.mock(HttpSession.class);
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(wsProxy.retrieveSystemApplicability(Mockito.anyLong(),Mockito.anyInt()))
				.thenReturn(codeValueVOList);
		Mockito.when(wsProxy.retrieveCountryApplicability(Mockito.anyLong(),Mockito.anyInt()))
				.thenReturn(codeValueVOList);
		ModelAndView showCodeTableSearch = scotsController
				.showCodeTableSearch(session);
		Assert.assertEquals("codeTableSearch",
				showCodeTableSearch.getViewName());
	}

	/**
	 * Method to test getCodeTableSearchAjaxResults of SCoTSController
	 * 
	 */
	@Test
	public void testGetCodeTableSearchAjaxResults() {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		String[] string = { "new", "old" };
		jsonMap.put("count", 10);
		((OngoingStubbing<Map<String, Object>>) Mockito.when(homeController
				.getJsonMap((HttpServletRequest) Mockito.any(),
						(List<?>) Mockito.any(), (Long) Mockito.any(),
						(String[]) Mockito.any()))).thenReturn(jsonMap);
		Mockito.when(homeController.getStartIndex(request)).thenReturn(1);
		Mockito.when(homeController.getMaxResults(request)).thenReturn(10);
		Mockito.when(homeController.getSearchString(request)).thenReturn(
				"New~1~892~1600~39");
		Mockito.when(homeController.getSortBy(request, string)).thenReturn("1");
		Mockito.when(homeController.getSortOrder(request)).thenReturn("1");

		Map<String, Object> getCodeTableSearchAjaxResults = scotsController
				.getCodeTableSearchAjaxResults(request, session);
		Assert.assertEquals(1, getCodeTableSearchAjaxResults.size());
	}

	/**
	 * Method to test listCodeTables of SCoTSController
	 * 
	 */
	@Test
	public void testListCodeTables() {
		HttpSession session = Mockito.mock(HttpSession.class);
		Model model = Mockito.mock(Model.class);
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(wsProxy.retrieveCodeTableList()).thenReturn(
				codeValueVOList);
		Mockito.when(wsProxy.retrieveCodeLanguages()).thenReturn(
				codeValueVOList);
		ModelAndView listCodeTables = scotsController.listCodeTables(model,
				session);
		Assert.assertEquals("listCodeTable", listCodeTables.getViewName());
	}

	/**
	 * Method to test retrieveSystemApplicability of SCoTSController
	 * 
	 */
	@Test
	public void testRetrieveSystemApplicability() {
		HttpSession session = Mockito.mock(HttpSession.class);
		Model model = Mockito.mock(Model.class);
		Long codeTableId = 1L;
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(wsProxy.retrieveSystemApplicability(Mockito.anyLong(),Mockito.anyInt()))
				.thenReturn(codeValueVOList);
		List<CodeValueVO> retrieveSystemApplicability = scotsController
				.retrieveSystemApplicability(codeTableId, model, session);
		Assert.assertEquals(1, retrieveSystemApplicability.size());
	}

	/**
	 * Method to test retrieveCountryApplicability of SCoTSController
	 * 
	 */
	@Test
	public void testRetrieveCountryApplicability() {
		Long codeTableId = 1L;
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(wsProxy.retrieveCountryApplicability(Mockito.anyLong(),Mockito.anyInt()))
				.thenReturn(codeValueVOList);
		List<CodeValueVO> retrieveCountryApplicability = scotsController
				.retrieveCountryApplicability(codeTableId);
		Assert.assertEquals(1, retrieveCountryApplicability.size());
	}

	/**
	 * Method to test getCodeValueSearchAjaxResults of SCoTSController
	 * 
	 */
	@Test
	public void testGetCodeValueSearchAjaxResults() {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		String[] string = { "new", "old" };
		jsonMap.put("count", 10);
		((OngoingStubbing<Map<String, Object>>) Mockito.when(homeController
				.getJsonMap((HttpServletRequest) Mockito.any(),
						(List<?>) Mockito.any(), (Long) Mockito.any(),
						(String[]) Mockito.any()))).thenReturn(jsonMap);
		Mockito.when(homeController.getStartIndex(request)).thenReturn(1);
		Mockito.when(homeController.getMaxResults(request)).thenReturn(10);
		Mockito.when(homeController.getSearchString(request)).thenReturn(
				"New~1~892~1600~39");
		Mockito.when(homeController.getSortBy(request, string)).thenReturn("1");
		Mockito.when(homeController.getSortOrder(request)).thenReturn("1");

		Map<String, Object> getCodeValueSearchAjaxResults = scotsController
				.getCodeValueSearchAjaxResults(request, session);
		Assert.assertEquals(1, getCodeValueSearchAjaxResults.size());
	}

	/**
	 * Method to test getCodeValueSearchAjaxResults of SCoTSController
	 * 
	 */
	@Test
	public void testGetCodeValueSearchAjaxResultsWithEmptyDescription() {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		String[] string = { "new", "old" };
		jsonMap.put("count", 10);
		((OngoingStubbing<Map<String, Object>>) Mockito.when(homeController
				.getJsonMap((HttpServletRequest) Mockito.any(),
						(List<?>) Mockito.any(), (Long) Mockito.any(),
						(String[]) Mockito.any()))).thenReturn(jsonMap);
		Mockito.when(homeController.getStartIndex(request)).thenReturn(1);
		Mockito.when(homeController.getMaxResults(request)).thenReturn(10);
		Mockito.when(homeController.getSearchString(request)).thenReturn(
				"~1~892~1600~39");
		Mockito.when(homeController.getSortBy(request, string)).thenReturn("1");
		Mockito.when(homeController.getSortOrder(request)).thenReturn("1");

		Map<String, Object> getCodeValueSearchAjaxResults = scotsController
				.getCodeValueSearchAjaxResults(request, session);
		Assert.assertEquals(1, getCodeValueSearchAjaxResults.size());
	}

	/**
	 * Method to test retrieveCodeTableById of SCoTSController
	 * 
	 */
	@Test
	public void testRetrieveCodeTableById() {
		HttpSession session = Mockito.mock(HttpSession.class);
		String codeTableId = "1";
		CodeTable codeTable = new CodeTable();
		codeTable.setCodeTableId(1L);
		codeTable.setCodeTableName("Test");
		codeTable.setBusinessDescription("Test Class");
		Mockito.when(wsProxy.retrieveCodeTableById(Mockito.anyLong()))
				.thenReturn(codeTable);
		String[] retrieveCodeTableById = scotsController
				.retrieveCodeTableById(codeTableId, session);
		Assert.assertEquals("1", retrieveCodeTableById[0]);
	}

	/**
	 * Method to test searchCodeValue of SCoTSController
	 * 
	 */
	@Test
	public void testSearchCodeValue() {
		HttpSession session = Mockito.mock(HttpSession.class);
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(wsProxy.retrieveCodeLanguages()).thenReturn(
				codeValueVOList);
		ModelAndView searchCodeValue = scotsController.searchCodeValue(session);
		Assert.assertEquals("codeValueSearch", searchCodeValue.getViewName());
	}

	/**
	 * Method to test getCodeValueDescSearchAjaxResults of SCoTSController
	 * 
	 */
	@Test
	public void testGetCodeValueDescSearchAjaxResults() {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		String[] string = { "new", "old" };
		jsonMap.put("count", 10);
		((OngoingStubbing<Map<String, Object>>) Mockito.when(homeController
				.getJsonMap((HttpServletRequest) Mockito.any(),
						(List<?>) Mockito.any(), (Long) Mockito.any(),
						(String[]) Mockito.any()))).thenReturn(jsonMap);
		Mockito.when(homeController.getStartIndex(request)).thenReturn(1);
		Mockito.when(homeController.getMaxResults(request)).thenReturn(10);
		Mockito.when(homeController.getSearchString(request)).thenReturn(
				"1#~codeValue#~1#~1600#~39");
		Mockito.when(homeController.getSortBy(request, string)).thenReturn("1");
		Mockito.when(homeController.getSortOrder(request)).thenReturn("1");

		Map<String, Object> getCodeValueSearchAjaxResults = scotsController
				.getCodeValueDescSearchAjaxResults(request, session);
		Assert.assertEquals(1, getCodeValueSearchAjaxResults.size());

		Mockito.when(homeController.getSearchString(request)).thenReturn(
				"1#~codeValueDesc#~1#~1600#~39");
		getCodeValueSearchAjaxResults = scotsController
				.getCodeValueDescSearchAjaxResults(request, session);
		Assert.assertEquals(1, getCodeValueSearchAjaxResults.size());

		Mockito.when(homeController.getSearchString(request)).thenReturn(
				"1#~#~1#~1600#~39");
		getCodeValueSearchAjaxResults = scotsController
				.getCodeValueDescSearchAjaxResults(request, session);
		Assert.assertEquals(1, getCodeValueSearchAjaxResults.size());

		Mockito.when(homeController.getSearchString(request)).thenReturn("");
		getCodeValueSearchAjaxResults = scotsController
				.getCodeValueDescSearchAjaxResults(request, session);
		Assert.assertEquals(1, getCodeValueSearchAjaxResults.size());
	}

	/**
	 * Method to test codeValueView of SCoTSController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testCodeValueView() {
		Model model = Mockito.mock(Model.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		String codeValueId = "1";
		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		List<CodeValue> codeValueList = new ArrayList<CodeValue>();
		CodeValue codeValue = new CodeValue();
		codeValue.setCodeValueId(3L);
		codeValueList.add(codeValue);
		tempCodeValueMap.put(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE),
				codeValueList);
		tempCodeValueMap.put(
				RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE_STRING,
				codeValueList);
		tempCodeValueMap.put(
				RefDataPropertiesConstants.CODE_TABLE_ID_CODING_SCHEME_STRING,
				codeValueList);
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(
				geoWsProxy.retrieveAllCountries(Mockito.anyLong(),
						Mockito.anyLong())).thenReturn(codeValueVOList);
		Mockito.when(homeController.retrieveCodeValues(Mockito.anyList()))
				.thenReturn(tempCodeValueMap);

		ModelAndView codeValueView = scotsController.codeValueView(codeValueId,
				null, null,null,model, session);
		Assert.assertEquals("codeValueView", codeValueView.getViewName());
	}

	/**
	 * Method to test codeTableView of SCoTSController
	 * 
	 */
	@Test
	public void testCodeTableView() {
		Model model = Mockito.mock(Model.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		String codeTableId = "1";
		String taskId = "402000";
		CodeTable codeTable = new CodeTable();
		codeTable.setCodeTableName("Test");
		Mockito.when(wsProxy.reviewCodeTableChanges(Mockito.anyLong()))
				.thenReturn(codeTable);
		Mockito.when(wsProxy.retrieveCodeTableById(Mockito.anyLong()))
				.thenReturn(codeTable);

		ModelAndView codeTaleView = scotsController.codeTableView(codeTableId,
				taskId, null, model, session);
		Assert.assertEquals("codeTableView", codeTaleView.getViewName());
		taskId = "";
		codeTaleView = scotsController.codeTableView(codeTableId, taskId, null,
				model, session);
		Assert.assertEquals("codeTableView", codeTaleView.getViewName());
	}

	/**
	 * Method to test updateCodeTable of SCoTSController
	 * 
	 */
	@Test
	public void testUpdateCodeTable() throws ParseException {
		Model model = Mockito.mock(Model.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		SessionStatus sessionStatus = Mockito.mock(SessionStatus.class);
		CodeTable codeTable = new CodeTable();
		List<String> systemList = new ArrayList<String>();
		List<String> countryList = new ArrayList<String>();
		systemList.add("1500");
		systemList.add("1600");
		countryList.add("892");
		countryList.add("893");
		codeTable.setSystemList(systemList);
		codeTable.setCountryList(countryList);
		List<SystemApplicability> systemApplicabilityList = new ArrayList<SystemApplicability>();
		SystemApplicability systemApplicability = new SystemApplicability();
		systemApplicability.setDnbSystemCode(1L);
		List<CountryApplicability> countryApplicabilityList = new ArrayList<CountryApplicability>();
		CountryApplicability countryApplicability = new CountryApplicability();
		countryApplicability.setCountryGeoUnitId(2L);
		codeTable.setSystemApplicability(systemApplicabilityList);
		codeTable.setCountryApplicability(countryApplicabilityList);
		UserContextVO userContextVO = new UserContextVO();
		userContextVO.setUserIdentifier("DNB");
		Mockito.when(session.getAttribute("REFDATA_USER_CONTEXT")).thenReturn(
				userContextVO);
		Mockito.when(wsProxy.updateCodeTable(Mockito.mock(CodeTable.class)))
				.thenReturn(1L);
		View updateCodeTable = scotsController.updateCodeTable(codeTable,
				model, sessionStatus, session, request);
		Assert.assertEquals(
				"org.springframework.web.servlet.view.RedirectView: unnamed; URL [submitterWorkQueueHome.form?domainName=SCoTS]",
				updateCodeTable.toString());

		Mockito.when(request.getParameter("taskId")).thenReturn("209");
		updateCodeTable = scotsController.updateCodeTable(codeTable, model,
				sessionStatus, session, request);
		Assert.assertEquals(
				"org.springframework.web.servlet.view.RedirectView: unnamed; URL [submitterWorkQueueHome.form?domainName=SCoTS]",
				updateCodeTable.toString());

	}

	/**
	 * Method to test lockCodeTable of SCoTSController
	 * 
	 */
	@Test
	public void testLockCodeTable() {
		CodeTable codeTable = new CodeTable();
		codeTable.setCodeTableId(1L);
		HttpSession session = Mockito.mock(HttpSession.class);
		Mockito.when(session.getAttribute("taskId")).thenReturn("");
		Mockito.when(wsProxy.lockCodeTable(Mockito.anyLong())).thenReturn("false");
		String lockCodeTable = scotsController.lockCodeTable(codeTable,
				session);
		Assert.assertEquals(null, lockCodeTable.toString());
		Mockito.when(session.getAttribute("taskId")).thenReturn("1");
		lockCodeTable = scotsController.lockCodeTable(codeTable, session);
		Assert.assertEquals("false", lockCodeTable);
	}

	/**
	 * Method to test lockCodeValue of SCoTSController
	 * 
	 */
	@Test
	public void testLockCodeValue() {
		CodeValue codeValue = new CodeValue();
		codeValue.setCodeValueId(1L);
		HttpSession session = Mockito.mock(HttpSession.class);
		Mockito.when(wsProxy.lockCodeValue(Mockito.anyLong())).thenReturn("false");
		Mockito.when(session.getAttribute(Mockito.anyString())).thenReturn("");
		String lockCodeValue = scotsController.lockCodeValue(codeValue, session);
		Assert.assertEquals("false", lockCodeValue.toString());
	}

	/**
	 * Method to test manageCodeRelationship of SCoTSController
	 * 
	 */
	@Test
	public void testManageCodeRelationship() {
		HttpSession session = Mockito.mock(HttpSession.class);
		Model model = Mockito.mock(Model.class);
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(wsProxy.retrieveCodeTableList()).thenReturn(
				codeValueVOList);
		ModelAndView manageCodeRelationship = scotsController
				.manageCodeRelationship(session, model);
		Assert.assertEquals("codeRelationshipView",
				manageCodeRelationship.getViewName());
	}

	/**
	 * Method to test retrieveCodeRelationship of SCoTSController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testRetrieveCodeRelationship() {
		Model model = Mockito.mock(Model.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		Long parentCodeTableId=1L;
		Long childCodeTableId=2L;
		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		List<CodeValue> codeValueList = new ArrayList<CodeValue>();
		CodeValue codeValue = new CodeValue();
		codeValue.setCodeValueId(3L);
		codeValueList.add(codeValue);
		tempCodeValueMap.put(
				"1",
				codeValueList);
		tempCodeValueMap.put(
				"2",
				codeValueList);
		Mockito.when(homeController.retrieveCodeValues(Mockito.anyList()))
				.thenReturn(tempCodeValueMap);
		ModelAndView retrieveCodeRelationship = scotsController
				.retrieveCodeRelationship(parentCodeTableId, childCodeTableId,
						null, false, model, session);
		Assert.assertEquals("codeRelationshipView", retrieveCodeRelationship.getViewName());
	}
	
	/**
	 * Method to test retrieveCodeRelationship of SCoTSController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testsaveCodeRelationship() {
		Model model = Mockito.mock(Model.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		Long parentCodeTableId=1L;
		Long childCodeTableId=2L;
		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		List<CodeValue> codeValueList = new ArrayList<CodeValue>();
		CodeValue codeValue = new CodeValue();
		codeValue.setCodeValueId(3L);
		codeValueList.add(codeValue);
		tempCodeValueMap.put(
				"1",
				codeValueList);
		tempCodeValueMap.put(
				"2",
				codeValueList);
		Mockito.when(homeController.retrieveCodeValues(Mockito.anyList()))
				.thenReturn(tempCodeValueMap);
		ModelAndView retrieveCodeRelationship = scotsController
				.retrieveCodeRelationship(parentCodeTableId, childCodeTableId,
						null, false, model, session);
		Assert.assertEquals("codeRelationshipView", retrieveCodeRelationship.getViewName());
	}
	
	/**
	 * Method to test testlockScotsRelationship of SCoTSController
	 * 
	 */
	@Test
	public void testlockScotsRelationship() {
		CodeTable codeTable = new CodeTable();
		codeTable.setCodeTableId(1L);
		SCoTSSearchCriteriaVO scotsSearchCriteriaVO= new SCoTSSearchCriteriaVO();
		scotsSearchCriteriaVO.setParentCodeTableId(3L);
		scotsSearchCriteriaVO.setChildCodeTableId(2L);
		
		
		HttpSession session = Mockito.mock(HttpSession.class);
		Mockito.when(session.getAttribute("taskId")).thenReturn("");
		Mockito.when(wsProxy.lockCodeTable(Mockito.anyLong())).thenReturn("false");
		
		String lockCodeTableRelationship = scotsController.lockScotsRelationship(scotsSearchCriteriaVO,session);
		Assert.assertEquals(null, lockCodeTableRelationship);
		Mockito.when(session.getAttribute("taskId")).thenReturn("1");
		lockCodeTableRelationship = scotsController.lockCodeTable(codeTable, session);
		Assert.assertEquals("false", lockCodeTableRelationship);
	}
	
	
	
}
