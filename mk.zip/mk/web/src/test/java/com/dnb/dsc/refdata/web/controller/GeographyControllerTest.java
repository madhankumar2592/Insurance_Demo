package com.dnb.dsc.refdata.web.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GeoDefaultConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoHierarchy;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.web.proxy.GeographyWebServiceProxy;
import com.dnb.dsc.refdata.web.util.EhCacheProvider;
import com.dnb.dsc.refdata.web.util.UserRoleMapper;

/**
 * Class to test the GeographyController Class
 * 
 * 
 */
@RunWith(MockitoJUnitRunner.class)
public class GeographyControllerTest {

	@Mock
	private HomeController homeController;

	@Mock
	private GeographyWebServiceProxy wsProxy;
	
	@Mock
	private EhCacheProvider cacheProvider;

	@Mock
	private UserRoleMapper roleMapper;
	
	@InjectMocks
	GeographyController geographyController = new GeographyController();

	/**
	 * Method to test geoNameCodeSearch of GeographyController
	 * 
	 */
	@Test
	public void testGeoNameCodeSearch() {
		ModelAndView geoNameCodeSearch = geographyController
				.geoNameCodeSearch();
		Assert.assertEquals("geoNameCodeSearch",
				geoNameCodeSearch.getViewName());
	}

	/**
	 * Method to test geoUnitView of GeographyController
	 * 
	 */
	@Test
	public void testGeoUnitView() {
		HttpSession session = Mockito.mock(HttpSession.class);
		Model model = Mockito.mock(Model.class);
		GeoUnit geoUnit = new GeoUnit();
		geoUnit.setGeoUnitId(999960254L);
		List<GeoUnitAssociation> geoUnitAssociation = new ArrayList<GeoUnitAssociation>();
		geoUnit.setParentGeoUnitAssociations(geoUnitAssociation);
		Mockito.when(wsProxy.retrieveGeoUnitByGeoUnitId(Mockito.anyLong()))
				.thenReturn(geoUnit);
		Mockito.when(cacheProvider.retrieveAllGeoConfigurations())
		.thenReturn(new ArrayList<GeoDefaultConfiguration>());
		ModelAndView geoUnitView = geographyController.geoUnitView(geoUnit
				.getGeoUnitId().toString(), null, null, model, session);
		Assert.assertEquals("geoUnitView", geoUnitView.getViewName());
	}

	/**
	 * Method to test populateGeoUnitAssociationParentGeoUnit of
	 * GeographyController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testPopulateGeoUnitAssociationParentGeoUnit() {
		GeoUnit geoUnit = new GeoUnit();
		geoUnit.setGeoUnitId(999960254L);
		List<GeoUnitAssociation> geoUnitAssociation = new ArrayList<GeoUnitAssociation>();
		geoUnit.setParentGeoUnitAssociations(geoUnitAssociation);
		Mockito.when(wsProxy.retrieveGeoUnitsByIdList(Mockito.anyList()))
				.thenReturn(new HashMap<Long, List<GeoUnit>>());
		geographyController.populateGeoUnitAssociationParentGeoUnit(geoUnit);
	}

	/**
	 * Method to test geoUnitUpdate of GeographyController
	 * 
	 */
	@Test
	public void testGeoUnitUpdate() throws ParseException {
		GeoUnit geoUnit = new GeoUnit();
		geoUnit.setGeoUnitId(0L);
		HttpSession session = Mockito.mock(HttpSession.class);
		SessionStatus sessionStatus = Mockito.mock(SessionStatus.class);
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		BindingResult result = Mockito.mock(BindingResult.class);
		Model model = Mockito.mock(Model.class);
		UserContextVO userContextVO = new UserContextVO();
		userContextVO.setUserIdentifier("DNB");
		Mockito.when(session.getAttribute("REFDATA_USER_CONTEXT")).thenReturn(
				userContextVO);
		Mockito.when(session.getAttribute("geoUnitInDB")).thenReturn(geoUnit);
		Mockito.when(roleMapper.getApproverUserGroupId(Mockito.anyString(), Mockito.anyLong()))
				.thenReturn(1L);
		Mockito.when(wsProxy.updateGeoUnit(Mockito.mock(GeoUnit.class)))
		.thenReturn(1L);
		View geoUnitUpdate = geographyController.geoUnitUpdate(geoUnit, result,
				model, sessionStatus, session, request);
		Assert.assertEquals("text/html;charset=ISO-8859-1",
				geoUnitUpdate.getContentType());
	}

	/**
	 * Method to test geoUnitDelete of GeographyController
	 * 
	 */
	@Test
	public void testGeoUnitDelete() {
		GeoUnit geoUnit = new GeoUnit();
		geoUnit.setGeoUnitId(0L);
		HttpSession session = Mockito.mock(HttpSession.class);
		SessionStatus sessionStatus = Mockito.mock(SessionStatus.class);
		BindingResult result = Mockito.mock(BindingResult.class);
		Model model = Mockito.mock(Model.class);
		UserContextVO userContextVO = new UserContextVO();
		userContextVO.setUserIdentifier("DNB");
		Mockito.when(session.getAttribute("REFDATA_USER_CONTEXT")).thenReturn(
				userContextVO);
		Mockito.when(wsProxy.deleteGeoUnitById(new GeoUnit())).thenReturn(null);
		View geoUnitDelete = geographyController.geoUnitDelete(geoUnit, result,
				model, session, sessionStatus);
		Assert.assertEquals("text/html;charset=ISO-8859-1",
				geoUnitDelete.getContentType());
	}

	/**
	 * Method to test getGeoSearchHome of GeographyController
	 * 
	 */
	@Test
	public void testGetGeoSearchHome() {
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(
				wsProxy.retrieveAllCountries(Mockito.anyLong(),
						Mockito.anyLong())).thenReturn(codeValueVOList);
		ModelAndView getGeoSearchHome = geographyController.getGeoSearchHome();
		Assert.assertEquals("geoSearchHome", getGeoSearchHome.getViewName());
	}

	/**
	 * Method to test getGeoSearchAjaxResults of GeographyController
	 * 
	 */
	@Test
	public void testGetGeoSearchAjaxResults() {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		String[] string = { "new", "old" };
		jsonMap.put("count", 10);
		((OngoingStubbing<Map<String, Object>>) Mockito.when(homeController
				.getJsonMap((HttpServletRequest) Mockito.any(),
						(List<?>) Mockito.any(), (Long) Mockito.any(),
						(String[]) Mockito.any()))).thenReturn(jsonMap);
		Mockito.when(homeController.getStartIndex(request)).thenReturn(1);
		Mockito.when(homeController.getMaxResults(request)).thenReturn(10);
		Mockito.when(homeController.getSearchString(request)).thenReturn("New");
		Mockito.when(homeController.getSortBy(request, string)).thenReturn("1");
		Mockito.when(homeController.getSortOrder(request)).thenReturn("1");

		Map<String, Object> getGeoSearchAjaxResults = geographyController
				.getGeoSearchAjaxResults(request, session);
		Assert.assertEquals(1, getGeoSearchAjaxResults.size());
	}

	/**
	 * Method to test getCountryGroupSearchHome of GeographyController
	 * 
	 */
	@Test
	public void testGetCountryGroupSearchHome() {
		HttpSession session = Mockito.mock(HttpSession.class);
		Model model = Mockito.mock(Model.class);
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(
				wsProxy.retrieveAllCountryGroups(Mockito.anyLong(),
						Mockito.anyLong())).thenReturn(codeValueVOList);

		ModelAndView getCountryGroupSearchHome = geographyController
				.getCountryGroupSearchHome(model, session);
		Assert.assertEquals("countryGroupSearch",
				getCountryGroupSearchHome.getViewName());
	}

	/**
	 * Method to test searchCountryGroups of GeographyController
	 * 
	 */
	@Test
	public void testSearchCountryGroups() {
		HttpSession session = Mockito.mock(HttpSession.class);

		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(
				wsProxy.retrieveAllCountryGroups(Mockito.anyLong(),
						Mockito.anyLong())).thenReturn(codeValueVOList);
		Mockito.when(
				wsProxy.searchCountryGroups(Mockito.anyLong(),
						Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(new ArrayList<GeoUnitName>());
		ModelAndView searchCountryGroups = geographyController
				.searchCountryGroups(1L, session);
		Assert.assertEquals("countryGroupSearch",
				searchCountryGroups.getViewName());
	}

	/**
	 * Method to test countryGroupView of GeographyController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testCountryGroupView() {
		GeoUnit geoUnit = new GeoUnit();
		geoUnit.setGeoUnitId(999960254L);
		HttpSession session = Mockito.mock(HttpSession.class);
		Model model = Mockito.mock(Model.class);
		List<GeoUnitAssociation> geoUnitAssociation = new ArrayList<GeoUnitAssociation>();
		geoUnit.setParentGeoUnitAssociations(geoUnitAssociation);
		Mockito.when(wsProxy.retrieveGeoUnitByGeoUnitId(Mockito.anyLong()))
				.thenReturn(geoUnit);
		List<Integer> codeTableIds = Mockito.mock(List.class);
		Map<String, List<CodeValue>> tempCodeValueMap = Mockito.mock(Map.class);
		List<CodeValue> codeValue = new ArrayList<CodeValue>();
		tempCodeValueMap.put("1", codeValue);
		Mockito.when(homeController.retrieveCodeValues(codeTableIds))
				.thenReturn(tempCodeValueMap);
		Mockito.when(
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE)))
				.thenReturn(codeValue);
		ModelAndView countryGroupView = geographyController.countryGroupView(
				String.valueOf(geoUnit.getGeoUnitId()), null, null, model, session);
		Assert.assertEquals("countryGroupView", countryGroupView.getViewName());
	}

	/**
	 * Method to test retrieveChildGeoUnitsForCountry of GeographyController
	 * 
	 */
	@Test
	public void testRetrieveChildGeoUnitsForCountry() {
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(
				wsProxy.retrieveChildGeoUnitsByType(Mockito.anyLong(),
						Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(codeValueVOList);

		List<CodeValueVO> retrieveChildGeoUnits = geographyController
				.retrieveChildGeoUnitsForCountry(1L);
		Assert.assertEquals(1, retrieveChildGeoUnits.size());
	}

	/**
	 * Method to test retrieveChildGeoUnits of GeographyController
	 * 
	 */
	@Test
	public void testRetrieveChildGeoUnits() {
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		HttpSession session = Mockito.mock(HttpSession.class);
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(
				wsProxy.retrieveChildGeoUnitsByType(Mockito.anyLong(),
						Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(codeValueVOList);

		List<CodeValueVO> retrieveChildGeoUnits = geographyController
				.retrieveChildGeoUnits(1L, 2L, 1073L, session);
		Assert.assertEquals(1, retrieveChildGeoUnits.size());
	}

	/**
	 * Method to test lockGeoUnit of GeographyController
	 * 
	 */
	@Test
	public void testLockGeoUnit() {
		GeoUnit geoUnit = new GeoUnit();
		geoUnit.setGeoUnitId(1L);		
		Mockito.when(wsProxy.lockGeoUnit(Mockito.anyLong())).thenReturn("false");
		String lockExchangeRate = geographyController.lockGeoUnit(geoUnit);
		Assert.assertEquals("false", lockExchangeRate);
	}

	/**
	 * Method to test loadAddGeoUnit of GeographyController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testLoadAddGeoUnit() {
		Model model = Mockito.mock(Model.class);
		List<Integer> codeTableIds = Mockito.mock(List.class);
		Map<String, List<CodeValue>> tempCodeValueMap = Mockito.mock(Map.class);
		List<CodeValue> codeValue = new ArrayList<CodeValue>();
		tempCodeValueMap.put("1", codeValue);
		Mockito.when(homeController.retrieveCodeValues(codeTableIds))
				.thenReturn(tempCodeValueMap);
		Mockito.when(
				tempCodeValueMap.get(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE)))
				.thenReturn(codeValue);
		ModelAndView loadAddGeoUnit = geographyController.loadAddGeoUnit(model);
		Assert.assertEquals("addGeoUnit", loadAddGeoUnit.getViewName());
	}

	/**
	 * Method to test loadAddGeoUnit of GeographyController
	 * 
	 */
	@Test
	public void testSaveGeoUnit() {
		HttpSession session = Mockito.mock(HttpSession.class);
		BindingResult result = Mockito.mock(BindingResult.class);
		GeoUnit geoUnit = new GeoUnit();
		geoUnit.setGeoUnitId(1L);
		List<GeoUnitAssociation> geoUnitAssociation = new ArrayList<GeoUnitAssociation>();
		geoUnit.setParentGeoUnitAssociations(geoUnitAssociation);
		Mockito.when(wsProxy.insertGeoUnit(Mockito.mock(GeoUnit.class)))
				.thenReturn(1L);
		UserContextVO userContextVO = new UserContextVO();
		userContextVO.setUserIdentifier("DNB");
		Mockito.when(session.getAttribute("REFDATA_USER_CONTEXT")).thenReturn(
				userContextVO);
		View saveGeoUnit = geographyController.saveGeoUnit(geoUnit, result,
				session);
		Assert.assertEquals("text/html;charset=ISO-8859-1",
				saveGeoUnit.getContentType());
	}

	/**
	 * Method to test retrieveCountryList of GeographyController
	 * 
	 */
	@Test
	public void testRetrieveCountryList() {
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(
				wsProxy.retrieveAllCountries(Mockito.anyLong(),
						Mockito.anyLong())).thenReturn(codeValueVOList);
		List<CodeValueVO> retrieveCountryList = geographyController
				.retrieveCountryList();
		Assert.assertEquals(1, retrieveCountryList.size());
	}

	/**
	 * Method to test retrieveContinentList of GeographyController
	 * 
	 */
	@Test
	public void testRetrieveContinentList() {
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(
				wsProxy.retrieveAllContinents(Mockito.anyLong(),
						Mockito.anyLong())).thenReturn(codeValueVOList);
		List<CodeValueVO> retrieveContinentList = geographyController
				.retrieveContinentList();
		Assert.assertEquals(1, retrieveContinentList.size());
	}

	/**
	 * Method to test getGeoSearchNameAjaxResults of GeographyController
	 * 
	 */
	@Test
	public void testGetGeoSearchNameAjaxResults() {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		String[] string = { "new", "old" };
		jsonMap.put("count", 10);
		((OngoingStubbing<Map<String, Object>>) Mockito.when(homeController
				.getJsonMap((HttpServletRequest) Mockito.any(),
						(List<?>) Mockito.any(), (Long) Mockito.any(),
						(String[]) Mockito.any()))).thenReturn(jsonMap);
		Mockito.when(homeController.getStartIndex(request)).thenReturn(1);
		Mockito.when(homeController.getMaxResults(request)).thenReturn(10);
		Mockito.when(homeController.getSearchString(request)).thenReturn("New");
		Mockito.when(homeController.getSortBy(request, string)).thenReturn("1");
		Mockito.when(homeController.getSortOrder(request)).thenReturn("1");
		Mockito.when(wsProxy.countSearchGeoUnitByName(Mockito.anyString()))
				.thenReturn(0L);

		Map<String, Object> getGeoSearchAjaxResults = geographyController
				.getGeoSearchNameAjaxResults(request, session);
		Assert.assertEquals(1, getGeoSearchAjaxResults.size());
	}

	/**
	 * Method to test getGeoSearchCodeAjaxResults of GeographyController
	 * 
	 */
	@Test
	public void testGetGeoSearchCodeAjaxResults() {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		String[] string = { "new", "old" };
		jsonMap.put("count", 10);
		((OngoingStubbing<Map<String, Object>>) Mockito.when(homeController
				.getJsonMap((HttpServletRequest) Mockito.any(),
						(List<?>) Mockito.any(), (Long) Mockito.any(),
						(String[]) Mockito.any()))).thenReturn(jsonMap);
		Mockito.when(homeController.getStartIndex(request)).thenReturn(1);
		Mockito.when(homeController.getMaxResults(request)).thenReturn(10);
		Mockito.when(homeController.getSearchString(request)).thenReturn("New");
		Mockito.when(homeController.getSortBy(request, string)).thenReturn("1");
		Mockito.when(homeController.getSortOrder(request)).thenReturn("1");
		Mockito.when(wsProxy.countSearchGeoUnitByName(Mockito.anyString()))
				.thenReturn(0L);

		Map<String, Object> getGeoSearchAjaxResults = geographyController
				.getGeoSearchCodeAjaxResults(request, session);
		Assert.assertEquals(1, getGeoSearchAjaxResults.size());
	}

	/**
	 * Method to test getOfficialNameByGeoUnitIdAndTypeCode of
	 * GeographyController
	 * 
	 */
	@Test
	public void testGetOfficialNameByGeoUnitIdAndTypeCode() {
		Long newParentGeoUnitId = 1L;
		Long newParentGeoUnitTypeCode = 2L;
		GeoUnit geoUnit = new GeoUnit();
		Mockito.when(
				wsProxy.getOfficialNameByGeoUnitIdAndTypeCode(
						Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn("Official");
		String getOfficialNameByGeoUnitIdAndTypeCode = geographyController
				.getOfficialNameByGeoUnitIdAndTypeCode(newParentGeoUnitId,
						newParentGeoUnitTypeCode, geoUnit);
		Assert.assertEquals("{\"officialName\" : \"Official\"}",
				getOfficialNameByGeoUnitIdAndTypeCode);
	}

	/**
	 * Method to test getHierarchyByGeoUnitId of GeographyController
	 * 
	 */
	@Test
	public void testGetHierarchyByGeoUnitId() {
		GeoUnit geoUnit = new GeoUnit();
		Mockito.when(
				wsProxy.getHierarchyByGeoUnitId(Mockito.anyLong(),
						Mockito.anyLong())).thenReturn(
				new HashMap<Long, String>());

		Map<Long, String> getHierarchyByGeoUnitId = geographyController
				.getHierarchyByGeoUnitId(geoUnit);
		Assert.assertEquals("class java.util.HashMap", getHierarchyByGeoUnitId
				.getClass().toString());
	}

	/**
	 * Method to test checkForChildGeoUnit of GeographyController
	 * 
	 */
	@Test
	public void testCheckForChildGeoUnit() {
		Long geoUnitId = 1L;
		Mockito.when(wsProxy.checkForChildGeoUnit(Mockito.anyLong()))
				.thenReturn(true);
		Boolean lockExchangeRate = geographyController
				.checkForChildGeoUnit(geoUnitId);
		Assert.assertEquals(true, lockExchangeRate.booleanValue());
	}

	/**
	 * Method to test geoUnitIdSearch of GeographyController
	 * 
	 */
	@Test
	public void testGeoUnitIdSearch() {
		HttpSession session = Mockito.mock(HttpSession.class);
		Model model = Mockito.mock(Model.class);
		ModelAndView geoUnitIdSearch = geographyController
				.geoUnitIdSearch("", model, session);
		Assert.assertEquals("geoUnitIdSearch",
				geoUnitIdSearch.getViewName());
	}
	/**
	 * Method to test resetGeoHierarchies of GeographyController
	 * 
	 */
	@Test
	public void testResetGeoHierarchies() {
		Long parentGeoUnitId=892L;
		Collection<String> resetGeoHierarchies=geographyController.resetGeoHierarchies(parentGeoUnitId);
		GeoHierarchy geoHierarchy =new GeoHierarchy();
		List<GeoHierarchy> geohierarchies = new ArrayList<GeoHierarchy>();
		geohierarchies.add(geoHierarchy);
		Mockito.when(wsProxy.retrieveAllGeoHierarchies())
		.thenReturn(geohierarchies);
		Assert.assertEquals(5,resetGeoHierarchies.size());
	}
}
