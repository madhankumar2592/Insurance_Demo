package com.dnb.dsc.refdata.web.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeMap;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.IndustryCodesSearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.UserContextVO;
import com.dnb.dsc.refdata.web.proxy.IndustryCodesWebServiceProxy;

/**
 * Class to test the IndustryCodesController Class
 * 
 * 
 */
@RunWith(MockitoJUnitRunner.class)
public class IndustryCodesControllerTest {

	@Mock
	private HomeController homeController;

	@Mock
	private IndustryCodesWebServiceProxy wsProxy;
	
	@Mock
	private SCoTSController scotsController;

	@Mock
	private WorkQueueController workQueueController;

	@InjectMocks
	private IndustryCodesController industryCodesController = new IndustryCodesController();

	/**
	 * Method to test getCurrencySearchHome of IndustryCodesController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testGetIndustryCodesSearchHome() {
		HttpSession session = Mockito.mock(HttpSession.class);

		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		List<CodeValue> codeValueList = new ArrayList<CodeValue>();
		CodeValue codeValue = new CodeValue();
		codeValue.setCodeValueId(1L);
		codeValueList.add(codeValue);
		tempCodeValueMap
				.put(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING,
						codeValueList);
		Mockito.when(homeController.retrieveCodeValues(Mockito.anyList()))
				.thenReturn(tempCodeValueMap);
		ModelAndView getCurrencySearchHome = industryCodesController
				.getIndustryCodesSearchHome(session);
		Assert.assertEquals("indsCodeSearch",
				getCurrencySearchHome.getViewName());
	}

	/**
	 * Method to test getIndustryCodesSearchAjaxResults of
	 * IndustryCodesController
	 * 
	 */
	@Test
	public void testGetIndustryCodesSearchAjaxResults() {
		IndustryCodesSearchCriteriaVO industryCodesSearchCriteria = new IndustryCodesSearchCriteriaVO();
		HttpSession session = Mockito.mock(HttpSession.class);
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		String[] string = { "new", "old" };
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		((OngoingStubbing<Map<String, Object>>) Mockito.when(homeController
				.getJsonMap((HttpServletRequest) Mockito.any(),
						(List<?>) Mockito.any(), (Long) Mockito.any(),
						(String[]) Mockito.any()))).thenReturn(jsonMap);

		Mockito.when(
				wsProxy.countSearchIndustryCodes(industryCodesSearchCriteria))
				.thenReturn(1L);
		Mockito.when(homeController.getStartIndex(request)).thenReturn(1);
		Mockito.when(homeController.getMaxResults(request)).thenReturn(10);
		Mockito.when(homeController.getSearchString(request)).thenReturn(
				"10001");
		Mockito.when(homeController.getSortBy(request, string)).thenReturn("1");
		Mockito.when(homeController.getSortOrder(request)).thenReturn("1");

		Map<String, Object> getIndustryCodesSearchAjaxResults = industryCodesController
				.getIndustryCodesSearchAjaxResults(request, session);
		Assert.assertNotNull(getIndustryCodesSearchAjaxResults);
	}

	/**
	 * Method to test getIndustryCodesCrosswalkSearchAjaxResults of
	 * IndustryCodesController
	 * 
	 */
	@Test
	public void testGetIndustryCodesCrosswalkSearchAjaxResults() {
		IndustryCodesSearchCriteriaVO industryCodesSearchCriteria = new IndustryCodesSearchCriteriaVO();
		HttpSession session = Mockito.mock(HttpSession.class);
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		String[] string = { "new", "old" };
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		((OngoingStubbing<Map<String, Object>>) Mockito.when(homeController
				.getJsonMap((HttpServletRequest) Mockito.any(),
						(List<?>) Mockito.any(), (Long) Mockito.any(),
						(String[]) Mockito.any()))).thenReturn(jsonMap);

		Mockito.when(
				wsProxy.countSearchIndustryCodes(industryCodesSearchCriteria))
				.thenReturn(1L);
		Mockito.when(homeController.getStartIndex(request)).thenReturn(1);
		Mockito.when(homeController.getMaxResults(request)).thenReturn(10);
		Mockito.when(homeController.getSearchString(request)).thenReturn(
				"10001");
		Mockito.when(homeController.getSortBy(request, string)).thenReturn("1");
		Mockito.when(homeController.getSortOrder(request)).thenReturn("1");

		Map<String, Object> getIndustryCodesCrosswalkSearchAjaxResults = industryCodesController
				.getIndustryCodesCrosswalkSearchAjaxResults(request, session);
		Assert.assertNotNull(getIndustryCodesCrosswalkSearchAjaxResults);
	}

	/**
	 * Method to test retrieveCrossWalksForIndsCodeType of
	 * IndustryCodesController
	 * 
	 */
	@Test
	public void testRetrieveCrossWalksForIndsCodeType() {
		HttpSession session = Mockito.mock(HttpSession.class);
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(
				wsProxy.retrieveCrossWalksForIndsCodeType(Mockito.anyLong()))
				.thenReturn(codeValueVOList);
		List<CodeValueVO> retrieveCrossWalksForIndsCodeType = industryCodesController
				.retrieveCrossWalksForIndsCodeType(Mockito.anyLong(), session);
		Assert.assertEquals(1, retrieveCrossWalksForIndsCodeType.size());
	}

	/**
	 * Method to test retrieveGroupLevelCodes of IndustryCodesController
	 * 
	 */
	@Test
	public void testRetrieveGroupLevelCodes() {
		HttpSession session = Mockito.mock(HttpSession.class);
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(
				wsProxy.retrieveGroupLevelCodes(Mockito.anyLong(),
						Mockito.anyLong())).thenReturn(codeValueVOList);

		List<CodeValueVO> retrieveGroupLevelCodes = industryCodesController
				.retrieveGroupLevelCodes(Mockito.anyLong(), Mockito.anyLong(),
						session);

		Assert.assertEquals(1, retrieveGroupLevelCodes.size());
	}

	/**
	 * Method to test retrieveLanguageForIndsCodeType of IndustryCodesController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testRetrieveLanguageForIndsCodeType() {
		HttpSession session = Mockito.mock(HttpSession.class);
		List<CodeValueVO> codeValueVOList = new ArrayList<CodeValueVO>();
		CodeValueVO codeValueVO = new CodeValueVO(1L, "Test", "Test");
		codeValueVOList.add(codeValueVO);
		Mockito.when(
				wsProxy.retrieveIndustryCodeLanguages(Mockito.anyLong(),
						Mockito.anyList())).thenReturn(codeValueVOList);

		List<CodeValueVO> retrieveLanguageForIndsCodeType = industryCodesController
				.retrieveLanguageForIndsCodeType(Mockito.anyLong(),
						Mockito.anyString(), session);

		Assert.assertEquals(1, retrieveLanguageForIndsCodeType.size());
	}

	/**
	 * Method to test toggleIndsCodeTable of IndustryCodesController
	 * 
	 */
	@SuppressWarnings("rawtypes")
	@Test
	public void testToggleIndsCodeTable() {
		HttpSession session = Mockito.mock(HttpSession.class);
		Model model = Mockito.mock(Model.class);

		List<CodeValue> codeValueList = new ArrayList<CodeValue>();
		CodeValue codeValue = new CodeValue();
		codeValue.setCodeValueId(1L);
		codeValueList.add(codeValue);
		Mockito.when(session.getAttribute(Mockito.anyString())).thenReturn(
				codeValueList);
		List codeValues = industryCodesController.toggleIndsCodeTable("CODE",
				session, model);

		Assert.assertEquals(1, codeValues.size());
	}

	/**
	 * Method to test getIndustryCodesDetail of IndustryCodesController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testGetIndustryCodesDetail() {
		HttpSession session = Mockito.mock(HttpSession.class);
		Model model = Mockito.mock(Model.class);

		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		List<CodeValue> codeValueList = new ArrayList<CodeValue>();
		CodeValue codeValue = new CodeValue();
		codeValue.setCodeValueId(1L);
		codeValueList.add(codeValue);
		tempCodeValueMap
				.put(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING,
						codeValueList);
		tempCodeValueMap
				.put(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_GROUP_LEVEL),
						codeValueList);
		tempCodeValueMap
				.put(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE),
						codeValueList);
		tempCodeValueMap.put(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE),
				codeValueList);

		Mockito.when(homeController.retrieveCodeValues(Mockito.anyList()))
				.thenReturn(tempCodeValueMap);
		Mockito.when(scotsController.retrieveValidIndustryCodeGroupLevels())
		.thenReturn(codeValueList);
		Mockito.when(
				wsProxy.retrieveIndustryCodeByIndustryCodeId(Mockito.anyLong()))
				.thenReturn(new IndustryCode());

		ModelAndView getIndustryCodesDetail = industryCodesController
				.getIndustryCodesDetail(Mockito.anyLong(), Mockito.anyString(),
						model, session);
		Assert.assertEquals("indsCodesDetail",
				getIndustryCodesDetail.getViewName());
	}

	/**
	 * Method to test getIndustryCodesDetail of IndustryCodesController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testIndsCodeUpdate() throws ParseException {
		IndustryCode industryCode = Mockito.mock(IndustryCode.class);
		BindingResult result = Mockito.mock(BindingResult.class);
		HttpSession session = Mockito.mock(HttpSession.class);
		SessionStatus sessionStatus = Mockito.mock(SessionStatus.class);
		Model model = Mockito.mock(Model.class);

		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		List<CodeValue> codeValueList = new ArrayList<CodeValue>();
		CodeValue codeValue = new CodeValue();
		codeValue.setCodeValueId(1L);
		codeValueList.add(codeValue);
		tempCodeValueMap
				.put(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING,
						codeValueList);
		tempCodeValueMap
				.put(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_GROUP_LEVEL),
						codeValueList);
		tempCodeValueMap
				.put(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE),
						codeValueList);
		tempCodeValueMap.put(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE),
				codeValueList);
		UserContextVO userContextVO = new UserContextVO();
		userContextVO.setUserIdentifier("DNB");
		Mockito.when(session.getAttribute("REFDATA_USER_CONTEXT")).thenReturn(
				userContextVO);
		Mockito.when(homeController.retrieveCodeValues(Mockito.anyList()))
				.thenReturn(tempCodeValueMap);
		Mockito.when(
				wsProxy.retrieveIndustryCodeByIndustryCodeId(Mockito.anyLong()))
				.thenReturn(new IndustryCode());
		Mockito.when(
				workQueueController.getSubmitterWorkQueueHome(Mockito.anyString(),Mockito.any(HttpSession.class)))
				.thenReturn(new ModelAndView());
		
		ModelAndView indsCodeUpdate = industryCodesController.indsCodeUpdate(
				industryCode, result, model, sessionStatus, session);
		Assert.assertEquals(null, indsCodeUpdate.getViewName());
	}

	/**
	 * Method to test retrieveDescriptionForIndsCodeTypeCode of
	 * IndustryCodesController
	 * 
	 */
	@Test
	public void testRetrieveDescriptionForIndsCodeTypeCode() {
		Mockito.when(
				wsProxy.retrieveDescriptionForIndsCodeTypeCode(
						Mockito.anyLong(), Mockito.anyString())).thenReturn(
				"Test");
		String retrieveDescriptionForIndsCodeTypeCode = industryCodesController
				.retrieveDescriptionForIndsCodeTypeCode(Mockito.anyLong(),
						Mockito.anyString());
		Assert.assertEquals("{\"description\" : \"Test\"}",
				retrieveDescriptionForIndsCodeTypeCode);
	}

	/**
	 * Method to test lockIndustryCodeForEdit of IndustryCodesController
	 * 
	 */
	@Test
	public void testLockIndustryCodeForEdit() {
		HttpSession session = Mockito.mock(HttpSession.class);
		IndustryCode industryCode = new IndustryCode();
		industryCode.setIndustryCodeId(1L);
		Mockito.when(wsProxy.lockIndustryCode(Mockito.anyLong())).thenReturn("false");
		Mockito.when(session.getAttribute(Mockito.anyString())).thenReturn("");
		String lockIndustryCode = industryCodesController
				.lockIndustryCodeForEdit(industryCode, session);
		Assert.assertEquals("false", lockIndustryCode);
	}

	/**
	 * Method to test getIndustryCodesAdd of IndustryCodesController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testGetIndustryCodesAdd() {
		HttpSession session = Mockito.mock(HttpSession.class);
		Model model = Mockito.mock(Model.class);

		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		List<CodeValue> codeValueList = new ArrayList<CodeValue>();
		CodeValue codeValue = new CodeValue();
		codeValue.setCodeValueId(1L);
		codeValueList.add(codeValue);
		tempCodeValueMap
				.put(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING,
						codeValueList);
		tempCodeValueMap
				.put(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_GROUP_LEVEL),
						codeValueList);
		tempCodeValueMap
				.put(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE),
						codeValueList);
		tempCodeValueMap.put(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE),
				codeValueList);

		Mockito.when(homeController.retrieveCodeValues(Mockito.anyList()))
				.thenReturn(tempCodeValueMap);

		ModelAndView getIndustryCodesAdd = industryCodesController
		.getIndustryCodesAdd(model, session);
		Assert.assertEquals("indsCodesAdd", getIndustryCodesAdd.getViewName());
	}
	
	/**
	 * Method to test indsCodeAddToDB of IndustryCodesController
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testIndsCodeAddToDB() throws  ParseException{
		HttpSession session = Mockito.mock(HttpSession.class);
		Model model = Mockito.mock(Model.class);
		SessionStatus sessionStatus = Mockito.mock(SessionStatus.class);
		BindingResult result = Mockito.mock(BindingResult.class);
		IndustryCode industryCode = new IndustryCode();
		industryCode.setIndustryCodeMaps(new ArrayList<IndustryCodeMap>());
		industryCode.setIndustryCodeId(1L);
		Map<String, List<CodeValue>> tempCodeValueMap = new HashMap<String, List<CodeValue>>();
		List<CodeValue> codeValueList = new ArrayList<CodeValue>();
		CodeValue codeValue = new CodeValue();
		codeValue.setCodeValueId(1L);
		codeValueList.add(codeValue);
		tempCodeValueMap
				.put(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING,
						codeValueList);
		tempCodeValueMap
				.put(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_GROUP_LEVEL),
						codeValueList);
		tempCodeValueMap
				.put(String
						.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE),
						codeValueList);
		tempCodeValueMap.put(String
				.valueOf(RefDataPropertiesConstants.CODE_TABLE_ID_LANGUAGE),
				codeValueList);

		Mockito.when(homeController.retrieveCodeValues(Mockito.anyList()))
				.thenReturn(tempCodeValueMap);
		UserContextVO userContextVO = new UserContextVO();
		userContextVO.setUserIdentifier("DNB");
		Mockito.when(session.getAttribute("REFDATA_USER_CONTEXT")).thenReturn(
				userContextVO);
		ModelAndView getIndustryCodesAdd = industryCodesController
		.indsCodeAddToDB(industryCode, result, model, sessionStatus, session);
		Assert.assertNull(getIndustryCodesAdd);
	}
	
}
