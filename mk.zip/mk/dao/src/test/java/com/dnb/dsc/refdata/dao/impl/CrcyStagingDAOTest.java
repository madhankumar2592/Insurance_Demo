package com.dnb.dsc.refdata.dao.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.CurrencySearchCriteriaVO;
import com.dnb.dsc.refdata.dao.CrcyStagingDAO;

/**
 * This test class is used as the DAO implementation class for the Geography
 * operations. The DAO contacts the staging DB for all its operations
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-dao-test.xml" })
public class CrcyStagingDAOTest {


	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CrcyStagingDAOTest.class);

	@Autowired
	private CrcyStagingDAO stagingDAO;
	
	/**
	 * 
	 * The method will perform a hierarchy search of Currency Exchange on the
	 * search db.
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 */
	@Test
	public void testSearchCurrencyExchange() {

		LOGGER.info("entering CrcyStagingDAOTest | testSearchCurrencyExchange");

		CurrencySearchCriteriaVO currencySearchCriteria = new CurrencySearchCriteriaVO();
		currencySearchCriteria.setSortOrder("asc");
		currencySearchCriteria.setSortBy("1");
		currencySearchCriteria.setMaxResults(10);
		currencySearchCriteria.setRowIndex(1);
		currencySearchCriteria.setFromCurrencyCode("1");
		currencySearchCriteria.setToCurrencyCode("28");
		currencySearchCriteria.setFromDate(getDateForString("2004-12-15"));
		currencySearchCriteria.setFromDate(getDateForString("2004-12-15"));
		currencySearchCriteria.setDataProviderCode("581");

		List<CurrencyExchange> currencyExchangeResult = stagingDAO
				.searchCurrencyExchange(currencySearchCriteria);
		Assert.assertEquals(10, currencyExchangeResult.size());
	}
	
	
	/**
	 * The method to retrieve all data providers for the currency exchange data.
	 * The data will be fetched from the currency exchange tables.
	 */
	@Test
	public void testRetrieveCurcyExchDataProviders() {

		LOGGER.info("entering CrcyStagingDAOTest | testRetrieveCurcyExchDataProviders");

		Long languageCode = 39L;
		List<CodeValueVO> retrieveDataProviderList = stagingDAO
				.retrieveCurcyExchDataProviders(languageCode);
		Assert.assertNotNull(retrieveDataProviderList);
	}

	/**
	 * The method will count the records in the hierarchy search of currency
	 * units on the search db. The search will be done on the flat db based on
	 * the search criteria the user had provided.
	 */
	@Test
	public void testCountSearchCurrencyExchange() {

		LOGGER.info("entering CrcyStagingDAOTest | testCountSearchCurrencyExchange");

		CurrencySearchCriteriaVO currencySearchCriteria = new CurrencySearchCriteriaVO();
		currencySearchCriteria.setSortOrder("asc");
		currencySearchCriteria.setSortBy("1");
		currencySearchCriteria.setMaxResults(10);
		currencySearchCriteria.setRowIndex(1);
		currencySearchCriteria.setFromCurrencyCode("1");
		currencySearchCriteria.setToCurrencyCode("28");
		currencySearchCriteria.setFromDate(getDateForString("12/15/2004"));
		currencySearchCriteria.setFromDate(getDateForString("12/15/2012"));
		currencySearchCriteria.setDataProviderCode("581");

		Long countCurrencyExchange = stagingDAO
				.countSearchCurrencyExchange(currencySearchCriteria);

		Assert.assertEquals(169L, countCurrencyExchange.longValue());
	}
	
	/**
	 * The method will search the Staging SoR for the CurrencyExchange based on
	 * the currencyExchangeId and will return the CurrencyExchange entity
	 */
	@Test
	public void testRetrieveCurrencyExchangeByCurrencyExchangeId() {
		LOGGER.info("entering CrcyStagingDAOTest | testRetrieveCurrencyExchangeByCurrencyExchangeId");

		Long currencyExchangeId = 100188L;
		CurrencyExchange retrieveCurrencyExchangeByCurrencyExchangeIdResult = stagingDAO
				.retrieveCurrencyExchangeByCurrencyExchangeId(currencyExchangeId);
		Assert.assertEquals(4479L,
				retrieveCurrencyExchangeByCurrencyExchangeIdResult
						.getFromCurrencyCode().longValue());
	}
	
	/**
	 * The method to test if currency exchange rate data is persisted in the
	 * Transaction DB.
	 */
	@Test
	public void testUpdateExchangeRate() {
		LOGGER.info("entering CrcyStagingDAOTest | testUpdateExchangeRate");

		CurrencyExchange currencyExchange = new CurrencyExchange(100176L,
				4550L, 28L, getDateForString("09/01/2007"), 11552L, 0.8765D,
				581L, "DNB", getDateForString("02/23/2012"), "DNB",
				getDateForString("09/01/2007"));

		CurrencyExchange result = stagingDAO
				.updateExchangeRate(currencyExchange);
		Assert.assertEquals(100176L,result.getCurrencyExchangeId().longValue());
	}
	/**
	 * method to convert a String object into a Date type object
	 * 
	 * @param inputStr
	 * @return
	 */
	private Date getDateForString(String inputStr) {
			DateFormat formatter = new SimpleDateFormat(
			RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT);
		try {
			return (Date) formatter.parse(inputStr);
		} catch (ParseException e) {
			return null;
		}
	}
}


