/*
 * Cognizant PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Cognizant Technology Solutions. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */

package com.dnb.dsc.refdata.dao.impl;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.IndustryCodesSearchCriteriaVO;
import com.dnb.dsc.refdata.dao.IndsCodeStagingDAO;

/**
 * This test class is used as the test class for DAO implementation class for
 * the Industry Code operations. The DAO contacts the staging DB for all its
 * operations
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-dao-test.xml" })
public class IndsCodeStagingDAOTest {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(IndsCodeStagingDAOTest.class);

	@Autowired
	private IndsCodeStagingDAO stagingDAO;

	/**
	 *
	 * Performs a hierarchy search of Industry Codes on the search db.
	 */
	@Test
	public void testSearchIndustryCodes() {
		LOGGER.info("entering IndsCodeStagingDAOTest | testSearchIndustryCodes");

		IndustryCodesSearchCriteriaVO industryCodesSearchCriteria = new IndustryCodesSearchCriteriaVO();
		industryCodesSearchCriteria.setSortOrder("asc");
		industryCodesSearchCriteria.setSortBy("1");
		industryCodesSearchCriteria.setMaxResults(10);
		industryCodesSearchCriteria.setRowIndex(1);
		industryCodesSearchCriteria.setIndustryCodeTypeCode("3844");

		List<IndustryCode> indsCodesList = stagingDAO
				.searchIndustryCodes(industryCodesSearchCriteria);
		Assert.assertEquals(10, indsCodesList.size());

	}


	/**
	 * The method will retrieve Industry code CrossWalks for the selected
	 * industry code type.
	 */
	@Test
	public void testRetrieveCrossWalksForIndsCodeType() {
		LOGGER.info("entering IndsCodeStagingDAOTest | testRetrieveCrossWalksForIndsCodeType");

		Long industryCodeTypeCode = 3844L;
		List<CodeValueVO> crossWalksList = stagingDAO
				.retrieveCrossWalksForIndsCodeType(industryCodeTypeCode);
		Assert.assertEquals(1, crossWalksList.size());
	}



	/**
	 *
	 * The method will count the records in the hierarchy search of industry
	 * codes on the search db. The search will be done on the flat db based on
	 * the search criteria the user had provided.
	 */
	@Test
	public void testCountSearchIndustryCodes() {
		LOGGER.info("entering IndsCodeStagingDAOTest | testCountSearchIndustryCodes");

		IndustryCodesSearchCriteriaVO industryCodesSearchCriteria = new IndustryCodesSearchCriteriaVO();
		industryCodesSearchCriteria.setSortOrder("asc");
		industryCodesSearchCriteria.setSortBy("1");
		industryCodesSearchCriteria.setMaxResults(10);
		industryCodesSearchCriteria.setRowIndex(1);
		industryCodesSearchCriteria.setIndustryCodeTypeCode("3844");

		Long countResults = stagingDAO
				.countSearchIndustryCodes(industryCodesSearchCriteria);
		Assert.assertNotNull(countResults);
	}


	/**
	 * This test method will search the Staging SoR for the IndustryCode based
	 * on the IndustryCodeId and will return the IndustryCode entity.
	 */
	@Test
	public void testRetrieveIndustryCodeByIndustryCodeId() {
		LOGGER.info("entering IndsCodeStagingDAOTest | testRetrieveIndustryCodeByIndustryCodeId");

		Long industryCodeId = 50030469L;
		IndustryCode industryCodeResult = stagingDAO
				.retrieveIndustryCodeByIndustryCodeId(industryCodeId);
		Assert.assertEquals("1112", industryCodeResult.getIndustryCode());
	}

	/**
	 * The method will retrieve Industry code Group Levels for the selected
	 * industry code type.
	 */
	@Test
	public void testRetrieveGroupLevelCodes() {
		LOGGER.info("entering IndsCodeStagingDAOTest | testRetrieveIndustryCodeIdByCodeTypeCode");

		Long industryCodeTypeCode = 3599L;
		List<CodeValueVO> groupLevelList = stagingDAO
				.retrieveGroupLevelCodes(industryCodeTypeCode,39L);
		Assert.assertEquals(5, groupLevelList.size());
	}

	/**
	 * The method will retrieve description for Industry code and type code.
	 */
	@Test
	public void testRetrieveDescriptionForIndsCodeTypeCode() {
		LOGGER.info("entering IndsCodeStagingDAOTest | testRetrieveDescriptionForIndsCodeTypeCode");

		Long industryCodeTypeCode = 1016L;
		String industryCode = "0139";
		String descriptionResult = stagingDAO
				.retrieveDescriptionForIndsCodeTypeCode(industryCodeTypeCode,
						industryCode);
		Assert.assertNotNull(descriptionResult);
	}

	/**
	 * This method will test if industry code id is retrieved by passing
	 * industry code type code
	 */
	@Test
	public void testRetrieveIndustryCodeIdByCodeTypeCode() {
		LOGGER.info("entering IndsCodeStagingDAOTest | testRetrieveIndustryCodeIdByCodeTypeCode");

		Long industryCodeTypeCode = 700L;
		String industryCode = "5418";
		Long descriptionResult = stagingDAO
				.retrieveIndustryCodeIdByCodeTypeCode(industryCodeTypeCode,
						industryCode);
		Assert.assertEquals(50032270L, descriptionResult.longValue());
	}

	/**
	 * This method will test if the Industry Code languages are being retrieved
	 * based on the industry code type code and the group level codes entered
	 */
	@Test
	public void testRetrieveIndustryCodeLanguages() {
		LOGGER.info("entering IndsCodeStagingDAOTest | testRetrieveIndustryCodeLanguages");

		Long industryCodeTypeCode = 700L;
		List<Long> groupLevelCodes = new ArrayList<Long>();
		List<CodeValueVO> codeLanguagesResult = stagingDAO
				.retrieveIndustryCodeLanguages(industryCodeTypeCode,
						groupLevelCodes);
		Assert.assertEquals(3, codeLanguagesResult.size());
	}

	/**
	 * The method will test if the existing IndustryCode data is being persisted
	 * in the Transactional DB
	 */
	@Test
	public void testUpdateIndustryCode() {
		LOGGER.info("entering IndsCodeStagingDAOTest | testUpdateIndustryCode");

		IndustryCode industryCodeResult = stagingDAO
				.retrieveIndustryCodeByIndustryCodeId(3529L);
		Boolean result = stagingDAO
				.updateIndustryCode(industryCodeResult);
		Assert.assertEquals(true,result.booleanValue());
	}
}
