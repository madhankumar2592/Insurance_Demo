/*
 * Cognizant PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Cognizant Technology Solutions. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.SCoTSSearchCriteriaVO;
import com.dnb.dsc.refdata.dao.SCoTsStagingDAO;


/**
 * This test class is used as the DAO implementation class for the SCoTs
 * operations. The DAO contacts the staging DB for all its operations
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-dao-test.xml" })
public class SCoTsStagingDAOTest {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SCoTsStagingDAOTest.class);

	@Autowired
	private SCoTsStagingDAO stagingDAO;
	
	 /**
	 * The test method to search code table based on any searc criteria
	 */
	@Test
	public void testSearchCodeTables() {
		LOGGER.debug("entering SCoTsStagingDAOTest || testSearchCodeTables");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setTableDescription("language");

		List<CodeTable> searchCodeTables=stagingDAO.searchCodeTables(searchCriteriaVO);

		Assert.assertEquals(1, searchCodeTables.size());
	}
	
	/**
	 * The test method to count the number of search results
	 */
	@Test
	public void testCountSearchCodeTables() {
		LOGGER.debug("entering SCoTSServiceTest || testCountSearchCodeTables");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setTableDescription("language");

		Long countSearchCodeTables=stagingDAO.countSearchCodeTables(searchCriteriaVO);

		Assert.assertEquals(2, countSearchCodeTables.longValue());
	}
	

	/**
	 * The test method to retrieve list of all code tables
	 */
	@Test
	public void testRetrieveCodeTableList() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeTableList");
		List<CodeValueVO> retrieveCodeTableList=stagingDAO.retrieveCodeTableList();
		Assert.assertEquals(633, retrieveCodeTableList.size());
	}


	/**
	 * The test method to retrieve Code languages
	 */
	@Test
	public void testRetrieveCodeLanguages() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeLanguages");
		List<CodeValueVO> retrieveCodeLanguages=stagingDAO.retrieveCodeLanguages();
		Assert.assertEquals(7, retrieveCodeLanguages.size());
	}
	
	/**
	 * The test method to retrieve system applicability for a code table
	 */
	@Test
	public void testRetrieveSystemApplicability() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveSystemApplicability");
		List<SystemApplicability> retrieveSystemApplicability=stagingDAO.retrieveSystemApplicability(3L,1);
		Assert.assertEquals(1, retrieveSystemApplicability.size());
	}
	
	/**
	 * The test method to retrieve all system applicabilities
	 */
	@Test
	public void testRetrieveAllSystemApplicability() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveAllSystemApplicability");
		List<CodeValueVO> retrieveAllSystemApplicability=stagingDAO.retrieveAllSystemApplicability("System");
		Assert.assertEquals(59, retrieveAllSystemApplicability.size());
	}


	/**
	 * The test method to retrieve country applicability
	 */
	@Test
	public void testRetrieveCountryApplicability() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCountryApplicability");
		List<CountryApplicability> retrieveCountryApplicability =stagingDAO.retrieveCountryApplicability(3L,1);
		Assert.assertEquals(2, retrieveCountryApplicability.size());
	}
	

	/**
	 * The test method to retrieve code table by id
	 */
	@Test
	public void testRetrieveCodeTableById() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeTableById");
		CodeTable retrieveCodeTableById=stagingDAO.retrieveCodeTableById(3L);
		Assert.assertEquals(3, retrieveCodeTableById.getCodeTableId().longValue());
	}
	
	/**
	 * The test method to retrieve code values by table id
	 */
	@Test
	public void testRetrieveCodeValuesByTableId(){
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeValuesByTableId");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setTableDescription("3");
		List<CodeValue> retrieveCodeValuesByTableId=stagingDAO.retrieveCodeValuesByTableId(searchCriteriaVO);
		Assert.assertEquals(10, retrieveCodeValuesByTableId.size());

	}
	
	/**
	 * The test method to count results of retrieving code value by table id
	 */
	@Test
	public void testCountCodeValuesByTableId() {
		LOGGER.debug("entering SCoTSServiceTest || testCountCodeValuesByTableId");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setTableDescription("3");

		Long countCodeValuesByTableId=stagingDAO.countCodeValuesByTableId(searchCriteriaVO);
		Assert.assertEquals(559, countCodeValuesByTableId.longValue());
	}
	
	/**
	 * The test method to search code values
	 */
	@Test
	public void testSearchCodeValues() {
		LOGGER.debug("entering SCoTSServiceTest || testSearchCodeValues");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setCodeValueDescription("English");
		List<CodeValue> searchCodeValues=stagingDAO.searchCodeValues(searchCriteriaVO);
		Assert.assertEquals(10, searchCodeValues.size());
	}
	
	

	/**
	 * The test method to count results of search code values
	 */
	@Test
	public void testCountOfSearchCodeValues() {
		LOGGER.debug("entering SCoTSServiceTest || testCountOfSearchCodeValues");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setCodeValueDescription("English");
		Long searchCodeValues=stagingDAO.countOfSearchCodeValues(searchCriteriaVO);
		Assert.assertEquals(21, searchCodeValues.longValue());

	}
	
	/**
	 * The test method to retrieve code value by code value id
	 * @throws Exception 
	 */
	@Test
	public void testRetrieveCodeValueByCodeValueId() throws Exception {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeValueByCodeValueId");
		Long codeValueId = 39L;
		CodeValue codeValue = stagingDAO.retrieveCodeValueByCodeValueId(codeValueId);
		Assert.assertEquals(39,codeValue.getCodeValueId().longValue());
	}

	/**
	 * The test method to retrieve code value associations with a parent and child code table
	 */
	@Test
	public void testRetrieveCodeValueAssociations(){
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeValueAssociations");
		List<CodeValueAssociation> retrieveCodeValueAssociations=stagingDAO.retrieveCodeValueAssociations(2L,9L, true);
		Assert.assertEquals(0,retrieveCodeValueAssociations.size());
	}

	/**
	 * The test method to retrieve all alternate scheme codes
	 */
	@Test
	public void testRetrieveAllAlternateSchemeCodes () {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveAllAlternateSchemeCodes");
		List<CodeValueVO> retrieveAllAlternateSchemeCodes=stagingDAO.retrieveAllAlternateSchemeCodes();
		Assert.assertEquals(8,retrieveAllAlternateSchemeCodes.size());
	}
	
	/**
	 * The test method to retrieve alternate scheme codes
	 */
	@Test
	public void testRetrieveAlternateSchemeCodes() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveAlternateSchemeCodes");
		List<CodeValueAlternateScheme> retrieveAlternateSchemeCodes =stagingDAO.retrieveAlternateSchemeCodes(23404L);
		Assert.assertEquals(196, retrieveAlternateSchemeCodes.size());

	}

}
