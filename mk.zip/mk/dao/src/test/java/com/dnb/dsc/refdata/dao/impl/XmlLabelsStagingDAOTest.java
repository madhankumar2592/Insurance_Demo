/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.vo.XmlSchemaSearchVO;
import com.dnb.dsc.refdata.dao.XmlLabelsStagingDAO;

/**
 * TODO
 * 
 * @author Cognizant
 * @version last updated : Apr 20, 2012
 * @see
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-dao-test.xml" })
public class XmlLabelsStagingDAOTest {

    /**
     * The instance variable for Logging
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(XmlLabelsStagingDAOTest.class);

    @Autowired
    private XmlLabelsStagingDAO xmlLabelsStagingDAO;

    /**
     * The test method will search for the xml elements by the input criteria.The user pass the input criteria to dao
     * and dao will return the corresponding xml element details
     * 
     */
    @Test
    public void testSearchXmLSchemaLabels() {
        LOGGER.info("entering XmlLabelsStagingDAOTest | testSearchXmLSchemaLabels");
        XmlSchemaSearchVO xmlSchemaSearchVO = new XmlSchemaSearchVO();
        xmlSchemaSearchVO.setElementName("Actual");
        xmlSchemaSearchVO.setElementDescription("Actual");
        xmlSchemaSearchVO.setSortBy("xmlSchemaElementId");
        xmlSchemaSearchVO.setSortOrder("asc");
        xmlSchemaSearchVO.setStartIndex(0);
        xmlSchemaSearchVO.setMaxResults(10);

        List<XmlSchemaElement> xmlElement = xmlLabelsStagingDAO.searchXmLSchemaLabels(xmlSchemaSearchVO);
        Assert.assertEquals(10, xmlElement.size());
        LOGGER.info("exiting XmlLabelsStagingDAOTest | testSearchXmLSchemaLabels");
    }

    /**
     * The test method will search for the xml elements by xml element id.The user pass the xml element id to dao and
     * dao will return the corresponding xml element details
     * 
     */
    @Test
    public void testRetrieveXmlSchemaByXmlElementId() {
        XmlSchemaElement xmlSchemaElement = xmlLabelsStagingDAO.retrieveXmlSchemaByXmlElementId("Element_Common_1588");
        Assert.assertEquals("Element_Common_1588", xmlSchemaElement.getXmlSchemaElementId());
    }

}
