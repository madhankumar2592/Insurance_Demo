/*
 * Cognizant PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Cognizant Technology Solutions. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.dao.GeoStagingDAO;

/**
 * This test class is used as the DAO implementation class for the Geography
 * operations. The DAO contacts the staging DB for all its operations
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-dao-test.xml" })
public class GeoStagingDAOTest {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GeoStagingDAOTest.class);

	@Autowired
	private GeoStagingDAO stagingDAO;

	/**
	 * The method will search for the geo units by name. The user will type in
	 * the filter condition in the name field and the dao layer will retrieve
	 * the names satisfying the filter
	 */
	@Test
	public void testSearchGeoUnitByName() {
		LOGGER.info("entering GeoStagingDAOTest | testSearchGeoUnitByName");
		String nameFilter = "Canada";
		Long langaugeCode = RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH;
		List<GeoUnitName> geoUnitNames = stagingDAO.searchGeoUnitByName(
				nameFilter, 0, 10, "", "", langaugeCode);
		Assert.assertEquals(10, geoUnitNames.size());
	}

	/**
	 * The method will search for the number of geo units by name. The user will
	 * type in the filter condition in the name field and the dao layer will
	 * retrieve the names satisfying the filter
	 */
	@Test
	public void testCountSearchGeoUnitByName() {
		LOGGER.info("entering GeoStagingDAOTest | testCountSearchGeoUnitByName");
		String nameFilter = "Canada";
		Long count = stagingDAO.countSearchGeoUnitByName(nameFilter);
		Assert.assertEquals(104, count.longValue());
	}

	/**
	 * The method will search for the geo units by code. The user will type in
	 * the filter condition in the code field and the dao layer will retrieve
	 * the codes satisfying the filter
	 */
	@Test
	public void testSearchGeoUnitByCode() {

		LOGGER.info("entering GeoStagingDAOTest | testSearchGeoUnitByName");
		String codeFilter = "CA";
		Long langaugeCode = RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH;
		List<GeoUnitCode> geoUnitCodes = stagingDAO.searchGeoUnitByCode(
				codeFilter, 0, 10, "", "", langaugeCode);
		Assert.assertEquals(4, geoUnitCodes.size());
	}

	/**
	 * The method will search for the number of geo units by code. The user will
	 * type in the filter condition in the code field and the dao layer will
	 * retrieve the codes satisfying the filter
	 */
	@Test
	public void testCountSearchGeoUnitByCode() {

		LOGGER.info("entering GeoStagingDAOTest | testCountSearchGeoUnitByCode");
		String codeFilter = "CA";
		Long count = stagingDAO.countSearchGeoUnitByCode(codeFilter);
		Assert.assertEquals(4, count.longValue());
	}

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 */
	@Test
	public void testRetrieveGeoUnitByGeoUnitId() {

		LOGGER.info("entering GeoStagingDAOTest | testRetrieveGeoUnitByGeoUnitId");
		Long geoUnitId = 999191774L;
		GeoUnit geoUnit = stagingDAO.retrieveGeoUnitByGeoUnitId(geoUnitId);

		Assert.assertEquals((Long) 999191774L, geoUnit.getGeoUnitId());
		Assert.assertEquals((Long) 126L, geoUnit.getGeoUnitTypeCode());
	}

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 * 
	 * @param geoUnitId
	 */
	@Test
	public void testRetrieveGeoUnitForDelete() {
		LOGGER.info("entering GeoStagingDAOTest | testRetrieveGeoUnitForDelete");
		Long geoUnitId = 999192465L;
		GeoUnit geoUnit = stagingDAO.retrieveGeoUnitForDelete(geoUnitId);
		Assert.assertEquals(999192465L, geoUnit.getGeoUnitId().longValue());
	}

	/**
	 * Validates geoUnit to check for the existence of any child records for the
	 * corresponding geoUnit.
	 * <p>
	 * The soft delete operation on geoUnit will be dependent on the validation.
	 * <p>
	 * 
	 * @param geoUnitId
	 * @return the count of child geo unit associations
	 */
	@Test
	public void testValidateGeoUnit() {
		LOGGER.info("entering GeoStagingDAOTest | testValidateGeoUnit");
		Long geoUnitId = 999192465L;
		Long result = stagingDAO.validateGeoUnit(geoUnitId);
		Assert.assertEquals(1L, result.longValue());
	}

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@Test
	public void testRetrieveAllCountries() {
		LOGGER.info("entering GeoStagingDAOTest | testRetrieveAllCountries");
		List<CodeValueVO> retrieveAllCountries = stagingDAO
				.retrieveAllCountries(32L, 39L);
		Assert.assertEquals(242, retrieveAllCountries.size());
	}

	/**
	 * The method will retrieve all Continent details from the Search DB based
	 * on the name type code and the user preferred language code. The return
	 * type is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@Test
	public void testRetrieveAllContinents() {
		LOGGER.info("entering GeoStagingDAOTest | testRetrieveAllContinents");
		List<CodeValueVO> retrieveAllContinents = stagingDAO
				.retrieveAllContinents(32L, 39L);
		Assert.assertEquals(2, retrieveAllContinents.size());
	}

	/**
	 * The method will retrieve the Geo Units corresponding to the
	 * parentGeoUnit, geoUnitType, nameType and languageCode which you want to
	 * retrieve the data. The retrieval is from the Search DB. The return type
	 * is a VO which contains the Geo Unit Id and the Geo Unit name.
	 * 
	 * @param languageCode
	 * @param geoUnitType
	 * @param parentGeoUnitId
	 * @param nameType
	 */
	@Test
	public void testRetrieveChildGeoUnitsByType() {
		LOGGER.info("entering GeoStagingDAOTest | retrieveChildGeoUnitsByType");
		List<CodeValueVO> retrieveChildGeoUnitsByType = stagingDAO
				.retrieveChildGeoUnitsByType(39L, 324L, 139326L, 32L);
		Assert.assertEquals(0, retrieveChildGeoUnitsByType.size());

	}

	/**
	 * This method will update given GeoUnit to Staging SoR DB. The return would
	 * be updated GeoUnit entity. The method is invoked when the business owner
	 * approves a request and the respective changes are to be updated from the
	 * Transaction DB to the Staging SoR.
	 * 
	 * @param GeoUnit
	 * @return status
	 */
	@Test
	public void testUpdateGeoUnit() {
		LOGGER.info("entering GeoStagingDAOTest | updateGeoUnit");
		Long geoUnitId = 999191774L;
		GeoUnit geoUnit = stagingDAO.retrieveGeoUnitByGeoUnitId(geoUnitId);
		
		Boolean result =stagingDAO.updateGeoUnit(geoUnit);
		Assert.assertEquals(true,result.booleanValue());
	}
	
	/**
	 * 
	 * The method will identify all child entities for the specified GeoUnit Id
	 * 
	 * @param geoUnitId
	 * @return
	 */
	@Test
	public void testRetrieveChildGeoUnitAssociations() {
		LOGGER.info("entering GeoStagingDAOTest | retrieveChildGeoUnitAssociations");
		Long geoUnitId = 999191774L;
		List<GeoUnitAssociation> retrieveChildGeoUnitAssociations=stagingDAO.retrieveChildGeoUnitAssociations(geoUnitId);
		Assert.assertEquals(1,retrieveChildGeoUnitAssociations.size());
		}
	

	/**
	 * The method will retrieve all Country Groups from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Group Geo Unit Id and the Country
	 * Names.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@Test
	public void testRetrieveAllCountryGroups(){
		LOGGER.info("entering GeoStagingDAOTest | testRetrieveAllCountryGroups");
		Long nameType=32L;
		Long languageCode=39L;
		List<CodeValueVO> retrieveAllCountryGroups=stagingDAO.retrieveAllCountryGroups(nameType,languageCode);
		Assert.assertEquals(23,retrieveAllCountryGroups.size());
	}
	

	/**
	 * Retrieves the country groups corresponds to a group id / all the country
	 * groups.
	 * <p>
	 * The resulted List of Geo unit names will be used for displaying in the
	 * Country Group search results page.
	 * <p>
	 * 
	 * @param langCode
	 * @param writingScriptCode
	 * @param nameTypeCode
	 * @param geoUnitId
	 * @return a List of GeoUnitName
	 */
	@Test
	public void testRetrieveCountryGroups() {
		LOGGER.info("entering GeoStagingDAOTest | testRetrieveCountryGroups");
		Long langCode=39L;
		Long writingScriptCode=RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN;
		Long nameTypeCode=324L;
		Long geoUnitId=9994229034L;
		List<GeoUnitName> retrieveCountryGroups=stagingDAO.retrieveCountryGroups(langCode,writingScriptCode,nameTypeCode,geoUnitId);
		Assert.assertEquals(0,retrieveCountryGroups.size());
	}
		
	/**
	 * 
	 * The method will retrieve official name  by the geoUnitId and type code passed.
	 * 
	 * @param geoUnitId,geoUnitTypeCode
	 */
	@Test
	public void testGetOfficialNameByGeoUnitIdAndTypeCode() {
		String getOfficialNameByGeoUnitIdAndTypeCode=stagingDAO.getOfficialNameByGeoUnitIdAndTypeCode(9994051903L, 9994187206L, 126L);
		Assert.assertEquals("s Ust-Rakhmanovka",getOfficialNameByGeoUnitIdAndTypeCode);
	}
	

	/**
	 * 
	 * The method will retrieve official name  by the geoUnitId and type code passed.
	 * 
	 * @param geoUnitId,geoUnitTypeCode
	 */
	@Test
	public void testRetrieveGeoUnitsByIdList() {
		
		List<Long> geoUnitIds= new ArrayList<Long>();
		geoUnitIds.add(9994051903L);
		geoUnitIds.add(139326L);
		
		List<GeoUnit> retrieveGeoUnitsByIdList=stagingDAO.retrieveGeoUnitsByIdList(geoUnitIds);
		Assert.assertEquals(11,retrieveGeoUnitsByIdList.size());
	}
}
