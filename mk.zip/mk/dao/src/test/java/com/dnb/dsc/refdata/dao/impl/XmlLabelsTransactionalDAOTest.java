/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.Date;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.dao.XmlLabelsTransactionalDAO;

/**
 * This test class is used as the DAO implementation class for the Xml
 * operations. The DAO contacts the staging DB for all its operations
 *
 * @author Cognizant
 * @version last updated :July 20, 2012
 * @see
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-dao-test.xml" })

public class XmlLabelsTransactionalDAOTest {

	/**
     * The instance variable for Logging
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(XmlLabelsTransactionalDAOTest.class);
    
	 @Autowired
	 private XmlLabelsTransactionalDAO xmlLabeltxnDAO;
	 
	 @Test
	 @Rollback(value=true)
	 public void testUpdateXmlSchema() {
		  LOGGER.info("entering XmlLabelsStagingDAOTest | testUpdateXmlSchema");
		  XmlSchemaElement xmlSchemaElement = new XmlSchemaElement();
		  xmlSchemaElement.setCreatedDate(new Date());
		  xmlSchemaElement.setModifiedDate(new Date());
		  xmlSchemaElement.setCreatedUser("DNB");
		  xmlSchemaElement.setModifiedUser("DNB");
		  xmlSchemaElement.setDataElementDescription("Description");
		  xmlSchemaElement.setDataElementName("desc");
		  xmlSchemaElement.setXmlSchemaElementId("XML_ELEMENT");
		  xmlSchemaElement.setXmlSchemaRecordTypeCd("type");
		  XmlSchemaElement xmlSchemaElementReceiever = xmlLabeltxnDAO.updateXmlSchemaElement(xmlSchemaElement);
		  Assert.assertEquals(xmlSchemaElementReceiever.getXmlSchemaElementId(),xmlSchemaElement.getXmlSchemaElementId());
	 }
	 
	 /**
	  * The test method to test count xmlSchemaElement in txn DB
	  */
    @Test
    public void testCountXmlSchema(){
    	 LOGGER.info("entering XmlSchemaLabelServiceTest | testCountXmlSchema");
    	 int count = xmlLabeltxnDAO.countXmlSchema("Element");
    	Assert.assertNotNull(count);
    }

    /**
     *  The test method to test retrieve xmlSchemaElement in txn DB
     */
    @Test
    @Rollback(value=true)
    public void testRetrieveXmlSchema(){
    	 LOGGER.info("entering XmlSchemaLabelServiceTest | testRetrieveXmlSchema");
    	XmlSchemaElement retrieveXmlSchemaByXmlElementId = xmlLabeltxnDAO.retrieveXmlSchemaByXmlElementId("Element");
    	Assert.assertNull(retrieveXmlSchemaByXmlElementId);
    }
    
   /**
    *  The test method to test remove xmlSchemaElement from txn DB
    */
   @Test
   @Transactional("txnTransactionManager")
   @Rollback(value=true)
   public void testRemoveXmlSchema(){
   	 LOGGER.info("entering XmlSchemaLabelServiceTest | testRemoveXmlSchema");
   	xmlLabeltxnDAO.removeApprovedXmlSchemaLabels("Element");
   }
}
