/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */

package com.dnb.dsc.refdata.dao.impl;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.dao.IndsTransactionalDAO;



/**
 * This test class is used as the test class for DAO implementation class for
 * the Industry Code operations. The DAO contacts the Transaction DB for all its
 * operations
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-dao-test.xml" })
public class IndsCodeTransactionalDAOTest {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(IndsCodeTransactionalDAOTest.class);

	@Autowired
	private IndsTransactionalDAO transactionalDAO;

	/**
	 * The method will test if the existing IndustryCode data is being persisted
	 * in the Transactional DB
	 */
	@Test
	public void testUpdateIndustryCode() {
		LOGGER.info("entering IndsCodeTransactionalDAOTest | testUpdateIndustryCode");
		IndustryCode industryCodeResult = transactionalDAO
				.retrieveIndustryCodeByIndustryCodeId(50151307L);
		IndustryCode result = transactionalDAO
				.updateIndustryCode(industryCodeResult);
		Assert.assertEquals(50151307L,result.getIndustryCodeId().longValue());
	}
	
	/**
	 * 
	 * The method will count the records in the hierarchy search of industry
	 * codes on the search db. The search will be done on the flat db based on
	 * the search criteria the user had provided.
	 */
	@Test
	public void testCountIndustryCode(){
		LOGGER.info("entering IndsCodeTransactionalDAOTest | testUpdateIndustryCode");
		String result=transactionalDAO.countIndustryCode(50007861L);
		Assert.assertEquals(null,result);
	}
	
	/**
	 * 
	 * The method will return the max value for the next geo unit id
	 *
	 * @return geoUnitId
	 */
	@Test
	public void testRetrieveMaxIndustryCodeId(){
		Long maxIndustryCodeId=transactionalDAO.retrieveMaxIndustryCodeId();
		Assert.assertNotNull(maxIndustryCodeId);
	}
	
	/**
	 * This test method will search the Staging SoR for the IndustryCode based
	 * on the IndustryCodeId and will return the IndustryCode entity.
	 */
	@Test
	public void testRetrieveIndustryCodeByIndustryCodeId() {
		LOGGER.info("entering IndustryCodesServiceTest | testRetrieveIndustryCodeByIndustryCodeId");

		Long industryCodeId = 50007861L;
		IndustryCode industryCodeResult = transactionalDAO
				.retrieveIndustryCodeByIndustryCodeId(industryCodeId);
		Assert.assertEquals("0131", industryCodeResult.getIndustryCode());
	}
	
	/**
	 * This test tries to remove an existing entry from the Transaction DB.
	 * currencyExchangeId is used to determine which entry is to be removed.
	 */
	@Test
	@Transactional("txnTransactionManager")
	@Rollback(value = true)
	public void testRemoveApprovedIndustryCode() {
		LOGGER.info("entering CurrencyServiceTest | testSaveApprovedCurrencyExchanges");

		Long industryCodeId = 3529L;
		transactionalDAO.removeApprovedIndustryCode(industryCodeId);
	}
}
