package com.dnb.dsc.refdata.dao.impl;

import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.entity.GeoDefaultConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoHierarchy;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.entity.GeographySearch;
import com.dnb.dsc.refdata.core.entity.UserGroupMapping;
import com.dnb.dsc.refdata.core.vo.GeoSearchCriteriaVO;
import com.dnb.dsc.refdata.dao.GeoStagingDAO;
import com.dnb.dsc.refdata.dao.GeoTransactionalDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-dao-test.xml" })
public class GeoTransactionalDAOTest {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GeoTransactionalDAOTest.class);

	@Autowired
	private GeoStagingDAO stagingDAO;

	@Autowired
	private GeoTransactionalDAO transactionalDAO;

	/**
	 * The method will persist the existing Geo Unit data in the Transactional
	 * DB.
	 */
	@Test
	@Rollback(value = true)
	public void testUpdateGeoUnit() {
		LOGGER.info("entering GeoTransactionalDAOTest | testUpdateGeoUnit");
		GeoUnit geoUnit = stagingDAO.retrieveGeoUnitByGeoUnitId(100009948L);
		GeoUnit geoUnitResult = transactionalDAO.updateGeoUnit(geoUnit);
		Assert.assertNotNull(geoUnitResult);
	}

	/**
	 * The method will delete the existing Geo Unit data from the Transactional
	 * DB.
	 */
	@Test
	@Rollback(value = true)
	public void testDeleteGeoUnit() {
		LOGGER.info("entering GeoTransactionalDAOTest | testDeleteGeoUnit");
		GeoUnit geoUnit = stagingDAO.retrieveGeoUnitByGeoUnitId(100009948L);
		Boolean result = transactionalDAO.deleteGeoUnit(geoUnit);
		Assert.assertEquals(true, result.booleanValue());
	}

	/**
	 * The method will validate the Geo Unit for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param geoUnitId
	 */
	@Test
	public void testCountGeoUnit() {
		LOGGER.info("entering GeoTransactionalDAOTest | testCountGeoUnit");
		String result = transactionalDAO.countGeoUnit(100009948L);
		Assert.assertEquals(null, result);
	}

	/**
	 * The method will retrieve the Geo Unit based on the Workflow Tracking Id.
	 * This method will be invoked from the Workflow Component and the search
	 * will be performed on the Transactional DB.
	 * 
	 * @param trackingId
	 * @param geoUnit
	 */
	@Test
	public void testRetreiveGeoUnitByTrackingId() {
		LOGGER.info("entering GeoTransactionalDAOTest | testRetreiveGeoUnitByTrackingId");
		Long trackingId = 9997232708L;
		GeoUnit retreiveGeoUnitByTrackingId = transactionalDAO
				.retreiveGeoUnitByTrackingId(trackingId);
		Assert.assertEquals(9997232708L, retreiveGeoUnitByTrackingId
				.getGeoUnitId().longValue());
	}

	/**
	 * The method will remove the geo unit data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 * 
	 * @param geoUnitId
	 * @param boolean indicating the status
	 */
	@Test
	@Transactional("txnTransactionManager")
	@Rollback(value = true)
	public void removeApprovedGeoUnit() {
		LOGGER.info("entering GeoTransactionalDAOImpl | removeApprovedGeoUnit");
		Long changeTypeId= (long)101;
		Boolean removeApprovedGeoUnit = transactionalDAO
				.removeApprovedGeoUnit(stagingDAO.retrieveGeoUnitByGeoUnitId(
						100009948L).getGeoUnitId(),changeTypeId);
		
		Assert.assertEquals(true, removeApprovedGeoUnit.booleanValue());
	}

	/**
	 * 
	 * The method will identify all child entities for the specified GeoUnit Id
	 * 
	 * @param geoUnitId
	 * @return
	 */
	@Test
	public void testRetrieveChildGeoUnitAssociations() {
		LOGGER.info("entering GeoStagingDAOTest | retrieveChildGeoUnitAssociations");
		Long geoUnitId = 999191774L;
		List<GeoUnitAssociation> retrieveChildGeoUnitAssociations = transactionalDAO
				.retrieveChildGeoUnitAssociations(geoUnitId);
		Assert.assertEquals(0, retrieveChildGeoUnitAssociations.size());
	}

	/**
	 * 
	 * The method will return the max value for the next geo unit id
	 * 
	 * @return geoUnitId
	 */
	@Test
	public void testRetrieveMaxGeoUnitId() {
		Long maxGeoUnitId = stagingDAO.retrieveMaxGeoUnitId(129L);
		Assert.assertNotNull(maxGeoUnitId);
	}

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 */
	@Test
	public void testRetrieveGeoUnitByGeoUnitId() {

		LOGGER.info("entering GeoStagingDAOTest | testRetrieveGeoUnitByGeoUnitId");
		Long geoUnitId = 9997232708L;
		GeoUnit geoUnit = transactionalDAO
				.retrieveGeoUnitByGeoUnitId(geoUnitId);

		Assert.assertEquals(9997232708L, geoUnit.getGeoUnitId().longValue());
	}

	/**
	 * 
	 * The method will retrieve all geography hierarchies
	 */
	@Test
	public void testRetrieveAllGeoHierarchies() {
		LOGGER.info("entering GeographyServiceTest | testRetrieveAllGeoHierarchies");
		List<GeoHierarchy> heirarchyResults = transactionalDAO
				.retrieveAllGeoHierarchies();
		Assert.assertEquals(280, heirarchyResults.size());
	}

	/**
	 * 
	 * The method will retrieve all geography default configurations
	 * 
	 */
	@Test
	public void testRetrieveAllGeoConfigurations() {
		LOGGER.info("entering GeographyServiceTest | testRetrieveAllGeoConfigurations");
		List<GeoDefaultConfiguration> configuratoinResults = transactionalDAO
				.retrieveAllGeoConfigurations();
		Assert.assertEquals(241, configuratoinResults.size());

	}

	/**
	 * 
	 * The method will retrieve all user group mappings available within
	 * refdata.
	 * 
	 * @return userGroupMappings
	 */
	@Test
	public void testRetrieveAllUserGroupMappings() {
		List<UserGroupMapping> retrieveAllUserGroupMappings = transactionalDAO
				.retrieveAllUserGroupMappings();
		Assert.assertEquals(29, retrieveAllUserGroupMappings.size());
	}

	/**
	 * 
	 * The method will retrieve all Hierarchy by the geoUnitId passed.
	 * 
	 * @param geoUnitId
	 *            ,geoUnitTypeCode
	 */
	@Test
	public void testGetHierarchyByGeoUnitId() {
		List<GeoHierarchy> getHierarchyByGeoUnitId = transactionalDAO
				.getHierarchyByGeoUnitId(9996618751L);

		Assert.assertEquals(0, getHierarchyByGeoUnitId.size());
	}
	
	/**
	 * 
	 * The method will perform a hierarchy search of geo units on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return list of geographies
	 */
	@Test
	public void testSearchGeographies() {
		LOGGER.info("entering GeoStagingDAOTest | testSearchGeographies");

		GeoSearchCriteriaVO geoSearchCriteria = new GeoSearchCriteriaVO();
		geoSearchCriteria.setSortOrder("asc");
		geoSearchCriteria.setSortBy("countryName");
		geoSearchCriteria.setMaxResults(10);
		geoSearchCriteria.setRowIndex(1);
		geoSearchCriteria.setCountryGeoCode("892");
		geoSearchCriteria.setStateGeoCode("999189145");
		geoSearchCriteria.setCountyName("WATERLOO");
		geoSearchCriteria.setPostTownName("KITCHENER");
		List<GeographySearch> searchResults = transactionalDAO
				.searchGeographies(geoSearchCriteria);
		Assert.assertEquals(0, searchResults.size());
	}
	
	/** 
	 * The method will count the number of records returned by the query
	 * 
	 * @param searchCriteriaVO
	 * @return list of geographies
	 */
	@Test
	public void testCountSearchGeographies() {
		LOGGER.info("entering GeoStagingDAOTest | testSearchGeographies");

		GeoSearchCriteriaVO geoSearchCriteria = new GeoSearchCriteriaVO();
		geoSearchCriteria.setSortOrder("asc");
		geoSearchCriteria.setSortBy("countryName");
		geoSearchCriteria.setMaxResults(10);
		geoSearchCriteria.setRowIndex(1);
		geoSearchCriteria.setCountryGeoCode("892");
		geoSearchCriteria.setStateGeoCode("999189145");
		geoSearchCriteria.setCountyName("WATERLOO");
		geoSearchCriteria.setPostTownName("KITCHENER");
		Long searchResults = transactionalDAO
				.countSearchGeographies(geoSearchCriteria);
		Assert.assertEquals(0, searchResults.longValue());
	}
}
