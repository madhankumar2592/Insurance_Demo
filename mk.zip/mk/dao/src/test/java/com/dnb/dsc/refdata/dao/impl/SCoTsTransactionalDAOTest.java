/*
 * Cognizant PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Cognizant Technology Solutions. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
//import com.dnb.dsc.refdata.dao.SCoTsStagingDAO;
import com.dnb.dsc.refdata.dao.SCoTsTransactionalDAO;

/**
 * This test class is used as the DAO implementation class for the SCoTs
 * operations. The DAO contacts the transaction DB for all its operations
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-dao-test.xml" })
public class SCoTsTransactionalDAOTest {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SCoTsTransactionalDAOTest.class);

//	@Autowired
//	private SCoTsStagingDAO stagingDAO;

	@Autowired
	private SCoTsTransactionalDAO transactionalDAO;

	/**
	 * The test method to check update code table functionality
	 */
	@Test
	@Rollback(value=true)
	public void testUpdateCodeTable() {
		LOGGER.debug("entering SCoTSServiceTest || testUpdateCodeTable");
		CodeTable codeTable = new CodeTable();
		codeTable.setBusinessDescription("Test");
		codeTable.setCodeTableId(99999L);
		codeTable.setCodeTableName("Test");
		codeTable.setCreatedDate(new Date());
		codeTable.setCreatedUser("refui");
		codeTable.setModifiedDate(new Date());
		codeTable.setModifiedUser("refui");
		codeTable.setEffectiveDate(new Date());
		codeTable.setOnBehalfOfName("refUi");
		codeTable.setReasonText("Not Avalilable");
		CodeTable codeTableReceiver = transactionalDAO
				.updateCodeTable(codeTable);
		Assert.assertEquals(99999L, codeTableReceiver.getCodeTableId()
				.longValue());
	}
	/**
	 * The test method to check update code value functionality
	 */
	@Test
	@Rollback(value=true)
	public void testUpdateCodeValue() {
		LOGGER.debug("entering SCoTSServiceTest || testUpdateCodeTable");
		CodeValue codeValue = new CodeValue();
		codeValue.setBusinessDescription("Test");
		codeValue.setCodeValueId(99999L);
		codeValue.setCodeTableId(99999);
		codeValue.setCodeTableName("Test");
		codeValue.setCreatedDate(new Date());
		codeValue.setCreatedUser("refui");
		codeValue.setModifiedDate(new Date());
		codeValue.setModifiedUser("refui");
		codeValue.setEffectiveDate(new Date());
		codeValue.setOnBehalfOfName("refUi");
		codeValue.setReasonText("Not Avalilable");
		CodeValue codeValueReceiver = transactionalDAO
				.updateCodeValue(codeValue);
		Assert.assertEquals(99999L, codeValueReceiver.getCodeValueId()
				.longValue());
	}
	/**
	 * The method will persist the existing Applicability data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param codeTable
	 */
	@Test
	@Rollback(value=true)
	public void testUpdateCountryApplicability() {
		CountryApplicability countryApplicability = new CountryApplicability(
				9999999L, 9999L, 0, 0L,	0L, new Date(), new Date(), "DNB", 
				new Date(),	new Date(),	"DNB", "Country");
			CountryApplicability recieveCountryApplicability = transactionalDAO
					.updateCountryApplicability(countryApplicability);
			Assert.assertEquals(9999999L,recieveCountryApplicability.getCtryAppyId().longValue());
	}
	
	/**
	 * The method will persist the existing Applicability data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param codeTable
	 */
	@Test
	@Rollback(value=true)
	public void testUpdateSystemApplicability() {
		SystemApplicability systemApplicability = new SystemApplicability(9999999L,1500L,
				1,99L,9L,new Date(),new Date(),"DNB",new Date(),new Date(),"DNB","Test","TableTest");
			SystemApplicability recieveSystemApplicability = transactionalDAO
					.updateSystemApplicability(systemApplicability);
			Assert.assertNotNull(recieveSystemApplicability.getSysAppyId());
	}
	
	/**
	 * The method will validate the Code Table for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param codeTableId
	 */
	@Test
	public void testCountCodeTable()
	{
		String result=transactionalDAO.countCodeTable(3L);
		Assert.assertEquals(null,result);
	}
	

	/**
	 * The method will validate the Code Value for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param codeTableId
	 */
	@Test
	public void testCountCodeValue()
	{
		String result=transactionalDAO.countCodeValue(39L);
		Assert.assertEquals(null,result);
	}
	/**
	 * The test class to test retrieve max code table id from a sequence 
	 */
	@Test
	public void testRetrieveMaxCodeTableId(){
		Long codeTableId = transactionalDAO.retrieveMaxCodeTableId();
		Assert.assertNotNull(codeTableId);
	}
	/**
	 * The test class to test retrieve max code value id from a sequence 
	 */
	@Test
	public void testRetrieveMaxCodeVauleId(){
		Long codeTableId = transactionalDAO.retrieveMaxCodeValueId();
		Assert.assertNotNull(codeTableId);
	}
	/**
	 * The test class to test retrieve first code table id from a sequence 
	 */
	@Test
	public void testRetrieveFirstCodeTableId(){
		Long codeTableId = transactionalDAO.retrieveFirstCodeTableId();
		Assert.assertNotNull(codeTableId);
	}
	/**
	 * The test method to check update code value functionality
	 */
	@Test
	@Rollback(value=true)
	public void testUpdateCodeValueText() {
		LOGGER.debug("entering SCoTSServiceTest || testUpdateCodeValueText");
		CodeValueText codeValueText = new CodeValueText();
		codeValueText.setCodeValueTextId(99999L);
		codeValueText.setCodeTableName("Test");
		codeValueText.setCreatedDate(new Date());
		codeValueText.setCreatedUser("refui");
		codeValueText.setModifiedDate(new Date());
		codeValueText.setModifiedUser("refui");
		codeValueText.setEffectiveDate(new Date());
		Long codeValueTextReceiver = transactionalDAO
				.updateCodeValueText(codeValueText);
		Assert.assertEquals(99999L, codeValueTextReceiver.longValue());
	}
	/**
	 * The test method to check update code value association functionality
	 */
	@Test
	@Rollback(value=true)
	public void testUpdateCodeValueAssociation() {
		LOGGER.debug("entering SCoTSServiceTest || testUpdateCodeValueAssociation");
		CodeValueAssociation codeValueAssociation = new CodeValueAssociation();
		codeValueAssociation.setParentCodeValueId(99999L);
		codeValueAssociation.setCodeValueAssociationId(123L);
		codeValueAssociation.setChildCodeValueId(99999L);
		codeValueAssociation.setCreatedDate(new Date());
		codeValueAssociation.setCreatedUser("refui");
		codeValueAssociation.setModifiedDate(new Date());
		codeValueAssociation.setModifiedUser("refui");
		codeValueAssociation.setEffectiveDate(new Date());
		CodeValueAssociation codeValueAssociationReceiver = transactionalDAO
				.updateCodeValueAssociation(codeValueAssociation);
		Assert.assertEquals(99999L, codeValueAssociationReceiver.getParentCodeValueId().longValue());
	}
	/**
	 * The test method to check update code value association functionality
	 */
	@Test
	@Rollback(value=true)
	public void testUpdateCodeValueAlternateScheme() {
		LOGGER.debug("entering SCoTSServiceTest || testUpdateCodeValueAlternateScheme");
		CodeValueAlternateScheme codeValueAlternateScheme = new CodeValueAlternateScheme();
		codeValueAlternateScheme.setCodeValueAlternateSchemeId(99999L);
		codeValueAlternateScheme.setCodeValueId(123L);
		codeValueAlternateScheme.setAlternateSchemeTypeCode(22384L);
		codeValueAlternateScheme.setAlternateSchemeCodeValue("11111");
		codeValueAlternateScheme.setAlternateSchemeCodeValueDescription("alternate");
		codeValueAlternateScheme.setCreatedDate(new Date());
		codeValueAlternateScheme.setCreatedUser("refui");
		codeValueAlternateScheme.setModifiedDate(new Date());
		codeValueAlternateScheme.setModifiedUser("refui");
		codeValueAlternateScheme.setEffectiveDate(new Date());
		CodeValueAlternateScheme codeValueAlternateSchemeReceiver = transactionalDAO
				.updateCodeValueAlternateScheme(codeValueAlternateScheme);
		Assert.assertEquals(99999L, codeValueAlternateSchemeReceiver.getCodeValueAlternateSchemeId().longValue());
	}
	/**
	 * The method will validate the AltSchemeTypeCode for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param altSchemeTypeCode
	 */
	@Test
	public void testCountAlternateSchemTypeCode()
	{
		String result=transactionalDAO.countAlternateSchemeTypeCode(23238L);
		Assert.assertEquals(null,result);
	}
    /**
     * Test class for retrieving alternate Scheme Codes
     */
	@Test
	public void testRetrieveAlternateSchemCodes(){
			List<CodeValueAlternateScheme> altSchmList = transactionalDAO.retrieveAlternateSchemeCodes(23238L);
			Assert.assertNotNull(altSchmList);
	}
	/**
     * Test class for retrieving  Txn System Applicability
     */
	@Test
	public void testRetrieveTxnSystemApplicabilities(){
		List<SystemApplicability> retrieveTxnSystemApplicabilities = transactionalDAO.retrieveTxnSystemApplicabilities(23238L);
			Assert.assertNotNull(retrieveTxnSystemApplicabilities);
	}
	/**
     * Test class for retrieving Txn Market Applicability
     */
	@Test
	public void testRetrieveTxnMarketApplicabilities(){
		List<CountryApplicability> retrieveTxnMarketApplicabilities = transactionalDAO.retrieveTxnMarketApplicabilities(23238L);
			Assert.assertNotNull(retrieveTxnMarketApplicabilities);
	}
	
	/**
	 * The method to test remove Approved SystemApplicabilites from transaction DAO
	 */
	@Test
	@Transactional("txnTransactionManager")
	@Rollback(value=true)
	public void testRemoveApprovedSystemApplicabilties(){
		transactionalDAO.removeApprovedSystemApplicabilities(0L);
	}

	/**
	 * The method to test remove Approved CountryApplicabilities from transaction DAO
	 */
	@Test
	@Transactional("txnTransactionManager")
	@Rollback(value=true)
	public void testRemoveApprovedCountryApplicabilties(){
		transactionalDAO.removeApprovedCountryApplicabilities(892L);
	}
	
	/**
	 * The method to test remove Approved CodeValueAlternateScheme from transaction DAO
	 */
	@Test
	@Transactional("txnTransactionManager")
	@Rollback(value=true)
	public void testRemoveApprovedCodeValueAlternateScheme(){
		transactionalDAO.removeApprovedCodeValueAlternateScheme(32L);
	}
	
	/**
	 * The method to test remove Approved CodeRelationship from transaction DAO
	 */
	@Test
	@Transactional("txnTransactionManager")
	@Rollback(value=true)
	public void testRemoveApprovedCodeRelationship(){
		List<Long> associationIds = new ArrayList<Long>();
		associationIds.add(11L);
		associationIds.add(32L);
		transactionalDAO.removeApprovedCodeRelationship(associationIds);
	}
//	/**
//	 * The method to test retrieve CodeTable by id
//	 */
//	@Test
//	public void testRetrieveCodeTableById() {
//		CodeTable codeTable = transactionalDAO.retrieveCodeTableById(0L);
//		Assert.assertNotNull(codeTable);
//	}
	
//	/**
//	 * The method to test retrieve CodeValue by id
//	 */
//	@Test
//	public void testRetrieveCodeValueById() {
//		CodeValue codeValue = transactionalDAO.retrieveCodeValueById(0L);
//		Assert.assertNotNull(codeValue);
//	}
	

	/**
	 * The method to test remove Approved CodeValue from transaction DAO
	 */
	@Test
	@Transactional("txnTransactionManager")
	@Rollback(value=true)
	public void testRemoveApprovedCodeValue(){
		transactionalDAO.removeApprovedCodeValue(32L);
	}
	
	/**
	 * The method to test remove Approved CodeTable from transaction DAO
	 */
	@Test
	@Transactional("txnTransactionManager")
	@Rollback(value=true)
	public void testRemoveApprovedCodeTable(){
		transactionalDAO.removeApprovedCodeTable(32L);
	}
}
