package com.dnb.dsc.refdata.dao.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.dao.CrcyTransactionalDAO;

/**
 * This test class is used as the DAO implementation class for the Geography
 * operations. The DAO contacts the staging DB for all its operations
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-dao-test.xml" })
public class CrcyTransactionalDAOTest {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CrcyTransactionalDAOTest.class);

	@Autowired
	private CrcyTransactionalDAO transactionalDAO;

	/**
	 * The method to test if currency exchange rate data is persisted in the
	 * Transaction DB.
	 */
	@Test
	public void testUpdateExchangeRate() {
		LOGGER.info("entering CrcyTransactionalDAOTest | testUpdateExchangeRate");

		CurrencyExchange currencyExchange = new CurrencyExchange(100176L,
				4550L, 28L, getDateForString("09/01/2007"), 11552L, 0.8765D,
				581L, "DNB", getDateForString("02/23/2012"), "DNB",
				getDateForString("09/01/2007"));

		CurrencyExchange result = transactionalDAO
				.updateExchangeRate(currencyExchange);
		Assert.assertEquals(100176L,result.getCurrencyExchangeId().longValue());
	}
	
	
	/**
	 * The method will validate the Currency Exchange for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param currencyExchangeId
	 */
	@Test
	public void testCountCurrencyExchange()
	{
		String result=transactionalDAO.countCurrencyExchange(126584L);
		Assert.assertEquals(null,result);
	}
	
	
	/**
	 * Retrieves the CurrencyExchange based on the Work-flow Tracking Id.
	 * Invoked from the Work-flow Component and the search will be performed on
	 * the Transactional DB.
	 */
	@Test
	public void testRetrieveCurrencyExchangeByTrackingId() {
		LOGGER.info("entering CurrencyServiceTest | testRetrieveCurrencyExchangeByTrackingId");

		Long trackingId = 124320L;
		CurrencyExchange retrieveCurrencyExchangeByTrackingIdResult = transactionalDAO
				.retrieveCurrencyExchangeByTrackingId(trackingId);
		Assert.assertEquals(124320L, retrieveCurrencyExchangeByTrackingIdResult
				.getCurrencyExchangeId().longValue());
	}
	
	/**
	 * This test tries to remove an existing entry from the Transaction DB.
	 * currencyExchangeId is used to determine which entry is to be removed.
	 */
	@Test
	@Rollback(value = true)
	@Transactional("txnTransactionManager")
	public void testRemoveApprovedCurrencyExchange() {
		LOGGER.info("entering CurrencyServiceTest | testSaveApprovedCurrencyExchanges");

		Long currencyExchangeId = 7L;
		transactionalDAO.removeApprovedCurrencyExchange(currencyExchangeId);
	}
	
	/**
	 * The method will search the Staging SoR for the CurrencyExchange based on
	 * the currencyExchangeId and will return the CurrencyExchange entity
	 */
	@Test
	public void testRetrieveCurrencyExchangeByCurrencyExchangeId() {
		LOGGER.info("entering CurrencyServiceTest | testRetrieveCurrencyExchangeByCurrencyExchangeId");

		Long currencyExchangeId = 126584L;
		CurrencyExchange retrieveCurrencyExchangeByCurrencyExchangeIdResult = transactionalDAO
				.retrieveCurrencyExchangeByCurrencyExchangeId(currencyExchangeId);
		Assert.assertEquals(4522L,
				retrieveCurrencyExchangeByCurrencyExchangeIdResult
						.getFromCurrencyCode().longValue());
	}
	
	/**
	 * method to convert a String object into a Date type object
	 * 
	 * @param inputStr
	 * @return
	 */
	private Date getDateForString(String inputStr) {
		DateFormat formatter = new SimpleDateFormat(
				RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT);
		try {
			return (Date) formatter.parse(inputStr);
		} catch (ParseException e) {
			return null;
		}
	}
}
