/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;


import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.vo.ScotsBulkUploadMasterVO;


/**
* DAO interface class for the Industry Bulk upload Batch operations.
* <p>
* 
* The DAO contacts the staging DB for all its operations.
* <p>
* 
* @author Cognizant
* @version last updated : May 28, 2012
* @see
* 
*/
public interface ScotsBulkUploadDAO {
	/**
	 * 
	 *  The method to save the SCoTS
	 *
	 * @param ScoTSList
	 */
	public void save(List<? extends ScotsBulkUploadMasterVO> scotsBulkUploadList,String userId);
	
	
	
	/**
	 * The method to get code value list
	 * 
	 * 
	 */
	public List<CodeValue> getCodeValueList();
	
	public boolean isSysAppyIdAvail(Long sysAppyId);
	public boolean isCdValIdAvail(Long cdValId);
	public boolean isCdTblIdAvail(Long cdTblId);
	public boolean isCntryIdAvail(Long cntryId);
	public boolean isCntryAppyIdAvail(Long cntryAppyId);
	public List<CodeValue> getCodeValueListForTxt();
	public boolean isCdValTxtIdAvail(Long cdValTxtId);
	public boolean isCdAltSchmIdAvail(Long cdAltSchmId);
	public boolean isCdAltSchmTypCdAvail(Long cdAltSchmTypCd);
	public Long generateCodeValueId();
	public Long getLastSequenceNumber();
	public Long getMaxCodeValueId();
	public Long resetSequence(Long lastSequence,Long maxCodeValueId);

}
