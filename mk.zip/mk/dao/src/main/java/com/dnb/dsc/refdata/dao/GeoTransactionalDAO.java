/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.GeoCodeConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoDefaultConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoHierarchy;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.entity.GeographySearch;
import com.dnb.dsc.refdata.core.entity.UserGroupMapping;
import com.dnb.dsc.refdata.core.vo.GeoSearchCriteriaVO;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;

/**
 * This is used as the DAO interface for the Geography operations
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 *
 */
public interface GeoTransactionalDAO {

	/**
	 * The method will search for the geo unit by geoUnitId. The return would be
	 * the GeoUnit entity
	 *
	 * @param geoUnitId
	 * @return geoUnit the geoUnit entity
	 */
	GeoUnit retrieveGeoUnit(Long geoUnitId);

	/**
	 * This method will update given GeoUnit to Transaction DB. The return would be
	 * updated GeoUnit entity
	 *
	 * @param GeoUnit
	 * @return GeoUnit
	 */
	GeoUnit updateGeoUnit(GeoUnit geoUnit);

	/**
	 * Performs a soft delete on geoUnit in Transactional DB.<p>
	 * The field expectedByDate will be set as current Date.<p>
	 *
	 * @param geoUnitId
	 * @return a Boolean status flag
	 */
	Boolean deleteGeoUnit(GeoUnit geoUnit);

	/**
	 * The method will validate the Geo Unit for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param geoUnitId
	 */
	String countGeoUnit(Long geoUnitId);

	/**
	 * The method will retrieve the Geo Unit based on the Workflow Tracking Id.
	 * This method will be invoked from the Workflow Component and the search
	 * will be performed on the Transaction DB.
	 *
	 * @param trackingId
	 * @param geoUnit
	 */
	GeoUnit retreiveGeoUnitByTrackingId(Long trackingId);

	/**
	 * The method will remove the geo unit data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param geoUnitId
	 * @param boolean indicating the status
	 */
	Boolean removeApprovedGeoUnit(Long geoUnitId,Long changeTypeId);

	/**
	 *
	 * The method will identify all child entities for the specified GeoUnit Id
	 *
	 * @param geoUnitId
	 * @return
	 */
	List<GeoUnitAssociation> retrieveChildGeoUnitAssociations(Long geoUnitId);

	/**
	 *
	 * The method will persist childGeoUnitAssociations
	 *
	 * @param List<GeoUnitAssociation>
	 * @return status
	 */
	Boolean insertGeoUnitAssociations(GeoUnitAssociation childGeoUnitAssociation);

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 *
	 * @param geoUnitId
	 */
	GeoUnit retrieveGeoUnitByGeoUnitId(Long geoUnitId);	

	/**
	 * 
	 * The method will retrieve all geography hierarchies
	 * 
	 * @return geoHierarchies
	 */
	List<GeoHierarchy> retrieveAllGeoHierarchies();
	
	/**
	 * 
	 * The method will retrieve all geography default configurations
	 * 
	 * @return geoDefaultConfigurations
	 */
	List<GeoDefaultConfiguration> retrieveAllGeoConfigurations();
	
	/**
	 * 
	 * The method will retrieve all user group mappings available within refdata.
	 * 
	 * @return userGroupMappings
	 */
	List<UserGroupMapping> retrieveAllUserGroupMappings();
	
	/**
	 * 
	 * TODO
	 *
	 * @param geoUnitId
	 * @return
	 */
	List<GeoHierarchy> getHierarchyByGeoUnitId(Long geoUnitId) ;
	/**
	 * 
	 * The method will perform a hierarchy search of geo units on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return list of geographies
	 */
	List<GeographySearch> searchGeographies(GeoSearchCriteriaVO searchCriteriaVO);

	/**
	 * 
	 * The method will count the records in the hierarchy search of geo units on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return countResults
	 */
	Long countSearchGeographies(GeoSearchCriteriaVO searchCriteriaVO);
	/**
	 * 
	 * The method will retrieve all GeoUnitType based on the GeoUnitId.
	 * 
	 * @return GeoUnitType
	 */
	List<GeoHierarchy> retrieveGeoUnitType(Long geoUnitId);
	/**
	 * This method will update given UiBulkDownload to Transaction DB. The return would be
	 * updated UiBulkDownload entity
	 *
	 * @param UiBulkDownload
	 * @return UiBulkDownload
	 */
    Long addUIBulkDownload(UiBulkDownload uiBulkDownload);
    
	/**
	 * 
	 * The method will retrieve all GeoUnitType based on the GeoUnitId.
	 * 
	 * @return GeoUnitType
	 */
	List<GeoHierarchy> retrieveGeoUnitHierarchies(Long geoUnitId);
	
	/**
	 * 
	 * The method to retrieve the geo unit code configurations
	 *
	 * @param codeTypeCode
	 * @return geoCodeConfigurations
	 */
	List<GeoCodeConfiguration> retrieveGeoUnitCodeConfigurations(Long codeTypeCode);

	/**
	 * 
	 * The method to identify the country for a GeoUnit. This method is
	 * applicable for all newly added GeoUnits. The newly added GeoUnit could be
	 * of any type and the method will return the parent country's geo_unit_id
	 * 
	 * @param geoUnitId
	 * @return countryGeoUnitId
	 */
	Long retrieveCountryGeoUnitId(Long geoUnitId);
}
