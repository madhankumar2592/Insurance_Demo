package com.dnb.dsc.refdata.dao.impl;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.entity.GranularityType;
import com.dnb.dsc.refdata.core.entity.Score;
import com.dnb.dsc.refdata.core.entity.ScoreDetails;
import com.dnb.dsc.refdata.core.entity.ScoreGranularityAssociation;
import com.dnb.dsc.refdata.core.entity.ScoreMap;
import com.dnb.dsc.refdata.core.entity.ScoreMapping;
import com.dnb.dsc.refdata.core.entity.ScoreType;
import com.dnb.dsc.refdata.core.entity.ScoreTypeAssociation;
import com.dnb.dsc.refdata.core.vo.AddNewScoreVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.EditScoreSearchVO;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.core.vo.ScoreSearchVO;
import com.dnb.dsc.refdata.core.vo.ScoreVO;
import com.dnb.dsc.refdata.dao.ScoreStagingDAO;


/**
 * This is used as the DAO implementation class for the Score operations. The
 * DAO contacts the Score tables for all its operations
 *
 * @author Cognizant
 * @version last updated : Aug 21, 2014
 * @see
 *
 */
@Repository("ScoreStagingDAO")
public class ScoreStagingDAOImpl implements ScoreStagingDAO{

	private static final Logger LOGGER = LoggerFactory
	.getLogger(ScoreStagingDAOImpl.class);
	
	@PersistenceContext(unitName = "PU-Staging")
	private EntityManager em;
	
	private JdbcTemplate jdbcTemplate;
	
	
	
/**
	 * The query to retrieve the count of Code Table details based on the filter
	 * condition
	 */
	private static final String QUERY_COUNT_FAILURE_SCORE = "FailureScore.countFailureScoreData";

	
	private static final String QUERY_RETRIEVE_GRANULARITY_FOR_CAPABILITY_TYPE_CODE = "CodeValue.retrieveGranularityForCapabilityTypeCode";
	
	private static final String QUERY_RETRIEVE_COUNT_FOR_SCORE_TYPE_CODE = "ScoreType.retrieveCountForScoreTypeCode";
	
	private static final String QUERY_RETRIEVE_ALL_SCORETYPECODE = "ScoreType.retrieveScoreTypeCode";
	
	private static final String QUERY_RETRIEVE_MARKET_CODE = "ScoreType.retrieveMarketTypeCode";
	
	private static final String QUERY_RETRIEVE_SCORE_VERSION = "Score.retrievescoreVersion";
	
	private static final String QUERY_RETRIEVE_ALL_SCORE_TYPE = "ScoreType.retreiveScoreType";

	private static final String QUERY_RETRIEVE_SRCH_SCR_CODE_VALUES = "ScoreType.findScoreTypeCodeValues";
	
	private static final String QUERY_RETRIEVE_MKT_CODE_VALUES = "ScoreType.retreiveMarketCode";

	private static final String QUERY_RETRIEVE_VERSION_VALUES = "ScoreType.retreiveVersion";

	private static final String QUERY_RETRIEVE_GRANULARITY_VALUES = "ScoreType.retreiveGranularityCodeValues";
	
	private static final String QUERY_RETRIEVE_SRCH_GRU_CODE_VALUES = "ScoreType.findGruTypeCodeValues";
	
	private static final String QUERY_RETRIEVE_GRANULARITY_VALS = "ScoreType.retreiveGranularityValues";

	private static final String QUERY_RETRIEVE_SCORE_DTL_ID = "ScoreDetails.retrieveScoreDetailsId";
	
	private static final String QUERY_RETRIEVE_PROD_SCORE_RESC_GRAN_MAP_ID = "ProdRescScrGru.retreiveProdRescScrGruId";

	private static final String QUERY_RETRIEVE_SCORE_MAP_ID = "ScoreMapping.retreiveScoreMappingById";
	
	private static final String QUERY_RETRIEVE_SCORE_DTL_ID_VAL = "ScoreDetails.retrieveScrDtlId";
	
	private static final String QUERY_RETRIEVE_SCORE_DTL_ID_VALS = "ScoreDetails.retrieveScrDtlsId";
	/**
	 * The setter method for the entity manager. The persistence context has
	 * been defined as part of the entity manager definition.
	 *
	 * @param em
	 */
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}
	
	 /**
     * Inject DataSource properties to jdbcTemplate.
     *
     * @param argDataSource
     *            the new data source
     */
    @Autowired
    @Qualifier("stgDataSource")
    public void setDataSource(DataSource argDataSource) {
        this.jdbcTemplate = new JdbcTemplate(argDataSource);
    }

	
	/**
	 *
	 * The method will create the named query instance by setting the query
	 * parameters. The method is invoked for all name query operations.
	 *
	 * @param sql
	 * @param parameters
	 * @return
	 */
	
	private Query createNamedQuery(String sql, Map<String, Object> parameters) {
		Query query = em.createNamedQuery(sql);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}

	

	
	
	
	
	
	
	
	
	@SuppressWarnings("unchecked")
	@Override
		
	public List<CodeValueVO> retrieveGranularityCodes(String capabilityCode) {
		LOGGER.info("entering ScoreStagingDAOImpl | retrieveGranularityCodes");

		Query query = null;
		
			query = em
				.createNamedQuery(QUERY_RETRIEVE_GRANULARITY_FOR_CAPABILITY_TYPE_CODE);
		
		//query.setParameter("capTypeCode", capabilityCode);
			List<CodeValue> granularityCodes =	query.getResultList();


		LOGGER.info("exiting ScoreStagingDAOImpl | retrieveGranularityCodes");
		try{
			System.out.println("query.getResultList() : --->"+query.getResultList());
		return mapCodeValueVO(granularityCodes);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	private List<CodeValueVO> mapCodeValueVO(List<CodeValue> granularityCodes) {
		LOGGER.info("entering ScoreStagingDAOImpl | mapCodeValueVO");
		List<CodeValueVO> codeValueVOs = null;

		if (granularityCodes != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (CodeValue codeValue : granularityCodes) {
				CodeValueVO codeValueVO = new CodeValueVO(
						codeValue.getCodeValueId(),
						codeValue.getCodeValueDescription());
						
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting ScoreStagingDAOImpl | mapGranularityValueVO");
		return codeValueVOs;
	}
	
	@SuppressWarnings("unchecked")
	public Long checkScoreTypeAvailability(Long ScoreTypeCode) {
		Long count=(long) 0;
		LOGGER.info("entering ScoreStagingDAOImpl | checkScoreTypeAvailability");

		Query query = null;
		
			query = em
				.createNamedQuery(QUERY_RETRIEVE_COUNT_FOR_SCORE_TYPE_CODE);
		
		query.setParameter("scoreTypeCode", ScoreTypeCode);
		
			List<Long> countForScoreTypeCode = query.getResultList();
			if(countForScoreTypeCode!=null) {
				count=countForScoreTypeCode.listIterator().next();
			}

		LOGGER.info("exiting ScoreStagingDAOImpl | checkScoreTypeAvailability");
		try{
			System.out.println("query.getResultList() : --->"+query.getResultList());
		return count;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	
	public Long retrieveMaxScoreTypeId() {
		try {
		return jdbcTemplate.queryForLong("SELECT SORUSR.SCR_TYP_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}


	public Long retrieveMaxGranularityTypeId() {
		try {
		return jdbcTemplate.queryForLong("SELECT SORUSR.SCR_GRU_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	
	public Long retrieveMaxScoreTypeAssnId() {
		try {
		return jdbcTemplate.queryForLong("SELECT SORUSR.SCR_TYP_ASSN_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	
	public Long retrieveMaxScoreGranularityAssnId() {
		try {
		return jdbcTemplate.queryForLong("SELECT SORUSR.SCR_ATTR_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	public Long retrieveMaxScoreGranularityAssnValueId() {
		try {
		return jdbcTemplate.queryForLong("SELECT SORUSR.SCR_GRU_ASSN_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	public ScoreType updateScoreTypeRec(ScoreType scoreType) {
		try {
			return em.merge(scoreType);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}		
	}
	
	public GranularityType updateGranularityTypeRec(GranularityType granularityType) {
		try {
			return em.merge(granularityType);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}		
	}
	
	public ScoreTypeAssociation updateScoreTypeAssnRec(ScoreTypeAssociation scrTypAssn) {
		try {
			return em.merge(scrTypAssn);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}		
	}

	public ScoreGranularityAssociation updateScoreGranuAssnRec(ScoreGranularityAssociation scrGruAssn) {
		try {
			return em.merge(scrGruAssn);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}		
	}
	
	public Long retrieveMaxCount(String query) {
		try {
			return jdbcTemplate.queryForLong(query);
			}catch(NoResultException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				ex.printStackTrace();
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		
	}
	public Long retrieveMax(String query) {
		try {
			return jdbcTemplate.queryForLong(query);
			}catch(NoResultException ex){
				ex.printStackTrace();
				return 0L;
			}catch(PersistenceException ex){
				ex.printStackTrace();
				return 0L;
			}catch(Exception ex){
				ex.printStackTrace();
				return 0L;
			}
		
	}
	@Override
	public String retrieveCodeValueDescription(String queryGruTypDesc) {
		try {
			return jdbcTemplate.queryForObject(queryGruTypDesc, null,  String.class);
			}catch(NoResultException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				ex.printStackTrace();
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
	}

	@Override
	public Score updateNewScoreTypeRec(Score score) {
		try {
			return em.merge(score);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}	
	}

	@Override
	public Long retrieveMaxScoreId() {
		try {
			return jdbcTemplate.queryForLong("SELECT SCR_ID_SEQ.nextval from dual");
			}catch(NoResultException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				ex.printStackTrace();
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
	}

	@Override
	public ScoreType findScoreType(Long scoreTypeId) {
		
		try {
			return em.find( ScoreType.class,  scoreTypeId);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}	
	}

	@Override
	public Score findScore(Long scoreId) {
		try {
			return em.find( Score.class,  scoreId);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
	}

	@Override
	public ScoreTypeAssociation findScoreTypeAssn(Long scoreTypeAssnId) {
		try {
			return em.find( ScoreTypeAssociation.class,  scoreTypeAssnId);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
	}

	@Override
	public GranularityType findGranuType(Long granularityTypeId) {
		try {
			return em.find( GranularityType.class,  granularityTypeId);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllScoreTypeCode() {

		LOGGER.info("entering GeoStagingDAOImpl | retrieveAllCountries");

		Query query = null;
		query = em.createNamedQuery(QUERY_RETRIEVE_ALL_SCORETYPECODE);
		
		List<CodeValueVO> scoreTypeCodes = query.getResultList();
		LOGGER.info("exiting GeoStagingDAOImpl | retrieveAllCountries");
		try{
		return scoreTypeCodes;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveMarketTypeCodes(Long scoreType) {
		LOGGER.info("entering ScoreStagingDAOImpl | retrieveMarketTypeCodes");

		Query query = null;
		
			query = em
				.createNamedQuery(QUERY_RETRIEVE_MARKET_CODE);
		
		query.setParameter("scoreType", scoreType);
			List<GeoUnitName> marketCodes =	query.getResultList();

		LOGGER.info("exiting ScoreStagingDAOImpl | retrieveMarketTypeCodes");
		try{
			System.out.println("query.getResultList() : --->"+query.getResultList());
		return mapCodeValueVOForMarketCode(marketCodes);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	private List<CodeValueVO> mapCodeValueVOForMarketCode(List<GeoUnitName> geoUnitNames) {
		LOGGER.info("entering GeoStagingDAOImpl | mapCodeValueVO");
		List<CodeValueVO> codeValueVOs = null;

		if (geoUnitNames != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (GeoUnitName geoUnitName : geoUnitNames) {
				CodeValueVO codeValueVO = new CodeValueVO(
						geoUnitName.getGeoUnitId(), geoUnitName.getGeoName(),
						null);
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting GeoStagingDAOImpl | mapCodeValueVO");
		return codeValueVOs;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Score> retrievescoreVersions(Long scoreType, Long marketType) {
		LOGGER.info("entering ScoreStagingDAOImpl | retrievescoreVersions");

		Query query = null;
			query = em
				.createNamedQuery(QUERY_RETRIEVE_SCORE_VERSION);
		
		query.setParameter("scoreType", scoreType);
		query.setParameter("marketType", marketType);
			List<Score> scoreVersions =	query.getResultList();

		LOGGER.info("exiting ScoreStagingDAOImpl | retrievescoreVersions");
		try{
			System.out.println("query.getResultList() : --->"+query.getResultList());
		return scoreVersions;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@Override
	public List<AddNewScoreVO> retrieveAttributeDetails(Long scoreType,
			Long marketType, Double scoreVersion) {
		List<AddNewScoreVO> addNewScoreVOs= new ArrayList<AddNewScoreVO>();
		LOGGER.info("entering ScoreStagingDAOImpl | retrieveAttributeDetails");
		
		String subQuery = "SELECT SCR_ID from SCR where SCR_TYP_ID =(SELECT SCR_TYP_ID FROM SCR_TYP where SCR_TYP_CD ="+String.valueOf(scoreType)+") and scr_mkt_cd = "+String.valueOf(marketType)+" and scr_ver = "+String.valueOf(scoreVersion);
		Long scoreId = retrieveScoreGruId(subQuery);
		String mainQuery = "SELECT scrgrnassn.scr_gru_assn_id as granularityTypeAssociationId,case when scrgrnassn.scr_attr_id=1 then 'Minimum' when scrgrnassn.scr_attr_id=2 then 'Maximum' when scrgrnassn.scr_attr_id=3 then (SELECT DISTINCT cdval.cd_val_Desc from cd_val_txt cdval where cdval.expn_dt is null and cdval.cd_val_id in (select scr_gru_cd from scr_gru where scr_gru.scr_gru_id = scrgrnassn.scr_gru_id)  and cdval.lang_cd = 39 and cdval.WRIT_SCRP_CD = 19349) End as granularityLable	FROM scr_gru_assn scrgrnassn where scrgrnassn.scr_gru_id in (select scr_gru_id from scr_typ_assn where scr_typ_assn_id in (select scr_typ_assn_id from scr_dtl where scr_id ="+scoreId+" ))";
		
		List<ScoreGranularityAssociation> attributeLabels =	retrieveGranuDetails(mainQuery);
			for(ScoreGranularityAssociation scrGruAssn : attributeLabels){
				AddNewScoreVO addNewScoreVO = new AddNewScoreVO();
				addNewScoreVO.setScoreId(scoreId);
				addNewScoreVO.setScoreGranuAssnId(scrGruAssn.getGranularityTypeAssociationId());
				addNewScoreVO.setScoreMappingLabel(scrGruAssn.getGranularityLabel());
				addNewScoreVOs.add(addNewScoreVO);
			}

		LOGGER.info("exiting ScoreStagingDAOImpl | retrieveAttributeDetails");
		try{
		return addNewScoreVOs;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	
	public Long retrieveScoreGruId(String subQuery) {
		try {
			return jdbcTemplate.queryForLong(subQuery);
			}catch(NoResultException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				ex.printStackTrace();
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		
	}
	

	/*public List<ScoreGranularityAssociation> retrieveGranuDetails(String mainQuery) {
		try {
			return jdbcTemplate.queryForList(mainQuery, ScoreGranularityAssociation.class);
			}catch(NoResultException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				ex.printStackTrace();
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
	}*/
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<ScoreGranularityAssociation> retrieveGranuDetails(String mainQuery) {
		LOGGER.info("entering ScoreStagingDAOImpl | retrieveGranuDetails");

		StringBuffer queryStr = new StringBuffer(mainQuery);
		List scoreGranularityAssociation = null;
		try{
			scoreGranularityAssociation = jdbcTemplate.query(queryStr.toString(), 
				new RowMapper<ScoreGranularityAssociation>() {

					@Override
					public ScoreGranularityAssociation mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						ScoreGranularityAssociation scoreGranularityAssociation = new ScoreGranularityAssociation();
						scoreGranularityAssociation.setGranularityTypeAssociationId(rs.getLong("granularityTypeAssociationId"));
						scoreGranularityAssociation.setGranularityLabel(rs.getString("granularityLable"));
						return scoreGranularityAssociation;
					}					
				});
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return scoreGranularityAssociation;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Long> retrieveScoreTypeCode() {
		Query query = em.createNamedQuery(QUERY_RETRIEVE_ALL_SCORE_TYPE);
		LOGGER.info("exiting ScoreStagingDAOImpl | retrieveAllScoreType");
		try{
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValue> retrieveScoreTypeCodeValues(
			ScoreVO scoreVO) {
		LOGGER.info("entering ScoreStagingDAOImpl | retrieveScoreTypeCodeValues");
		Query query = em.createNamedQuery(QUERY_RETRIEVE_SRCH_SCR_CODE_VALUES);
		List<CodeValue> codeValues = null;
		try{
			codeValues = query.getResultList();
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveScoreTypeCodeValues");
		return codeValues;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueVO> retrieveMarketCodeValues(ScoreVO scoreVO) {
		LOGGER.info("entering ScoreStagingDAOImpl | retrieveMarketCodeValues");
		/*
		 * Set the parameters
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("scoreTypeCode", scoreVO.getScoreId());		
		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_MKT_CODE_VALUES,parameters);
		/*for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}*/
		
		List<GeoUnitName> geoUnitName = null;
		try{
			geoUnitName = query.getResultList();
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveMarketCodeValues");
		return mapCodeValueVOs(geoUnitName);
	}
	private List<CodeValueVO> mapCodeValueVOs(List<GeoUnitName> geoUnitNames) {
		LOGGER.info("entering ScoreStagingDAOImpl | mapCodeValueVO");
		List<CodeValueVO> codeValueVOs = null;

		if (geoUnitNames != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (GeoUnitName geoUnitName : geoUnitNames) {
				CodeValueVO codeValueVO = new CodeValueVO(
						geoUnitName.getGeoUnitId(), geoUnitName.getGeoName(),
						null);
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting ScoreStagingDAOImpl | mapCodeValueVO");
		return codeValueVOs;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Score> retrieveVersionValues(Score scoreVO) {
		LOGGER.info("entering ScoreStagingDAOImpl | retrieveMarketCodeValues");
		/*
		 * Set the parameters
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("scoreTypeCode", scoreVO.getScoreTypeId());		
		parameters.put("scoreMktCode", scoreVO.getScoreMarketCode());		

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_VERSION_VALUES,parameters);
		/*for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}*/
		
		List<Score> version = null;
		try{
			version = query.getResultList();
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveMarketCodeValues");
		return version;
	}
	@SuppressWarnings("unused")
	private List<Score> mapScoreDtlVO(List<Double> version) {
		LOGGER.info("entering ScoreStagingDAOImpl | mapCodeValueVO");
		List<Score> Scores = null;

		if (version != null) {
			Scores = new ArrayList<Score>();
			for (Double versionValue : version) {
				Score Score = new Score(versionValue);
				Scores.add(Score);
			}
		}
		LOGGER.info("exiting ScoreStagingDAOImpl | mapCodeValueVO");
		return Scores;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValue> retrieveGranularityForScrType(ScoreVO scoreVO) {
		boolean flag = true;
		try{
			if(scoreVO.getIndicator()==null){
				flag = false;
			}
			else if(scoreVO.getIndicator().equalsIgnoreCase("1")){
				flag = true;
			}
		}
		catch(Exception e){
			flag = false;
			e.printStackTrace();
		}
		if(flag){
			List<CodeValue> codeValues = null;
		if(scoreVO.getIndicator().equalsIgnoreCase("1")){
			LOGGER.info("entering ScoreStagingDAOImpl | retrieveGranularityForScrType");
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("scoreTypeCode", scoreVO.getScoreId());		
			parameters.put("scrMktCode", scoreVO.getScoreMarketCode());	
			parameters.put("scrVers", scoreVO.getScoreVersion());	
			Query query = createNamedQuery(QUERY_RETRIEVE_GRANULARITY_VALS,parameters);
					
			
			try{
				codeValues = query.getResultList();
			} catch(PersistenceException ex) {
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			} catch(Exception ex) {
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
			LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveGranularityForScrType");
			
		}
		return codeValues;
		}
		else{
		LOGGER.info("entering ScoreStagingDAOImpl | retrieveGranularityForScrType");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("scoreTypeCode", scoreVO.getScoreId());		

		Query query = createNamedQuery(QUERY_RETRIEVE_GRANULARITY_VALUES,parameters);
				
		List<CodeValue> codeValues = null;
		try{
			codeValues = query.getResultList();
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveGranularityForScrType");
		return codeValues;
		}
		
	}
	@Override
	public Long retreiveIds(String Query) {
		try {
			return jdbcTemplate.queryForLong(Query);
			}catch(NoResultException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				ex.printStackTrace();
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
	}
	@Override
	public ScoreDetails updateScoreDetail(ScoreDetails scoreDtl) {
		try {
			return em.merge(scoreDtl);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

@Override
	public ScoreMapping updateNewScoreMapRec(ScoreMapping granularityMap) {
		try {
			return em.merge(granularityMap);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValue> retrieveGruTypeCodeValues(ScoreVO scoreVO) {
		LOGGER.info("entering ScoreStagingDAOImpl | retrieveGruTypeCodeValues");
		Query query = em.createNamedQuery(QUERY_RETRIEVE_SRCH_GRU_CODE_VALUES);
		List<CodeValue> codeValues = null;
		try{
			codeValues = query.getResultList();
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveGruTypeCodeValues");
		return codeValues;
	}
	
	public Long retrieveMaxScoreMapId() {
		try {
		return jdbcTemplate.queryForLong("SELECT SORUSR.SCR_MAP_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@Override
	public Long countSearchScore(ScoreSearchVO searchCriteriaVO) {
		Query query = null;
		try {
			query = em.createNamedQuery(QUERY_COUNT_FAILURE_SCORE);	
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
		Long serachfail= (Long) query.getSingleResult();
		System.out.println("Result DAOImpl::::"+ serachfail); 
		return serachfail;
	}
	public static <T extends Object> List<List<T>> split(List<T> list, int targetSize) {
	    List<List<T>> lists = new ArrayList<List<T>>();
	    for (int i = 0; i < list.size(); i += targetSize) {
	        lists.add(list.subList(i, Math.min(i + targetSize, list.size())));
	    }
	    return lists;
	}
	@SuppressWarnings("unchecked")
		public List<ScoreSearchVO> scoreSearch(ScoreSearchVO searchCriteriaVO) {
		//Query query = null;
		String mainQuery = "";
		List<ScoreSearchVO> searchResult = new ArrayList<ScoreSearchVO>();
		
		int targetSize = 999;
		String[] mktCd = searchCriteriaVO.getMkt_cd().split(",");
		List<String> mktCdList = new ArrayList<String>( Arrays.asList( mktCd ) );

		List<List<String>> lists = split(mktCdList, targetSize);
		String strMktCd = "";
    	String orVal = "OR";
    	String append = " scr.scr_mkt_cd in (";
    	String end = ") ";
    	for(List<String> lis: lists){
	    	String[] val = lis.toArray(new String[lis.size()]);
	    	String valStr = Arrays.toString(val);
	    	valStr = valStr.replace("[", "").replace("]", "");
	    	if(strMktCd.equalsIgnoreCase("")){
	    		strMktCd = strMktCd + "scr.scr_mkt_cd in ("+valStr+") ";
	    	}
	    	else if(valStr.length()>0)
	    	{
	    	strMktCd = strMktCd + orVal + append +valStr+end;
	    	}
		}
    	
    	//
		String[] scr_typ_cd = searchCriteriaVO.getSr_typ_cd().split(",");
		List<String> scr_typ_cdList = new ArrayList<String>( Arrays.asList( scr_typ_cd ) );

		List<List<String>> lisrts = split(scr_typ_cdList, targetSize);
		String scrtycd = "";
    	String appendScr_typ_cd = " scr_typ_cd in (";
    	for(List<String> lis: lisrts){
	    	String[] val = lis.toArray(new String[lis.size()]);
	    	String valStr = Arrays.toString(val);
	    	valStr = valStr.replace("[", "").replace("]", "");
	    	if(scrtycd.equalsIgnoreCase("")){
	    		scrtycd = scrtycd + "scr_typ_cd in ("+valStr+") ";
	    	}
	    	else if(valStr.length()>0)
	    	{
	    		scrtycd = scrtycd + orVal + appendScr_typ_cd +valStr+end;
	    	}
		}
    	//
    	
    	//
    	String[] scr_gru_cd = null;
    	List<String> scr_gru_cdList = null;
    	String scrgrucd = "";
    	if((searchCriteriaVO.getSr_gru_cd() != null )){
		scr_gru_cd = searchCriteriaVO.getSr_gru_cd().split(",");
		scr_gru_cdList = new ArrayList<String>( Arrays.asList( scr_gru_cd ) );

		List<List<String>> lisrs = split(scr_gru_cdList, targetSize);
		
    	String appendScr_gru_cd = " scr_gru_cd in (";
    	for(List<String> lis: lisrs){
	    	String[] val = lis.toArray(new String[lis.size()]);
	    	String valStr = Arrays.toString(val);
	    	valStr = valStr.replace("[", "").replace("]", "");
	    	if(scrgrucd.equalsIgnoreCase("")){
	    		scrgrucd = scrgrucd + "scr_gru_cd in ("+valStr+") ";
	    	}
	    	else if(valStr.length()>0)
	    	{
	    		scrgrucd = scrgrucd + orVal + appendScr_gru_cd +valStr+end;
	    	}
		}
    	}
    	//
    	
		try {
			if((!(searchCriteriaVO.getSr_gru_cd() != null )) || ((("").equalsIgnoreCase(searchCriteriaVO.getSr_gru_cd())))){
				mainQuery = "SELECT "+
								" GEO_UNIT_ID as scr_mkt_cd_id,GEO_NME as country_name,"+
								" subquery7.scr_typ_cd_id as scr_typ_cd_id,subquery7.scr_typ_cd_shrt_d as scr_typ_cd_shrt_d,subquery7.scr_typ_cd_val_d as scr_typ_cd_val_d,"+
								" subquery7.scr_gru_cd_id as scr_gru_cd_id,subquery7.scr_gru_cd_shrt_d as scr_gru_cd_shrt_d,subquery7.scr_gru_cd_val_d as scr_gru_cd_val_d,subquery7.scr_id as scr_id,subquery7.scr_gru_cd as scr_gru_cd,subquery7.scr_gru_id as scr_gru_id,subquery7.scr_typ_assn_id as scr_typ_assn_id,subquery7.scr_typ_id as scr_typ_id,"+
								" subquery7.scr_mkt_cd as scr_mkt_cd,subquery7.scr_typ_cd as scr_typ_cd,subquery7.scr_vers "+
								" from GEO_UNIT_NME,(SELECT "+
								" CD_VAL_ID as scr_typ_cd_id,CD_VAL_SHRT_DESC as scr_typ_cd_shrt_d,CD_VAL_DESC as scr_typ_cd_val_d,"+
								" subquery6.scr_gru_cd_id,subquery6.scr_gru_cd_shrt_d,subquery6.scr_gru_cd_val_d,subquery6.scr_id as scr_id,subquery6.scr_gru_cd as scr_gru_cd,subquery6.scr_gru_id as scr_gru_id,subquery6.scr_typ_assn_id as scr_typ_assn_id,subquery6.scr_typ_id as scr_typ_id,"+
								" subquery6.scr_mkt_cd as scr_mkt_cd,subquery6.scr_typ_cd as scr_typ_cd,subquery6.scr_vers "+
								" from CD_VAL_TXT,(SELECT CD_VAL_ID as scr_gru_cd_id,CD_VAL_SHRT_DESC as scr_gru_cd_shrt_d,CD_VAL_DESC as scr_gru_cd_val_d,subquery5.scr_id as scr_id,subquery5.scr_gru_cd as scr_gru_cd,subquery5.scr_gru_id as scr_gru_id,subquery5.scr_typ_assn_id as scr_typ_assn_id,subquery5.scr_typ_id as scr_typ_id,"+
								" subquery5.scr_mkt_cd as scr_mkt_cd,subquery5.scr_typ_cd as scr_typ_cd,subquery5.scr_vers from CD_VAL_TXT,(SELECT subquery3.scr_id as scr_id,scr_gru.scr_gru_cd as scr_gru_cd,subquery3.scr_gru_id as scr_gru_id,subquery3.scr_typ_assn_id as scr_typ_assn_id,subquery3.scr_typ_id as scr_typ_id,"+
								" subquery3.scr_mkt_cd as scr_mkt_cd,subquery3.scr_typ_cd as scr_typ_cd,subquery3.scr_vers from scr_gru,(SELECT scr_typ_assn.scr_gru_id as scr_gru_id,subquery2.scr_typ_assn_id as scr_typ_assn_id,subquery2.scr_id as scr_id,subquery2.scr_typ_id as scr_typ_id,"+
								" subquery2.scr_mkt_cd as scr_mkt_cd,subquery2.scr_typ_cd as scr_typ_cd,subquery2.scr_vers  from scr_typ_assn,(SELECT scr_dtl.scr_typ_assn_id as scr_typ_assn_id, subquery1.scr_id as scr_id,subquery1.scr_typ_id as scr_typ_id,"+
								" subquery1.scr_mkt_cd as scr_mkt_cd,subquery1.scr_typ_cd as scr_typ_cd,subquery1.scr_vers"+
								" FROM scr_dtl,"+
								"  (SELECT scr.scr_id,scr.scr_typ_id,scr.scr_mkt_cd,subquery4.scr_typ_cd as scr_typ_cd,scr.scr_ver as scr_vers"+
								" FROM scr,"+
								"  (select scr_typ_id,scr_typ_cd from scr_typ where ("+scrtycd+")"+") subquery4"+
								" WHERE subquery4.scr_typ_id = scr.scr_typ_id and ("+strMktCd+")"+
								" ) subquery1 "+
								" WHERE subquery1.scr_id = scr_dtl.scr_id) subquery2"+
								" WHERE subquery2.scr_typ_assn_id = scr_typ_assn.scr_typ_assn_id) subquery3"+ 
								" WHERE subquery3.scr_gru_id = scr_gru.scr_gru_id) subquery5 "+ 
								" WHERE subquery5.scr_gru_cd = CD_VAL_TXT.CD_VAL_ID  and CD_VAL_TXT.EXPN_DT is null and  CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6"+ 
								" WHERE subquery6.scr_typ_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.EXPN_DT is null and  CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7"+
								" WHERE subquery7.scr_mkt_cd = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32 order by GEO_UNIT_NME.GEO_NME";
				}
			else{
				mainQuery = "SELECT "+
								" GEO_UNIT_ID as scr_mkt_cd_id,GEO_NME as country_name,"+
								" subquery7.scr_typ_cd_id as scr_typ_cd_id,subquery7.scr_typ_cd_shrt_d as scr_typ_cd_shrt_d,subquery7.scr_typ_cd_val_d as scr_typ_cd_val_d,"+
								" subquery7.scr_gru_cd_id as scr_gru_cd_id,subquery7.scr_gru_cd_shrt_d as scr_gru_cd_shrt_d,subquery7.scr_gru_cd_val_d as scr_gru_cd_val_d,subquery7.scr_id as scr_id,subquery7.scr_gru_cd as scr_gru_cd,subquery7.scr_gru_id as scr_gru_id,subquery7.scr_typ_assn_id as scr_typ_assn_id,subquery7.scr_typ_id as scr_typ_id,"+
								" subquery7.scr_mkt_cd as scr_mkt_cd,subquery7.scr_typ_cd as scr_typ_cd,subquery7.scr_vers "+
								" from GEO_UNIT_NME,(SELECT "+
								" CD_VAL_ID as scr_typ_cd_id,CD_VAL_SHRT_DESC as scr_typ_cd_shrt_d,CD_VAL_DESC as scr_typ_cd_val_d,"+
								" subquery6.scr_gru_cd_id,subquery6.scr_gru_cd_shrt_d,subquery6.scr_gru_cd_val_d,subquery6.scr_id as scr_id,subquery6.scr_gru_cd as scr_gru_cd,subquery6.scr_gru_id as scr_gru_id,subquery6.scr_typ_assn_id as scr_typ_assn_id,subquery6.scr_typ_id as scr_typ_id,"+
								" subquery6.scr_mkt_cd as scr_mkt_cd,subquery6.scr_typ_cd as scr_typ_cd,subquery6.scr_vers "+
								" from CD_VAL_TXT,(SELECT CD_VAL_ID as scr_gru_cd_id,CD_VAL_SHRT_DESC as scr_gru_cd_shrt_d,CD_VAL_DESC as scr_gru_cd_val_d,subquery5.scr_id as scr_id,subquery5.scr_gru_cd as scr_gru_cd,subquery5.scr_gru_id as scr_gru_id,subquery5.scr_typ_assn_id as scr_typ_assn_id,subquery5.scr_typ_id as scr_typ_id,"+
								" subquery5.scr_mkt_cd as scr_mkt_cd,subquery5.scr_typ_cd as scr_typ_cd,subquery5.scr_vers from CD_VAL_TXT,(SELECT subquery3.scr_id as scr_id,scr_gru.scr_gru_cd as scr_gru_cd,subquery3.scr_gru_id as scr_gru_id,subquery3.scr_typ_assn_id as scr_typ_assn_id,subquery3.scr_typ_id as scr_typ_id,"+
								" subquery3.scr_mkt_cd as scr_mkt_cd,subquery3.scr_typ_cd as scr_typ_cd,subquery3.scr_vers from scr_gru,(SELECT scr_typ_assn.scr_gru_id as scr_gru_id,subquery2.scr_typ_assn_id as scr_typ_assn_id,subquery2.scr_id as scr_id,subquery2.scr_typ_id as scr_typ_id,"+
								" subquery2.scr_mkt_cd as scr_mkt_cd,subquery2.scr_typ_cd as scr_typ_cd,subquery2.scr_vers  from scr_typ_assn,(SELECT scr_dtl.scr_typ_assn_id as scr_typ_assn_id, subquery1.scr_id as scr_id,subquery1.scr_typ_id as scr_typ_id,"+
								" subquery1.scr_mkt_cd as scr_mkt_cd,subquery1.scr_typ_cd as scr_typ_cd,subquery1.scr_vers"+
								" FROM scr_dtl,"+
								"  (SELECT scr.scr_id,scr.scr_typ_id,scr.scr_mkt_cd,subquery4.scr_typ_cd as scr_typ_cd,scr.scr_ver as scr_vers"+
								" FROM scr,"+
								"  (select scr_typ_id,scr_typ_cd from scr_typ where ("+scrtycd+")"+") subquery4"+
								" WHERE subquery4.scr_typ_id = scr.scr_typ_id and ("+strMktCd+")"+
								" ) subquery1 "+
								" WHERE subquery1.scr_id = scr_dtl.scr_id) subquery2"+
								" WHERE subquery2.scr_typ_assn_id = scr_typ_assn.scr_typ_assn_id and scr_typ_assn.scr_gru_id in (SELECT scr_gru_id from scr_gru where ("+scrgrucd+")"+")) subquery3"+ 
								" WHERE subquery3.scr_gru_id = scr_gru.scr_gru_id) subquery5 "+ 
								" WHERE subquery5.scr_gru_cd = CD_VAL_TXT.CD_VAL_ID  and  CD_VAL_TXT.EXPN_DT is null and  CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6"+ 
								" WHERE subquery6.scr_typ_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.EXPN_DT is null and  CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7"+
								" WHERE subquery7.scr_mkt_cd = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32 order by GEO_UNIT_NME.GEO_NME";
				}
			Query query = formQueryForSearchCrcyExchange(searchCriteriaVO,mainQuery, false);
			// setting the page count and max results for pagination
			if(!(("1").equalsIgnoreCase(searchCriteriaVO.getExportIndc()))){
			query.setMaxResults(searchCriteriaVO.getMaxResults());
			query.setFirstResult(searchCriteriaVO.getRowIndex());
			}
			
			List<Object[]> searchResut =	query.getResultList();
			 for (Object[] result : searchResut) {
				    ScoreSearchVO scoreGranularityAssociation = new ScoreSearchVO();
					scoreGranularityAssociation.setScr_mkt_cd_id(Long.valueOf(result[0].toString()));
					scoreGranularityAssociation.setCountry_name(result[1].toString());
					scoreGranularityAssociation.setScr_typ_cd_id(Long.valueOf(result[2].toString()));
					scoreGranularityAssociation.setScr_typ_cd_shrt_d(result[3].toString());
					scoreGranularityAssociation.setScr_typ_cd_val_d(result[4].toString());
					scoreGranularityAssociation.setScr_gru_cd_id(Long.valueOf(result[5].toString()));
					scoreGranularityAssociation.setScr_gru_cd_shrt_d(result[6].toString());
					scoreGranularityAssociation.setScr_gru_cd_val_d(result[7].toString());
					scoreGranularityAssociation.setScr_id(Long.valueOf(result[8].toString()));
					scoreGranularityAssociation.setScoreGranularity(Long.valueOf(result[9].toString()));
					scoreGranularityAssociation.setScr_gru_id(Long.valueOf(result[10].toString()));
					scoreGranularityAssociation.setScr_typ_assn_id(Long.valueOf(result[11].toString()));
					scoreGranularityAssociation.setScr_typ_id(Long.valueOf(result[12].toString()));
					scoreGranularityAssociation.setMarketCode(Long.valueOf(result[13].toString()));
					scoreGranularityAssociation.setScoreTypeCode(Long.valueOf(result[14].toString()));  
					scoreGranularityAssociation.setScr_vers(Double.valueOf(result[15].toString()));  
					searchResult.add(scoreGranularityAssociation);
			  }
			
		}catch(Exception e){
			e.printStackTrace();
		}		
		return searchResult;
	}
	@SuppressWarnings("unused")
	private Query formQueryForSearchCrcyExchange(
			ScoreSearchVO scoreSearchVO,
			String selectQuery, boolean isCountQuery) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer();
		queryStr.append(selectQuery); 
		
		/*parameters.put("enLangCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);*/

		Query query = em.createNativeQuery(queryStr.toString());
		/*for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		*/
		return query;
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<ScoreSearchVO> retrieveSearchResults(String mainQuery) {
		LOGGER.info("entering ScoreStagingDAOImpl | retrieveGranuDetails");

		StringBuffer queryStr = new StringBuffer(mainQuery);
		List scoreSearchVO = null;
		try{
			scoreSearchVO = jdbcTemplate.query(queryStr.toString(), 
				new RowMapper<ScoreSearchVO>() {

					@Override
					public ScoreSearchVO mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						ScoreSearchVO scoreGranularityAssociation = new ScoreSearchVO();
						scoreGranularityAssociation.setScr_mkt_cd_id(rs.getLong("scr_mkt_cd_id"));
						scoreGranularityAssociation.setCountry_name(rs.getString("country_name"));
						scoreGranularityAssociation.setScr_typ_cd_id(rs.getLong("scr_typ_cd_id"));
						scoreGranularityAssociation.setScr_typ_cd_shrt_d(rs.getString("scr_typ_cd_shrt_d"));
						scoreGranularityAssociation.setScr_typ_cd_val_d(rs.getString("scr_typ_cd_val_d"));
						scoreGranularityAssociation.setScr_gru_cd_id(rs.getLong("scr_gru_cd_id"));
						scoreGranularityAssociation.setScr_gru_cd_shrt_d(rs.getString("scr_gru_cd_shrt_d"));
						scoreGranularityAssociation.setScr_gru_cd_val_d(rs.getString("scr_gru_cd_val_d"));
						scoreGranularityAssociation.setScr_id(rs.getLong("scr_id"));
						scoreGranularityAssociation.setScoreGranularity(rs.getLong("scr_gru_cd"));
						scoreGranularityAssociation.setScr_gru_id(rs.getLong("scr_gru_id"));
						scoreGranularityAssociation.setScr_typ_assn_id(rs.getLong("scr_typ_assn_id"));
						scoreGranularityAssociation.setScr_typ_id(rs.getLong("scr_typ_id"));
						scoreGranularityAssociation.setMarketCode(rs.getLong("scr_mkt_cd"));
						scoreGranularityAssociation.setScoreTypeCode(rs.getLong("scr_typ_cd"));
						return scoreGranularityAssociation;
					}					
				});
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return scoreSearchVO;
	}
	
	@Override
	public ScoreSearchVO editScoreSearch(ScoreSearchVO scoreSearchVO) {
		String mainQuery = "";
		ScoreSearchVO scrSearchVO = new ScoreSearchVO();
		try {
			if((scoreSearchVO.getScr_id() != null)){			
				
				mainQuery = " SELECT CASE WHEN subquery4.SCR_ATTR_ID = 1 then 'Minimum'"+
				" WHEN subquery4.SCR_ATTR_ID = 2 then 'Maximum'"+
				" WHEN subquery4.SCR_ATTR_ID=3 then cd_val_txt.cd_val_Desc"+
				" END as scrGranularityLable,"+
				" subquery4.SCR_GRU_ID,subquery4.SCR_ATTR_ID,subquery4.prnt_scr_id,subquery4.scr_map_id,subquery4.SCR_GRU_ASSN_ID,subquery4.SCR_ATTR_VAL,"+
				" subquery4.scr_id, subquery4.scr_typ_id,subquery4.scr_mkt_cd,subquery4.scr_ver from cd_val_txt,(SELECT SCR_GRU.SCR_GRU_CD as SCR_GRU_ID,subquery3.SCR_ATTR_ID,subquery3.prnt_scr_id,subquery3.scr_map_id,subquery3.SCR_GRU_ASSN_ID,subquery3.SCR_ATTR_VAL,"+
				" subquery3.scr_id, subquery3.scr_typ_id,subquery3.scr_mkt_cd,subquery3.scr_ver from SCR_GRU,(SELECT SCR_GRU_ASSN.SCR_GRU_ID,SCR_GRU_ASSN.SCR_ATTR_ID,subquery2.prnt_scr_id,subquery2.scr_map_id,subquery2.SCR_GRU_ASSN_ID,subquery2.SCR_ATTR_VAL,"+
				" subquery2.scr_id, subquery2.scr_typ_id,subquery2.scr_mkt_cd,subquery2.scr_ver"+
				" from SCR_GRU_ASSN,(SELECT scr_map.prnt_scr_id,scr_map.scr_map_id,scr_map.SCR_GRU_ASSN_ID,scr_map.SCR_ATTR_VAL,"+
				" subquery1.scr_id, subquery1.scr_typ_id,subquery1.scr_mkt_cd,subquery1.scr_ver"+
				" FROM scr_map,"+
				" (SELECT scr_id,scr_typ_id,scr_mkt_cd,scr_ver"+
				" FROM scr where scr_id = "+scoreSearchVO.getScr_id()+") subquery1"+
				" WHERE subquery1.scr_id = scr_map.scr_id)subquery2 "+
				" WHERE subquery2.SCR_GRU_ASSN_ID = SCR_GRU_ASSN.SCR_GRU_ASSN_ID) subquery3"+
				" WHERE subquery3.SCR_GRU_ID = SCR_GRU.SCR_GRU_ID) subquery4"+
				" WHERE subquery4.SCR_GRU_ID = cd_val_txt.cd_val_id   and cd_val_txt.EXPN_DT is null and  cd_val_txt.lang_cd = 39 and cd_val_txt.WRIT_SCRP_CD = 19349";
											
			}
			
			scrSearchVO = retrieveEditSearchResults(mainQuery);
			String codeValueDesc = retrieveScoreTypeCodeValueDesc("SELECT CD_VAL_TXT.CD_VAL_DESC from CD_VAL_TXT WHERE CD_VAL_TXT.EXPN_DT is null and CD_VAL_TXT.CD_VAL_ID = "+scoreSearchVO.getScoreTypeCode()+" and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 order by CD_VAL_TXT.CD_VAL_SHRT_DESC");
			scrSearchVO.setScr_typ_cd_val_d(codeValueDesc);
			String query = "SELECT scrgrnassn.scr_gru_assn_id as granularityTypeAssociationId,case when scrgrnassn.scr_attr_id=1 then 'Minimum' when scrgrnassn.scr_attr_id=2 then 'Maximum' when scrgrnassn.scr_attr_id=3 then (SELECT DISTINCT cdval.cd_val_Desc from cd_val_txt cdval where scrgrnassn.scr_gru_id = cdval.cd_val_id  and   cdval.EXPN_DT is null and cdval.lang_cd = 39 and cdval.WRIT_SCRP_CD = 19349) End as granularityLable	FROM scr_gru_assn scrgrnassn where scrgrnassn.scr_gru_id in (select scr_gru_id from scr_typ_assn where scr_typ_assn_id in (select scr_typ_assn_id from scr_dtl where scr_id = 2 ))";			
			List<ScoreGranularityAssociation> scoreGranularityAssociation =	retrieveGranuDetails(query);
			scrSearchVO.setScoreGranularityAssociation(scoreGranularityAssociation);
			
			Score value = findScr(scoreSearchVO.getScr_id());
			scrSearchVO.setScrVersion(value.getScoreVersion());
			scrSearchVO.setScr_id(value.getScoreId());
			scrSearchVO.setScr_mkt_cd_id(value.getScoreMarketCode());
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return scrSearchVO;	
	}

	private String retrieveScoreTypeCodeValueDesc(String mainQuery) {
		try {
			return jdbcTemplate.queryForObject(mainQuery, String.class);
			}catch(NoResultException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				ex.printStackTrace();
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
	}

	private ScoreSearchVO retrieveEditSearchResults(String mainQuery) {
		LOGGER.info("entering ScoreStagingDAOImpl | retrieveEditSearchResults");

		StringBuffer queryStr = new StringBuffer(mainQuery);
		ScoreSearchVO scrSearchVO = new ScoreSearchVO();
		List<EditScoreSearchVO> editScoreSearchVO = null;
		try{
			editScoreSearchVO = jdbcTemplate.query(queryStr.toString(), 
				new RowMapper<EditScoreSearchVO>() {

					@Override
					public EditScoreSearchVO mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						EditScoreSearchVO edtScoreSearchVO = new EditScoreSearchVO();
						edtScoreSearchVO.setScrGranularityLable(rs.getString("scrGranularityLable"));
						edtScoreSearchVO.setScr_gru_id(rs.getLong("scr_gru_id"));
						edtScoreSearchVO.setScr_attr_id(rs.getLong("scr_attr_id"));	
						edtScoreSearchVO.setPrnt_scr_id(rs.getLong("prnt_scr_id"));	
						edtScoreSearchVO.setScr_map_id(rs.getLong("scr_map_id"));	
						edtScoreSearchVO.setScr_gru_assn_id(rs.getLong("scr_gru_assn_id"));						
						edtScoreSearchVO.setScr_attr_val(rs.getString("scr_attr_val"));						
						edtScoreSearchVO.setScr_id(rs.getLong("scr_id"));
						edtScoreSearchVO.setScr_typ_id(rs.getLong("scr_typ_id"));						
						edtScoreSearchVO.setScr_mkt_cd(rs.getLong("scr_mkt_cd"));						
						edtScoreSearchVO.setScr_ver(rs.getDouble("scr_ver"));
						
						return edtScoreSearchVO;
					}					
				});
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		scrSearchVO.setEditScoreSearchList(editScoreSearchVO);		
		return scrSearchVO;
	}
	
	@Override
	public Score findScr(Long scoreTypeAssnId) {
		try {
			return em.find( Score.class,  scoreTypeAssnId);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
	}
	
	public Score updateScore(Score score) {
		try {
			return em.merge(score);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}		
	}
	public ScoreMap findScrMap(Long score) {
		try {
			return em.find( ScoreMap.class,  score);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}		
	}
	public ScoreMap updateScoreMap(ScoreMap score) {
		try {
			return em.merge(score);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}		
	}
	@Override
	public ScoreDetails findScrDtl(Long scoreDetailsId) {
		try {
			return em.find( ScoreDetails.class,  scoreDetailsId);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Long> retrieveLongList(String query) {
		Query qury = em.createNativeQuery(query);
		List<Long> returnRes = new ArrayList<Long>();
		LOGGER.info("exiting ScoreStagingDAOImpl | retrieveAllScoreType");
		try{
			List<BigDecimal> searchResut =	qury.getResultList();
			 for (BigDecimal result : searchResut) {
				 returnRes.add(Long.valueOf(result.toString()));
			 }
		return returnRes;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
///// Score Search Page changes
	@Override
	public List<CodeValue> retrieveScrSearchScoreTypeCode(ScoreVO scoreVO) {
	
		return null;
	}

	@Override
	public List<CodeValue> retrieveScrSearchGranularity(ScoreVO scoreVO) {
	
		return null;
	}
	
	@Override
	public void removeID(List<Long> prodDtlIdList, String deleteQuery,
			String parameter, Long prod_id, String prodParameter) {
		LOGGER.info("entering ScoreStagingDAOImpl | removeID");
		// remove the Sales Channel from the table
		Query query = em.createNamedQuery(deleteQuery);
		query.setParameter(parameter, prodDtlIdList);
		query.setParameter(prodParameter, prod_id);
		try {
		query.executeUpdate();		
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting ScoreStagingDAOImpl | removeID");		
	}
	 public void removeID(String deleteQuery,
				String parameter, Long prod_id, String prodParameter){
			LOGGER.info("entering ScoreStagingDAOImpl | removeID");
			// remove the Sales Channel from the table
			Query query = em.createNamedQuery(deleteQuery);
			query.setParameter(prodParameter, prod_id);
			try {
			query.executeUpdate();		
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
			LOGGER.info("exiting ScoreStagingDAOImpl | removeID");		
		}
	 
	@SuppressWarnings("unchecked")
	@Override
	public List<Long> retrieveScoreDtlId(Long scoreId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("scoreId", scoreId);		

		Query query = createNamedQuery(QUERY_RETRIEVE_SCORE_DTL_ID,parameters);
	
		LOGGER.info("exiting ScoreStagingDAOImpl | retrieveAllScoreType");
		List<Long> scoreDetails = null;
		try{
		scoreDetails = query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return scoreDetails;
	}
	@SuppressWarnings("unchecked")
	public List<Long> retrieveProdScoreMapId(List<Long> scoreDtlId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("scrDtlId", scoreDtlId);		

		Query query = createNamedQuery(QUERY_RETRIEVE_PROD_SCORE_RESC_GRAN_MAP_ID,parameters);
				
		List<Long> codeValues = null;
		try{
			codeValues = query.getResultList();
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting ScoreStagingDAOImpl | retrieveProdScoreMapId");
		return codeValues;	
		
	}
	
	
	@Override
	public void removeProdRescID(List<Long> prodDtlIdList, String deleteQuery,
			String parameter) {
		LOGGER.info("entering ScoreStagingDAOImpl | removeID");
		// remove the Sales Channel from the table
		Query query = em.createNamedQuery(deleteQuery);
		query.setParameter(parameter, prodDtlIdList);
		try {
		query.executeUpdate();	
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting ScoreStagingDAOImpl | removeProdRescID");		
	}
	
	@SuppressWarnings("unchecked")
	public List<Long> retreiveScoreMappingId(List<Long> scrMapId,Long scoreId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("scoreMapId", scrMapId);		
		parameters.put("scoreId", scoreId);	
		Query query = createNamedQuery(QUERY_RETRIEVE_SCORE_MAP_ID,parameters);
				
		List<Long> codeValues = null;
		try{
			codeValues = query.getResultList();
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting ScoreStagingDAOImpl | retreiveScoreMappingId");
		return codeValues;	
		
	}
	@SuppressWarnings("unchecked")
	public List<Long> retreiveScrDtlId(List<Long> scrGruId,Long scoreId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("granAssnId", scrGruId);		
		parameters.put("scoreId", scoreId);	
		Query query = createNamedQuery(QUERY_RETRIEVE_SCORE_DTL_ID_VAL,parameters);
				
		List<Long> codeValues = null;
		try{
			codeValues = query.getResultList();
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting ScoreStagingDAOImpl | retreiveScrDtlId");
		return codeValues;	
		
	}
	@SuppressWarnings("unchecked")
	public List<Long> retreiveScrDtlId(Long scoreId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("scoreId", scoreId);	
		Query query = createNamedQuery(QUERY_RETRIEVE_SCORE_DTL_ID_VALS,parameters);
				
		List<Long> codeValues = null;
		try{
			codeValues = query.getResultList();
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting ScoreStagingDAOImpl | retreiveScrDtlId");
		return codeValues;	
		
	}
	
	@Override
	public Long retrieveScoreTypeId(String query) {
	try{	
		System.out.println("retrieveScoreTypeId");
		return jdbcTemplate.queryForLong(query);
	}catch(NoResultException ex){
		throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
	}catch(PersistenceException ex){
		throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
	}catch(Exception ex){
		ex.printStackTrace();
		throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
	}
}
	

	@Override
	public Boolean checkForDuplicate(Long scrTypId, Long scoreMarketCode,
			Double scoreVersion) {
		Long count = (long) 0;
		try{
		count = jdbcTemplate.queryForLong("SELECT COUNT(*) FROM SORUSR.SCR WHERE SCR_TYP_ID="+scrTypId+" AND SCR_MKT_CD="+scoreMarketCode+" AND SCR_VER="+scoreVersion);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		if(count>0){
			return true;
		}else{
			return false;
		}
	}

	
	
}
