/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;


import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.vo.IndsPropertyFileVO;
import com.dnb.dsc.refdata.core.vo.IndusCodeBulkUploadMasterVO;
import com.dnb.dsc.refdata.core.vo.IndusCodeBulkUploadVO;
import com.dnb.dsc.refdata.dao.IndsCodeBulkUploadDAO;
/**
 * DAO implementation class for the Industry Code Bulk Batch operations.
 * <p>
 * 
 * The DAO contacts the staging DB for all its operations.
 * <p>
 * 
 * @author Cognizant
 * @version last updated : May 28, 2012
 * @see
 * 
 */
public class IndsCodeBulkUploadDAOImpl extends JdbcDaoSupport implements IndsCodeBulkUploadDAO {
	/*@Autowired
	private JdbcTemplate jdbcTemplate;*/

	IndsPropertyFileVO indsPropertyFileVO;
	
	public IndsCodeBulkUploadDAOImpl(IndsPropertyFileVO indsPropertyFileVO)
	{
		this.indsPropertyFileVO = indsPropertyFileVO;
	}

	@Override
	public void saveMap(final List<? extends IndusCodeBulkUploadVO> mapList,final Long fromTypCd,final Long toTypCd,final String userId) {
		String insertStmt = indsPropertyFileVO.getInsertQuery();
		String deleteStmt = indsPropertyFileVO.getIndsMapDeleteQuery();		
		
		getJdbcTemplate().batchUpdate(deleteStmt,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						ps.setLong(1, fromTypCd);
						ps.setLong(2, toTypCd);
					}
					public int getBatchSize() { 
						return 1;
					}
				});
	
		getJdbcTemplate().batchUpdate(insertStmt,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						IndusCodeBulkUploadVO indusCodeBulkUploadVO = mapList.get(i);
						ps.setLong(1, indusCodeBulkUploadVO.getFromIndusCodeId());
						ps.setLong(2, indusCodeBulkUploadVO.getToIndusCodeId());
						ps.setLong(3,   indusCodeBulkUploadVO.getPrfdMappingInd());
						ps.setString(4,  userId);
						ps.setString(5,  userId);
					}
					public int getBatchSize() { 
						return mapList.size();
					}
				});
		
	}

	@Override
	public void saveIndsCode(final
			List<? extends IndusCodeBulkUploadMasterVO> indusCodeBulkUploadList,String userId) {
		String indsCodeInsertQuery = indsPropertyFileVO.getIndsCodeInsertQuery();
		String indsCodeDescInsertQuery = indsPropertyFileVO.getIndsCodeDescInsertQuery();
		String indsCodeDescUpdateQuery = indsPropertyFileVO.getIndsDescUpdateQuery();
		final List<IndustryCode> indusCodeList=new ArrayList<IndustryCode>();
		final List<IndustryCode> indusCodeDescInsertList=new ArrayList<IndustryCode>();
		final List<IndustryCode> indusCodeDescUpdateList=new ArrayList<IndustryCode>();
		for(IndusCodeBulkUploadMasterVO indusCodeBulkUploadMasterVO:indusCodeBulkUploadList){
			IndustryCode indsCode=indusCodeBulkUploadMasterVO.getIndsCode();
			if(indsCode!=null){
				if(indsCode.getIndustryCodeIdBulk().startsWith("NRQ"))
				{
					indsCode.setCreatedUser(userId);
					indsCode.setModifiedUser(userId);
					indusCodeList.add(indsCode);
				}
			}
			
		}
		for(IndusCodeBulkUploadMasterVO indusCodeBulkUploadMasterVO:indusCodeBulkUploadList){
			IndustryCode indsCodeDesc=indusCodeBulkUploadMasterVO.getIndsCodeDesc();
			if(indsCodeDesc!=null){
				if(indsCodeDesc.getIndustryCodeDescIdBulk()==null)
				{
					indsCodeDesc.setCreatedUser(userId);
					indsCodeDesc.setModifiedUser(userId);
					indusCodeDescInsertList.add(indsCodeDesc);
				}
				else{
					indsCodeDesc.setModifiedUser(userId);
					indusCodeDescUpdateList.add(indsCodeDesc);
				}
			}
			
		}
		
		getJdbcTemplate().batchUpdate(indsCodeInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						IndustryCode indsCode = indusCodeList.get(i);
						ps.setLong(1,   indsCode.getIndustryCodeId());
						ps.setString(2, indsCode.getIndustryCode());
						ps.setLong(3,   indsCode.getIndustryCodeTypeCode());
						if(indsCode.getIndustryCodeGroupLvelCode()!=null){
							ps.setLong(4,indsCode.getIndustryCodeGroupLvelCode());
						}
						else
						{
							ps.setNull(4,java.sql.Types.INTEGER);
						}
						ps.setString(5, indsCode.getCreatedUser());
						ps.setString(6, indsCode.getModifiedUser());
					}
					public int getBatchSize() { 
						return indusCodeList.size();
					}
				});
		getJdbcTemplate().batchUpdate(indsCodeDescInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						IndustryCode indsCodeDesc=indusCodeDescInsertList.get(i);
								if(indsCodeDesc.getIndustryCodeIdBulk().startsWith("NRQ"))
								{
									ps.setLong(1, indsCodeDesc.getIndustryCodeId());
								}
								else
								{
									ps.setLong(1,new Long(indsCodeDesc.getIndustryCodeIdBulk()));
								}
								ps.setLong(2, indsCodeDesc.getLanguageCode());
								ps.setLong(3,   indsCodeDesc.getWritScriptCD());
								ps.setString(4,   indsCodeDesc.getIndustryCodeDescription());
								ps.setLong(5,   indsCodeDesc.getDescLenCD());
								ps.setString(6,   indsCodeDesc.getCreatedUser());
								ps.setString(7,   indsCodeDesc.getModifiedUser());
							}
						
					public int getBatchSize() { 
						return indusCodeDescInsertList.size();
					}
				});
		getJdbcTemplate().batchUpdate(indsCodeDescUpdateQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						IndustryCode indsCodeDesc=indusCodeDescUpdateList.get(i);
								
								ps.setString(1, indsCodeDesc.getIndustryCodeDescription());
								ps.setLong(2, indsCodeDesc.getLanguageCode());
								ps.setLong(3,   indsCodeDesc.getWritScriptCD());
								ps.setLong(4,   indsCodeDesc.getDescLenCD());								
								ps.setString(5, indsCodeDesc.getModifiedUser());
								ps.setLong(6,   indsCodeDesc.getIndustryCodeDescIdBulk());
							}
						
					public int getBatchSize() { 
						return indusCodeDescUpdateList.size();
					}
				});
		
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public List<CodeValue> getCodeValueList() {
		String getcdvalQuery = indsPropertyFileVO.getCdValQuery();
		List<Map<String, Object>>  rows = getJdbcTemplate().queryForList(getcdvalQuery);
		List<CodeValue> cdValList = new ArrayList<CodeValue>();
		for (Map row : rows) {
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((BigDecimal)row.get("cd_val_id")).longValue());
			codeValue.setCodeTableId(((BigDecimal)row.get("cd_tbl_id")).intValue());
			cdValList.add(codeValue);
		}
		return cdValList;

	}

	@Override
	public boolean isUniqueIndsCode(String indsCode,Long indsCodeTypCode) {
		String indsUniqueQuery = indsPropertyFileVO.getIndsUniqueQuery();
		int count = getJdbcTemplate().queryForInt(indsUniqueQuery,indsCode,indsCodeTypCode);
		if(count==0){
			return true;
		}
		else{
			return false;
		}
	}
	
	@Override
	public boolean isIndsCodeAvail(Long indsCodeId) {
		String indsCodeQuery = indsPropertyFileVO.getValidateIdQuery();
		int count = getJdbcTemplate().queryForInt(indsCodeQuery,indsCodeId);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
	}
	
	@Override
	public boolean isIndsCodeDescAvail(Long indsCodeDescId) {
		String indsCodeDescQuery = indsPropertyFileVO.getValidateDescIdQuery();
		int count = getJdbcTemplate().queryForInt(indsCodeDescQuery,indsCodeDescId);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
	}

	

	@Override
	public boolean isPrfdIndcValid(Long fromIndsCodeId, Long toIndsCodeTypCode) {
		String prfdMapQuery = indsPropertyFileVO.getValidatePrfdMapQuery();
		int count = getJdbcTemplate().queryForInt(prfdMapQuery,fromIndsCodeId,toIndsCodeTypCode);
		if(count==0){
			return true;
		}
		else{
			return false;
		}
	}

	@Override
	public boolean isMapValid(Long indsCodeId, String indsCode,
			Long indsCodeTypCode) {
		String validateWithIdQuery = indsPropertyFileVO.getValidateWithIdQuery();
		int count = getJdbcTemplate().queryForInt(validateWithIdQuery,indsCodeId,indsCode,indsCodeTypCode);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
	}

	@Override
	public boolean isMapValidWithoutId(String indsCode, Long indsCodeTypCode) {
		boolean flag=false;
		String validateWithoutIdQuery = indsPropertyFileVO.getValidateWithoutIdQuery();
		List<Map<String, Object>>  rows = getJdbcTemplate().queryForList(validateWithoutIdQuery,indsCode,indsCodeTypCode);
		if(rows==null||rows.size()==0)
		{
			flag=false;
		}
		else if(rows.size()==1)
		{
			flag=true;
		}
		return flag;
	}
	@Override
	public Long generateIndsCodeId(){
		String generateIndsCodeIdQuery = indsPropertyFileVO.getIndsCodeIdSeqQuery();
		Long indsCodeId = getJdbcTemplate().queryForLong(generateIndsCodeIdQuery);
		return indsCodeId;
	}
	
}
