/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.DnbUnusAdr;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsyCtryAppy;
import com.dnb.dsc.refdata.core.entity.DnbUnusIndNme;
import com.dnb.dsc.refdata.core.entity.DnbUnusTlcmAdr;
import com.dnb.dsc.refdata.core.entity.IndustryCodeInferment;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.InfermentTextCountryApplicability;
import com.dnb.dsc.refdata.core.entity.LegalFormInferment;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;
import com.dnb.dsc.refdata.core.vo.ControlWordsPropertyFileVO;
import com.dnb.dsc.refdata.core.vo.DNBUnusableGlsyBulkUploadMasterVO;
import com.dnb.dsc.refdata.core.vo.InfermentBulkUploadMasterVO;
import com.dnb.dsc.refdata.dao.CtrlWrdsBulkUploadDAO;

/**
 * 
 * @author Cognizant
 * @version last updated : June 23, 2012
 * @see
 * 
 * 
 */
public class CtrlWrdsBulkUploadDAOImpl extends JdbcDaoSupport implements
		CtrlWrdsBulkUploadDAO {
	ControlWordsPropertyFileVO ctrlWrdsPropertyFileVO;
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CrcyBatchDAOImpl.class);


	public CtrlWrdsBulkUploadDAOImpl(
			ControlWordsPropertyFileVO ctrlWrdsPropertyFileVO) {
		this.ctrlWrdsPropertyFileVO = ctrlWrdsPropertyFileVO;
	}

	@Override
	public boolean isGeoUnitIdAvail(Long dnbUnusGlsyCtryAppyId) {
		String geoUnitIdValidateQuery = ctrlWrdsPropertyFileVO
				.getValidateDnbGlyIdQuery();
		int count = getJdbcTemplate().queryForInt(geoUnitIdValidateQuery,
				dnbUnusGlsyCtryAppyId);
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public boolean isDnbUnsbleGlyIdAvail(Long dnbUnsGlyBulkId) {
		String dnbGlyValidateQuery = ctrlWrdsPropertyFileVO
				.getValidateDnbGlyIdQuery();
		int count = getJdbcTemplate().queryForInt(dnbGlyValidateQuery,
				dnbUnsGlyBulkId);
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}

	
	@Override
	public boolean isIndusCodeIdAvail(Long indusCodeId) {
		String indusCdValidateQuery = ctrlWrdsPropertyFileVO
				.getValidateIndusCdQuery();
	
		int count = getJdbcTemplate().queryForInt(indusCdValidateQuery,
				indusCodeId);
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}
	@Override
	public boolean isInfrTxtCtryApyIdAvail(Long infrTxtCtryApyBulkId) {
		String infrTxtCtryApyValidateQuery = ctrlWrdsPropertyFileVO
				.getValidateInfTxtCtrApyIdQuery();
		int count = getJdbcTemplate().queryForInt(infrTxtCtryApyValidateQuery,
				infrTxtCtryApyBulkId);
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}
	
	@Override
	public boolean isIndusCdInfmntIdAvail(Long indusCdInfmntId) {
		String indsCdInfmntIdValidateQuery = ctrlWrdsPropertyFileVO
				.getValidateIndsCdInfTxIdQuery();
		int count = getJdbcTemplate().queryForInt(indsCdInfmntIdValidateQuery,
				indusCdInfmntId);
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}
	
	@Override
	public boolean isInfermentTextIdAvail(String infrTextBulkId) {
		String geoUnitIdValidateQuery = ctrlWrdsPropertyFileVO
				.getValidateInfrTxtIdQuery();
		int count = getJdbcTemplate().queryForInt(geoUnitIdValidateQuery,
				infrTextBulkId);
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}
	
	
	
	@SuppressWarnings("rawtypes")
	@Override
	public List<CodeValue> getCdValListFordnbGlyTypCd() {

		String getValidateDNBGlsryTypeCdQuery = ctrlWrdsPropertyFileVO
				.getValidateDNBGlsryTypeCdQuery();
		List<Map<String, Object>> rows = getJdbcTemplate().queryForList(
				getValidateDNBGlsryTypeCdQuery);
		List<CodeValue> cdValList = new ArrayList<CodeValue>();
		for (Map row : rows) {
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((BigDecimal) row.get("cd_val_id"))
					.longValue());
			codeValue.setCodeTableId(((BigDecimal) row.get("cd_tbl_id"))
					.intValue());
			cdValList.add(codeValue);
		}
		return cdValList;
	}

	
	@SuppressWarnings("rawtypes")
	@Override
	public List<CodeValue> getCdValListForTypCd() {

		String getCdValListTypeCdQuery = ctrlWrdsPropertyFileVO
				.getValidateTypecodesQuery();
		List<Map<String, Object>> rows = getJdbcTemplate().queryForList(
				getCdValListTypeCdQuery);
		List<CodeValue> cdValList = new ArrayList<CodeValue>();
		for (Map row : rows) {
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((BigDecimal) row.get("cd_val_id"))
					.longValue());
			codeValue.setCodeTableId(((BigDecimal) row.get("cd_tbl_id"))
					.intValue());
			cdValList.add(codeValue);
		}
		return cdValList;
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public List<CodeValue> getValidateComMethdCdQuery() {

		String getValidateDNBGlsryTypeCdQuery = ctrlWrdsPropertyFileVO
				.getValidateComMethdCdQuery();
		List<Map<String, Object>> rows = getJdbcTemplate().queryForList(
				getValidateDNBGlsryTypeCdQuery);
		List<CodeValue> cdValList = new ArrayList<CodeValue>();
		for (Map row : rows) {
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((BigDecimal) row.get("cd_val_id"))
					.longValue());
			codeValue.setCodeTableId(((BigDecimal) row.get("cd_tbl_id"))
					.intValue());
			cdValList.add(codeValue);
		}
		return cdValList;
	}
	
	@Override
	public boolean isCntryGeoUnitIdAvail(Long cntryGeoUnitId) {
		String cntryValidateQuery=ctrlWrdsPropertyFileVO.getValidateGeoUnitIdQuery();
		cntryValidateQuery=cntryValidateQuery+" and geo_unit_typ_cd=128";
		int count = getJdbcTemplate().queryForInt(cntryValidateQuery,cntryGeoUnitId);
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}
	
	@Override
		public boolean isAddrGeoUnitAvail(Long addrGeoUnitId) {
			String geoUnitIdValidateQuery = ctrlWrdsPropertyFileVO
					.getValidateAddrGeoUnitQuery();
			int count = getJdbcTemplate().queryForInt(geoUnitIdValidateQuery,
					addrGeoUnitId);
			if (count == 0) {
				return false;
			} else {
				return true;
			}
		}

	@Override
	public boolean isTerrtoryGeoUnitIdAvail(Long terrtoryGeoUnitId) {
		String terrtoryValidateQuery=ctrlWrdsPropertyFileVO.getValidateGeoUnitIdQuery();
		terrtoryValidateQuery=terrtoryValidateQuery+" and geo_unit_typ_cd=5392";
		int count = getJdbcTemplate().queryForInt(terrtoryValidateQuery,terrtoryGeoUnitId);
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public void savePhoneAreaCode(
			List<? extends PhoneAreaCode> phoneAreaCodeList,String userId) {
		String phonAreaCodeInsertQuery = ctrlWrdsPropertyFileVO.getPhonAreaCodeInsertQuery();
		final List<PhoneAreaCode> insertList = new ArrayList<PhoneAreaCode>();
		
		for (PhoneAreaCode phoneAreaCode : phoneAreaCodeList) {
			if (phoneAreaCode.getPhoneAreaCodeId() == null) {
				phoneAreaCode.setCreatedUser(userId);
				phoneAreaCode.setModifiedUser(userId);
				insertList.add(phoneAreaCode);
			}
		}
		
		LOGGER.info("Inserting Records :");
		getJdbcTemplate().batchUpdate(phonAreaCodeInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						PhoneAreaCode phoneAreaCode = insertList.get(i);
						
						ps.setString(1, phoneAreaCode.getAreaCodeNumber());
						if(phoneAreaCode.getAreaCodeServiceDescription()!=null){
							ps.setString(2, phoneAreaCode.getAreaCodeServiceDescription());
						}else{
							ps.setNull(2, java.sql.Types.VARCHAR);
						}
						if(phoneAreaCode.getTerritoryGeoUnitId()!=null){
						ps.setLong(3,
								phoneAreaCode.getTerritoryGeoUnitId());
						}else{
							ps.setNull(3, java.sql.Types.NUMERIC);
						}
						ps.setLong(4, phoneAreaCode.getCountryGeoUnitId());
						if(phoneAreaCode.getDnbUnusGlsyId()!=null){
							ps.setDouble(5, phoneAreaCode.getDnbUnusGlsyId());
						}else{
							ps.setNull(5, java.sql.Types.NUMERIC);
						}
						ps.setString(6, phoneAreaCode.getCreatedUser());
						ps.setString(7, phoneAreaCode.getModifiedUser());
					}
					public int getBatchSize() {
						return insertList.size();
					}
				});
		
		/*LOGGER.info("updating Records :");
		getJdbcTemplate().batchUpdate(updatestmt,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						CurrencyExchange currency = updateList.get(i);
						ps.setLong(1, currency.getFromCurrencyCode());
						ps.setLong(2, currency.getToCurrencyCode());
						ps.setDate(3, new Date(currency.getCurrencyExchangeDate().getTime()));
						ps.setLong(4,
								currency.getCurrencyExchangeDatePrcnCode());
						ps.setDouble(5, currency.getCurrencyExchangeRate());
						ps.setLong(6, currency.getDataProviderCode());
						ps.setLong(7, currency.getCurrencyExchangeId());
					}
					public int getBatchSize() {
						return updateList.size();
					}
				});*/
		
	}

	@Override
	public Long generateInfrTxtId() {
		String generateInferTxtIdQuery = ctrlWrdsPropertyFileVO.getPhonAreaCodeSeqQuery();
		Long inferTxtId = getJdbcTemplate().queryForLong(generateInferTxtIdQuery);
		return inferTxtId;
	}
	@Override
	public Long generateDnbUnusableGlsyId() {
		String generateInferTxtIdQuery = ctrlWrdsPropertyFileVO.getDnbUnusableGlsySeqQuery();
		Long dnbUnusableGlsyId = getJdbcTemplate().queryForLong(generateInferTxtIdQuery);
		return dnbUnusableGlsyId;
	}

	@Override
	public void saveInferment(
			List<? extends InfermentBulkUploadMasterVO> inferBlkUploadList,String userId) {
		final SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		String inferTxtInsertQuery = ctrlWrdsPropertyFileVO.getInferTxtInsertQuery();
		String inftTxtCntryAppyInsertQuery = ctrlWrdsPropertyFileVO.getInftTxtCntryAppyInsertQuery();
		String indsCdInferInsertQuery = ctrlWrdsPropertyFileVO.getIndsCdInferInsertQuery();
		String lglFormInsertQuery = ctrlWrdsPropertyFileVO.getLglFormInsertQuery();
		String infrTxtUpdateQuery = ctrlWrdsPropertyFileVO.getInfrTxtUpdateQuery();
		String indsCdInfrDeleteQuery = ctrlWrdsPropertyFileVO.getIndsCdInfrDeleteQuery();
		String infrTxtCntyAppyDeleteQuery = ctrlWrdsPropertyFileVO.getInfrTxtCntyAppyDeleteQuery();
		String infrTxtDeleteQuery = ctrlWrdsPropertyFileVO.getInfrTxtDeleteQuery();
		String lglInfrDeleteQuery = ctrlWrdsPropertyFileVO.getLglInfrDeleteQuery();
		String infrTxtCntyAppyDeleteSoftQuery = ctrlWrdsPropertyFileVO.getInfrTxtCntyAppyDeleteSoftQuery();
		String infrTxtDeleteSoftQuery = ctrlWrdsPropertyFileVO.getInfrTxtCntyAppyDeleteSoftQuery();
		String indsCdInfrUpdateQuery = ctrlWrdsPropertyFileVO.getIndsCdInfrUpdateQuery();
		//String infrTxtCntyAppyIdDeleteQuery = ctrlWrdsPropertyFileVO.getInfrTxtCntyAppyIdDeleteQuery();
		String infrTxtCntyAppyIdDeleteSoftQuery = ctrlWrdsPropertyFileVO.getInfrTxtCntyAppyDeleteSoftQuery();
		final List<InfermentText> infrTxtList=new ArrayList<InfermentText>();
		final List<InfermentText> infrTxtDeleteList=new ArrayList<InfermentText>();
		final List<InfermentText> infrTxtSoftDeleteList=new ArrayList<InfermentText>();
		final List<InfermentText> infrTxtUpdateList=new ArrayList<InfermentText>();
		final List<InfermentTextCountryApplicability> infrTxtCntryAppyInsertList=new ArrayList<InfermentTextCountryApplicability>();
		final List<InfermentTextCountryApplicability> infrTxtCntryAppyUpdateList=new ArrayList<InfermentTextCountryApplicability>();
		final List<IndustryCodeInferment> indsCdInferInsertList=new ArrayList<IndustryCodeInferment>();
		final List<IndustryCodeInferment> indsCdInferUpdateList=new ArrayList<IndustryCodeInferment>();
		final List<LegalFormInferment> lglFrmInferInsertList=new ArrayList<LegalFormInferment>();
		final List<LegalFormInferment> lglFrmInferUpdateList=new ArrayList<LegalFormInferment>();
		for(InfermentBulkUploadMasterVO inferBlkUploadMasterVO:inferBlkUploadList){
			InfermentText inferTxt=inferBlkUploadMasterVO.getInfermentText();
			if(inferTxt!=null){
				if(inferTxt.getInfrmntTxtBulkId().startsWith("NRQ"))
				{
					inferTxt.setCreatedUser(userId);
					inferTxt.setModifiedUser(userId);
					infrTxtList.add(inferTxt);
				}else if(inferTxt.getInfermentTypeCode()==24761){
					if(inferTxt.getExpirationDate()!=null){
						inferTxt.setModifiedUser(userId);
						inferTxt.setInfermentTextId(Long.valueOf(inferTxt.getInfrmntTxtBulkId()));
						infrTxtDeleteList.add(inferTxt);
					}else if(inferTxt.getInfermentText()!=null){
						inferTxt.setModifiedUser(userId);
						inferTxt.setInfermentTextId(Long.valueOf(inferTxt.getInfrmntTxtBulkId()));
						infrTxtUpdateList.add(inferTxt);
					}
				}else if(inferTxt.getInfermentTypeCode()==24760){
					if(inferTxt.getExpirationDate()!=null){
						inferTxt.setModifiedUser(userId);
						inferTxt.setInfermentTextId(Long.valueOf(inferTxt.getInfrmntTxtBulkId()));
						infrTxtSoftDeleteList.add(inferTxt);
					}
				}
			}
			
		}
		for(InfermentBulkUploadMasterVO inferBlkUploadMasterVO:inferBlkUploadList){
			InfermentTextCountryApplicability inferTxtCntryAppy=inferBlkUploadMasterVO.getInferTxtCtyAppy();
			if(inferTxtCntryAppy!=null){
				if(inferTxtCntryAppy.getInfermentTextCountryApplicabilityId()==null)
				{
					inferTxtCntryAppy.setCreatedUser(userId);
					inferTxtCntryAppy.setModifiedUser(userId);
					infrTxtCntryAppyInsertList.add(inferTxtCntryAppy);
				}
				else if(inferTxtCntryAppy.getExpirationDate()!=null){
					inferTxtCntryAppy.setModifiedUser(userId);
					infrTxtCntryAppyUpdateList.add(inferTxtCntryAppy);
				}
			}
			
		}
		for(InfermentBulkUploadMasterVO inferBlkUploadMasterVO:inferBlkUploadList){
			IndustryCodeInferment indsCdInfer=inferBlkUploadMasterVO.getIndsCodeInferment();
			if(indsCdInfer!=null){
				if(indsCdInfer.getIndustryCodeInfermentId()==null)
				{
					indsCdInfer.setCreatedUser(userId);
					indsCdInfer.setModifiedUser(userId);
					indsCdInferInsertList.add(indsCdInfer);
				}
				else if(indsCdInfer.getExpirationDate()==null){
					indsCdInfer.setModifiedUser(userId);
					indsCdInferUpdateList.add(indsCdInfer);
				}
			}
			
		}
		for(InfermentBulkUploadMasterVO inferBlkUploadMasterVO:inferBlkUploadList){
			LegalFormInferment lglFrmInfer=inferBlkUploadMasterVO.getLglFormInferment();
			if(lglFrmInfer!=null){
				if(lglFrmInfer.getLegalFormInfermentId()==null)
				{
					lglFrmInfer.setCreatedUser(userId);
					lglFrmInfer.setModifiedUser(userId);
					lglFrmInferInsertList.add(lglFrmInfer);
				}
				else{
					lglFrmInfer.setModifiedUser(userId);
					lglFrmInferUpdateList.add(lglFrmInfer);
				}
			}
			
		}
	
		
		getJdbcTemplate().batchUpdate(inferTxtInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						InfermentText infrTxt = infrTxtList.get(i);
						ps.setLong(1,   infrTxt.getInfermentTextId());
						ps.setLong(2, infrTxt.getLanguageCode());
						ps.setLong(3,   infrTxt.getWritingScriptCode());
						ps.setLong(4,   infrTxt.getInfermentTypeCode());
						ps.setString(5,   infrTxt.getInfermentText());
						ps.setString(6, format.format(infrTxt
								.getEffectiveDate()));

						if (infrTxt.getExpirationDate() != null) {
							ps.setString(7, format.format(infrTxt
									.getExpirationDate()));
						} else {
							ps.setNull(7, java.sql.Types.DATE);
						}
						ps.setString(8,   infrTxt.getCreatedUser());
						ps.setString(9,   infrTxt.getModifiedUser());
					}
					public int getBatchSize() { 
						return infrTxtList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(infrTxtUpdateQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						InfermentText infrTxt = infrTxtUpdateList.get(i);
						ps.setString(1, infrTxt.getInfermentText());
						ps.setString(2,   infrTxt.getModifiedUser());
						ps.setLong(3,   infrTxt.getInfermentTextId());
					}
					public int getBatchSize() { 
						return infrTxtUpdateList.size();
					}
				});
		getJdbcTemplate().batchUpdate(indsCdInfrDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						InfermentText infrTxt = infrTxtDeleteList.get(i);
						ps.setLong(1,   infrTxt.getInfermentTextId());
					}
					public int getBatchSize() { 
						return infrTxtDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(infrTxtCntyAppyDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						InfermentText infrTxt = infrTxtDeleteList.get(i);
						ps.setLong(1,   infrTxt.getInfermentTextId());
					}
					public int getBatchSize() { 
						return infrTxtDeleteList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(infrTxtDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						InfermentText infrTxt = infrTxtDeleteList.get(i);
						ps.setLong(1,   infrTxt.getInfermentTextId());
					}
					public int getBatchSize() { 
						return infrTxtDeleteList.size();
					}
				});
		
		
		
		getJdbcTemplate().batchUpdate(lglInfrDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						InfermentText infrTxt = infrTxtSoftDeleteList.get(i);
						ps.setString(1, format.format(infrTxt.getExpirationDate()));
						ps.setString(2,   infrTxt.getModifiedUser());
						ps.setLong(3,   infrTxt.getInfermentTextId());
					}
					public int getBatchSize() { 
						return infrTxtSoftDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(infrTxtCntyAppyDeleteSoftQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						InfermentText infrTxt = infrTxtSoftDeleteList.get(i);
						ps.setString(1, format.format(infrTxt.getExpirationDate()));
						ps.setString(2,   infrTxt.getModifiedUser());
						ps.setLong(3,   infrTxt.getInfermentTextId());
					}
					public int getBatchSize() { 
						return infrTxtSoftDeleteList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(infrTxtDeleteSoftQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						InfermentText infrTxt = infrTxtSoftDeleteList.get(i);
						ps.setString(1, format.format(infrTxt.getExpirationDate()));
						ps.setString(2,   infrTxt.getModifiedUser());
						ps.setLong(3,   infrTxt.getInfermentTextId());
					}
					public int getBatchSize() { 
						return infrTxtSoftDeleteList.size();
					}
				});
		
		
		
		
		getJdbcTemplate().batchUpdate(inftTxtCntryAppyInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						InfermentTextCountryApplicability inferTxtCntryAppy=infrTxtCntryAppyInsertList.get(i);
								if(inferTxtCntryAppy.getInfrmntTxtBulkId().startsWith("NRQ"))
								{
									ps.setLong(1, inferTxtCntryAppy.getInfermentTextId());
								}
								else
								{
									ps.setLong(1,new Long(inferTxtCntryAppy.getInfrmntTxtBulkId()));
								}
								ps.setString(2, format.format(inferTxtCntryAppy
										.getEffectiveDate()));

								if (inferTxtCntryAppy.getExpirationDate() != null) {
									ps.setString(3, format.format(inferTxtCntryAppy
											.getExpirationDate()));
								} else {
									ps.setNull(3, java.sql.Types.DATE);
								}
								ps.setLong(4, inferTxtCntryAppy.getIcountryGeoUnitId());
								ps.setString(5,   inferTxtCntryAppy.getCreatedUser());
								ps.setString(6,   inferTxtCntryAppy.getModifiedUser());
							}
						
					public int getBatchSize() { 
						return infrTxtCntryAppyInsertList.size();
					}
				});
		getJdbcTemplate().batchUpdate(infrTxtCntyAppyIdDeleteSoftQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						InfermentTextCountryApplicability inferTxtCntryAppy=infrTxtCntryAppyUpdateList.get(i);
								ps.setString(1, format.format(inferTxtCntryAppy
											.getExpirationDate()));
							
								ps.setString(2,   inferTxtCntryAppy.getModifiedUser());
								ps.setLong(3,   inferTxtCntryAppy.getInfermentTextCountryApplicabilityId());
							}
						
					public int getBatchSize() { 
						return infrTxtCntryAppyUpdateList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(indsCdInferInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						IndustryCodeInferment indsCdInfer=indsCdInferInsertList.get(i);
						ps.setLong(1, indsCdInfer.getIndustryCodeId());
						if(indsCdInfer.getInfrmntTxtBulkId().startsWith("NRQ"))
						{
							ps.setLong(2, indsCdInfer.getInfermentTextId());
						}
						else
						{
							ps.setLong(2,new Long(indsCdInfer.getInfrmntTxtBulkId()));
						}
						ps.setString(3,   indsCdInfer.getCreatedUser());
						ps.setString(4,   indsCdInfer.getModifiedUser());
							}
						
					public int getBatchSize() { 
						return indsCdInferInsertList.size();
					}
				});
		getJdbcTemplate().batchUpdate(indsCdInfrUpdateQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						IndustryCodeInferment indsCdInfer=indsCdInferUpdateList.get(i);
						ps.setLong(1, indsCdInfer.getIndustryCodeId());
						ps.setString(2,   indsCdInfer.getModifiedUser());
						ps.setLong(3,   indsCdInfer.getInfermentTextId());
							}
						
					public int getBatchSize() { 
						return indsCdInferUpdateList.size();
					}
				});
		getJdbcTemplate().batchUpdate(lglFormInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						LegalFormInferment lglFrmInfer=lglFrmInferInsertList.get(i);
								
						if(lglFrmInfer.getInfrmntTxtBulkId().startsWith("NRQ"))
						{
							ps.setLong(1, lglFrmInfer.getInfermentTextId());
						}
						else
						{
							ps.setLong(1,new Long(lglFrmInfer.getInfrmntTxtBulkId()));
						}
						if(lglFrmInfer.getLegalFormCode()!=null){
							ps.setLong(2, lglFrmInfer.getLegalFormCode());
						}else{
							ps.setNull(2, java.sql.Types.NUMERIC);
						}
						ps.setLong(3,   lglFrmInfer.getLegalFormClassCode());
						ps.setString(4, format.format(lglFrmInfer
								.getEffectiveDate()));

						if (lglFrmInfer.getExpirationDate() != null) {
							ps.setString(5, format.format(lglFrmInfer
									.getExpirationDate()));
						} else {
							ps.setNull(5, java.sql.Types.DATE);
						}
						ps.setString(6,   lglFrmInfer.getCreatedUser());
						ps.setString(7,   lglFrmInfer.getModifiedUser());
					}
						
					public int getBatchSize() { 
						return lglFrmInferInsertList.size();
					}
				});
		
	}
	
	
	@SuppressWarnings("rawtypes")
	@Override
	public List<CodeValue> getCdValListForLglFmInfmnt(){
		List<CodeValue> cdValList = new ArrayList<CodeValue>();
		String getValidateDNBGlsryTypeCdQuery = ctrlWrdsPropertyFileVO
													.getValidateLglFmClsCdQuery();
		List<Map<String, Object>> rows = getJdbcTemplate().
											queryForList(getValidateDNBGlsryTypeCdQuery);
		for (Map row : rows) {
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((BigDecimal) row.get("cd_val_id"))
					.longValue());
			codeValue.setCodeTableId(((BigDecimal) row.get("cd_tbl_id"))
					.intValue());
			cdValList.add(codeValue);
		}
		return cdValList;
	}

	@Override
	public void saveDnbUnusableGlsy(
			List<? extends DNBUnusableGlsyBulkUploadMasterVO> dnbUnusableGlsyBlkUploadList,String userId) {
		
		final SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		String dnbUnusableGlsyInsertQuery = ctrlWrdsPropertyFileVO.getDnbUnusableGlsyInsertQuery();
		String dnbUnusableGlsyIndNmeInsertQuery = ctrlWrdsPropertyFileVO.getDnbUnusableGlsyIndNmeInsertQuery();
		String dnbUnusableGlsyAddrInsertQuery = ctrlWrdsPropertyFileVO.getDnbUnusableGlsyAddrInsertQuery();
		String dnbUnusableGlsyCntyAppyInsertQuery = ctrlWrdsPropertyFileVO.getDnbUnusableGlsyCntyAppyInsertQuery();
		String dnbUnusableGlsyTelecomInsertQuery = ctrlWrdsPropertyFileVO.getDnbUnusableGlsyTelecomInsertQuery();
		String dnbUnusableGlsyDeleteQuery=ctrlWrdsPropertyFileVO.getDnbUnusableGlsyDeleteQuery();		
		String dnbUnusableGlsyCntyAppyDeleteQuery=ctrlWrdsPropertyFileVO.getDnbUnusableGlsyCntyAppyDeleteQuery();		
		String dnbUnusableGlsyCntyAppyDeleteIdQuery=ctrlWrdsPropertyFileVO.getDnbUnusableGlsyCntyAppyDeleteIdQuery();
		final List<DnbUnusGlsy> dnbUnusGlsyList = new ArrayList<DnbUnusGlsy>();
		final List<DnbUnusGlsy> dnbUnusGlsyDeleteList = new ArrayList<DnbUnusGlsy>();
		final List<DnbUnusIndNme> dnbUnusIndNmeList = new ArrayList<DnbUnusIndNme>();
		final List<DnbUnusAdr> dnbUnusAdrList = new ArrayList<DnbUnusAdr>();
		final List<DnbUnusGlsyCtryAppy> dnbUnusGlsyCtryAppyList=new ArrayList<DnbUnusGlsyCtryAppy>();
		final List<DnbUnusGlsyCtryAppy> dnbUnusGlsyCtryAppyDeleteList=new ArrayList<DnbUnusGlsyCtryAppy>();
		final List<DnbUnusTlcmAdr> dnbUnusTlcmAdrList=new ArrayList<DnbUnusTlcmAdr>();
		/*final List<LegalFormInferment> lglFrmInferInsertList=new ArrayList<LegalFormInferment>();
		final List<LegalFormInferment> lglFrmInferUpdateList=new ArrayList<LegalFormInferment>();*/
		for(DNBUnusableGlsyBulkUploadMasterVO dnbUnusableGlsyBulkUploadMasterVO:dnbUnusableGlsyBlkUploadList){
			DnbUnusGlsy dnbUnusGlsy=dnbUnusableGlsyBulkUploadMasterVO.getDnbUnusGlsy();
			DnbUnusIndNme dnbUnusIndNme=dnbUnusableGlsyBulkUploadMasterVO.getDnbUnusIndNme();
			DnbUnusAdr dnbUnusAdr=dnbUnusableGlsyBulkUploadMasterVO.getDnbUnusAdr();
			if(dnbUnusGlsy!=null){
				if(dnbUnusGlsy.getDnbUnsGlyBulkId().startsWith("NRQ"))
				{
					dnbUnusGlsy.setCreatedUser(userId);
					dnbUnusGlsy.setModifiedUser(userId);
					dnbUnusIndNme.setCreatedUser(userId);
					dnbUnusIndNme.setModifiedUser(userId);
					dnbUnusAdr.setCreatedUser(userId);
					dnbUnusAdr.setModifiedUser(userId);
					dnbUnusGlsyList.add(dnbUnusGlsy);
					dnbUnusIndNmeList.add(dnbUnusIndNme);
					dnbUnusAdrList.add(dnbUnusAdr);
				}else if(dnbUnusGlsy.getExpnDt()!=null){
					dnbUnusGlsy.setModifiedUser(userId);
					dnbUnusGlsy.setDnbUnusGlsyId(Long.valueOf(dnbUnusGlsy.getDnbUnsGlyBulkId()));
					dnbUnusGlsyDeleteList.add(dnbUnusGlsy);
				}
			}
			
		}
		for(DNBUnusableGlsyBulkUploadMasterVO dnbUnusableGlsyBulkUploadMasterVO:dnbUnusableGlsyBlkUploadList){
			DnbUnusGlsyCtryAppy dnbUnusGlsyCtryAppy=dnbUnusableGlsyBulkUploadMasterVO.getDnbUnusGlsyCtryAppy();
			if(dnbUnusGlsyCtryAppy!=null)
			{
				if(dnbUnusGlsyCtryAppy.getDnbUnusGlsyCtryAppyId()==null){
					dnbUnusGlsyCtryAppy.setCreatedUser(userId);
					dnbUnusGlsyCtryAppy.setModifiedUser(userId);
					dnbUnusGlsyCtryAppyList.add(dnbUnusGlsyCtryAppy);
					
				}else if(dnbUnusGlsyCtryAppy.getExpnDt()!=null){
					dnbUnusGlsyCtryAppy.setModifiedUser(userId);
					dnbUnusGlsyCtryAppyDeleteList.add(dnbUnusGlsyCtryAppy);
				}
			}
			
		}
		for(DNBUnusableGlsyBulkUploadMasterVO dnbUnusableGlsyBulkUploadMasterVO:dnbUnusableGlsyBlkUploadList){
			DnbUnusTlcmAdr dnbUnusTlcmAdr=dnbUnusableGlsyBulkUploadMasterVO.getDnbUnusTlcmAdr();
			if(dnbUnusTlcmAdr!=null)
			{
				if(dnbUnusTlcmAdr.getDnbUnusTlcmAdrId()==null){
					dnbUnusTlcmAdr.setCreatedUser(userId);
					dnbUnusTlcmAdr.setModifiedUser(userId);
					dnbUnusTlcmAdrList.add(dnbUnusTlcmAdr);
					
				}
			}
			
			
		}
		
		
		getJdbcTemplate().batchUpdate(dnbUnusableGlsyInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						DnbUnusGlsy dnbUnusGlsy = dnbUnusGlsyList.get(i);
						ps.setLong(1,   dnbUnusGlsy.getDnbUnusGlsyId());
						ps.setLong(2, dnbUnusGlsy.getDnbUnusGlsyTypCd());
						ps.setString(3,   dnbUnusGlsy.getDnbUnusTxt());
						
						ps.setLong(4,   dnbUnusGlsy.getStopPrcsRecIndc()? 1 : 0);
						if(dnbUnusGlsy.getExctMtchIndc()!=null){
							ps.setLong(5,   dnbUnusGlsy.getExctMtchIndc()? 1 : 0);
						}else{
							ps.setNull(5, java.sql.Types.NUMERIC);
						}
						if(dnbUnusGlsy.getAlwdWthOthWdIndc()!=null){
							ps.setLong(6, dnbUnusGlsy.getAlwdWthOthWdIndc()? 1 : 0);
						}else{
							ps.setNull(6, java.sql.Types.NUMERIC);
						}
						ps.setString(7, format.format(dnbUnusGlsy.getEffvDt()));

						if (dnbUnusGlsy.getExpnDt() != null) {
							ps.setString(8, format.format(dnbUnusGlsy
									.getExpnDt()));
						} else {
							ps.setNull(8, java.sql.Types.DATE);
						}
						ps.setString(9, dnbUnusGlsy.getCreatedUser());
						ps.setString(10, dnbUnusGlsy.getModifiedUser());
						
					}
					public int getBatchSize() { 
						return dnbUnusGlsyList.size();
					}
				});
		getJdbcTemplate().batchUpdate(dnbUnusableGlsyDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						DnbUnusGlsy dnbUnusGlsy  = dnbUnusGlsyDeleteList.get(i);
						
							
						ps.setString(1,
								format.format(dnbUnusGlsy.getExpnDt()));	
						ps.setString(2,dnbUnusGlsy.getModifiedUser());
						ps.setLong(3,dnbUnusGlsy.getDnbUnusGlsyId());
					}

					public int getBatchSize() {
						return dnbUnusGlsyDeleteList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(dnbUnusableGlsyCntyAppyDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						DnbUnusGlsy dnbUnusGlsy  = dnbUnusGlsyDeleteList.get(i);
						
							
						ps.setString(1,
								format.format(dnbUnusGlsy.getExpnDt()));	
						ps.setString(2,dnbUnusGlsy.getModifiedUser());
						ps.setLong(3,dnbUnusGlsy.getDnbUnusGlsyId());
					}

					public int getBatchSize() {
						return dnbUnusGlsyDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(dnbUnusableGlsyIndNmeInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						DnbUnusIndNme dnbUnusIndNme=dnbUnusIndNmeList.get(i);
								ps.setLong(1, dnbUnusIndNme.getDnbUnusGlsyId());
								
								
								if(dnbUnusIndNme.getNmePfxTxt()!=null){
									ps.setString(2, dnbUnusIndNme.getNmePfxTxt());
								}else{
									ps.setNull(2, java.sql.Types.VARCHAR);
								}
								if(dnbUnusIndNme.getNmeSfxTxt()!=null){
									ps.setString(3, dnbUnusIndNme.getNmeSfxTxt());
								}else{
									ps.setNull(3, java.sql.Types.VARCHAR);
								}
								ps.setString(4, dnbUnusIndNme.getFrnm());
								if(dnbUnusIndNme.getMidlNme()!=null){
									ps.setString(5, dnbUnusIndNme.getMidlNme());
								}else{
									ps.setNull(5, java.sql.Types.VARCHAR);
								}
								ps.setString(6, dnbUnusIndNme.getSrnme());
								ps.setString(7, dnbUnusIndNme.getCreatedUser());
								ps.setString(8, dnbUnusIndNme.getModifiedUser());
							}
						
					public int getBatchSize() { 
						return dnbUnusIndNmeList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(dnbUnusableGlsyAddrInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						DnbUnusAdr dnbUnusAdr=dnbUnusAdrList.get(i);
						ps.setLong(1, dnbUnusAdr.getDnbUnusGlsyId());
						if(dnbUnusAdr.getPostBxNbr()!=null)
						{
							ps.setString(2, dnbUnusAdr.getPostBxNbr());
						}
						else
						{
							ps.setNull(2, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getPostRteBxNbr()!=null)
						{
							ps.setString(3, dnbUnusAdr.getPostRteBxNbr());
						}
						else
						{
							ps.setNull(3, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getPostRteNbr()!=null)
						{
							ps.setString(4, dnbUnusAdr.getPostRteNbr());
						}
						else
						{
							ps.setNull(4, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getBldgNme()!=null)
						{
							ps.setString(5, dnbUnusAdr.getBldgNme());
						}
						else
						{
							ps.setNull(5, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getStrNbr()!=null)
						{
							ps.setString(6, dnbUnusAdr.getStrNbr());
						}
						else
						{
							ps.setNull(6, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getStrNbrExtnTxt()!=null)
						{
							ps.setString(7, dnbUnusAdr.getStrNbrExtnTxt());
						}
						else
						{
							ps.setNull(7, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getStrToNbr()!=null)
						{
							ps.setString(8, dnbUnusAdr.getStrToNbr());
						}
						else
						{
							ps.setNull(8, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getStrToNbrExtnTxt()!=null)
						{
							ps.setString(9, dnbUnusAdr.getStrToNbrExtnTxt());
						}
						else
						{
							ps.setNull(9, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getStrNme()!=null)
						{
							ps.setString(10, dnbUnusAdr.getStrNme());
						}
						else
						{
							ps.setNull(10, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getStrDsgnTxt()!=null)
						{
							ps.setString(11, dnbUnusAdr.getStrDsgnTxt());
						}
						else
						{
							ps.setNull(11, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getScdyStrNme()!=null)
						{
							ps.setString(12, dnbUnusAdr.getScdyStrNme());
						}
						else
						{
							ps.setNull(12, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getLocnTxt()!=null)
						{
							ps.setString(13, dnbUnusAdr.getLocnTxt());
						}
						else
						{
							ps.setNull(13, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getEsteNme()!=null)
						{
							ps.setString(14, dnbUnusAdr.getEsteNme());
						}
						else
						{
							ps.setNull(14, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getMinrTownSubdNme()!=null)
						{
							ps.setString(15, dnbUnusAdr.getMinrTownSubdNme());
						}
						else
						{
							ps.setNull(15, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getMinrTownNme()!=null)
						{
							ps.setString(16, dnbUnusAdr.getMinrTownNme());
						}
						else
						{
							ps.setNull(16, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getPrimTownNme()!=null)
						{
							ps.setString(17, dnbUnusAdr.getPrimTownNme());
						}
						else
						{
							ps.setNull(17, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getPostCode()!=null)
						{
							ps.setString(18, dnbUnusAdr.getPostCode());
						}
						else
						{
							ps.setNull(18, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getPostCodeExtnCode()!=null)
						{
							ps.setString(19, dnbUnusAdr.getPostCodeExtnCode());
						}
						else
						{
							ps.setNull(19, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getFllPostCode()!=null)
						{
							ps.setString(20, dnbUnusAdr.getFllPostCode());
						}
						else
						{
							ps.setNull(20, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getCntyNme()!=null)
						{
							ps.setString(21, dnbUnusAdr.getCntyNme());
						}
						else
						{
							ps.setNull(21, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getTerrNme()!=null)
						{
							ps.setString(22, dnbUnusAdr.getTerrNme());
						}
						else
						{
							ps.setNull(22, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getBldgIntrlStruUnitTypTxt()!=null)
						{
							ps.setString(23, dnbUnusAdr.getBldgIntrlStruUnitTypTxt());
						}
						else
						{
							ps.setNull(23, java.sql.Types.VARCHAR);
						}
						ps.setLong(24, dnbUnusAdr.getCtryGeoUnitId());
						if(dnbUnusAdr.getLn1Adr()!=null)
						{
							ps.setString(25, dnbUnusAdr.getLn1Adr());
						}
						else
						{
							ps.setNull(25, java.sql.Types.VARCHAR);
						}
						if(dnbUnusAdr.getLn2Adr()!=null)
						{
							ps.setString(26, dnbUnusAdr.getLn2Adr());
						}
						else
						{
							ps.setNull(26, java.sql.Types.VARCHAR);
						}
						ps.setString(27, dnbUnusAdr.getCreatedUser());
						ps.setString(28, dnbUnusAdr.getModifiedUser());
							
					}
						
					public int getBatchSize() { 
						return dnbUnusAdrList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(dnbUnusableGlsyCntyAppyInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						DnbUnusGlsyCtryAppy dnbUnusGlsyCtryAppy=dnbUnusGlsyCtryAppyList.get(i);
								
						if(dnbUnusGlsyCtryAppy.getDnbUnsGlyBulkId().startsWith("NRQ"))
						{
							ps.setLong(1, dnbUnusGlsyCtryAppy.getDnbUnusGlsyId());
						}
						else
						{
							ps.setLong(1,new Long(dnbUnusGlsyCtryAppy.getDnbUnsGlyBulkId()));
						}
						
						ps.setLong(2, dnbUnusGlsyCtryAppy.getCtryGeoUnitId());
						ps.setString(3, format.format(dnbUnusGlsyCtryAppy.getEffvDt()));

						if (dnbUnusGlsyCtryAppy.getExpnDt() != null) {
							ps.setString(4, format.format(dnbUnusGlsyCtryAppy
									.getExpnDt()));
						} else {
							ps.setNull(4, java.sql.Types.DATE);
						}
						ps.setString(5, dnbUnusGlsyCtryAppy.getCreatedUser());
						ps.setString(6, dnbUnusGlsyCtryAppy.getModifiedUser());
							}
						
					public int getBatchSize() { 
						return dnbUnusGlsyCtryAppyList.size();
					}
				});
		getJdbcTemplate().batchUpdate(dnbUnusableGlsyCntyAppyDeleteIdQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						DnbUnusGlsyCtryAppy dnbUnusGlsyCtryAppy  = dnbUnusGlsyCtryAppyDeleteList.get(i);
						
							
						ps.setString(1,
								format.format(dnbUnusGlsyCtryAppy.getExpnDt()));	
						ps.setString(2,dnbUnusGlsyCtryAppy.getModifiedUser());
						ps.setLong(3,dnbUnusGlsyCtryAppy.getDnbUnusGlsyCtryAppyId());
					}

					public int getBatchSize() {
						return dnbUnusGlsyCtryAppyDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(dnbUnusableGlsyTelecomInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						DnbUnusTlcmAdr dnbUnusTlcmAdr=dnbUnusTlcmAdrList.get(i);
								
						if(dnbUnusTlcmAdr.getDnbUnsGlyBulkId().startsWith("NRQ"))
						{
							ps.setLong(1, dnbUnusTlcmAdr.getDnbUnusGlsyId());
						}
						else
						{
							ps.setLong(1,new Long(dnbUnusTlcmAdr.getDnbUnsGlyBulkId()));
						}
						if(dnbUnusTlcmAdr.getCommMethCd()!=null)
						{
							ps.setLong(2, dnbUnusTlcmAdr.getCommMethCd());
						}
						else
						{
							ps.setNull(2,java.sql.Types.NUMERIC);
						}
						if(dnbUnusTlcmAdr.getAreaCodeNbr()!=null)
						{
							ps.setString(3, dnbUnusTlcmAdr.getAreaCodeNbr());
						}
						else
						{
							ps.setNull(3,java.sql.Types.VARCHAR);
						}
						if(dnbUnusTlcmAdr.getTlcmExchCode()!=null)
						{
							ps.setString(4, dnbUnusTlcmAdr.getTlcmExchCode());
						}
						else
						{
							ps.setNull(4,java.sql.Types.VARCHAR);
						}
						if(dnbUnusTlcmAdr.getPhonExtnNbr()!=null)
						{
							ps.setString(5, dnbUnusTlcmAdr.getPhonExtnNbr());
						}
						else
						{
							ps.setNull(5,java.sql.Types.VARCHAR);
						}
						if(dnbUnusTlcmAdr.getResIndc()!=null)
						{
							ps.setLong(6, dnbUnusTlcmAdr.getResIndc()? 1 : 0);
						}
						else
						{
							ps.setNull(6,java.sql.Types.NUMERIC);
						}
						if(dnbUnusTlcmAdr.getMblIndc()!=null)
						{
							ps.setLong(7, dnbUnusTlcmAdr.getMblIndc()? 1 : 0);
						}
						else
						{
							ps.setNull(7,java.sql.Types.NUMERIC);
						}
						if(dnbUnusTlcmAdr.getTelxAnsbTxt()!=null)
						{
							ps.setString(8, dnbUnusTlcmAdr.getTelxAnsbTxt());
						}
						else
						{
							ps.setNull(8,java.sql.Types.VARCHAR);
						}
						ps.setString(9, dnbUnusTlcmAdr.getCreatedUser());
						ps.setString(10, dnbUnusTlcmAdr.getModifiedUser());
					}
						
					public int getBatchSize() { 
						return dnbUnusTlcmAdrList.size();
					}
				});

		
		
	}	

}
