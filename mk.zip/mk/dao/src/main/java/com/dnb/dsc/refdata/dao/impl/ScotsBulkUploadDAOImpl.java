package com.dnb.dsc.refdata.dao.impl;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.ScotsBulkUploadMasterVO;
import com.dnb.dsc.refdata.core.vo.ScotsPropertyFileVO;
import com.dnb.dsc.refdata.dao.ScotsBulkUploadDAO;

public class ScotsBulkUploadDAOImpl extends JdbcDaoSupport implements
		ScotsBulkUploadDAO {
	
	private static final Logger LOGGER = LoggerFactory
	.getLogger(ScotsBulkUploadDAOImpl.class);

	/*@Autowired
	private JdbcTemplate jdbcTemplate;*/

	ScotsPropertyFileVO scotsPropertyFileVO;

	public ScotsBulkUploadDAOImpl(ScotsPropertyFileVO scotsPropertyFileVO) {
		this.scotsPropertyFileVO = scotsPropertyFileVO;
	}

	public void save(List<? extends ScotsBulkUploadMasterVO> scotsBulkUploadList,String userId) {
		String cdValInsertQuery = scotsPropertyFileVO.getCdValueInsertQuery();
		String cdValTxtInsertQuery = scotsPropertyFileVO
				.getCdValTxtInsertQuery();
		String cdValAltSchmInsertQuery = scotsPropertyFileVO
				.getCdValAltSchmInsertQuery();
		String sysAppyInsertQuery = scotsPropertyFileVO.getSysAppyInsertQuery();
		String cntryAppyInsertQuery = scotsPropertyFileVO
				.getCntryAppyInsertQuery();
		
		String codeValUpdateQuery=scotsPropertyFileVO.getCodeValUpdateQuery();
		String codeValDeleteQuery=scotsPropertyFileVO.getCodeValDeleteQuery();
		String cdValTxtDeleteQuery=scotsPropertyFileVO.getCdValTxtDeleteQuery();
		String cdValAltSchmDeleteQuery=scotsPropertyFileVO.getCdValAltSchmDeleteQuery();
		String sysAppyDeleteQuery=scotsPropertyFileVO.getSysAppyDeleteQuery();
		String ctryAppyDeleteQuery=scotsPropertyFileVO.getCtryAppyDeleteQuery();
		String cdValTxtIdDeleteQuery=scotsPropertyFileVO.getCdValTxtIdDeleteQuery();
		String cdValAltSchmIdDeleteQuery=scotsPropertyFileVO.getCdValAltSchmIdDeleteQuery();
		String sysAppyIdDeleteQuery=scotsPropertyFileVO.getSysAppyIdDeleteQuery();
		String ctryAppyIdDeleteQuery=scotsPropertyFileVO.getCtryAppyIdDeleteQuery();
		
		final SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		final List<CodeValue> cdValList = new ArrayList<CodeValue>();
		final List<CodeValue> cdValUpdateList = new ArrayList<CodeValue>();
		final List<CodeValue> cdValDeleteList = new ArrayList<CodeValue>();
		final List<CodeValueText> cdValTxtList = new ArrayList<CodeValueText>();
		final List<CodeValueText> cdValTxtDeleteList = new ArrayList<CodeValueText>();
		final List<CodeValueAlternateScheme> cdValAltSchmList = new ArrayList<CodeValueAlternateScheme>();
		final List<CodeValueAlternateScheme> cdValAltSchmDeleteList = new ArrayList<CodeValueAlternateScheme>();
		final List<CountryApplicability> cntryAppyList = new ArrayList<CountryApplicability>();
		final List<CountryApplicability> cntryAppyDeleteList = new ArrayList<CountryApplicability>();
		final List<SystemApplicability> sysAppyList = new ArrayList<SystemApplicability>();
		final List<SystemApplicability> sysAppyDeleteList = new ArrayList<SystemApplicability>();


		for (ScotsBulkUploadMasterVO scotsBulkUploadMasterVO : scotsBulkUploadList) {
			CodeValue cdVal = scotsBulkUploadMasterVO.getCodeValue();
			if (cdVal != null) {
				if (cdVal.getCdValIdBulk().startsWith("NRQ")) {
					cdVal.setCreatedUser(userId);
					cdVal.setModifiedUser(userId);
					cdValList.add(cdVal);
				}
				else{
					cdVal.setModifiedUser(userId);
					if(cdVal.getCdValIdBulk()!=null&&cdVal.getExpirationDate()!=null){
						cdVal.setCodeValueId(Long.valueOf(cdVal.getCdValIdBulk()));
						cdValDeleteList.add(cdVal);
					}else{
						if(cdVal.getBusinessDescription()!=null){
							cdVal.setCodeValueId(Long.valueOf(cdVal.getCdValIdBulk()));
							cdValUpdateList.add(cdVal);
						}
					}
				}
			}

		}
		for (ScotsBulkUploadMasterVO scotsBulkUploadMasterVO : scotsBulkUploadList) {
			CodeValueText codeValueText = scotsBulkUploadMasterVO
					.getCodeValueText();
			if (codeValueText != null) {
				if (codeValueText.getCodeValueTextId() == null) {
					codeValueText.setCreatedUser(userId);
					codeValueText.setModifiedUser(userId);
					cdValTxtList.add(codeValueText);
				}else if(codeValueText.getExpirationDate()!=null){
					codeValueText.setModifiedUser(userId);
					cdValTxtDeleteList.add(codeValueText);
				}
			}

		}
		for (ScotsBulkUploadMasterVO scotsBulkUploadMasterVO : scotsBulkUploadList) {
			CodeValueAlternateScheme cdValAltSchm = scotsBulkUploadMasterVO
					.getCodeValAltSchm();
			if (cdValAltSchm != null) {
				if (cdValAltSchm.getCodeValueAlternateSchemeId() == null) {
					cdValAltSchm.setCreatedUser(userId);
					cdValAltSchm.setModifiedUser(userId);
					cdValAltSchmList.add(cdValAltSchm);
				}else if(cdValAltSchm.getExpirationDate()!=null){
					cdValAltSchm.setModifiedUser(userId);
					cdValAltSchmDeleteList.add(cdValAltSchm);
				}
			}

		}
		for (ScotsBulkUploadMasterVO scotsBulkUploadMasterVO : scotsBulkUploadList) {
			CountryApplicability cntryAppy = scotsBulkUploadMasterVO
					.getCountryAppy();
			if (cntryAppy != null) {
				if (cntryAppy.getCtryAppyId() == null) {
					cntryAppy.setCreatedUser(userId);
					cntryAppy.setModifiedUser(userId);
					cntryAppyList.add(cntryAppy);
				}else if(cntryAppy.getExpirationDate()!=null){
					cntryAppy.setModifiedUser(userId);
					cntryAppyDeleteList.add(cntryAppy);
				}
			}

		}

		for (ScotsBulkUploadMasterVO scotsBulkUploadMasterVO : scotsBulkUploadList) {
			SystemApplicability sysAppy = scotsBulkUploadMasterVO
					.getSystemAppy();
			if (sysAppy != null) {
				if (sysAppy.getSysAppyId() == null) {
					sysAppy.setCreatedUser(userId);
					sysAppy.setModifiedUser(userId);
					sysAppyList.add(sysAppy);
				}else if(sysAppy.getExpirationDate()!=null){
					sysAppy.setModifiedUser(userId);
					sysAppyDeleteList.add(sysAppy);
				}
			}

		}

		getJdbcTemplate().batchUpdate(cdValInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						CodeValue cdVal = cdValList.get(i);
						if (cdVal.getCdValIdBulk().startsWith("NRQ")) {
							ps.setLong(1, cdVal.getCodeValueId());
						} else {
							ps.setLong(1, new Long(cdVal.getCdValIdBulk()));
						}
						ps.setLong(2, cdVal.getCodeTableId());
						ps.setString(3, cdVal.getBusinessDescription());
						if (cdVal.getReasonText() != null) {
							ps.setString(4, cdVal.getReasonText());
						} else {
							ps.setNull(4, java.sql.Types.VARCHAR);
						}
						if (cdVal.getOnBehalfOfName() != null) {
							ps.setString(5, cdVal.getOnBehalfOfName());
						} else {
							ps.setNull(5, java.sql.Types.VARCHAR);
						}
						ps.setString(6, format.format(cdVal.getEffectiveDate()));
						if (cdVal.getExpirationDate() != null) {
							ps.setString(7,
									format.format(cdVal.getExpirationDate()));
						} else {
							ps.setNull(7, java.sql.Types.DATE);
						}
						ps.setString(8,cdVal.getCreatedUser());
						ps.setString(9,cdVal.getModifiedUser());
					}

					public int getBatchSize() {
						return cdValList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(codeValUpdateQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						CodeValue cdVal = cdValUpdateList.get(i);
						
						ps.setString(1,cdVal.getBusinessDescription());				
						ps.setString(2,cdVal.getModifiedUser());
						ps.setLong(3,cdVal.getCodeValueId());
					}

					public int getBatchSize() {
						return cdValUpdateList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(codeValDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						CodeValue cdVal = cdValDeleteList.get(i);
						
							
						ps.setString(1,
								format.format(cdVal.getExpirationDate()));	
						ps.setString(2,cdVal.getModifiedUser());
						ps.setLong(3,cdVal.getCodeValueId());
					}

					public int getBatchSize() {
						return cdValDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(cdValTxtDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						CodeValue cdVal = cdValDeleteList.get(i);
						
						ps.setString(1,
								format.format(cdVal.getExpirationDate()));							
						ps.setString(2,cdVal.getModifiedUser());
						ps.setLong(3,cdVal.getCodeValueId());
					}

					public int getBatchSize() {
						return cdValDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(cdValAltSchmDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						CodeValue cdVal = cdValDeleteList.get(i);
						
						ps.setString(1,
								format.format(cdVal.getExpirationDate()));						
						ps.setString(2,cdVal.getModifiedUser());
						ps.setLong(3,cdVal.getCodeValueId());
					}

					public int getBatchSize() {
						return cdValDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(sysAppyDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						CodeValue cdVal = cdValDeleteList.get(i);
						
						ps.setString(1,
								format.format(cdVal.getExpirationDate()));						
						ps.setString(2,cdVal.getModifiedUser());
						ps.setLong(3,cdVal.getCodeValueId());
					}

					public int getBatchSize() {
						return cdValDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(ctryAppyDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						CodeValue cdVal = cdValDeleteList.get(i);
						
						ps.setString(1,
								format.format(cdVal.getExpirationDate()));						
						ps.setString(2,cdVal.getModifiedUser());
						ps.setLong(3,cdVal.getCodeValueId());
					}

					public int getBatchSize() {
						return cdValDeleteList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(cdValTxtInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						CodeValueText cdValTxt = cdValTxtList.get(i);
						if (cdValTxt.getCdValIdBulk().startsWith("NRQ")) {
							ps.setLong(1, cdValTxt.getCodeValueId());
						} else {
							ps.setLong(1, new Long(cdValTxt.getCdValIdBulk()));
						}						
						ps.setLong(2, cdValTxt.getLanguageCode());
						ps.setLong(3, cdValTxt.getWritingScriptCode());
						ps.setString(4, cdValTxt.getCodeValueShortDescription());
						ps.setString(5, cdValTxt.getCodeValueDescription());
						if (cdValTxt.getProductLiteralShortDescription() != null) {
							ps.setString(6, cdValTxt
									.getProductLiteralShortDescription());
						} else {
							ps.setNull(6, java.sql.Types.VARCHAR);
						}
						ps.setString(7, cdValTxt.getProductLiteralDescription());
						if (cdValTxt.getLiteralMasculineDescription() != null) {
							ps.setString(8,
									cdValTxt.getLiteralMasculineDescription());
						} else {
							ps.setNull(8, java.sql.Types.VARCHAR);
						}

						if (cdValTxt.getLiteralMasculineShortDescription() != null) {
							ps.setString(9, cdValTxt
									.getLiteralMasculineShortDescription());
						} else {
							ps.setNull(9, java.sql.Types.VARCHAR);
						}
						if (cdValTxt.getLiteralFeminineShortDescription() != null) {
							ps.setString(10, cdValTxt
									.getLiteralFeminineShortDescription());
						} else {
							ps.setNull(10, java.sql.Types.VARCHAR);
						}
						if (cdValTxt.getLiteralFeminineDescription() != null) {
							ps.setString(11,
									cdValTxt.getLiteralFeminineDescription());
						} else {
							ps.setNull(11, java.sql.Types.VARCHAR);
						}
						System.out.println(format.format(cdValTxt.getEffectiveDate()));
						ps.setString(12,format.format(cdValTxt.getEffectiveDate()));
						if (cdValTxt.getExpirationDate() != null) {
							ps.setString(13,
									format.format(cdValTxt.getExpirationDate()));
						} else {
							ps.setNull(13, java.sql.Types.DATE);
						}
						ps.setString(14,cdValTxt.getCreatedUser());
						ps.setString(15,cdValTxt.getModifiedUser());

					}

					public int getBatchSize() {
						return cdValTxtList.size();
					}
				});
		getJdbcTemplate().batchUpdate(cdValTxtIdDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						CodeValueText cdValTxt = cdValTxtDeleteList.get(i);
						
						ps.setString(1,
								format.format(cdValTxt.getExpirationDate()));						
						ps.setString(2,cdValTxt.getModifiedUser());
						ps.setLong(3,cdValTxt.getCodeValueTextId());
					}

					public int getBatchSize() {
						return cdValTxtDeleteList.size();
					}
				});

		getJdbcTemplate().batchUpdate(cdValAltSchmInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						CodeValueAlternateScheme cdValAltSchm = cdValAltSchmList
								.get(i);
						if (cdValAltSchm.getCdValIdBulk().startsWith("NRQ")) {
							ps.setLong(1, cdValAltSchm.getCodeValueId());
						} else {
							ps.setLong(1,
									new Long(cdValAltSchm.getCdValIdBulk()));
						}
						ps.setLong(2, cdValAltSchm.getAlternateSchemeTypeCode());
						ps.setString(3,
								cdValAltSchm.getAlternateSchemeCodeValue());
						if (cdValAltSchm
								.getAlternateSchemeCodeValueDescription() != null) {
							ps.setString(4, cdValAltSchm
									.getAlternateSchemeCodeValueDescription());
						} else {
							ps.setNull(4, java.sql.Types.VARCHAR);
						}

						ps.setString(5,
								format.format(cdValAltSchm.getEffectiveDate()));
						if (cdValAltSchm.getExpirationDate() != null) {
							ps.setString(6, format.format(cdValAltSchm
									.getExpirationDate()));
						} else {
							ps.setNull(6, java.sql.Types.DATE);
						}
						ps.setString(7,cdValAltSchm.getCreatedUser());
						ps.setString(8,cdValAltSchm.getModifiedUser());

					}

					public int getBatchSize() {
						return cdValAltSchmList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(cdValAltSchmIdDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						CodeValueAlternateScheme cdValAltSchm = cdValAltSchmDeleteList.get(i);
						
						ps.setString(1,
								format.format(cdValAltSchm.getExpirationDate()));						
						ps.setString(2,cdValAltSchm.getModifiedUser());
						ps.setLong(3,cdValAltSchm.getCodeValueAlternateSchemeId());
					}

					public int getBatchSize() {
						return cdValAltSchmDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(cntryAppyInsertQuery,
				new BatchPreparedStatementSetter() {
					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						CountryApplicability cntryAppy = cntryAppyList.get(i);
						/*if (cntryAppy.getCdValIdBulk().startsWith("NRQ"))

						{
							ps.setLong(1, cntryAppy.getCodeValueId());
						} else {
							ps.setLong(1, new Long(cntryAppy.getCdValIdBulk()));
						}*/
						ps.setLong(1, cntryAppy.getCountryGeoUnitId());
						ps.setLong(2, cntryAppy.getApplicabilityIndicator());
						if (cntryAppy.getCodeTableId() != null) {
							ps.setLong(3, cntryAppy.getCodeTableId());
						} else {
							ps.setNull(3, java.sql.Types.VARCHAR);
						}
						if (cntryAppy.getCdValIdBulk() != null) {
							if (cntryAppy.getCdValIdBulk().startsWith("NRQ"))

							{
								ps.setLong(4, cntryAppy.getCodeValueId());
							} else {
								ps.setLong(4, new Long(cntryAppy.getCdValIdBulk()));
							}							
						} else {
							ps.setNull(4, java.sql.Types.VARCHAR);
						}

						ps.setString(5,
								format.format(cntryAppy.getEffectiveDate()));
						if (cntryAppy.getExpirationDate() != null) {
							ps.setString(6, format.format(cntryAppy
									.getExpirationDate()));
						} else {
							ps.setNull(6, java.sql.Types.DATE);
						}
						ps.setString(7,cntryAppy.getCreatedUser());
						ps.setString(8,cntryAppy.getModifiedUser());

					}

					public int getBatchSize() {
						return cntryAppyList.size();
					}
				});
		getJdbcTemplate().batchUpdate(ctryAppyIdDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						CountryApplicability cntryAppy = cntryAppyDeleteList.get(i);
						
						ps.setString(1,
								format.format(cntryAppy.getExpirationDate()));						
						ps.setString(2,cntryAppy.getModifiedUser());
						ps.setLong(3,cntryAppy.getCtryAppyId());
					}

					public int getBatchSize() {
						return cntryAppyDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(sysAppyInsertQuery,
				new BatchPreparedStatementSetter() {
					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						SystemApplicability sysAppy = sysAppyList.get(i);
						/*if (sysAppy.getCdValIdBulk().startsWith("NRQ")) {
							ps.setLong(1, sysAppy.getCodeValueId());
						} else {
							ps.setLong(1, new Long(sysAppy.getCdValIdBulk()));
						}*/
						ps.setLong(1, sysAppy.getDnbSystemCode());
						ps.setLong(2, sysAppy.getApplicabilityIndicator());
						if (sysAppy.getCodeTableId() != null) {
							ps.setLong(3, sysAppy.getCodeTableId());
						} else {
							ps.setNull(3, java.sql.Types.VARCHAR);
						}
						if (sysAppy.getCdValIdBulk() != null) {
							if (sysAppy.getCdValIdBulk().startsWith("NRQ")) {
								ps.setLong(4, sysAppy.getCodeValueId());
							} else {
								ps.setLong(4, new Long(sysAppy.getCdValIdBulk()));
							}
						} else {
							ps.setNull(4, java.sql.Types.VARCHAR);
						}
						ps.setString(5,
								format.format(sysAppy.getEffectiveDate()));
						if (sysAppy.getExpirationDate() != null) {
							ps.setString(6,
									format.format(sysAppy.getExpirationDate()));
						} else {
							ps.setNull(6, java.sql.Types.DATE);
						}
						ps.setString(7,sysAppy.getCreatedUser());
						ps.setString(8,sysAppy.getModifiedUser());

					}

					public int getBatchSize() {
						return sysAppyList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(sysAppyIdDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						SystemApplicability sysAppy = sysAppyDeleteList.get(i);
						
						ps.setString(1,
								format.format(sysAppy.getExpirationDate()));						
						ps.setString(2,sysAppy.getModifiedUser());
						ps.setLong(3,sysAppy.getSysAppyId());
					}

					public int getBatchSize() {
						return sysAppyDeleteList.size();
					}
				});

	}

	@SuppressWarnings("rawtypes")
	@Override
	public List<CodeValue> getCodeValueList() {
		String cdValQuery = scotsPropertyFileVO.getCdValSysAppyQuery();
		List<Map<String, Object>>  rows = getJdbcTemplate().queryForList(cdValQuery);
		List<CodeValue> cdValList = new ArrayList<CodeValue>();
		for (Map row : rows) {
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((BigDecimal)row.get("cd_val_id")).longValue());
			codeValue.setCodeTableId(((BigDecimal)row.get("cd_tbl_id")).intValue());
			cdValList.add(codeValue);
		}
		return cdValList;
		
	}
	@Override
	public boolean isSysAppyIdAvail(Long sysAppyId) {
		String getSelectQuery = scotsPropertyFileVO.getSysAppyIdQuery();
		int count = getJdbcTemplate().queryForInt(getSelectQuery,sysAppyId);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
		
	}
	@Override
	public boolean isCdValIdAvail(Long cdValId) {
		String getSelectQuery = scotsPropertyFileVO.getCdValIdCheckQuery();
		int count = getJdbcTemplate().queryForInt(getSelectQuery,cdValId);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
		
	}
	@Override
	public boolean isCdTblIdAvail(Long cdTblId) {
		String getSelectQuery = scotsPropertyFileVO.getCdTblIdCheckQuery();
		int count = getJdbcTemplate().queryForInt(getSelectQuery,cdTblId);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
		
	}
	@Override
	public boolean isCntryIdAvail(Long cntryId) {
		String cntryQuery = scotsPropertyFileVO.getCtryGeoUnitIdQuery();
		int count = getJdbcTemplate().queryForInt(cntryQuery,cntryId);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
		
	}
	@Override
	public boolean isCntryAppyIdAvail(Long cntryAppyId) {
		String cntryAppyIdQuery = scotsPropertyFileVO.getCtryAppyIdQuery();
		int count = getJdbcTemplate().queryForInt(cntryAppyIdQuery,cntryAppyId);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
		
	}
	@Override
	public boolean isCdValTxtIdAvail(Long cdValTxtId) {
		String getCdValTxtIdQuery = scotsPropertyFileVO.getCdValTxtIdQuery();
		int count = getJdbcTemplate().queryForInt(getCdValTxtIdQuery,cdValTxtId);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
		
	}
	@Override
	public boolean isCdAltSchmIdAvail(Long cdAltSchmId) {
		String getCdAltSchmIdQuery = scotsPropertyFileVO.getCdValAltSchmIdQuery();
		int count = getJdbcTemplate().queryForInt(getCdAltSchmIdQuery,cdAltSchmId);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
		
	}
	
	@Override
	public boolean isCdAltSchmTypCdAvail(Long cdAltSchmTypCd) {
		String getCdAltSchmTypCdQuery = scotsPropertyFileVO.getCdValAltSchmTypCdQuery();
		int count = getJdbcTemplate().queryForInt(getCdAltSchmTypCdQuery,cdAltSchmTypCd);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
		
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public List<CodeValue> getCodeValueListForTxt() {
		String cdValQuery = scotsPropertyFileVO.getCdValTxtQuery();
		List<Map<String, Object>>  rows = getJdbcTemplate().queryForList(cdValQuery);
		List<CodeValue> cdValList = new ArrayList<CodeValue>();
		for (Map row : rows) {
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((BigDecimal)row.get("cd_val_id")).longValue());
			codeValue.setCodeTableId(((BigDecimal)row.get("cd_tbl_id")).intValue());
			cdValList.add(codeValue);
		}
		return cdValList;
		
	}

	@Override
	public Long generateCodeValueId() {
		String generateCodeValueIdQuery = scotsPropertyFileVO.getCodeValIdSeqQuery();
		Long codeValueId = getJdbcTemplate().queryForLong(generateCodeValueIdQuery);
		return codeValueId;
	}
	
	
	/** 
	 * This method will get the Last Sequence Number from the CD_VAL_ID_SEQ Sequence
	 * This method will be called before the SCoTS bulk upload loading job starts
	 * 
	 */
	@Override
	public Long getLastSequenceNumber() {			
		String getSequenceNumber = scotsPropertyFileVO.getLastSequenceNumberQuery();		
		Long lastSequenceNumber = getJdbcTemplate().queryForLong(getSequenceNumber);		
		return lastSequenceNumber;
	}
	
	/** 
	 * This method will get the Maximum Sequence Number from the CD_VAL table.
	 * This method will be called after the SCoTS bulk upload fails in loading process.
	 * 
	 */	
	@Override
	public Long getMaxCodeValueId(){
		
		String maxCodeValueIdQuery = scotsPropertyFileVO.getMaxCodeValueIdQuery();
		Long maxCodeValueIdFromDB = getJdbcTemplate().queryForLong(maxCodeValueIdQuery);
		LOGGER.info("ScotsBulkUploadDAOImpl || getMaxCodeValueId || maxCodeValueIdFromDB::"+maxCodeValueIdFromDB);		
		return maxCodeValueIdFromDB;
	}
	
	
	/** 
	 * This method will reset the CD_VAL_ID_SEQ sequence.
	 * This method will be called for resetting the CD_VAL_ID_SEQ sequence after the SCoTS bulk upload fails in loading process.
	 * 
	 */	
	@Override
	public Long resetSequence(Long lastSequence,Long maxCodeValueId){
		
		Long incrementNumber = maxCodeValueId - lastSequence;
		LOGGER.info("ScotsBulkUploadDAOImpl || resetSequence || Increment number :"+incrementNumber);
		String resetSequenceNumber = scotsPropertyFileVO.getResetSequenceNumberQuery()+incrementNumber;
		LOGGER.info("ScotsBulkUploadDAOImpl || resetSequence || Sequence reset Query :"+resetSequenceNumber);
		getJdbcTemplate().execute(resetSequenceNumber);		
		getJdbcTemplate().execute(scotsPropertyFileVO.getCodeValIdSeqQuery());			
		getJdbcTemplate().execute(scotsPropertyFileVO.getAlterSequenceQuery());
		getJdbcTemplate().execute(scotsPropertyFileVO.getCodeValIdSeqQuery());	
		LOGGER.info("ScotsBulkUploadDAOImpl || resetSequence || Sequence value after reset :"+getLastSequenceNumber());	
		return getLastSequenceNumber();
	}
	
}
