/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import com.dnb.dsc.refdata.core.entity.CurrencyExchange;


/**
 * This is used as the DAO interface for the Geography operations
 *
 * @author Cognizant
 * @version last updated : Mar 14, 2012
 * @see
 *
 */
public interface CrcyTransactionalDAO {

	/**
	 * This method will update given exchangeRate to Transaction DB. The return would be
	 * updated CurrencyExchange entity
	 *
	 * @param
	 * @return GeoUnit
	 */
	CurrencyExchange updateExchangeRate(CurrencyExchange currencyExchange);

	/**
	 * The method will validate the Currency Exchange for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param currencyExchangeId
	 */
	String countCurrencyExchange(Long currencyExchangeId);

        /**
	 * Retrieves the CurrencyExchange based on the Work flow Tracking Id.<p>
	 * Invoked from the Work flow Component and the search
	 * will be performed on the Transaction DB.<p>
	 *
	 * @param trackingId
	 * @return CurrencyExchange
	 */
	CurrencyExchange retrieveCurrencyExchangeByTrackingId(Long trackingId);

	/**
	 * The method will remove the crcyExch data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param currencyExchId
	 * @param boolean indicating the status
	 */
	void removeApprovedCurrencyExchange(Long currencyExchId);

	/**
	 * Searches the Transaction SoR for the CurrencyExchange based on the
	 * currencyExchangeId and will return the CurrencyExchange entity.
	 * <p>
	 *
	 * @param currencyExchangeId
	 * @return CurrencyExchange
	 */
	CurrencyExchange retrieveCurrencyExchangeByCurrencyExchangeId(Long currencyExchangeId);

}