package com.dnb.dsc.refdata.dao;

import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;

/**
 * This is used as the DAO interface class for the Xml Schema Elements
 * operations. The DAO contacts the staging DB for all its operations
 *
 * @author Cognizant
 * @version last updated : Apr 13, 2012
 * @see
 *
 */
public interface XmlLabelsTransactionalDAO {

	/**
	 * The method will persist the updated xmlSchemaElement in the Transactional DB.
	 *
	 * @param xmlSchemaElement
	 */

	XmlSchemaElement updateXmlSchemaElement(XmlSchemaElement xmlSchemaElement);

	/**
	 * The method will validate the xmlSchemaElement for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param xmlSchemaElementId
	 */
	public int countXmlSchema(String xmlSchemaElementId);

	/**
	 * The method will search for the xml schema elements details by element id.
	 * The user will pass the element id and the dao layer will retrieve the
	 * corresponfing details
	 * 
	 * @param elementId
	 * @return XmlSchemaElement
	 */
	public XmlSchemaElement retrieveXmlSchemaByXmlElementId(String elementId);
	
	/**
	 * The method will remove the xmlSchemaElement data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param xmlSchemaElementId
	 * @param boolean indicating the status
	 */
	void removeApprovedXmlSchemaLabels(String xmlSchemaElementId);
}
