/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.SCoTsTransactionalDAO;

/**
 * The DAO class which handles the SCoTS Transaction DB Implementation
 *
 *
 * @author	Cognizant
 * @version	last updated : Apr 17, 2012
 * @see
 *
 */
@Repository("SCoTsTransactionalDAO")
public class SCoTsTransactionalDAOImpl implements SCoTsTransactionalDAO{

	private static final Logger LOGGER = LoggerFactory
			.getLogger(SCoTsTransactionalDAO.class);

	@PersistenceContext(unitName = "PU-Transactional")
	private EntityManager em;

	private JdbcTemplate jdbcTemplate;    
	/**
	 *
	 * The method will create the named query instance by setting the query
	 * parameters. The method is invoked for all name query operations.
	 *
	 * @param sql
	 * @param parameters
	 * @return
	 */
	private Query createNamedQuery(String sql, Map<String, Object> parameters) {
		Query query = em.createNamedQuery(sql);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}

	/**
	 * Inject DataSource properties to jdbcTemplate.
	 *
	 * @param argDataSource
	 *            the new data source
	 */
	@Autowired
	@Qualifier("txnDataSource")
	public void setDataSource(DataSource argDataSource) {
		this.jdbcTemplate = new JdbcTemplate(argDataSource);
	}
	/**
	 * The constants for named query - count code table entries
	 */
	private static final String QUERY_COUNT_CODE_TABLE = "CodeTable.countCodeTable";

	/**
	 * The constants for named query - count code value entries
	 */
	private static final String QUERY_COUNT_CODE_VALUE = "CodeValue.countCodeValue";

	/**
	 * The constants for named query - count code value entries
	 */
	private static final String QUERY_COUNT_ALTERNATE_SCHEME_CODE = "CodeValueAlternateScheme.countCodeValueAlternateScheme";

	/**
	 * the query to retrieve all the applicable systems based on the selected
	 * code table
	 */
	private static final String QUERY_RETRIEVE_SYSTEM_APPLICABILITY_FOR_CODE_TABLE_REVIEW = "SystemApplicability.retrieveSystemsForCodeTableReview";


	/**
	 * the query to retrieve all the applicable systems based on the selected
	 * code table
	 */
	private static final String QUERY_RETRIEVE_SYSTEM_APPLICABILITY_FOR_CODE_VALUE_REVIEW = "SystemApplicability.retrieveSystemsForCodeValueReview";


	/**
	 * the query to retrieve all the systems without any filtering
	 */
	private static final String QUERY_RETRIEVE_ALL_SYSTEM_APPLICABILITY = "SystemApplicability.retrieveAllSystems";

	/**
	 * the query to retrieve all the applicable countries based on the selected
	 * code table
	 */
	private static final String QUERY_RETRIEVE_COUNTRY_APPLICABILITY_FOR_REVIEW = "CountryApplicability.retrieveCountriesForReview";

	/**
	 * the query to retrieve all the applicable countries based on the selected
	 * code table
	 */
	private static final String QUERY_RETRIEVE_COUNTRY_APPLICABILITY_FOR_CODE_VALUE_REVIEW = "CountryApplicability.retrieveCountriesForCodeValueReview";

	/**
	 * the query to retrieve all the countries without any filtering
	 */
	private static final String QUERY_RETRIEVE_ALL_COUNTRY_APPLICABILITY = "CountryApplicability.retrieveAllCountries";

	/**
	 * the query to remove code table by id
	 */
	private static final String QUERY_REMOVE_CODE_TABLE_BY_ID = "CodeTable.removeCodeTableById";
	/**
	 * the query to remove SystemApplicability by codeTableId
	 */
	private static final String QUERY_REMOVE_SYSTEM_BY_CODE_TABLE_ID="SystemApplicability.removeSystemByCodeTableById";
	/**
	 * the query to remove CountryApplicability by codeTableId
	 */
	private static final String QUERY_REMOVE_COUNTRY_BY_CODE_TABLE_ID="CountryApplicability.removeCountryByCodeTableById";


	/**
	 * the query to retrieve all the systems saved in the txn database
	 */
	private static final String QUERY_RETRIEVE_TXN_MARKET_APPLICABILITIES = 
			"CountryApplicability.retrieveTxnMarketApplicabilities";

	/**
	 * the query to remove code value by id
	 */
	private static final String QUERY_REMOVE_CODE_VALUE_BY_ID="CodeValue.removeCodeValueById";
	/**
	 * the query to remove code value alternate scheme by id
	 */
	private static final String QUERY_REMOVE_CODE_VALUE_ALTERNATE_SCHEME_BY_TYPE="CodeValueAlternateScheme.removeAlternateSchemeByType";

	private static final String QUERY_RETRIEVE_SYSTEM_APPLICABILITY_FOR_CODE_WITHOUT_DESCRIPTION = "SELECT " +
			"sa.sys_appy_id AS SYS_APPY_ID, sa.dnb_sys_cd AS DNB_SYS_CD, sa.cd_tbl_appy_indc AS CD_TBL_APPY_INDC, " +
			"sa.cd_tbl_id AS CD_TBL_ID, (SELECT ct.cd_tbl_nme FROM sorusr.cd_tbl ct WHERE ct.cd_tbl_id = sa.cd_tbl_id) " +
			"AS CD_TBL_NME, sa.cd_val_id AS CD_VAL_ID, (SELECT cvt.cd_val_desc FROM sorusr.cd_val_txt cvt WHERE " +
			"cvt.cd_val_id = sa.cd_val_id and cvt.lang_cd = 39) AS CD_VAL_DESC, sa.effv_dt AS EFFV_DT, sa.expn_dt AS EXPN_DT, " +
			"sa.row_cre_id AS ROW_CRE_ID, sa.row_cre_tmst AS ROW_CRE_TMST, sa.row_mod_id AS ROW_MOD_ID, " +
			"sa.row_mod_tmst AS ROW_MOD_TMST FROM soruiconfig.sys_appy sa WHERE sa.dnb_sys_cd = :applicabilityCode " +
			"ORDER BY sa.cd_tbl_id, sa.cd_val_id";

	private static final String QUERY_RETRIEVE_MARKET_FOR_CODE_WITHOUT_DESCRIPTION = "SELECT ca.ctry_appy_id , " +
			"ca.ctry_geo_unit_id , ca.cd_tbl_appy_indc AS CD_TBL_APPY_INDC, ca.cd_tbl_id AS CD_TBL_ID, " +
			"(SELECT ct.cd_tbl_nme FROM sorusr.cd_tbl ct WHERE ct.cd_tbl_id = ca.cd_tbl_id) AS CD_TBL_NME, " +
			"ca.cd_val_id AS CD_VAL_ID, (SELECT cvt.cd_val_desc FROM sorusr.cd_val_txt cvt WHERE " +
			"cvt.cd_val_id = ca.cd_val_id and cvt.lang_cd = 39) AS CD_VAL_DESC, ca.effv_dt AS EFFV_DT, " +
			"ca.expn_dt AS EXPN_DT, ca.row_cre_id AS ROW_CRE_ID, ca.row_cre_tmst AS ROW_CRE_TMST, " +
			"ca.row_mod_id AS ROW_MOD_ID, ca.row_mod_tmst AS ROW_MOD_TMST FROM soruiconfig.ctry_appy ca WHERE " +
			"ca.ctry_geo_unit_id = :applicabilityCode ORDER BY ca.cd_tbl_id, ca.cd_val_id";
	/**
	 * the query to retrieve all the systems saved in the txn database
	 */
	private static final String QUERY_RETRIEVE_TXN_SYSTEM_APPLICABILITIES = 
			"SystemApplicability.retrieveTxnSystemApplicabilities";

	/**
	 * the query to remove all the systems saved in the txn database
	 */
	private static final String QUERY_REMOVE_CNTRY_APPY_BY_GEO_UNIT_ID = 
			"CountryApplicability.removeCountryApplicabilities";

	/**
	 * the query to remove all the systems saved in the txn database
	 */
	private static final String QUERY_REMOVE_SYS_APPY_BY_TYP_CD = 
			"SystemApplicability.removeSystemApplicabilities";

	private static final String QUERY_RETRIEVE_CODE_VALUE_ASSOCIATIONS_SELECT = "SELECT a.CD_VAL_ASSN_ID as CD_VAL_ASSN_ID, "
			+ "a.PRNT_CD_VAL_ID as PRNT_CD_VAL_ID, a.CHLD_CD_VAL_ID as CHLD_CD_VAL_ID, a.EFFV_DT as EFFV_DT, " +
			"a.EXPN_DT as EXPN_DT, a.ROW_CRE_ID as ROW_CRE_ID, a.ROW_CRE_TMST as ROW_CRE_TMST, a.ROW_MOD_ID as ROW_MOD_ID, "
			+ "a.ROW_MOD_TMST as ROW_MOD_TMST from soruiconfig.cd_val_assn a ";

	/**
	 * Query to retrieve Code Value associations parent code table id condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN1 = ",sorusr.cd_val c1 ";

	/**
	 * Query to retrieve Code Value associations parent code table id condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN1_1 = " and c1.CD_VAL_ID = a.PRNT_CD_VAL_ID ";

	/**
	 * Query to retrieve Code Value associations child code table id condition
	 */ 
	private static final String QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN2 = ",sorusr.cd_val c2 ";

	/**
	 * Query to retrieve Code Value associations parent code table id condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN2_1 = " and c2.CD_VAL_ID = a.CHLD_CD_VAL_ID ";

	/**
	 * Query to retrieve Code Value associations - append parent code table id
	 * condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VAL_ASSN_PRNT_CDTBL_ID = " and c1.CD_TBL_ID = :parentCodeTableId ";

	/**
	 * Query to retrieve Code Value associations - append parent code table id
	 * condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VAL_ASSN_CHLD_CDTBL_ID = " and c2.CD_TBL_ID = :childCodeTableId ";

	/**
	 * Query to retrieve Code Value associations - append parent code table id
	 * condition
	 */
	private static final String QUERY_REMOVE_CODE_RELATIONSHIP_BY_TBL_ID = "CodeValueAssociation.removeCodeValueAssociationsByTableId";

	/**
	 * Query to retrieve Code Value Alt Scheme - fetch by scheme type code
	 */
	private static final String QUERY_RETRIEVE_ALT_SCHEME_BY_CODE_TYPE = "CodeValueAlternateScheme.retrieveSchemeCodesByType";

	/**
	 * the query to remove code value by id
	 */
	private static final String QUERY_REMOVE_SYSTEM_BY_CODE_VALUE_ID = "SystemApplicability.removeSystemAppyByCodeValueId";

	/**
	 * the query to remove code value by id
	 */
	private static final String QUERY_REMOVE_COUNTRY_BY_CODE_VALUE_ID = "CountryApplicability.removeCountryAppyByCodeValueId";

	/**
	 * the query to remove code value by id
	 */
	private static final String QUERY_REMOVE_TEXT_BY_CODE_VALUE_ID = "CodeValueText.removeTextByCodeValueId";

	private static final String QUERY_LOCK_SYSTEM_APPLICABILITY_FOR_EDIT = "SystemApplicability.lockSystemApplicabilityForEdit";
	private static final String QUERY_LOCK_MARKET_APPLICABILITY_FOR_EDIT = "CountryApplicability.lockCountryApplicabilityForEdit";

	/**
	 * the query to retrieve savedRecord by domain name
	 */
	private static final String QUERY_RETRIEVE_SAVED_RECORDS_BY_DOMAIN_NAME= "SavedRecord.retrieveByDomainName";

	/**
	 * the query to retrieve scots Relationship modified user from transactional DB to check for locks
	 */

	private static final String QUERY_COUNT_SCOTS_RELATIONSHIP= "SELECT  cva.ROW_MOD_ID as ROW_MOD_ID from soruiconfig.cd_val_assn cva"
			+" where cva.PRNT_CD_VAL_ID in (select cd_val_id from sorusr.cd_val where expn_dt is null and cd_tbl_id=:parentTableId )"
			+" and cva.CHLD_CD_VAL_ID in (select cd_val_id from sorusr.cd_val where expn_dt is null and cd_tbl_id=:childTableId)";

	

	/**
	 * The method will persist the existing Code Table data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	@Override
	public CodeTable updateCodeTable(CodeTable codeTable) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | updateCodeTable");
		try {
			return em.merge(codeTable);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will persist the existing Code Value data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	@Override
	public CodeValue updateCodeValue(CodeValue codeValue) {
		LOGGER.info("entering SCoTsTransactionalDAOImpl | updateCodeTable");
		try {
			return em.merge(codeValue);
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will persist the existing Applicability data in the Transaction
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	@Override
	public SystemApplicability updateSystemApplicability(
			SystemApplicability systemApplicability) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | updateSystemApplicability");

		LOGGER.info("exiting ScotsTransactionalDAOImpl | updateSystemApplicability || entered into db :"
				+ systemApplicability);
		try {
			return em.merge(systemApplicability);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will persist the existing Applicability data in the Transaction
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	@Override
	public CountryApplicability updateCountryApplicability(
			CountryApplicability countryApplicability) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | updateCountryApplicability");
		LOGGER.info("exiting ScotsTransactionalDAOImpl | updateCountryApplicability || entered into db :"
				+ countryApplicability);
		try {
			return em.merge(countryApplicability);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will validate the CodeTable for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param codeTableId
	 */
	public String countCodeTable(Long codeTableId) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | countCodeTable");		
		String lockedUser = null;
		try {
			CodeTable modifiedUser = (CodeTable)em.find(CodeTable.class, codeTableId);
			if(modifiedUser != null){
				lockedUser = modifiedUser.getModifiedUser();
			}
			return lockedUser;
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will validate the Code Value for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transaction DB.
	 *
	 * @param currencyExchangeId
	 */
	public String countCodeValue(Long codeValueId) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | countCodeValue");
		String lockedUser = null;
		try {
			CodeValue modifiedUser = (CodeValue)em.find(CodeValue.class, codeValueId);
			if(modifiedUser != null){
				lockedUser = modifiedUser.getModifiedUser();				
			}	
			return lockedUser;
		}catch(NoResultException ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will validate the alternateSchemeTypeCode for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param alternateSchemeTypeCode
	 */
	@SuppressWarnings("unchecked")
	public String countAlternateSchemeTypeCode(Long alternateSchemeTypeCode) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | countCodeValue");			
		Query query = em.createNamedQuery(QUERY_COUNT_ALTERNATE_SCHEME_CODE);		
		query.setParameter("alternateSchemeTypeCode", alternateSchemeTypeCode);	




		String lockedUser =null;
		try {			
			List<CodeValueAlternateScheme> modifiedUser = query.getResultList();			 
			if(modifiedUser!=null && !(modifiedUser.isEmpty())){
				for (CodeValueAlternateScheme codeValueAlternateScheme : modifiedUser) {				
					lockedUser = codeValueAlternateScheme.getModifiedUser();
				}
			}

			return lockedUser;
		}catch(NoResultException ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method to find the CodeTable entity by the primary key codeTableId
	 *
	 * @param codeTableId
	 * @return CodeTable entity
	 */
	public CodeTable retrieveCodeTableById(Long codeTableId) {
		CodeTable codeTable = null;
		try {
			codeTable = em.find(CodeTable.class, codeTableId);
		} catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		codeTable.setSystemApplicability(retrieveSystemApplicability(codeTableId));
		codeTable.setCountryApplicability(retrieveCountryApplicability(codeTableId));
		LOGGER.info("exiting SCoTsTransactionalDAOImpl | retrieveCodeTableById | codeTable :" + codeTable );

		return codeTable;
	}
	/**
	 *
	 * The method to find the CodeValue entity by the primary key codeValueId
	 *
	 * @param codeTableId
	 * @return CodeTable entity
	 */
	@SuppressWarnings("null")
	public CodeValue retrieveCodeValueById(Long codeValueId) {
		CodeValue codeValue = null;
		List<SystemApplicability> systemApplicabilityFirst  = null;
		List<SystemApplicability> systemApplicabilityFinal = null;


		try {
			codeValue = em.find(CodeValue.class, codeValueId);



		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		codeValue.setSystemApplicability(retrieveSystemApplicabilityForCodeValue(codeValueId));
		System.out.println("CodeValue"+codeValue);

		codeValue.setCountryApplicability(retrieveCountryApplicabilityForCodeValue(codeValueId));
		LOGGER.info("exiting SCoTsTransactionalDAOImpl | retrieveCodeValueById  || codeValue:" + codeValue );

		return codeValue;
	}
	/**
	 * The method will retrieve all systems applicable from the Search DB . The
	 * return type is a VO which contains the DNB system code and the Code Value
	 * Description.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<SystemApplicability> retrieveSystemApplicability(Long codeTableId) {
		if (codeTableId != null && codeTableId != -1L) {
			// Setting parameter codeTableId
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("codeTableId", codeTableId);
			Query query = createNamedQuery(QUERY_RETRIEVE_SYSTEM_APPLICABILITY_FOR_CODE_TABLE_REVIEW, parameters);
			try {
				return query.getResultList();
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		} else {
			return retrieveAllSystemApplicabilities();
		}

	}
	/**
	 * The method will retrieve all systems applicable from the Search DB . The
	 * return type is a VO which contains the DNB system code and the Code Value
	 * Description.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<SystemApplicability> retrieveSystemApplicabilityForCodeValue(Long codeValueId) {
		if (codeValueId != null && codeValueId != -1L) {
			// Setting parameter codeValueId
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("codeValueId", codeValueId);
			Query query = createNamedQuery(QUERY_RETRIEVE_SYSTEM_APPLICABILITY_FOR_CODE_VALUE_REVIEW, parameters);
			try {
				return query.getResultList();
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		} else {
			return retrieveAllSystemApplicabilities();
		}	
	}
	/**
	 * 
	 * The generic method which returns all system applicabilities
	 *
	 * @return system applicability
	 */
	@SuppressWarnings("unchecked")
	private List<SystemApplicability> retrieveAllSystemApplicabilities() {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("codeTableId", RefDataUIConstants.CODE_TABLE_ID_FOR_ALL_SYSTEMS);
		parameters.put("dnbSystemCode", RefDataUIConstants.DNB_SYSTEM_CODE_FOR_ALL_SYSTEMS);
		Query query = createNamedQuery(QUERY_RETRIEVE_ALL_SYSTEM_APPLICABILITY, parameters);
		try {
			return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * The method will retrieve all countries applicable from the Search DB .
	 * The return type is a VO which contains the DNB system code and the Code
	 * Value Description.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<CountryApplicability> retrieveCountryApplicability(Long codeTableId) {
		LOGGER.info("entering SCoTsDAOImpl | retrieveCountryApplicability");
		try {
			if (codeTableId != null && codeTableId != -1L) {
				// Setting parameter codeTableId
				Map<String, Object> parameters = new HashMap<String, Object>();
				parameters.put("codeTableId", codeTableId);
				Query query = createNamedQuery(
						QUERY_RETRIEVE_COUNTRY_APPLICABILITY_FOR_REVIEW , parameters);
				LOGGER.info("exiting SCoTsDAOImpl | retrieveCountryApplicability");
				return query.getResultList();
			} else {
				Query query = em.createNamedQuery(QUERY_RETRIEVE_ALL_COUNTRY_APPLICABILITY);
				LOGGER.info("exiting SCoTsDAOImpl | retrieveCountryApplicability");
				return query.getResultList();
			}
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * The method will retrieve all countries applicable from the Search DB .
	 * The return type is a VO which contains the DNB system code and the Code
	 * Value Description.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<CountryApplicability> retrieveCountryApplicabilityForCodeValue(Long codeValueId) {
		LOGGER.info("entering SCoTsDAOImpl | retrieveCountryApplicabilityForCodeValue");

		if (codeValueId != null && codeValueId != -1L) {
			// Setting parameter codeTableId
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("codeValueId", codeValueId);
			Query query = createNamedQuery(
					QUERY_RETRIEVE_COUNTRY_APPLICABILITY_FOR_CODE_VALUE_REVIEW , parameters);
			LOGGER.info("exiting SCoTsDAOImpl | retrieveCountryApplicabilityForCodeValue");
			try {
				return query.getResultList();
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		}
		return null;
	}
	/**
	 * The method will remove the CodeTable data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param codeTableId
	 * @param boolean indicating the status
	 */
	@Override
	public void removeApprovedCodeTable(Long codeTableId) {
		LOGGER.info("entering SCoTsDAOImpl | removeApprovedCodeTable");
		// remove the industry Code details from the table
		Query query = em.createNamedQuery(QUERY_REMOVE_CODE_TABLE_BY_ID);
		query.setParameter("codeTableId", codeTableId);
		try {
			query.executeUpdate();
			query = em.createNamedQuery(QUERY_REMOVE_SYSTEM_BY_CODE_TABLE_ID);
			query.setParameter("codeTableId", codeTableId);
			query.executeUpdate();
			query = em.createNamedQuery(QUERY_REMOVE_COUNTRY_BY_CODE_TABLE_ID);
			query.setParameter("codeTableId", codeTableId);
			query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting SCoTsDAOImpl | removeApprovedCodeTable");
	}
	/**
	 * The method will remove the codeValue data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param codeValueId
	 * @param boolean indicating the status
	 */
	@Override
	public void removeApprovedCodeValue(Long codeValueId) {
		LOGGER.info("entering SCoTsDAOImpl | removeApprovedCodeValue");
		// remove the industry Code details from the table
		Query query = em.createNamedQuery(QUERY_REMOVE_CODE_VALUE_BY_ID);
		query.setParameter("codeValueId", codeValueId);
		try {
			query.executeUpdate();
			query = em.createNamedQuery(QUERY_REMOVE_SYSTEM_BY_CODE_VALUE_ID);
			query.setParameter("codeValueId", codeValueId);
			query.executeUpdate();
			query = em.createNamedQuery(QUERY_REMOVE_COUNTRY_BY_CODE_VALUE_ID);
			query.setParameter("codeValueId", codeValueId);
			query.executeUpdate();
			query = em.createNamedQuery(QUERY_REMOVE_TEXT_BY_CODE_VALUE_ID);
			query.setParameter("codeValueId", codeValueId);
			query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting SCoTsDAOImpl | removeApprovedCodeValue");
	}
	/**
	 * The method will remove the codeValueAlternateScheme data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param alternateSchemeTypeCode
	 * @param boolean indicating the status
	 */
	@Override
	public void removeApprovedCodeValueAlternateScheme(Long alternateSchemeTypeCode) {
		LOGGER.info("entering SCoTsDAOImpl | removeApprovedCodeValueAlternateScheme");
		// remove the industry Code details from the table
		Query query = em.createNamedQuery(QUERY_REMOVE_CODE_VALUE_ALTERNATE_SCHEME_BY_TYPE);
		query.setParameter("alternateSchemeTypeCode", alternateSchemeTypeCode);
		try {
			query.executeUpdate();
			LOGGER.info("exiting SCoTsDAOImpl | removeApprovedCodeValueAlternateScheme");
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<Object> retrieveSystemForCode(String applicability, Long applicabilityCode) {
		LOGGER.info("entering SCoTsTransactionalDAOImpl | retrieveSystemForCode");
		try {
			if ("System".equals(applicability.trim())) {			
				StringBuffer queryStr = new StringBuffer(QUERY_RETRIEVE_SYSTEM_APPLICABILITY_FOR_CODE_WITHOUT_DESCRIPTION);
				List sysApplicabilities = jdbcTemplate.query(queryStr.toString(), 
						new Object[] { applicabilityCode }, new RowMapper<SystemApplicability>() {
					@Override
					public SystemApplicability mapRow(ResultSet rs, int arg1) throws SQLException {
						SystemApplicability sysAppy = new SystemApplicability();
						sysAppy.setSysAppyId(rs.getLong("SYS_APPY_ID"));
						sysAppy.setDnbSystemCode(rs.getLong("DNB_SYS_CD"));
						sysAppy.setApplicabilityIndicator(rs.getInt("CD_TBL_APPY_INDC"));
						sysAppy.setCodeTableId(rs.getLong("CD_TBL_ID"));
						sysAppy.setCodeTableName(rs.getString("CD_TBL_NME"));
						sysAppy.setCodeValueId(rs.getLong("CD_VAL_ID"));
						sysAppy.setCodeValueDescription(rs.getString("CD_VAL_DESC"));
						sysAppy.setEffectiveDate(rs.getDate("EFFV_DT"));
						sysAppy.setExpirationDate(rs.getDate("EXPN_DT"));
						sysAppy.setCreatedDate(rs.getDate("ROW_CRE_TMST"));
						sysAppy.setModifiedDate(rs.getDate("ROW_MOD_TMST"));
						sysAppy.setCreatedUser(rs.getString("ROW_CRE_ID"));
						sysAppy.setModifiedUser(rs.getString("ROW_MOD_ID"));
						return sysAppy;
					}
				});
				return sysApplicabilities;

			} else if ("Market".equals(applicability.trim())) {

				StringBuffer queryStr = new StringBuffer(QUERY_RETRIEVE_MARKET_FOR_CODE_WITHOUT_DESCRIPTION);
				List countryApplicabilities = jdbcTemplate.query(queryStr.toString(), 
						new Object[] { applicabilityCode }, new RowMapper<CountryApplicability>() {
					@Override
					public CountryApplicability mapRow(ResultSet rs, int arg1) throws SQLException {
						CountryApplicability ctryAppy = new CountryApplicability();
						ctryAppy.setCtryAppyId(rs.getLong("CTRY_APPY_ID"));
						ctryAppy.setCountryGeoUnitId(rs.getLong("CTRY_GEO_UNIT_ID"));
						ctryAppy.setApplicabilityIndicator(rs.getInt("CD_TBL_APPY_INDC"));
						ctryAppy.setCodeTableId(rs.getLong("CD_TBL_ID"));
						ctryAppy.setCodeTableName(rs.getString("CD_TBL_NME"));
						ctryAppy.setCodeValueId(rs.getLong("CD_VAL_ID"));
						ctryAppy.setCodeValueDescription(rs.getString("CD_VAL_DESC"));
						ctryAppy.setEffectiveDate(rs.getDate("EFFV_DT"));
						ctryAppy.setExpirationDate(rs.getDate("EXPN_DT"));
						ctryAppy.setCreatedDate(rs.getDate("ROW_CRE_TMST"));
						ctryAppy.setModifiedDate(rs.getDate("ROW_MOD_TMST"));
						ctryAppy.setCreatedUser(rs.getString("ROW_CRE_ID"));
						ctryAppy.setModifiedUser(rs.getString("ROW_MOD_ID"));
						return ctryAppy;
					}
				});
				return countryApplicabilities;
			}
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return null;
	}

	/**
	 * 
	 * The method to retrieve the MarketApplicabilities for a given market applicability type. 
	 *
	 * @param domainId
	 * @return marketApplicabilities
	 */
	@SuppressWarnings("unchecked")
	public List<CountryApplicability> retrieveTxnMarketApplicabilities(Long domainId) {
		LOGGER.info("entering SCoTsTransactionalDAOImpl | retrieveTxnMarketApplicabilities");

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("countryGeoUnitId", domainId);
		Query query = createNamedQuery(QUERY_RETRIEVE_TXN_MARKET_APPLICABILITIES, parameters);

		LOGGER.info("exiting SCoTsTransactionalDAOImpl | retrieveTxnMarketApplicabilities");
		try {
			return query != null ? query.getResultList() : null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * 
	 * The method to retrieve the SystemApplicabilities for a given system applicability type. 
	 *
	 * @param domainId
	 * @return systemApplicabilities
	 */
	@SuppressWarnings("unchecked")
	public List<SystemApplicability> retrieveTxnSystemApplicabilities(Long domainId) {
		LOGGER.info("entering SCoTsTransactionalDAOImpl | retrieveTxnSystemApplicabilities");

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("dnbSystemCode", domainId);
		Query query = createNamedQuery(QUERY_RETRIEVE_TXN_SYSTEM_APPLICABILITIES, parameters);

		LOGGER.info("exiting SCoTsTransactionalDAOImpl | retrieveTxnSystemApplicabilities");
		try {
			return query != null ? query.getResultList() : null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will remove the country appy data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param domainId
	 */
	public void removeApprovedCountryApplicabilities(Long domainId) {
		Query query = em.createNamedQuery(QUERY_REMOVE_CNTRY_APPY_BY_GEO_UNIT_ID);
		query.setParameter("countryGeoUnitId", domainId);
		try {
			query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will remove the system appy data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param domainId
	 */
	public void removeApprovedSystemApplicabilities(Long domainId) {
		Query query = em.createNamedQuery(QUERY_REMOVE_SYS_APPY_BY_TYP_CD);
		query.setParameter("dnbSystemCode", domainId);
		try {
			query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will persist the existing CodeValueAssociation in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param codeValueAssociation
	 */
	@Override
	public CodeValueAssociation updateCodeValueAssociation(CodeValueAssociation codeValueAssociation) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | updateCodeValueAssociation");
		try {
			return em.merge(codeValueAssociation);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will persist the existing CodeValue Alternate Scheme in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param codeValueAlternateScheme
	 */
	@Override
	public CodeValueAlternateScheme updateCodeValueAlternateScheme(CodeValueAlternateScheme codeValueAlternateScheme) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | updateCodeValueAssociation");
		try {
			return em.merge(codeValueAlternateScheme);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method to retrieve all codeValue associations from database. The
	 * method will accept the parent and child code table Id s and will return
	 * all associations having the relationship between the specified parent and
	 * child code tables.
	 * 
	 * @param parentCodeTableId
	 * @param childCodeTableId
	 * @return List<CodeValueAssociation>
	 */
	@Override
	public List<CodeValueAssociation> retrieveCodeValueAssociations(
			Long parentCodeTableId, Long childCodeTableId) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | retrieveCodeValueAssociations");

		StringBuffer queryStr = new StringBuffer();
		// append the select clause
		queryStr.append(QUERY_RETRIEVE_CODE_VALUE_ASSOCIATIONS_SELECT);

		// append the code value table join condition
		if(parentCodeTableId != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN1);
		}
		if(childCodeTableId != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN2);
		}
		queryStr.append("WHERE 1 = 1 ");

		// append the parentCodeTableId condition
		if(parentCodeTableId != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN1_1);
			queryStr.append(QUERY_RETRIEVE_CODE_VAL_ASSN_PRNT_CDTBL_ID);
		}
		// append the parentCodeTableId condition
		if(childCodeTableId != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN2_1);
			queryStr.append(QUERY_RETRIEVE_CODE_VAL_ASSN_CHLD_CDTBL_ID);
		}
		List<CodeValueAssociation> associations = null;
		try {
			associations = jdbcTemplate.query(queryStr.toString(), 
					new Object[] { parentCodeTableId, childCodeTableId }, new RowMapper<CodeValueAssociation>() {
				@Override
				public CodeValueAssociation mapRow(ResultSet rs, int arg1) throws SQLException {
					CodeValueAssociation association = new CodeValueAssociation();
					association.setCodeValueAssociationId(rs.getLong("CD_VAL_ASSN_ID"));
					association.setParentCodeValueId(rs.getLong("PRNT_CD_VAL_ID"));
					association.setChildCodeValueId(rs.getLong("CHLD_CD_VAL_ID"));
					association.setEffectiveDate(rs.getDate("EFFV_DT"));
					association.setExpirationDate(rs.getDate("EXPN_DT"));
					association.setCreatedDate(rs.getDate("ROW_CRE_TMST"));
					association.setModifiedDate(rs.getDate("ROW_MOD_TMST"));
					association.setCreatedUser(rs.getString("ROW_CRE_ID"));
					association.setModifiedUser(rs.getString("ROW_MOD_ID"));
					return association;
				}
			});
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting ScotsTransactionalDAOImpl | retrieveCodeValueAssociations");
		return associations;
	}

	/**
	 * 
	 * The method to update the CodeValueText into the Transaction DB
	 *
	 * @param codeValueText
	 * @return CodeValueText
	 */
	public Long updateCodeValueText(CodeValueText codeValueText) {
		CodeValueText updatedCdValtext = null;
		try {
			updatedCdValtext = em.merge(codeValueText);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return updatedCdValtext.getCodeValueTextId();
	}

	/**
	 *
	 * The method will return the max value for the next code value id
	 *
	 * @return codeValueId
	 */
	public Long retrieveMaxCodeValueId() {
		try {
			return jdbcTemplate.queryForLong("SELECT soruiconfig.CD_VAL_ID_SEQ.nextval from dual");
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method will return the max value for the next code table id
	 *
	 * @return codeTableId
	 */
	@Override
	public Long retrieveMaxCodeTableId() {
		try {
			return jdbcTemplate.queryForLong("SELECT soruiconfig.CD_TBL_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method will return the max value for the next code table id
	 *
	 * @return codeTableId
	 */
	@Override
	public Long retrieveFirstCodeTableId() {
		try {
			return jdbcTemplate.queryForLong("SELECT cd_tbl_id from soruiconfig.CD_TBL WHERE rownum=1");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * 
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the staging
	 * DB to fetch all alternate scheme codes matching the scheme type code
	 * selected by the user.
	 * 
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueAlternateScheme> retrieveAlternateSchemeCodes(
			Long schemeTypeCode) {
		LOGGER.info("retrieveAlternateSchemeCodes | schemeTypeCode " + schemeTypeCode);
		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_ALT_SCHEME_BY_CODE_TYPE);
		query.setParameter("alternateSchemeTypeCode", schemeTypeCode);
		try {
			return (List<CodeValueAlternateScheme>)query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * The method will remove the codeTable data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param associationIds
	 */
	public void removeApprovedCodeRelationship(List<Long> associationIds) {
		Query query = em.createNamedQuery(QUERY_REMOVE_CODE_RELATIONSHIP_BY_TBL_ID);
		query.setParameter("associationIds", associationIds);
		try {
			query.executeUpdate();
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * If applicability is "System", value of dnbSystemCode will be dnbSystemCode
	 * in sys_appy table. If it is "Market", value of dnbSystemCode will be 
	 * ctry_geo_unit_id in ctry_appy table. This method checks if the applicability 
	 * with given dnbSystemCode is already present in transactional db. If it exists, 
	 * the return map will contain isLocked=true and username=modifiedUser. Else the 
	 * map will contain isLocked=false and username="".
	 * 
	 * @param dnbSystemCode
	 * @param applicability
	 * @return map
	 */
	@Override
	public Map<String, Object> lockApplicabilityForEdit(Long dnbSystemCode, String applicability){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Query query = null;
		try {
			if("System".equalsIgnoreCase(applicability)){
				query = em.createNamedQuery(QUERY_LOCK_SYSTEM_APPLICABILITY_FOR_EDIT);
				query.setParameter("dnbSystemCode", dnbSystemCode);
				SystemApplicability sa = (SystemApplicability) query.getSingleResult();
				resultMap.put("isLocked", true);
				resultMap.put("username", sa.getModifiedUser());
			}else if("Market".equalsIgnoreCase(applicability)){
				query = em.createNamedQuery(QUERY_LOCK_MARKET_APPLICABILITY_FOR_EDIT);
				query.setParameter("countryGeoUnitId", dnbSystemCode);
				CountryApplicability ca = (CountryApplicability) query.getSingleResult();
				resultMap.put("isLocked", true);
				resultMap.put("username", ca.getModifiedUser());
			}
		}catch(NoResultException nre){
			resultMap.put("isLocked", false);
			resultMap.put("username", "");
		}catch(NonUniqueResultException nue){
			resultMap.put("isLocked", true);
			resultMap.put("username", "more than one users");
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return resultMap;
	}
	/**
	 * This method will retrieve the saved records from the transaction db.
	 * @param domainName
	 * @return resultMap
	 */
	@Override
	@SuppressWarnings("unchecked")
	public  Map<String, List<SavedRecord>> retrieveSavedRecordsByDomainName(String domainName){
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveSavedRecordsByDomainName");
		/*
		 * Set the parameters for the named query to retrieve saved records unit by domain name
		 */

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("domainName",domainName);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(QUERY_RETRIEVE_SAVED_RECORDS_BY_DOMAIN_NAME);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveSavedRecordsByDomainName");
		Map<String, List<SavedRecord>> resultMap = null;
		try{
			resultMap = constructCodeValueMap(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return resultMap;
	}
	/**
	 * The method will construct the map from the list of SavedRecord entity
	 * objects. The key for the map will be the domain Name and the value will
	 * be the entire SavedRecord entity as such.
	 * 
	 * @param savedRecords
	 * @return savedRecordMap
	 */
	private Map<String, List<SavedRecord>> constructCodeValueMap(
			List<SavedRecord> savedRecords) {
		Map<String, List<SavedRecord>> savedRecordMap = new HashMap<String, List<SavedRecord>>();
		List<SavedRecord> valuesList = null;
		for (SavedRecord savedRecord : savedRecords) {
			valuesList = savedRecordMap.get(savedRecord
					.getDomainName());
			if (valuesList == null) {
				valuesList = new ArrayList<SavedRecord>();
			}
			valuesList.add(savedRecord);
			savedRecordMap.put(savedRecord.getDomainName(),
					valuesList);
		}
		return savedRecordMap;
	}

	/** Implemented to fix 209048785 -Edit SCoTS Approval Page**/

	public CodeValue update(CodeValue codeVal,String ApproverId){
		CodeValue codeVals = null;
		try {
			codeVals = em.find(CodeValue.class, codeVal.getCodeValueId());

		} catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		codeVals.setBusinessDescription(codeVal.getBusinessDescription());
		codeVals.setReasonText(codeVal.getReasonText());
		codeVals.setModifiedDate( new Date());
		codeVals.setModifiedUser(ApproverId);
		LOGGER.info("exiting SCoTsTransactionalDAOImpl | retrieveCodeTableById | codeTable :" + codeVals );

		return codeVals;


	}

	/**
	 * The method will validate the Code Value for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transaction DB.
	 *
	 * @param currencyExchangeId
	 */

	@SuppressWarnings("unchecked")
	@Override
	public String countCodeRealtionship(Long parentTableId, Long childTableId) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | countCodeRealtionship");

		StringBuffer queryStr = new StringBuffer();
		queryStr.append(QUERY_COUNT_SCOTS_RELATIONSHIP);
		String modifiedUser=null;
		List<CodeValueAssociation> associations = null;
		try {
			associations = jdbcTemplate.query(queryStr.toString(), 
					new Object[] { parentTableId, childTableId }, new RowMapper<CodeValueAssociation>() {				
				@Override
				public CodeValueAssociation mapRow(ResultSet rs, int arg1) throws SQLException {
					CodeValueAssociation association = new CodeValueAssociation();
					association.setModifiedUser(rs.getString("ROW_MOD_ID"));
					return association;
				}	
			});			
			if (!associations.isEmpty()){
				CodeValueAssociation codeValueAssociation=associations.get(0);
				modifiedUser=codeValueAssociation.getModifiedUser();
			}
			LOGGER.info("exiting ScotsTransactionalDAOImpl | retrieveCodeValueAssociations");
			return modifiedUser;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}

	}





}
