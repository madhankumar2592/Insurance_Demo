/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.DnbUnusAdr;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsyCtryAppy;
import com.dnb.dsc.refdata.core.entity.DnbUnusIndNme;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeInferment;
import com.dnb.dsc.refdata.core.entity.DnbUnusTlcmAdr;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ControlWordsSearchVO;

/**
 * This is used as the DAO interface for the Control Words operations
 * 
 * @author Cognizant
 * @version last updated : May 03, 2012
 * @see
 * 
 */
public interface CtrlWrdsStagingDAO {

	
	/**
	 * The method will provide list of Offensive words based
	 * 
	 * @param OffensiveWord
	 * @return List of Offensive Words
	 */
	List<DnbUnusGlsy> searchByOffensiveWord(ControlWordsSearchVO controlWordsSearchVO);

	/**
	 * 
	 * The method to retrieve all control words type codes
	 *
	 * @return
	 */
	List<CodeValueText> retrieveAllControlWords();
	/**
	 * 
	 * The method to retrieve control word by control word identifier
	 *
	 * @param dnbUnusGlsyId
	 * @return
	 */
	DnbUnusGlsy retrieveControlWordById(Long dnbUnusGlsyId);
	/**
	 * 
	 * The method to update control word
	 *
	 * @param dnbUnusGlsy
	 * @return
	 */
	DnbUnusGlsy updateControlWord(DnbUnusGlsy dnbUnusGlsy);
	/**
	 * 
	 * The method to update unusable glossary country applicability
	 *
	 * @param dnbUnusGlsyCtryAppy
	 * @return
	 */
	DnbUnusGlsyCtryAppy updateDnbUnusGlsyCtryAppy(DnbUnusGlsyCtryAppy dnbUnusGlsyCtryAppy);
	/**
	 * 
	 * The method to update the unusable glossary individual name 
	 *
	 * @param dnbUnusIndNme
	 * @return
	 */
	DnbUnusIndNme updateDnbUnusIndNme(DnbUnusIndNme dnbUnusIndNme);
	/**
	 * 
	 * The method to update the unusable glossary address
	 *
	 * @param dnbUnusAdr
	 * @return
	 */
	DnbUnusAdr updateDnbUnusAdr(DnbUnusAdr dnbUnusAdr);
	/**
	 * 
	 * The method to update the unusable glossary telecommunication address
	 *
	 * @param dnbUnusTlcmAdr
	 * @return
	 */
	DnbUnusTlcmAdr updateDnbUnusTlcmAdr(DnbUnusTlcmAdr dnbUnusTlcmAdr);
	/**
	 * 
	 * The method to update the phone area code
	 *
	 * @param phoneAreaCode
	 * @return
	 */
	PhoneAreaCode updatePhoneAreaCode(PhoneAreaCode phoneAreaCode);

	/**
	 * 
	 * The method to retrieve all applicable country codes for the Area Code Numbers
	 *
	 * @param geoUnitTypeCode
	 * @return codeValueVOs
	 */
	List<CodeValueVO> retrieveAllAreaCodeGeoUnits(Long geoUnitTypeCode);
	
	/**
	 * 
	 * Performs a hierarchy search of Phone Area Code on the search db.
	 * <p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param controlWordsSearchVO
	 * @return list of PhoneAreaCode
	 */
	List<PhoneAreaCode> searchAreaCodeNumbers(ControlWordsSearchVO controlWordsSearchVO);

	/**
	 * 
	 * The method will count the records in the hierarchy search of control words on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param controlWordsSearchVO
	 * @return countResults
	 */
	Long countSearchAreaCodeNumbers(ControlWordsSearchVO controlWordsSearchVO);
        /**
	 * The method will retrieve all Legal Form Class Codes from the Search DB .
	 * The return type is a VO which contains the Legal Form Class Codes and the
	 * Code Value Descriptions.
	 */
	List<CodeValueVO> retrieveLegalFormClassCodes();
	/**
	 * The method will retrieve all Legal Form Languages from the Search DB .
	 * The return type is a VO which contains the Legal Form Language code and the
	 * Code Value Descriptions.
	 */
	List<CodeValueVO> retrieveLegalFormLanguages();
	/**
	 * The method will retrieve all Legal Form Codes from the Search DB .
	 * The return type is a VO which contains the Legal Form Codes and the
	 * Code Value Descriptions.
	 */
	List<CodeValueVO> retrieveLegalFormCodes();
	/**
	 * The method will retrieve all Legal Form Countries from the Search DB .
	 * The return type is a VO which contains the Legal Form Country code and the
	 * Code Value Descriptions.
	 */
	List<CodeValueVO> retrieveLegalFormCountries();
	/**
	 * 
	 * The method will perform a hierarchy search of inferment text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return list of inferment text
	 */
	List<InfermentText> searchLegalFormInfermentText(ControlWordsSearchVO searchCriteriaVO);
	/**
	 * 
	 * The method will perform a hierarchy search of inferment text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return count of inferment text
	 */
	Long countSearchLegalFormInfermentText(ControlWordsSearchVO searchCriteriaVO);
	/**
	 * 
	 * Fetches the InfermentText entity by the  key infermentTextId.<p>
	 * 
	 * @param infermentTextId
	 * @return InfermentText entity
     * @throws Exception 
	 */
	List<IndustryCodeInferment> retrieveIndustryCodeTypeAndDesc(Integer codeTableId,Long languageCode);
	/**
	 * 
	 * The method to retrieve all language codes in control words
	 *
	 * @return
	 */
	List<IndustryCodeInferment> retrieveLanguageCode();
	/**
	 * 
	 * The method to retrieve industry code description
	 *
	 * @param industryCodeTypeCode
	 * @return
	 */
	List<IndustryCode> retrieveIndustryCodeDescription(Long industryCodeTypeCode);
	/**
	 * 
	 * The method to count the search results of industry code inferment
	 *
	 * @param industryCodesInfermentSearchCriteria
	 * @return
	 */
	Long countSearchIndustryCodesInferment(
	        ControlWordsSearchVO industryCodesInfermentSearchCriteria);
	/**
	 * 
	 * The method to retrieve the search results of industry code inferment
	 *
	 * @param industryCodesInfermentSearchCriteria
	 * @return
	 */
	List<IndustryCodeInferment> searchIndustryCodesInferment(
			ControlWordsSearchVO industryCodesInfermentSearchCriteria);

	/**
	 * 
	 * The method to retrieve the search results of industry code inferment
	 *
	 * @param infermentText
	 * @return
	 */
	IndustryCodeInferment industryCodeInfermentSearchView(Long infermentText);
	
	/**
	 * 
	 * The method to retrieve the Inferment text by text identifier
	 *
	 * @param infermentTextId
	 * @return
	 */
	InfermentText retrieveInfermentTextByInfermentTextId(Long infermentTextId);

	/**
	 * 
	 * The method to retrieve the list of all industry codes
	 *
	 * @param industryCodeId
	 * @return
	 */
	List<IndustryCode> retreiveIndustryCodeList(Long industryCodeId);
	
	/**
	 * The method will persist the updated InfermentText data in the
	 * Staging DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param infermentText
	 */
	InfermentText saveApprovedInfermentText(InfermentText infermentText);

	/**
	 * 
	 * The method to retrieve the area code info
	 *
	 * @return
	 */
	List<String> retrieveAreaCodeInfo();
	/**
	 * 
	 * The method to retrieve the phone area code by id
	 *
	 * @param phoneAreaCodeId
	 * @return
	 */
	PhoneAreaCode retrievePhoneAreaCodeById(Long phoneAreaCodeId);
	/**
	 * 
	 * The method to count the search results of control words
	 *
	 * @param controlWordsSearchVO
	 * @return
	 */
	Long countSearchControlWords(ControlWordsSearchVO controlWordsSearchVO);
}
