/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.GeoCodeConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoDefaultConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoHierarchy;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.entity.GeographySearch;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.entity.UserGroupMapping;
import com.dnb.dsc.refdata.core.vo.GeoSearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.GeoTransactionalDAO;
import com.googlecode.ehcache.annotations.Cacheable;

/**
 * This is used as the DAO implementation class for the Geography operations.
 * The DAO contacts the transactional DB for all its operations
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 *
 */
@Repository("GeoTransactionalDAO")
public class GeoTransactionalDAOImpl implements GeoTransactionalDAO {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GeoTransactionalDAOImpl.class);

	@PersistenceContext(unitName = "PU-Transactional")
	private EntityManager em;

    private JdbcTemplate jdbcTemplate;    

	/**
	 * The constants for named query - retrieve all geo hierarchy
	 */
	private static final String QUERY_RETRIEVE_ALL_GEO_HIERARCHY = "SELECT h FROM GeoHierarchy h where h.isDefaultHierarchy = 1 order by h.geoHierarchyId ";

	/**
	 * The constants for named query - retrieve all geo default configurations
	 */
	private static final String QUERY_RETRIEVE_ALL_GEO_CONFIGURATIONS = "SELECT c FROM GeoDefaultConfiguration c";

	/**
	 * The constants for named query - retrieve all user group mappings
	 */
	private static final String QUERY_RETRIEVE_ALL_USR_GRP_MAPPINGS = "SELECT g FROM UserGroupMapping g";

	private static final String QUERY_RETRIEVE_HIERARCHY_BY_GEO_UNIT_ID = "GeoHierarchy.getHierarchyByGeoUnitId";
	
	/**
	 * The constants for named query - retrieve geo unit type by geo unit id
	 */
	private static final String QUERY_RETRIEVE_GEOUNITHIERARCHY_BY_GEOUNITID = "GeoHierarchy.retrieveGeoUnitHierarchyByGeoUnitId";
	 /**
	  * The constants for named query - retrieve UIBULKDOWNLOAD by userId
	 */
	@SuppressWarnings("unused")
	private static final String QUERY_RETRIEVE_UIBULKDOWNLOAD_BY_USRID = "IndustryCode.retrieveUIBulkDownload";
	/**
	 * The constants for query - retrieve hierarchy search results
	 */
	private static final String QUERY_RETRIEVE_GEO_SEARCH_SELECT = "SELECT new GeographySearch(g.countryName, g.countryGeoCode, "
			+ "g.stateName, g.stateGeoCode, g.countyName, g.countyGeoCode, "
			+ "g.postTownName, g.postTownGeoCode, g.postCode, g.postCodeGeoCode "
			+ ") FROM GeographySearch g ";
	/**
	 * The constants for query - retrieve hierarchy search results
	 */
	private static final String QUERY_RETRIEVE_GEO_SEARCH_COUNT = "SELECT count(g.countryName) FROM GeographySearch g ";

	/**
	 * The constants for named query - retrieve GeoCodeConfiguration by codeType code
	 */
	private static final String QUERY_RETRIEVE_GEOCODECONFIG_BY_CODETYPE = "GeoCodeConfiguration.retrieveGeoUnitCodeConfigurations";

	/**
	 * The constants for named query - retrieve country geo unit by id
	 */
	private static final String QUERY_RETRIEVE_COUNTRY_BY_GEOUNITID = "SELECT g.geoUnitId FROM GeoUnit g, GeoUnitAssociation a " +
			"WHERE g.geoUnitId = a.parentGeoUnitId and g.geoUnitTypeCode = 128 and a.childGeoUnitId = :geoUnitId";
	
    /**
     * Inject DataSource properties to jdbcTemplate.
     *
     * @param argDataSource
     *            the new data source
     */
    @Autowired
    @Qualifier("txnDataSource")
    public void setDataSource(DataSource argDataSource) {
        this.jdbcTemplate = new JdbcTemplate(argDataSource);
    }

	/**
	 * The constants for named query - count geo unit
	 */
	private static final String QUERY_COUNT_GEO_UNIT = "GeoUnit.countGeoUnit";

	/**
	 * The constants for named query - retrieve geo unit by tracking id
	 */
	private static final String QUERY_RETRIEVE_GEO_UNIT_BY_TRACKINGID = "GeoUnit.retrieveGeoUnitByTrackingId";

	/**
	 * The constants for named query - delete geo unit by id
	 */
	private static final String QUERY_REMOVE_GEO_UNIT_BY_GEO_UNIT_ID = "GeoUnit.removeGeoUnitByGeoUnitId";

	/**
	 * The constants for named query - delete geo unit code by id
	 */
	private static final String QUERY_REMOVE_GEO_UNIT_CODE_BY_GEO_UNIT_ID = "GeoUnitCode.removeGeoUnitByGeoUnitId";

	/**
	 * The constants for named query - delete geo unit name by id
	 */
	private static final String QUERY_REMOVE_GEO_UNIT_NME_BY_GEO_UNIT_ID = "GeoUnitName.removeGeoUnitByGeoUnitId";

	/**
	 * The constants for named query - delete geo unit association by id
	 */
	private static final String QUERY_REMOVE_PRNT_GEO_UNIT_ASSN_BY_ID = "GeoUnitAssociation.removeParentGeoUnitsByGeoUnitId";

	/**
	 * The constants for named query - retrieve child geo unit associations
	 */
	private static final String QUERY_RETRIEVE_CHILD_GEO_ASSOCIATION = "select a.geo_unit_assn_id as geo_unit_assn_id, " +
			"a.prnt_geo_unit_id as prnt_geo_unit_id, a.chld_geo_unit_id as chld_geo_unit_id, a.effv_dt as effv_dt, " +
			"a.expn_dt as expn_dt, a.expd_by_dt as expd_by_dt, g.geo_unit_typ_cd as geo_unit_typ_cd, " +
			"a.row_cre_tmst as row_cre_tmst, a.row_mod_tmst as row_mod_tmst, a.row_mod_id as row_mod_id, " +
			"a.row_cre_id as row_cre_id from soruiconfig.geo_unit_assn a, sorusr.geo_unit g " +
			"where a.chld_geo_unit_id=g.geo_unit_id and a.prnt_geo_unit_id= :geoUnitId";

	/**
	 * The constants for named query - retrieve geo unit by geo unit id
	 */
	private static final String QUERY_RETRIEVE_GEOUNIT_BY_ID = "GeoUnit.retrieveGeoUnitByGeoUnitId";
	/**
	 * The constants for named query - retrieve geo unit type by geo unit id
	 */
	private static final String QUERY_RETRIEVE_GEOUNITTYPE_BY_GEOUNITID = "GeoHierarchy.retrieveGeoUnitTypeByGeoUnitId";
	
	
	/**
	 *
	 * The setter method for the entity manager. The persistence context has
	 * been defined as part of the entity manager definition.
	 *
	 * @param em
	 */
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}

	/**
	 * The method will search for the geo unit by geoUnitId. The return would be
	 * the GeoUnit entity
	 *
	 * @param geoUnitId
	 * @return geoUnit the geoUnit entity
	 */
	public GeoUnit retrieveGeoUnit(Long geoUnitId) {
		LOGGER.info("entering GeoTransactionalDAOImpl | retrieveGeoUnit");

		LOGGER.info("exiting GeoTransactionalDAOImpl | retrieveGeoUnit");
		return null;
	}

	/**
	 * This method updates geo unit entity to transaction DB
	 *
	 * @param GeoUnit
	 * @return status
	 */
	public GeoUnit updateGeoUnit(GeoUnit geoUnit){
		try{
		return em.merge(geoUnit);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * Performs a soft delete on the geo unit.<p>
	 *
	 * @param geoUnit
	 * @return a Boolean status flag.
	 */
	@Override
	public Boolean deleteGeoUnit(GeoUnit geoUnit) {
		LOGGER.info("entering GeoTransactionalDAOImpl | deleteGeoUnitById");
		try{
		em.merge(geoUnit);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting GeoTransactionalDAOImpl | deleteGeoUnitById");
		return true;
	}

	/**
	 * The method will validate the Geo Unit for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param geoUnitId
	 */
	public String countGeoUnit(Long geoUnitId) {
		LOGGER.info("entering GeoTransactionalDAOImpl | countGeoUnit");
		String lockedUser = null;
			try {
				GeoUnit modifiedUser = (GeoUnit)em.find(GeoUnit.class, geoUnitId);
				if(modifiedUser != null){
					lockedUser = modifiedUser.getModifiedUser();
				}
		return lockedUser;		
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will retrieve the Geo Unit based on the Workflow Tracking Id.
	 * This method will be invoked from the Workflow Component and the search
	 * will be performed on the Transactional DB.
	 *
	 * @param trackingId
	 * @param geoUnit
	 */
	@Override
	public GeoUnit retreiveGeoUnitByTrackingId(Long trackingId) {
		LOGGER.info("entering GeoTransactionalDAOImpl | retreiveGeoUnitByTrackingId");

		Query query = em.createNamedQuery(QUERY_RETRIEVE_GEO_UNIT_BY_TRACKINGID);
		query.setParameter("trackingId", trackingId);

		LOGGER.info("exiting GeoTransactionalDAOImpl | retreiveGeoUnitByTrackingId");
		try{
		return (GeoUnit) query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will remove the geo unit data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param geoUnitId
	 * @param boolean indicating the status
	 */
	@Override
	public Boolean removeApprovedGeoUnit(Long geoUnitId,Long changeTypeId) {
		LOGGER.info("entering GeoTransactionalDAOImpl | removeApprovedGeoUnit");
		// remove the GeoUnit details from the Association table
		Query query = em.createNamedQuery(QUERY_REMOVE_PRNT_GEO_UNIT_ASSN_BY_ID);
		query.setParameter("geoUnitId", geoUnitId);
		try {
		query.executeUpdate();
		// remove the GeoUnit details from the Name table
		query = em.createNamedQuery(QUERY_REMOVE_GEO_UNIT_NME_BY_GEO_UNIT_ID);
		query.setParameter("geoUnitId", geoUnitId);
		query.executeUpdate();
		// remove the GeoUnit details from the Code table
		query = em.createNamedQuery(QUERY_REMOVE_GEO_UNIT_CODE_BY_GEO_UNIT_ID);
		query.setParameter("geoUnitId", geoUnitId);
		query.executeUpdate();
		// remove the GeoUnit details from the GeoUnit table
		query = em.createNamedQuery(QUERY_REMOVE_GEO_UNIT_BY_GEO_UNIT_ID);
		query.setParameter("geoUnitId", geoUnitId);
		query.executeUpdate();
		
		//Calling Geography Insert Proc
		if(RefDataChangeTypeConstants.CHANGE_TYPE_ADD_GEO_UNIT.equals(String.valueOf(changeTypeId))) {
			jdbcTemplate.update("call soruiconfig.GEO_SRCH_INSERT(?)",geoUnitId);
		}
		
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting GeoTransactionalDAOImpl | removeApprovedGeoUnit");
		return true;
	}

	/**
	 *
	 * The method will identify all child entities for the specified GeoUnit Id
	 *
	 * @param geoUnitId
	 * @return
	 */
	public List<GeoUnitAssociation> retrieveChildGeoUnitAssociations(Long geoUnitId) {
		LOGGER.info("entering GeoTransactionalDAOImpl | retrieveChildGeoUnitAssociations");
	
		List<GeoUnitAssociation> associations = null;
		try {
			associations = jdbcTemplate.query(QUERY_RETRIEVE_CHILD_GEO_ASSOCIATION, 
					new Object[] { geoUnitId }, new RowMapper<GeoUnitAssociation>() {
						@Override
						public GeoUnitAssociation mapRow(ResultSet rs, int arg1) throws SQLException {
							GeoUnitAssociation association = new GeoUnitAssociation();
							association.setGeoUnitAssociationId(rs.getLong("geo_unit_assn_id"));
							association.setParentGeoUnitId(rs.getLong("prnt_geo_unit_id"));
							association.setChildGeoUnitId(rs.getLong("chld_geo_unit_id"));
							association.setEffectiveDate(rs.getDate("effv_dt"));
							association.setExpirationDate(rs.getDate("expn_dt"));
							association.setExpiredByDate(rs.getDate("expd_by_dt"));
							association.setChildGeoUnitTypeCode(rs.getLong("geo_unit_typ_cd"));
							association.setCreatedDate(rs.getDate("row_cre_tmst"));
							association.setModifiedDate(rs.getDate("row_mod_tmst"));
							association.setCreatedUser(rs.getString("row_cre_id"));
							association.setModifiedUser(rs.getString("row_mod_id"));
							return association;
						}
					});
		} catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting GeoTransactionalDAOImpl | retrieveChildGeoUnitAssociations");
		return associations;
	}

	/**
	 *
	 * The method will persist childGeoUnitAssociations
	 *
	 * @param childGeoUnitAssociation
	 * @return status
	 */
	public Boolean insertGeoUnitAssociations(GeoUnitAssociation childGeoUnitAssociation){
		try{
		em.persist(childGeoUnitAssociation);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return true;
	}

	/**
	 *
	 * The method will create the named query instance by setting the query
	 * parameters. The method is invoked for all name query operations.
	 *
	 * @param sql
	 * @param parameters
	 * @return
	 */
	private Query createNamedQuery(String sql, Map<String, Object> parameters) {
		Query query = em.createNamedQuery(sql);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 *
	 * @param geoUnitId
	 */
	public GeoUnit retrieveGeoUnitByGeoUnitId(Long geoUnitId) {
		LOGGER.info("entering GeoTransactionalDAOImpl | retrieveGeoUnitByGeoUnitId");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("geoUnitId", geoUnitId);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_GEOUNIT_BY_ID, parameters);
		LOGGER.info("exiting GeoTransactionalDAOImpl | retrieveGeoUnitByGeoUnitId");
		try {
			return (GeoUnit) query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	


	/**
	 *
	 * The method will retrieve all geography hierarchies
	 *
	 * @return geoHierarchies
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Cacheable(cacheName = "refdataCache")
	public List<GeoHierarchy> retrieveAllGeoHierarchies() {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveAllGeoHierarchies");
		Query query = em.createQuery(QUERY_RETRIEVE_ALL_GEO_HIERARCHY);
		try{
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method will retrieve all geography default configurations
	 *
	 * @return geoDefaultConfigurations
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Cacheable(cacheName = "refdataCache")
	public List<GeoDefaultConfiguration> retrieveAllGeoConfigurations() {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveAllGeoConfigurations");
		Query query = em.createQuery(QUERY_RETRIEVE_ALL_GEO_CONFIGURATIONS);
		try{
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method will retrieve all user group mappings available within
	 * refdata.
	 *
	 * @return userGroupMappings
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Cacheable(cacheName = "refdataCache")
	public List<UserGroupMapping> retrieveAllUserGroupMappings() {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveAllUserGroupMappings");
		Query query = em.createQuery(QUERY_RETRIEVE_ALL_USR_GRP_MAPPINGS);
		try {
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<GeoHierarchy> getHierarchyByGeoUnitId(Long geoUnitId) {
		LOGGER.info("entering GeoStagingDAOImpl | getHierarchyByGeoUnitId");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("geoUnitId", geoUnitId);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_HIERARCHY_BY_GEO_UNIT_ID,
				parameters);
		LOGGER.info("exiting GeoStagingDAOImpl | getHierarchyByGeoUnitId");
		try {
			return (List<GeoHierarchy>) query.getResultList();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	


	/**
	 *
	 * The method will perform a hierarchy search of geo units on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return list of geographies
	 */
	@SuppressWarnings("unchecked")
	public List<GeographySearch> searchGeographies(
			GeoSearchCriteriaVO geoSearchCriteria) {
		LOGGER.info("entering GeoStagingDAOImpl | searchGeographies");

		LOGGER.info("\n\ngeoSearchCriteria :: " + geoSearchCriteria);

		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer(
				QUERY_RETRIEVE_GEO_SEARCH_SELECT);
		/*
		 * Include the where condition if at least one of the filter condition
		 * is not empty. append the where condition.
		 */
		if (geoSearchCriteria.getCountryGeoCode() != null
				&& geoSearchCriteria.getCountryGeoCode().length() > 0) {
			queryStr.append("where g.countryGeoCode like concat(:countryGeoCode,'%') ");
			parameters.put("countryGeoCode",
					geoSearchCriteria.getCountryGeoCode());
		}
		// if state/territory drop down is selected
		if (geoSearchCriteria.getStateGeoCode() != null
				&& geoSearchCriteria.getStateGeoCode().length() > 0) {
			queryStr.append("and g.stateGeoCode like concat('%',:stateGeoCode,'%') ");
			parameters.put("stateGeoCode", geoSearchCriteria.getStateGeoCode());
		}
		// if county value is entered as a filter
		if (geoSearchCriteria.getCountyName() != null
				&& geoSearchCriteria.getCountyName().length() > 0) {
			String countyNme = null;
			if("_".equals(geoSearchCriteria.getCountyName())) {
				countyNme = "upper(:countyName)";
			} else {
				countyNme = "upper(:countyName),'%'";
			}
			queryStr.append("and upper(g.countyName) like concat(" + countyNme + ") ");
			parameters.put("countyName", geoSearchCriteria.getCountyName());
		}
		// if post town value is entered as a filter
		if (geoSearchCriteria.getPostTownName() != null
				&& geoSearchCriteria.getPostTownName().length() > 0) {
			String postTownName = null;
			if("_".equals(geoSearchCriteria.getPostTownName())) {
				postTownName = "upper(:postTownName)";
			} else {
				postTownName = "upper(:postTownName),'%'";
			}
			queryStr.append("and upper(g.postTownName) like concat(" + postTownName + ") ");
			parameters.put("postTownName", geoSearchCriteria.getPostTownName());
		}
		// if post code value is entered as a filter
		if (geoSearchCriteria.getPostCode() != null
				&& geoSearchCriteria.getPostCode().length() > 0) {
			String postCode = null;
			if("_".equals(geoSearchCriteria.getPostCode())) {
				postCode = "upper(:postCode)";
			} else {
				postCode = "upper(:postCode),'%'";
			}
			queryStr.append("and upper(g.postCode) like concat(" + postCode + ") ");
			parameters.put("postCode", geoSearchCriteria.getPostCode());
		}

		queryStr.append("order by ").append(
				getSortByColumnForGeoSearch(geoSearchCriteria.getSortBy(),
						geoSearchCriteria.getSortOrder()));

		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		// setting the page count and max results for pagination
		query.setMaxResults(geoSearchCriteria.getMaxResults());
		query.setFirstResult(geoSearchCriteria.getRowIndex());

		LOGGER.info("exiting GeoStagingDAOImpl | searchGeographies");
		try{
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method to identify the sort order of columns in the Geography Search
	 * page. The search will be performed on a specific column and the secondary
	 * sort orders are to be defined to be displayed in the UI.
	 *
	 * @param sortBy
	 * @param sortOrder
	 * @return sortByColumns
	 */
	private String getSortByColumnForGeoSearch(String sortBy, String sortOrder) {
		String sortByColumns;
		if ("countryName".equals(sortBy)) {
			sortByColumns = "g.countryName " + sortOrder
					+ ", g.stateName, g.countyName, g.postTownName, g.postCode";
		} else if ("stateName".equals(sortBy)) {
			sortByColumns = "g.stateName "
					+ sortOrder
					+ ", g.countryName, g.countyName, g.postTownName, g.postCode";
		} else if ("countyName".equals(sortBy)) {
			sortByColumns = "g.countyName "
					+ sortOrder
					+ ", g.countryName, g.stateName, g.postTownName, g.postCode";
		} else if ("postTownName".equals(sortBy)) {
			sortByColumns = "g.postTownName " + sortOrder
					+ ", g.countryName, g.stateName, g.countyName, g.postCode";
		} else if ("postCode".equals(sortBy)) {
			sortByColumns = "g.postCode "
					+ sortOrder
					+ ", g.countryName, g.stateName, g.countyName, g.postTownName";
		} else {
			sortByColumns = "g.countryName " + sortOrder
					+ ", g.stateName, g.countyName, g.postTownName, g.postCode";
		}

		return sortByColumns;
	}

	/**
	 *
	 * The method will count the number of records returned by the query
	 *
	 * @param searchCriteriaVO
	 * @return list of geographies
	 */
	public Long countSearchGeographies(GeoSearchCriteriaVO geoSearchCriteria) {
		LOGGER.info("entering GeoStagingDAOImpl | countSearchGeographies");

		LOGGER.info("geoSearchCriteria :: " + geoSearchCriteria);
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer(
				QUERY_RETRIEVE_GEO_SEARCH_COUNT);
		/*
		 * Include the where condition if at least one of the filter condition
		 * is not empty. append the where condition.
		 */
		if (geoSearchCriteria.getCountryGeoCode() != null
				&& geoSearchCriteria.getCountryGeoCode().length() > 0) {
			queryStr.append("where g.countryGeoCode like concat(:countryGeoCode,'%') ");
			parameters.put("countryGeoCode",
					geoSearchCriteria.getCountryGeoCode());
		}
		// if state/territory drop down is selected
		if (geoSearchCriteria.getStateGeoCode() != null
				&& geoSearchCriteria.getStateGeoCode().length() > 0) {
			queryStr.append("and g.stateGeoCode like concat('%',:stateGeoCode,'%') ");
			parameters.put("stateGeoCode", geoSearchCriteria.getStateGeoCode());
		}
		// if county value is entered as a filter
		if (geoSearchCriteria.getCountyName() != null
				&& geoSearchCriteria.getCountyName().length() > 0) {
			queryStr.append("and upper(g.countyName) like concat(upper(:countyName),'%') ");
			parameters.put("countyName", geoSearchCriteria.getCountyName());
		}
		// if post town value is entered as a filter
		if (geoSearchCriteria.getPostTownName() != null
				&& geoSearchCriteria.getPostTownName().length() > 0) {
			queryStr.append("and upper(g.postTownName) like concat(upper(:postTownName),'%') ");
			parameters.put("postTownName", geoSearchCriteria.getPostTownName());
		}
		// if post code value is entered as a filter
		if (geoSearchCriteria.getPostCode() != null
				&& geoSearchCriteria.getPostCode().length() > 0) {
			queryStr.append("and upper(g.postCode) like concat(upper(:postCode),'%') ");
			parameters.put("postCode", geoSearchCriteria.getPostCode());
		}

		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		try{
			return (Long) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	/**
	 * The method will search the Transaction SoR for the GeoHierarchy based on the
	 * geoUnitId and will return the GeoHierarchy entity.
	 *
	 * @param geoUnitId
	 */
	@SuppressWarnings("unchecked")
	public List<GeoHierarchy> retrieveGeoUnitType(Long geoUnitId) {
		LOGGER.info("entering GeoTransactionalDAOImpl | retrieveGeoUnitType");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("geoUnitId", geoUnitId);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_GEOUNITTYPE_BY_GEOUNITID, parameters);
		LOGGER.info("exiting GeoTransactionalDAOImpl | retrieveGeoUnitType");
		try {
			return  (List<GeoHierarchy>) query.getResultList();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}

}
	/**
	 * This method updates UiBulkDownload entity to transaction DB
	 *
	 * @param UiBulkDownload
	 * @return UiBulkDownload
	 */
	public Long addUIBulkDownload(UiBulkDownload uiBulkDownload) {
		UiBulkDownload bulkDownload = null;
		try{
			bulkDownload = em.merge(uiBulkDownload);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return bulkDownload.getUiBulkDownloadId();
	}
	
	/**
	 * The method will search the Transaction SoR for the GeoHierarchy based on the
	 * geoUnitId and will return the GeoHierarchy entity.
	 *
	 * @param geoUnitId
	 */
	@SuppressWarnings("unchecked")
	public List<GeoHierarchy> retrieveGeoUnitHierarchies(Long geoUnitId) {
		LOGGER.info("entering GeoTransactionalDAOImpl | retrieveGeoUnitHierarchies");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("geoUnitId", geoUnitId);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_GEOUNITHIERARCHY_BY_GEOUNITID, parameters);
		LOGGER.info("exiting GeoTransactionalDAOImpl | retrieveGeoUnitHierarchies");
		try {
			return  (List<GeoHierarchy>) query.getResultList();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}

	}
	
	/**
	 * 
	 * The method to retrieve the geo unit code configurations
	 *
	 * @param codeTypeCode
	 * @return geoCodeConfigurations
	 */
	@SuppressWarnings("unchecked")	
	@Cacheable(cacheName = "refdataCache")
	public List<GeoCodeConfiguration> retrieveGeoUnitCodeConfigurations(Long codeTypeCode) {
		LOGGER.info("entering GeoTransactionalDAOImpl | retrieveGeoUnitCodeConfigurations");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("geoCodeTypeCode", codeTypeCode);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_GEOCODECONFIG_BY_CODETYPE, parameters);
		LOGGER.info("exiting GeoTransactionalDAOImpl | retrieveGeoUnitCodeConfigurations");
		try {
			return (List<GeoCodeConfiguration>) query.getResultList();
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}	
	
	/**
	 * 
	 * The method to identify the country for a GeoUnit. This method is
	 * applicable for all newly added GeoUnits. The newly added GeoUnit could be
	 * of any type and the method will return the parent country's geo_unit_id
	 * 
	 * @param geoUnitId
	 * @return countryGeoUnitId
	 */
	public Long retrieveCountryGeoUnitId(Long geoUnitId) {
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("geoUnitId", geoUnitId);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_COUNTRY_BY_GEOUNITID, parameters);
		LOGGER.info("exiting GeoTransactionalDAOImpl | retrieveCountryGeoUnitId");
		try {
			return (Long) query.getSingleResult();
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
}
