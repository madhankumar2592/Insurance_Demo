package com.dnb.dsc.refdata.dao;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GranularityType;
import com.dnb.dsc.refdata.core.entity.Score;
import com.dnb.dsc.refdata.core.entity.ScoreDetails;
import com.dnb.dsc.refdata.core.entity.ScoreGranularityAssociation;
import com.dnb.dsc.refdata.core.entity.ScoreMap;
import com.dnb.dsc.refdata.core.entity.ScoreMapping;
import com.dnb.dsc.refdata.core.entity.ScoreType;
import com.dnb.dsc.refdata.core.entity.ScoreTypeAssociation;
import com.dnb.dsc.refdata.core.vo.AddNewScoreVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ScoreSearchVO;
import com.dnb.dsc.refdata.core.vo.ScoreVO;


/**
 * This is used as the services interface for the Score operations
 *
 * @author Cognizant
 * @version last updated : Aug 21, 2014
 * @see
 *
 */
public interface ScoreStagingDAO {
	
	

		List<CodeValueVO> retrieveGranularityCodes(String capabilityCode);
		
		Long checkScoreTypeAvailability(Long ScoreTypeCode);
		
		//HashMap<GranularityDetailVO,Long> checkGranuTypeAvailability(GranularityDetailVO granularityDetailVO);
		
		  Long retrieveMaxScoreTypeId();
		  
		  Long retrieveMaxGranularityTypeId();
		  
		  Long retrieveMaxScoreTypeAssnId();
		  
		  Long retrieveMaxScoreGranularityAssnId();
		  
		  Long retrieveMaxScoreGranularityAssnValueId();
		  
		  Long retrieveMaxCount(String query);
		  
		  ScoreType updateScoreTypeRec(ScoreType scoreType);
		  
		  GranularityType updateGranularityTypeRec(GranularityType granularityType);
		  
		  ScoreTypeAssociation updateScoreTypeAssnRec(ScoreTypeAssociation scrTypAssn);
		
		  ScoreGranularityAssociation updateScoreGranuAssnRec(ScoreGranularityAssociation scrGruAssn);

		String retrieveCodeValueDescription(String queryGruTypDesc);

		Score updateNewScoreTypeRec(Score score);

		Long retrieveMaxScoreId();

		ScoreType findScoreType(Long scoreTypeId);

		Score findScore(Long scoreId);

		ScoreTypeAssociation findScoreTypeAssn(Long scoreTypeAssnId);

		GranularityType findGranuType(Long granularityTypeId);

		List<CodeValueVO> retrieveAllScoreTypeCode();

		List<CodeValueVO> retrieveMarketTypeCodes(Long scoreType);

		List<Score> retrievescoreVersions(Long scoreType, Long marketType);

		List<AddNewScoreVO> retrieveAttributeDetails(Long scoreType,
				Long marketType, Double scoreVersion);
		List<Long> retrieveScoreTypeCode();

		List<CodeValue> retrieveScoreTypeCodeValues(ScoreVO scoreVO);

		List<CodeValueVO> retrieveMarketCodeValues(ScoreVO scoreVO);

		List<Score> retrieveVersionValues(Score scoreVO);

		List<CodeValue> retrieveGranularityForScrType(ScoreVO scoreVO);

		Long retreiveIds(String Query);

		ScoreDetails updateScoreDetail(ScoreDetails scoreDtl);

		List<CodeValue> retrieveGruTypeCodeValues(ScoreVO scoreVO);

		Long countSearchScore(ScoreSearchVO searchCriteriaVO);

		List<ScoreSearchVO> scoreSearch(ScoreSearchVO searchCriteriaVO);

		ScoreSearchVO editScoreSearch(ScoreSearchVO scoreSearchVO);

		Score findScr(Long scoreId);

		Score updateScore(Score score);

		ScoreMap findScrMap(Long scr_map_id);

		ScoreMap updateScoreMap(ScoreMap scoreMap);

		ScoreDetails findScrDtl(Long scrDtlID);
		
		Long retrieveMax(String query);
		
		ScoreMapping updateNewScoreMapRec(ScoreMapping granularityMap);
		
		 Long retrieveMaxScoreMapId();
		 
		 List<Long> retrieveLongList(String query);

		List<CodeValue> retrieveScrSearchScoreTypeCode(ScoreVO scoreVO);

		List<CodeValue> retrieveScrSearchGranularity(ScoreVO scoreVO);
		
		void removeProdRescID(List<Long> prodDtlIdList, String deleteQuery,
				String parameter);
		
		 void removeID(List<Long> prodDtlIdList, String deleteQuery,
					String parameter, Long prod_id, String prodParameter);
		 void removeID(String deleteQuery,
					String parameter, Long prod_id, String prodParameter);
		 List<Long> retrieveScoreDtlId(Long scoreId);
		 List<Long> retrieveProdScoreMapId(List<Long> scoreDtlId);
		 List<Long> retreiveScoreMappingId(List<Long> scrMapId,Long scoreId);
		 List<Long> retreiveScrDtlId(List<Long> scrGruId,Long scoreId);
		 List<Long> retreiveScrDtlId(Long scoreId);
		 
		Long retrieveScoreTypeId(String query);

		Boolean checkForDuplicate(Long scrTypId, Long scrMarketCode,Double scoreVersion);
}
