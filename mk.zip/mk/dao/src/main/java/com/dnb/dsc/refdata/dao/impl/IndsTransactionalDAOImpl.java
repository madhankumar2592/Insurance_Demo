/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.IndsTransactionalDAO;

/**
 * This is used as the DAO implementation class for the Geography operations.
 * The DAO contacts the transactional DB for all its operations
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 *
 */
@Repository("IndsTransactionalDAO")
public class IndsTransactionalDAOImpl implements IndsTransactionalDAO {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(IndsTransactionalDAOImpl.class);

	private static final String QUERY_COUNT_INDUSTRY_CODE = "IndustryCode.countIndustryCode";
	
	private static final String QUERY_COUNT_SAVED_RECORD = "SavedRecord.countByDomainId";

	/**
	 * The constants for named query - retrieve IndustryCode by industryCodeId
	 */
	private static final String QUERY_RETRIEVE_INDUSTRYCODE_BY_ID = "IndustryCode.retrieveIndustryCodeByIndustryCodeId";

	/**
	 * The constants for named query - delete industry code by id
	 */
	private static final String QUERY_REMOVE_INDUSTRYCODE_BY_ID = "IndustryCode.removeIndustryCodeById";
	
	/**
	 * The constants for named query - delete industry code by id
	 */
	private static final String QUERY_REMOVE_INDUSTRY_CODE_DESCRIPTION_BY_ID = "IndustryCodeDescription.removeIndustryCodeDescriptionByIndustryCodeId";
	
	/**
	 * The constants for named query - delete industry code by id
	 */
	private static final String QUERY_REMOVE_INDUSTRY_CODE_MAPPING_BY_ID = "IndustryCodeMap.removeIndustryCodeMapByIndustryCodeId";
	
	/**
	 * The constants for named query - retrieve UIBULKDOWNLOAD by userId
	 */
	private static final String QUERY_RETRIEVE_UIBULKDOWNLOAD_BY_USRID = "IndustryCode.retrieveUIBulkDownload";

	/**
	 * The constants for named query - retrieve UIBULKDOWNLOAD by userId
	 */
	private static final String QUERY_REMOVE_SAVEDRECORD_BY_DOMAIN_ID = "SavedRecord.removeByDomainId";
	
	@PersistenceContext(unitName = "PU-Transactional")
	private EntityManager em;

	private JdbcTemplate jdbcTemplate;

    /**
	 *
	 * The method will create the named query instance by setting the query
	 * parameters. The method is invoked for all name query operations.
	 *
	 * @param sql
	 * @param parameters
	 * @return
	 */
	private Query createNamedQuery(String sql, Map<String, Object> parameters) {
		Query query = em.createNamedQuery(sql);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}

    /**
     * Inject DataSource properties to jdbcTemplate.
     *
     * @param argDataSource
     *            the new data source
     */
    @Autowired
    @Qualifier("txnDataSource")
    public void setDataSource(DataSource argDataSource) {
        this.jdbcTemplate = new JdbcTemplate(argDataSource);
    }

	/**
	 *
	 * The setter method for the entity manager. The persistence context has
	 * been defined as part of the entity manager definition.
	 *
	 * @param em
	 */
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}

	/**
	 * This method updates IndustryCode entity to transaction DB
	 *
	 * @param IndustryCode
	 * @return status
	 */
	@Override
	public IndustryCode updateIndustryCode(IndustryCode industryCode){
		try {
		return em.merge(industryCode);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * This method updates counts the IndustryCode entity in the transaction DB
	 *
	 * @param industryCodeId
	 * @return count
	 */
	public String countIndustryCode(Long industryCodeId) {
		LOGGER.info("entering IndsTransactionalDAOImpl | countIndustryCode");
		String lockedUser = null;		
		try {
			IndustryCode modifiedUser = (IndustryCode)em.find(IndustryCode.class, industryCodeId);
			if(modifiedUser != null){
				lockedUser = modifiedUser.getModifiedUser();
			}
		return lockedUser;
		}catch(NoResultException ex){			
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){			
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){			
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * This method returns the maximum value of industry code id. It does so by
	 * selecting the next value from a sequence
	 */
	@Override
	public Long retrieveMaxIndustryCodeId() {
		try {
		return jdbcTemplate.queryForLong("SELECT SORUSR.INDS_CODE_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will search the Transaction SoR for the IndustryCode based on the
	 * industryCodeId and will return the IndustryCode entity.
	 *
	 * @param industryCodeId
	 */
	public IndustryCode retrieveIndustryCodeByIndustryCodeId(Long industryCodeId) {
		LOGGER.info("entering IndsTransactionalDAOImpl | retrieveIndustryCodeByIndustryCodeId");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("industryCodeId", industryCodeId);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_INDUSTRYCODE_BY_ID, parameters);
		LOGGER.info("exiting IndsTransactionalDAOImpl | retrieveIndustryCodeByIndustryCodeId");
		try {
			return (IndustryCode) query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will remove the industryCode data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param industryCodeId
	 * @param boolean indicating the status
	 */
	@Override
	public void removeApprovedIndustryCode(Long industryCodeId) {
		LOGGER.info("entering IndsTransactionalDAOImpl | removeApprovedIndustryCode");
		// remove the industry Code details from the table
		Query query = em.createNamedQuery(QUERY_REMOVE_INDUSTRYCODE_BY_ID);
		query.setParameter("industryCodeId", industryCodeId);
		try {
		query.executeUpdate();
		query = em.createNamedQuery(QUERY_REMOVE_INDUSTRY_CODE_DESCRIPTION_BY_ID);
		query.setParameter("industryCodeId", industryCodeId);
		query.executeUpdate();
		query = em.createNamedQuery(QUERY_REMOVE_INDUSTRY_CODE_MAPPING_BY_ID);
		query.setParameter("industryCodeId", industryCodeId);
		query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting IndsTransactionalDAOImpl | removeApprovedIndustryCode");
	}
	
	/**
	 * This method updates UiBulkDownload entity to transaction DB
	 *
	 * @param UiBulkDownload
	 * @return UiBulkDownload
	 */
	public Long addUIBulkDownload(UiBulkDownload uiBulkDownload) {
		UiBulkDownload bulkDownload = null;
		try {
			bulkDownload = em.merge(uiBulkDownload);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return bulkDownload.getUiBulkDownloadId();
	}
	
	/**
	 * The method will search the Transaction SoR for the UiBulkDownload based on the
	 * userId and will return the UiBulkDownload entity.
	 *
	 * @param userId
	 */
	@SuppressWarnings("unchecked")
	public List<UiBulkDownload> retrieveUIBulkDownload(String userId) {
		LOGGER.info("entering IndsTransactionalDAOImpl | retrieveUIBulkDownload");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("userId", userId);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_UIBULKDOWNLOAD_BY_USRID,
				parameters);
		LOGGER.info("exiting IndsTransactionalDAOImpl | retrieveUIBulkDownload");
		try {
			return (List<UiBulkDownload>) query.getResultList();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
    /**
     * 
     * The method to persist the saved record entity.
     *
     * @param savedRecord
     * @return savedRecordId
     */
	@Override
    public Long insertSavedRecord(SavedRecord savedRecord) {
		SavedRecord mergedRecord = null;
		try {
			mergedRecord = em.merge(savedRecord);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
    	return mergedRecord.getSavedRecordId();
    }
	
    /**
     * 
     * The method to retrieve the count of savedRecord from the domain identifier.
     *
     * @param domainId
     * @return count of savedRecord
     */
	@SuppressWarnings("unchecked")
	@Override
    public String countSavedRecord(Long domainId) {
		LOGGER.info("entering IndsTransactionalDAOImpl | countSavedRecord");

		Query query = em.createNamedQuery(QUERY_COUNT_SAVED_RECORD);
		query.setParameter("domainId", domainId);
		String lockedUser = null;
		try {
			List<SavedRecord> modifiedUser = query.getResultList();	
			if(modifiedUser != null && !(modifiedUser.isEmpty())) {
				for (SavedRecord savedRecord : modifiedUser) {
					lockedUser = savedRecord.getUserId();
				}
			}
		return lockedUser;
		}catch(NoResultException ex){			
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){			
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
    }
	
	/**
	 * 
	 * TODO
	 *
	 * @param domainId
	 */
	@Override
	public void removeSavedRecord(Long domainId) {
		LOGGER.info("entering IndsTransactionalDAOImpl | removeApprovedIndustryCodeFromStaging");
		// remove the industry Code details from the table
		Query query = em.createNamedQuery(QUERY_REMOVE_SAVEDRECORD_BY_DOMAIN_ID);
		query.setParameter("domainId", domainId);
		try {
		query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	/**
	 * 
	 * The method to retrieve the savedRecords based on domainName and domain
	 * Identifier
	 * 
	 * @param userId
	 * @param domainName
	 * @param domainId
	 * @return savedRecords
	 */
	@SuppressWarnings("unchecked")
	@Override
    public List<SavedRecord> retrieveSavedRecords(String userId, String domainName, Long domainId , String userComment) {
		LOGGER.info("entering IndsTransactionalDAOImpl | retrieveSavedRecords");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		
		StringBuffer qryStr = new StringBuffer("SELECT s FROM SavedRecord s WHERE 1=1 ");
		
		if(domainName != null) {
			qryStr.append("and s.domainName = :domainName ");
			parameters.put("domainName", domainName);
		}
		if(domainId != null) {
			qryStr.append("and s.domainId = :domainId ");
			parameters.put("domainId", domainId);
		}
		if(userId != null) {
			qryStr.append("and s.userId = :userId ");
			parameters.put("userId", userId);
		}
		if(userComment != null) {
			qryStr.append("and s.userComment like '%'|| :userComment ||'#'  ");
			parameters.put("userComment", userComment);
		}
		qryStr.append("ORDER BY s.changeTypeCode ");
		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createQuery(qryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		try {
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
    }
}
