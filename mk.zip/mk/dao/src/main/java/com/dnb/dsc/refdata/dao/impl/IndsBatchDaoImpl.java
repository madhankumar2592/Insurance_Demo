/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.dnb.dsc.refdata.dao.IndsBatchDao;

/**
 * This class used to update
 * 
 * 
 * 
 * @author Cognizant
 * @version last updated : March 23, 2012
 * @see
 * 
 */
public class IndsBatchDaoImpl extends JdbcDaoSupport implements IndsBatchDao {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CrcyBatchDAOImpl.class);

	/**
	 * The method to update the indus bulk download status
	 * 
	 * @param currency
	 */
	public void update(Long uiBulkDwnldId, int status) {

		LOGGER.info("updating Records :");
		// System.out.println("inside dao impl");
		if (status == 1) {
			getJdbcTemplate()
					.update("update UI_BULK_DWNL set bulk_dwnl_stat='Completed',dwnl_end_tme=sysdate where ui_bulk_dwnl_id=?",
							new Object[] { uiBulkDwnldId });
		} else {
			getJdbcTemplate()
					.update("update UI_BULK_DWNL set bulk_dwnl_stat='Failed',dwnl_end_tme=sysdate where ui_bulk_dwnl_id=?",
							new Object[] { uiBulkDwnldId });
		}

	}

}
