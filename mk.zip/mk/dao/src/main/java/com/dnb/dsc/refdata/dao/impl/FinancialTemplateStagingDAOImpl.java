/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.FinancialStatementSchedule;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplate;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateInternalLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateOwnerLineItem;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.FinancialTemplateStagingDAO;

/**
 * 
 * @author Cognizant
 * @version last updated : June 19, 2012
 * @see
 * 
 */
@Repository("FinancialTemplateStagingDAO")
public class FinancialTemplateStagingDAOImpl implements FinancialTemplateStagingDAO {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(FinancialTemplateStagingDAOImpl.class);

	@PersistenceContext(unitName = "PU-Staging")
	private EntityManager em;

	/**
	 * The constants for named query
	 */
	private static final String QUERY_RETRIEVE_FINANCIAL_TEMPLATES = "CodeValueText.retrieveFinancialTemplates";
	private static final String QUERY_RETRIEVE_SCHEDULES_FOR_STATEMENT_TYPE = "CodeValueText.retrieveSchedulesForStatementType";
	private static final String QUERY_RETRIEVE_FINANCIAL_STATEMENT_TEMPLATE_BY_TYPE_CODE = "FinancialStatementTemplate.retrieveFinancialStatementTemplateByTypeCode";
	private static final String QUERY_RETRIEVE_LINE_ITEMS_FOR_SCHEDULE_TYPE = "CodeValueText.retrieveLineItemsForScheduleType";
	private static final String QUERY_RETRIEVE_DESC_FOR_ID = "CodeValueText.retrieveDescForId";
	private static final String QUERY_RETRIEVE_STATEMENT_FOR_SCHEDULES = "CodeValueText.retrieveStatementForSchedules";
	private static final String QUERY_RETRIEVE_FINANCIAL_STATEMENT_TEMPLATE_BY_ID = "FinancialStatementTemplate.retrieveFinancialStatementTemplateById";

	/**
	 * The setter method for the entity manager. The persistence context has
	 * been defined as part of the entity manager definition.
	 * 
	 * @param em
	 */
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}

	/**
	 * 
	 * The method will create the named query instance by setting the query
	 * parameters. The method is invoked for all name query operations.
	 * 
	 * @param sql
	 * @param parameters
	 * @return
	 */
	private Query createNamedQuery(String sql, Map<String, Object> parameters) {
		Query query = em.createNamedQuery(sql);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}

	@SuppressWarnings("unchecked")
	public List<CodeValueText> getFinancialTemplates(Long codeTableId) {
		LOGGER.info("entering FinancialTemplateStagingDAOImpl | getFinancialTemplates");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("languageCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		parameters.put("codeTableId",codeTableId.intValue());
		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_FINANCIAL_TEMPLATES, parameters);
		LOGGER.info("exiting FinancialTemplateStagingDAOImpl | getFinancialTemplates");
		try{
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	/**
	 * The query to retrieve the Financial Schedules for a specific statement type
	 * 
	 * @param statementType
	 * @return list of schedules
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueText> getSchedulesForStatementType(Long statementType){
		LOGGER.info("entering FinancialTemplateStagingDAOImpl | getSchedulesForStatementType");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("languageCode", RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		parameters.put("codeTableId", RefDataPropertiesConstants.CODE_TABLE_FINANCIAL_STATEMENT_SCHEDULE.intValue());
		parameters.put("statementType", statementType);
		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_SCHEDULES_FOR_STATEMENT_TYPE, parameters);
		LOGGER.info("exiting FinancialTemplateStagingDAOImpl | getSchedulesForStatementType");
		try{
		return query.getResultList();		
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementTemplate updateFinancialStatementTemplate(FinancialStatementTemplate fsTemplate){
		LOGGER.info("FinancialTemplateStagingDAOImpl - updateFinancialStatementTemplate");
		try{
		return em.merge(fsTemplate);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementSchedule updateFinancialStatementSchedule(FinancialStatementSchedule schedule){
		LOGGER.info("FinancialTemplateStagingDAOImpl - updateFinancialStatementSchedule");
		try{			
		return em.merge(schedule);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementTemplateLineItem updateFinancialStatementTemplateLineItem(FinancialStatementTemplateLineItem lineItem){
		LOGGER.info("FinancialTemplateStagingDAOImpl - updateFinancialStatementTemplateLineItem");
		try{
		return em.merge(lineItem);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementTemplateInternalLineItem updateFinancialStatementTemplateInternalLineItem(FinancialStatementTemplateInternalLineItem internalLineItem){
		LOGGER.info("FinancialTemplateStagingDAOImpl - updateFinancialStatementTemplateInternalLineItem");
		try{
		return em.merge(internalLineItem);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementTemplateOwnerLineItem updateFinancialStatementTemplateOwnerLineItem(FinancialStatementTemplateOwnerLineItem ownerLineItem){
		LOGGER.info("FinancialTemplateStagingDAOImpl - updateFinancialStatementTemplateOwnerLineItem");
		try{
		return em.merge(ownerLineItem);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementTemplate retrieveFinancialStatementTemplateByTypeCode(Long financialTemplateTypeCode) {
		LOGGER.info("entering FinancialTemplateStagingDAOImpl | retrieveFinancialStatementTemplateByTypeCode");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("financialTemplateTypeCode", financialTemplateTypeCode);

		Query query = em.createNamedQuery(QUERY_RETRIEVE_FINANCIAL_STATEMENT_TEMPLATE_BY_TYPE_CODE);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		LOGGER.info("exiting FinancialTemplateStagingDAOImpl | retrieveFinancialStatementTemplateByTypeCode");
		try {
			return (FinancialStatementTemplate) query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<CodeValueText> getLineItemsForScheduleType(Long scheduleType){
		LOGGER.info("entering FinancialTemplateStagingDAOImpl | getLineItemsForScheduleType");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("languageCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		parameters.put("codeTableId", RefDataPropertiesConstants.CODE_TABLE_FINANCIAL_STATEMENT_LINE_ITEM.intValue());
		parameters.put("scheduleType", scheduleType);
		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_LINE_ITEMS_FOR_SCHEDULE_TYPE, parameters);
		LOGGER.info("exiting FinancialTemplateStagingDAOImpl | getLineItemsForScheduleType");
		try{
		return query.getResultList();		
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}	
	
	@Override
	@SuppressWarnings("unchecked")
	public Map<Integer, String> retrieveDescForId(
			List<Integer> codeValueIdList) {
		LOGGER.info("entering FinancialTemplateStagingDAOImpl | retrieveDescForId");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		List<Long> codeValueIdLongList = new ArrayList<Long>();
		for(Integer i : codeValueIdList){
			codeValueIdLongList.add(i.longValue());
		}
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("languageCode", RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		parameters.put("codeValueIdList", codeValueIdLongList);
		parameters.put("writingScriptCode",
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(QUERY_RETRIEVE_DESC_FOR_ID);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting FinancialTemplateStagingDAOImpl | retrieveDescForId");
		try{
		return constructDescForIdMap(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	private Map<Integer, String> constructDescForIdMap(List<CodeValueText> codeValueTextList){
		Map<Integer, String> descForIdMap = new HashMap<Integer, String>();
		for(CodeValueText cvt : codeValueTextList){
			descForIdMap.put(cvt.getCodeValueId().intValue(), cvt.getCodeValueDescription());
		}
		return descForIdMap;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<CodeValueText> retrieveStatementForSchedules(
			List<Integer> scheduleCodeList) {
		LOGGER.info("entering FinancialTemplateStagingDAOImpl | retrieveStatementForSchedules");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		List<Long> codeValueIdLongList = new ArrayList<Long>();
		for(Integer i : scheduleCodeList){
			codeValueIdLongList.add(i.longValue());
		}
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("codeTableId", RefDataPropertiesConstants.CODE_TABLE_FINANCIAL_STATEMENT_TYPE.intValue());
		parameters.put("scheduleCodeList", codeValueIdLongList);
		parameters.put("languageCode", RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(QUERY_RETRIEVE_STATEMENT_FOR_SCHEDULES);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting FinancialTemplateStagingDAOImpl | retrieveStatementForSchedules");
		try{
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementTemplate retrieveFinancialStatementTemplateById(Long financialStatementTemplateId) {
		LOGGER.info("entering FinancialTemplateStagingDAOImpl | retrieveFinancialStatementTemplateById");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("financialStatementTemplateId", financialStatementTemplateId);

		Query query = em.createNamedQuery(QUERY_RETRIEVE_FINANCIAL_STATEMENT_TEMPLATE_BY_ID);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		LOGGER.info("exiting FinancialTemplateStagingDAOImpl | retrieveFinancialStatementTemplateById");
		try {
			return (FinancialStatementTemplate) query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
}
