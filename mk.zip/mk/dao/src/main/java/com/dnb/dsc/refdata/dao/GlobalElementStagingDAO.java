/**
 * 
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GlobalElement;
import com.dnb.dsc.refdata.core.entity.GlobalElementDetail;
import com.dnb.dsc.refdata.core.entity.GlobalElementHistory;
import com.dnb.dsc.refdata.core.entity.GloblalElementCrossWalk;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.AddCrosswalkVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementCrosswalkSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementDetailVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementVO;

/**
 * @author 302801
 *
 */
public interface GlobalElementStagingDAO {
	
	
	
	
	
	/**
	 * 
	 * The method will count the records in the hierarchy search of geo units on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return countResults
	 */
	Long countSearchTopicsBkp(GlobalElementSearchVOBkp globalElementSearchVO);
	
	/**
	 * 
	 * The method will perform a hierarchy search of geo units on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return list of geographies
	 */
	List<GlobalElement> searchByTopicsBkp(GlobalElementSearchVOBkp globalElementSearchVO);

	List<GlobalElementVO> retrieveHints();

	List<GlobalElementVO> retrieveHintsDesc();

	Long retrieveMaxGlobalElementId();

	GlobalElement insertGlobalElement(GlobalElement globalElement);

	Long retreiveData(String query);

	GlobalElementDetail findGlobalElementDetailUsingId(Long globalElementDetailId);

	GlobalElementDetail updateGlobalElementDetails(GlobalElementDetail existing_glblEle_details);

	Long retrieveMaxGlobalElementDetailId();

	Long retrieveMaxGlobalElementHistoryId();

	GlobalElementHistory updateGlobalElementHistory(
			GlobalElementHistory glblEleHistory);

	List<GlobalElement> retrieveGlobalElement(
			String query);

	List<GlobalElementDetailVO> retrieveGlobalElementDetail(
			String detailQuery);

	GlobalElement findElementExistingId(Long elemnt_id);

	String retreiveEleNme(String query);

	List<SystemApplicability> retrievePlatformDetails(String query);

	Long retrieveMaxCrossWalkId();

	GloblalElementCrossWalk addNewCrosswalk(GloblalElementCrossWalk globlalElementCrossWalk);	

	String retreiveEleTypDesc(String query);

	List<GloblalElementCrossWalk> crosswalkSearch(
			GlobalElementCrosswalkSearchVOBkp globalElementSearchVO);

	List<CodeValue> retrieveSearchCrossWalkCodeType(Long crosswalkAppied);

	Long countCrosswalkSearch(
			GlobalElementCrosswalkSearchVOBkp globalElementCrosswalkSearchVOBkp);

	

	List<AddCrosswalkVO> retrieveEditPlatformDetails(String query);

	Long retrieveEleTypCd(String eleTypQuery);

	List<GloblalElementCrossWalk> retrievePlatformList();

	List<GloblalElementCrossWalk> retrieveGlobalElementCrosswalk(String query);

	List<GlobalElement> retrieveUnMappedCountList();

	Long totalUnMappedElementCount();

	int deleteCrosswalk(AddCrosswalkVO globalElementId);

	Long retrieveGroupName(String trim);

	Long retrieveGroupName(String groupName, Long globalElementId);



}
