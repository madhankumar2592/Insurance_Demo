/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;

/**
 * This is used as the DAO interface for the Geography operations
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
public interface GeoStagingDAO {

	/**
	 * The method will search for the geo units by name. The user will type in
	 * the filter condition in the name field and the dao layer will retrieve
	 * the names satisfying the filter
	 * 
	 * @param nameFilter
	 * @param langaugeCode
	 * @return geoUnitNames the list of geo names
	 */
	List<GeoUnitName> searchGeoUnitByName(String nameFilter, int startIndex,
			int maxResults, String sortBy, String sortOrder, Long langaugeCode);

	/**
	 * The method will search for the geo units by code. The user will type in
	 * the filter condition in the code field and the dao layer will retrieve
	 * the codes satisfying the filter
	 * 
	 * @param codeFilter
	 * @param langaugeCode
	 * @return geoUnitCodes the list of geo codes
	 */
	List<GeoUnitCode> searchGeoUnitByCode(String codeFilter, int startIndex,
			int maxResults, String sortBy, String sortOrder, Long langaugeCode);

	/**
	 * 
	 * The method will count the records in the name search of geo units on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchString
	 * @return countResults
	 */
	Long countSearchGeoUnitByName(String searchString);

	/**
	 * 
	 * The method will count the records in the code search of geo units on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchString
	 * @return countResults
	 */
	Long countSearchGeoUnitByCode(String searchString);

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 * 
	 * @param geoUnitId
	 * @param languageCode
	 */
	GeoUnit retrieveGeoUnitByGeoUnitId(Long geoUnitId);

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 * 
	 * @param geoUnitId
	 * @param languageCode
	 */
	GeoUnit retrieveGeoUnitForDelete(Long geoUnitId);

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	List<CodeValueVO> retrieveAllCountries(Long nameType, Long languageCode);

	/**
	 * The method will retrieve all Continent details from the Search DB based
	 * on the name type code and the user preferred language code. The return
	 * type is a VO which contains the Continent Geo Unit Id and the Continent
	 * Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	List<CodeValueVO> retrieveAllContinents(Long nameType, Long languageCode);

	/**
	 * The method will retrieve the Geo Units corresponding to the
	 * parentGeoUnit, geoUnitType, nameType and languageCode which you want to
	 * retrieve the data. The retrieval is from the Search DB. The return type
	 * is a VO which contains the Geo Unit Id and the Geo Unit name.
	 * 
	 * @param languageCode
	 * @param geoUnitType
	 * @param parentGeoUnitId
	 * @param nameType
	 */
	List<CodeValueVO> retrieveChildGeoUnitsByType(Long languageCode,
			Long geoUnitType, Long parentGeoUnitId, Long nameType);

	/**
	 * Validates geoUnit to check for the existence of any child records for the
	 * corresponding geoUnit.
	 * <p>
	 * The soft delete operation on geoUnit will be dependent on the validation.
	 * <p>
	 * 
	 * @param geoUnitId
	 * @return the count of child geo unit associations
	 */
	Long validateGeoUnit(Long geoUnitId);

	/**
	 * This method will update given GeoUnit to Staging SoR DB. The return would
	 * be updated GeoUnit entity. The method is invoked when the business owner
	 * approves a request and the respective changes are to be updated from the
	 * Transactional DB to the Staging SoR.
	 * 
	 * @param GeoUnit
	 * @return status
	 */
	Boolean updateGeoUnit(GeoUnit geoUnit);

	/**
	 * 
	 * The method will identify all child entities for the specified GeoUnit Id
	 * 
	 * @param geoUnitId
	 * @return
	 */
	List<GeoUnitAssociation> retrieveChildGeoUnitAssociations(Long geoUnitId);

	/**
	 * The method will retrieve all Country Groups from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Group Geo Unit Id and the Country
	 * Names.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	List<CodeValueVO> retrieveAllCountryGroups(Long nameType, Long languageCode);

	/**
	 * Retrieves the country groups corresponds to a group id / all the country
	 * groups.
	 * <p>
	 * The resulted List of Geo unit names will be used for displaying in the
	 * Country Group search results page.
	 * <p>
	 * 
	 * @param langCode
	 * @param writingScriptCode
	 * @param nameTypeCode
	 * @param geoUnitId
	 * @return a List of GeoUnitName
	 */
	List<GeoUnitName> retrieveCountryGroups(Long langCode,
			Long writingScriptCode, Long nameTypeCode, Long geoUnitId);
	
	String getOfficialNameByGeoUnitIdAndTypeCode(Long parentGeoUnitId,
			Long geoUnitId, Long geoUnitTypeCode);
	
	List<GeoUnit> retrieveGeoUnitsByIdList(List<Long> geoUnitIds);
	
	/**
	 * the method to return all geoUnit Types
	 * @return
	 */
	List<CodeValue> retrieveAllGeoUnitTypes();
	/**
	 * 
	 * The method to retrieve all applicable GeoUnit Names
	 *
	 * @return
	 */
	List<CodeValue> retrieveApplicableGeoNameTypes();
	
	/**
	 * 
	 * The method will return the max value for the next geo unit id. When we
	 * add new country Geo Unit, we need to follow the below given logic for
	 * creating the geo unit id (both transactional and batch) 
	 * 1. New Country Geo Unit ID - Max 4 digit + 1 
	 * 2. New Country Group Geo Unit ID - Max 7 digit + 1
	 *  
	 * @param geoUnitTypeCode
	 * @return geoUnitId
	 */
	Long retrieveMaxGeoUnitId(Long geoUnitTypeCode);
	
	/**
	 * 
	 * The method will get the maximum value of of the specified GeoCode Type.
	 *
	 * @param geoCodeTypeCode
	 * @param geoUnitTypeCode
	 * @param uniqueWithInGeoUnitTypeCode
	 * @param uniqueWithInGeoUnitId
	 * @return wbCode
	 */
	String findMaxValueOfGeoCode(Long geoCodeTypeCode, Long geoUnitTypeCode,
			Long uniqueWithInGeoUnitTypeCode, Long uniqueWithInGeoUnitId);
	
	/**
	 * 
	 * The method will find the next WB code based on the configuration
	 * mentioned in the GeoCodeConfiguration entity. This method will return the
	 * next code to be assigned for a Country.
	 * 
	 * @param geoCodeTypeCode
	 * @return wbCode
	 */
	String findMaxValueOfCountryGeoCode(Long geoCodeTypeCode);

	String getOfficialNameByGeoUnitId(Long geoUnitId);
}
