/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.vo.XmlSchemaSearchVO;

/**
 * This is used as the DAO interface class for the Xml Schema Elements
 * operations. The DAO contacts the staging DB for all its operations
 * 
 * @author Cognizant
 * @version last updated : Apr 13, 2012
 * @see
 * 
 */
public interface XmlLabelsStagingDAO {

    public List<XmlSchemaElement> searchXmLSchemaLabels(XmlSchemaSearchVO xmlSchemaSearchVO);
    public XmlSchemaElement retrieveXmlSchemaByXmlElementId(String elementId);
	/**
	 * 
	 * The method will perform the table count of xml schema element on the
	 * staging db based on the specified filter conditions.
	 * 
	 * @param XmlSchemaSearchVO
	 * @return count of XmlSchemaElement
	 */
    Long countSearchXmLSchemaLabels(XmlSchemaSearchVO xmlSchemaSearchVO);
    
	/**
	 * The method will persist the updated xmlSchemaElement in the Staging
	 * DB.
	 * 
	 * @param xmlSchemaElement
	 */

	XmlSchemaElement updateXmlSchemaElement(XmlSchemaElement xmlSchemaElement);
	
	void removeDeletedXmlSchemaLabelDetail(Long xmlSchemaElementLabelDetailId);
}
