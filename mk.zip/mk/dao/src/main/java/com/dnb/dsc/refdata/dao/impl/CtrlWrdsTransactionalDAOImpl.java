/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsyCtryAppy;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.CtrlWrdsTransactionalDAO;

/**
 * This is used as the DAO implementation class for the Control Words operations.
 * The DAO contacts the staging DB for all its operations
 *
 * @author Cognizant
 * @version last updated : May 31, 2012
 * @see
 *
 */
@Repository("CtrlWrdsTransactionalDAO")
public class CtrlWrdsTransactionalDAOImpl implements CtrlWrdsTransactionalDAO {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CtrlWrdsTransactionalDAOImpl.class);
	
	private static final String QUERY_RETRIEVE_CONTROL_WORD_BY_ID = "DnbUnusGlsy.retrieveDnbUnusGlsyById";
	private static final String QUERY_REMOVE_CTRY_APPY_BY_ID = "DnbUnusGlsyCtryAppy.removeDnbUnusGlsyCtryAppyById";
	private static final String QUERY_REMOVE_CONTROL_WORD_BY_ID = "DnbUnusGlsy.removeDnbUnusGlsyById";
	private static final String QUERY_REMOVE_CONTROL_WORD_BY_ID_AND_TEXT = "DnbUnusGlsy.removeDnbUnusGlsyByIdAndText";
	private static final String QUERY_REMOVE_INDIVIDUAL_NAME_BY_ID = "DnbUnusIndNme.removeDnbUnusIndNmeById";
	private static final String QUERY_REMOVE_ADDRESS_BY_ID = "DnbUnusAdr.removeDnbUnusAdrById";
	private static final String QUERY_REMOVE_TLCM_ADDRESS_BY_ID = "DnbUnusTlcmAdr.removeDnbUnusTlcmAdrById";
	private static final String QUERY_REMOVE_PHONE_AREA_CODE_BY_ID = "PhoneAreaCode.removePhoneAreaCodeById";
	private static final String QUERY_RETRIEVE_PHONE_AREA_CODE_BY_ID = "PhoneAreaCode.retrievePhoneAreaCodeById";
	private static final String QUERY_REMOVE_PHONE_AREA_CODE_BY_PRIMARY_KEY = "PhoneAreaCode.removePhoneAreaCodeByPrimaryKey";
	private static final String QUERY_COUNT_PHONE_AREA_CODE = "PhoneAreaCode.countPhoneAreaCode";

	@PersistenceContext(unitName = "PU-Transactional")
	private EntityManager em;

    private JdbcTemplate jdbcTemplate;
	
	/**
	 * The constants for named query - count currency exchange entries
	 */
	private static final String QUERY_COUNT_INFERMENT_TEXT = "InfermentText.countInfermentText";

	/**
	 * Query to retrieve Code Value Text based on code value id.
	 */
	private static final String QUERY_RETRIEVE_INFERMENT_TEXT_BY_INFERMENT_TEXT_ID = "InfermentText.retrieveInfermentTextByInfermentTextId";

	/**
	 * the query to remove code value by id
	 */
	private static final String QUERY_REMOVE_INFERMENT_TEXT_BY_ID="InfermentText.removeApprovedInfermentText";

	/**
	 * the query to remove code value by id
	 */
	private static final String QUERY_REMOVE_INFERMENT_TEXT_COUNTRY_APPLICABILITY_BY_INFERMENT_TEXTID = "InfermentTextCountryApplicability.removeApprovedInfermentTextCountryApplicability";

	/**
	 * the query to remove code value by id
	 */
	private static final String QUERY_REMOVE_LEGAL_FORM_INFERMENT_BY_INFERMENT_TEXTID = "LegalFormInferment.removeApprovedLegalFormInferment";
	/**
	 * the query to remove code value by id
	 */
	private static final String QUERY_REMOVE_INDS_CODE_INFERMENT_BY_TEXT_ID = "IndustryCodeInferment.removeApprovedIndustryCodeInferment";

	/**
	 * Inject DataSource properties to jdbcTemplate.
	 * 
	 * @param argDataSource
	 *            the new data source
	 */
    @Autowired
    @Qualifier("txnDataSource")
    public void setDataSource(DataSource argDataSource) {
        this.jdbcTemplate = new JdbcTemplate(argDataSource);
    }
    
	/**
	 * This method returns the maximum value of inferment Text id. It does so by
	 * selecting the next value from a sequence
	 */
	@Override
	public Long retrieveMaxInfermentTextId() {
		return jdbcTemplate
				.queryForLong("SELECT SORUSR.INFR_TXT_ID_SEQ.nextval from dual");
	}
	/**
	 * This method returns the maximum value of inferment Text id. It does so by
	 * selecting the next value from a sequence
	 */
	@Override
	public Long retrieveMaxInfermentTextCountryApplicabilityId() {
		return jdbcTemplate
				.queryForLong("SELECT SORUSR.INFR_TXT_CTRY_APPY_ID_SEQ.nextval from dual");
	}
	/**
	 * The method will validate the Inferment Text for any locks (If already
	 * been opened by any other user for edit). If no lock is currently
	 * available then the method will lock the record and return FALSE
	 * indicating no lock currently. But if a lock already exists, the method
	 * will return TRUE. The lock operation will be performed in the
	 * Transactional DB.
	 *
	 * @param infermentTextId
	 */
	@Override
	public int countInfermentText(Long infermentTextId) {
		LOGGER.info("entering CtrlWrdsTransactionalDAOImpl | countInfermentText");
		Query query = em.createNamedQuery(QUERY_COUNT_INFERMENT_TEXT);
		query.setParameter("infermentTextId", infermentTextId);
		try{
		return ((Long) query.getSingleResult()).intValue();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	/**
	 * The method will persist the existing Inferment Text data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param infermentText
	 */
	@Override
	public InfermentText updateLegalFormInferment(InfermentText infermentText) {
		LOGGER.info("entering CtrlWrdsTransactionalDAOImpl | updateLegalFormInferment||infermentText: "+infermentText);
		try{
		return em.merge(infermentText);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * 
	 * Fetches the InfermentText entity by the key infermentTextId.
	 * <p>
	 * 
	 * @param infermentTextId
	 * @return InfermentText entity
	 */
	@Override
	public InfermentText retrieveInfermentTextByInfermentTextId(
			Long infermentTextId) {
		LOGGER.info("entering CtrlWrdsTransactionalDAOImpl | retrieveInfermentTextByInfermentTextId");
		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_INFERMENT_TEXT_BY_INFERMENT_TEXT_ID);
		query.setParameter("infermentTextId", Long.valueOf(infermentTextId));
		LOGGER.info("exiting CtrlWrdsTransactionalDAOImpl | retrieveInfermentTextByInfermentTextId ");
		try{
			return (InfermentText) query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * The method will remove the InfermentText data from the Transaction DB.
	 * The method will be invoked when the business owner approves a change and
	 * the respective changes have been updated in the Staging SoR.
	 *
	 * @param infermentTextId
	 * @param boolean indicating the status
	 */
	@Override
	public void removeApprovedInfermentText(Long infermentTextId) {
		LOGGER.info("entering CtrlWrdsTransactionalDAOImpl | removeApprovedInfermentText");
		// remove the InfermentText details from the table
		Query query = em.createNamedQuery(QUERY_REMOVE_INFERMENT_TEXT_BY_ID);
		query.setParameter("infermentTextId", infermentTextId);
		try{
		query.executeUpdate();
		query = em.createNamedQuery(QUERY_REMOVE_INFERMENT_TEXT_COUNTRY_APPLICABILITY_BY_INFERMENT_TEXTID);
		query.setParameter("infermentTextId", infermentTextId);
		query.executeUpdate();
		query = em.createNamedQuery(QUERY_REMOVE_LEGAL_FORM_INFERMENT_BY_INFERMENT_TEXTID);
		query.setParameter("infermentTextId", infermentTextId);
		query.executeUpdate();
		query = em.createNamedQuery(QUERY_REMOVE_INDS_CODE_INFERMENT_BY_TEXT_ID);
		query.setParameter("infermentTextId", infermentTextId);
		query.executeUpdate();
		LOGGER.info("exiting CtrlWrdsTransactionalDAOImpl | removeApprovedInfermentText");
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}
	/**
	 * The method to update the control words changes into the transaction DB 
	 * 
	 * @param dnbUnusGlsy
	 * @return DnbUnusGlsy
	 */
	public DnbUnusGlsy updateControlWord(DnbUnusGlsy dnbUnusGlsy){
		LOGGER.info("CtrlWrdsTransactionalDAOImpl - updateControlWord");
		if(dnbUnusGlsy.getDnbUnusGlsyId() ==  null){
			Long dnbUnusGlsyId = retrieveMaxDnbUnusGlsyId();
			dnbUnusGlsy.setDnbUnusGlsyId(dnbUnusGlsyId);
			if(dnbUnusGlsy.getCountryApplicability()!=null){
				for(DnbUnusGlsyCtryAppy newCtryAppy : dnbUnusGlsy.getCountryApplicability()){
					newCtryAppy.setDnbUnusGlsyId(dnbUnusGlsyId);
				}
			}
			if(dnbUnusGlsy.getDnbUnusIndNme()!=null){
				dnbUnusGlsy.getDnbUnusIndNme().setDnbUnusGlsyId(dnbUnusGlsyId);
				dnbUnusGlsy.getDnbUnusIndNme().setCreatedDate(dnbUnusGlsy.getCreatedDate());
				dnbUnusGlsy.getDnbUnusIndNme().setCreatedUser(dnbUnusGlsy.getCreatedUser());
				dnbUnusGlsy.getDnbUnusIndNme().setModifiedDate(dnbUnusGlsy.getModifiedDate());
				dnbUnusGlsy.getDnbUnusIndNme().setModifiedUser(dnbUnusGlsy.getModifiedUser());
			}
			if(dnbUnusGlsy.getTelecomAddress()!=null){
				dnbUnusGlsy.getTelecomAddress().get(0).setDnbUnusTlcmAdrId(retrieveMaxTelecomAddressId());
				dnbUnusGlsy.getTelecomAddress().get(0).setDnbUnusGlsyId(dnbUnusGlsyId);
				dnbUnusGlsy.getTelecomAddress().get(0).setCreatedDate(dnbUnusGlsy.getCreatedDate());
				dnbUnusGlsy.getTelecomAddress().get(0).setCreatedUser(dnbUnusGlsy.getCreatedUser());
				dnbUnusGlsy.getTelecomAddress().get(0).setModifiedDate(dnbUnusGlsy.getModifiedDate());
				dnbUnusGlsy.getTelecomAddress().get(0).setModifiedUser(dnbUnusGlsy.getModifiedUser());
			}
			if(dnbUnusGlsy.getDnbUnusAdr()!=null){
				dnbUnusGlsy.getDnbUnusAdr().setDnbUnusGlsyId(dnbUnusGlsyId);
				dnbUnusGlsy.getDnbUnusAdr().setCreatedDate(dnbUnusGlsy.getCreatedDate());
				dnbUnusGlsy.getDnbUnusAdr().setCreatedUser(dnbUnusGlsy.getCreatedUser());
				dnbUnusGlsy.getDnbUnusAdr().setModifiedDate(dnbUnusGlsy.getModifiedDate());
				dnbUnusGlsy.getDnbUnusAdr().setModifiedUser(dnbUnusGlsy.getModifiedUser());
			}
			if(dnbUnusGlsy.getPhoneAreaCode()!=null){
				dnbUnusGlsy.getPhoneAreaCode().setPhoneAreaCodeId(retrieveMaxPhoneAreaCodeId());
				dnbUnusGlsy.getPhoneAreaCode().setDnbUnusGlsyId(dnbUnusGlsyId);
				dnbUnusGlsy.getPhoneAreaCode().setCreatedDate(dnbUnusGlsy.getCreatedDate());
				dnbUnusGlsy.getPhoneAreaCode().setCreatedUser(dnbUnusGlsy.getCreatedUser());
				dnbUnusGlsy.getPhoneAreaCode().setModifiedDate(dnbUnusGlsy.getModifiedDate());
				dnbUnusGlsy.getPhoneAreaCode().setModifiedUser(dnbUnusGlsy.getModifiedUser());
			}
		}
		try{
		em.persist(dnbUnusGlsy);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return dnbUnusGlsy;
	}
	
	@Override
	public Long retrieveMaxDnbUnusGlsyId() {
		try{
		return jdbcTemplate.queryForLong("SELECT SORUSR.DNB_UNUS_GLSY_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	public DnbUnusGlsyCtryAppy updateDnbUnusGlsyCtryAppy(DnbUnusGlsyCtryAppy dnbUnusGlsyCtryAppy){
		LOGGER.info("CtrlWrdsTransactionalDAOImpl - updateDnbUnusGlsyCtryAppy");
		try{
		return em.merge(dnbUnusGlsyCtryAppy);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	/**
	 * The method to retrieve the control words by id
	 * 
	 * @param dnbUnusGlsyId
	 * @return DnbUnusGlsy
	 */
	@Override
	public DnbUnusGlsy retrieveControlWordById(Long dnbUnusGlsyId) {
		LOGGER.info("entering CtrlWrdsTransactionalDAOImpl | retrieveControlWordById");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("dnbUnusGlsyId", dnbUnusGlsyId);
		Query query = em.createNamedQuery(QUERY_RETRIEVE_CONTROL_WORD_BY_ID);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		LOGGER.info("exiting CtrlWrdsTransactionalDAOImpl | retrieveControlWordById");
		try {
			return (DnbUnusGlsy) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * The method to remove the approved control words text changes
	 * 
	 * @param dnbUnusGlsyId
	 * @return
	 */
	@Override
	public Boolean removeApprovedControlWord(Long dnbUnusGlsyId) {
		LOGGER.info("entering CtrlWrdsTransactionalDAOImpl | removeApprovedControlWord");

		Query query = em.createNamedQuery(QUERY_REMOVE_CTRY_APPY_BY_ID);
		query.setParameter("dnbUnusGlsyId", dnbUnusGlsyId);
		try{
		query.executeUpdate();

		query = em.createNamedQuery(QUERY_REMOVE_INDIVIDUAL_NAME_BY_ID);
		query.setParameter("dnbUnusGlsyId", dnbUnusGlsyId);
		query.executeUpdate();
		
		query = em.createNamedQuery(QUERY_REMOVE_ADDRESS_BY_ID);
		query.setParameter("dnbUnusGlsyId", dnbUnusGlsyId);
		query.executeUpdate();
		
		query = em.createNamedQuery(QUERY_REMOVE_TLCM_ADDRESS_BY_ID);
		query.setParameter("dnbUnusGlsyId", dnbUnusGlsyId);
		query.executeUpdate();
		
		query = em.createNamedQuery(QUERY_REMOVE_PHONE_AREA_CODE_BY_ID);
		query.setParameter("dnbUnusGlsyId", dnbUnusGlsyId);
		query.executeUpdate();
		
		query = em.createNamedQuery(QUERY_REMOVE_CONTROL_WORD_BY_ID);
		query.setParameter("dnbUnusGlsyId", dnbUnusGlsyId);
		query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting CtrlWrdsTransactionalDAOImpl | removeApprovedControlWord");
		return true;
	}

	@Override
	public Long retrieveMaxPhoneAreaCodeId() {
		try{
		return jdbcTemplate.queryForLong("SELECT SORUSR.PHON_AREA_CODE_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public Long retrieveMaxTelecomAddressId() {
		try{
		return jdbcTemplate.queryForLong("SELECT SORUSR.DNB_UNUS_TLCM_ADR_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	public PhoneAreaCode updatePhoneAreaCode(PhoneAreaCode phoneAreaCode){
		try{
		return em.merge(phoneAreaCode);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * The method to retrieve the approved phone area code changes
	 * 
	 * @param phoneAreaCodeId
	 * @return 
	 */
	public PhoneAreaCode retrievePhoneAreaCodeById(Long phoneAreaCodeId) {
		LOGGER.info("entering CtrlWrdsTransactionalDAOImpl | retrievePhoneAreaCodeById");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("phoneAreaCodeId", phoneAreaCodeId);

		Query query = em.createNamedQuery(QUERY_RETRIEVE_PHONE_AREA_CODE_BY_ID);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		LOGGER.info("exiting CtrlWrdsTransactionalDAOImpl | retrievePhoneAreaCodeById");
		try {
			return (PhoneAreaCode) query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method to remove the approved phone area code changes
	 * 
	 * @param phoneAreaCodeId
	 * @return 
	 */
	@Override
	public Boolean removeApprovedPhoneAreaCode(Long phoneAreaCodeId) {
		LOGGER.info("entering CtrlWrdsTransactionalDAOImpl | removeApprovedPhoneAreaCode");
		PhoneAreaCode phoneAreaCode = retrievePhoneAreaCodeById(phoneAreaCodeId);
		Long dnbUnusGlsyId = phoneAreaCode.getDnbUnusGlsyId();
		String areaCodeNumber = phoneAreaCode.getAreaCodeNumber();

		Query query = em.createNamedQuery(QUERY_REMOVE_PHONE_AREA_CODE_BY_PRIMARY_KEY);
		query.setParameter("phoneAreaCodeId", phoneAreaCodeId);
		try{
		query.executeUpdate();
		
		query = em.createNamedQuery(QUERY_REMOVE_CONTROL_WORD_BY_ID_AND_TEXT);
		query.setParameter("dnbUnusGlsyId", dnbUnusGlsyId);
		query.setParameter("dnbUnusTxt", areaCodeNumber);
		query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return true;
	}
	
	@Override
	public int countPhoneAreaCode(Long phoneAreaCodeId) {
		LOGGER.info("entering CtrlWrdsTransactionalDAOImpl | countPhoneAreaCode");
		
		Query query = em.createNamedQuery(QUERY_COUNT_PHONE_AREA_CODE);
		query.setParameter("phoneAreaCodeId", phoneAreaCodeId);
		try{
		return ((Long) query.getSingleResult()).intValue();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
}
