/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.entity.GeoCurrency;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.CurrencySearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.GeoCurrencySearchVO;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.CrcyStagingDAO;

/**
 * DAO implementation class for the Currency Exchange operations.
 * <p>
 * 
 * The DAO contacts the staging DB for all its operations.
 * <p>
 * 
 * @author Cognizant
 * @version last updated : Mar 02, 2012
 * @see
 * 
 */
@Repository("CrcyStagingDAO")
public class CrcyStagingDAOImpl implements CrcyStagingDAO {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CrcyStagingDAOImpl.class);

	@PersistenceContext(unitName = "PU-Staging")
	private EntityManager em;

	private JdbcTemplate jdbcTemplate;

	@Autowired
	@Qualifier("stgDataSource")
	public void setDataSource(DataSource argDataSource) {
		this.jdbcTemplate = new JdbcTemplate(argDataSource);
	}

	/**
	 * The constants for named query - retrieve all data providers
	 */
	private static final String QUERY_RETRIEVE_ALL_DATA_PROVIDERS = "CurrencyExchange.retrieveAllDataProviders";
	/**
	 * The constants for named query - retrieve geo unit by geo unit id
	 */
	private static final String QUERY_RETRIEVE_CURRENCY_EXCHANGE_BY_CURRENCY_EXCHANGE_ID = "CurrencyExchange.retrieveCurrencyExchangeByCurrencyExchangeId";
	private static final String QUERY_RETRIEVE_GEO_CURRENCY_BY_GEO_CURRENCY_ID = "GeoCurrency.retrieveGeoCurrencyByGeoCurrencyId";

	/**
	 * The setter method for the entity manager. The persistence context has
	 * been defined as part of the entity manager definition.
	 * 
	 * @param em
	 */
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}

	/**
	 * 
	 * Performs a hierarchy search of Currency Exchange on the search db.
	 * <p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param currencySearchCriteria
	 * @return list of CurrencyExchange
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CurrencyExchange> searchCurrencyExchange(
			CurrencySearchCriteriaVO currencySearchCriteria) {
		LOGGER.info("entering CrcyStagingDAOImpl | searchCurrencyExchange");

		StringBuffer queryStr = new StringBuffer("SELECT ");
		queryStr.append(
				"new CurrencyExchange(c.currencyExchangeId, c.fromCurrencyCode, c.toCurrencyCode, ")
				.append("c.currencyExchangeDate, c.currencyExchangeRate, c.currencyExchangeDatePrcnCode, ")
				.append("c.dataProviderCode, t1.codeValueShortDescription, t1.codeValueDescription, ")
				.append("t2.codeValueShortDescription, t2.codeValueDescription, t3.codeValueShortDescription, ")
				.append("c.createdDate, c.createdUser, c.modifiedDate, c.modifiedUser) ")
				.append("from CurrencyExchange c, CodeValueText t1, CodeValueText t2, CodeValueText t3  ")
				.append("where c.fromCurrencyCode = t1.codeValueId and c.toCurrencyCode = t2.codeValueId and ")
				.append("t1.expirationDate is null and t2.expirationDate is null and t3.expirationDate is null and ")
				.append("c.dataProviderCode = t3.codeValueId and t1.languageCode = :enLangCode and ")
				.append("t2.languageCode = :enLangCode and t3.languageCode = :enLangCode ");

		Query query = formQueryForSearchCrcyExchange(currencySearchCriteria,
				queryStr.toString(), false);
		// setting the page count and max results for pagination
		query.setMaxResults(currencySearchCriteria.getMaxResults());
		query.setFirstResult(currencySearchCriteria.getRowIndex());
		List<CurrencyExchange> result = null;
		try {
			result = (List<CurrencyExchange>) query.getResultList();
			LOGGER.info("size of result list in dao : " + result.size());
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting CrcyStagingDAOImpl | searchCurrencyExchange");
		return result;
	}

	/**
	 * 
	 * The method to get the sort index
	 * 
	 * @param sortBy
	 * @return
	 */
	private int getCurrencySortByColumnIndex(String sortBy) {
		if ("fromCurrencyShortDescription".equalsIgnoreCase(sortBy)) {
			return 2;
		} else if ("toCurrencyShortDescription".equalsIgnoreCase(sortBy)) {
			return 3;
		} else if ("currencyExchangeDate".equalsIgnoreCase(sortBy)) {
			return 4;
		} else if ("currencyExchangeRate".equalsIgnoreCase(sortBy)) {
			return 5;
		} else if ("dataProvider".equalsIgnoreCase(sortBy)) {
			return 7;
		} else {
			return 2;
		}
	}

	/**
	 * The method to retrieve all data providers for the currency exchange data.
	 * The data will be fetched from the currency exchange tables.
	 * 
	 * @param languageCode
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueVO> retrieveCurcyExchDataProviders(Long languageCode) {
		LOGGER.info("entering CrcyStagingDAOImpl | retrieveCurcyExchDataProviders");
		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(QUERY_RETRIEVE_ALL_DATA_PROVIDERS);
		query.setParameter("langCode", languageCode);
		LOGGER.info("exiting GeoStagingDAOImpl | retrieveAllContinents");
		try {
			return mapCodeValueVO(query.getResultList());
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method to convert the currency exchange entity object to a value
	 * object.
	 * 
	 * @param currencyExchanges
	 * @return
	 */
	private List<CodeValueVO> mapCodeValueVO(
			List<CurrencyExchange> currencyExchanges) {
		LOGGER.info("entering CrcyStagingDAOImpl | mapCodeValueVO");
		List<CodeValueVO> codeValueVOs = null;

		if (currencyExchanges != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (CurrencyExchange currencyExchange : currencyExchanges) {
				CodeValueVO codeValueVO = new CodeValueVO(
						currencyExchange.getDataProviderCode(),
						currencyExchange.getDataProvider(),
						currencyExchange.getDataProvider());
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting CrcyStagingDAOImpl | mapCodeValueVO");
		return codeValueVOs;
	}

	/**
	 * 
	 * The method will count the number of records returned by the query
	 * 
	 * @param searchCriteriaVO
	 * @return list of geographies
	 */
	@Override
	public Long countSearchCurrencyExchange(
			CurrencySearchCriteriaVO currencySearchCriteria) {
		LOGGER.info("entering CrcyStagingDAOImpl | countSearchCurrencyExchange");

		LOGGER.info("currencySearchCriteria :: " + currencySearchCriteria);
		Long countResults;
		StringBuffer queryStr = new StringBuffer(
				"SELECT COUNT(c.currencyExchangeId) ");

		queryStr.append(
				"from CurrencyExchange c, CodeValueText t1, CodeValueText t2, CodeValueText t3  ")
				.append("where c.fromCurrencyCode = t1.codeValueId and c.toCurrencyCode = t2.codeValueId and ")
				.append("t1.expirationDate is null and t2.expirationDate is null and t3.expirationDate is null ")
				.append("and c.dataProviderCode = t3.codeValueId and t1.languageCode = :enLangCode and ")
				.append("t2.languageCode = :enLangCode and t3.languageCode = :enLangCode ");

		Query query = formQueryForSearchCrcyExchange(currencySearchCriteria,
				queryStr.toString(), true);
		try {
			countResults = (Long) query.getSingleResult();
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}

		LOGGER.info("exiting CrcyStagingDAOImpl | countSearchCurrencyExchange");
		return countResults;
	}

	/**
	 * Searches the Staging SoR for the CurrencyExchange based on the
	 * currencyExchangeId and will return the CurrencyExchange entity.
	 * <p>
	 * 
	 * @param currencyExchangeId
	 * @return CurrencyExchange
	 */
	@Override
	public CurrencyExchange retrieveCurrencyExchangeByCurrencyExchangeId(
			Long currencyExchangeId) {
		LOGGER.info("entering CrcyStagingDAOImpl | retrieveCurrencyExchangeByCurrencyExchangeId");
		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_CURRENCY_EXCHANGE_BY_CURRENCY_EXCHANGE_ID);
		query.setParameter("currencyExchangeId", currencyExchangeId);
		LOGGER.info("exiting CrcyStagingDAOImpl | retrieveCurrencyExchangeByCurrencyExchangeId");
		Object result = null;
		try {
			result = query.getSingleResult();
		} catch (NoResultException ex) {
			return null;
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return (CurrencyExchange) result;
	}

	/**
	 * The method will persist the existing Currency Exchange data in the
	 * Staging DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param currencyExchange
	 */
	@Override
	public CurrencyExchange updateExchangeRate(CurrencyExchange currencyExchange) {
		LOGGER.info("entering CrcyTransactionalDAOImpl | updateExchangeRate");
		try {
			return em.merge(currencyExchange);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method will construct the query instance for the search currency
	 * exchange functionality. The query string with the query parameters will
	 * be appended and the entity manager is invoked to form the query
	 * 
	 * @param currencySearchCriteria
	 * @param selectQuery
	 * @param isCountQuery
	 * @return
	 */
	private Query formQueryForSearchCrcyExchange(
			CurrencySearchCriteriaVO currencySearchCriteria,
			String selectQuery, boolean isCountQuery) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer();
		queryStr.append(selectQuery);

		parameters.put("enLangCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		if (null != currencySearchCriteria.getFromCurrencyCode()
				&& currencySearchCriteria.getFromCurrencyCode().length() > 0) {
			queryStr.append(" and c.fromCurrencyCode = :fromCurrencyCode");
			parameters.put("fromCurrencyCode",
					Long.valueOf(currencySearchCriteria.getFromCurrencyCode()));
		}
		if (null != currencySearchCriteria.getToCurrencyCode()
				&& currencySearchCriteria.getToCurrencyCode().length() > 0) {
			queryStr.append(" and c.toCurrencyCode = :toCurrencyCode");
			parameters.put("toCurrencyCode",
					Long.valueOf(currencySearchCriteria.getToCurrencyCode()));
		}
		if (null != currencySearchCriteria.getFromDate()
				&& null != currencySearchCriteria.getToDate()) {
			queryStr.append(" and c.currencyExchangeDate between ");
			queryStr.append(" :currencyExchangeFromDate and :currencyExchangeToDate");
			parameters.put("currencyExchangeFromDate",
					currencySearchCriteria.getFromDate());
			parameters.put("currencyExchangeToDate",
					currencySearchCriteria.getToDate());
		}
		if (null != currencySearchCriteria.getDataProviderCode()
				&& currencySearchCriteria.getDataProviderCode().length() > 0) {
			queryStr.append(" and c.dataProviderCode = :dataProviderCode");
			parameters.put("dataProviderCode",
					Long.valueOf(currencySearchCriteria.getDataProviderCode()));
		}
		/**
		 * If only count is required then no need for order by clause in the
		 * query. Checking for isCountQuery in the if condition
		 */
		if (!isCountQuery) {
			queryStr.append(" order by ");
			queryStr.append(getCurrencySortByColumnIndex(currencySearchCriteria
					.getSortBy()));
			queryStr.append(" ");
			queryStr.append(currencySearchCriteria.getSortOrder());
		}
		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}

	/**
	 * 
	 * Performs a hierarchy search of Geo Currency on the SOR db.
	 * <p>
	 * 
	 * The search will be done on the db based on the search criteria the user
	 * had provided.
	 * 
	 * @param geoCurrencySearchVO
	 * @return list of GeoCurrency
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<GeoCurrency> searchGeoCurrency(
			GeoCurrencySearchVO geoCurrencySearchVO) {
		LOGGER.info("entering CrcyStagingDAOImpl | searchCurrencyExchange");

		StringBuffer queryStr = new StringBuffer("SELECT ");
		queryStr.append(
				"new GeoCurrency(c.geoCurrencyId, c.geoUnitId, g.geoName, ")
				.append("c.currencyCode, t.codeValueDescription, c.effectiveDate, ")
				.append("c.endDate) from GeoCurrency c, CodeValueText t, GeoUnitName g ")
				.append("where c.geoUnitId = g.geoUnitId and g.expirationDate is null and ")
				.append("g.expiredByDate is null and g.languageCode = :enLangCode and g.nameTypeCode = 32 and t.expirationDate is null and ")
				.append("c.currencyCode = t.codeValueId and t.languageCode = :enLangCode ");

		Query query = formQueryForSearchGeoCrcy(geoCurrencySearchVO,
				queryStr.toString(), false);
		// setting the page count and max results for pagination
		if(geoCurrencySearchVO.getViewType() == null){
		query.setMaxResults(geoCurrencySearchVO.getMaxResults());
		query.setFirstResult(geoCurrencySearchVO.getRowIndex());
		}
		List<GeoCurrency> result = null;
		try {
			result = (List<GeoCurrency>) query.getResultList();
			LOGGER.info("size of result list in dao : " + result.size());
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting CrcyStagingDAOImpl | searchCurrencyExchange");
		return result;
	}

	/**
	 * 
	 * The method will construct the query instance for the search currency
	 * exchange functionality. The query string with the query parameters will
	 * be appended and the entity manager is invoked to form the query
	 * 
	 * @param currencySearchCriteria
	 * @param selectQuery
	 * @param isCountQuery
	 * @return
	 */
	private Query formQueryForSearchGeoCrcy(
			GeoCurrencySearchVO geoCurrencySearchVO, String selectQuery,
			boolean isCountQuery) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer();
		queryStr.append(selectQuery);

		parameters.put("enLangCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		if (null != geoCurrencySearchVO.getGeoUnitId()) {
			queryStr.append(" and c.geoUnitId = :geoUnitId order by c.geoCurrencyId ");
			parameters.put("geoUnitId",
					Long.valueOf(geoCurrencySearchVO.getGeoUnitId()));
		} else {

			queryStr.append(" order by c.geoCurrencyId ");
		}

		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}

	/**
	 * 
	 * The method will count the records in the geo currency table based on user
	 * inputs in db. The search will be done on the SOR db based on the search
	 * criteria the user had provided.
	 * 
	 * @param geoCurrencySearchCriteria
	 * @return countResults
	 */
	@Override
	public Long countSearchGeoCurrency(GeoCurrencySearchVO geoCurrencySearchVO) {
		LOGGER.info("entering CrcyStagingDAOImpl | countSearchCurrencyExchange");

		LOGGER.info("currencySearchCriteria :: " + geoCurrencySearchVO);
		Long countResults;
		StringBuffer queryStr = new StringBuffer(
				"SELECT COUNT(c.geoCurrencyId) ");

		queryStr.append(" from GeoCurrency c, CodeValueText t, GeoUnitName g ")
				.append("where c.geoUnitId = g.geoUnitId and g.expirationDate is null and ")
				.append("g.expiredByDate is null and g.languageCode = :enLangCode and g.nameTypeCode = 32 and t.expirationDate is null and ")
				.append("c.currencyCode = t.codeValueId and t.languageCode = :enLangCode ");

		Query query = formQueryForSearchGeoCrcy(geoCurrencySearchVO,
				queryStr.toString(), true);
		try {
			countResults = (Long) query.getSingleResult();
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}

		LOGGER.info("exiting CrcyStagingDAOImpl | countSearchCurrencyExchange");
		return countResults;
	}

	/**
	 * Retrieve the next Geo Currency Id value using the sequence
	 */
	@Override
	public Long retrieveMaxGeoCurrencyId() {
		try {
			return jdbcTemplate
					.queryForLong("SELECT SORUSR.GEO_CRCY_ID_SEQ.nextval from dual");

		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			LOGGER.error("GlobalElementStagingDAOImpl | retreiveData", ex);
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will persist the existing Geo Currency data in the SOR DB.
	 * Only the changed relational data will be inserted.
	 * 
	 * @param geoCurrency
	 */
	@Override
	public GeoCurrency insertGeoCurrency(GeoCurrency geoCurrency) {
		try {
			return em.merge(geoCurrency);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
@Override
	public GeoCurrency retrieveGeoCurrencyByGeoCurrencyId(Long geoCurrencyId) {
		LOGGER.info("entering CrcyStagingDAOImpl | retrieveGeoCurrencyByGeoCurrencyId");
		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_GEO_CURRENCY_BY_GEO_CURRENCY_ID);
		query.setParameter("geoCurrencyId", geoCurrencyId);
		LOGGER.info("exiting CrcyStagingDAOImpl | retrieveGeoCurrencyByGeoCurrencyId");
		Object result = null;
		try {
			result = query.getSingleResult();
		} catch (NoResultException ex) {
			return null;
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return (GeoCurrency) result;
	}

	@Override
	public GeoCurrency updateGeoCurrency(GeoCurrency geoCurrency) {
		GeoCurrency updatedGeoCurrency = null;
		
		try {
			updatedGeoCurrency =  em.merge(geoCurrency);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		
		return updatedGeoCurrency;
	}
}
