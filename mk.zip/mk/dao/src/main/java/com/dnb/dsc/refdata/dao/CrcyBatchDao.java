/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.Date;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CurrencyExchange;

/**
 * DAO interface class for the Currency Exchange Batch operations.
 * <p>
 * 
 * The DAO contacts the staging DB for all its operations.
 * <p>
 * 
 * @author Cognizant
 * @version last updated : May 02, 2012
 * @see
 * 
 */
public interface CrcyBatchDao {
	/**
	 * 
	 *  The method to save the currency exchange bulk info
	 *
	 * @param currencyList
	 */
	public void save(List<? extends CurrencyExchange> currencyList,String userId);

	/**
	 * The method to update the currency exchange bulk info
	 * 
	 * @param currency
	 */
	public void update(CurrencyExchange currency);
	
	/**
	 * The method to get code value list
	 * 
	 * 
	 */
	public List<CodeValue> getCodeValueList();
	
	/**
	 * The method to check crcy id available
	 * 
	 * 
	 */
	public boolean isCrcyExchIdAvail(Long crcyExchId);
	
	/**
	 * The method to check duplicate crcy record
	 * 
	 * 
	 */
	public boolean isDuplicateCrcy(Long fromCrcyCD,Long toCrcyCD,Date exchDate,Long prcnCode);

}
