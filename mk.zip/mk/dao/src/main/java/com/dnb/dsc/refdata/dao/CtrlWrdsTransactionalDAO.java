/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;

/**
 * This is used as the DAO interface for the Control Words operations
 * 
 * @author Cognizant
 * @version last updated : May 03, 2012
 * @see
 * 
 */
public interface CtrlWrdsTransactionalDAO {
	/**
	 * 
	 * The method to update control word
	 *
	 * @param dnbUnusGlsy
	 * @return
	 */
	DnbUnusGlsy updateControlWord(DnbUnusGlsy dnbUnusGlsy);	
	/**
	 * 
	 * The method to retrieve control word by control word identifier
	 *
	 * @param dnbUnusGlsyId
	 * @return
	 */
	DnbUnusGlsy retrieveControlWordById(Long dnbUnusGlsyId);
	/**
	 * 
	 * The method to remove the control words data from transaction DB after user approval
	 *
	 * @param domainId
	 */
	Boolean removeApprovedControlWord(Long dnbUnusGlsyId);
	/**
	 * 
	 * The method to remove the approved phone area code details from the transaction DB
	 *
	 * @param domainId
	 */
	Boolean removeApprovedPhoneAreaCode(Long phoneAreaCodeId);
	/**
	 * The method will validate the Inferment Text for any locks (If already
	 * been opened by any other user for edit). If no lock is currently
	 * available then the method will lock the record and return FALSE
	 * indicating no lock currently. But if a lock already exists, the method
	 * will return TRUE. The lock operation will be performed in the
	 * Transactional DB.
	 * 
	 * @param infermentTextId
	 */
	int countInfermentText(Long infermentTextId);

	/**
	 * The method will persist the existing InfermentText data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param infermentText
	 */
	InfermentText updateLegalFormInferment(InfermentText infermentText);

	/**
	 * 
	 * Fetches the InfermentText entity by the key infermentTextId.
	 * <p>
	 * 
	 * @param infermentTextId
	 * @return InfermentText entity
	 * @throws Exception
	 */
	InfermentText retrieveInfermentTextByInfermentTextId(Long infermentTextId);
	
	/**
	 * This method deletes the approved InfermentText data from the transaction DB
	 * @param infermentTextId
	 */
	void removeApprovedInfermentText(Long infermentTextId);
        /**
	 * This method returns the maximum value of inferment Text id. It does so by
	 * selecting the next value from a sequence
	 */
	Long retrieveMaxInfermentTextId();
    /**
	 * This method returns the maximum value of inferment Text countryApplicability id. It does so by
	 * selecting the next value from a sequence
	 */
	Long retrieveMaxInfermentTextCountryApplicabilityId();
	/**
	 * 
	 * This method returns the maximum value of inferment Text countryApplicability id. It does so by
	 * selecting the next value from a sequence
	 *
	 * @return
	 */
	Long retrieveMaxPhoneAreaCodeId();
	/**
	 * 
	 * This method returns the maximum value of inferment Text countryApplicability id. It does so by
	 * selecting the next value from a sequence
	 *
	 * @return
	 */
	Long retrieveMaxTelecomAddressId();
	/**
	 * 
	 * The method to update the phone area code
	 *
	 * @param phoneAreaCode
	 * @return
	 */
	PhoneAreaCode updatePhoneAreaCode(PhoneAreaCode phoneAreaCode);	
	/**
	 * 
	 * The method to retrieve the phone area code by id
	 *
	 * @param phoneAreaCodeId
	 * @return
	 */
	PhoneAreaCode retrievePhoneAreaCodeById(Long phoneAreaCodeId);
	/**
	 * 
	 * This method returns the maximum value of inferment Text countryApplicability id. It does so by
	 * selecting the next value from a sequence
	 *
	 * @return
	 */
	Long retrieveMaxDnbUnusGlsyId();
	
	int countPhoneAreaCode(Long phoneAreaCodeId);
}
