package com.dnb.dsc.refdata.dao;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.MarketGroup;
import com.dnb.dsc.refdata.core.entity.ProdRescScrGru;
import com.dnb.dsc.refdata.core.entity.Product;
import com.dnb.dsc.refdata.core.entity.ProductAvailability;
import com.dnb.dsc.refdata.core.entity.ProductDetails;
import com.dnb.dsc.refdata.core.entity.ProductGroup;
import com.dnb.dsc.refdata.core.entity.ProductMarket;
import com.dnb.dsc.refdata.core.entity.Resource;
import com.dnb.dsc.refdata.core.entity.ResourceDetails;
import com.dnb.dsc.refdata.core.entity.ResourceGroup;
import com.dnb.dsc.refdata.core.entity.ResourceMapping;
import com.dnb.dsc.refdata.core.entity.SalesChannel;
import com.dnb.dsc.refdata.core.entity.SalesChannelDetails;
import com.dnb.dsc.refdata.core.vo.AddNewProductsVO;
import com.dnb.dsc.refdata.core.vo.ProductMetaData;
import com.dnb.dsc.refdata.core.vo.ProductResources;
import com.dnb.dsc.refdata.core.vo.ProductScoreMappingVO;
import com.dnb.dsc.refdata.core.vo.ProductScoreReportVO;
import com.dnb.dsc.refdata.core.vo.ProductSearchVO;
import com.dnb.dsc.refdata.core.vo.ProductVO;
import com.dnb.dsc.refdata.core.vo.ResourceMetadataVO;
import com.dnb.dsc.refdata.core.vo.SalesMetadataVO;
import com.dnb.dsc.refdata.core.vo.ScoreMappingListVO;


public interface ProductStagingDAO {

	List<CodeValue> retrieveProductTypeCodeValues(ProductVO productSearchVO);

	List<CodeValue> retrieveResourceTypeCodeValues(
			ProductVO productSearchVO);

	Long retreiveIds(String query);

	List<ProductSearchVO> productSearch(ProductSearchVO productSearchVO);
	Long retreiveData(String query);

	Product findProductUsingId(Long product_id);

	Product updateProduct(Product product);

	Long retrieveMaxProductId();

	ProductGroup findProductGroupUsingId(Long product_grp_id);

	ProductGroup updateProductGroup(ProductGroup product_grp);

	Long retrieveMaxProductGroupId();

	ProductDetails findProductDetailsUsingId(Long product_detail_id);

	ProductDetails updateProductDetails(ProductDetails product_details);

	Long retrieveMaxProductDetailId();

	SalesChannel findSalesChannelUsingId(Long sales_channel_id);

	SalesChannel updateSalesChannel(SalesChannel sales_channel);

	Long retrieveMaxSalesChannelId();

	SalesChannelDetails findSalesChannelDetailsUsingId(
			Long sales_channel_detail_id);

	SalesChannelDetails updateSalesChannelDetails(
			SalesChannelDetails sales_channel_details);

	Long retrieveMaxSalesChannelDetailsId();

	ProductAvailability findProductAvailabilityUsingId(
			Long product_availability_id);

	ProductAvailability updateProductAvailability(
			ProductAvailability product_availability);

	Long retrieveMaxProductAvailabilityId();

	ProductMarket findProductMarketUsingId(Long product_market_id);

	ProductMarket updateProductMarket(ProductMarket product_market);

	Long retrieveMaxProductMarketId();

	MarketGroup findMarketGroupUsingId(Long market_group_id);

	MarketGroup updateMarketGroup(MarketGroup market_group);

	Long retrieveMaxMarketGroupId();

	Resource findResourceUsingId(Long resource_id);

	Resource updateResource(Resource resource);

	Long retrieveMaxResourceId();

	ResourceMapping findResourceMappingUsingId(Long resource_mapping_id);

	ResourceGroup findResourceGroupUsingId(Long resource_group_id);

	ResourceDetails findResourceDetailsUsingId(Long resource_details_id);

	ResourceMapping updateResourceMapping(ResourceMapping resource_mapping);

	ResourceGroup updateResourceGroup(ResourceGroup resource_group);

	ResourceDetails updateResourceDetails(ResourceDetails resource_details);

	Long retrieveMaxResourceMappingId();

	Long retrieveMaxResourceGroupId();

	Long retrieveMaxResourceDetailsId();

	Product findProduct(Long prodId);

	ProductAvailability findProductAvailability(Long prodAvailId);

	SalesChannel findSalesChannel(Long saleChnlid);

	ProductMarket findProductMarket(Long prodMktId);

	ResourceMapping findResourceMapping(Long rescMapId);

	Resource findResource(Long rescId);

	ProductGroup findProductGroup(Long prodGrpId);

	ProductDetails findProductDetails(Long prodDtlId);

	MarketGroup findMarketGroup(Long mktGrpId);

	ResourceGroup findResourceGroup(Long rescGrpId);

	ResourceDetails findResourceDetails(Long rescDtlID);

	SalesChannelDetails findSalesChannelDetails(Long slsChnlDtlID);

	List<ProductScoreReportVO> productScrReport(
			ProductScoreReportVO productScoreReportVO);

	List<CodeValue> retrieveGranularityCodes(Long scoreType);

	List<CodeValue> retrieveProductCodeValues(AddNewProductsVO addNewProductsVO);

	List<CodeValue> retrieveProdFamCode(Long prodCode);

	List<Product> retrieveProdVers(Long prodCode);

	List<CodeValue> retrieveResource(Long prodCode);

	List<Product> retrieveFamProdVersion(Long famCode,Long prodCode);

	List<CodeValue> retrieveFamVerResource(Long famCode, Long prodCode);

	List<CodeValue> retrieveProdFamVerResource(Long famCode, Long prodCode,
			Long prodVer);

	List<Long> retreiveScrTypAssnIds(String scr_typ_assn_Query);

	ProdRescScrGru findProdRescScrGruId(Long prodRescScrGruId);

	ProdRescScrGru updateProdRescScrGru(ProdRescScrGru prodRescScrGruExist);
	
	List<ProductMetaData> retreiveProdDtlInfo(String scr_typ_assn_Query);

	void removeDtlID(String prodDtl, String deleteQuery, String parameter,Long prod_id,String prodParameter);

	void removeDtlID(List<Long> prodDtlIdList, String deleteQuery,
			String parameter, Long prod_id, String prodParameter);

	List<SalesMetadataVO> retrieveSalesDtlInfo(String sales_query);

	void removeSalesDtlId(List<Long> salesChnlDtlIdList, String deleteQuery,
			String parameter, Long sales_channel_id, String salesParameter);

	List<ResourceMetadataVO> retreiveRescDtlInfo(String resc_query);

	void removeRescDtlId(List<Long> rescDtlIdList, String deleteQuery,
			String parameter, String rescParameter, Long resource_Id);

	List<Long> retrieveRescId(Long prodId);
	
	ProductResources retreiveRescDetails(String qry);
	
	List<ResourceMetadataVO> retreiveRescMetaDetails(String qry);

	List<Long> retrieveRescIds(String rescIdQuery);

	List<Long> retrieveMapIds(String rescMapId_query);

	void removeRescDtl(String deleteRescDtl);

	Long countMapId(String query);

	void removeProdRescToScrGrn(String deleteProdRescToScrGrn);

	void removeMapIds(String deleteMapIds);

	void removeRescId(String deleteRescId);
	
	List<ResourceMapping> retrieveAllRescId(Long prodId,List<Long> rescId);
	
	void removeRescDtlID(List<Long> rescIdNot, String deleteQuery, String parameter,List<Long> rescId,String prodParameter);

ProductScoreMappingVO retreiveProdDetails(Long rescMapId);

	List<ScoreMappingListVO> retreiveScrDetails(Long rescMapId);

	List<Long> retrieveProdScoreMapId(List<Long> scoreDtlId,Long rescMapId);
	
	List<Long> retrieveProdScoreMapId(Long rescMapId);

	void removeProdRescID(List<Long> prodDtlIdList, String deleteQuery,
			String parameter);

	List<Long> retrieveProductMarketDetails(Long prodAvailId);
	
	
}
