/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.core.vo.SCoTSSearchCriteriaVO;
import com.dnb.dsc.refdata.dao.GeoStagingDAO;
import com.dnb.dsc.refdata.dao.SCoTsStagingDAO;
import com.googlecode.ehcache.annotations.Cacheable;

/**
 * This is used as the DAO implementation class for the SCoTS operations. The
 * DAO contacts the code tables for all its operations
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 *
 */
@Repository("SCoTsStagingDAO")
public class SCoTsStagingDAOImpl implements SCoTsStagingDAO {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SCoTsStagingDAOImpl.class);

	@PersistenceContext(unitName = "PU-Staging")
	private EntityManager em;
	
	private JdbcTemplate jdbcTemplate;  
	
	@Autowired
	private GeoStagingDAO geoStagingDao;

	/**
	 *
	 * The method will create the named query instance by setting the query
	 * parameters. The method is invoked for all name query operations.
	 *
	 * @param sql
	 * @param parameters
	 * @return
	 */
	private Query createNamedQuery(String sql, Map<String, Object> parameters) {
		Query query = em.createNamedQuery(sql);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}

	/**
	 * The query to retrieve all code values based on the input code table Ids
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUES = "CodeValue.retrieveCodeValues";
	
	private static final String QUERY_RETRIEVE_MKT_GRP_CODE_VALUES = "CodeValue.retrieveMktGrpCodes";
	
	private static final String QUERY_RETRIEVE_CODE_VALUES_SCR = "CodeValue.retrieveCodeValuesScr";

	/**
	 * The query to retrieve all code values based on the input code table Ids
	 */
	private static final String QUERY_RETRIEVE_GROUP_LEVEL_CODES = "CodeValue.retrieveGroupLevelCodes";

	/**
	 * The query to retrieve all code values based on the input code value Ids
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUES_BY_IDS = "CodeValue.retrieveCodeValuesById";

	/**
	 * The query to retrieve the Code Table details based on the filter
	 * condition
	 */
	private static final String QUERY_RETRIEVE_CODE_TABLES_START = "SELECT ct from CodeTable ct ";

	/**
	 * The query to retrieve the Code Value details based on the filter
	 * condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUES_START = "SELECT new CodeValue(cv.codeValueId, "
			+ "cvt.codeValueDescription, cv.businessDescription) from CodeValue cv, CodeValueText cvt ";

	/**
	 * The query to retrieve the count of Code Table details based on the filter
	 * condition
	 */
	private static final String QUERY_COUNT_CODE_TABLES_START = "SELECT count(ct.codeTableId) from CodeTable ct ";

	/**
	 * The query to retrieve the count of Code Value details based on the filter
	 * condition
	 */
	private static final String QUERY_COUNT_CODE_VALUES_START = "SELECT count(cv.codeValueId) from CodeValue cv, CodeValueText cvt ";

	/**
	 * The query to retrieve the Code Table details based on the system filter
	 */
	private static final String QUERY_RETRIEVE_CODE_TABLES_JOIN_SYSAPPY = " ,SystemApplicability sa ";

	/**
	 * The query to retrieve the Code Table details based on the country
	 * applicability filter
	 */
	private static final String QUERY_RETRIEVE_CODE_TABLES_JOIN_CTRYAPPY = " ,CountryApplicability ca ";

	/**
	 * The query to retrieve the Code Table details based on the country
	 * applicability filter
	 */
	private static final String QUERY_RETRIEVE_CODE_TABLES_JOIN_CTRYAPPY_CND = "and ct.codeTableId = ca.codeTableId"
			+ "  and ca.applicabilityIndicator = 1 ";

	/**
	 * The query to retrieve the Code Value details based on the country
	 * applicability filter
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUES_JOIN_CTRYAPPY_CND = "and cv.codeValueId = ca.codeValueId"
			+ "  and ca.applicabilityIndicator = 0 and ca.codeTableId = :caCodeTableId ";

	/**
	 * The query to retrieve the Code Table details based on the system
	 * applicability filter
	 */
	private static final String QUERY_RETRIEVE_CODE_TABLES_JOIN_SYSAPPY_CND = "and ct.codeTableId = sa.codeTableId"
			+ " and sa.applicabilityIndicator = 1 ";

	/**
	 * The query to retrieve the Code Value details based on the system
	 * applicability filter
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUES_JOIN_SYSAPPY_CND = "and cv.codeValueId = sa.codeValueId"
			+ " and sa.applicabilityIndicator = 0 and sa.expirationDate is null and sa.codeTableId = :saCodeTableId ";

	/**
	 * The query to retrieve the Code Value details based on the system
	 * applicability filter
	 */
	private static final String QUERY_RETRIEVE_CODE_TABLES_CTRYAPPY_CND = " and ca.countryGeoUnitId = :ctryGeoUnitId ";

	/**
	 * The query to retrieve the Code Table details based on the table
	 * description filter
	 */
	private static final String QUERY_RETRIEVE_CODE_TABLES_FL_TBLDESC = " and ("
			+ "upper(ct.codeTableName) like concat('%', upper(:tableDescription), '%') or "
			+ "upper(ct.businessDescription) like concat('%', upper(:tableDescription), '%') )";

	/**
	 * The query to retrieve the Code Table details based on the table
	 * description filter - code table id
	 */
	private static final String QUERY_RETRIEVE_CODE_TABLES_FL_TBLID = " and ct.codeTableId = :tableDescription ";

	/**
	 * The query to retrieve all the code tables from the DB
	 */
	private static final String QUERY_RETRIEVE_CODE_TABLE_LIST = "CodeTable.retrieveCodeTableList";

	/**
	 * The query to retrieve all the code languages from the DB. Code
	 * descriptions are available in these languages
	 */
	private static final String QUERY_RETRIEVE_CODE_LANGUAGES = "CodeValueText.retrieveLanguages";

	/**
	 * the query to retrieve all the applicable systems based on the selected
	 * code table
	 */
	private static final String QUERY_RETRIEVE_SYSTEM_APPLICABILITY_FOR_CODE_TABLES = "SystemApplicability.retrieveSystemsForCodeTable";

	/**
	 * the query to retrieve all the applicable systems based on the selected
	 * code table
	 */
	private static final String QUERY_RETRIEVE_APPLICABILE_SYSTEMS_FOR_CODE_TABLES = "SystemApplicability.retrieveCodeTableSystems";

	/**
	 * The query to retrieve all systems based on the input code value Id
	 */
	private static final String QUERY_RETRIEVE_SYSTEM_APPLICABILITY_FOR_CODE_VALUES ="SystemApplicability.retrieveSystemsForCodeValue";
	private static final String QUERY_RETRIEVE_CODE_VALUE_SYSTEM_APPLICABILITY_FOR_CODE = "SystemApplicability.retrieveCodeValueSystemForCode";
	private static final String QUERY_RETRIEVE_CODE_TABLE_SYSTEM_APPLICABILITY_FOR_CODE = "SystemApplicability.retrieveCodeTableSystemForCode";

	private static final String QUERY_RETRIEVE_CODE_VALUE_MARKET_FOR_CODE = "CountryApplicability.retrieveCodeValueCountryForCode";
	private static final String QUERY_RETRIEVE_CODE_TABLE_MARKET_FOR_CODE = "CountryApplicability.retrieveCodeTableCountryForCode";

	/**
	 * the query to retrieve all the systems without any filtering
	 */
	private static final String QUERY_RETRIEVE_ALL_SYSTEM_APPLICABILITY = "SystemApplicability.retrieveAllSystems";

	/**
	 * the query to retrieve all the systems without any filtering and
	 * irrespective of indicator
	 */
	private static final String QUERY_RETRIEVE_ALL_SYSTEM_APPLICABILITY_IRRESP_OF_IND = "SystemApplicability.retrieveAllSystemsIrrespOfInd";

	/**
	 * the query to retrieve all the applicable countries based on the selected
	 * code table
	 */
	private static final String QUERY_RETRIEVE_COUNTRY_APPLICABILITY = "CountryApplicability.retrieveCountries";

	/**
	 * the query to retrieve all the applicable countries based on the selected
	 * code table
	 */
	private static final String QUERY_RETRIEVE_COUNTRY_APPLICABILITY_FOR_CODE_TABLE = "CountryApplicability.retrieveCountriesForCodeTable";

	/**
	 * the query to retrieve all the applicable countries based on the selected
	 * code table
	 */
	private static final String QUERY_RETRIEVE_COUNTRY_APPLICABILITY_FOR_CODE_VALUES = "CountryApplicability.retrieveCountriesForCodeValue";

	/**
	 * the query to retrieve all the applicable countries based on the search
	 * criteria
	 */
	private static final String QUERY_SEARCH_SYSTEM = "SystemApplicability.searchSystemByCodeTable";

	/**
	 * the query to retrieve all the applicable countries based on the search
	 * criteria
	 */
	private static final String QUERY_SEARCH_COUNTRY = "CountryApplicability.searchCountryByCodeTable";

	/**
	 * the query to retrieve all the systems without any filtering
	 */
	private static final String QUERY_RETRIEVE_ALL_COUNTRY_APPLICABILITY = "CountryApplicability.retrieveAllCountries";

	/**
	 * The query to retrieve the Code Value details based on the table id filter
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUES_FL_TBLID = " and cv.codeTableId = :codeTableId and cv.expirationDate is null ";

	/**
	 * The query to retrieve the Code Value details based on the language code
	 * filter
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUES_FL_LANGCD = " and cvt.languageCode = :langCode ";
	
	/**
	 * The query to retrieve the Code Value details based on the expiration date
	 * Included to implement the fix for 208410455(the issue of displaying expired Code Value Description in Search Codes by CodeValue)
	 */
	private static final String QUERY_SEARCH_CODE_VALUES_EXPN_DT = " and cvt.expirationDate is null ";

	/**
	 * The query to retrieve the Code Table details based on the system
	 * applicability filter
	 */
	private static final String QUERY_RETRIEVE_CODE_TABLES_SYSAPPY_CND = " and sa.dnbSystemCode = :dnbSystemCode ";

	/**
	 * The select query to retrieve the Code Value details based on the
	 * description/ business description
	 */
	private static final String QUERY_SEARCH_CODE_VALUES_SELECT = "SELECT new CodeValue("
			+ "cv.codeValueId, cvt.codeValueDescription, cv.businessDescription, ct.codeTableId, ct.businessDescription, ct.codeTableName) ";

	/**
	 * The select query to retrieve the Code Value details based on the
	 * description/ business description
	 */
	private static final String QUERY_SEARCH_CODE_VALUES_LANG_CND = " and cvt.languageCode = :langCode ";

	/**
	 * The filter query to retrieve the Code Value details based on the code
	 * value Id
	 */
	private static final String QUERY_SEARCH_CODE_VALUES_VALID_CND = " and cv.codeValueId = :codeValId and cv.expirationDate is null ";

	/**
	 * The filter query to retrieve the Code Value details based on the
	 * description/ business description
	 */
	private static final String QUERY_SEARCH_CODE_VALUES_VALDESC_CND = " and upper(cvt.codeValueDescription) like concat('%', upper(:codeDesc), '%') ";

	/**
	 * The from query to retrieve the Code Value details based on the business
	 * description
	 */
	private static final String QUERY_SEARCH_CODE_VALUES_BUSDESC_CND = " and upper(cv.businessDescription) like concat('%', upper(:codeBusDesc), '%') ";

	/**
	 * The from query to retrieve the Code Value details based on the
	 * description
	 */
	private static final String QUERY_SEARCH_CODE_VALUES_FROM = " FROM CodeValue cv, CodeTable ct, CodeValueText cvt WHERE "
			+ "cv.codeTableId = ct.codeTableId and cv.codeValueId = cvt.codeValueId and cvt.expirationDate is null";

	/**
	 * The count query to retrieve the Code Value details based on the
	 * description/ business description
	 */
	private static final String QUERY_SEARCH_CODE_VALUES_COUNT = "SELECT count(cv.codeValueId) ";

	/**
	 * Query to retrieve Code Value Text based on code value id.
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUE_BY_CODE_VALUE_ID = "CodeValue.retrieveCodeValueByCodeValueId";

	/**
	 * Query to retrieve Code Value associations
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUE_ASSOCIATIONS_SELECT = "SELECT a from CodeValueAssociation a ";

//	private static final String QUERY_RETRIEVE_CODE_VALUE_ASSOCIATIONS_UICONFIG = "SELECT a from soruiconfig.CodeValueAssociation a ";

	/**
	 * Query to retrieve Code Value associations parent code table id condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN1 = ",CodeValue c1 ";

	/**
	 * Query to retrieve Code Value associations parent code table id condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN1_1 = " and c1.codeValueId = a.parentCodeValueId ";

	/**
	 * Query to retrieve Code Value associations child code table id condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN2 = ",CodeValue c2 ";

	/**
	 * Query to retrieve Code Value associations parent code table id condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN2_1 = " and c2.codeValueId = a.childCodeValueId ";

	/**
	 * Query to retrieve Code Value associations - append parent code table id
	 * condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VAL_ASSN_PRNT_CDTBL_ID = " and c1.codeTableId = :parentCodeTableId ";

	/**
	 * Query to retrieve Code Value associations - append parent code table id
	 * condition
	 */
	private static final String QUERY_RETRIEVE_CODE_VAL_ASSN_CHLD_CDTBL_ID = " and c2.codeTableId = :childCodeTableId ";

	/**
	 * Query to retrieve Code Value Alt Scheme - append parent code table id
	 * condition
	 */
	private static final String QUERY_RETRIEVE_ALL_ALT_SCHEME_CODES = "CodeValueAlternateScheme.retrieveAllSchemeCodes";

	/**
	 * Query to retrieve Code Value Alt Scheme - fetch by scheme type code
	 */
	private static final String QUERY_RETRIEVE_ALT_SCHEME_BY_CODE_TYPE = "CodeValueAlternateScheme.retrieveAlternateSchemeCodes";

	private static final String QUERY_RETRIEVE_PARENT_CODE_VALUE_ASSOCIATIONS = "CodeValueAssociation.retrieveParentCodeValueAssociations";
	private static final String QUERY_RETRIEVE_CHILD_CODE_VALUE_ASSOCIATIONS = "CodeValueAssociation.retrieveChildCodeValueAssociations";
	
	/**
	 * Query to retrieve Industry Code Search Values
	 */
	private static final String QUERY_RETRIEVE_SRCH_INDS_CODE_VALUES = "CodeValue.findIndustryCodeValues";
	
	/**
	 * The setter method for the entity manager. The persistence context has
	 * been defined as part of the entity manager definition.
	 *
	 * @param em
	 */
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}

    /**
     * Inject DataSource properties to jdbcTemplate.
     *
     * @param argDataSource
     *            the new data source
     */
    @Autowired
    @Qualifier("stgDataSource")
    public void setDataSource(DataSource argDataSource) {
        this.jdbcTemplate = new JdbcTemplate(argDataSource);
    }
    
	/**
	 *
	 * The method will retrieve the SCoTS data for all the tables given as
	 * parameter from the Staging SoR. The input will be list of Code Table IDs
	 * and the user preferred language. The return will be a map with key as
	 * Code table ID and value as list of CodeValue. The method is invoked to
	 * populate the following drop downs in Add Geo Unit UI: - Geo Unit Type -
	 * Name Type - Language - Data Provider - Code Type
	 *
	 * @param codeTableIds
	 * @param langaugeCode
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<Long, List<CodeValue>> retrieveCodeValues(
			List<Long> codeTableIds, Long langaugeCode) {
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveCodeValues");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("langCode", langaugeCode);
		parameters.put("codeTableIds", codeTableIds);
		parameters.put("writingScriptCode",
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(QUERY_RETRIEVE_CODE_VALUES);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveCodeValues");
		Map<Long, List<CodeValue>> resultMap = null;
		try{
			resultMap = constructCodeValueMap(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return resultMap;
	}
	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveCodeValuesScores(
			List<Long> codeTableIds, Long langaugeCode) {
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveCodeValuesScores");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("langCode", langaugeCode);
		parameters.put("codeTableIds", codeTableIds);
		parameters.put("writingScriptCode",
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(QUERY_RETRIEVE_CODE_VALUES);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveCodeValuesScores");
		List<CodeValue> resultMap = null;
		try{
			resultMap = query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return resultMap;
	}
	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveMktGrpCodes() {
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveMktGrpCodes");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */

		//Map<String, Object> parameters = new HashMap<String, Object>();
		//parameters.put("langCode", langaugeCode);
		//parameters.put("codeTableIds", codeTableIds);
		//parameters.put("writingScriptCode",
				//RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(QUERY_RETRIEVE_MKT_GRP_CODE_VALUES);
	//	for (Entry<String, ?> parameter : parameters.entrySet()) {
	//		query.setParameter(parameter.getKey(), parameter.getValue());
	//	}

		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveMktGrpCodes");
		try{
			return mapCodeValue(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}		
	}
	/**
	 *
	 * The method to convert the geo unit entity object to a value object.
	 *
	 * @param geoUnitNames
	 * @return
	 */
	private List<CodeValue> mapCodeValue(List<GeoUnitName> geoUnitNames) {
		LOGGER.info("entering GeoStagingDAOImpl | mapCodeValueVO");
		List<CodeValue> codeValues = null;

		if (geoUnitNames != null) {
			codeValues = new ArrayList<CodeValue>();
			for (GeoUnitName geoUnitName : geoUnitNames) {
				CodeValue codeValue = new CodeValue(
						geoUnitName.getGeoUnitId(), geoUnitName.getGeoName(),
						null);
				codeValues.add(codeValue);
			}
		}
		LOGGER.info("exiting GeoStagingDAOImpl | mapCodeValueVO");
		return codeValues;
	}
	
	
	@SuppressWarnings("unchecked")
	public Map<Long, List<CodeValue>> retrieveCodeValuesScr(
			List<Long> codeTableIds, Long langaugeCode) {
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveCodeValues");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("langCode", langaugeCode);
		parameters.put("codeTableIds", codeTableIds);
		parameters.put("writingScriptCode",
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(QUERY_RETRIEVE_CODE_VALUES_SCR);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveCodeValues");
		Map<Long, List<CodeValue>> resultMap = null;
		try{
			resultMap = constructCodeValueMap(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return resultMap;
	}

	/**
	 *
	 * The method will retrieve the SCoTS data for all the code values given as
	 * parameter from the Staging SoR. The input will be list of Code value IDs
	 * and the user preferred language. The return will be a map with key as
	 * Code table ID and value as list of CodeValue. 
	 *
	 * @param codeValueIds
	 * @param langaugeCode
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<Long, List<CodeValue>> retrieveCodeValuesById(
			List<Long> codeValueIds, Long langaugeCode) {
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveCodeValuesById");
		LOGGER.info("SCoTsStagingDAOImpl | retrieveCodeValuesById | codeValueIds : " + codeValueIds);
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("langCode", langaugeCode);
		parameters.put("codeValueIds", codeValueIds);
		parameters.put("writingScriptCode",
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(QUERY_RETRIEVE_CODE_VALUES_BY_IDS);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveCodeValuesById");
		try{
		return constructCodeValueByIdMap(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 *
	 * The method will construct the map from the list of CodeValue entity
	 * objects. The key for the map will be the code table id and the value will
	 * be the entire CodeValue entity as such.
	 *
	 * @param codeValues
	 * @return codeValueMap
	 */
	private Map<Long, List<CodeValue>> constructCodeValueMap(
			List<CodeValue> codeValues) {
		Map<Long, List<CodeValue>> codeValueMap = new HashMap<Long, List<CodeValue>>();
		List<CodeValue> valuesList = null;

		for (CodeValue codeValue : codeValues) {
			valuesList = codeValueMap.get(Long.valueOf(codeValue
					.getCodeTableId()));
			if (valuesList == null) {
				valuesList = new ArrayList<CodeValue>();
			}
			valuesList.add(codeValue);
			codeValueMap.put(Long.valueOf(codeValue.getCodeTableId()),
					valuesList);
		}
		return codeValueMap;
	}
	/**
	 *
	 * The method will construct the map from the list of CodeValue entity
	 * objects. The key for the map will be the code table id and the value will
	 * be the entire CodeValue entity as such.
	 *
	 * @param codeValues
	 * @return codeValueMap
	 */
	private Map<Long, List<CodeValue>> constructCodeValueByIdMap(
			List<CodeValue> codeValues) {
		Map<Long, List<CodeValue>> codeValueMap = new HashMap<Long, List<CodeValue>>();
		List<CodeValue> valuesList = null;

		for (CodeValue codeValue : codeValues) {
			valuesList = codeValueMap.get(Long.valueOf(codeValue
					.getCodeValueId()));
			if (valuesList == null) {
				valuesList = new ArrayList<CodeValue>();
			}
			valuesList.add(codeValue);
			codeValueMap.put(Long.valueOf(codeValue.getCodeValueId()),
					valuesList);
		}
		LOGGER.info("constructCodeValueByIdMap | codeValueMap : " + codeValueMap);
		return codeValueMap;
	}

	/**
	 *
	 * The method will perform the table search of SCoTS Code Tables on the
	 * search db.
	 * <p>
	 *
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 *
	 * @param SCoTSSearchCriteriaVO
	 * @return list of CodeValue
	 */
	@SuppressWarnings("unchecked")
	public List<CodeTable> searchCodeTables(
			SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTsStagingDAOImpl | searchCodeTables");

		Query query = formQueryForSearchCodeTables(searchCriteriaVO,
				QUERY_RETRIEVE_CODE_TABLES_START, false);

		// setting the page count and max results for pagination
		query.setMaxResults(searchCriteriaVO.getMaxResults());
		query.setFirstResult(searchCriteriaVO.getRowIndex());
		try{
		return (List<CodeTable>) query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method will count the records in the hierarchy search of code tables
	 * on the search db. The search will be done on the flat db based on the
	 * search criteria the user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return count of search results
	 */
	public Long countSearchCodeTables(SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTsStagingDAOImpl | countSearchCodeTables");

		Query query = formQueryForSearchCodeTables(searchCriteriaVO,
				QUERY_COUNT_CODE_TABLES_START, true);
		try {
		return (Long) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method will construct the query instance for the search code table
	 * functionality. The query string with the query parameters will be
	 * appended and the entity manager is invoked to form the query
	 *
	 * @param searchCriteriaVO
	 * @param selectQuery
	 * @param isCountQuery
	 * @return query
	 */
	private Query formQueryForSearchCodeTables(
			SCoTSSearchCriteriaVO searchCriteriaVO, String selectQuery,
			boolean isCountQuery) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer(selectQuery);

		// if country applicability is selected join the ctry_appy table
		if (searchCriteriaVO.getCountryApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_TABLES_JOIN_CTRYAPPY);
		}
		// if system applicability is selected join the sys_appy table
		if (searchCriteriaVO.getSystemApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_TABLES_JOIN_SYSAPPY);
		}
		queryStr.append("WHERE 1=1 ");

		// if country applicability is selected append the ctry_appy join
		// condition
		if (searchCriteriaVO.getCountryApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_TABLES_JOIN_CTRYAPPY_CND);
		}
		// if system applicability is selected append the sys_appy join
		// condition
		if (searchCriteriaVO.getSystemApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_TABLES_JOIN_SYSAPPY_CND);
		}

		// if table name/ description is entered
		if (searchCriteriaVO.getTableDescription() != null
				&& searchCriteriaVO.getTableDescription().length() > 0) {
			// if numeric the check for codeTableId
			if (searchCriteriaVO.getTableDescription().matches("[0-9]+")) {
				queryStr.append(QUERY_RETRIEVE_CODE_TABLES_FL_TBLID);
				parameters.put("tableDescription",
						Long.valueOf(searchCriteriaVO.getTableDescription()));
			} else {
				queryStr.append(QUERY_RETRIEVE_CODE_TABLES_FL_TBLDESC);
				parameters.put("tableDescription",
						searchCriteriaVO.getTableDescription());
			}
		}
		// if country applicability is selected append the ctry_appy condition
		if (searchCriteriaVO.getCountryApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_TABLES_CTRYAPPY_CND);
			parameters.put("ctryGeoUnitId",
					searchCriteriaVO.getCountryApplicabilityCode());
		}
		// if system applicability is selected append the sys_appy condition
		if (searchCriteriaVO.getSystemApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_TABLES_SYSAPPY_CND);
			parameters.put("dnbSystemCode",
					searchCriteriaVO.getSystemApplicabilityCode());
		}
		/*
		 * If only count is required then no need for order by clause in the
		 * query. Checking for isCountQuery in the if condition
		 */
		if (!isCountQuery) {
			// setting the sort order
			queryStr.append(" order by ");
			queryStr.append(getSortIndexForSearchCodeTables(searchCriteriaVO.getSortBy()));
			queryStr.append(" ");
			queryStr.append(searchCriteriaVO.getSortOrder());
		}
		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}
	
	/**
	 *
	 * The method to retrieve the sort column for the searchCodeTables
	 *
	 * @param sortBy
	 * @return sortColumn
	 */
	private String getSortIndexForSearchCodeTables(String sortBy) {
		if("businessDescription".equals(sortBy)) {
			return "ct.businessDescription";
		} else if("codeTableName".equals(sortBy)) {
			return "ct.codeTableName";
		} else {
			return "ct.codeTableId";
		}
	}

	/**
	 * The method will retrieve all Code Tables from the Search DB . The return
	 * type is a VO which contains the Code Table Id and the Code Table Names.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveCodeTableList() {
		LOGGER.info("entering SCoTsDAOImpl | retrieveCodeTableList");
		Query query = em.createNamedQuery(QUERY_RETRIEVE_CODE_TABLE_LIST);
		LOGGER.info("exiting SCoTsDAOImpl | retrieveCodeTableList");
		try {
		return mapCodeValueVO(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will retrieve all Code Languages from the Search DB . The
	 * return type is a VO which contains the Code Value Id and the COde Value
	 * Description (language names).
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveCodeLanguages() {
		LOGGER.info("entering SCoTsDAOImpl | retrieveCodeLanguages");
		Query query = em.createNamedQuery(QUERY_RETRIEVE_CODE_LANGUAGES);
		LOGGER.info("exiting SCoTsDAOImpl | retrieveCodeLanguages");
		try {
		return mapCodeValueTextVO(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will retrieve all systems applicable from the Search DB . The
	 * return type is a VO which contains the DNB system code and the Code Value
	 * Description.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<SystemApplicability> retrieveSystemApplicability(
			Long codeTableId , int applicabilityIndicator) {
		LOGGER.info("entering SCoTsDAOImpl | retrieveSystemApplicability");

		String queryString = new String();
		if (codeTableId != null && codeTableId != -1L) {
			// Setting parameter codeTableId
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("codeTableId", codeTableId);
			if(applicabilityIndicator==1){
				queryString=QUERY_RETRIEVE_APPLICABILE_SYSTEMS_FOR_CODE_TABLES;
			} else if(applicabilityIndicator==0){
				queryString=QUERY_RETRIEVE_SYSTEM_APPLICABILITY_FOR_CODE_TABLES;
			}
			
			Query query = createNamedQuery(
					queryString,
					parameters);
			LOGGER.info("exiting SCoTsDAOImpl | retrieveSystemApplicability");
			try {
			return query.getResultList();
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		} else {
			return retrieveAllSystemApplicabilities();
		}
	}

	/**
	 * The method will retrieve all systems applicable from the Search DB . The
	 * return type is a VO which contains the DNB system code and the Code Value
	 * Description.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<SystemApplicability> retrieveSystemApplicabilityForCodeValue(
			Long codeValueId) {
		LOGGER.info("entering SCoTsDAOImpl | retrieveSystemApplicability");

		if (codeValueId != null && codeValueId != -1L) {
			// Setting parameter codeTableId
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("codeValueId", codeValueId);
			Query query = createNamedQuery(
					QUERY_RETRIEVE_SYSTEM_APPLICABILITY_FOR_CODE_VALUES,
					parameters);
			LOGGER.info("exiting SCoTsDAOImpl | retrieveSystemApplicability");
			try {
			return query.getResultList();
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		} else {
				return retrieveAllSystemApplicabilities();
			}
		}

        /**
	 * The method will retrieve all systems applicable from the Search DB . The
	 * return type is a VO which contains the DNB system code and the Code Value
	 * Description.
	 *
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllSystemApplicability(String applicability) {
		LOGGER.info("entering SCoTsDAOImpl | retrieveAllSystemApplicability");

		Query query = null;
		if (applicability != null
				&& applicability.trim().equalsIgnoreCase("System")) {
			query = em
					.createNamedQuery(QUERY_RETRIEVE_ALL_SYSTEM_APPLICABILITY_IRRESP_OF_IND);
			try {
			return mapSystemApplicabilityVO(query.getResultList());
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		} else if (applicability != null
				&& applicability.trim().equalsIgnoreCase("Market")) {
			try {
			return geoStagingDao.retrieveAllCountries(
					RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL,
					RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		} else {
			return null;
		}
	}

	/**
	 * The method will retrieve all countries applicable from the Search DB .
	 * The return type is a VO which contains the DNB system code and the Code
	 * Value Description.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<CountryApplicability> retrieveCountryApplicability(
			Long codeTableId , int applicabilityIndicator) {
		LOGGER.info("entering SCoTsDAOImpl | retrieveCountryApplicability");
		try {
			String queryString = new String();
		if (codeTableId != null && codeTableId != -1L) {
			// Setting parameter codeTableId
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("codeTableId", codeTableId);
			if(applicabilityIndicator==1){
				queryString=QUERY_RETRIEVE_COUNTRY_APPLICABILITY_FOR_CODE_TABLE;
			}else if(applicabilityIndicator==0){
				queryString=QUERY_RETRIEVE_COUNTRY_APPLICABILITY;
			}
			Query query = createNamedQuery(
					queryString, parameters);
			LOGGER.info("exiting SCoTsDAOImpl | retrieveCountryApplicability");
			return query.getResultList();
		} else {
			Query query = em
					.createNamedQuery(QUERY_RETRIEVE_ALL_COUNTRY_APPLICABILITY);
			LOGGER.info("exiting SCoTsDAOImpl | retrieveCountryApplicability");
			return query.getResultList();
		}
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will retrieve all countries applicable from the Search DB .
	 * The return type is a VO which contains the DNB system code and the Code
	 * Value Description.
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<CountryApplicability> retrieveCountryApplicabilityForCodeValue(
			Long codeValueId) {
		LOGGER.info("entering SCoTsDAOImpl | retrieveCountryApplicabilityForCodeValue");
		try {
		if (codeValueId != null && codeValueId != -1L) {
			// Setting parameter codeTableId
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("codeValueId", codeValueId);
			Query query = createNamedQuery(
					QUERY_RETRIEVE_COUNTRY_APPLICABILITY_FOR_CODE_VALUES, parameters);
			LOGGER.info("exiting SCoTsDAOImpl | retrieveCountryApplicabilityForCodeValue");
			return query.getResultList();
		} else {
			Query query = em
					.createNamedQuery(QUERY_RETRIEVE_ALL_COUNTRY_APPLICABILITY);
			LOGGER.info("exiting SCoTsDAOImpl | retrieveCountryApplicabilityForCodeValue");
			return query.getResultList();
		}
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 *
	 * The method to convert the Code Table entity object to a value object.
	 *
	 * @param geoUnitNames
	 * @return
	 */
	private List<CodeValueVO> mapCodeValueVO(List<CodeTable> codeTables) {
		LOGGER.info("entering SCoTsDAOImpl | mapCodeValueVO");
		List<CodeValueVO> codeValueVOs = null;

		if (codeTables != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (CodeTable codeTable : codeTables) {
				CodeValueVO codeValueVO = new CodeValueVO(
						Long.valueOf(codeTable.getCodeTableId()),
						codeTable.getCodeTableName(), null);
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting SCoTsDAOImpl | mapCodeValueVO");
		return codeValueVOs;
	}

	/**
	 *
	 * The method to convert the Code Value Text entity object to a value
	 * object.
	 *
	 * @param geoUnitNames
	 * @return
	 */
	private List<CodeValueVO> mapCodeValueTextVO(
			List<CodeValueText> codeValueTexts) {
		LOGGER.info("entering SCoTsDAOImpl | mapCodeValueTextVO");
		List<CodeValueVO> codeValueVOs = null;

		if (codeValueTexts != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (CodeValueText codeValueText : codeValueTexts) {
				CodeValueVO codeValueVO = new CodeValueVO(
						codeValueText.getCodeValueId(),
						codeValueText.getCodeValueDescription(), null);
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting SCoTsDAOImpl | mapCodeValueTextVO");
		return codeValueVOs;
	}

	/**
	 *
	 * The method to convert the Code Value Text entity object to a value
	 * object.
	 *
	 * @param geoUnitNames
	 * @return
	 */
	private List<CodeValueVO> mapSystemApplicabilityVO(
			List<SystemApplicability> systemAppys) {
		LOGGER.info("entering SCoTsDAOImpl | mapSystemApplicabilityVO");
		List<CodeValueVO> codeValueVOs = null;

		if (systemAppys != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (SystemApplicability systemAppy : systemAppys) {
				CodeValueVO codeValueVO = new CodeValueVO(
						systemAppy.getDnbSystemCode(),
						systemAppy.getCodeValueDescription(), null);
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting SCoTsDAOImpl | mapSystemApplicabilityVO");
		return codeValueVOs;
	}

	/**
	 *
	 * The method to find the CodeTable entity by the primary key codeTableId
	 *
	 * @param codeTableId
	 * @return CodeTable entity
	 */
	public CodeTable retrieveCodeTableById(Long codeTableId) {
		try {
			return em.find(CodeTable.class, codeTableId);
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method to fetch the details of codeValues based on the codeTableId.
	 * The filter will also contain the language code, system applicability code
	 * and country applicability code.
	 *
	 * @param searchCriteriaVO
	 * @return list of codeValues
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveCodeValuesByTableId(
			SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveCodeValuesByTableId");

		Query query = formQueryForCodeValuesByTableId(searchCriteriaVO,
				QUERY_RETRIEVE_CODE_VALUES_START, false);

		// setting the page count and max results for pagination
		query.setMaxResults(searchCriteriaVO.getMaxResults());
		query.setFirstResult(searchCriteriaVO.getRowIndex());
		try {
		return (List<CodeValue>) query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method to count the results of codeValues based on the codeTableId.
	 * The filter will also contain the language code, system applicability code
	 * and country applicability code.
	 *
	 * @param searchCriteriaVO
	 * @return count of codeValues
	 */
	public Long countCodeValuesByTableId(SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTsStagingDAOImpl | countCodeValuesByTableId");

		Query query = formQueryForCodeValuesByTableId(searchCriteriaVO,
				QUERY_COUNT_CODE_VALUES_START, true);
		try {
		return (Long) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method will construct the query instance for the retrieve code values
	 * by Id functionality. The query string with the query parameters will be
	 * appended and the entity manager is invoked to form the query
	 *
	 * @param searchCriteriaVO
	 * @param selectQuery
	 * @param isCountQuery
	 * @return query
	 */
	private Query formQueryForCodeValuesByTableId(
			SCoTSSearchCriteriaVO searchCriteriaVO, String selectQuery,
			boolean isCountQuery) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer(selectQuery);

		// if country applicability is selected join the ctry_appy table
		if (searchCriteriaVO.getCountryApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_TABLES_JOIN_CTRYAPPY);
		}
		// if system applicability is selected join the sys_appy table
		if (searchCriteriaVO.getSystemApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_TABLES_JOIN_SYSAPPY);
		}
		queryStr.append("WHERE 1=1 ").append(
				"and cvt.expirationDate is null and cv.codeValueId = cvt.codeValueId ");

		// if country applicability is selected append the ctry_appy join
		// condition
		if (searchCriteriaVO.getCountryApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUES_JOIN_CTRYAPPY_CND);
			parameters.put("caCodeTableId",
					Long.valueOf(searchCriteriaVO.getTableDescription()));
		}
		// if system applicability is selected append the sys_appy join
		// condition
		if (searchCriteriaVO.getSystemApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUES_JOIN_SYSAPPY_CND);
			parameters.put("saCodeTableId",
					Long.valueOf(searchCriteriaVO.getTableDescription()));
		}

		// if table name/ description is entered
		if (searchCriteriaVO.getTableDescription() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUES_FL_TBLID);
			parameters.put("codeTableId",
					Integer.valueOf(searchCriteriaVO.getTableDescription()));
		}
		// if country applicability is selected append the ctry_appy condition
		if (searchCriteriaVO.getCountryApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_TABLES_CTRYAPPY_CND);
			parameters.put("ctryGeoUnitId",
					searchCriteriaVO.getCountryApplicabilityCode());
		}
		// if system applicability is selected append the sys_appy condition
		if (searchCriteriaVO.getSystemApplicabilityCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_TABLES_SYSAPPY_CND);
			parameters.put("dnbSystemCode",
					searchCriteriaVO.getSystemApplicabilityCode());
		}
		// if language code is selected append the langCode condition
		if (searchCriteriaVO.getLanguageCode() != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUES_FL_LANGCD);
			parameters.put("langCode",
					Long.valueOf(searchCriteriaVO.getLanguageCode()));
		}
		/*
		 * If only count is required then no need for order by clause in the
		 * query. Checking for isCountQuery in the if condition
		 */
		if (!isCountQuery) {
			// setting the sort order
			queryStr.append(" order by ");
			queryStr.append(getSortIndexForCodeValuesByTableId(searchCriteriaVO.getSortBy()));
			queryStr.append(" ");
			queryStr.append(searchCriteriaVO.getSortOrder());
		}
		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}

	/**
	 *
	 * The method to retrieve the sort column for the retrieveCodeValuesByTableId
	 *
	 * @param sortBy
	 * @return sortColumn
	 */
	private String getSortIndexForCodeValuesByTableId(String sortBy) {
		if("codeValueDescription".equals(sortBy)) {
			return "cvt.codeValueDescription";
		} else if("businessDescription".equals(sortBy)) {
			return "cv.businessDescription";
		} else {
			return "cv.codeValueId";
		}
	}
	
	/**
	 *
	 * The method to fetch the Code Value details based on the filter condition.
	 * The Code Value will be searched based on description or on the business
	 * description.
	 *
	 * @param searchCriteriaVO
	 * @return codeValues
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValue> searchCodeValues(
			SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTsStagingDAOImpl | searchCodeValues");

		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer();
		// append the select clause
		queryStr.append(QUERY_SEARCH_CODE_VALUES_SELECT);
		// append the from clause
		queryStr.append(QUERY_SEARCH_CODE_VALUES_FROM);

		if (searchCriteriaVO.getLanguageCode() != null) {
			queryStr.append(QUERY_SEARCH_CODE_VALUES_LANG_CND);
			parameters.put("langCode", searchCriteriaVO.getLanguageCode());
		}
		LOGGER.info("\n\n\n\nsearchCriteriaVO " + searchCriteriaVO);
		if (searchCriteriaVO.getCodeValueId() != null) {
			queryStr.append(QUERY_SEARCH_CODE_VALUES_VALID_CND);
			parameters.put("codeValId", searchCriteriaVO.getCodeValueId());
		} else if (searchCriteriaVO.getCodeValueDescription() != null) {
			queryStr.append(QUERY_SEARCH_CODE_VALUES_VALDESC_CND);
			parameters.put("codeDesc",
					searchCriteriaVO.getCodeValueDescription());
		} else if (searchCriteriaVO.getCodeValueBusinessDescription() != null) {
			queryStr.append(QUERY_SEARCH_CODE_VALUES_BUSDESC_CND);
			parameters.put("codeBusDesc",
					searchCriteriaVO.getCodeValueBusinessDescription());
		}
		/**
	 * The query to retrieve the Code Value details based on the expiration date
	 * Included to implement the fix for 208410455(the issue of displaying expired Code Value Description in Search Codes by CodeValue)
	 */
		queryStr.append(QUERY_SEARCH_CODE_VALUES_EXPN_DT);
		queryStr.append(" order by ");
		queryStr.append(getSearchCodeValueSortIndex(searchCriteriaVO
				.getSortBy()));
		queryStr.append(" ");
		queryStr.append(searchCriteriaVO.getSortOrder());

		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		// setting the pagination attributes
		query.setMaxResults(searchCriteriaVO.getMaxResults());
		query.setFirstResult(searchCriteriaVO.getRowIndex());
		try {
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method to retrieve the sortBy column index for the search code value
	 *
	 * @param sortBy
	 * @return sortByColumnIndex
	 */
	private String getSearchCodeValueSortIndex(String sortBy) {
		if ("codeValueId".equals(sortBy)) {
			return "cv.codeValueId";
		} else if ("codeValueDescription".equals(sortBy)) {
			return "cvt.codeValueDescription";
		} else if ("codeTableId".equals(sortBy)) {
			return "ct.codeTableId";
		} else if ("businessDescription".equals(sortBy)) {
			return "cv.businessDescription";
		} else {
			return "cv.codeValueId";
		}
	}

	/**
	 *
	 * The method to fetch the count of Code Value details based on the filter
	 * condition. The Code Value will be searched based on description or on the
	 * business description.
	 *
	 * @param searchCriteriaVO
	 * @return countCodeValues
	 */
	public Long countOfSearchCodeValues(SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTsStagingDAOImpl | countOfSearchCodeValues");

		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer();
		// append the select clause
		queryStr.append(QUERY_SEARCH_CODE_VALUES_COUNT);
		// append the from clause
		queryStr.append(QUERY_SEARCH_CODE_VALUES_FROM);

		if (searchCriteriaVO.getLanguageCode() != null) {
			queryStr.append(QUERY_SEARCH_CODE_VALUES_LANG_CND);
			parameters.put("langCode", searchCriteriaVO.getLanguageCode());
		}

		if (searchCriteriaVO.getCodeValueId() != null) {
			queryStr.append(QUERY_SEARCH_CODE_VALUES_VALID_CND);
			parameters.put("codeValId", searchCriteriaVO.getCodeValueId());
		} else if (searchCriteriaVO.getCodeValueDescription() != null) {
			queryStr.append(QUERY_SEARCH_CODE_VALUES_VALDESC_CND);
			parameters.put("codeDesc",
					searchCriteriaVO.getCodeValueDescription());
		} else if (searchCriteriaVO.getCodeValueBusinessDescription() != null) {
			queryStr.append(QUERY_SEARCH_CODE_VALUES_BUSDESC_CND);
			parameters.put("codeBusDesc",
					searchCriteriaVO.getCodeValueBusinessDescription());
		}

		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		try {
		return (Long) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * Fetches the CodeValue entity by the key codeValueId.
	 * <p>
	 *
	 * @param codeTableId
	 * @return CodeValue entity
	 */
	@Override
	public CodeValue retrieveCodeValueByCodeValueId(Long codeValueId) throws Exception {
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveCodeValueByCodeValueId");

		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_CODE_VALUE_BY_CODE_VALUE_ID);
		query.setParameter("codeValueId", Long.valueOf(codeValueId));
		CodeValue cv = null;
		try {
			cv = (CodeValue) query.getSingleResult();
		}catch(NoResultException ex){			
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){			
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){			
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		List <SystemApplicability> validSystems=new ArrayList<SystemApplicability>();
		List<SystemApplicability> setSystemApplicability=retrieveSystemApplicabilityForCodeValue(codeValueId);
		for (SystemApplicability systemApplicability :setSystemApplicability ) {
			if(systemApplicability.getExpirationDate() !=null) {
				if(systemApplicability.getExpirationDate().compareTo(new Date())>0){
				validSystems.add(systemApplicability);
				}
			} else {
				validSystems.add(systemApplicability);
			}
		}
		cv.setSystemApplicability(validSystems);
		List <CountryApplicability> validCountries=new ArrayList<CountryApplicability>();
		List<CountryApplicability> setCountryApplicability=retrieveCountryApplicabilityForCodeValue(codeValueId);
		for (CountryApplicability countryApplicability :setCountryApplicability ) {
			if(countryApplicability.getExpirationDate() != null) {
				if(countryApplicability.getExpirationDate().compareTo(new Date())>0){
				validCountries.add(countryApplicability);
				}
			} else {
				validCountries.add(countryApplicability);
			}
		}
		cv.setCountryApplicability(validCountries);
		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveCodeValueByCodeValueId");
		return cv;
	}

	/**
	 *
	 * The method to retrieve all codeValue associations from database. The
	 * method will accept the parent and child code table Id s and will return
	 * all associations having the relationship between the specified parent and
	 * child code tables.
	 *
	 * @param parentCodeTableId
	 * @param childCodeTableId
	 * @return List<CodeValueAssociation>
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueAssociation> retrieveCodeValueAssociations(
			Long parentCodeTableId, Long childCodeTableId, Boolean isStagingDB) {
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveCodeValueAssociations");

		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer();
		// append the select clause
		//if(isStagingDB){
		queryStr.append(QUERY_RETRIEVE_CODE_VALUE_ASSOCIATIONS_SELECT);
		//}else{
		//	queryStr.append(QUERY_RETRIEVE_CODE_VALUE_ASSOCIATIONS_UICONFIG);
		//}

		// append the code value table join condition
		if (parentCodeTableId != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN1);
		}
		if (childCodeTableId != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN2);
		}
		queryStr.append("WHERE 1 = 1 ");

		// append the parentCodeTableId condition
		if (parentCodeTableId != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN1_1);
			queryStr.append(QUERY_RETRIEVE_CODE_VAL_ASSN_PRNT_CDTBL_ID);
			parameters.put("parentCodeTableId", parentCodeTableId.intValue());
		}
		// append the parentCodeTableId condition
		if (childCodeTableId != null) {
			queryStr.append(QUERY_RETRIEVE_CODE_VALUE_ASSN_JOIN2_1);
			queryStr.append(QUERY_RETRIEVE_CODE_VAL_ASSN_CHLD_CDTBL_ID);
			parameters.put("childCodeTableId", childCodeTableId.intValue());
		}
		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveCodeValueAssociations");
		try {
		return (List<CodeValueAssociation>) query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method to retrieve all alternate schema code types from the database.
	 * The method will be invoked as a web-service to retrieve the data.
	 *
	 * @return List<CodeValueVO>
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllAlternateSchemeCodes() {
		LOGGER.info("entering SCoTsDAOImpl | retrieveAllAlternateSchemeCodes");

		Query query = em.createNamedQuery(QUERY_RETRIEVE_ALL_ALT_SCHEME_CODES);
		query.setParameter("engLangCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		try {
		return mapAlternateSchemeCodesVO(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method will map the list of alternateSchemes retrieved by the query
	 * to list of codeValueVO.
	 *
	 * @param alternateSchemes
	 * @return alternateSchemes
	 */
	private List<CodeValueVO> mapAlternateSchemeCodesVO(
			List<CodeValueAlternateScheme> alternateSchemes) {
		LOGGER.info("entering SCoTsDAOImpl | mapAlternateSchemeCodesVO");
		List<CodeValueVO> codeValueVOs = null;

		if (alternateSchemes != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (CodeValueAlternateScheme alternateScheme : alternateSchemes) {
				CodeValueVO codeValueVO = new CodeValueVO(
						Long.valueOf(alternateScheme
								.getAlternateSchemeTypeCode()),
						alternateScheme.getAlternateSchemeTypeDescription(),
						null);
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting SCoTsDAOImpl | mapAlternateSchemeCodesVO");
		return codeValueVOs;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List retrieveSystemForCode(String applicability,
			Long applicabilityCode) {
		LOGGER.info("entering SCoTsDAOImpl | retrieveSystemForCode");
		List<Object> codeValueList = retrieveCodeValueSystemForCode(applicability,
				applicabilityCode);
		List<Object> codeTableList = retrieveCodeTableSystemForCode(applicability,
				applicabilityCode);
		if((codeValueList != null) && (codeTableList != null)){
			codeValueList.addAll(codeTableList);
		}
		LOGGER.info("exiting SCoTsDAOImpl | retrieveSystemForCode");
		return codeValueList;
	}
	
	@SuppressWarnings({ "rawtypes" })
	public List retrieveCodeValueSystemForCode(String applicability,
			Long applicabilityCode) {
		LOGGER.info("entering SCoTsDAOImpl | retrieveCodeValueSystemForCode");

		Map<String, Object> parameters = new HashMap<String, Object>();
		Query query = null;

		if ("System".equals(applicability.trim())) {
			parameters.put("dnbSystemCode", applicabilityCode);
			query = createNamedQuery(
					QUERY_RETRIEVE_CODE_VALUE_SYSTEM_APPLICABILITY_FOR_CODE, parameters);
		} else if ("Market".equals(applicability.trim())) {
			parameters.put("countryGeoUnitId", applicabilityCode);
			query = createNamedQuery(QUERY_RETRIEVE_CODE_VALUE_MARKET_FOR_CODE, parameters);
		}

		LOGGER.info("exiting SCoTsDAOImpl | retrieveCodeValueSystemForCode");
		try {
		return query != null ? query.getResultList() : null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@SuppressWarnings({ "rawtypes"})
	public List retrieveCodeTableSystemForCode(String applicability,
			Long applicabilityCode) {
		LOGGER.info("entering SCoTsDAOImpl | retrieveCodeTableSystemForCode");

		Map<String, Object> parameters = new HashMap<String, Object>();
		Query query = null;

		if ("System".equals(applicability.trim())) {
			parameters.put("dnbSystemCode", applicabilityCode);
			query = createNamedQuery(
					QUERY_RETRIEVE_CODE_TABLE_SYSTEM_APPLICABILITY_FOR_CODE, parameters);
		} else if ("Market".equals(applicability.trim())) {
			parameters.put("countryGeoUnitId", applicabilityCode);
			query = createNamedQuery(QUERY_RETRIEVE_CODE_TABLE_MARKET_FOR_CODE, parameters);
		}
		
		LOGGER.info("exiting SCoTsDAOImpl | retrieveCodeTableSystemForCode");
		try {
		return query != null ? query.getResultList() : null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the staging
	 * DB to fetch all alternate scheme codes matching the scheme type code
	 * selected by the user.
	 *
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueAlternateScheme> retrieveAlternateSchemeCodes(
			Long schemeTypeCode) {
		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_ALT_SCHEME_BY_CODE_TYPE);
		query.setParameter("altSchTypeCode", schemeTypeCode);
		try {
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * Fetches the SystemApplicability entity by the key dnbSystemCode and
	 * codeTableId.
	 * <p>
	 *
	 * @param dnbSystemCode
	 * @param codeTableId
	 * @return SystemApplicability entity
	 */
	@Override
	public SystemApplicability retrieveSystemByCodeTable(
			CodeValueVO systemSearchCriteriaVO) {
		LOGGER.info("entering SCoTsStagingDAOImpl | searchSystem");

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("codeValueDescription",
				systemSearchCriteriaVO.getValue());
		parameters.put("codeTableId", systemSearchCriteriaVO.getCode());
		parameters.put("dnbSystemCode",
				Long.valueOf(systemSearchCriteriaVO.getDescription()));
		Query query = createNamedQuery(QUERY_SEARCH_SYSTEM, parameters);
		SystemApplicability sa = null;
		try {
			sa = (SystemApplicability) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}

		LOGGER.info("\n\n Resulted code value  in dao: ------->" + sa);
		LOGGER.info("exiting SCoTsStagingDAOImpl | searchSystem");
		return sa;
	}

	/**
	 *
	 * Fetches the CountryApplicability entity by the key dnbSystemCode and
	 * codeTableId.
	 * <p>
	 *
	 * @param dnbSystemCode
	 * @param codeTableId
	 * @return CountryApplicability entity
	 */
	@Override
	public CountryApplicability retrieveCountryByCodeTable(
			String codeValueDescription) {
		LOGGER.info("entering SCoTsStagingDAOImpl | searchCountry");

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("codeValueDescription", codeValueDescription);
		Query query = createNamedQuery(QUERY_SEARCH_COUNTRY, parameters);
		CountryApplicability ca = null;
		try {
			ca = (CountryApplicability) query
				.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("\n\n Resulted code value  in dao: ------->" + ca);
		LOGGER.info("exiting SCoTsStagingDAOImpl | searchCountry");
		return ca;
	}
	/**
	 * The method will persist the existing CodeTable data in the Staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	@Override
	public CodeTable updateCodeTable(CodeTable codeTable) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | updateCodeTable");
		CodeTable codeTableToMerge = null;
		try {
			codeTableToMerge=  em.merge(codeTable);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		List<SystemApplicability> systemApplicability = codeTable
				.getSystemApplicability();
		if (systemApplicability != null) {
			for (SystemApplicability updateSystem : systemApplicability) {
				SystemApplicability systemReciever = em.merge(updateSystem);
				LOGGER.info("SystemApplicability updated with Id : "
						+ systemReciever.getSysAppyId());
			}
		}
		List<CountryApplicability> countryApplicability = codeTable
				.getCountryApplicability();
		if (countryApplicability != null) {
			for (CountryApplicability updateCountry : countryApplicability) {
				CountryApplicability countryReciever = em.merge(updateCountry);
				LOGGER.info("CountryApplicability updated with Id : "
						+ countryReciever.getCtryAppyId());
			}
		}
		return codeTableToMerge;
	}
	/**
	 * The method will persist the existing Code Value data in the Staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeValue
	 */
	@Override
	public CodeValue updateCodeValue(CodeValue codeValue) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | updateCodeValue");
		CodeValue cValue = null;
		try {
			cValue = em.merge(codeValue);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		List<SystemApplicability> systemApplicability = codeValue
				.getSystemApplicability();
		if (systemApplicability != null) {
			for (SystemApplicability updateSystem : systemApplicability) {
				SystemApplicability systemReciever = em.merge(updateSystem);
				LOGGER.info("SystemApplicability updated with Id : "
						+ systemReciever.getSysAppyId());
			}
		}
		List<CountryApplicability> countryApplicability = codeValue
				.getCountryApplicability();
		if (countryApplicability != null) {
			for (CountryApplicability updateCountry : countryApplicability) {
				CountryApplicability countryReciever = em.merge(updateCountry);
				LOGGER.info("CountryApplicability updated with Id : "
						+ countryReciever.getCtryAppyId());
			}
		}
		return cValue;
	}
	/**
	 * The method will persist the existing Applicability data in the Staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param systemApplicabilities
	 */
	public void updateApprovedSystemApplicabilities(List<SystemApplicability> systemApplicabilities) {
		for(SystemApplicability systemApplicability : systemApplicabilities) {
			try {
			em.merge(systemApplicability);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		}
	}
	
	/**
	 * The method will persist the existing Applicability data in the Staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param countryApplicabilities
	 */
	public void updateApprovedCountryApplicabilities(List<CountryApplicability> countryApplicabilities) {
		for(CountryApplicability countryApplicability : countryApplicabilities) {
			try {
			em.merge(countryApplicability);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		}
	}
	
	/**
	 * The method will persist the existing Code Value AlternateScheme data in the Staging DB.
	 * Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param codeValueAlternateScheme
	 */
	@Override
	public void updateApprovedCodeValueAlternateSchemes(List<CodeValueAlternateScheme> codeValueAlternateScheme) {
		LOGGER.info("entering ScotsTransactionalDAOImpl | updateCodeValue");
		if(codeValueAlternateScheme!=null) {
			for (CodeValueAlternateScheme updateCodeValueAlternateScheme : codeValueAlternateScheme) {
				CodeValueAlternateScheme codeReciever = null;
				try {
					codeReciever=em.merge(updateCodeValueAlternateScheme);
				}catch(PersistenceException ex){
					throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
				}catch(Exception ex){
					throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
				}
				LOGGER.info("CodeValueAlternateScheme updated with Id : "
						+ codeReciever.getCodeValueAlternateSchemeId());
			}
		}
	}

/**
	 * The method will persist the existing CodeValueAssociation in the Staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param codeTable
	 */
	@Override
	public CodeValueAssociation updateCodeValueAssociation(CodeValueAssociation codeValueAssociation) {
		LOGGER.info("entering ScotsStagingDAOImpl | updateCodeValueAssociation");
		try {
		return em.merge(codeValueAssociation);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
    public List<CodeValueAssociation> retrieveParentCodeValueAssociations(Long codeValueId) {
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveParentCodeValueAssociations");
		
		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_PARENT_CODE_VALUE_ASSOCIATIONS);
		query.setParameter("childCodeValueId", Long.valueOf(codeValueId));
		try {
		return (List<CodeValueAssociation>) query.getResultList();	
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
    public List<CodeValueAssociation> retrieveChildCodeValueAssociations(Long codeValueId) {
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveChildCodeValueAssociations");
		
		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_CHILD_CODE_VALUE_ASSOCIATIONS);
		query.setParameter("parentCodeValueId", Long.valueOf(codeValueId));
		try {
		return (List<CodeValueAssociation>) query.getResultList();	
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	/**
	 * 
	 * The method to retrieve all valid industry code group levels
	 *
	 * @return validIndustryCodeGroupLevels
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Cacheable(cacheName = "refdataCache")
	public List<CodeValue> retrieveValidIndustryCodeGroupLevels() {
		/*
		 * Set the parameters for the named query to retrieve group level codes
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("langCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		parameters.put("codeTableId", 265);
		parameters.put("writingScriptCode",
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
		parameters.put("dnbSystemCode", 24291L);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(QUERY_RETRIEVE_GROUP_LEVEL_CODES);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		try {
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * 
	 * The generic method which returns all system applicabilities
	 *
	 * @return system applicability
	 */
	@SuppressWarnings("unchecked")
	private List<SystemApplicability> retrieveAllSystemApplicabilities() {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("codeTableId", RefDataUIConstants.CODE_TABLE_ID_FOR_ALL_SYSTEMS);
		parameters.put("dnbSystemCode", RefDataUIConstants.DNB_SYSTEM_CODE_FOR_ALL_SYSTEMS);
		Query query = createNamedQuery(QUERY_RETRIEVE_ALL_SYSTEM_APPLICABILITY, parameters);
			try {
		return query.getResultList();
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
	}
	

	/**
	 * 
	 * The method will retrieve the Industry code data for all the tables given
	 * as parameter from the Staging SoR. The input will be Code Table ID of the
	 * Industry Code Type table. This method will be invoked only for search as
	 * this will fetch only the existing industry code types from inds_code
	 * table.
	 * 
	 * @param indsCodeTableId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValue> retrieveIndustryCodeValues(Long indsCodeTableId) {
		LOGGER.info("entering SCoTsStagingDAOImpl | retrieveIndustryCodeValues");
		/*
		 * Set the parameters
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("langCode", RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		parameters.put("codeTableId", indsCodeTableId.intValue());
		parameters.put("writingScriptCode", RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(QUERY_RETRIEVE_SRCH_INDS_CODE_VALUES);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		
		List<CodeValue> codeValues = null;
		try{
			codeValues = query.getResultList();
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting SCoTsStagingDAOImpl | retrieveIndustryCodeValues");
		return codeValues;
	}
	
	/**
	 * 
	 * The method to check whether the code value is existing in the staging
	 * database. This method will be invoked on approval of request by work-flow
	 * 
	 * @param codeId
	 * @return boolean true if existing in staging db
	 */
	public Boolean isSCoTsCodeAvailable(Long codeId, String tableName) {
		try {
			String columnObj = tableName.equals("sorusr.CD_TBL") ? "cd_tbl_id" : "cd_val_id";
			int cntCodeId = jdbcTemplate.queryForInt(
					"SELECT count(" + columnObj + ") FROM " + tableName + " WHERE " + columnObj + " = :codeId ",
					new Object[] { codeId });
			LOGGER.info("SCoTsStagingDAOImpl | isSCoTsCodeAvailable : " + cntCodeId);
			return cntCodeId > 0 ? true : false;
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method will be invoked on approval of request by work-flow. The
	 * method will return the max of code value id from the staging database.
	 * 
	 * @param tableName
	 * @return codeId
	 */
	public Long retrieveStagingCodeId(String tableName) {
		try {
			String columnObj = tableName.equals("sorusr.CD_TBL") ? "sorusr.cd_tbl_id_seq" : "sorusr.cd_val_id_seq";
			return jdbcTemplate.queryForLong("SELECT " + columnObj + ".nextval FROM dual");
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
}
