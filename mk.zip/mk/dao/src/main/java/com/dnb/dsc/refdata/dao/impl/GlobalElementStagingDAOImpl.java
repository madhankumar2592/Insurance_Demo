/**
 * 
 */
package com.dnb.dsc.refdata.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GlobalElement;
import com.dnb.dsc.refdata.core.entity.GlobalElementDetail;
import com.dnb.dsc.refdata.core.entity.GlobalElementHistory;
import com.dnb.dsc.refdata.core.entity.GloblalElementCrossWalk;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.AddCrosswalkVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementCrosswalkSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementDetailVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementVO;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.GlobalElementStagingDAO;

/**
 * @author 302801
 *
 */
@Repository("GlobalElementStagingDAO")
public class GlobalElementStagingDAOImpl implements GlobalElementStagingDAO{
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SCoTsStagingDAOImpl.class);

	@PersistenceContext(unitName = "PU-Staging")
	private EntityManager em;
	
	private JdbcTemplate jdbcTemplate; 	
	
	
	
	private static final String QUERY_RETRIEVE_ALL_SEARCH_COUNT_BKP = "SELECT count(g.globalElementId) FROM GlobalElement g,GlobalElementDetail gd,CodeValueText cvt,CodeValueText cvt1 where g.globalElementId=gd.globalElementId and"
			+" g.globalElementTopicCategoryCode=cvt.codeValueId and gd.globalElementMetadataCode=cvt1.codeValueId and cvt.languageCode=39 and"
			+" cvt1.languageCode=39 ";
	
	
	/**
	 * The constants for query - retrieve hierarchy search results
	 */
	private static final String QUERY_RETRIEVE_ALL_SEARCH_SELECT_BKP = "SELECT DISTINCT new GlobalElement(g.globalElementId, g.globalElementTopicCategoryCode, "
			+"(SELECT cvt.codeValueDescription from CodeValueText cvt "
			+"where cvt.languageCode = 39 and cvt.codeValueId = g.globalElementTopicCategoryCode), "
			+" g.globalElementName,gd.globalElementMetadataCode," 
			+"(SELECT cvt.codeValueDescription from CodeValueText cvt "
			+"where cvt.languageCode = 39 and cvt.codeValueId = gd.globalElementMetadataCode), "
			+"gd.globalElementMetadataValue, g.effectiveDate,g.expirationDate,g.globalElementComment,gd.globalElementDetailComment)FROM GlobalElement g,GlobalElementDetail gd " 
			+"where g.globalElementId=gd.globalElementId ";
			
	
	private static final String QUERY_RETRIEVE_PLATFORM_LIST = "GloblalElementCrossWalk.retrievePlatformList";
	
	private static final String QUERY_RETRIEVE_UNMAPPED_ELEMENT_COUNT_LIST = "GlobalElement.retrieveUnmappedCount";
	
	private static final String QUERY_RETRIEVE_HINTS_LIST = "HelpfulHintType.retrieveHints";
	
	private static final String QUERY_RETRIEVE_HINTS_DESC_LIST = "HelpfulHint.retrieveHintsDesc";
	
	private static final String QUERY_RETRIEVE_CROSSWALK_CODE_TYPE_CODE = "CodeValue.retrieveMetada";
	
	private static final String QUERY_RETRIEVE_CROSSWALK_SEARCH_SELECT = "SELECT distinct new GloblalElementCrossWalk(g.globalElementId,g.globalElementCrosswalkId,  "
		+" g.globalElementMetadataCode," 
		+"(SELECT cvt.codeValueDescription from CodeValueText cvt "
		+"where cvt.languageCode = 39 and cvt.codeValueId = g.globalElementMetadataCode and cvt.expirationDate is null), "
		+"g.globalElementMetadataValue,g.globalElementPlatformCode,"
		+"(SELECT cvt.codeValueDescription from CodeValueText cvt "
		+"where cvt.languageCode = 39 and cvt.codeValueId = g.globalElementPlatformCode  and cvt.expirationDate is null), "
		+"g.globalElementCrosswalkGrpNme "
		+") FROM GloblalElementCrossWalk g " ;
	
	private static final String QUERY_RETRIEVE_CROSSWALK_SEARCH_COUNT = "SELECT count(*) FROM GloblalElementCrossWalk g ";
	
	private static final String QUERY_COUNT_CROSSWALK_EXISTING_GROUP_NAME = "SELECT count(*) FROM GloblalElementCrossWalk  ";
	
	@Autowired
    @Qualifier("stgDataSource")
    public void setDataSource(DataSource argDataSource) {
        this.jdbcTemplate = new JdbcTemplate(argDataSource);
    }
	
	

	/**
	 *
	 * The method to identify the sort order of columns in the Global Element Search
	 * page. The search will be performed on a specific column and the secondary
	 * sort orders are to be defined to be displayed in the UI.
	 *
	 * @param sortBy
	 * @param sortOrder
	 * @return sortByColumns
	 */
	private String getSortByColumnForSearch(String sortBy, String sortOrder) {
		String sortByColumns;
		
		 if ("globalElementId".equalsIgnoreCase(sortBy)) {
			sortByColumns = "g.globalElementId "
					+ sortOrder
					+ ", g.globalElementName, gd.globalElementMetadataValue, g.expirationDate";
		}else if ("globalElementName".equalsIgnoreCase(sortBy)) {
			sortByColumns = "g.globalElementName "
					+ sortOrder
					+ ", g.globalElementId, gd.globalElementMetadataValue, g.expirationDate";
		}else if ("globalElementMetadataValue".equalsIgnoreCase(sortBy)) {
			sortByColumns = "gd.globalElementMetadataValue " + sortOrder
					+ ", g.globalElementId, g.globalElementName, g.expirationDate";
		}else if("expirationDate".equalsIgnoreCase(sortBy)){
			sortByColumns = "g.expirationDate " + sortOrder
					+ ", g.globalElementId, g.globalElementName, gd.globalElementMetadataValue";	
		}else {
			sortByColumns = "g.globalElementId " + sortOrder
					+ ", g.globalElementName, gd.globalElementMetadataValue";
		}

		return sortByColumns;
	}


	@Override
	public Long countSearchTopicsBkp(
			GlobalElementSearchVOBkp globalElementSearchVO) {

		LOGGER.info("entering GeoStagingDAOImpl | countSearchGeographies");

		LOGGER.info("globalElementSearchCriteriaVO :: " + globalElementSearchVO);
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer(QUERY_RETRIEVE_ALL_SEARCH_COUNT_BKP);
		
		if (globalElementSearchVO.getViewType() == null) {			
			queryStr.append(" and gd.globalElementMetadataCode=29656 ");
		}
		
		/**
		 * Include the where condition if at least one of the filter condition
		 * is not empty. append the where condition.
		 */	
		
		// if Element Id value is entered as a filter
		
		if( globalElementSearchVO.getGlobalElementId() != null){
			queryStr.append(" and g.globalElementId=:globalElementId ");
			parameters.put("globalElementId", globalElementSearchVO.getGlobalElementId());
		}else{
			
			// Category Name value is entered as a filter
			if (globalElementSearchVO.getGlobalElementTopicCategoryCode() != null) {		
				queryStr.append(" and g.globalElementTopicCategoryCode=:globalElementTopicCategoryCode ");
				parameters.put("globalElementTopicCategoryCode", globalElementSearchVO.getGlobalElementTopicCategoryCode());
			}
			
			if(globalElementSearchVO.getGlobalElementName() != null 
					|| globalElementSearchVO.getGlobalElementMetadataValue() != null){
			
				queryStr.append(" and ( ");
		// if Element Name value is entered as a filter
		if (globalElementSearchVO.getGlobalElementName() != null
				&& globalElementSearchVO.getGlobalElementName().length() > 0) {
			queryStr.append(" upper(g.globalElementName) like upper(:globalElementName) or");
			parameters.put("globalElementName", "%"+globalElementSearchVO.getGlobalElementName()+"%");
		}
				
		
		if(globalElementSearchVO.getGlobalElementMetadataValue() != null && globalElementSearchVO.getGlobalElementMetadataValue().length() > 0){
			queryStr.append("  upper(gd.globalElementMetadataValue) like upper(:globalElementMetadataValue) or");
			parameters.put("globalElementMetadataValue", "%"+globalElementSearchVO.getGlobalElementMetadataValue()+"%");
		}
		
		queryStr.replace(queryStr.length()-2, queryStr.length(), "");	
		queryStr.append(" )");
		}
		}
		
		
		LOGGER.info("exiting GlobalElementStagingDAOImpl | searchByTopics | queryStr::"+queryStr.toString());
		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		try{
			return (Long) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<GlobalElement> searchByTopicsBkp(
			GlobalElementSearchVOBkp globalElementSearchVO) {

		LOGGER.info("entering GlobalElementStagingDAOImpl | searchByTopics");

		LOGGER.info("\n\ngeoSearchCriteria :: " + globalElementSearchVO);

		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer(QUERY_RETRIEVE_ALL_SEARCH_SELECT_BKP);
		
		
		if (globalElementSearchVO.getViewType() == null) {			
			queryStr.append(" and gd.globalElementMetadataCode=29656 ");
		}
		
		/**
		 * Include the where condition if at least one of the filter condition
		 * is not empty. append the where condition.
		 */	
		// if Element Id value is entered as a filter
		
		if( globalElementSearchVO.getGlobalElementId() != null){
			queryStr.append(" and g.globalElementId=:globalElementId ");
			parameters.put("globalElementId", globalElementSearchVO.getGlobalElementId());
		}else{
			
				// Category Name value is entered as a filter
				if (globalElementSearchVO.getGlobalElementTopicCategoryCode() != null) {		
					queryStr.append(" and g.globalElementTopicCategoryCode=:globalElementTopicCategoryCode ");
					parameters.put("globalElementTopicCategoryCode", globalElementSearchVO.getGlobalElementTopicCategoryCode());
				}
			
			
			if(globalElementSearchVO.getGlobalElementName() != null || globalElementSearchVO.getGlobalElementMetadataValue() != null){
			
				queryStr.append(" and ( ");
		
				
		// if Element Name value is entered as a filter
		if (globalElementSearchVO.getGlobalElementName() != null
				&& globalElementSearchVO.getGlobalElementName().length() > 0) {
			queryStr.append(" upper(g.globalElementName) like upper(:globalElementName) or");
			parameters.put("globalElementName", "%"+globalElementSearchVO.getGlobalElementName()+"%");
		}
		
				
		if(globalElementSearchVO.getGlobalElementMetadataValue() != null && globalElementSearchVO.getGlobalElementMetadataValue().length() > 0){
			queryStr.append(" upper(gd.globalElementMetadataValue) like upper(:globalElementMetadataValue) or");
			parameters.put("globalElementMetadataValue", "%"+globalElementSearchVO.getGlobalElementMetadataValue()+"%");
		}
		
		queryStr.replace(queryStr.length()-2, queryStr.length(), "");	
		queryStr.append(" )");
		}
		}
		
		
		queryStr.append("order by ").append(
				getSortByColumnForSearch(globalElementSearchVO.getSortBy(),
						globalElementSearchVO.getSortOrder()));
		
		
		LOGGER.info("exiting GlobalElementStagingDAOImpl | searchByTopics | queryStr::"+queryStr.toString());

		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		// setting the page count and max results for pagination
		if (globalElementSearchVO.getViewType() == null) {
		query.setMaxResults(globalElementSearchVO.getMaxResults());
		query.setFirstResult(globalElementSearchVO.getRowIndex());
		}
		LOGGER.info("exiting GlobalElementStagingDAOImpl | searchByTopics");
		try{
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<GlobalElementVO> retrieveHints() {
		LOGGER.info("entering GlobalElementStagingDAOImpl | retrieveHints");
		Query query = em.createNamedQuery(QUERY_RETRIEVE_HINTS_LIST);
		LOGGER.info("exiting GlobalElementStagingDAOImpl | retrieveHints");		
		List<GlobalElementVO> hintsList =	query.getResultList();
		try {			
			return hintsList;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}




	@Override
	@SuppressWarnings("unchecked")
	public List<GlobalElementVO> retrieveHintsDesc() {
		LOGGER.info("entering GlobalElementStagingDAOImpl | retrieveHints");
		Query query = em.createNamedQuery(QUERY_RETRIEVE_HINTS_DESC_LIST);
		LOGGER.info("exiting GlobalElementStagingDAOImpl | retrieveHints");		
		List<GlobalElementVO> hintsDescList =	query.getResultList();
		try {			
			return hintsDescList;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}




	@Override
	public Long retrieveMaxGlobalElementId() {
		try {
			return jdbcTemplate.queryForLong("SELECT SORUSR.GLBL_ELE_ID_SEQ.nextval from dual");
			
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {		
			LOGGER.error("GlobalElementStagingDAOImpl | retreiveData", ex);
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}




	@Override
	public GlobalElement insertGlobalElement(GlobalElement globalElement) {
		try {
			return em.merge(globalElement);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}




	@Override
	public Long retreiveData(String query) {
		try {
			return jdbcTemplate.queryForLong(query);
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			LOGGER.error("GlobalElementStagingDAOImpl | retreiveData", ex);
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}




	@Override
	public GlobalElementDetail findGlobalElementDetailUsingId(
			Long globalElementDetailId) {
		try {
			return em.find(GlobalElementDetail.class, globalElementDetailId);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}




	@Override
	public GlobalElementDetail updateGlobalElementDetails(
			GlobalElementDetail existing_glblEle_details) {
		try {
			return em.merge(existing_glblEle_details);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}




	@Override
	public Long retrieveMaxGlobalElementDetailId() {
		try {
			return jdbcTemplate
					.queryForLong("SELECT SORUSR.GLBL_ELE_DTL_ID_SEQ.nextval from dual");
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			LOGGER.error("GlobalElementStagingDAOImpl | retrieveMaxGlobalElementDetailId",
					ex);
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@Override
	public Long retrieveMaxGlobalElementHistoryId() {
		try {
			return jdbcTemplate
					.queryForLong("SELECT SORUSR.GLBL_ELE_HIST_ID_SEQ.nextval from dual");
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			LOGGER.error("GlobalElementStagingDAOImpl | retrieveMaxGlobalElementHistoryId",
					ex);
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}	
	
	@Override
	public GlobalElementHistory updateGlobalElementHistory(
			GlobalElementHistory existing_glblEle_history) {
		try {
			return em.merge(existing_glblEle_history);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<GlobalElement> retrieveGlobalElement(String query) {		
			
		
		List<GlobalElement> listVal = new ArrayList<GlobalElement>();
		Query queryVal = formQueryForSearch(query);
		List<Object[]> result = queryVal.getResultList();
		try {
			for (Object[] rslt : result) {
				GlobalElement glblEle = new GlobalElement();
				glblEle.setGlobalElementId(Long.valueOf(rslt[0].toString()));
				glblEle.setGlobalElementTypeCode((Long.valueOf(rslt[1]
						.toString())));
				glblEle.setGlobalElementTopicCategoryCode(Long.valueOf(rslt[2].toString()));
				glblEle.setGlobalElementName(rslt[3].toString());
				glblEle.setEffectiveDate(Timestamp.valueOf(rslt[4].toString()));
				if(rslt[5] != null){
				glblEle.setExpirationDate(Timestamp.valueOf(rslt[5].toString()));
				}
				if(rslt[6] != null){
				glblEle.setGlobalElementComment(rslt[6].toString());
				}
				listVal.add(glblEle);
			}
		} catch (Exception e) {
			LOGGER.error("GlobalElementStagingDAOImpl | retrieveGlobalElement", e);
		}
		return listVal;
	}
	@Override
	public int deleteCrosswalk(AddCrosswalkVO addCrosswalkVO) {
			Map<String, Object> parameters = new HashMap<String, Object>();
			
			StringBuffer queryStr = new StringBuffer("DELETE FROM GloblalElementCrossWalk WHERE globalElementId=:globalElementId");
				parameters.put("globalElementId", addCrosswalkVO.getGlobalElementId());
			Query query = em.createQuery(queryStr.toString());
			for (Entry<String, ?> parameter : parameters.entrySet()) {
				query.setParameter(parameter.getKey(), parameter.getValue());
			}
			 return query.executeUpdate();
		}
	@SuppressWarnings("unchecked")
	@Override
	public List<GloblalElementCrossWalk> retrieveGlobalElementCrosswalk(String query) {		
		
		List<GloblalElementCrossWalk> listVal = new ArrayList<GloblalElementCrossWalk>();
		Query queryVal = formQueryForSearch(query);
		List<Object[]> result = queryVal.getResultList();
		try {
			for (Object[] rslt : result) {
				
				GloblalElementCrossWalk glblEle = new GloblalElementCrossWalk();
				glblEle.setGlobalElementCrosswalkId(Long.valueOf(rslt[0].toString()));
				glblEle.setGlobalElementId(Long.valueOf(rslt[1].toString()));
				glblEle.setGlobalElementMetadataCode(Long.valueOf(rslt[2].toString()));
				glblEle.setGlobalElementMetadataValue(rslt[3].toString());
				glblEle.setCreatedUser(rslt[4].toString());
				
				//glblEle.setCreatedDate(Date.valueOf(rslt[5].toString()));
				glblEle.setModifiedUser(rslt[6].toString());
				//glblEle.setModifiedDate(Date.valueOf(rslt[7].toString()));
				//glblEle.setGlobalElementCrosswalkCommnet(rslt[8].toString());
				glblEle.setGlobalElementPlatformCode(Long.valueOf(rslt[9].toString()));
				glblEle.setGlobalElementCrosswalkGrpNme(rslt[10].toString());				
				listVal.add(glblEle);
			}
		} catch (Exception e) {
			LOGGER.error("GlobalElementStagingDAOImpl | retrieveGlobalElementCrosswalk", e);
		}
		return listVal;
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<GlobalElementDetailVO> retrieveGlobalElementDetail(
			String detailQuery) {
				
		List<GlobalElementDetailVO> listVal = new ArrayList<GlobalElementDetailVO>();
		Query queryVal = formQueryForSearch(detailQuery);
		List<Object[]> result = queryVal.getResultList();
		try {
			for (Object[] rslt : result) {
				GlobalElementDetailVO glblEleDtl = new GlobalElementDetailVO();
				glblEleDtl.setGlobalElementDetailId(Long.valueOf(rslt[0].toString()));
				glblEleDtl.setGlobalElementId((Long.valueOf(rslt[1]
						.toString())));
				glblEleDtl.setGlobalElementMetadataCode(Long.valueOf(rslt[2].toString()));
				glblEleDtl.setGlobalElementMetadataValue(rslt[3].toString());
				if(rslt[4] != null){
				glblEleDtl.setGlobalElementMetadataTypeCode(Long.valueOf(rslt[4].toString()));
				}
				if(rslt[5] != null){
				glblEleDtl.setGlobalElementMetadataLangCode(Long.valueOf(rslt[5].toString()));
				}
				if(rslt[6] != null){
				glblEleDtl.setGlobalElementDetailComment(rslt[6].toString());				
				}
				listVal.add(glblEleDtl);
			}
		} catch (Exception e) {
			LOGGER.error("GlobalElementStagingDAOImpl | retrieveGlobalElementDetail", e);
		}
		return listVal;
		
		
		
		
	}

	private Query formQueryForSearch(String selectQuery) {
		StringBuffer queryStr = new StringBuffer();
		queryStr.append(selectQuery);
		Query query = em.createNativeQuery(queryStr.toString());
		return query;
	}
	
	@Override
	public GlobalElement findElementExistingId(Long elemnt_id) {
		try {
			return em.find(GlobalElement.class, elemnt_id);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	
	public String retreiveEleNme(String query) {
		try {
			List<String> elemntNme = jdbcTemplate.queryForList(query, String.class); 
		    if (elemntNme.isEmpty()) {
		        return "false";
		    } else {
		        return elemntNme.get(0);
		    }	
						
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			LOGGER.error("GlobalElementStagingDAOImpl | retreiveEleNme", ex);
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<SystemApplicability> retrievePlatformDetails(String query) {
		
		StringBuffer queryStr = new StringBuffer(query);
		List systemApplicability = null;
		try{
			systemApplicability = jdbcTemplate.query(queryStr.toString(), 
				new RowMapper<SystemApplicability>() {

					@Override
					public SystemApplicability mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						SystemApplicability systemApplicability = new SystemApplicability();
						systemApplicability.setCodeValueId(rs.getLong("codeValueId"));
						systemApplicability.setCodeValueDescription(rs.getString("codeValueDescription"));
						return systemApplicability;
					}					
				});
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return systemApplicability;
	}

	@Override
	public Long retrieveMaxCrossWalkId() {
		try {
			return jdbcTemplate.queryForLong("SELECT SORUSR.GLBL_ELE_CW_ID_SEQ.nextval from dual");
			
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {		
			LOGGER.error("GlobalElementStagingDAOImpl | retreiveData", ex);
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@Override
	public GloblalElementCrossWalk addNewCrosswalk(GloblalElementCrossWalk globlalElementCrossWalk) {
		try {
			return em.merge(globlalElementCrossWalk);
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		
	}

	@Override
	public String retreiveEleTypDesc(String query) {
		try {
			List<String> elemntNme = jdbcTemplate.queryForList(query, String.class);   
		    return elemntNme.get(0);		    	
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			LOGGER.error("GlobalElementStagingDAOImpl | retreiveData", ex);
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}



	@SuppressWarnings("unchecked")
	@Override
	public List<GloblalElementCrossWalk> crosswalkSearch(
			GlobalElementCrosswalkSearchVOBkp globalElementSearchVO) {
		LOGGER.info("entering GlobalElementStagingDAOImpl | searchByTopics");
		LOGGER.info("\n\ngeoSearchCriteria :: " + globalElementSearchVO);
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer(QUERY_RETRIEVE_CROSSWALK_SEARCH_SELECT);
		// if Element Id value is entered as a filter
		if( globalElementSearchVO.getGlobalElementId() != null){
			queryStr.append(" where g.globalElementId=:globalElementId ");
			parameters.put("globalElementId", globalElementSearchVO.getGlobalElementId());
		}else{					
			if(globalElementSearchVO.getGlobalElementMetadataCode()!=null || globalElementSearchVO.getGlobalElementPlatformCode() != null || globalElementSearchVO.getGlobalElementMetadataValue() != null)
				queryStr.append(" where ");
			if(globalElementSearchVO.getGlobalElementMetadataCode() != null){
				queryStr.append(" g.globalElementMetadataCode=:globalElementMetadataCode ");
				parameters.put("globalElementMetadataCode", globalElementSearchVO.getGlobalElementMetadataCode());
				if(globalElementSearchVO.getGlobalElementMetadataValue()!=null || globalElementSearchVO.getGlobalElementPlatformCode() != null){
				queryStr.append(" and ");
				}
			}
			if( globalElementSearchVO.getGlobalElementPlatformCode() != null){
				queryStr.append("  g.globalElementPlatformCode=:globalElementPlatformCode ");
				parameters.put("globalElementPlatformCode", globalElementSearchVO.getGlobalElementPlatformCode());
				if(globalElementSearchVO.getGlobalElementMetadataValue()!=null){
				queryStr.append(" and ");
				}
			}
			if( globalElementSearchVO.getGlobalElementMetadataValue() != null){
				queryStr.append("  upper(g.globalElementMetadataValue) like upper(:globalElementMetadataValue) ");
				parameters.put("globalElementMetadataValue", "%"+globalElementSearchVO.getGlobalElementMetadataValue()+"%");
			}
		}
		queryStr.append(" order by ").append(getSortByColumnForCrosswalkSearch(globalElementSearchVO.getSortBy(),globalElementSearchVO.getSortOrder()));
		LOGGER.info("exiting GlobalElementStagingDAOImpl | searchByTopics | queryStr::"+queryStr.toString());
		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		// setting the page count and max results for pagination
		if (globalElementSearchVO.getViewType() == null) {
		query.setMaxResults(globalElementSearchVO.getMaxResults());
		query.setFirstResult(globalElementSearchVO.getRowIndex());
		}
		LOGGER.info("exiting GlobalElementStagingDAOImpl | searchByTopics  ");
		try{
		return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	private String getSortByColumnForCrosswalkSearch(String sortBy, String sortOrder) {
		String sortByColumns;
		
		 if ("globalElementId".equalsIgnoreCase(sortBy)) {
			sortByColumns = "g.globalElementId "
					+ sortOrder
					+ ", g.globalElementCrosswalkId, g.globalElementMetadataCode,g.globalElementMetadataValue,g.globalElementPlatformCode,g.globalElementCrosswalkGrpNme";
		}else if ("globalElementCrosswalkId".equalsIgnoreCase(sortBy)) {
			sortByColumns = "g.globalElementCrosswalkId "
					+ sortOrder
					+ ", g.globalElementId, g.globalElementMetadataCode,g.globalElementMetadataValue,g.globalElementPlatformCode,g.globalElementCrosswalkGrpNme";
		}else if ("globalElementMetadataCode".equalsIgnoreCase(sortBy)) {
			sortByColumns = "g.globalElementMetadataCode "
				+ sortOrder
				+ ", g.globalElementId, g.globalElementCrosswalkId,g.globalElementMetadataValue,g.globalElementPlatformCode,g.globalElementCrosswalkGrpNme";
		}else if ("globalElementMetadataValue".equalsIgnoreCase(sortBy)) {
			sortByColumns = "g.globalElementMetadataValue "
				+ sortOrder
				+ ", g.globalElementId, g.globalElementCrosswalkId,g.globalElementMetadataCode,g.globalElementPlatformCode,g.globalElementCrosswalkGrpNme";
		}else if ("globalElementPlatformCode".equalsIgnoreCase(sortBy)) {
			sortByColumns = "g.globalElementPlatformCode "
				+ sortOrder
				+ ", g.globalElementId, g.globalElementCrosswalkId,g.globalElementMetadataCode,g.globalElementMetadataValue,g.globalElementCrosswalkGrpNme";
		}else if ("globalElementCrosswalkGrpNme".equalsIgnoreCase(sortBy)) {
			sortByColumns = "g.globalElementCrosswalkGrpNme "
				+ sortOrder
				+ ", g.globalElementId,g.globalElementCrosswalkId, g.globalElementMetadataCode,g.globalElementMetadataValue,g.globalElementPlatformCode";
		}else {
			sortByColumns = "g.globalElementId "
				+ sortOrder
				+ ", g.globalElementCrosswalkId, g.globalElementMetadataCode,g.globalElementMetadataValue,g.globalElementPlatformCode,g.globalElementCrosswalkGrpNme";
		}

		return sortByColumns;
	}



	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValue> retrieveSearchCrossWalkCodeType(Long crosswalkApplied) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | retrieveCrossWalksForIndsCodeType");
		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_CROSSWALK_CODE_TYPE_CODE);
		query.setParameter("crosswalkApplied", crosswalkApplied);

		LOGGER.info("exiting IndsCodeStagingDAOImpl | retrieveCrossWalksForIndsCodeType");
		try{
		//	return null;
			List<CodeValue> codeValueList=query.getResultList();
		return codeValueList;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}



	@Override
	public Long countCrosswalkSearch(
			GlobalElementCrosswalkSearchVOBkp globalElementCrosswalkSearchVO) {
		LOGGER.info("entering countCrosswalkSearch | countCrosswalkSearch");
		LOGGER.info("globalElementSearchCriteriaVO :: " + globalElementCrosswalkSearchVO);
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer(QUERY_RETRIEVE_CROSSWALK_SEARCH_COUNT);
		/**
		 * Include the where condition if at least one of the filter condition is not empty. append the where condition.
		 */	
		// if Element Id value is entered as a filter
		if( globalElementCrosswalkSearchVO.getGlobalElementId() != null){
			queryStr.append(" where g.globalElementId=:globalElementId ");
			parameters.put("globalElementId", globalElementCrosswalkSearchVO.getGlobalElementId());
		}else{					
			if(globalElementCrosswalkSearchVO.getGlobalElementMetadataCode()!=null || globalElementCrosswalkSearchVO.getGlobalElementPlatformCode() != null || globalElementCrosswalkSearchVO.getGlobalElementMetadataValue() != null)
				queryStr.append(" where ");
			if(globalElementCrosswalkSearchVO.getGlobalElementMetadataCode() != null){
				queryStr.append(" g.globalElementMetadataCode=:globalElementMetadataCode ");
				parameters.put("globalElementMetadataCode", globalElementCrosswalkSearchVO.getGlobalElementMetadataCode());
				if(globalElementCrosswalkSearchVO.getGlobalElementMetadataValue()!=null || globalElementCrosswalkSearchVO.getGlobalElementPlatformCode() != null){
				queryStr.append(" and ");
				}
			}
			if( globalElementCrosswalkSearchVO.getGlobalElementPlatformCode() != null){
				queryStr.append("  g.globalElementPlatformCode=:globalElementPlatformCode ");
				parameters.put("globalElementPlatformCode", globalElementCrosswalkSearchVO.getGlobalElementPlatformCode());
				if(globalElementCrosswalkSearchVO.getGlobalElementMetadataValue()!=null){
				queryStr.append(" and ");
				}
			}
			if( globalElementCrosswalkSearchVO.getGlobalElementMetadataValue() != null){
				queryStr.append("  upper(g.globalElementMetadataValue) like upper(:globalElementMetadataValue) ");
				parameters.put("globalElementMetadataValue", "%"+globalElementCrosswalkSearchVO.getGlobalElementMetadataValue()+"%");
			}
		}
		
		LOGGER.info("exiting GlobalElementStagingDAOImpl | countCrosswalkSearch");
		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		try{
			return (Long) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}



	
	@SuppressWarnings("unchecked")
	@Override
	public List<AddCrosswalkVO> retrieveEditPlatformDetails(String query) {
		
		List<AddCrosswalkVO> listVal = new ArrayList<AddCrosswalkVO>();
		Query queryVal = formQueryForSearch(query);
		List<Object[]> result = queryVal.getResultList();
		try {
			for (Object[] rslt : result) {
				AddCrosswalkVO crosswalkData = new AddCrosswalkVO();
				crosswalkData.setMetadataCode(Long.valueOf(rslt[0].toString()));
				crosswalkData.setCodeValueDescription(rslt[1].toString());
				crosswalkData.setMetadataValue(rslt[2].toString());				
				listVal.add(crosswalkData);
			}
		} catch (Exception e) {
			LOGGER.error("GlobalElementStagingDAOImpl | retrieveEditPlatformDetails", e);
		}
		return listVal;
	}



	@Override
	public Long retrieveEleTypCd(String eleTypQuery) {
		try {
			return jdbcTemplate.queryForLong(eleTypQuery);
			
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {		
			LOGGER.error("GlobalElementStagingDAOImpl | retreiveData", ex);
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}



	@SuppressWarnings("unchecked")
	@Override
	public List<GloblalElementCrossWalk> retrievePlatformList() {
		LOGGER.info("entering GlobalElementStagingDAOImpl | retrieveTopics");
		List<GloblalElementCrossWalk> platformList = new ArrayList<GloblalElementCrossWalk>();
		Query query = em.createNamedQuery(QUERY_RETRIEVE_PLATFORM_LIST);  
		List<Object[]> result =	 query.getResultList();
		
		try {
			for (Object[] rslt : result) {
				GloblalElementCrossWalk platformData = new GloblalElementCrossWalk();
				platformData.setGlobalElementPlatformCode(Long.valueOf(rslt[0].toString()));
				platformData.setGlobalElementPlatformCodeDescription(rslt[1].toString());
				platformData.setElementsCount(Long.valueOf(rslt[2].toString()));			
				platformList.add(platformData);		
			}			
			
			LOGGER.info("exiting GlobalElementStagingDAOImpl | retrievePlatformList |"+platformList);				
			return platformList;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<GlobalElement> retrieveUnMappedCountList() {
		
		LOGGER.info("entering GlobalElementStagingDAOImpl | retrieveTopics");
		List<GlobalElement> platformUnmappedList = new ArrayList<GlobalElement>();
		Query query = em.createNamedQuery(QUERY_RETRIEVE_UNMAPPED_ELEMENT_COUNT_LIST);  
		List<Object[]> result =	 query.getResultList();
		
		
		try {
			for (Object[] rslt : result) {
				GlobalElement platformUnmappedData = new GlobalElement();
				platformUnmappedData.setMonth(rslt[0].toString());
				platformUnmappedData.setUnMappedElementCount(Long.valueOf(rslt[1].toString()));		
				platformUnmappedList.add(platformUnmappedData);		
			}			
			
			LOGGER.info("exiting GlobalElementStagingDAOImpl | retrievePlatformList |"+platformUnmappedList);				
			return platformUnmappedList;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@Override
	public Long totalUnMappedElementCount() {
		try {
			return jdbcTemplate.queryForLong("select count(GLBL_ELE_ID) from SORUSR.GLBL_ELE_RLS_2 where GLBL_ELE_ID not in (select GLBL_ELE_ID from SORUSR.GLBL_ELE_CROSS_WALK)");
			
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {		
			LOGGER.error("GlobalElementStagingDAOImpl | retreiveData", ex);
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	
	@Override
	public Long retrieveGroupName(String groupName) {		
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer(QUERY_COUNT_CROSSWALK_EXISTING_GROUP_NAME);
		/**
		 * Include the where condition if at least one of the filter condition is not empty. append the where condition.
		 */	
		// if Element Id value is entered as a filter
		if( groupName != null){
			queryStr.append(" where globalElementCrosswalkGrpNme=:globalElementCrosswalkGrpNme ");
			parameters.put("globalElementCrosswalkGrpNme", groupName);
		}
		LOGGER.info("exiting GlobalElementStagingDAOImpl | countCrosswalkSearch");
		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
			return (Long) query.getSingleResult();
	}
	
	@Override
    public Long retrieveGroupName(String groupName,Long globalElementId) {        
          Map<String, Object> parameters = new HashMap<String, Object>();
          StringBuffer queryStr = new StringBuffer(QUERY_COUNT_CROSSWALK_EXISTING_GROUP_NAME);
          /**
          * Include the where condition if at least one of the filter condition is not empty. append the where condition.
          */   
          // if Element Id value is entered as a filter
          if( groupName != null){
                queryStr.append(" where globalElementCrosswalkGrpNme=:globalElementCrosswalkGrpNme ");
                parameters.put("globalElementCrosswalkGrpNme", groupName);
          }
          if( globalElementId != null){
                queryStr.append(" and globalElementId != (:globalElementId)");
                parameters.put("globalElementId", globalElementId);
          }
          LOGGER.info("exiting GlobalElementStagingDAOImpl | countCrosswalkSearch");
          Query query = em.createQuery(queryStr.toString());
          for (Entry<String, ?> parameter : parameters.entrySet()) {
                query.setParameter(parameter.getKey(), parameter.getValue());
          }
                return (Long) query.getSingleResult();
    }


}
