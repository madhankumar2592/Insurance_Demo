/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;
import java.util.Map;

import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.SCoTSSearchCriteriaVO;

/**
 * This is used as the services interface for the SCoTS operations
 *
 * @author Cognizant
 * @version last updated : Feb 2, 2012
 * @see
 *
 */
public interface SCoTsStagingDAO {

	/**
	 *
	 * The method will retrieve the SCoTS data for all the tables given as
	 * parameter from the Staging SoR. The input will be list of Code Table IDs
	 * and the user preferred language. The return will be a map with key as
	 * Code table ID and value as list of CodeValue. The method is invoked to
	 * populate the following drop downs in Add Geo Unit UI: - Geo Unit Type -
	 * Name Type - Language - Data Provider - Code Type
	 *
	 * @param codeTableIds
	 * @param langaugeCode
	 * @return
	 */
	Map<Long, List<CodeValue>> retrieveCodeValues(List<Long> codeTableIds, Long langaugeCode);

	Map<Long, List<CodeValue>> retrieveCodeValuesScr(List<Long> codeTableIds, Long langaugeCode);

	/**
	 *
	 * The method will retrieve the SCoTS data for all the tables given as
	 * parameter from the Staging SoR. The input will be list of Code Table IDs
	 * and the user preferred language. The return will be a map with key as
	 * Code table ID and value as list of CodeValue.
	 *
	 * @param codeValueIds
	 * @param langaugeCode
	 * @return
	 */
	Map<Long, List<CodeValue>> retrieveCodeValuesById(List<Long> codeValueIds, Long langaugeCode);
	/**
	 *
	 * The method will perform the table search of SCoTS Code Tables on the
	 * search db.
	 * <p>
	 *
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 *
	 * @param SCoTSSearchCriteriaVO
	 * @return list of CodeValue
	 */
	List<CodeTable> searchCodeTables(SCoTSSearchCriteriaVO searchCriteriaVO);

	/**
	 *
	 * The method will count the records in the hierarchy search of code tables
	 * on the search db. The search will be done on the flat db based on the
	 * search criteria the user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return count of search results
	 */
	Long countSearchCodeTables(SCoTSSearchCriteriaVO searchCriteriaVO);

	/**
	 * The method will retrieve all Code Tables from the Search DB . The return
	 * type is a VO which contains the Code Table Id and the Code Table Names.
	 *
	 */

	List<CodeValueVO> retrieveCodeTableList();

	/**
	 * The method will retrieve all Code Languages from the Search DB . The
	 * return type is a VO which contains the Code Value Id and the COde Value
	 * Description (language names).
	 *
	 */
	List<CodeValueVO> retrieveCodeLanguages();

	/**
	 * The method will retrieve all systems applicable from the Search DB . The
	 * return type is a VO which contains the DNB system code and the Code Value
	 * Description.
	 *
	 * @param codeTableId
	 * @return list of CodeValueVO
	 */
	List<SystemApplicability> retrieveSystemApplicability(Long codeTableId, int applicabilityIndicator);

	@SuppressWarnings("rawtypes")
	List retrieveSystemForCode(String applicability, Long applicabilityCode);

	List<CodeValueVO> retrieveAllSystemApplicability(String applicability);

	/**
	 * The method will retrieve all systems applicable from the Search DB . The
	 * return type is a VO which contains the DNB system code and the Code Value
	 * Description.
	 *
	 * @param codeTableId
	 * @return list of CodeValueVO
	 */
	List<CountryApplicability> retrieveCountryApplicability(Long codeTableId, int applicabilityIndicator);

	/**
	 *
	 * The method to find the CodeTable entity by the primary key codeTableId
	 *
	 * @param codeTableId
	 * @return CodeTable entity
	 */
	CodeTable retrieveCodeTableById(Long codeTableId);

	/**
	 *
	 * The method to fetch the details of codeValues based on the codeTableId.
	 * The filter will also contain the language code, system applicability code
	 * and country applicability code.
	 *
	 * @param searchCriteriaVO
	 * @return list of codeValues
	 */
	List<CodeValue> retrieveCodeValuesByTableId(SCoTSSearchCriteriaVO searchCriteriaVO);

	/**
	 *
	 * The method to count the results of codeValues based on the codeTableId.
	 * The filter will also contain the language code, system applicability code
	 * and country applicability code.
	 *
	 * @param searchCriteriaVO
	 * @return count of codeValues
	 */
	Long countCodeValuesByTableId(SCoTSSearchCriteriaVO searchCriteriaVO);

	/**
	 *
	 * The method to fetch the count of Code Value details based on the filter
	 * condition. The Code Value will be searched based on description or on the
	 * business description.
	 *
	 * @param searchCriteriaVO
	 * @return countCodeValues
	 */
	Long countOfSearchCodeValues(SCoTSSearchCriteriaVO searchCriteriaVO);

	/**
	 *
	 * The method to fetch the Code Value details based on the filter condition.
	 * The Code Value will be searched based on description or on the business
	 * description.
	 *
	 * @param searchCriteriaVO
	 * @return codeValues
	 */
	List<CodeValue> searchCodeValues(SCoTSSearchCriteriaVO searchCriteriaVO);

       	/**
	 *
	 * Fetches the CodeValue entity by the  key codeValueId.<p>
	 *
	 * @param codeTableId
	 * @return CodeValue entity
       	 * @throws Exception
	 */
	CodeValue retrieveCodeValueByCodeValueId(Long codeValueId) throws Exception;

	/**
	 *
	 * The method to retrieve all codeValue associations from database. The
	 * method will accept the parent and child code table Id s and will return
	 * all associations having the relationship between the specified parent and
	 * child code tables.
	 *
	 * @param parentCodeTableId
	 * @param childCodeTableId
	 * @return List<CodeValueAssociation>
	 */
	List<CodeValueAssociation> retrieveCodeValueAssociations(
			Long parentCodeTableId, Long childCodeTableId, Boolean isStagingDB);

	/**
	 *
	 * The method to retrieve all alternate schema code types from the database.
	 * The method will be invoked as a web-service to retrieve the data.
	 *
	 * @return List<CodeValueVO>
	 */
	List<CodeValueVO> retrieveAllAlternateSchemeCodes();

	/**
	 *
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the staging
	 * DB to fetch all alternate scheme codes matching the scheme type code
	 * selected by the user.
	 *
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	List<CodeValueAlternateScheme> retrieveAlternateSchemeCodes(Long schemeTypeCode);

        /**
	 *
	 * The method to find the SystemApplicability entity by CodeTable
	 *
	 * @param codeValueDescription
	 * @return SystemApplicability entity
	 */
	SystemApplicability retrieveSystemByCodeTable(CodeValueVO systemSearchCriteriaVO);

	/**
	 *
	 * The method to find the CountryApplicability entity by the  CodeTable
	 *
	 * @param codeValueDescription
	 * @return CountryApplicability entity
	 */
	CountryApplicability retrieveCountryByCodeTable(String codeValueDescription);

	 /**
	 * The method will persist the existing Code Table data in the Staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	CodeTable updateCodeTable(CodeTable codeTable);

        /**
	 * The method will persist the existing Code Value data in the Staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	CodeValue updateCodeValue(CodeValue codeValue);
	/**
	 * The method will persist the existing Applicability data in the Staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param systemApplicabilities
	 */
	void updateApprovedSystemApplicabilities(List<SystemApplicability> systemApplicabilities);

	/**
	 * The method will persist the existing Applicability data in the Staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param countryApplicabilities
	 */
	void updateApprovedCountryApplicabilities(List<CountryApplicability> countryApplicabilities);

	/**
	 * The method will persist the existing Code Value data in the Staging DB.
	 * Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	void updateApprovedCodeValueAlternateSchemes(List<CodeValueAlternateScheme> codeValueAlternateScheme);

 /**
	 * The method will persist the existing CodeValueAssociation in the Staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeValueAssociation
	 */
	CodeValueAssociation updateCodeValueAssociation(CodeValueAssociation codeValueAssociation);
	List<CodeValueAssociation> retrieveParentCodeValueAssociations(Long codeValueId);
	List<CodeValueAssociation> retrieveChildCodeValueAssociations(Long codeValueId);
	
	/**
	 * 
	 * The method to retrieve all valid industry code group levels
	 *
	 * @return validIndustryCodeGroupLevels
	 */
	List<CodeValue> retrieveValidIndustryCodeGroupLevels();
	
	/**
	 * 
	 * The method will retrieve the Industry code data for all the tables given
	 * as parameter from the Staging SoR. The input will be Code Table ID of the
	 * Industry Code Type table. This method will be invoked only for search as
	 * this will fetch only the existing industry code types from inds_code
	 * table.
	 * 
	 * @param indsCodeTableId
	 * @return
	 */
	public List<CodeValue> retrieveIndustryCodeValues(Long indsCodeTableId);
	
	/**
	 * 
	 * The method will be invoked on approval of request by work-flow. The
	 * method will return the max of code value id from the staging database.
	 * 
	 * @param tableName
	 * @return codeId
	 */
	public Long retrieveStagingCodeId(String tableName);
	
	/**
	 * 
	 * The method to check whether the code value is existing in the staging
	 * database. This method will be invoked on approval of request by work-flow
	 * 
	 * @param codeId
	 * @param tableName
	 * @return boolean true if existing in staging db
	 */
	public Boolean isSCoTsCodeAvailable(Long codeId, String tableName);

	List<CodeValue> retrieveCodeValuesScores(List<Long> codeTableIds,
			Long langaugeCode);
	
	List<CodeValue> retrieveMktGrpCodes();
}
