
/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;
/**
 * DAO interface class for th industry code bulk downaload status operations.
 * <p>
 * 
 * The DAO contacts the staging DB for all its operations.
 * <p>
 * 
 * @author Cognizant
 * @version last updated : May 21, 2012
 * @see
 * 
 */
public interface IndsBatchDao {
	/**
	 * The method to update the industry code bulk downaload status
	 * 
	 * @param uibulkid
	 */
	public void update(Long uiBulkDwnldId,int status);

}
