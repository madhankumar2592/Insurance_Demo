/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.vo.GeoBulkUploadMasterVO;
import com.dnb.dsc.refdata.core.vo.GeoPropertyFileVO;
import com.dnb.dsc.refdata.dao.GeoBulkUploadDAO;

/**
 * 
 * @author Cognizant
 * @version last updated : June 23, 2012
 * @see
 * 
 */
public class GeoBulkUploadDAOImpl extends JdbcDaoSupport implements
		GeoBulkUploadDAO {

	/*@Autowired
	private JdbcTemplate jdbcTemplate;*/

	GeoPropertyFileVO geoPropertyFileVO;

	public GeoBulkUploadDAOImpl(GeoPropertyFileVO geoPropertyFileVO) {
		this.geoPropertyFileVO = geoPropertyFileVO;
	}

	/**
	 * 
	 */
	public void save(
			final List<? extends GeoUnitAssociation> geoAssnBulkuploadList,String userId) {
		final SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		String geoAssnInsertQuery = geoPropertyFileVO
				.getGeoUnitAssnInsertQuery();
		String updatestmt = geoPropertyFileVO.getGeoUnitAssnUpdateQuery();
		final List<GeoUnitAssociation> insertList = new ArrayList<GeoUnitAssociation>();
		final List<GeoUnitAssociation> deleteList = new ArrayList<GeoUnitAssociation>();
		for (GeoUnitAssociation geoUnitAssn : geoAssnBulkuploadList) {
			if (geoUnitAssn.getGeoUnitAssociationId() == null) {
				geoUnitAssn.setCreatedUser(userId);
				geoUnitAssn.setModifiedUser(userId);
				insertList.add(geoUnitAssn);
			} else if(geoUnitAssn.getExpirationDate()!=null){
				geoUnitAssn.setModifiedUser(userId);
				deleteList.add(geoUnitAssn);
			}
		}

		getJdbcTemplate().batchUpdate(geoAssnInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						GeoUnitAssociation geoUnitAssociation = insertList
								.get(i);
						ps.setLong(1, geoUnitAssociation.getChildGeoUnitId());
						ps.setLong(2, geoUnitAssociation.getParentGeoUnitId());
						ps.setString(3, format.format(geoUnitAssociation
								.getEffectiveDate()));

						if (geoUnitAssociation.getExpirationDate() != null) {
							ps.setString(4, format.format(geoUnitAssociation
									.getExpirationDate()));
						} else {
							ps.setNull(4, java.sql.Types.DATE);
						}
						if (geoUnitAssociation.getExpiredByDate() != null) {
							ps.setString(5, format.format(geoUnitAssociation
									.getExpiredByDate()));
						} else {
							ps.setNull(5, java.sql.Types.DATE);
						}
						ps.setString(6, geoUnitAssociation.getCreatedUser());
						ps.setString(7, geoUnitAssociation.getModifiedUser());
					}

					public int getBatchSize() {
						return insertList.size();
					}
				});
		getJdbcTemplate().batchUpdate(updatestmt,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						/*GeoUnitAssociation geoUnitAssociation = deleteList
								.get(i);
						ps.setLong(1, geoUnitAssociation.getChildGeoUnitId());
						ps.setLong(2, geoUnitAssociation.getParentGeoUnitId());
						ps.setString(3, format.format(geoUnitAssociation
								.getEffectiveDate()));

						if (geoUnitAssociation.getExpirationDate() != null) {
							ps.setString(4, format.format(geoUnitAssociation
									.getExpirationDate()));
						} else {
							ps.setNull(4, java.sql.Types.DATE);
						}
						if (geoUnitAssociation.getExpiredByDate() != null) {
							ps.setString(5, format.format(geoUnitAssociation
									.getExpiredByDate()));
						} else {
							ps.setNull(5, java.sql.Types.DATE);
						}
						ps.setString(6, geoUnitAssociation.getModifiedUser());
						ps.setLong(7,
								geoUnitAssociation.getGeoUnitAssociationId());*/
						GeoUnitAssociation geoUnitAssociation = deleteList.get(i);
						ps.setString(1, format.format(geoUnitAssociation
								.getExpirationDate()));
						ps.setString(2,format.format(geoUnitAssociation
								.getExpiredByDate()));                                 // added for Geo Fix
						ps.setString(3, geoUnitAssociation.getModifiedUser());
						ps.setLong(4,
								geoUnitAssociation.getGeoUnitAssociationId());
						
					}

					public int getBatchSize() {
						return deleteList.size();
					}
				});
	}

	/**
	 * 
	 */
	public void saveGeoCode(
			List<? extends GeoBulkUploadMasterVO> geoBulkUploadList,String userId) {
		String geoUnitInsertQuery = geoPropertyFileVO.getGeoUnitInsertQuery();
		String geoUnitNmeInsertQuery = geoPropertyFileVO
				.getGeoUnitNmeInsertQuery();
		String geoUnitCodeInsertQuery = geoPropertyFileVO
				.getGeoUnitCodeInsertQuery();
		
		String geoUnitDeleteQuery=geoPropertyFileVO.getGeoUnitDeleteQuery();                          //modified
		String geoUnitNmeDeleteQuery=geoPropertyFileVO.getGeoUnitNmeDeleteQuery();						 //modified
		String geoUnitCodeDeleteQuery=geoPropertyFileVO.getGeoUnitCodeDeleteQuery();						//modified
		String geoUnitAssnPrntDeleteQuery=geoPropertyFileVO.getGeoUnitAssnPrntDeleteQuery();					//modified
		String geoUnitAssnChldDeleteQuery=geoPropertyFileVO.getGeoUnitAssnChldDeleteQuery();						//modified
		String geoUnitNmeIdDeleteQuery=geoPropertyFileVO.getGeoUnitNmeIdDeleteQuery();									//modified
		String geoUnitCodeIdDeleteQuery=geoPropertyFileVO.getGeoUnitCodeIdDeleteQuery();
		
		final SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		final List<GeoUnit> geoUnitList = new ArrayList<GeoUnit>();
		final List<GeoUnit> geoUnitDeleteList = new ArrayList<GeoUnit>();
		final List<GeoUnitName> geoUnitNmeList = new ArrayList<GeoUnitName>();
		final List<GeoUnitName> geoUnitNmeDeleteList = new ArrayList<GeoUnitName>();
		final List<GeoUnitCode> geoUnitCodeList = new ArrayList<GeoUnitCode>();
		final List<GeoUnitCode> geoUnitCodeDeleteList = new ArrayList<GeoUnitCode>();
		for (GeoBulkUploadMasterVO geoBulkUploadMasterVO : geoBulkUploadList) {
			GeoUnit geoUnit = geoBulkUploadMasterVO.getGeoUnit();
			if (geoUnit != null) {
				if (geoUnit.getGeoUnitBulkId().startsWith("NRQ")) {
					geoUnit.setCreatedUser(userId);
					geoUnit.setModifiedUser(userId);
					geoUnitList.add(geoUnit);
				}
				else if(geoUnit.getExpirationDate()!=null){
					geoUnit.setGeoUnitId(Long.valueOf(geoUnit.getGeoUnitBulkId()));
					geoUnit.setModifiedUser(userId);
					geoUnitDeleteList.add(geoUnit);
				}
			}

		}
		for (GeoBulkUploadMasterVO geoBulkUploadMasterVO : geoBulkUploadList) {
			GeoUnitName geoUnitName = geoBulkUploadMasterVO.getGeoUnitNme();
			if (geoUnitName != null) {
				if (geoUnitName.getGeoUnitNameId() == null) {
					geoUnitName.setCreatedUser(userId);
					geoUnitName.setModifiedUser(userId);
					geoUnitNmeList.add(geoUnitName);
				}
				else if(geoUnitName.getExpirationDate()!=null){
					geoUnitName.setModifiedUser(userId);
					geoUnitNmeDeleteList.add(geoUnitName);
				}
			}

		}
		for (GeoBulkUploadMasterVO geoBulkUploadMasterVO : geoBulkUploadList) {
			GeoUnitCode geoUnitCode = geoBulkUploadMasterVO.getGeoUnitCode();
			if (geoUnitCode != null) {
				if (geoUnitCode.getGeoUnitCodeId() == null) {
					geoUnitCode.setCreatedUser(userId);
					geoUnitCode.setModifiedUser(userId);
					geoUnitCodeList.add(geoUnitCode);
				}else if(geoUnitCode.getExpirationDate()!=null){
					geoUnitCode.setModifiedUser(userId);
					geoUnitCodeDeleteList.add(geoUnitCode);
				}
			}

		}
		getJdbcTemplate().batchUpdate(geoUnitInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						GeoUnit geoUnit = geoUnitList.get(i);
						ps.setLong(1, geoUnit.getGeoUnitId());
						ps.setLong(2, geoUnit.getGeoUnitTypeCode());
						if (geoUnit.getDnbComment() != null) {
							ps.setString(3, geoUnit.getDnbComment());
						} else {
							ps.setNull(3, java.sql.Types.VARCHAR);
						}
						ps.setString(4,
								format.format(geoUnit.getEffectiveDate()));
						if (geoUnit.getExpiredByDate() != null) {
							ps.setString(5,
									format.format(geoUnit.getExpiredByDate()));
						} else {
							ps.setNull(5, java.sql.Types.DATE);
						}
						if (geoUnit.getExpirationDate() != null) {
							ps.setString(6,
									format.format(geoUnit.getExpirationDate()));
						} else {
							ps.setNull(6, java.sql.Types.DATE);
						}
						ps.setString(7,geoUnit.getCreatedUser());
						ps.setString(8,geoUnit.getModifiedUser());
					}

					public int getBatchSize() {
						return geoUnitList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(geoUnitDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						GeoUnit geoUnit = geoUnitDeleteList.get(i);
						
						ps.setString(1,
								format.format(geoUnit.getExpirationDate()));
						ps.setString(2,
								format.format(geoUnit.getExpiredByDate()));   // Added Geo Bug Fix
						ps.setString(3,geoUnit.getModifiedUser());
						ps.setLong(4,geoUnit.getGeoUnitId());
					}

					public int getBatchSize() {
						return geoUnitDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(geoUnitNmeDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						GeoUnit geoUnit = geoUnitDeleteList.get(i);
						
						ps.setString(1,
								format.format(geoUnit.getExpirationDate()));
						ps.setString(2,
								format.format(geoUnit.getExpiredByDate()));   // Added Geo Bug Fix
						ps.setString(3,geoUnit.getModifiedUser());
						ps.setLong(4,geoUnit.getGeoUnitId());
					}

					public int getBatchSize() {
						return geoUnitDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(geoUnitCodeDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						GeoUnit geoUnit = geoUnitDeleteList.get(i);
						
						ps.setString(1,
								format.format(geoUnit.getExpirationDate()));	
						ps.setString(2,
								format.format(geoUnit.getExpiredByDate()));   // Added Geo Bug Fix
						ps.setString(3,geoUnit.getModifiedUser());
						ps.setLong(4,geoUnit.getGeoUnitId());
					}

					public int getBatchSize() {
						return geoUnitDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(geoUnitAssnPrntDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						GeoUnit geoUnit = geoUnitDeleteList.get(i);
						
						ps.setString(1,
								format.format(geoUnit.getExpirationDate()));		
						ps.setString(2,
								format.format(geoUnit.getExpiredByDate())); // Added Geo Bug Fix
						ps.setString(3,geoUnit.getModifiedUser());
						ps.setLong(4,geoUnit.getGeoUnitId());
					}

					public int getBatchSize() {
						return geoUnitDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(geoUnitAssnChldDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						GeoUnit geoUnit = geoUnitDeleteList.get(i);
						
						ps.setString(1,
								format.format(geoUnit.getExpirationDate()));
						
						ps.setString(2,
								format.format(geoUnit.getExpiredByDate())); // Added Geo Bug Fix
						ps.setString(3,geoUnit.getModifiedUser());
						ps.setLong(4,geoUnit.getGeoUnitId());
					}

					public int getBatchSize() {
						return geoUnitDeleteList.size();
					}
				});

		getJdbcTemplate().batchUpdate(geoUnitNmeInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						GeoUnitName geoUnitName = geoUnitNmeList.get(i);
						if (geoUnitName.getGeoUnitBulkId().startsWith("NRQ")) {
							ps.setLong(1, geoUnitName.getGeoUnitId());
						} else {
							ps.setLong(1,
									new Long(geoUnitName.getGeoUnitBulkId()));
						}
						ps.setLong(2, geoUnitName.getLanguageCode());
						ps.setLong(3, geoUnitName.getWritingScriptCode());
						ps.setLong(4, geoUnitName.getNameTypeCode());
						ps.setString(5, geoUnitName.getGeoName());
						ps.setLong(6, geoUnitName.getDataProviderCode());
						ps.setString(7,
								format.format(geoUnitName.getEffectiveDate()));
						if (geoUnitName.getExpiredByDate() != null) {
							ps.setString(8, format.format(geoUnitName
									.getExpiredByDate()));
						} else {
							ps.setNull(8, java.sql.Types.DATE);
						}
						if (geoUnitName.getExpirationDate() != null) {
							ps.setString(9, format.format(geoUnitName
									.getExpirationDate()));
						} else {
							ps.setNull(9, java.sql.Types.DATE);
						}
						ps.setString(10,geoUnitName.getCreatedUser());
						ps.setString(11,geoUnitName.getModifiedUser());
					}

					public int getBatchSize() {
						return geoUnitNmeList.size();
					}
				});
		getJdbcTemplate().batchUpdate(geoUnitNmeIdDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						GeoUnitName geoUnitName = geoUnitNmeDeleteList.get(i);
						
						ps.setString(1,
								format.format(geoUnitName.getExpirationDate()));
						ps.setString(2,
								format.format(geoUnitName.getExpiredByDate()));  // Added Geo Bug Fix
						ps.setString(3,geoUnitName.getModifiedUser());
						ps.setLong(4,geoUnitName.getGeoUnitNameId());
					}

					public int getBatchSize() {
						return geoUnitNmeDeleteList.size();
					}
				});
		getJdbcTemplate().batchUpdate(geoUnitCodeInsertQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						GeoUnitCode geoUnitCode = geoUnitCodeList.get(i);
						if (geoUnitCode.getGeoUnitBulkId().startsWith("NRQ")) {
							ps.setLong(1, geoUnitCode.getGeoUnitId());
						} else {
							ps.setLong(1,
									new Long(geoUnitCode.getGeoUnitBulkId()));
						}
						ps.setLong(2, geoUnitCode.getGeoCodeTypeCode());
						ps.setString(3, geoUnitCode.getGeoCode());
						ps.setLong(4, geoUnitCode.getDataProviderCode());
						ps.setString(5,
								format.format(geoUnitCode.getEffectiveDate()));
						if (geoUnitCode.getExpiredByDate() != null) {
							ps.setString(6, format.format(geoUnitCode
									.getExpiredByDate()));
						} else {
							ps.setNull(6, java.sql.Types.DATE);
						}
						if (geoUnitCode.getExpirationDate() != null) {
							ps.setString(7, format.format(geoUnitCode
									.getExpirationDate()));
						} else {
							ps.setNull(7, java.sql.Types.DATE);
						}
						ps.setString(8,geoUnitCode.getCreatedUser());
						ps.setString(9,geoUnitCode.getModifiedUser());
					}

					public int getBatchSize() {
						return geoUnitCodeList.size();
					}
				});
		
		getJdbcTemplate().batchUpdate(geoUnitCodeIdDeleteQuery,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {

						GeoUnitCode geoUnitCode = geoUnitCodeDeleteList.get(i);
						
						ps.setString(1,
								format.format(geoUnitCode.getExpirationDate()));	
						ps.setString(2,
								format.format(geoUnitCode.getExpiredByDate()));   //  Added Geo Bug Fix
						ps.setString(3,geoUnitCode.getModifiedUser());
						ps.setLong(4,geoUnitCode.getGeoUnitCodeId());
					}

					public int getBatchSize() {
						return geoUnitCodeDeleteList.size();
					}
				});

	}

	@SuppressWarnings("rawtypes")
	@Override
	public List<CodeValue> getCodeValueList() {
		String getValidateGeoUnitTypCdQuery = geoPropertyFileVO.getValidateGeoUnitTypCdQuery();
		List<Map<String, Object>>  rows = getJdbcTemplate().queryForList(getValidateGeoUnitTypCdQuery);
		List<CodeValue> cdValList = new ArrayList<CodeValue>();
		for (Map row : rows) {
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((BigDecimal)row.get("cd_val_id")).longValue());
			codeValue.setCodeTableId(((BigDecimal)row.get("cd_tbl_id")).intValue());
			cdValList.add(codeValue);
		}
		return cdValList;
	}

	@Override
	public boolean isGeoUnitIdAvail(Long geoUnitId) {
		String geoUnitIdValidateQuery = geoPropertyFileVO.getValidateGeoUnitIdQuery();
		int count=getJdbcTemplate().queryForInt(geoUnitIdValidateQuery,geoUnitId);
		if(count==0){
			return false;
		}else{
			return true;
		}
	}
	@Override
	public boolean isGeoUnitNameIdAvail(Long geoUnitNameId) {
		String geoUnitNmeIdValidateQuery = geoPropertyFileVO.getValidateGeoNmeIdQuery();
		int count=getJdbcTemplate().queryForInt(geoUnitNmeIdValidateQuery,geoUnitNameId);
		if(count==0){
			return false;
		}else{
			return true;
		}
	}
	@SuppressWarnings("rawtypes")
	@Override
	public List<CodeValue> getCdValListForGeoNme() {
		String getValidateGeoNameTypCdQuery = geoPropertyFileVO.getValidateGeoNameTypCdQuery();
		List<Map<String, Object>>  rows = getJdbcTemplate().queryForList(getValidateGeoNameTypCdQuery);
		List<CodeValue> cdValList = new ArrayList<CodeValue>();
		for (Map row : rows) {
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((BigDecimal)row.get("cd_val_id")).longValue());
			codeValue.setCodeTableId(((BigDecimal)row.get("cd_tbl_id")).intValue());
			cdValList.add(codeValue);
		}
		return cdValList;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List<CodeValue> getCdValListForGeoCode() {
		String getValidateGeoCdTypCdQuery = geoPropertyFileVO.getValidateGeoCdTypCdQuery();
		List<Map<String, Object>>  rows = getJdbcTemplate().queryForList(getValidateGeoCdTypCdQuery);
		List<CodeValue> cdValList = new ArrayList<CodeValue>();
		for (Map row : rows) {
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((BigDecimal)row.get("cd_val_id")).longValue());
			codeValue.setCodeTableId(((BigDecimal)row.get("cd_tbl_id")).intValue());
			cdValList.add(codeValue);
		}
		return cdValList;
	}

	@Override
	public boolean isGeoUnitCodeIdAvail(Long geoUnitCodeId) {
		String getValidateGeoCodeIdQuery = geoPropertyFileVO.getValidateGeoCodeIdQuery();
		int count=getJdbcTemplate().queryForInt(getValidateGeoCodeIdQuery,geoUnitCodeId);
		if(count==0){
			return false;
		}else{
			return true;
		}
	}

	@Override
	public boolean isGeoUnitAssnIdAvail(Long geoUnitAssnId) {
		String getValidateGeoUnitAssnIdQuery = geoPropertyFileVO.getValidateGeoUnitAssnIdQuery();
		int count=getJdbcTemplate().queryForInt(getValidateGeoUnitAssnIdQuery,geoUnitAssnId);
		if(count==0){
			return false;
		}else{
			return true;
		}
	}
	@Override
	public Long generateGeoUnitId() {
		String generateGeoUnitIdQuery = geoPropertyFileVO.getGeoUnitIdSeqQuery();
		Long geoUnitId = getJdbcTemplate().queryForLong(generateGeoUnitIdQuery);
		return geoUnitId;
	}

}
