/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;
import com.dnb.dsc.refdata.core.vo.DNBUnusableGlsyBulkUploadMasterVO;
import com.dnb.dsc.refdata.core.vo.InfermentBulkUploadMasterVO;

/**
* DAO interface class for the Geo Bulk upload Batch operations.
* <p>
* 
* The DAO contacts the staging DB for all its operations.
* <p>
* 
* @author Cognizant
* @version last updated : May 28, 2012
* @see
* 
*/
public interface CtrlWrdsBulkUploadDAO {
	/**
	 * 
	 *  The method to save the inferment
	 *
	 * @param inferBlkUploadList
	 */
	public void saveInferment(List<? extends InfermentBulkUploadMasterVO> inferBlkUploadList,String userId);
	
	/**
	 * 
	 *  The method to save the phone area code
	 *
	 * @param phoneAreaCodeList
	 */
	public void savePhoneAreaCode(List<? extends PhoneAreaCode> phoneAreaCodeList,String userId);
	
	/**
	 * 
	 *  The method to save the unusable glossary
	 *
	 * @param dnbUnusableGlsyBlkUploadList
	 */	
	public void saveDnbUnusableGlsy(List<? extends DNBUnusableGlsyBulkUploadMasterVO> dnbUnusableGlsyBlkUploadList,String userId);
	
	public boolean isDnbUnsbleGlyIdAvail(Long dnbUnsGlyBulkId);	
	public boolean isAddrGeoUnitAvail(Long dnbUnsGlyBulkId);	
	public List<CodeValue> getCdValListFordnbGlyTypCd();
	public List<CodeValue> getCdValListForTypCd();
	public List<CodeValue> getValidateComMethdCdQuery();
	public List<CodeValue> getCdValListForLglFmInfmnt();
	public boolean isGeoUnitIdAvail(Long ctryGeoUnitId);
	public boolean isInfermentTextIdAvail(String infrmntTextBulkId);	
	public boolean  isInfrTxtCtryApyIdAvail(Long infrmntTextBulkId);
	public boolean isIndusCodeIdAvail(Long indusCodeId);
	public boolean isIndusCdInfmntIdAvail(Long indsCdInfId);
	public boolean isCntryGeoUnitIdAvail(Long cntryGeoUnitId);
	public boolean isTerrtoryGeoUnitIdAvail(Long terrtoryGeoUnitId);
	public Long generateInfrTxtId();
	public Long generateDnbUnusableGlsyId();
	

}
