/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.vo.CurrencyPropertyFileVO;
import com.dnb.dsc.refdata.dao.CrcyBatchDao;

/**
 * DAO implementation class for the Currency Exchange Batch operations.
 * <p>
 * 
 * The DAO contacts the staging DB for all its operations.
 * <p>
 * 
 * @author Cognizant
 * @version last updated : May 02, 2012
 * @see
 * 
 */
public class CrcyBatchDAOImpl extends JdbcDaoSupport implements CrcyBatchDao {

	/*@Autowired
	private JdbcTemplate jdbcTemplate;*/

	CurrencyPropertyFileVO currencyPropertyFileVO;

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CrcyBatchDAOImpl.class);

	/**
	 * 
	 * @param currencyPropertyFileVO
	 */
	public CrcyBatchDAOImpl(CurrencyPropertyFileVO currencyPropertyFileVO) {
		this.currencyPropertyFileVO = currencyPropertyFileVO;
	}

	/**
	 * 
	 *  The method to save the currency exchange bulk info
	 *
	 * @param currencyList
	 */
	@Override
	public void save(final List<? extends CurrencyExchange> currencyList,String userId) {
		String getinsertStmt = currencyPropertyFileVO.getInsertQuery();
		String updatestmt = currencyPropertyFileVO.getUpdateQuery();
		final List<CurrencyExchange> insertList=new ArrayList<CurrencyExchange>();
		final List<CurrencyExchange> updateList=new ArrayList<CurrencyExchange>();
		
		for(CurrencyExchange crcyExch:currencyList){
			if(crcyExch.getCurrencyExchangeId()==null){
				crcyExch.setCreatedUser(userId);
				crcyExch.setModifiedUser(userId);
				insertList.add(crcyExch);
			}
			else
			{
				crcyExch.setModifiedUser(userId);
				updateList.add(crcyExch);
			}
		}
		
		LOGGER.info("Inserting Records :");
		getJdbcTemplate().batchUpdate(getinsertStmt,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						CurrencyExchange currency = insertList.get(i);
						ps.setLong(1, currency.getFromCurrencyCode());
						ps.setLong(2, currency.getToCurrencyCode());
						ps.setDate(3, new Date(currency.getCurrencyExchangeDate().getTime()));
						ps.setLong(4,
								currency.getCurrencyExchangeDatePrcnCode());
						ps.setDouble(5, currency.getCurrencyExchangeRate());
						ps.setLong(6, currency.getDataProviderCode());
						ps.setString(7, currency.getCreatedUser());
						ps.setString(8, currency.getModifiedUser());
					}
					public int getBatchSize() {
						return insertList.size();
					}
				});
		
		LOGGER.info("updating Records :");
		getJdbcTemplate().batchUpdate(updatestmt,
				new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						
						CurrencyExchange currency = updateList.get(i);
						System.out.println(currency.getModifiedUser());
						ps.setLong(1, currency.getFromCurrencyCode());
						ps.setLong(2, currency.getToCurrencyCode());
						ps.setDate(3, new Date(currency.getCurrencyExchangeDate().getTime()));
						ps.setLong(4,
								currency.getCurrencyExchangeDatePrcnCode());
						ps.setDouble(5, currency.getCurrencyExchangeRate());
						ps.setLong(6, currency.getDataProviderCode());
						ps.setString(7, currency.getModifiedUser());
						ps.setLong(8, currency.getCurrencyExchangeId());
					}
					public int getBatchSize() {
						return updateList.size();
					}
				});
	}

	/**
	 * The method to update the currency exchange bulk info
	 * 
	 * @param currency
	 */
	public void update(CurrencyExchange currency) {

		LOGGER.info("updating Records :");
		String updatestmt = currencyPropertyFileVO.getUpdateQuery();

		getJdbcTemplate().update(
				updatestmt,
				new Object[] { currency.getFromCurrencyCode(),
						currency.getToCurrencyCode(),
						currency.getCurrencyExchangeDate(),
						currency.getCurrencyExchangeDatePrcnCode(),
						currency.getCurrencyExchangeRate(),
						currency.getDataProviderCode(),
						currency.getCurrencyExchangeId()});

	}

	@SuppressWarnings("rawtypes")
	@Override
	public List<CodeValue> getCodeValueList() {
		String getcdvalQuery = currencyPropertyFileVO.getCdvalQuery();
		List<Map<String, Object>>  rows = getJdbcTemplate().queryForList(getcdvalQuery);
		List<CodeValue> cdValList = new ArrayList<CodeValue>();
		for (Map row : rows) {
			CodeValue codeValue = new CodeValue();
			codeValue.setCodeValueId(((BigDecimal)row.get("cd_val_id")).longValue());
			codeValue.setCodeTableId(((BigDecimal)row.get("cd_tbl_id")).intValue());
			cdValList.add(codeValue);
		}
		System.out.println("Printing fetched Code values"+cdValList);
		return cdValList;

	}

	@Override
	public boolean isCrcyExchIdAvail(Long crcyExchId) {
		String getSelectQuery = currencyPropertyFileVO.getSelectQuery();
		int count = getJdbcTemplate().queryForInt(getSelectQuery,crcyExchId);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
		
	}

	@Override
	public boolean isDuplicateCrcy(Long fromCrcyCD, Long toCrcyCD,
			java.util.Date exchDate, Long prcnCode) {
		String getSelectUniqueQuery = currencyPropertyFileVO.getSelectUniqueQuery();
		int count = getJdbcTemplate().queryForInt(getSelectUniqueQuery,fromCrcyCD,toCrcyCD,exchDate,prcnCode);
		if(count==0){
			return false;
		}
		else{
			return true;
		}
	}
}
