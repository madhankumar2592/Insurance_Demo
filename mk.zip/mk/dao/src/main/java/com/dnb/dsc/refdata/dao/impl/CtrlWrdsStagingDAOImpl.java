/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.DnbUnusAdr;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsyCtryAppy;
import com.dnb.dsc.refdata.core.entity.DnbUnusIndNme;
import com.dnb.dsc.refdata.core.entity.DnbUnusTlcmAdr;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeInferment;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.InfermentTextCountryApplicability;
import com.dnb.dsc.refdata.core.entity.LegalFormInferment;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ControlWordsSearchVO;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.CtrlWrdsStagingDAO;

/**
 * This is used as the DAO implementation class for the Control Words operations.
 * The DAO contacts the staging DB for all its operations
 *
 * @author Cognizant
 * @version last updated : May 31, 2012
 * @see
 *
 */
@Repository("CtrlWrdsStagingDAO")
public class CtrlWrdsStagingDAOImpl implements CtrlWrdsStagingDAO {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CtrlWrdsStagingDAOImpl.class);
	
	/**
	 *
	 * The method will create the named query instance by setting the query
	 * parameters. The method is invoked for all name query operations.
	 *
	 * @param sql
	 * @param parameters
	 * @return
	 */
	private Query createNamedQuery(String sql, Map<String, Object> parameters) {
		Query query = em.createNamedQuery(sql);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}
	/**
	 * The query to retrieve all legal form class codes
	 */
	private static final String QUERY_RETRIEVE_LEGAL_FORM_CLASS_CODES = "LegalFormInferment.retrieveLegalFormClassCodeList";
	/**
	 * The query to retrieve all legal form class codes
	 */
	private static final String QUERY_RETRIEVE_LEGAL_FORM_CODES = "LegalFormInferment.retrieveLegalFormCodeList";
	/**
	 * The query to retrieve all legal form class codes
	 */
	private static final String QUERY_RETRIEVE_LEGAL_FORM_LANGUAGES = "InfermentText.retrieveLegalFormLanguages";
	/**
         * The query to retrieve all legal form class codes
	 */
	private static final String QUERY_RETRIEVE_LEGAL_FORM_COUNTRIES = "InfermentTextCountryApplicability.retrieveLegalFormCountries";
	/**
	 * The constants for query - retrieve inferment text search results :select country
	 */
	private static final String QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_SELECT_COUNTRY = "SELECT new InfermentText( ca.icountryGeoUnitId, (select gn.geoName from GeoUnitName gn where gn.geoUnitId = ca.icountryGeoUnitId and gn.languageCode = 39 and gn.nameTypeCode = 32), ";
	/**
	 * The constants for query - retrieve inferment text search results :select language
	 */
	private static final String QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_SELECT_LANGUAGE = "it.languageCode, (SELECT cvt.codeValueDescription from CodeValueText cvt where cvt.codeValueId = it.languageCode and cvt.languageCode = 39) , ";
	/**
	 * The constants for query - retrieve inferment text search results :select legal form code
	 */
	private static final String QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_SELECT_LEGAL_FORM_CODE = "li.legalFormCode, (select cvt.codeValueDescription from CodeValueText cvt where cvt.codeValueId = li.legalFormCode and cvt.languageCode = 39),";
	/**
	 * The constants for query - retrieve inferment text search results :select legal from class code
	 */
	private static final String QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_SELECT_LEGAL_FORM_CLASS_CODE = "li.legalFormClassCode, (select cvt.codeValueDescription from CodeValueText cvt where cvt.codeValueId = li.legalFormClassCode and cvt.languageCode = 39), ";
	/**
	 * The constants for query - retrieve inferment text search results :select inferment text
	 */
	private static final String QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_SELECT_INFERMENT_TEXT = "it.infermentTextId,it.infermentText,it.expirationDate) ";
	/**
	 * The constants for query - retrieve inferment text search results :select count
	 */
	private static final String QUERY_RETRIEVE_INFERMENT_TEXT_COUNT_SEARCH_SELECT = "SELECT count(it.infermentText)";
	
	private static final String QUERY_RETRIEVE_AREA_CODES = "PhoneAreaCode.retrieveAreaCode";
	
	private static final String QUERY_RETRIEVE_AREA_CODE_SERVICE_DESC = "PhoneAreaCode.retrieveAreaCodeServiceDesc";
	
    /**
     * the query to retrieve all the Industry Code type and description criteria
     */
    private static final String QUERY_RETRIEVE_CODE_VALUES_BY_TBLID = "IndustryCodeInferment.retrieveIndustryCodeTypeAndDesc";
    private static final String QUERY_RETRIEVE_LANG_CODE_FOR_INFERMENT = "IndustryCodeInferment.retrieveLanguageCode";
    private static final String QUERY_RETRIEVE_INDS_CODE_DESC_FOR_INFERMENT = "IndustryCode.retrieveIndustryCodeDescriptionByIndsCodeTypeCode";
    private static final String QUERY_RETRIEVE_INDS_INFERMENT_VIEW_BY_INFR_TXT = "IndustryCodeInferment.retrieveIndustryCodeInfermentView";
    
	
	/**
	 * The constants for query - retrieve inferment text results :from
	 */
	private static final String QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_FROM =" FROM InfermentText it, LegalFormInferment li, InfermentTextCountryApplicability ca where " +
			"it.infermentTextId=li.infermentTextId and it.infermentTextId= ca.infermentTextId ";
	
	/**
	 * Query to retrieve Code Value Text based on code value id.
	 */
	private static final String QUERY_RETRIEVE_INFERMENT_TEXT_BY_INFERMENT_TEXT_ID = "InfermentText.retrieveInfermentTextByInfermentTextId";

	/**
	 * The constants for named query - retrieve all control words
	 */
	private static final String QUERY_RETRIEVE_ALL_CONTROL_WORDS = "CodeValueText.retrieveAllControlWords";
	
	private static final String QUERY_RETRIEVE_CONTROL_WORDS_SELECT_CLAUSE = "SELECT new DnbUnusGlsy(d.dnbUnusGlsyId, " +
			"d.dnbUnusGlsyTypCd, d.dnbUnusTxt, d.alwdWthOthWdIndc, d.exctMtchIndc, d.expnDt, d.effvDt, " +
			"d.stopPrcsRecIndc, g.geoName ";
	private static final String QUERY_RETRIEVE_CONTROL_WORDS_FROM_CLAUSE = " FROM DnbUnusGlsy d, DnbUnusGlsyCtryAppy c, GeoUnitName g ";
	private static final String QUERY_RETRIEVE_CONTROL_WORDS_WHERE_CLAUSE = " WHERE d.dnbUnusGlsyId = c.dnbUnusGlsyId and" +
			"  d.dnbUnusGlsyTypCd = :dnbUnusGlsyTypCd and c.ctryGeoUnitId = g.geoUnitId and g.languageCode = :languageCode and " +
			"g.nameTypeCode = :nameTypeCode ";
	
	private static final String QUERY_RETRIEVE_CONTROL_WORD_BY_ID = "DnbUnusGlsy.retrieveDnbUnusGlsyById";
	private static final String QUERY_RETRIEVE_PHONE_AREA_CODE_BY_ID = "PhoneAreaCode.retrievePhoneAreaCodeById";
	
	/**
	 * The constants for named query - retrieve all area code countries
	 */
	private static final String QUERY_RETRIEVE_ALL_AREACODE_COUNTRIES_SELECT1 = "SELECT distinct new PhoneAreaCode(";
	
	/**
	 * The constants for named query - retrieve all area code countries join condition for select
	 */
	private static final String QUERY_RETRIEVE_ALL_AREACODE_COUNTRIES_SELECT_JOIN = "p.countryGeoUnitId, ";
	
	/**
	 * The constants for named query - retrieve all area code territory join condition for select
	 */
	private static final String QUERY_RETRIEVE_ALL_AREACODE_TERRITORY_SELECT_JOIN = "p.territoryGeoUnitId, ";
	
	/**
	 * The constants for named query - retrieve all area code countries select 2
	 */
	private static final String QUERY_RETRIEVE_ALL_AREACODE_COUNTRIES_SELECT2 = " n.geoName) FROM PhoneAreaCode p, " +
			"GeoUnit g, GeoUnitName n WHERE 1=1 and g.geoUnitId = n.geoUnitId and ";
	
	/**
	 * The constants for named query - retrieve all area code countries join condition 
	 */
	private static final String QUERY_RETRIEVE_ALL_AREACODE_COUNTRIES_CND_JOIN = "p.countryGeoUnitId = g.geoUnitId and ";
	
       private static final String QUERY_RETRIEVE_INDUSTRY_CODE_BY_ID = "IndustryCode.retrieveIndustryCodeByindsCodeId";
    
	/**
	 * The constants for named query - retrieve all area code countries join condition 
	 */
	private static final String QUERY_RETRIEVE_ALL_AREACODE_TERRITORY_CND_JOIN = "p.territoryGeoUnitId = g.geoUnitId and ";
	
	/**
	 * The constants for named query - retrieve all area code countries join condition 
	 */
	private static final String QUERY_RETRIEVE_ALL_AREACODE_CND_JOIN = "n.languageCode = 39 and n.nameTypeCode = 32";
	

	@PersistenceContext(unitName = "PU-Staging")
	private EntityManager em;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<DnbUnusGlsy> searchByOffensiveWord(ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | searchByOffensiveWord");
		try{
		return getControlWordQuery(controlWordsSearchVO,false).getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method to count the search results of control words
	 *
	 * @param controlWordsSearchVO
	 * @return
	 */
	@Override
	public Long countSearchControlWords(ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | searchByOffensiveWord");
		try{
		return (Long) getControlWordQuery(controlWordsSearchVO , true).getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * This method creates the control word query based on the values set
	 * in the searchCriteriaVO
	 * 
	 * @param controlWordsSearchVO
	 * @param isCountQuery
	 * @return
	 */
	private Query getControlWordQuery(ControlWordsSearchVO controlWordsSearchVO, Boolean isCountQuery){
		StringBuffer controlWordQuery = null;
		if(isCountQuery){
			controlWordQuery = new StringBuffer("SELECT count(d.dnbUnusGlsyId");
		}
		else {
			controlWordQuery = new StringBuffer(QUERY_RETRIEVE_CONTROL_WORDS_SELECT_CLAUSE);
		if(controlWordsSearchVO.getControlWordsTypeCode() == 24808L){
			controlWordQuery.append(" , i.frnm, i.midlNme, i.srnme, i.nmeSfxTxt ");
		}else if(controlWordsSearchVO.getControlWordsTypeCode() == 24802L){
			controlWordQuery.append(" , a.ln1Adr, a.ln2Adr, a.strNme, a.primTownNme ");
			controlWordQuery.append(" , a.cntyNme, a.terrNme, a.postCode ");
		}else if(controlWordsSearchVO.getControlWordsTypeCode() == 24806L){
			controlWordQuery.append(" , t.areaCodeNbr, t.tlcmExchCode, t.phonExtnNbr ");
		}else if(controlWordsSearchVO.getControlWordsTypeCode() == 24801L){
			controlWordQuery.append(" , p.areaCodeNumber, p.areaCodeServiceDescription ");
			controlWordQuery.append(" , p.countryGeoUnitId, (SELECT n.geoName from GeoUnitName n WHERE n.geoUnitId = p.countryGeoUnitId and ")
			.append("n.nameTypeCode = 32 and n.languageCode = 39 ) ,");
			controlWordQuery.append("p.territoryGeoUnitId ,").append(" (SELECT n.geoName from GeoUnitName n WHERE ")
				.append("n.geoUnitId = p.territoryGeoUnitId and n.nameTypeCode = 32 and n.languageCode = 39 ) ");
		}
		}
		controlWordQuery.append(")");
		controlWordQuery.append(QUERY_RETRIEVE_CONTROL_WORDS_FROM_CLAUSE);
		if(controlWordsSearchVO.getControlWordsTypeCode() == 24808L){
			controlWordQuery.append(" , DnbUnusIndNme i ");
		} else if(controlWordsSearchVO.getControlWordsTypeCode() == 24802L){
			controlWordQuery.append(" , DnbUnusAdr a ");
		} else if(controlWordsSearchVO.getControlWordsTypeCode() == 24806L){
			controlWordQuery.append(" , DnbUnusTlcmAdr t ");
		} else if(controlWordsSearchVO.getControlWordsTypeCode() == 24801L){
			controlWordQuery.append(" , PhoneAreaCode p ");
		}
		controlWordQuery.append(QUERY_RETRIEVE_CONTROL_WORDS_WHERE_CLAUSE);
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("languageCode",RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		parameters.put("nameTypeCode",RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL);
		parameters.put("dnbUnusGlsyTypCd",controlWordsSearchVO.getControlWordsTypeCode());
		if(controlWordsSearchVO.getControlWordsTypeCode() == 24808L){
			controlWordQuery.append(" and d.dnbUnusGlsyId = i.dnbUnusGlsyId ");
		} else if(controlWordsSearchVO.getControlWordsTypeCode() == 24802L){
			controlWordQuery.append(" and d.dnbUnusGlsyId = a.dnbUnusGlsyId ");
		} else if(controlWordsSearchVO.getControlWordsTypeCode() == 24806L){
			controlWordQuery.append(" and d.dnbUnusGlsyId = t.dnbUnusGlsyId ");
		} else if(controlWordsSearchVO.getControlWordsTypeCode() == 24801L){
			controlWordQuery.append(" and d.dnbUnusGlsyId = p.dnbUnusGlsyId ");
		}

		controlWordQuery.append(" and ((c.expnDt > sysdate ) or (c.expnDt is null)) ");
		if((controlWordsSearchVO.getCountryGeoUnitId() != null) && (controlWordsSearchVO.getCountryGeoUnitId() > 0)){
			controlWordQuery.append(" and c.ctryGeoUnitId = :ctryGeoUnitId ");
			parameters.put("ctryGeoUnitId",controlWordsSearchVO.getCountryGeoUnitId());
		}
		if((controlWordsSearchVO.getSearchText() != null) && (!controlWordsSearchVO.getSearchText().isEmpty())){
			controlWordQuery.append(" and upper(d.dnbUnusTxt) like concat('%', upper(:dnbUnusTxt),'%') ");
			parameters.put("dnbUnusTxt",controlWordsSearchVO.getSearchText());
		}
		if (controlWordsSearchVO.getIsActive()!= null & controlWordsSearchVO.getIsInactive()!= null){
		if(controlWordsSearchVO.getIsActive() && !controlWordsSearchVO.getIsInactive()){
			controlWordQuery.append(" and ((d.expnDt > sysdate ) or (d.expnDt is null) ) ");
		}
		if(controlWordsSearchVO.getIsInactive() && !controlWordsSearchVO.getIsActive()){
			controlWordQuery.append(" and d.expnDt < sysdate ");
		}
		}
		if(!isCountQuery){
			// setting the sort order
			controlWordQuery.append(" order by ");
			controlWordQuery.append(getControlWordsSortByColumnIndex(controlWordsSearchVO.getSortBy()));
			controlWordQuery.append(" ");
			controlWordQuery.append(controlWordsSearchVO.getSortOrder());
		}
		LOGGER.info("controlWordQuery : " + controlWordQuery.toString());
		Query query = em.createQuery(controlWordQuery.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		query.setMaxResults(controlWordsSearchVO.getMaxResults());
		 query.setFirstResult(controlWordsSearchVO.getRowIndex());
		return query;
	}
        /**
     * TODO
     * 
     * @return
     */
    @SuppressWarnings("unchecked")
    public List<IndustryCodeInferment> retrieveIndustryCodeTypeAndDesc(Integer codeTableId, Long languageCode) {
        LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveIndustryCodeTypeAndDesc");

        /*
         * Set the parameters for the named query to retrieve geo unit by name
         */

        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("langCode", languageCode);
        parameters.put("writingScriptCode", RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
        parameters.put("codeTableId", codeTableId);

        /*
         * Execute the query by setting the parameters
         */
        Query query = em.createNamedQuery(QUERY_RETRIEVE_CODE_VALUES_BY_TBLID);
        for (Entry<String, ?> parameter : parameters.entrySet()) {
            query.setParameter(parameter.getKey(), parameter.getValue());
        }

        LOGGER.info("exiting CtrlWrdsStagingDAOImpl | retrieveIndustryCodeTypeAndDesc");
        try{
        return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}

    }

    /**
     * The method will fetch the language code related to industry code inferment
     * 
     * @return
     */
    @SuppressWarnings("unchecked")
    public List<IndustryCodeInferment> retrieveLanguageCode() {
        LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveLanguageCode");

        /*
         * Execute the query by setting the parameters
         */
        Query query = em.createNamedQuery(QUERY_RETRIEVE_LANG_CODE_FOR_INFERMENT);

        LOGGER.info("exiting CtrlWrdsStagingDAOImpl | retrieveLanguageCode");
        try{
        return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}

    }
       
    @SuppressWarnings("unchecked")
    public List<IndustryCode> retrieveIndustryCodeDescription(Long industryCodeTypeCode){
        LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveIndustryCodeDescription");
        /*
         * Execute the query by setting the parameters
         */
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("industryCodeTypeCode", industryCodeTypeCode);
        parameters.put("languageCode", RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
        
        Query query = em.createNamedQuery(QUERY_RETRIEVE_INDS_CODE_DESC_FOR_INFERMENT);
        for (Entry<String, ?> parameter : parameters.entrySet()) {
            query.setParameter(parameter.getKey(), parameter.getValue());
        }
        
        LOGGER.info("exiting CtrlWrdsStagingDAOImpl | retrieveIndustryCodeDescription");
        try{
        return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
    }

    /**
     * The method will fetch the count of industry code inferment search data
     * 
     * @return
     */
    public Long countSearchIndustryCodesInferment(ControlWordsSearchVO industryCodesInfermentSearchCriteria) {
        LOGGER.info("entering CtrlWrdsStagingDAOImpl | countSearchIndustryCodesInferment");
        
        StringBuffer queryStr = new StringBuffer("select ");
        queryStr.append(" count(it.infermentText) ");
        
        Query query = formQueryForSearchIndustryCodesInferments(
				industryCodesInfermentSearchCriteria, queryStr.toString(),
				false);               
        
        LOGGER.info("exiting CtrlWrdsStagingDAOImpl | countSearchIndustryCodesInferment");
        try{
        return (Long) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
    }
    
    /**
     * The method will fetch the result of industry code inferment search 
     * 
     * @return
     */
    @SuppressWarnings("unchecked")
    public List<IndustryCodeInferment> searchIndustryCodesInferment(ControlWordsSearchVO industryCodesInfermentSearchCriteria){
        LOGGER.info("entering CtrlWrdsStagingDAOImpl | countSearchIndustryCodesInferment");
        
        StringBuffer queryStr = new StringBuffer("select distinct ");
        queryStr.append("new IndustryCodeInferment(");
        queryStr.append("(select gn.geoName from GeoUnitName gn where gn.geoUnitId=itca.icountryGeoUnitId and gn.languageCode=39 and gn.nameTypeCode=32),");
        queryStr.append("(select cvt.codeValueDescription from CodeValueText cvt where cvt.codeValueId=it.languageCode and cvt.languageCode=39),");
        queryStr.append("(select cvt.codeValueDescription from CodeValueText cvt where cvt.codeValueId=ic.industryCodeTypeCode and cvt.languageCode=39),");
        queryStr.append("(select icd.industryDescription from IndustryCodeDescription icd where icd.industryCodeId=ic.industryCodeId and icd.languageCode=39),");
        queryStr.append("ic.industryCode,");
        queryStr.append("it.infermentText,");
        queryStr.append("it.infermentTextId");
        queryStr.append(")");
        
		/*
		 * Execute the query by setting the parameters
		 */
		Query query = formQueryForSearchIndustryCodesInferments(
				industryCodesInfermentSearchCriteria, queryStr.toString(),
				false);
        try{        
        return query.getResultList();           
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
    }
    
	/**
	 * 
	 * The method will construct the query instance for the search Industry Codes Inferments
	 * functionality. The query string with the query parameters will be
	 * appended and the entity manager is invoked to form the query
	 *
	 * @param industryCodesInfermentSearchCriteria
	 * @param selectQuery
	 * @param isCountQuery
	 * @return query
	 */
	private Query formQueryForSearchIndustryCodesInferments(ControlWordsSearchVO industryCodesInfermentSearchCriteria, 
			String selectQuery, boolean isCountQuery) {        
        Map<String, Object> parameters = new HashMap<String, Object>();
        
        StringBuffer queryStr = new StringBuffer(selectQuery);
        
		queryStr.append(" from IndustryCode ic,IndustryCodeInferment ici,InfermentText it,InfermentTextCountryApplicability itca");
		queryStr.append(" where ic.industryCodeId = ici.industryCodeId and ici.infermentTextId=it.infermentTextId ");
		queryStr.append(" and it.infermentTextId = itca.infermentTextId ");
                      
        if(null != industryCodesInfermentSearchCriteria.getInfermentText() && industryCodesInfermentSearchCriteria.getInfermentText().length()>0 ){
            queryStr.append(" and upper(it.infermentText) like concat(upper(:infermentText), '%')");
            parameters.put("infermentText",
                industryCodesInfermentSearchCriteria.getInfermentText());
            
        }
        
        if(null != industryCodesInfermentSearchCriteria.getCountryGeoUnitId()){
            queryStr.append(" and upper(itca.icountryGeoUnitId) like concat(upper(:countryGeoUnitId), '%')");
            parameters.put("countryGeoUnitId",
                    String.valueOf(industryCodesInfermentSearchCriteria.getCountryGeoUnitId()));
            
        }
        if(null != industryCodesInfermentSearchCriteria.getIndustryCodeType() && industryCodesInfermentSearchCriteria.getIndustryCodeType().length()>0){
            queryStr.append(" and upper(ic.industryCodeTypeCode) like  concat(upper(:industryCodeTypeCode), '%')");
            parameters.put("industryCodeTypeCode",
                    String.valueOf(industryCodesInfermentSearchCriteria.getIndustryCodeType()));
            
        }
        
        if(null != industryCodesInfermentSearchCriteria.getIndustryCode() && industryCodesInfermentSearchCriteria.getIndustryCode().length()>0){
            queryStr.append(" and upper(ic.industryCode)  like concat(upper(:industryCode), '%')");
            parameters.put("industryCode",
                    String.valueOf(industryCodesInfermentSearchCriteria.getIndustryCode()));
            
        }
        
        if(null != industryCodesInfermentSearchCriteria.getLanguageCode() && industryCodesInfermentSearchCriteria.getLanguageCode()>0){
            queryStr.append(" and upper(it.languageCode) like concat(upper(:languageCode), '%')");
            parameters.put("languageCode",
                    Long.valueOf(industryCodesInfermentSearchCriteria.getLanguageCode()));            
        }
        
		/*
         * Execute the query by setting the parameters
         */
        Query query = em.createQuery(queryStr.toString());
        for (Entry<String, ?> parameter : parameters.entrySet()) {
            query.setParameter(parameter.getKey(), parameter.getValue());
        }
        query.setMaxResults(industryCodesInfermentSearchCriteria.getMaxResults());
        query.setFirstResult(industryCodesInfermentSearchCriteria.getRowIndex());
                
        return query;
	}
    
    /**
     * The method will fetch the inferment view details 
     * 
     * @return
     */
    public IndustryCodeInferment industryCodeInfermentSearchView(Long infermentText){
        
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("langCode", RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
        parameters.put("indsCodeDescriptionLanguage",RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
        parameters.put("indsTypeCodeLanguage", RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
        parameters.put("infermentText", infermentText);

        /*
         * Execute the query by setting the parameters
         */        
        Query query = em.createNamedQuery(QUERY_RETRIEVE_INDS_INFERMENT_VIEW_BY_INFR_TXT);
        for (Entry<String, ?> parameter : parameters.entrySet()) {
            query.setParameter(parameter.getKey(), parameter.getValue());
        }
        
        LOGGER.info("exiting CtrlWrdsStagingDAOImpl | industryCodeInfermentSearchView");
        try {
            IndustryCodeInferment infermentDetails = (IndustryCodeInferment) query.getSingleResult();
            LOGGER.info("infermentDeatil in dao is "+infermentDetails);
            return infermentDetails;
		}catch(NoResultException ex){
            return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
        }         
    }
    
   
    
    /**
	 * The method will retrieve all Legal Form Class Codes from the Search DB . The return
	 * type is a VO which contains the Legal Form Class Codes and the Code Value Descriptions.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueVO> retrieveLegalFormClassCodes(){
			LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveLegalFormClassCodes");
			
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("languageCode",RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			Query query =createNamedQuery(QUERY_RETRIEVE_LEGAL_FORM_CLASS_CODES,parameters);
			LOGGER.info("exiting CtrlWrdsStagingDAOImpl | retrieveLegalFormClassCodes");
			try{
			return mapCodeValueVOForLegalFormInferment((List<LegalFormInferment>)query.getResultList());
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			} 
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueText> retrieveAllControlWords() {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveAllControlWords");
		Query query = em.createNamedQuery(QUERY_RETRIEVE_ALL_CONTROL_WORDS);
		query.setParameter("languageCode", RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		try{
			return query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}

	@SuppressWarnings("unchecked")
	public List<String> retrieveAreaCodeInfo(){
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveAreaCodeInfo");
		List<String> result = new ArrayList<String>();
		Query query = em.createNamedQuery(QUERY_RETRIEVE_AREA_CODES);
		try{
		result.addAll(query.getResultList());
		result.add("#####");
		query = em.createNamedQuery(QUERY_RETRIEVE_AREA_CODE_SERVICE_DESC);
		result.addAll(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
		result.remove(null);
		return result;
	}

	/**
	 * The method to retrieve the control words by id
	 * 
	 * @param dnbUnusGlsyId
	 * @return DnbUnusGlsy
	 */
	@Override
	public DnbUnusGlsy retrieveControlWordById(Long dnbUnusGlsyId) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveControlWordById");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("dnbUnusGlsyId", dnbUnusGlsyId);

		Query query = em.createNamedQuery(QUERY_RETRIEVE_CONTROL_WORD_BY_ID);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		LOGGER.info("exiting CtrlWrdsStagingDAOImpl | retrieveControlWordById");
		try {
			return (DnbUnusGlsy) query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method to retrieve all applicable country codes for the Area Code Numbers
	 *
	 * @param geoUnitTypeCode
	 * @return codeValueVOs
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllAreaCodeGeoUnits(Long geoUnitTypeCode) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveAllAreaCodeCountries");	
		StringBuffer queryStr = new StringBuffer();
		
		queryStr.append(QUERY_RETRIEVE_ALL_AREACODE_COUNTRIES_SELECT1);
		
		if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY.equals(geoUnitTypeCode)) {
			queryStr.append(QUERY_RETRIEVE_ALL_AREACODE_COUNTRIES_SELECT_JOIN);
		} else if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_TERRITORY.equals(geoUnitTypeCode)) {
			queryStr.append(QUERY_RETRIEVE_ALL_AREACODE_TERRITORY_SELECT_JOIN);
		}
		
		queryStr.append(QUERY_RETRIEVE_ALL_AREACODE_COUNTRIES_SELECT2);
		
		if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY.equals(geoUnitTypeCode)) {
			queryStr.append(QUERY_RETRIEVE_ALL_AREACODE_COUNTRIES_CND_JOIN);
		} else if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_TERRITORY.equals(geoUnitTypeCode)) {
			queryStr.append(QUERY_RETRIEVE_ALL_AREACODE_TERRITORY_CND_JOIN);
		}
		
		queryStr.append(QUERY_RETRIEVE_ALL_AREACODE_CND_JOIN);
		
		Query query = em.createQuery(queryStr.toString());
		try{
		return mapEntityToCodeValueVO((List<PhoneAreaCode>)query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
	
	/**
	 * 
	 * The method to map the list of PhoneAreaCOde entity to the collection of CodeValueVO
	 *
	 * @param phoneAreaCodes
	 * @return codeValueVOs
	 */
	private List<CodeValueVO> mapEntityToCodeValueVO(List<PhoneAreaCode> phoneAreaCodes) {
		List<CodeValueVO> codeValueVOs = null;
		if(phoneAreaCodes != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for(PhoneAreaCode phoneAreaCode : phoneAreaCodes) {
				CodeValueVO codeValueVO = new CodeValueVO();
				codeValueVO.setCode(phoneAreaCode.getCountryGeoUnitId());
				codeValueVO.setValue(phoneAreaCode.getCountryGeoUnitOfficialName());
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("mapEntityToCodeValueVO | codeValueVOs " + codeValueVOs);
		return codeValueVOs;
	}
	
	/**
	 * 
	 * Performs a hierarchy search of Phone Area Code on the search db.
	 * <p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param controlWordsSearchVO
	 * @return list of PhoneAreaCode
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<PhoneAreaCode> searchAreaCodeNumbers(ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | searchAreaCodeNumbers");
		
		StringBuffer queryStr = new StringBuffer("SELECT distinct new PhoneAreaCode(");
		queryStr.append("p.phoneAreaCodeId, p.areaCodeNumber, p.areaCodeServiceDescription, p.territoryGeoUnitId, ")
				.append("p.countryGeoUnitId, (SELECT n.geoName from GeoUnitName n WHERE ")
				.append("n.geoUnitId = p.territoryGeoUnitId and n.nameTypeCode = 32 and n.languageCode = 39 ), ")
				.append("(SELECT n.geoName from GeoUnitName n WHERE n.geoUnitId = p.countryGeoUnitId and ")
				.append("n.nameTypeCode = 32 and n.languageCode = 39 ) ")
				.append(") FROM PhoneAreaCode p WHERE 1= 1 ");

		Query query = formQueryForSearchAreaCodes(controlWordsSearchVO, queryStr.toString(), false);
		// setting the page count and max results for pagination
		query.setMaxResults(controlWordsSearchVO.getMaxResults());
		query.setFirstResult(controlWordsSearchVO.getRowIndex());
		try{
			return (List<PhoneAreaCode>) query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
	
	/**
	 * 
	 * The method will count the records in the hierarchy search of control words on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param controlWordsSearchVO
	 * @return countResults
	 */
	@Override
	public Long countSearchAreaCodeNumbers(ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | controlWordsSearchVO");

		LOGGER.info("controlWordsSearchVO :: " + controlWordsSearchVO);
		StringBuffer queryStr = new StringBuffer("SELECT count(p.phoneAreaCodeId) FROM PhoneAreaCode p WHERE 1=1");

		Query query = formQueryForSearchAreaCodes(controlWordsSearchVO, queryStr.toString(), true);
		try{
			return (Long) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
	
	/**
	 * 
	 * The method will construct the query instance for the search currency
	 * exchange functionality. The query string with the query parameters will
	 * be appended and the entity manager is invoked to form the query
	 * 
	 * @param controlWordsSearchVO
	 * @param selectQuery
	 * @param isCountQuery
	 * @return
	 */
	private Query formQueryForSearchAreaCodes(ControlWordsSearchVO controlWordsSearchVO, String selectQuery, 
			boolean isCountQuery) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer();
		queryStr.append(selectQuery); 
		
		if (null != controlWordsSearchVO.getSearchText() && controlWordsSearchVO.getSearchText().length() > 0) {
			queryStr.append(" and upper(p.areaCodeNumber) like concat('%', upper(:areaCodeNumber), '%')");
			parameters.put("areaCodeNumber", controlWordsSearchVO.getSearchText());
		}
		if (null != controlWordsSearchVO.getCountryGeoUnitId() && controlWordsSearchVO.getCountryGeoUnitId() > 0) {
			queryStr.append(" and p.countryGeoUnitId = :countryGeoUnitId");
			parameters.put("countryGeoUnitId", controlWordsSearchVO.getCountryGeoUnitId());
		}
		if (null != controlWordsSearchVO.getTerritoryGeoUnitId() && 
				null != controlWordsSearchVO.getTerritoryGeoUnitId()) {
			queryStr.append(" and p.territoryGeoUnitId = :territoryGeoUnitId ");
			parameters.put("territoryGeoUnitId", controlWordsSearchVO.getTerritoryGeoUnitId());
		}
		/*
		 * If only count is required then no need for order by clause in the
		 * query. Checking for isCountQuery in the if condition
		 */
		if(! isCountQuery) {
			queryStr.append(" order by ");
			queryStr.append(getAreaCodeSortByColumnIndex(controlWordsSearchVO.getSortBy()));
			queryStr.append(" ");
			queryStr.append(controlWordsSearchVO.getSortOrder());
		}
		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		
		return query;
	}
	
	/**
	 * 
	 * The method to get the sort index
	 *
	 * @param sortBy
	 * @return
	 */
	private int getAreaCodeSortByColumnIndex(String sortBy) {
		if ("areaCodeNumber".equalsIgnoreCase(sortBy)) {
			return 2;
		} else if ("areaCodeServiceDescription".equalsIgnoreCase(sortBy)) {
			return 3;
		} else if ("countryGeoUnitOfficialName".equalsIgnoreCase(sortBy)) {
			return 7;
		} else if ("territoryGeoUnitOfficialName".equalsIgnoreCase(sortBy)) {
			return 6;
		} else {
			return 1;
		}
	}
	
	@Override
	public DnbUnusGlsy updateControlWord(DnbUnusGlsy dnbUnusGlsy){
		LOGGER.info("CtrlWrdsStagingDAOImpl - updateControlWord");
		try{
		return em.merge(dnbUnusGlsy);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
	
	@Override
	public DnbUnusGlsyCtryAppy updateDnbUnusGlsyCtryAppy(DnbUnusGlsyCtryAppy dnbUnusGlsyCtryAppy){
		LOGGER.info("CtrlWrdsStagingDAOImpl - updateDnbUnusGlsyCtryAppy");
		try{
		return em.merge(dnbUnusGlsyCtryAppy);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
	
	@Override
	public DnbUnusIndNme updateDnbUnusIndNme(DnbUnusIndNme dnbUnusIndNme){
		LOGGER.info("CtrlWrdsStagingDAOImpl - updateDnbUnusIndNme");
		try{
		return em.merge(dnbUnusIndNme);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
	
	@Override
	public DnbUnusAdr updateDnbUnusAdr(DnbUnusAdr dnbUnusAdr){
		LOGGER.info("CtrlWrdsStagingDAOImpl - updateDnbUnusAdr");
		try{
		return em.merge(dnbUnusAdr);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
	
	@Override
	public DnbUnusTlcmAdr updateDnbUnusTlcmAdr(DnbUnusTlcmAdr dnbUnusTlcmAdr){
		LOGGER.info("CtrlWrdsStagingDAOImpl - updateDnbUnusTlcmAdr");
		try{
		return em.merge(dnbUnusTlcmAdr);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
	
	@Override
	public PhoneAreaCode updatePhoneAreaCode(PhoneAreaCode phoneAreaCode){
		LOGGER.info("CtrlWrdsStagingDAOImpl - updatePhoneAreaCode");
		try{
		return em.merge(phoneAreaCode);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
        /**
	 * The method will retrieve all Legal Form Codes from the Search DB . The return
	 * type is a VO which contains the Legal Form Codes and the Code Value Descriptions.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueVO> retrieveLegalFormCodes(){
			LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveLegalFormCodes");
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("languageCode",RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			Query query =createNamedQuery(QUERY_RETRIEVE_LEGAL_FORM_CODES,parameters);
			LOGGER.info("exiting CtrlWrdsStagingDAOImpl | retrieveLegalFormCodes");
		try{
			return mapCodeValueVOForLegalFormInferment((List<LegalFormInferment>)query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
	
	/**
	 * The method will retrieve all Legal Form Class Codes from the Search DB . The return
	 * type is a VO which contains the Legal Form Class Codes and the Code Value Descriptions.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueVO> retrieveLegalFormLanguages(){
			LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveLegalFormLanguages");
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("languageCode",RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			parameters.put("infermentTypeCode",RefDataPropertiesConstants.CODE_INFERMENT_TYPE_LEGAL);
			Query query = createNamedQuery(QUERY_RETRIEVE_LEGAL_FORM_LANGUAGES,parameters);
			LOGGER.info("exiting CtrlWrdsStagingDAOImpl | retrieveLegalFormLanguages");
		try{
			return mapCodeValueVOForInfermentText((List<InfermentText>)query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
	/**
	 * The method will retrieve all Legal Form Countries from the Search DB . The return
	 * type is a VO which contains the Legal Form Country Codes and the Code Value Descriptions.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueVO> retrieveLegalFormCountries(){
			LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveLegalFormCountries");
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("languageCode",RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			parameters.put("nameTypeCode", RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL);
			Query query = createNamedQuery(QUERY_RETRIEVE_LEGAL_FORM_COUNTRIES,parameters);
			LOGGER.info("exiting CtrlWrdsStagingDAOImpl | retrieveLegalFormCountries");
		try{
			return mapCodeValueVOForInfermentTextCountryApplicability((List<InfermentTextCountryApplicability>)query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 			
	}
	/**
	 * 
	 * The method to convert the LegalFormInferment entity object to a value object.
	 *
	 * @param legalFormInferments
	 * @return
	 */
	private List<CodeValueVO> mapCodeValueVOForLegalFormInferment(List<LegalFormInferment> legalFormInferments) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | mapCodeValueVO ||legalFormInferments: "+legalFormInferments);
		List<CodeValueVO> codeValueVOs = null;
		if (legalFormInferments != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (LegalFormInferment legalFormInferment : legalFormInferments) {
				codeValueVOs.add(new CodeValueVO(
						Long.valueOf(legalFormInferment.getLegalFormClassCode()),
						legalFormInferment.getCodeValueDescription(), null));
			}
		}
		LOGGER.info("exiting CtrlWrdsStagingDAOImpl | mapCodeValueVO");
		return codeValueVOs;
	}
	/**
	 * 
	 * The method to convert the InfermentText entity object to a value object.
	 * 
	 * @param legalFormInferments
	 * @return
	 */
	private List<CodeValueVO> mapCodeValueVOForInfermentText(List<InfermentText> infermentTexts) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | mapCodeValueVOForInfermentText");
		List<CodeValueVO> codeValueVOs = null;
		if (infermentTexts != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (InfermentText infermentText : infermentTexts) {
				LOGGER.info("entering CtrlWrdsStagingDAOImpl | mapCodeValueVOForInfermentText || language:"+infermentText.getLanguageCode().getClass());
				CodeValueVO codeValueVO = new CodeValueVO(
						Long.valueOf(infermentText.getLanguageCode()),
						infermentText.getCodeValueDescription(), null);
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting CtrlWrdsStagingDAOImpl | mapCodeValueVOForInfermentText");
		return codeValueVOs;
	}
	/**
	 * 
	 * The method to convert the InfermentText entity object to a value object.
	 * 
	 * @param legalFormInferments
	 * @return
	 */
	private List<CodeValueVO> mapCodeValueVOForInfermentTextCountryApplicability(List<InfermentTextCountryApplicability> infermentTexts) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | mapCodeValueVO");
		List<CodeValueVO> codeValueVOs = null;
		if (infermentTexts != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (InfermentTextCountryApplicability infermentTextCountryApplicability : infermentTexts) {
				CodeValueVO codeValueVO = new CodeValueVO(
						Long.valueOf(infermentTextCountryApplicability.getIcountryGeoUnitId()),
						infermentTextCountryApplicability.getGeoName(), null);
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting CtrlWrdsStagingDAOImpl | mapCodeValueVO");
		return codeValueVOs;
	}
	/**
	 *
	 * The method will perform a hierarchy search of Inferment Text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return list of Inferment Text
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<InfermentText> searchLegalFormInfermentText(
			ControlWordsSearchVO ctrlWrdsSearchCriteria) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | searchInfermentText");
		LOGGER.info("\n\nctrlWrdsSearchCriteria :: " + ctrlWrdsSearchCriteria);		
		StringBuffer queryStr = new StringBuffer(QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_SELECT_COUNTRY);
		queryStr.append(QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_SELECT_LANGUAGE);
		queryStr.append(QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_SELECT_LEGAL_FORM_CODE);
		queryStr.append(QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_SELECT_LEGAL_FORM_CLASS_CODE);
		queryStr.append(QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_SELECT_INFERMENT_TEXT);		
		Query query = formQueryForSearchLegalFormInferment(ctrlWrdsSearchCriteria, queryStr.toString(), false);
		LOGGER.info("exiting GeoStagingDAOImpl | searchGeographies");
		try{
		return ((List<InfermentText>)query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		} 
	}
	/**
	 *
	 * The method will perform a hierarchy search of count of Inferment Text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return count of Inferment Text
	 */
	@Override
	public Long countSearchLegalFormInfermentText(
			ControlWordsSearchVO ctrlWrdsSearchCriteria) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | countSearchInfermentText");
		LOGGER.info("\n\nctrlWrdsSearchCriteria :: " + ctrlWrdsSearchCriteria);
		StringBuffer queryStr = new StringBuffer(QUERY_RETRIEVE_INFERMENT_TEXT_COUNT_SEARCH_SELECT);
		Query query = formQueryForSearchLegalFormInferment(ctrlWrdsSearchCriteria, queryStr.toString(), true);
		LOGGER.info("exiting CtrlWrdsStagingDAOImpl | countSearchInfermentText");
		try{
			return (Long) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	/**
	 * 
	 * The method will construct the query instance for the search Industry Codes Inferments
	 * functionality. The query string with the query parameters will be
	 * appended and the entity manager is invoked to form the query
	 *
	 * @param industryCodesInfermentSearchCriteria
	 * @param selectQuery
	 * @param isCountQuery
	 * @return query
	 */
	private Query formQueryForSearchLegalFormInferment(ControlWordsSearchVO ctrlWrdsSearchCriteria, 
			String selectQuery, boolean isCountQuery) { 
		LOGGER.info("\n\nctrlWrdsSearchCriteria :: " + ctrlWrdsSearchCriteria);

		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer(selectQuery);
		queryStr.append(QUERY_RETRIEVE_INFERMENT_TEXT_SEARCH_FROM);
		/*
		 * Include the where condition if at least one of the filter condition
		 * is not empty. append the where condition.
		 */		
		if (ctrlWrdsSearchCriteria.getInfermentText() != null
				&& ctrlWrdsSearchCriteria.getInfermentText().length() > 0) {
			queryStr.append("and upper(it.infermentText) like '%'|| upper(:infermentText)||'%'");
			parameters.put("infermentText",
					ctrlWrdsSearchCriteria.getInfermentText());
		}
		// if country drop down is selected
		if (ctrlWrdsSearchCriteria.getCountryGeoUnitId() != null
				&& ctrlWrdsSearchCriteria.getCountryGeoUnitId() > 0) {
			queryStr.append(" and ca.icountryGeoUnitId like concat(:countryGeoUnitId,'%') ");
			parameters.put("countryGeoUnitId",
					ctrlWrdsSearchCriteria.getCountryGeoUnitId());
		}
		// if Language drop down is selected
		if (ctrlWrdsSearchCriteria.getLanguageCode() != null
				&& ctrlWrdsSearchCriteria.getLanguageCode() > 0) {
			queryStr.append(" and it.languageCode = :languageCode  ");
			parameters.put("languageCode", Long.valueOf(ctrlWrdsSearchCriteria.getLanguageCode()));
		}
		// if legal form code is entered as a filter
		if (ctrlWrdsSearchCriteria.getLegalFormCode() != null
				&& ctrlWrdsSearchCriteria.getLegalFormCode() > 0) {
			queryStr.append(" and upper(li.legalFormCode) like concat(upper(:legalFormCode),'%') and li.infermentTextId=it.infermentTextId ");
			parameters.put("legalFormCode", ctrlWrdsSearchCriteria.getLegalFormCode());
		}
		// if LegalFormClassCode is entered as a filter
		if (ctrlWrdsSearchCriteria.getLegalFormClassCode()!= null
				&& ctrlWrdsSearchCriteria.getLegalFormClassCode() > 0) {
			queryStr.append(" and upper(li.legalFormClassCode) like concat(upper(:legalFormClassCode),'%') and li.infermentTextId=it.infermentTextId ");
			parameters.put("legalFormClassCode", ctrlWrdsSearchCriteria.getLegalFormClassCode());
		}
		
		if (ctrlWrdsSearchCriteria.getIsActive()!= null & ctrlWrdsSearchCriteria.getIsInactive()!= null){
			if(ctrlWrdsSearchCriteria.getIsActive() && !ctrlWrdsSearchCriteria.getIsInactive()){
				queryStr.append(" and ((it.expirationDate > sysdate ) or (it.expirationDate is null) ) ");
			}
			if(ctrlWrdsSearchCriteria.getIsInactive() && !ctrlWrdsSearchCriteria.getIsActive()){
				queryStr.append(" and it.expirationDate < sysdate ");
			}
		}
		/*
		 * If only count is required then no need for order by clause in the
		 * query. Checking for isCountQuery in the if condition
		 */
		if (!isCountQuery) {
			// setting the sort order
			queryStr.append(" order by ");
			queryStr.append(getInfermentTextSortByColumnIndex(ctrlWrdsSearchCriteria.getSortBy()));
			queryStr.append(" ");
			queryStr.append(ctrlWrdsSearchCriteria.getSortOrder());
		}
		
		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		query.setMaxResults(ctrlWrdsSearchCriteria.getMaxResults());
		 query.setFirstResult(ctrlWrdsSearchCriteria.getRowIndex());
		return query;
	}
	/**
	 * 
	 * The method to get the sort index
	 *
	 * @param sortBy
	 * @return
	 */
	private int getInfermentTextSortByColumnIndex(String sortBy) {
		if ("geoName".equalsIgnoreCase(sortBy)) {
			return 2;
		} else if ("languageDescription".equalsIgnoreCase(sortBy)) {
			return 4;
		} else if ("legalFormCodeValue".equalsIgnoreCase(sortBy)) {
			return 6;
		} else if ("legalFormClassCodeValue".equalsIgnoreCase(sortBy)) {
			return 8;
		} else if ("infermentText".equalsIgnoreCase(sortBy)) {
			return 10;
		} else if ("status".equalsIgnoreCase(sortBy)) {
			return 11;
		} else {
			return 2;
		}
	}
	/**
	 *
	 * Fetches the InfermentText entity by the key infermentTextId.
	 * <p>
	 * 
	 * @param infermentTextId
	 * @return InfermentText entity
	 */
	@Override
	public InfermentText retrieveInfermentTextByInfermentTextId(Long infermentTextId){
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrieveInfermentTextByInfermentTextId");

		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_INFERMENT_TEXT_BY_INFERMENT_TEXT_ID);
		query.setParameter("infermentTextId", Long.valueOf(infermentTextId));
        LOGGER.info("exiting CtrlWrdsStagingDAOImpl | retrieveInfermentTextByInfermentTextId");
        try {
			return (InfermentText)query.getSingleResult();
		} catch(NoResultException ex) {
			return null;
		} catch(PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
    }
        
    /**
     * TODO
     *
     * @param industryCodeId
     * @return
     */
	@SuppressWarnings("unchecked")
    public List<IndustryCode> retreiveIndustryCodeList(Long industryCodeId){        
	LOGGER.info("entering CtrlWrdsStagingDAOImpl | retreiveIndustryCodeList");
        List<IndustryCode> industryCodeList  =null;
		if (industryCodeId != 0L) {
			Query queryTofetchIndustryCode = em.createNamedQuery(QUERY_RETRIEVE_INDUSTRY_CODE_BY_ID);
			queryTofetchIndustryCode.setParameter("languageCode", RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			queryTofetchIndustryCode.setParameter("industryCodeId", industryCodeId);
			try {
				industryCodeList = queryTofetchIndustryCode.getResultList();
			} catch (PersistenceException ex) {
				throw new ReferenceDataExceptionVO(
						RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			} catch (Exception ex) {
				throw new ReferenceDataExceptionVO(
						RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		}
        LOGGER.info("exiting CtrlWrdsStagingDAOImpl | retreiveIndustryCodeList");
        return industryCodeList;      
	}
    
	/**
	 * The method will persist the existing InfermentText data in the
	 * Staging DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param infermentText
	 */
	@Override
	public InfermentText saveApprovedInfermentText(InfermentText infermentText){
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | saveApprovedInfermentText ||infermentText:" +infermentText);
		try{
		return em.merge(infermentText);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public PhoneAreaCode retrievePhoneAreaCodeById(Long phoneAreaCodeId) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | retrievePhoneAreaCodeById");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("phoneAreaCodeId", phoneAreaCodeId);
		Query query = em.createNamedQuery(QUERY_RETRIEVE_PHONE_AREA_CODE_BY_ID);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		LOGGER.info("exiting CtrlWrdsStagingDAOImpl | retrievePhoneAreaCodeById");
		try {
			return (PhoneAreaCode) query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * 
	 * The method to get the sort index of Control Words search
	 * based on the type code
	 *
	 * @param sortBy
	 * @return
	 */
	private int getControlWordsSortByColumnIndex(String sortBy) {
		if ("officialGeoName".equalsIgnoreCase(sortBy)) {
			return 9;
		} else if ("dnbUnusTxt".equalsIgnoreCase(sortBy)) {
			return 3;
		} else if ("alwdWthOthWdIndc".equalsIgnoreCase(sortBy)) {
			return 4;
		} else if ("exctMtchIndc".equalsIgnoreCase(sortBy)) {
			return 5;
		} else if ("status".equalsIgnoreCase(sortBy)) {
			return 6;
		}else if ("stopPrcsRecIndc".equalsIgnoreCase(sortBy)) {
			return 8;
		} else if ("areaCodeNumber".equalsIgnoreCase(sortBy)
				||"ln1Adr".equalsIgnoreCase(sortBy)
				||"areaCodeNbr".equalsIgnoreCase(sortBy)
				||"frnm".equalsIgnoreCase(sortBy)) {
			return 10;
		}else if ("areaCodeServiceDescription".equalsIgnoreCase(sortBy)
				||"ln2Adr".equalsIgnoreCase(sortBy)
				||"tlcmExchCode".equalsIgnoreCase(sortBy)
				||"midlNme".equalsIgnoreCase(sortBy)) {
			return 11;
		} else if ("countryGeoUnitOfficialName".equalsIgnoreCase(sortBy)
				||"strNme".equalsIgnoreCase(sortBy)
				||"phonExtnNbr".equalsIgnoreCase(sortBy)
				||"srnme".equalsIgnoreCase(sortBy)) {
			return 12;
		} else if ("territoryGeoUnitOfficialName".equalsIgnoreCase(sortBy)
				||"primTownNme".equalsIgnoreCase(sortBy)
				||"nmeSfxTxt".equalsIgnoreCase(sortBy)) {
			return 13;
		} else if ("cntyNme".equalsIgnoreCase(sortBy)) {
			return 14;
		} else if ("terrNme".equalsIgnoreCase(sortBy)) {
			return 15;
		} else if ("postCode".equalsIgnoreCase(sortBy)) {
			return 16;
		} else {
			return 9;
		}
	}
}
