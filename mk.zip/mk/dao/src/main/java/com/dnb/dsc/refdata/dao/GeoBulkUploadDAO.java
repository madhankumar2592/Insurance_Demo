/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.vo.GeoBulkUploadMasterVO;

/**
* DAO interface class for the Geo Bulk upload Batch operations.
* <p>
* 
* The DAO contacts the staging DB for all its operations.
* <p>
* 
* @author Cognizant
* @version last updated : May 28, 2012
* @see
* 
*/
public interface GeoBulkUploadDAO {
	/**
	 * 
	 *  The method to save the geo assn
	 *
	 * @param mapList
	 */
	public void save(List<? extends GeoUnitAssociation> geoAssnBulkuploadList,String userId);
	
	/**
	 * 
	 *  The method to save the geo code
	 *
	 * @param geoBulkUploadList
	 */
	public void saveGeoCode(List<? extends GeoBulkUploadMasterVO> geoBulkUploadList,String userId);
	
	/**
	 * The method to get code value list
	 * 
	 * 
	 */
	public List<CodeValue> getCodeValueList();
	
	/**
	 * The method to check geo unit id
	 * 
	 * 
	 */
	public boolean isGeoUnitIdAvail(Long geoUnitId);
	
	public boolean isGeoUnitNameIdAvail(Long geoUnitNameId);
	public boolean isGeoUnitCodeIdAvail(Long geoUnitCodeId);
	public boolean isGeoUnitAssnIdAvail(Long geoUnitAssnId);
	public List<CodeValue> getCdValListForGeoNme();
	public List<CodeValue> getCdValListForGeoCode();
	public Long generateGeoUnitId();

}
