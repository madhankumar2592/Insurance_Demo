/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;

/**
 * This is used as the DAO interface for the Industry Code operations
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 *
 */
public interface IndsTransactionalDAO {

	/**
	 * This method will update given IndustryCode to Transaction DB. The return would be
	 * updated IndustryCode entity
	 *
	 * @param IndustryCode
	 * @return IndustryCode
	 */
	IndustryCode updateIndustryCode(IndustryCode industryCode);

	/**
	 * This method updates counts the IndustryCode entity in the transaction DB
	 *
	 * @param industryCodeId
	 * @return count
	 */
	String countIndustryCode(Long industryCodeId);

	/**
	 * This method returns the maximum value of industry code id. It does so by
	 * selecting the next value from a sequence
	 */
	Long retrieveMaxIndustryCodeId();

	/**
	 * The method will search the Transaction SoR for the IndustryCode based on the
	 * industryCodeId and will return the IndustryCode entity.
	 *
	 * @param industryCodeId
	 */
	IndustryCode retrieveIndustryCodeByIndustryCodeId(Long industryCodeId);

	/**
	 * The method will remove the industryCode data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param industryCodeId
	 * @param boolean indicating the status
	 */
	void removeApprovedIndustryCode(Long industryCodeId);
	
	/**
	 * This method will update given UiBulkDownload to Transaction DB. The return would be
	 * updated UiBulkDownload entity
	 *
	 * @param UiBulkDownload
	 * @return UiBulkDownload
	 */
    Long addUIBulkDownload(UiBulkDownload uiBulkDownload);
    
    /**
	 * The method will search the Transaction SoR for the UiBulkDownload based on the
	 * userId and will return the UiBulkDownload entity.
	 *
	 * @param userId
	 */
    List<UiBulkDownload> retrieveUIBulkDownload(String userId);
    /**
     * 
     * The method to persist the saved record entity.
     *
     * @param savedRecord
     * @return savedRecordId
     */
    Long insertSavedRecord(SavedRecord savedRecord);
    
    /**
     * 
     * The method to retrieve the count of savedRecord from the domain identifier.
     *
     * @param domainId
     * @return count of savedRecord
     */
    String countSavedRecord(Long domainId);
    
    /**
     * 
     * The method to retrieve the remove savedRecord by the domain identifier.
     *
     * @param domainId
     * @return count of savedRecord
     */
    void removeSavedRecord(Long domainId);
    
	/**
	 * 
	 * The method to retrieve the savedRecords based on domainName and domain
	 * Identifier
	 * 
	 * @param userId
	 * @param domainName
	 * @param domainId
	 * @return savedRecords
	 */
    List<SavedRecord> retrieveSavedRecords(String userId, String domainName, Long domainId, String userComment);
}
