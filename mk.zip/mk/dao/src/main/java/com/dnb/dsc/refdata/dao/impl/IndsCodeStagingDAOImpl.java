/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.InduscodeMappingBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.IndustryCodesSearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.IndsCodeStagingDAO;

/**
 * DAO implementation class for the Industry Code operations.
 * <p>
 *
 * The DAO contacts the staging DB for all its operations.
 * <p>
 *
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 *
 */
@Repository("IndsCodeStagingDAO")
public class IndsCodeStagingDAOImpl implements IndsCodeStagingDAO {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(IndsCodeStagingDAOImpl.class);

	@PersistenceContext(unitName = "PU-Staging")
	private EntityManager em;

	/**
	 * The constants for named query - retrieve CrossWalks for the Inds Code
	 */
	private static final String QUERY_RETRIEVE_CROSSWALK_FOR_INDS_CODE_TYPE_CODE = "IndustryCode.	";

	/**
	 * The constants for named query - retrieve IndustryCode by industryCodeId
	 */
	private static final String QUERY_RETRIEVE_INDUSTRYCODE_BY_ID = "IndustryCode.retrieveIndustryCodeByIndustryCodeId";

	/**
	 * The constants for named query - retrieve CrossWalks for the Inds Code
	 * Type Code
	 */
	private static final String QUERY_RETRIEVE_GROUPLVL_FOR_INDS_CODE_TYPE_CODE = "IndustryCode.retrieveGroupLevelsForIndsCodeTypeCode";

	private static final String QUERY_RETRIEVE_GROUPLVL_FOR_INDS_CODE_TYPE_CODE_AND_LANGUAGE_CODE = "IndustryCode.retrieveGroupLevelsForIndsCodeTypeCodeAndLanguageCode";

	/**
	 * Query to retrieve industryCode and description based on industryCodeTypeCode.
	 */
	private static final String QUERY_RETRIEVE_DESCRIPTION_FOR_CODE_TYPE_CODE = "IndustryCode.retrieveDescriptionForIndsCodeTypeCode";

	private static final String QUERY_RETRIEVE_INDS_ID_FOR_CODE_TYPE_CODE = "IndustryCode.retrieveIndsIdForIndsCodeTypeCode";

	/**
	 * The constants for named query - retrieve CrossWalks for the Inds Code
	 * Type Code
	 */
	private static final String QUERY_RETRIEVE_LANGUAGE_FOR_INDS_CODE_TYPE_CODE = "SELECT distinct new IndustryCode(id.languageCode, " +
			"(SELECT cvt.codeValueDescription from CodeValueText cvt where cvt.languageCode = :enLangCode and cvt.codeValueId = id.languageCode) ) " +
			"FROM IndustryCodeDescription id, IndustryCode ic where id.industryCodeId = ic.industryCodeId and ic.industryCodeTypeCode = :indsCodeTypeCode ";

	/**
	 * The constants for named query - retrieve CrossWalks for the Inds Code
	 * Type Code
	 */
	private static final String QUERY_RETRIEVE_LANGUAGE_FOR_INDS_CODE_TYPE_CODE_GRPCND = " and ic.industryCodeGroupLvelCode in (:groupLevelCodes)";

	/**
	 * The constants for named query - delete industry code by id
	 */
	private static final String QUERY_REMOVE_INDUSTRYCODE_BY_ID = "IndustryCode.removeIndustryCodeById";
	
	/**
	 * The constants for named query - delete industry code by id
	 */
	private static final String QUERY_REMOVE_INDUSTRY_CODE_DESCRIPTION_BY_ID = "IndustryCodeDescription.removeIndustryCodeDescriptionByIndustryCodeId";
	
	/**
	 * The constants for named query - delete industry code by id
	 */
	private static final String QUERY_REMOVE_INDUSTRY_CODE_FROM_MAPPING_BY_ID = "IndustryCodeMap.removeIndustryCodeMapByIndustryCodeId";
	
	/**
	 * The constants for named query - delete industry code by id
	 */
	private static final String QUERY_REMOVE_INDUSTRY_CODE_TO_MAPPING_BY_ID = "IndustryCodeMap.removeIndustryCodeToMapByIndustryCodeId";
	
	/**
	 * The constants for named query - delete industry code by description id
	 */
	private static final String QUERY_REMOVE_INDUSTRY_CODE_DESCRIPTION_BY_DESCID = "IndustryCodeDescription.removeByIndustryCodeDescriptionId";
	
	/**
	 * The constants for named query - delete industry code map
	 */
	private static final String QUERY_REMOVE_INDUSTRY_CODE_MAP_BY_PK = "IndustryCodeMap.removeByFromAndToIndsCodeId";
	
	/**
	 * The constants for named query - delete industry code map
	 */
	private static final String QUERY_COUNT_INDUSTRY_CODE_DESCRIPTION_FOR_DUPLICATE = "IndustryCode.countIndustryCodeDescriptionForDuplicate";
	
	/**
	 * Query to retrieve crosswalk details 
	 */
	private static final String QUERY_RETRIEVE_CROSSWALK_DETAILS = "select ic.industryCodeTypeCode,cvt.codeValueDescription,ic1.industryCodeTypeCode,cvt1.codeValueDescription,count(icm.industryCodeMapPK.fromIndustryCodeId) from "
			+ "IndustryCodeMap icm,IndustryCode ic,IndustryCode ic1,CodeValueText cvt,CodeValueText cvt1 where "
			+ "ic.industryCodeId = icm.industryCodeMapPK.fromIndustryCodeId and ic1.industryCodeId=icm.industryCodeMapPK.toIndustryCodeId "
			+ "and ic.industryCodeTypeCode = cvt.codeValueId and cvt.languageCode=39 and cvt.expirationDate is null "
			+ "and ic1.industryCodeTypeCode = cvt1.codeValueId and cvt1.languageCode=39 and cvt1.expirationDate is null "
			+ "group by ic.industryCodeTypeCode,cvt.codeValueDescription,ic1.industryCodeTypeCode,cvt1.codeValueDescription order by cvt.codeValueDescription,cvt1.codeValueDescription";
	
	/**
	 * The setter method for the entity manager. The persistence context has
	 * been defined as part of the entity manager definition.
	 *
	 * @param em
	 */
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}

	/**
	 *
	 * Performs a hierarchy search of Industry Codes on the search db.
	 * <p>
	 *
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 *
	 * @param industryCodesSearchCriteria
	 * @return list of IndustryCode
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<IndustryCode> searchIndustryCodes(
			IndustryCodesSearchCriteriaVO industryCodesSearchCriteria) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | searchIndustryCodes");
		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer("SELECT DISTINCT ");

		if (null != industryCodesSearchCriteria.getIndustryCodeCrosswalk()
				&& industryCodesSearchCriteria.getIndustryCodeCrosswalk()
						.length() > 0) {
			queryStr.append(
					"new IndustryCode(icm.industryCodeMapPK.fromIndustryCodeId, ic1.industryCode, ")
					.append("d1.industryDescription, d1.descriptionLengthCode,t1.codeValueDescription, ")
					.append("icm.industryCodeMapPK.toIndustryCodeId, ic2.industryCode, ")
					.append("d2.industryDescription, d2.descriptionLengthCode,t2.codeValueDescription, ")
					.append("icm.preferredMapIndicator, ic1.industryCodeTypeCode, ic2.industryCodeTypeCode) ")
					.append("FROM IndustryCode ic1, IndustryCode ic2, IndustryCodeMap icm ")
					.append(",IndustryCodeDescription d1, IndustryCodeDescription d2,CodeValueText t1, CodeValueText t2 ")
					.append("WHERE icm.industryCodeMapPK.fromIndustryCodeId = ic1.industryCodeId ")
					.append("and icm.industryCodeMapPK.toIndustryCodeId = ic2.industryCodeId ")
					.append("and d1.industryCodeId = icm.industryCodeMapPK.fromIndustryCodeId ")
					.append("and d1.descriptionLengthCode = t1.codeValueId ")
					.append("and d2.descriptionLengthCode = t2.codeValueId ")
					.append("and d1.languageCode = :codeLangCode ")
					.append("and d1.writingScriptCode = :writingScriptCode ")
					.append("and d2.industryCodeId = icm.industryCodeMapPK.toIndustryCodeId ")
					.append("and d2.languageCode = :crossWalkLangCode ")
					.append("and d2.writingScriptCode = :writingScriptCode ")
					.append("and ic1.industryCodeTypeCode = :industryCodeTypeCode ")
					.append("and ic2.industryCodeTypeCode = :industryCodeCrosswalk ")
					.append("and t1.languageCode = :enLangCode ")					
					.append("and t2.languageCode = :enLangCode ")
					.append("and t1.expirationDate is null ")	//	Added for IC UI Duplicate issue
					.append("and t2.expirationDate is null ");	//	Added for IC UI Duplicate issue
			parameters.put("writingScriptCode",
					RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
			parameters.put("industryCodeTypeCode", Long.valueOf(industryCodesSearchCriteria
							.getIndustryCodeTypeCode()));
			parameters.put("industryCodeCrosswalk", Long.valueOf(industryCodesSearchCriteria
							.getIndustryCodeCrosswalk()));
			parameters.put("codeLangCode",
					industryCodesSearchCriteria.getIndustryCodeLanguageCode() != null ?
							industryCodesSearchCriteria.getIndustryCodeLanguageCode() :
								RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			parameters.put("crossWalkLangCode",
					industryCodesSearchCriteria.getIndustryCrossWalkLanguageCode() != null ?
							industryCodesSearchCriteria.getIndustryCrossWalkLanguageCode() :
								RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			
			parameters.put("enLangCode",
					RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

			if (null != industryCodesSearchCriteria.getIndustryCode()
					||(null != industryCodesSearchCriteria.getIndustryCodeDescription()
					&& industryCodesSearchCriteria.getIndustryCodeDescription().length() > 0)) {

				queryStr.append(" and ( upper(ic1.industryCode) like concat(upper(:industryCode), '%') ");
				parameters.put("industryCode", String.valueOf(
						industryCodesSearchCriteria.getIndustryCode()));

				queryStr.append(" or upper(d1.industryDescription) like concat('%',upper(:industryDescription),'%'))");
				parameters.put("industryDescription",
						industryCodesSearchCriteria.getIndustryCodeDescription());
			}
			// adding the group level filter
			if(industryCodesSearchCriteria.getIndustryGroupLevelCodes() != null) {
				queryStr.append(" and ic1.industryCodeGroupLvelCode in (:groupLvelCodes)");
				parameters.put("groupLvelCodes",
						industryCodesSearchCriteria.getIndustryGroupLevelCodes());
			}
		} else { 
			queryStr.append(
					"new IndustryCode(ic.industryCodeId, ic.industryCode,ic.industryCodeGroupLvelCode,icd.industryDescription, icd.languageCode, ")
					.append("t1.codeValueDescription, ic.industryCodeTypeCode, t2.codeValueDescription, icd.descriptionLengthCode,t3.codeValueDescription) ")
					.append("FROM IndustryCode ic, IndustryCodeDescription icd, CodeValueText t1, CodeValueText t2,CodeValueText t3")
					.append(" WHERE ic.industryCodeId = icd.industryCodeId")
					.append(" AND icd.languageCode = t1.codeValueId")
					.append(" AND ic.industryCodeTypeCode = t2.codeValueId")
					.append(" and t1.languageCode = :enLangCode")
					.append(" and t2.languageCode = :enLangCode")
					.append(" and t3.languageCode = :enLangCode")
					.append(" and icd.writingScriptCode = :writingScriptCode")
					.append(" and ic.industryCodeTypeCode = :industryCodeTypeCode")
					.append(" and t1.expirationDate is null ")    //	Added for IC UI Duplicate issue
					.append(" and t2.expirationDate is null ")    //	Added for IC UI Duplicate issue
					.append(" and t3.expirationDate is null ")    //	Added for IC UI Duplicate issue
					.append(" and icd.descriptionLengthCode = t3.codeValueId");
			parameters.put("enLangCode",
					RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			parameters.put("writingScriptCode",
					RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
			parameters.put("industryCodeTypeCode", Long
					.valueOf(industryCodesSearchCriteria.getIndustryCodeTypeCode()));

			if (null != industryCodesSearchCriteria.getIndustryCode()
					||(null != industryCodesSearchCriteria.getIndustryCodeDescription()
					&& industryCodesSearchCriteria.getIndustryCodeDescription().length() > 0)) {

				queryStr.append(" and ( upper(ic.industryCode) like concat(upper(:industryCode), '%') ");
				parameters.put("industryCode", String
						.valueOf(industryCodesSearchCriteria.getIndustryCode()));

				queryStr.append(" or upper(icd.industryDescription) like concat('%',upper(:industryDescription),'%') ) ");
				parameters.put("industryDescription",
						industryCodesSearchCriteria
								.getIndustryCodeDescription());
			}
			// adding the group level filter
			if(industryCodesSearchCriteria.getIndustryGroupLevelCodes() != null) {
				queryStr.append(" and ic.industryCodeGroupLvelCode in (:groupLvelCodes)");
				parameters.put("groupLvelCodes",
						industryCodesSearchCriteria.getIndustryGroupLevelCodes());
			}
			// language filter
			if(industryCodesSearchCriteria.getIndustryCodeLanguageCode() != null) {
				queryStr.append(" and icd.languageCode = :codeTableLangCode");
				parameters.put("codeTableLangCode",
						industryCodesSearchCriteria.getIndustryCodeLanguageCode());
			}
		}

		queryStr.append(" order by ");
		queryStr.append(getIndustrySortByColumnIndex(industryCodesSearchCriteria
				.getSortBy()));
		queryStr.append(" ");
		queryStr.append(industryCodesSearchCriteria.getSortOrder());

		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		if (industryCodesSearchCriteria.getViewType() == null) {
			query.setMaxResults(industryCodesSearchCriteria.getMaxResults());
			query.setFirstResult(industryCodesSearchCriteria.getRowIndex());
		}
		try {
			return (List<IndustryCode>) query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method to get the sort index
	 *
	 * @param sortBy
	 * @return
	 */
	private int getIndustrySortByColumnIndex(String sortBy) {
		if ("industryCode".equalsIgnoreCase(sortBy)) {
			return 2;
		} else if ("industryCodeDescription".equalsIgnoreCase(sortBy)) {
			return 3;
		} else if ("crosswalkIndustryCode".equalsIgnoreCase(sortBy)) {
			return 5;
		} else if ("crosswalkIndustryDescription".equalsIgnoreCase(sortBy)) {
			return 6;
		} else if ("languageCode".equalsIgnoreCase(sortBy)) {
			return 4;
		} else if ("preferredMapIndicator".equalsIgnoreCase(sortBy)) {
			return 7;
		} else {
			return 2;
		}
	}

	/**
	 * The method will retrieve Industry code CrossWalks for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 *
	 * @param industryCodeTypeCode
	 * @return list of codeValueVO
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueVO> retrieveCrossWalksForIndsCodeType(
			Long industryCodeTypeCode) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | retrieveCrossWalksForIndsCodeType");

		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_CROSSWALK_FOR_INDS_CODE_TYPE_CODE);
		query.setParameter("indsCodeTypeCode", industryCodeTypeCode);
		query.setParameter("enLangCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		LOGGER.info("exiting IndsCodeStagingDAOImpl | retrieveCrossWalksForIndsCodeType");
		try{
		return mapCodeValueVO(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method to convert the Industry Code entity object to a value object.
	 *
	 * @param industryCodes
	 * @return codeValueVOs
	 */
	private List<CodeValueVO> mapCodeValueVO(List<IndustryCode> industryCodes) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | mapCodeValueVO");
		List<CodeValueVO> codeValueVOs = null;

		if (industryCodes != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (IndustryCode industryCode : industryCodes) {
				CodeValueVO codeValueVO = new CodeValueVO(
						industryCode.getIndustryCodeTypeCode(),
						industryCode.getIndustryCrosswalkDescription(),
						industryCode.getIndustryCrosswalkDescription());
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting IndsCodeStagingDAOImpl | mapCodeValueVO");
		return codeValueVOs;
	}

	/**
	 *
	 * The method will count the number of records returned by the query
	 *
	 * @param searchCriteriaVO
	 * @return list of geographies
	 */
	@Override
	public Long countSearchIndustryCodes(
			IndustryCodesSearchCriteriaVO industryCodesSearchCriteria) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | countSearchIndustryCodes");
		LOGGER.info("industryCodesSearchCriteria :: "
				+ industryCodesSearchCriteria);

		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer("SELECT ");
		if (null != industryCodesSearchCriteria.getIndustryCodeCrosswalk()
				&& industryCodesSearchCriteria.getIndustryCodeCrosswalk()
						.length() > 0) {
			queryStr.append("count(icm.industryCodeMapPK.fromIndustryCodeId) ")
					.append("FROM IndustryCode ic1, IndustryCode ic2, IndustryCodeMap icm ")
					.append(",IndustryCodeDescription d1, IndustryCodeDescription d2 ")
					.append("WHERE icm.industryCodeMapPK.fromIndustryCodeId = ic1.industryCodeId ")
					.append("and  icm.industryCodeMapPK.toIndustryCodeId = ic2.industryCodeId ")
					.append("and d1.industryCodeId = icm.industryCodeMapPK.fromIndustryCodeId ")
					.append("and d1.languageCode = :codeLangCode ")
					.append("and d1.writingScriptCode = :writingScriptCode ")					
					.append("and d2.industryCodeId = icm.industryCodeMapPK.toIndustryCodeId ")
					.append("and d2.languageCode = :crossWalkLangCode ")
					.append("and d2.writingScriptCode = :writingScriptCode ")					
					.append("and ic1.industryCodeTypeCode = :industryCodeTypeCode ")
					.append("and ic2.industryCodeTypeCode = :industryCodeCrosswalk");
			parameters.put("industryCodeTypeCode", Long
					.valueOf(industryCodesSearchCriteria.getIndustryCodeTypeCode()));
			parameters.put("industryCodeCrosswalk", Long
					.valueOf(industryCodesSearchCriteria.getIndustryCodeCrosswalk()));
			parameters.put("writingScriptCode",
					RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);			
			parameters.put("codeLangCode",
					industryCodesSearchCriteria.getIndustryCodeLanguageCode() != null ?
							industryCodesSearchCriteria.getIndustryCodeLanguageCode() :
								RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			parameters.put("crossWalkLangCode",
					industryCodesSearchCriteria.getIndustryCrossWalkLanguageCode() != null ?
							industryCodesSearchCriteria.getIndustryCrossWalkLanguageCode() :
								RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

			if (null != industryCodesSearchCriteria.getIndustryCode()
					&& industryCodesSearchCriteria.getIndustryCode().length() > 0
					||(null != industryCodesSearchCriteria.getIndustryCodeDescription()
						&& industryCodesSearchCriteria.getIndustryCodeDescription().length() > 0)) {

				queryStr.append(" and ( upper(ic1.industryCode) like concat(upper(:industryCode), '%') ");
				parameters.put("industryCode", String
						.valueOf(industryCodesSearchCriteria
								.getIndustryCode()));

				queryStr.append(" or upper(d1.industryDescription) like concat('%',upper(:industryDescription),'%') ) ");
				parameters.put("industryDescription",
						industryCodesSearchCriteria.getIndustryCodeDescription());
			}
			// adding the group level filter
			if(industryCodesSearchCriteria.getIndustryGroupLevelCodes() != null) {
				queryStr.append(" and ic1.industryCodeGroupLvelCode in (:groupLvelCodes)");
				parameters.put("groupLvelCodes",
						industryCodesSearchCriteria.getIndustryGroupLevelCodes());
			}
		} else {
			queryStr.append("count(ic.industryCodeId) ")
					.append("FROM IndustryCode ic, IndustryCodeDescription icd, CodeValueText t1, CodeValueText t2")
					.append(" WHERE ic.industryCodeId = icd.industryCodeId")
					.append(" AND icd.languageCode = t1.codeValueId")
					.append(" AND ic.industryCodeTypeCode = t2.codeValueId")
					.append(" and t1.languageCode = :enLangCode")
					.append(" and t2.languageCode = :enLangCode")
					.append(" and icd.writingScriptCode = :writingScriptCode")
					.append(" and ic.industryCodeTypeCode = :industryCodeTypeCode")				
					.append(" and t1.expirationDate is null ")  //	Added for IC UI Duplicate issue
					.append(" and t2.expirationDate is null ");  //	Added for IC UI Duplicate issue
			parameters.put("enLangCode",
					RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
			parameters.put("writingScriptCode",
					RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
			parameters.put("industryCodeTypeCode", Long.valueOf(
					industryCodesSearchCriteria.getIndustryCodeTypeCode()));

			if (null != industryCodesSearchCriteria.getIndustryCode()
					&& industryCodesSearchCriteria.getIndustryCode().length() > 0
					||(null != industryCodesSearchCriteria.getIndustryCodeDescription()
						&& industryCodesSearchCriteria.getIndustryCodeDescription().length() > 0)) {

				queryStr.append(" and ( upper(ic.industryCode) like concat(upper(:industryCode), '%') ");
				parameters.put("industryCode", String.valueOf(
						industryCodesSearchCriteria.getIndustryCode()));

				queryStr.append(" or upper(icd.industryDescription) like concat('%',upper(:industryDescription),'%'))");
				parameters.put("industryDescription",
						industryCodesSearchCriteria.getIndustryCodeDescription());
			}
			// adding the group level filter
			if(industryCodesSearchCriteria.getIndustryGroupLevelCodes() != null) {
				queryStr.append(" and ic.industryCodeGroupLvelCode in (:groupLvelCodes)");
				parameters.put("groupLvelCodes",
						industryCodesSearchCriteria.getIndustryGroupLevelCodes());
			}
			// language filter
			if(industryCodesSearchCriteria.getIndustryCodeLanguageCode() != null) {
				queryStr.append(" and icd.languageCode = :codeTableLangCode");
				parameters.put("codeTableLangCode",
						industryCodesSearchCriteria.getIndustryCodeLanguageCode());
			}
		}

		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting IndsCodeStagingDAOImpl | countSearchIndustryCodes");
		try {
		return (Long) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will search the Staging SoR for the IndustryCode based on the
	 * industryCodeId and will return the IndustryCode entity.
	 *
	 * @param industryCodeId
	 */
	public IndustryCode retrieveIndustryCodeByIndustryCodeId(Long industryCodeId) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | retrieveIndustryCodeByIndustryCodeId");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("industryCodeId", industryCodeId);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_INDUSTRYCODE_BY_ID, parameters);
		LOGGER.info("exiting IndsCodeStagingDAOImpl | retrieveIndustryCodeByIndustryCodeId");
		try {
			return (IndustryCode) query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will retrieve Industry code Group Levels for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 *
	 * @param industryCodeTypeCode
	 * @param session
	 * @return list of codeValueVO
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CodeValueVO> retrieveGroupLevelCodes(
			Long industryCodeTypeCode, Long languageCode) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | retrieveGroupLevelCodes");

		Query query = null;
		if(languageCode != null && languageCode.longValue() > 0){
			query = em
			.createNamedQuery(QUERY_RETRIEVE_GROUPLVL_FOR_INDS_CODE_TYPE_CODE_AND_LANGUAGE_CODE);
			query.setParameter("languageCode", languageCode);
		}else{
			query = em
				.createNamedQuery(QUERY_RETRIEVE_GROUPLVL_FOR_INDS_CODE_TYPE_CODE);
		}
		query.setParameter("indsCodeTypeCode", industryCodeTypeCode);
		query.setParameter("enLangCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		LOGGER.info("exiting IndsCodeStagingDAOImpl | retrieveGroupLevelCodes");
		try{
		return mapCodeValueVO(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 *
	 * The method will create the named query instance by setting the query
	 * parameters. The method is invoked for all name query operations.
	 *
	 * @param sql
	 * @param parameters
	 * @return
	 */
	private Query createNamedQuery(String sql, Map<String, Object> parameters) {
		Query query = em.createNamedQuery(sql);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}

	/**
	 * The method will retrieve Industry code and description for the selected
	 * industry code type.
	 *
	 * @param industryCodeTypeCode
	 * @return list of codeValueVO
	 */
	@Override
	public String retrieveDescriptionForIndsCodeTypeCode(
			Long industryCodeTypeCode, String industryCode) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | retrieveDescriptionForIndsCodeTypeCode");

		Query query = em.createNamedQuery(QUERY_RETRIEVE_DESCRIPTION_FOR_CODE_TYPE_CODE);
		query.setParameter("industryCodeTypeCode", industryCodeTypeCode);
		query.setParameter("industryCode", industryCode);
		query.setParameter("languageCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		//query.setParameter("descriptionLengthCode",
			//	RefDataPropertiesConstants.DESCRIPTION_LENGTH_240);
		query.setMaxResults(1);
		String description = "InvalidCodeTypeCodeCombination";
		try {
			IndustryCode industryCodeResult = (IndustryCode)query.getSingleResult();
			if(industryCodeResult != null){
				description = industryCodeResult.getIndustryCodeDescription();
			}

		LOGGER.info("exiting IndsCodeStagingDAOImpl | retrieveDescriptionForIndsCodeTypeCode");
		return description;
		}catch(NoResultException ex){
			return description;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@Override
	public Long retrieveIndustryCodeIdByCodeTypeCode(Long industryCodeTypeCode,
			String industryCode) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | retrieveIndustryCodeIdByCodeTypeCode");

		Query query = em.createNamedQuery(QUERY_RETRIEVE_INDS_ID_FOR_CODE_TYPE_CODE);
		query.setParameter("industryCodeTypeCode", industryCodeTypeCode);
		query.setParameter("industryCode", industryCode);
		Long industryCodeId = null;
		try {
			IndustryCode resultIndustryCode = (IndustryCode) query
					.getSingleResult();
			industryCodeId = resultIndustryCode.getIndustryCodeId();
		}catch(NoResultException ex){
			return 0L;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}

		LOGGER.info("exiting IndsCodeStagingDAOImpl | retrieveIndustryCodeIdByCodeTypeCode");
		return industryCodeId;
	}

	/**
	 *
	 * The method will fetch the language codes available for the selected
	 * Industry Code Type. The method will be invoked when the user selects the
	 * Industry Code type value.
	 *
	 * @param industryCodeTypeCode
	 * @param groupLevelCodes
	 * @return list of codeValueVO
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveIndustryCodeLanguages(
			Long industryCodeTypeCode, List<Long> groupLevelCodes) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | retrieveIndustryCodeLanguages");

		Map<String, Object> parameters = new HashMap<String, Object>();
		StringBuffer queryStr = new StringBuffer(
				QUERY_RETRIEVE_LANGUAGE_FOR_INDS_CODE_TYPE_CODE);

		if(groupLevelCodes != null && groupLevelCodes.size() > 0) {
			queryStr.append(QUERY_RETRIEVE_LANGUAGE_FOR_INDS_CODE_TYPE_CODE_GRPCND);
			List<Long> groupLevelLongIds = new ArrayList<Long>();
			for(int index = 0; index < groupLevelCodes.size(); index++){
				 Object currObj = groupLevelCodes.get(index);
				 if(currObj instanceof Integer){
					 groupLevelLongIds.add(((Integer)currObj).longValue());
				 }
			 }
			parameters.put("groupLevelCodes", groupLevelLongIds);
		}

		parameters.put("indsCodeTypeCode", industryCodeTypeCode);
		parameters.put("enLangCode", RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		Query query = em.createQuery(queryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting IndsCodeStagingDAOImpl | retrieveIndustryCodeLanguages");
		try{
		return mapCodeValueVO(query.getResultList());
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * This method will update given IndustryCode to Staging SoR DB. The return would
	 * be updated IndustryCode entity. The method is invoked when the business owner
	 * approves a request and the respective changes are to be updated from the
	 * Transaction DB to the Staging SoR.
	 *
	 * @param industryCode
	 * @return status
	 */
	@Override
	public Boolean updateIndustryCode(IndustryCode industryCode) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | updateIndustryCode");
		try {
		em.merge(industryCode);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return true;
	}
	/**
	 * The method will remove the industryCode data from the Staging DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param industryCodeId
	 * @param boolean indicating the status
	 */
	@Override
	public void removeApprovedIndustryCodeFromStaging(Long industryCodeId) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | removeApprovedIndustryCodeFromStaging");
		// remove the industry Code details from the table
		Query query = em.createNamedQuery(QUERY_REMOVE_INDUSTRY_CODE_DESCRIPTION_BY_ID);
		query.setParameter("industryCodeId", industryCodeId);
		try {
		query.executeUpdate();
		query = em.createNamedQuery(QUERY_REMOVE_INDUSTRY_CODE_FROM_MAPPING_BY_ID);
		query.setParameter("industryCodeId", industryCodeId);
		query.executeUpdate();
		query = em.createNamedQuery(QUERY_REMOVE_INDUSTRY_CODE_TO_MAPPING_BY_ID);
		query.setParameter("industryCodeId", industryCodeId);
		query.executeUpdate();	
		query = em.createNamedQuery(QUERY_REMOVE_INDUSTRYCODE_BY_ID);
		query.setParameter("industryCodeId", industryCodeId);
		query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting IndsTransactionalDAOImpl | removeApprovedIndustryCodeFromStaging");
	}
	
	/**
	 * 
	 * The method to remove the deleted Industry Code Descriptions from the Staging DB
	 *
	 * @param industryCodeDescriptionId
	 */
	@Override
	public void removeIndustryCodeDescription(Long industryCodeDescriptionId) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | removeIndustryCodeDescription");
		Query query = em.createNamedQuery(QUERY_REMOVE_INDUSTRY_CODE_DESCRIPTION_BY_DESCID);
		query.setParameter("industryCodeDescriptionId", industryCodeDescriptionId);
		try{
		query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting IndsCodeStagingDAOImpl | removeIndustryCodeDescription");
	}
	/**
	 * 
	 * The method to remove the deleted Industry Code Map from the Staging DB
	 *
	 * @param fromIndustryCodeId
	 * @param toIndustryCodeId
	 */
	@Override
	public void removeIndustryCodeMap(Long fromIndustryCodeId, Long toIndustryCodeId) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | removeIndustryCodeMap");
		Query query = em.createNamedQuery(QUERY_REMOVE_INDUSTRY_CODE_MAP_BY_PK);
		query.setParameter("fromIndustryCodeId", fromIndustryCodeId);
		query.setParameter("toIndustryCodeId", toIndustryCodeId);
		try {
		query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting IndsCodeStagingDAOImpl | removeIndustryCodeMap");
	}
	/**
	 * This method counts the IndustryCodeDescription  in the Staging DB to identify any duplicates
	 *
	 * @param industryCodeId
	 * @param industryCodeTypeCode
	 * @return count
	 */
	@Override
	public int countIndustryCodeDescriptionForDuplicate(String industryCode,
			Long industryCodeTypeCode,String industryDescription) {
		LOGGER.info("entering IndsCodeStagingDAOImpl | countIndustryCodeDescriptionForDuplicate");

		Query query = em.createNamedQuery(QUERY_COUNT_INDUSTRY_CODE_DESCRIPTION_FOR_DUPLICATE);
		query.setParameter("industryCode", industryCode);
		query.setParameter("industryCodeTypeCode", industryCodeTypeCode);
		query.setParameter("industryDescription", industryDescription);
		try {
			return ((Long) query.getSingleResult()).intValue();
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * This method will retrieve all the crosswalks available with respective count of each crosswalk
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<InduscodeMappingBulkDownloadVO> retrieveCrosswalkDetails() {
		LOGGER.info("entering IndsCodeStagingDAOImpl | retrieveCrosswalkDetails");
		List<InduscodeMappingBulkDownloadVO> crosswalkList = new ArrayList<InduscodeMappingBulkDownloadVO>();
		Query query = em.createQuery(QUERY_RETRIEVE_CROSSWALK_DETAILS);  
		List<Object[]> result =	 query.getResultList();
				
		try {
			for (Object[] rslt : result) {
				InduscodeMappingBulkDownloadVO crosswalkData = new InduscodeMappingBulkDownloadVO();
				crosswalkData.setFromIndustryCodeTypeCode(Long.valueOf(rslt[0].toString()));
				crosswalkData.setFromIndustryCodeTypeCodeDesc(rslt[1].toString());
				crosswalkData.setToIndustryCodeTypeCode(Long.valueOf(rslt[2].toString()));
				crosswalkData.setToIndustryCodeTypeCodeDesc(rslt[3].toString());				
				crosswalkData.setCrosswalkCount(Long.valueOf(rslt[4].toString()));		
				crosswalkList.add(crosswalkData);		
			}				
		LOGGER.info("exiting IndsCodeStagingDAOImpl | retrieveCrosswalkDetails");				
			return crosswalkList;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
}
