/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.core.vo.XmlSchemaSearchVO;
import com.dnb.dsc.refdata.dao.XmlLabelsStagingDAO;

/**
 * This is used as the DAO implementation class for the Xml Schema Elements operations. The DAO contacts the staging DB
 * for all its operations
 * 
 * @author Cognizant
 * @version last updated : Apr 13, 2012
 * @see
 * 
 */
@Repository("XmlLabelsStagingDAO")
public class XmlLabelsStagingDAOImpl implements XmlLabelsStagingDAO {

    /**
     * The instance variable for Logging
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(XmlLabelsStagingDAOImpl.class);

    @PersistenceContext(unitName = "PU-Staging")
    private EntityManager em;

    /**
     * The constants for named query - retrieve xml schema element by element id
     */
    private static final String QUERY_RETRIEVE_XML_ELEMENT_BY_ID = "XmlSchema.retrieveXmlSchemaByXmlElementId";

    /**
     * The constants for named query - retrieve xml schema element by element name or description
     */
    private static final String QUERY_RETRIEVE_XML_ELEMENT_BY_NAME_OR_DESC = "SELECT new XmlSchemaElement(el.xmlSchemaElementId,el.dataElementName,el.dataElementDescription)"
            + " FROM XmlSchemaElement el where upper(el.dataElementName) like concat('%', upper(:elementName),'%')"
            + " or upper(el.dataElementDescription) like concat('%', upper(:elementDescription),'%')";

    /**
     * The constants for named query - count xml schema element by element name or description
     */
    private static final String QUERY_COUNT_XML_ELEMENT_BY_NAME_OR_DESC = "SELECT count(el.xmlSchemaElementId) "
            + " FROM XmlSchemaElement el where upper(el.dataElementName) like concat('%', upper(:elementName),'%')"
            + " or upper(el.dataElementDescription) like concat('%', upper(:elementDescription),'%')";
    
    /**
	 * The constants for named query - delete xml schema element labal details by id
	 */
	private static final String QUERY_REMOVE_XML_SCHEMA_ELEMENT_LBL_DTL_BY_ID = "XmlSchemaElementLabelDetails.removeByXmlSchemaElementLabelDetailsId";
    
    
    /**
     * 
     * The method will perform the table search of xml schema element on the staging db.
     * 
     * @param XmlSchemaSearchVO
     * @return list of XmlSchemaElement
     */
    @SuppressWarnings("unchecked")
    public List<XmlSchemaElement> searchXmLSchemaLabels(XmlSchemaSearchVO xmlSchemaSearchVO) {
        LOGGER.info("entering XmlLabelsStagingDAOImpl | searchXmLSchemaLabels");

        String sortBy = getNameColumnIndex(xmlSchemaSearchVO.getSortBy());
        String queryString = QUERY_RETRIEVE_XML_ELEMENT_BY_NAME_OR_DESC + " order by " + sortBy + " "
                + xmlSchemaSearchVO.getSortOrder();

        /*
         * Set the parameters for the named query to retrieve geo unit by name
         */
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("elementName", xmlSchemaSearchVO.getElementName());
        parameters.put("elementDescription", xmlSchemaSearchVO.getElementDescription());
        /*
         * Execute the query by setting the parameters
         */
        Query query = em.createQuery(queryString);
        query.setFirstResult(xmlSchemaSearchVO.getStartIndex());
        query.setMaxResults(xmlSchemaSearchVO.getMaxResults());

        for (Entry<String, ?> parameter : parameters.entrySet()) {
            query.setParameter(parameter.getKey(), parameter.getValue());
        }

        LOGGER.info("exiting XmlLabelsStagingDAOImpl | searchXmLSchemaLabels");
        try {
        return (List<XmlSchemaElement>) query.getResultList();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
    }

    /**
     * The method will get the Xml Schema details by Id Element Id and will return the XmlSchemaElement entity.
     * 
     * @param elementId
     */
    public XmlSchemaElement retrieveXmlSchemaByXmlElementId(String elementId) {
        LOGGER.info("entering XmlLabelsStagingDAOImpl | retrieveXmlSchemaByXmlElementId");

        /*
         * Set the parameters for the named query to retrieve geo unit by name
         */
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("elementId", elementId);

        /*
         * Execute the query by setting the parameters
         */
        Query query = em.createNamedQuery(QUERY_RETRIEVE_XML_ELEMENT_BY_ID);
        for (Entry<String, ?> parameter : parameters.entrySet()) {
            query.setParameter(parameter.getKey(), parameter.getValue());
        }
        XmlSchemaElement xmlSchemaElement = null;
        try {
            xmlSchemaElement = (XmlSchemaElement) query.getSingleResult();
		} catch(NoResultException ex){
            return null;
		} catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
        }
		
		LOGGER.info("xmlSchemaElement : " + xmlSchemaElement);
        LOGGER.info("exiting XmlLabelsStagingDAOImpl | retrieveXmlSchemaByXmlElementId");
        return xmlSchemaElement;
    }

	/**
	 * 
	 * The method will perform the table count of xml schema element on the
	 * staging db based on the specified filter conditions.
	 * 
	 * @param XmlSchemaSearchVO
	 * @return count of XmlSchemaElement
	 */
    public Long countSearchXmLSchemaLabels(XmlSchemaSearchVO xmlSchemaSearchVO) {
        LOGGER.info("entering XmlLabelsStagingDAOImpl | countSearchXmLSchemaLabels");

        String queryString = QUERY_COUNT_XML_ELEMENT_BY_NAME_OR_DESC;
        /*
         * Set the parameters for the named query to retrieve geo unit by name
         */
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("elementName", xmlSchemaSearchVO.getElementName());
        parameters.put("elementDescription", xmlSchemaSearchVO.getElementDescription());
        /*
         * Execute the query by setting the parameters
         */
        Query query = em.createQuery(queryString);
        for (Entry<String, ?> parameter : parameters.entrySet()) {
            query.setParameter(parameter.getKey(), parameter.getValue());
        }

        LOGGER.info("exiting XmlLabelsStagingDAOImpl | countSearchXmLSchemaLabels");
        try {
        return (Long) query.getSingleResult();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
    }

    /**
     * the method returns the sort by order
     * 
     * @param sortBy
     * @return String
     */
    private String getNameColumnIndex(String sortBy) {
        // Ordering by column name is not working.
        // Hence using columnIndex for the time being
        if (sortBy.equalsIgnoreCase("xmlSchemaElementId")) {
            return "1";
        } else if (sortBy.equalsIgnoreCase("dataElementName")) {
            return "2";
        } else {
            return "3";
        }
    }
    /**
	 * The method will persist the updated xmlSchemaElement in the Staging
	 * DB.
	 * 
	 * @param xmlSchemaElement
	 */
    public XmlSchemaElement updateXmlSchemaElement(XmlSchemaElement xmlSchemaElement){
		LOGGER.info("entering XmlLabelsTransactionalDAOImpl | updateXmlSchemaElement");
		try {
		return em.merge(xmlSchemaElement);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
    /**
     * This method will remove the deleted xmlSchemaElementLabelDetail from the staging db
     */
    @Override
	public void removeDeletedXmlSchemaLabelDetail(Long xmlSchemaElementLabelDetailsId) {
		LOGGER.info("entering IndsTransactionalDAOImpl | removeApprovedIndustryCode");
		// remove the XML Schema Element from the table
		Query query = em.createNamedQuery(QUERY_REMOVE_XML_SCHEMA_ELEMENT_LBL_DTL_BY_ID);
		query.setParameter("xmlSchemaElementLabelDetailsId", xmlSchemaElementLabelDetailsId);
		try {
		query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
    }
}
