/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.CrcyTransactionalDAO;


@Repository("CrcyTransactionalDAO")
public class CrcyTransactionalDAOImpl implements CrcyTransactionalDAO{


	private static final Logger LOGGER = LoggerFactory
	.getLogger(CrcyTransactionalDAOImpl.class);

	@PersistenceContext(unitName = "PU-Transactional")
	private EntityManager em;

	/**
	 * The constants for named query - count currency exchange entries
	 */
	private static final String QUERY_COUNT_CRCY_EXCH = "CurrencyExchange.countCurrencyExchange";


	/**
	 * The constants for named query - delete currency exchange by id
	 */
	private static final String QUERY_REMOVE_CURRENCY_EXCH_BY_ID = "CurrencyExchange.removeCurrencyExchangeById";

	/**
	 * The constants for named query - retrieve geo unit by geo unit id
	 */
	private static final String QUERY_RETRIEVE_CURRENCY_EXCHANGE_BY_CURRENCY_EXCHANGE_ID = "CurrencyExchange.retrieveCurrencyExchangeByCurrencyExchangeId";

    /**
	 * The method will persist the existing Currency Exchange data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param currencyExchange
	 */
	@Override
	public CurrencyExchange updateExchangeRate(CurrencyExchange currencyExchange) {
		LOGGER.info("entering CrcyTransactionalDAOImpl | updateExchRate");
		CurrencyExchange updatedCurrencyExchange = null;
		try{
			updatedCurrencyExchange = em.merge(currencyExchange);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return updatedCurrencyExchange;
	}

	/**
	 * The method will validate the Currency Exchange for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param currencyExchangeId
	 */
	public String countCurrencyExchange(Long currencyExchangeId) {
		LOGGER.info("entering CrcyTransactionalDAOImpl | countCurrencyExchange");
		
		String lockedUser = null;
		try{
			CurrencyExchange modifiedUser = (CurrencyExchange)em.find(CurrencyExchange.class, currencyExchangeId);
			if(modifiedUser != null){
				lockedUser = modifiedUser.getModifiedUser();
			}
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return lockedUser;
	}

   /**
	 * Retrieves the CurrencyExchange based on the Work flow Tracking Id.<p>
	 * Invoked from the Work flow Component and the search will be performed on the Transaction DB.<p>
	 *
	 * @param trackingId
	 * @return CurrencyExchange
	 */
	@Override
	public CurrencyExchange retrieveCurrencyExchangeByTrackingId(Long currencyExchangeId) {
		LOGGER.info("entering CrcyTransactionalDAOImpl | retrieveCurrencyExchangeByTrackingId");
		Query query = em.createNamedQuery(QUERY_RETRIEVE_CURRENCY_EXCHANGE_BY_CURRENCY_EXCHANGE_ID);
		query.setParameter("currencyExchangeId", currencyExchangeId);
		LOGGER.info("exiting CrcyTransactionalDAOImpl | retrieveCurrencyExchangeByTrackingId");
		Object result = null;
		try{
			result = query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return (CurrencyExchange)result;
	}

	/**
	 * The method will remove the crcyExch data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param currencyExchId
	 * @param boolean indicating the status
	 */
	@Override
	public void removeApprovedCurrencyExchange(Long currencyExchId) {
		LOGGER.info("entering CrcyTransactionalDAOImpl | removeApprovedCurrencyExchange");
		// remove the currency exchange details from the table
		Query query = em.createNamedQuery(QUERY_REMOVE_CURRENCY_EXCH_BY_ID);
		query.setParameter("currencyExchangeId", currencyExchId);
		try{
		query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting CrcyTransactionalDAOImpl | removeApprovedCurrencyExchange");
	}

	/**
	 * Searches the Transaction SoR for the CurrencyExchange based on the
	 * currencyExchangeId and will return the CurrencyExchange entity.
	 * <p>
	 *
	 * @param currencyExchangeId
	 * @return CurrencyExchange
	 */
	@Override
	public CurrencyExchange retrieveCurrencyExchangeByCurrencyExchangeId(
			Long currencyExchangeId) {
		LOGGER.info("entering CrcyTransactionalDAOImpl | retrieveCurrencyExchangeByCurrencyExchangeId");
		Query query = em.createNamedQuery(QUERY_RETRIEVE_CURRENCY_EXCHANGE_BY_CURRENCY_EXCHANGE_ID);
		query.setParameter("currencyExchangeId", currencyExchangeId);
		LOGGER.info("exiting CrcyTransactionalDAOImpl | retrieveCurrencyExchangeByCurrencyExchangeId");
		try{
		return (CurrencyExchange)query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
}
