/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;
import java.util.Map;

import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;

/**
 * This is used as the services interface for the SCoTS operations
 *
 * @author Cognizant
 * @version last updated : Feb 2, 2012
 * @see
 *
 */
public interface SCoTsTransactionalDAO {
	 /**
	 * The method will persist the existing Code Table data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	CodeTable updateCodeTable(CodeTable codeTable);

	 /**
	 * The method will persist the existing Code Value data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	CodeValue updateCodeValue(CodeValue codeValue);


	 /**
	 * The method will persist the existing SystemApplicability data in the Transaction
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param systemApplicability
	 */
	public SystemApplicability updateSystemApplicability(
			SystemApplicability systemApplicability) ;

	 /**
	 * The method will persist the existing CountryApplicability data in the Transaction
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param systemApplicability
	 */
	public CountryApplicability updateCountryApplicability(
			CountryApplicability countryApplicability);

	/**
	 * The method will validate the Currency Exchange for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param codeTableId
	 */
	String countCodeTable(Long codeTableId);

		/**
		 * The method will validate the Code Value for any locks (If already been
		 * opened by any other user for edit). If no lock is currently available
		 * then the method will lock the record and return FALSE indicating no lock
		 * currently. But if a lock already exists, the method will return TRUE. The
		 * lock operation will be performed in the Transactional DB.
		 *
		 * @param codeValueId
		 */
	String countCodeValue(Long codeValueId);

	/**
	 * The method will validate the alternateSchemeTypeCode for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param alternateSchemeTypeCode
	 */
	String countAlternateSchemeTypeCode(Long alternateSchemeTypeCode);
	/**
	 *
	 * The method to find the CodeTable entity by the primary key codeTableId
	 *
	 * @param codeTableId
	 * @return CodeTable entity
	 */
	CodeTable retrieveCodeTableById(Long codeTableId);

	/**
	 *
	 * The method to find the CodeTable entity by the primary key codeValueId
	 *
	 * @param codeValueId
	 * @return CodeTable entity
	 */
	CodeValue retrieveCodeValueById(Long codeValueId);

	/**
	 * The method will remove the CodeTable data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param codeTableId
	 * @param boolean indicating the status
	 */
	void removeApprovedCodeTable(Long codeTableId);

       /**
	 * The method will remove the CodeValue data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param codeValueId
	 * @param boolean indicating the status
	 */
	void removeApprovedCodeValue(Long codeValueId);
	/**
	 * The method will remove the CodeValueAlternateScheme data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param alternateSchemeTypeCode
	 * @param boolean indicating the status
	 */
	void removeApprovedCodeValueAlternateScheme(Long alternateSchemeTypeCode);
	/**
	 *
	 * The method to retrieve the MarketApplicabilities for a given market applicability type.
	 *
	 * @param domainId
	 * @return marketApplicabilities
	 */
	List<CountryApplicability> retrieveTxnMarketApplicabilities(Long domainId);
	/**
	 *
	 * The method to retrieve the SystemApplicabilities for a given system applicability type.
	 *
	 * @param domainId
	 * @return systemApplicabilities
	 */
	List<SystemApplicability> retrieveTxnSystemApplicabilities(Long domainId);

	/**
	 * The method will remove the country appy data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param domainId
	 */
	void removeApprovedCountryApplicabilities(Long domainId);

	/**
	 * The method will remove the system appy data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param domainId
	 */
	void removeApprovedSystemApplicabilities(Long domainId);
	@SuppressWarnings("rawtypes")
	List retrieveSystemForCode(String applicability, Long applicabilityCode);
	
	 /**
	 * The method will persist the existing CodeValueAssociation in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param codeValueAssociation
	 */	
	CodeValueAssociation updateCodeValueAssociation(CodeValueAssociation codeValueAssociation);
	
        /**
	 * The method will persist the existing CodeValue Alternate Scheme in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param codeValueAssociation
	 */	
	CodeValueAlternateScheme updateCodeValueAlternateScheme(CodeValueAlternateScheme codeValueAlternateScheme);
	
	List<CodeValueAssociation> retrieveCodeValueAssociations(Long parentCodeTableId, Long childCodeTableId);
	/**
	 * 
	 * The method to update the CodeValueText into the Transaction DB
	 *
	 * @param codeValueText
	 * @return CodeValueText
	 */
	Long updateCodeValueText(CodeValueText codeValueText);
	
	/**
	 *
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the transaction
	 * DB to fetch all alternate scheme codes matching the scheme type code
	 * selected by the user.
	 * 
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	List<CodeValueAlternateScheme> retrieveAlternateSchemeCodes(Long schemeTypeCode);
	/**
	 *
	 * The method will return the max value for the next code value id
	 *
	 * @return codeValueId
	 */
	Long retrieveMaxCodeValueId();
	
	/**
	 * 
	 * The method will return the max value for the next code table id
	 *
	 * @return codeTableId
	 */
    Long retrieveMaxCodeTableId();
/**
	 * 
	 * The method will return the max value for the next code table id
	 *
	 * @return codeTableId
	 */
    Long retrieveFirstCodeTableId();
/**
	 * The method will remove the codeTable data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param associationIds
	 */
	void removeApprovedCodeRelationship(List<Long> associationIds);
	
	/**
	 * If applicability is "System", value of dnbSystemCode will be dnbSystemCode
	 * in sys_appy table. If it is "Market", value of dnbSystemCode will be 
	 * ctry_geo_unit_id in ctry_appy table. This method checks if the applicability 
	 * with given dnbSystemCode is already present in transactional db. If it exists, 
	 * the return map will contain isLocked=true and username=modifiedUser. Else the 
	 * map will contain isLocked=false and username="".
	 * 
	 * @param dnbSystemCode
	 * @param applicability
	 * @return map
	 */
	Map<String, Object> lockApplicabilityForEdit(Long dnbSystemCode, String applicability);
	
	/**
	 * This method will retrieve the saved records from the transaction db.
	 * @param domainName
	 * @return
	 */
	public  Map<String, List<SavedRecord>> retrieveSavedRecordsByDomainName(String domainName);
	
	/** Implemented to fix 209048785 -Edit SCoTS Approval Page**/
    CodeValue update(CodeValue codeValue,String ApproverId );
    
    /**
	 * The method will validate the Scots Relationship for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param codeTableId
	 */
	String countCodeRealtionship(Long parentTableId,Long childTableId);

}
