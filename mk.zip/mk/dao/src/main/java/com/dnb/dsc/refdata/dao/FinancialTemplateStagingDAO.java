/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;
import java.util.Map;

import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.FinancialStatementSchedule;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplate;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateInternalLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateOwnerLineItem;

/**
 * 
 * @author Cognizant
 * @version last updated : June 19, 2012
 * @see
 * 
 */
public interface FinancialTemplateStagingDAO {

	/**
	 * 
	 * The method to get the financial templates from the staging DB
	 *
	 * @param codeTableId
	 * @return
	 */
	List<CodeValueText> getFinancialTemplates(Long codeTableId);
	/**
	 * 
	 * The method to retrieve the schedules for a statement type
	 *
	 * @param statementType
	 * @return
	 */
	List<CodeValueText> getSchedulesForStatementType(Long statementType);
	/**
	 * 
	 * The method is to update the financial template 
	 *
	 * @param fsTemplate
	 * @return
	 */
	FinancialStatementTemplate updateFinancialStatementTemplate(FinancialStatementTemplate fsTemplate);
	/**
	 * 
	 * The method is to update the financial statement schedule
	 *
	 * @param schedule
	 * @return
	 */
	FinancialStatementSchedule updateFinancialStatementSchedule(FinancialStatementSchedule schedule);
	/**
	 * 
	 * The method is to update the financial statement line item
	 *
	 * @param lineItem
	 * @return
	 */
	FinancialStatementTemplateLineItem updateFinancialStatementTemplateLineItem(FinancialStatementTemplateLineItem lineItem);
	/**
	 * 
	 * The method is to update the financial statement internal line item
	 *
	 * @param internalLineItem
	 * @return
	 */
	FinancialStatementTemplateInternalLineItem updateFinancialStatementTemplateInternalLineItem(FinancialStatementTemplateInternalLineItem internalLineItem);
	/**
	 * 
	 * The method is to update the financial statement template owner line item
	 *
	 * @param ownerLineItem
	 * @return
	 */
	FinancialStatementTemplateOwnerLineItem updateFinancialStatementTemplateOwnerLineItem(
			FinancialStatementTemplateOwnerLineItem ownerLineItem);
	/**
	 * 
	 * The method is to retrieve the financial statement template by type code
	 *
	 * @param financialTemplateTypeCode
	 * @return
	 */
	FinancialStatementTemplate retrieveFinancialStatementTemplateByTypeCode(Long financialTemplateTypeCode);
	/**
	 * 
	 * The method is to retrieve the line items for a schedule type
	 *
	 * @param scheduleType
	 * @return
	 */
	List<CodeValueText> getLineItemsForScheduleType(Long scheduleType);
	/**
	 * 
	 * The method is to retrieve the description for id
	 *
	 * @param codeValueIdList
	 * @return
	 */
	Map<Integer, String> retrieveDescForId(List<Integer> codeValueIdList);
	/**
	 * 
	 * The method is to retrieve the statement types for a schedule
	 *
	 * @param scheduleCodeList
	 * @return
	 */
	List<CodeValueText> retrieveStatementForSchedules(List<Integer> scheduleCodeList);
	/**
	 * 
	 * The method is to retrieve the financial statement templates by id
	 *
	 * @param financialStatementTemplateId
	 * @return
	 */
	FinancialStatementTemplate retrieveFinancialStatementTemplateById(Long financialStatementTemplateId);
}
