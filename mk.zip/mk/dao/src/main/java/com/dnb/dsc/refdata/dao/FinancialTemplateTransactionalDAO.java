/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.Map;

import com.dnb.dsc.refdata.core.entity.FinancialStatementSchedule;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplate;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateInternalLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateOwnerLineItem;

/**
 * 
 * @author Cognizant
 * @version last updated : June 23, 2012
 * @see
 * 
 */
public interface FinancialTemplateTransactionalDAO {

	/**
	 * 
	 * The method is to update the financial statement template
	 *
	 * @param fsTemplate
	 * @return
	 */
	FinancialStatementTemplate updateFinancialStatementTemplate(FinancialStatementTemplate fsTemplate);
	/**
	 * 
	 * The method is to update the financial statement schedules
	 *
	 * @param schedule
	 * @return
	 */
	FinancialStatementSchedule updateFinancialStatementSchedule(FinancialStatementSchedule schedule);
	/**
	 * 
	 * The method is to update the financial statement template line item
	 *
	 * @param lineItem
	 * @return
	 */
	FinancialStatementTemplateLineItem updateFinancialStatementTemplateLineItem(
			FinancialStatementTemplateLineItem lineItem);
	/**
	 * 
	 * The method is to update the financial statement template internal line item
	 *
	 * @param internalLineItem
	 * @return
	 */
	FinancialStatementTemplateInternalLineItem updateFinancialStatementTemplateInternalLineItem(
			FinancialStatementTemplateInternalLineItem internalLineItem);
	/**
	 * 
	 * The method is to update the financial statement template owner line item
	 *
	 * @param ownerLineItem
	 * @return
	 */
	FinancialStatementTemplateOwnerLineItem updateFinancialStatementTemplateOwnerLineItem(
			FinancialStatementTemplateOwnerLineItem ownerLineItem);
	/**
	 * 
	 * The method is to retrieve the financial statement template by id
	 *
	 * @param financialStatementTemplateId
	 * @return
	 */
	FinancialStatementTemplate retrieveFinancialStatementTemplateById(Long financialStatementTemplateId);
	/**
	 * 
	 * The method is to remove the approved financial template
	 *
	 * @param financialStatementTemplateId
	 * @return
	 */
	Boolean removeApprovedFinancialTemplate(Long financialStatementTemplateId);
	/**
	 * 
	 * The method is to retrieve the financial statement template by type code
	 *
	 * @param financialTemplateTypeCode
	 * @return
	 */
	FinancialStatementTemplate retrieveFinancialStatementTemplateByTypeCode(Long financialTemplateTypeCode);
	/**
	 * 
	 * The method is to retrieve the max financial template id
	 *
	 * @return
	 */
	Long retrieveMaxFinanceTemplateId();
	
	/**
     * method return the finance template type code for a given finance template id
     * @param financeTemplateId
     * @return
     */
	Long retrieveFinanceTemplateCodeById(Long financeTemplateId);
	/**
	 * 
	 * The method is to retrieve the max financial schedule id
	 *
	 * @return
	 */
	Long retrieveMaxScheduleId();
	/**
	 * 
	 * The method is to retrieve the max financial line item id
	 *
	 * @return
	 */
	Long retrieveMaxLineItemId();
	
	Map<String, Object> lockFinancialTemplateForEdit(Long financialTemplateTypeCode);
}
