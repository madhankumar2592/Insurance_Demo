/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.XmlLabelsTransactionalDAO;

/**
 * This is used as the DAO implementation class for the Xml Schema Elements operations. The DAO contacts the staging DB
 * for all its operations
 * 
 * @author Cognizant
 * @version last updated : Apr 13, 2012
 * @see
 * 
 */
@Repository("XmlLabelsTransactionalDAO")
public class XmlLabelsTransactionalDAOImpl implements XmlLabelsTransactionalDAO{

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(XmlLabelsTransactionalDAOImpl.class);

	/**
	 * The constants for named query - count currency exchange entries
	 */
	private static final String QUERY_COUNT_XML_SCHEMA = "XmlSchema.countXmlSchema";

	 /**
     * The constants for named query - retrieve xml schema element by element id
     */
    private static final String QUERY_RETRIEVE_XML_ELEMENT_BY_ID = "XmlSchema.retrieveXmlSchemaByXmlElementId";
    /**
	 * The constants for named query - delete xml schema element
	 */
	private static final String QUERY_REMOVE_XML_SCHEMA_ELEMENT_BY_ID = "XmlSchema.removeXmlSchemaElementById";
    /**
	 * The constants for named query - delete xml schema element labal details
	 */
	private static final String QUERY_REMOVE_XML_SCHEMA_ELEMENT_LBL_DTL = "XmlSchemaElementLabelDetails.removeByXmlSchemaElementId";
    /**
	 * The constants for named query - delete xml schema element path
	 */
	private static final String QUERY_REMOVE_XML_SCHEMA_ELEMENT_PATH = "XmlSchemaElementXPath.removeByXmlSchemaElementId";

	@PersistenceContext(unitName = "PU-Transactional")
	private EntityManager em;

	/**
	 * The method will persist the updated xmlSchemaElement in the Transactional
	 * DB.
	 *
	 * @param xmlSchemaElement
	 */
	public XmlSchemaElement updateXmlSchemaElement(XmlSchemaElement xmlSchemaElement){
		LOGGER.info("entering XmlLabelsTransactionalDAOImpl | updateXmlSchemaElement");
		try {
		return em.merge(xmlSchemaElement);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will validate the xmlSchemaElement for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param currencyExchangeId
	 */
	public int countXmlSchema(String xmlSchemaElementId) {
		LOGGER.info("entering XmlLabelsTransactionalDAOImpl | countXmlSchema");

		Query query = em.createNamedQuery(QUERY_COUNT_XML_SCHEMA);
		query.setParameter("xmlSchemaElementId", xmlSchemaElementId);
		try {
		return ((Long) query.getSingleResult()).intValue();
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will get the Xml Schema details by Id Element Id and will
	 * return the XmlSchemaElement entity.
	 * 
	 * @param elementId
	 */
    public XmlSchemaElement retrieveXmlSchemaByXmlElementId(String elementId) {
        LOGGER.info("entering XmlLabelsTransactionalDAOImpl | retrieveXmlSchemaByXmlElementId");

        /*
         * Set the parameters for the named query to retrieve geo unit by name
         */
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("elementId", elementId);

        /*
         * Execute the query by setting the parameters
         */
        Query query = em.createNamedQuery(QUERY_RETRIEVE_XML_ELEMENT_BY_ID);
        for (Entry<String, ?> parameter : parameters.entrySet()) {
            query.setParameter(parameter.getKey(), parameter.getValue());
        }
        XmlSchemaElement xmlSchemaElement = null;
        try {
            xmlSchemaElement = (XmlSchemaElement) query.getSingleResult();
		} catch(NoResultException ex){
            return null;
		} catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
        }
		
		LOGGER.info("xmlSchemaElement : " + xmlSchemaElement);
        LOGGER.info("exiting XmlLabelsTransactionalDAOImpl | retrieveXmlSchemaByXmlElementId");
        return xmlSchemaElement;
    }
    /**
	 * The method will remove the industryCode data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param industryCodeId
	 * @param boolean indicating the status
	 */
	@Override
	public void removeApprovedXmlSchemaLabels(String xmlSchemaElementId) {
		LOGGER.info("entering IndsTransactionalDAOImpl | removeApprovedIndustryCode");
		// remove the XML Schema Element from the table
		Query query = em.createNamedQuery(QUERY_REMOVE_XML_SCHEMA_ELEMENT_BY_ID);
		query.setParameter("xmlSchemaElementId", xmlSchemaElementId);
		try {
		query.executeUpdate();

		// remove the XML Schema Element Label Details from the table
		query = em.createNamedQuery(QUERY_REMOVE_XML_SCHEMA_ELEMENT_LBL_DTL);
		query.setParameter("xmlSchemaElementId", xmlSchemaElementId);
		query.executeUpdate();
		
		// remove the Xml Schema Element Path from the table
		query = em.createNamedQuery(QUERY_REMOVE_XML_SCHEMA_ELEMENT_PATH);
		query.setParameter("xmlSchemaElementId", xmlSchemaElementId);
		query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting IndsTransactionalDAOImpl | removeApprovedIndustryCode");
	}
}
