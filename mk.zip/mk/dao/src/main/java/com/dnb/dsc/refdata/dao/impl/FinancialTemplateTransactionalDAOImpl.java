/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.FinancialStatementSchedule;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplate;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateInternalLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateOwnerLineItem;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.FinancialTemplateTransactionalDAO;

/**
 * 
 * @author Cognizant
 * @version last updated : June 23, 2012
 * @see
 * 
 */
@Repository("FinancialTemplateTransactionalDAO")
public class FinancialTemplateTransactionalDAOImpl implements FinancialTemplateTransactionalDAO {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(FinancialTemplateTransactionalDAOImpl.class);
	
	private static final String QUERY_RETRIEVE_FINANCIAL_STATEMENT_TEMPLATE_BY_ID = "FinancialStatementTemplate.retrieveFinancialStatementTemplateById";
	private static final String QUERY_REMOVE_INTERNAL_LINE_ITEM_BY_ID = "FinancialStatementTemplateInternalLineItem.removeFinancialStatementTemplateInternalLineItemById";
	private static final String QUERY_REMOVE_OWNER_LINE_ITEM_BY_ID = "FinancialStatementTemplateOwnerLineItem.removeFinancialStatementTemplateOwnerLineItemById";
	private static final String QUERY_REMOVE_LINE_ITEM_BY_ID = "FinancialStatementTemplateLineItem.removeFinancialStatementTemplateLineItemById";
	private static final String QUERY_REMOVE_SCHEDULE_BY_ID = "FinancialStatementSchedule.removeFinancialStatementScheduleById";
	private static final String QUERY_REMOVE_TEMPLATE_BY_ID = "FinancialStatementTemplate.removeFinancialStatementTemplateById";
	private static final String QUERY_RETRIEVE_FINANCIAL_TEMPLATE_CODE_BY_ID ="FinancialStatementTemplate.retrieveFinanceTemplateCodeById";
	
	private static final String QUERY_RETRIEVE_FINANCIAL_STATEMENT_TEMPLATE_BY_TYPE_CODE = "FinancialStatementTemplate.retrieveFinancialStatementTemplateByTypeCode";

	private static final String QUERY_LOCK_FINANCIAL_TEMPLATE_FOR_EDIT = "FinancialStatementTemplate.lockFinancialTemplateForEdit";
	@PersistenceContext(unitName = "PU-Transactional")
	private EntityManager em;
	
	private JdbcTemplate jdbcTemplate;
  
    /**
     * Inject DataSource properties to jdbcTemplate.
     * 
     * @param argDataSource
     *            the new data source
     */
    @Autowired
    @Qualifier("txnDataSource")
    public void setDataSource(DataSource argDataSource) {
        this.jdbcTemplate = new JdbcTemplate(argDataSource);
    }
	
	/**
	 * 
	 * The setter method for the entity manager. The persistence context has
	 * been defined as part of the entity manager definition.
	 * 
	 * @param em
	 */
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}

	@Override
	public FinancialStatementTemplate updateFinancialStatementTemplate(FinancialStatementTemplate fsTemplate){
		LOGGER.info("FinancialTemplateTransactionalDAOImpl - updateFinancialStatementTemplate");
		try{
		return em.merge(fsTemplate);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementSchedule updateFinancialStatementSchedule(FinancialStatementSchedule schedule){
		LOGGER.info("FinancialTemplateTransactionalDAOImpl - updateFinancialStatementSchedule");
		try{
		return em.merge(schedule);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementTemplateLineItem updateFinancialStatementTemplateLineItem(FinancialStatementTemplateLineItem lineItem){
		LOGGER.info("FinancialTemplateTransactionalDAOImpl - updateFinancialStatementTemplateLineItem");
		try{	
		return em.merge(lineItem);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementTemplateInternalLineItem updateFinancialStatementTemplateInternalLineItem(FinancialStatementTemplateInternalLineItem internalLineItem){
		LOGGER.info("FinancialTemplateTransactionalDAOImpl - updateFinancialStatementTemplateInternalLineItem");
		try{
		return em.merge(internalLineItem);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementTemplateOwnerLineItem updateFinancialStatementTemplateOwnerLineItem(FinancialStatementTemplateOwnerLineItem ownerLineItem){
		LOGGER.info("FinancialTemplateTransactionalDAOImpl - updateFinancialStatementTemplateOwnerLineItem");
		try{
		return em.merge(ownerLineItem);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public FinancialStatementTemplate retrieveFinancialStatementTemplateById(Long financialStatementTemplateId) {
		LOGGER.info("entering FinancialTemplateTransactionalDAOImpl | retrieveFinancialStatementTemplateById");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("financialStatementTemplateId", financialStatementTemplateId);

		Query query = em.createNamedQuery(QUERY_RETRIEVE_FINANCIAL_STATEMENT_TEMPLATE_BY_ID);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		LOGGER.info("exiting FinancialTemplateTransactionalDAOImpl | retrieveFinancialStatementTemplateById");
		try{
		FinancialStatementTemplate financialStatementTemplate= (FinancialStatementTemplate) query.getSingleResult();
		LOGGER.info(" FinancialStatementTemplate || "+financialStatementTemplate);
			return financialStatementTemplate;
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public Boolean removeApprovedFinancialTemplate(Long financialStatementTemplateId) {
		LOGGER.info("entering FinancialTemplateTransactionalDAOImpl | removeApprovedFinancialTemplate");
		
		Query query = null;
		FinancialStatementTemplate fsTemplate = retrieveFinancialStatementTemplateById(financialStatementTemplateId);
		List<FinancialStatementSchedule> fsScheduleList =  fsTemplate.getFinancialStatementScheduleList();
		try {
		if(fsScheduleList != null){
			for(FinancialStatementSchedule schedule : fsScheduleList){
				List<FinancialStatementTemplateLineItem> lineItemList = schedule.getFinancialStatementTemplateLineItemList();
				if(lineItemList != null){
					for(FinancialStatementTemplateLineItem lineItem : lineItemList){
						query = em.createNamedQuery(QUERY_REMOVE_INTERNAL_LINE_ITEM_BY_ID);
						query.setParameter("financialStatementTemplateLineItemId", lineItem.getFinancialStatementTemplateLineItemId());
						query.executeUpdate();
						
						query = em.createNamedQuery(QUERY_REMOVE_OWNER_LINE_ITEM_BY_ID);
						query.setParameter("financialStatementTemplateLineItemId", lineItem.getFinancialStatementTemplateLineItemId());
						query.executeUpdate();
						
						query = em.createNamedQuery(QUERY_REMOVE_LINE_ITEM_BY_ID);
						query.setParameter("financialStatementScheduleId", schedule.getFinancialStatementScheduleId());
						query.executeUpdate();
						
					}
				}
			}
			query = em.createNamedQuery(QUERY_REMOVE_SCHEDULE_BY_ID);
			query.setParameter("financialStatementTemplateId", fsTemplate.getFinancialStatementTemplateId());
			query.executeUpdate();
		}
		query = em.createNamedQuery(QUERY_REMOVE_TEMPLATE_BY_ID);
		query.setParameter("financialStatementTemplateId", fsTemplate.getFinancialStatementTemplateId());
		query.executeUpdate();
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		LOGGER.info("exiting FinancialTemplateTransactionalDAOImpl | removeApprovedFinancialTemplate");
		return true;
	}
	
	@Override
	public FinancialStatementTemplate retrieveFinancialStatementTemplateByTypeCode(Long financialTemplateTypeCode) {
		LOGGER.info("entering FinancialTemplateTransactionalDAOImpl | retrieveFinancialStatementTemplateByTypeCode");
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("financialTemplateTypeCode", financialTemplateTypeCode);

		Query query = em.createNamedQuery(QUERY_RETRIEVE_FINANCIAL_STATEMENT_TEMPLATE_BY_TYPE_CODE);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		LOGGER.info("exiting FinancialTemplateTransactionalDAOImpl | retrieveFinancialStatementTemplateByTypeCode");
		try {
			return (FinancialStatementTemplate) query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * method return the finance template type code for a given finance template id
	 * @param financeTemplateId
	 * @return
	 */
	public Long retrieveFinanceTemplateCodeById(Long financeTemplateId){
		LOGGER.info("entering FinancialTemplateTransactionalDAOImpl | retrieveFinanceTemplateCodeById");
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("financeTemplateId", financeTemplateId);
		
		Query query = em.createNamedQuery(QUERY_RETRIEVE_FINANCIAL_TEMPLATE_CODE_BY_ID);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		 
		LOGGER.info("exiting FinancialTemplateTransactionalDAOImpl | retrieveFinanceTemplateCodeById");
		try{
			return (Long)query.getSingleResult();
		}catch(NoResultException ex){
			return null;
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@Override
	public Long retrieveMaxFinanceTemplateId() {
		try{
		return jdbcTemplate.queryForLong("SELECT SORUSR.FINL_STMT_TMPLT_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public Long retrieveMaxScheduleId() {
		try{
		return jdbcTemplate.queryForLong("SELECT SORUSR.FINL_STMT_SCHE_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	
	@Override
	public Long retrieveMaxLineItemId() {
		try{
		return jdbcTemplate.queryForLong("SELECT SORUSR.FINL_STMT_TMPLT_LN_ITM_ID_SEQ.nextval from dual");
		}catch(NoResultException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}
	/**
	 * This method checks if the financial Template with given financialTemplateTypeCode 
	 * is already present in transactional db. If it exists, 
	 * the return map will contain isLocked=true and username=modifiedUser. Else the 
	 * map will contain isLocked=false and username="".
	 * 
	 * @param financialTemplateTypeCode
	 * @return map
	 */
	@Override
	public Map<String, Object> lockFinancialTemplateForEdit(Long financialTemplateTypeCode){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Query query = null;
		try {
				query = em.createNamedQuery(QUERY_LOCK_FINANCIAL_TEMPLATE_FOR_EDIT);
				query.setParameter("financialTemplateTypeCode", financialTemplateTypeCode);
				FinancialStatementTemplate fst = (FinancialStatementTemplate) query.getSingleResult();
				resultMap.put("isLocked", true);
				resultMap.put("username", fst.getModifiedUser());
		}catch(NoResultException nre){
			resultMap.put("isLocked", false);
			resultMap.put("username", "");
		}catch(NonUniqueResultException nue){
			resultMap.put("isLocked", true);
			resultMap.put("username", "more than one users");
		}catch(PersistenceException ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		}catch(Exception ex){
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return resultMap;
	}
}
