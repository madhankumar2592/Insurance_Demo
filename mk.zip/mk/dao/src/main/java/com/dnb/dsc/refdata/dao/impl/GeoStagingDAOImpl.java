/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.GeoStagingDAO;
import com.googlecode.ehcache.annotations.Cacheable;

/**
 * This is used as the DAO implementation class for the Geography operations.
 * The DAO contacts the staging DB for all its operations
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@Repository("GeoStagingDAO")
public class GeoStagingDAOImpl implements GeoStagingDAO {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GeoStagingDAOImpl.class);

	@PersistenceContext(unitName = "PU-Staging")
	private EntityManager em;

	private JdbcTemplate jdbcTemplate;

	/**
	 * The constants for named query - retrieve geo unit by geo unit id
	 */
	private static final String QUERY_RETRIEVE_GEOUNIT_BY_ID = "GeoUnit.retrieveGeoUnitByGeoUnitId";

	/**
	 * The constants for named query - retrieve geo unit by geo unit for delete
	 */
	private static final String QUERY_RETRIEVE_GEOUNIT_FOR_DELETE = "GeoUnit.retrieveGeoUnitForDelete";

	/**
	 * The constant for named Query - to validate geo unit for child
	 * associations.
	 */
	private static final String QUERY_VALIDATE_GEO_UNIT_ASSOCIATIONS_FOR_DELETE = "GeoUnitAssociation.validateGeoUnitAssociations";

	/**
	 * The constant for named Query - to retrieve all geoUnitTypes associations.
	 */
	private static final String QUERY_RETRIEVE_ALL_GEO_UNIT_TYPES = "CodeValue.retrieveAllGeoUnitTypes";
	/**
	 * The constant for named Query - to retrieve all geoUnit name types .
	 */
	private static final String QUERY_RETRIEVE_ALL_GEO_NAME_TYPES = "CodeValue.retrieveApplicableGeoNameTypes";
	/**
	 * The constants for named query - retrieve all geo unit countries
	 */
	private static final String QUERY_RETRIEVE_ALL_COUNTRIES = "GeoUnitName.retrieveAllCountries";

	/**
	 * The constants for named query - retrieve all geo unit country groups
	 */
	private static final String QUERY_RETRIEVE_ALL_COUNTRY_GROUPS = "GeoUnitName.retrieveAllCountryGroups";

	/**
	 * The constants for named query - retrieve all geo unit countries
	 */
	// private static final String QUERY_RETRIEVE_CHILD_GEO_BY_TYPE =
	// "GeoUnitName.retrieveChildGeoUnitsByType";
	private static final String QUERY_RETRIEVE_CHILD_GEO_BY_TYPE = "SELECT distinct gnme.geo_unit_id as geo_unit_id, "
			+ "gnme.geo_nme as geo_nme "
			+ "from SORUSR.geo_unit_nme gnme, SORUSR.geo_unit geo, "
			+ "	SORUSR.geo_unit_assn assn where gnme.geo_unit_id = geo.geo_unit_id "
			+ "	and geo.geo_unit_id = assn.chld_geo_unit_id "
			+ "	and geo.geo_unit_typ_cd = :geoUnitType "
			+ "	and gnme.writ_scrp_cd = 19349  "
			+ "	and gnme.geo_nme_typ_cd = 32 "
			+ "	and assn.prnt_geo_unit_id = :parentGeoUnitId "
			+ "	and gnme.lang_cd = ( "
			+ "	case  "
			+ "	  when exists (select distinct nmeT.lang_cd from geo_unit_nme nmeT "
			+ "						where nmeT.lang_cd = :langCode ) "
			+ "	  then ( :langCode ) else 39 "
			+ "	end "
			+ "	) "
			+ "	order by gnme.geo_nme";

	/**
	 * The constants for named query - retrieve child geo unit associations
	 */
	private static final String QUERY_RETRIEVE_CHILD_GEO_ASSOCIATION = "GeoUnitAssociation.retrieveChildGeoAssociation";

	/**
	 * The constants for named query - retrieve child geo unit associations
	 */
	private static final String QUERY_RETRIEVE_GEO_UNITS_BY_COUNTRY_GROUP = "GeoUnitName.retrieveGeoUnitsByCountryGroup";

	/**
	 * The constants for named query - retrieve child geo unit associations
	 */
	private static final String QUERY_RETRIEVE_ALL_GEO_UNITS_BY_COUNTRY_GROUP = "GeoUnitName.retrieveAllGeoUnitsByCountryGroup";

	/**
	 * The constants for query - retrieve name search results
	 */
	private static final String RETRIEVE_GEO_NAME_SEARCH = "SELECT new GeoUnitName(n.geoUnitNameId, n.geoUnitId, "
			+ "(SELECT cvt.codeValueShortDescription from CodeValueText cvt "
			+ "where cvt.languageCode = :enLangCode and cvt.codeValueId = n.languageCode), "
			+ "(SELECT cvt.codeValueShortDescription from CodeValueText cvt "
			+ "where cvt.languageCode = :enLangCode and cvt.codeValueId = n.nameTypeCode), "
			+ "n.geoName, n.dataProviderCode) "
			+ "FROM GeoUnitName n where upper(n.geoName) like concat(upper(:geoName),'%')  and "
			+ "n.writingScriptCode = :writingScriptCode";

	/**
	 * The constants for query - retrieve count of name search results
	 */
	private static final String RETRIEVE_GEO_NAME_SEARCH_COUNT = "SELECT count(n.geoName) "
			+ "FROM GeoUnitName n where upper(n.geoName) like concat(upper(:geoName),'%')  and "
			+ "n.writingScriptCode = :writingScriptCode";

	/**
	 * The constants for query - retrieve count of code search results
	 */
	private static final String RETRIEVE_GEO_CODE_SEARCH_COUNT = "select count(*) from GeoUnitCode where upper(GEO_CODE) like concat(upper(:geoCode),'%')"
			+ " and expirationDate is null and expiredByDate is null ";

	/**
	 * The constants for query - retrieve code search results
	 */
	private static final String RETRIEVE_GEO_CODE_SEARCH = "SELECT new GeoUnitCode(c.geoUnitCodeId, "
			+ "cvt.codeValueShortDescription , "
			+ "c.geoUnitId, c.geoCode, (select distinct geoName from GeoUnitName where geoUnitId=c.geoUnitId and languageCode = 39 and nameTypeCode = 32 ), cvt1.codeValueShortDescription) "
			+ "FROM GeoUnitCode c, CodeValueText cvt,CodeValueText cvt1,GeoUnit unit where "
			+ " upper(c.geoCode) like concat(upper(:geoCode),'%') "
			+ "and cvt.languageCode = :enLangCode "
			+ "and cvt.codeValueId = c.geoCodeTypeCode "
			+ "and c.geoUnitId = unit.geoUnitId "
			+ "and cvt1.codeValueId = unit.geoUnitTypeCode "
			+ "and cvt1.languageCode = :enLangCode "
			+ "and c.expirationDate is null and c.expiredByDate is null "
			+ "and cvt.expirationDate is null and cvt1.expirationDate is null "
			+ "and unit.expirationDate is null and unit.expiredByDate is null ";

	private static final String QUERY_RETRIEVE_GEO_UNIT_LIST_BY_ID_LIST = "GeoUnit.getCodeAndNameById";

	private static final String QUERY_RETRIEVE_MAX_GEO_CODE_VALUE = "SELECT max(TO_NUMBER(c.geo_code)) FROM "
			+ "sorusr.geo_unit_code c, sorusr.geo_unit g1, sorusr.geo_unit_assn a, sorusr.geo_unit g2 WHERE "
			+ "c.geo_code_typ_cd = ? and c.geo_unit_id = g1.geo_unit_id and g1.geo_unit_typ_cd = ? and "
			+ "g1.geo_unit_id = a.chld_geo_unit_id and a.prnt_geo_unit_id = g2.geo_unit_id and g2.geo_unit_typ_cd = ? "
			+ "and g2.geo_unit_id = ? group by c.geo_code_typ_cd";

	private static final String QUERY_RETRIEVE_MAX_COUNTRY_GEO_CODE_VALUE = "SELECT max(TO_NUMBER(geo_code)) FROM "
			+ "sorusr.geo_unit_code c, sorusr.geo_unit g1 WHERE c.geo_code_typ_cd = ? and "
			+ "c.geo_unit_id = g1.geo_unit_id and g1.geo_unit_typ_cd = 128 group by c.geo_code_typ_cd ";

	/**
	 * The setter method for the entity manager. The persistence context has
	 * been defined as part of the entity manager definition.
	 * 
	 * @param em
	 */
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}

	/**
	 * Inject DataSource properties to jdbcTemplate.
	 * 
	 * @param argDataSource
	 *            the new data source
	 */
	@Autowired
	@Qualifier("stgDataSource")
	public void setDataSource(DataSource argDataSource) {
		this.jdbcTemplate = new JdbcTemplate(argDataSource);
	}

	/**
	 * 
	 * The method will create the named query instance by setting the query
	 * parameters. The method is invoked for all name query operations.
	 * 
	 * @param sql
	 * @param parameters
	 * @return
	 */
	private Query createNamedQuery(String sql, Map<String, Object> parameters) {
		Query query = em.createNamedQuery(sql);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		return query;
	}

	/**
	 * The method will search for the geo units by name. The user will type in
	 * the filter condition in the name field and the dao layer will retrieve
	 * the names satisfying the filter
	 * 
	 * @param nameFilter
	 * @param langaugeCode
	 * @return geoUnitNames the list of geo names
	 */
	@SuppressWarnings("unchecked")
	public List<GeoUnitName> searchGeoUnitByName(String nameFilter,
			int startIndex, int maxResults, String sortBy, String sortOrder,
			Long langaugeCode) {
		LOGGER.info("entering GeoStagingDAOImpl | searchByName");

		sortBy = getNameColumnIndex(sortBy);
		String queryString = RETRIEVE_GEO_NAME_SEARCH + " order by " + sortBy
				+ " " + sortOrder;

		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("enLangCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		parameters.put("geoName", nameFilter);
		parameters.put("writingScriptCode",
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);

		Query query = em.createQuery(queryString);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		query.setFirstResult(startIndex);
		query.setMaxResults(maxResults);

		LOGGER.info("exiting GeoStagingDAOImpl | searchByName");
		try {
			return query.getResultList();
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will count the number of geo units filtered by name.
	 * 
	 * @param nameFilter
	 * @return Long count
	 */
	public Long countSearchGeoUnitByName(String nameFilter) {
		LOGGER.info("entering GeoStagingDAOImpl | countOfSearchGeoUnitByName");

		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("geoName", nameFilter);
		parameters.put("writingScriptCode",
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);

		Query query = em.createQuery(RETRIEVE_GEO_NAME_SEARCH_COUNT);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting GeoStagingDAOImpl | countOfSearchGeoUnitByName");
		try {
			return (Long) query.getSingleResult();
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will count the number of geo units filtered by code.
	 * 
	 * @param nameFilter
	 * @return Long count
	 */
	public Long countSearchGeoUnitByCode(String searchString) {
		LOGGER.info("entering GeoStagingDAOImpl | countSearchGeoUnitByCode");

		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		
		parameters.put("geoCode", searchString);
		

		Query query = em.createQuery(RETRIEVE_GEO_CODE_SEARCH_COUNT);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting GeoStagingDAOImpl | countSearchGeoUnitByCode");
		try {
			return (Long) query.getSingleResult();
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	private String getNameColumnIndex(String sortBy) {
		// Ordering by column name is not working.
		// Hence using columnIndex for the time being
		if (sortBy.equalsIgnoreCase("languageDescription")) {
			return "3";
		} else if (sortBy.equalsIgnoreCase("nameTypeDescription")) {
			return "4";
		} else {
			return "5";
		}
	}

	/**
	 * The method will search for the geo units by code. The user will type in
	 * the filter condition in the code field and the dao layer will retrieve
	 * the codes satisfying the filter
	 * 
	 * @param codeFilter
	 * @param langaugeCode
	 * @return geoUnitCodes the list of geo codes
	 */
	@SuppressWarnings("unchecked")
	public List<GeoUnitCode> searchGeoUnitByCode(String codeFilter,
			int startIndex, int maxResults, String sortBy, String sortOrder,
			Long languageCode) {
		LOGGER.info("entering GeoStagingDAOImpl | searchByCode");

		sortBy = getCodeColumnIndex(sortBy);
		String queryString = RETRIEVE_GEO_CODE_SEARCH + " order by " + sortBy
				+ " " + sortOrder;

		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("enLangCode",
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		parameters.put("geoCode", codeFilter);

		Query query = em.createQuery(queryString);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		query.setFirstResult(startIndex);
		query.setMaxResults(maxResults);
		List<GeoUnitCode> codeList = query.getResultList();
		String officialName = null;
		/** Code to check official name **/
		for (GeoUnitCode geoCodeList : codeList) {

			if (geoCodeList.getOfficialGeoName() == null) {
				officialName = getOfficialNameByGeoUnitId(geoCodeList
						.getGeoUnitId());
				geoCodeList.setOfficialGeoName(officialName);

			} else {

				geoCodeList
						.setOfficialGeoName(geoCodeList.getOfficialGeoName());
			}
		}

		LOGGER.info("exiting GeoStagingDAOImpl | searchByCode");
		try {
			return codeList;
			// return query.getResultList();

		} catch (PersistenceException ex) {
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@Override
	public String getOfficialNameByGeoUnitId(Long geoUnitId) {
		LOGGER.info("entering GeoStagingDAOImpl | getOfficialNameByGeoUnitId");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();

		StringBuffer qryStr = new StringBuffer(
				"SELECT distinct new GeoUnitName(n.geoName) FROM GeoUnitName n where n.geoUnitId = :geoUnitId and n.expirationDate is null and n.expiredByDate is null and n.nameTypeCode=32 and rownum=1");
		parameters.put("geoUnitId", geoUnitId);

		/*
		 * Execute the query by setting the parameters
		 */
		final String EMPTY_STRING = "";
		Query query = em.createQuery(qryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		try {

			GeoUnitName resultGeoUnit = (GeoUnitName) query.getSingleResult();
			if (resultGeoUnit != null) {

				return resultGeoUnit.getGeoName();
			} else {
				return EMPTY_STRING;
			}
		} catch (NoResultException ex) {
			ex.printStackTrace();
			return EMPTY_STRING;
		} catch (PersistenceException ex) {
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	private String getCodeColumnIndex(String sortBy) {
		// Ordering by column name is not working.
		// Hence using columnIndex for the time being
		if (sortBy.equalsIgnoreCase("geoCodeTypeDescription")) {
			return "2";
		} else if (sortBy.equalsIgnoreCase("geoCode")) {
			return "4";
		} else {
			return "5";
		}
	}

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 * 
	 * @param geoUnitId
	 */
	public GeoUnit retrieveGeoUnitByGeoUnitId(Long geoUnitId) {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveGeoUnitByGeoUnitId");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("geoUnitId", geoUnitId);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_GEOUNIT_BY_ID, parameters);
		LOGGER.info("exiting GeoStagingDAOImpl | retrieveGeoUnitByGeoUnitId");
		try {
			return (GeoUnit) query.getSingleResult();
		} catch (NoResultException ex) {
			return null;
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 * 
	 * @param geoUnitId
	 */
	public GeoUnit retrieveGeoUnitForDelete(Long geoUnitId) {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveGeoUnitForDelete");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("geoUnitId", geoUnitId);
		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_GEOUNIT_FOR_DELETE,
				parameters);
		LOGGER.info("exiting GeoStagingDAOImpl | retrieveGeoUnitForDelete");
		try {
			return (GeoUnit) query.getSingleResult();
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * Validates geoUnit to check for the existence of any child records for the
	 * corresponding geoUnit.
	 * <p>
	 * The soft delete operation on geoUnit will be dependent on the validation.
	 * <p>
	 * 
	 * @param geoUnitId
	 * @return the count of child geo unit associations
	 */
	@Override
	public Long validateGeoUnit(Long geoUnitId) {
		LOGGER.info("entering GeoStagingDAOImpl | validateGeoUnit");
		Query query = em
				.createNamedQuery(QUERY_VALIDATE_GEO_UNIT_ASSOCIATIONS_FOR_DELETE);
		query.setParameter(RefDataUIConstants.GEO_UNIT_ID_REQ_PARAM, geoUnitId);
		try {
			return (Long) query.getSingleResult();
		} catch (NoResultException ex) {
			return null;
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@SuppressWarnings("unchecked")
	@Cacheable(cacheName = "refdataCache")
	public List<CodeValueVO> retrieveAllCountries(Long nameType,
			Long languageCode) {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveAllCountries");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("nameTypeCode", nameType);
		parameters.put("langCode", languageCode);
		parameters.put("geoUnitTypeCode",
				RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY);
		parameters.put("writingScriptCode",
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);
		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_ALL_COUNTRIES, parameters);
		LOGGER.info("exiting GeoStagingDAOImpl | retrieveAllCountries");
		try {
			return mapCodeValueVO(query.getResultList());
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will retrieve all Continent details from the Search DB based
	 * on the name type code and the user preferred language code. The return
	 * type is a VO which contains the Continent Geo Unit Id and the Continent
	 * Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllContinents(Long nameType,
			Long languageCode) {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveAllContinents");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("nameTypeCode", nameType);
		parameters.put("langCode", languageCode);
		parameters.put("geoUnitTypeCode",
				RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_CONTINENT);
		parameters.put("writingScriptCode",
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_ALL_COUNTRIES, parameters);
		LOGGER.info("exiting GeoStagingDAOImpl | retrieveAllContinents");
		try {
			return mapCodeValueVO(query.getResultList());
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method to convert the geo unit entity object to a value object.
	 * 
	 * @param geoUnitNames
	 * @return
	 */
	private List<CodeValueVO> mapCodeValueVO(List<GeoUnitName> geoUnitNames) {
		LOGGER.info("entering GeoStagingDAOImpl | mapCodeValueVO");
		List<CodeValueVO> codeValueVOs = null;

		if (geoUnitNames != null) {
			codeValueVOs = new ArrayList<CodeValueVO>();
			for (GeoUnitName geoUnitName : geoUnitNames) {
				CodeValueVO codeValueVO = new CodeValueVO(
						geoUnitName.getGeoUnitId(), geoUnitName.getGeoName(),
						null);
				codeValueVOs.add(codeValueVO);
			}
		}
		LOGGER.info("exiting GeoStagingDAOImpl | mapCodeValueVO");
		return codeValueVOs;
	}

	/**
	 * 
	 * The method to identify the language
	 * 
	 * @param languageCode
	 * @param geoUnitType
	 * @param parentGeoUnitId
	 * @param nameType
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<CodeValueVO> retrieveChildGeoUnitsByType(Long languageCode,
			Long geoUnitType, Long parentGeoUnitId, Long nameType) {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveChildGeoUnitsByType");

		StringBuffer queryStr = new StringBuffer(
				QUERY_RETRIEVE_CHILD_GEO_BY_TYPE);
		List codeValueVOs = null;
		try {
			codeValueVOs = jdbcTemplate.query(queryStr.toString(),
					new Object[] { geoUnitType, parentGeoUnitId, languageCode,
							languageCode }, new RowMapper<CodeValueVO>() {

						@Override
						public CodeValueVO mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							CodeValueVO codeValueVO = new CodeValueVO();
							codeValueVO.setCode(rs.getLong("geo_unit_id"));
							codeValueVO.setValue(rs.getString("geo_nme"));
							return codeValueVO;
						}
					});
		} catch (NoResultException ex) {
			return null;
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return codeValueVOs;
	}

	/**
	 * This method will update given GeoUnit to Staging SoR DB. The return would
	 * be updated GeoUnit entity. The method is invoked when the business owner
	 * approves a request and the respective changes are to be updated from the
	 * Transaction DB to the Staging SoR.
	 * 
	 * @param GeoUnit
	 * @return status
	 */
	@Override
	public Boolean updateGeoUnit(GeoUnit geoUnit) {
		LOGGER.info("entering GeoStagingDAOImpl | updateGeoUnit");
		try {
			em.merge(geoUnit);

		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_MERGE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return true;
	}

	/**
	 * 
	 * The method will identify all child entities for the specified GeoUnit Id
	 * 
	 * @param geoUnitId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<GeoUnitAssociation> retrieveChildGeoUnitAssociations(
			Long geoUnitId) {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveChildGeoUnitAssociations");
		Query query = em.createNamedQuery(QUERY_RETRIEVE_CHILD_GEO_ASSOCIATION);
		query.setParameter("geoUnitId", geoUnitId);
		try {
			return query.getResultList();
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * The method will retrieve all Country Groups from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Group Geo Unit Id and the Country
	 * Names.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@SuppressWarnings("unchecked")
	public List<CodeValueVO> retrieveAllCountryGroups(Long nameType,
			Long languageCode) {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveAllCountryGroups");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("nameTypeCode", nameType);
		parameters.put("langCode", languageCode);
		parameters.put("geoUnitTypeCode",
				RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY_GROUP);
		parameters.put("writingScriptCode",
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = createNamedQuery(QUERY_RETRIEVE_ALL_COUNTRY_GROUPS,
				parameters);
		LOGGER.info("exiting GeoStagingDAOImpl | retrieveAllCountryGroups");
		try {
			return mapCodeValueVO(query.getResultList());
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * Retrieves the country groups corresponds to a group id / all the country
	 * groups.
	 * <p>
	 * The resulted List of Geo unit names will be used for displaying in the
	 * Country Group search results page.
	 * <p>
	 * 
	 * @param langCode
	 * @param writingScriptCode
	 * @param nameTypeCode
	 * @param geoUnitId
	 * @return a List of GeoUnitName
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<GeoUnitName> retrieveCountryGroups(Long langCode,
			Long writingScriptCode, Long nameTypeCode, Long geoUnitId) {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveCountryGroups");
		Query query = null;
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("nameTypeCode", nameTypeCode);
		parameters.put("langCode", langCode);
		parameters.put("writingScriptCode", writingScriptCode);
		if (geoUnitId.equals(0L)) {
			parameters
					.put("geoUnitTypeCode",
							RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY_GROUP);
			query = createNamedQuery(
					QUERY_RETRIEVE_ALL_GEO_UNITS_BY_COUNTRY_GROUP, parameters);
		} else {
			parameters.put("geoUnitId", geoUnitId);
			query = createNamedQuery(QUERY_RETRIEVE_GEO_UNITS_BY_COUNTRY_GROUP,
					parameters);
		}

		LOGGER.info("exiting GeoStagingDAOImpl | retrieveCountryGroups");
		try {
			return (List<GeoUnitName>) query.getResultList();
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@Override
	public String getOfficialNameByGeoUnitIdAndTypeCode(Long parentGeoUnitId,
			Long geoUnitId, Long geoUnitTypeCode) {
		LOGGER.info("entering GeoStagingDAOImpl | getOfficialNameByGeoUnitIdAndTypeCode");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();

		StringBuffer qryStr = new StringBuffer(
				"SELECT new GeoUnit(n.geoName) FROM GeoUnit g, ");
		if (!RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY
				.equals(geoUnitTypeCode)) {
			qryStr.append("GeoUnitAssociation a, ");
		}
		qryStr.append("GeoUnitName n ").append(
				"WHERE g.geoUnitId = n.geoUnitId and ");
		if (!RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY
				.equals(geoUnitTypeCode)) {
			qryStr.append("g.geoUnitId = a.childGeoUnitId and a.parentGeoUnitId = :parentGeoUnitId and ");
			parameters.put("parentGeoUnitId", parentGeoUnitId);
		}
		qryStr.append(
				"g.geoUnitTypeCode = :geoUnitTypeCode and n.languageCode = 39 and n.nameTypeCode = 32 ")
				.append("and n.geoUnitId = :geoUnitId");
		parameters.put("geoUnitId", geoUnitId);
		parameters.put("geoUnitTypeCode", geoUnitTypeCode);

		/*
		 * Execute the query by setting the parameters
		 */
		final String EMPTY_STRING = "";
		Query query = em.createQuery(qryStr.toString());
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		try {
			GeoUnit resultGeoUnit = (GeoUnit) query.getSingleResult();
			if (resultGeoUnit != null) {
				return resultGeoUnit.getOfficialGeoName();
			} else {
				return EMPTY_STRING;
			}
		} catch (NoResultException ex) {
			return EMPTY_STRING;
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<GeoUnit> retrieveGeoUnitsByIdList(List<Long> geoUnitIds) {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveGeoUnitsByIdList");
		/*
		 * Set the parameters for the named query to retrieve geo unit by name
		 */
		List<Long> longGeoUnitIdList = new ArrayList<Long>();
		// parameter is coming in as Integer. Looks like and issue at
		// httpendpoint side.
		// Hence converting back to long.
		for (int index = 0; index < geoUnitIds.size(); index++) {
			Object currentObject = geoUnitIds.get(index);
			if (currentObject instanceof java.lang.Integer) {
				Integer currentInt = (Integer) currentObject;
				longGeoUnitIdList.add(currentInt.longValue());
			} else {
				longGeoUnitIdList.add((Long) currentObject);
			}
		}
		LOGGER.info("GeoStagingDAOImpl | retrieveGeoUnitsByIdList | longGeoUnitIdList "
				+ longGeoUnitIdList);

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("geoUnitIdList", longGeoUnitIdList);
		parameters.put("nameTypeCode",
				RefDataPropertiesConstants.CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL);

		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em
				.createNamedQuery(QUERY_RETRIEVE_GEO_UNIT_LIST_BY_ID_LIST);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}

		LOGGER.info("exiting GeoStagingDAOImpl | retrieveGeoUnitsByIdList");
		try {
			return (List<GeoUnit>) query.getResultList();
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * the method to return all geoUnit Types
	 * 
	 * @return
	 */
	@Override
	@Cacheable(cacheName = "refdataCache")
	public List<CodeValue> retrieveAllGeoUnitTypes() {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveAllGeoUnitTypes");

		return formRetrieveAllQuery(
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH,
				RefDataPropertiesConstants.CODE_TABLE_ID_GEO_UNIT_TYPE,
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN,
				QUERY_RETRIEVE_ALL_GEO_UNIT_TYPES);
	}

	/**
	 * 
	 * The method to retrieve all applicable GeoUnit Names
	 * 
	 * @return
	 */
	@Cacheable(cacheName = "refdataCache")
	public List<CodeValue> retrieveApplicableGeoNameTypes() {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveApplicableGeoNameTypes");

		return formRetrieveAllQuery(
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH,
				RefDataPropertiesConstants.CODE_TABLE_ID_GEO_NAME_TYPE,
				RefDataPropertiesConstants.CODE_WRITING_SCRIPT_LATIN,
				QUERY_RETRIEVE_ALL_GEO_NAME_TYPES);
	}

	/**
	 * 
	 * The common method for retrieve all products
	 * 
	 * @param languageCode
	 * @param codeTableId
	 * @param writingScriptCode
	 * @param queryStr
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<CodeValue> formRetrieveAllQuery(Long languageCode,
			Integer codeTableId, Long writingScriptCode, String queryStr) {
		/*
		 * Set the parameters for the named query to retrieve geo unit types
		 */
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("languageCode", languageCode);
		parameters.put("codeTableId", codeTableId);
		parameters.put("writingScriptCode", writingScriptCode);
		/*
		 * Execute the query by setting the parameters
		 */
		Query query = em.createNamedQuery(queryStr);
		for (Entry<String, ?> parameter : parameters.entrySet()) {
			query.setParameter(parameter.getKey(), parameter.getValue());
		}
		try {
			return query.getResultList();
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method will return the max value for the next geo unit id. When we
	 * add new country Geo Unit, we need to follow the below given logic for
	 * creating the geo unit id (both transactional and batch) 1. New Country
	 * Geo Unit ID - Max 4 digit + 1 2. New Country Group Geo Unit ID - Max 7
	 * digit + 1
	 * 
	 * @param geoUnitTypeCode
	 * @return geoUnitId
	 */
	@Override
	public Long retrieveMaxGeoUnitId(Long geoUnitTypeCode) {
		LOGGER.info("entering GeoTransactionalDAOImpl | retrieveMaxGeoUnitId ");
		LOGGER.info("GeoTransactionalDAOImpl | retrieveMaxGeoUnitId | geoUnitTypeCode : "
				+ geoUnitTypeCode);

		String sequence = "GEO_UNIT_ID_SEQ";
		if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY
				.equals(geoUnitTypeCode)) {
			sequence = "GEO_CTRY_UNIT_ID_SEQ";
		} else if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY_GROUP
				.equals(geoUnitTypeCode)) {
			sequence = "GEO_CTRY_GRP_UNIT_ID_SEQ";
		}
		LOGGER.info("GeoTransactionalDAOImpl | retrieveMaxGeoUnitId | sequence : "
				+ sequence);

		try {
			return jdbcTemplate.queryForLong("SELECT SORUSR." + sequence
					+ ".nextval from dual");
		} catch (NoResultException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_NOT_FOUND, ex);
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
	}

	/**
	 * 
	 * The method will get the maximum value of of the specified GeoCode Type.
	 * 
	 * @param geoCodeTypeCode
	 * @param geoUnitTypeCode
	 * @param uniqueWithInGeoUnitTypeCode
	 * @param uniqueWithInGeoUnitId
	 * @return wbCode
	 */
	public String findMaxValueOfGeoCode(Long geoCodeTypeCode,
			Long geoUnitTypeCode, Long uniqueWithInGeoUnitTypeCode,
			Long uniqueWithInGeoUnitId) {
		LOGGER.info("entering GeoStagingDAOImpl | findMaxValueOfGeoCode");
		StringBuffer queryStr = new StringBuffer(
				QUERY_RETRIEVE_MAX_GEO_CODE_VALUE);
		String maxGeoCode = null;
		try {
			maxGeoCode = jdbcTemplate
					.queryForObject(queryStr.toString(),
							new Object[] { geoCodeTypeCode, geoUnitTypeCode,
									uniqueWithInGeoUnitTypeCode,
									uniqueWithInGeoUnitId }, String.class);
		} catch (NoResultException ex) {
			return "0";
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return maxGeoCode;
	}

	/**
	 * 
	 * The method will find the next WB code based on the configuration
	 * mentioned in the GeoCodeConfiguration entity. This method will return the
	 * next code to be assigned for a Country.
	 * 
	 * @param geoCodeTypeCode
	 * @return wbCode
	 */
	public String findMaxValueOfCountryGeoCode(Long geoCodeTypeCode) {
		LOGGER.info("entering GeoStagingDAOImpl | findMaxValueOfGeoCode");
		StringBuffer queryStr = new StringBuffer(
				QUERY_RETRIEVE_MAX_COUNTRY_GEO_CODE_VALUE);
		String maxGeoCode = null;
		try {
			maxGeoCode = jdbcTemplate.queryForObject(queryStr.toString(),
					new Object[] { geoCodeTypeCode }, String.class);
		} catch (NoResultException ex) {
			return "0";
		} catch (PersistenceException ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
		} catch (Exception ex) {
			throw new ReferenceDataExceptionVO(
					RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
		}
		return maxGeoCode;
	}
}
