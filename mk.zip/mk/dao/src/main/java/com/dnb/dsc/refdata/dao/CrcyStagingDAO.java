/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.entity.GeoCurrency;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.CurrencySearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.GeoCurrencySearchVO;

/**
 * This is used as the DAO interface for the Currency Exchange operations
 * 
 * @author Cognizant
 * @version last updated : Mar 02, 2012
 * @see
 * 
 */
public interface CrcyStagingDAO {	
	/**
	 * 
	 * Performs a hierarchy search of Currency Exchange on the search db.<p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param currencySearchCriteria
	 * @return list of CurrencyExchange
	 */
	List<CurrencyExchange> searchCurrencyExchange(CurrencySearchCriteriaVO currencySearchCriteria);

	/**
	 * The method to retrieve all data providers for the currency exchange data.
	 * The data will be fetched from the currency exchange tables.
	 * 
	 * @param languageCode
	 */
	List<CodeValueVO> retrieveCurcyExchDataProviders(Long languageCode);
	
	/**
	 * 
	 * The method will count the records in the name search of currency units on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchString
	 * @return countResults
	 */
	Long countSearchCurrencyExchange(CurrencySearchCriteriaVO searchCriteriaVO);
	
	/**
	 * Searches the Staging SoR for the CurrencyExchange based on the currencyExchangeId
	 *  and will return the CurrencyExchange entity.<p>
	 * 
	 * @param currencyExchangeId
	 * @return CurrencyExchange
	 */
	CurrencyExchange retrieveCurrencyExchangeByCurrencyExchangeId(Long currencyExchangeId);
	
	/**
	 * This method will update given exchangeRate to Transaction DB. The return would be
	 * updated CurrencyExchange entity
	 * 
	 * @param 
	 * @return GeoUnit
	 */	
	CurrencyExchange updateExchangeRate(CurrencyExchange currencyExchange);

	/**
	 * @param geoCurrencySearchVO
	 * @return
	 */
	List<GeoCurrency> searchGeoCurrency(
			GeoCurrencySearchVO geoCurrencySearchVO);

	/**
	 * 
	 * The method will count the records in the geo currency table based on
	 * user inputs in db. The search will be done on the SOR db based on
	 * the search criteria the user had provided.
	 * 
	 * @param geoCurrencySearchCriteria
	 * @return countResults
	 */
	Long countSearchGeoCurrency(GeoCurrencySearchVO geoCurrencySearchVO);

	/**
	 * To retrieve the next value of the Geo Currency Id using the sequence
	 */
	Long retrieveMaxGeoCurrencyId();

	/**
	 * This method will Add given Geo Currency to SOR DB. The return would be
	 * updated GeoCurrency entity
	 * 
	 * @param 
	 * @return geoCurrency
	 */	
	GeoCurrency insertGeoCurrency(GeoCurrency geoCurrency);
	
	GeoCurrency retrieveGeoCurrencyByGeoCurrencyId(Long geoCurrencyId);

	GeoCurrency updateGeoCurrency(GeoCurrency geoCurrency);
}
