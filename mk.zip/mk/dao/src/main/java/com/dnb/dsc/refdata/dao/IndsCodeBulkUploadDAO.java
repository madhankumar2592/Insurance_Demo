/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;


import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.vo.IndusCodeBulkUploadMasterVO;
import com.dnb.dsc.refdata.core.vo.IndusCodeBulkUploadVO;

/**
* DAO interface class for the Industry Bulk upload Batch operations.
* <p>
* 
* The DAO contacts the staging DB for all its operations.
* <p>
* 
* @author Cognizant
* @version last updated : May 28, 2012
* @see
* 
*/
public interface IndsCodeBulkUploadDAO {
	/**
	 * 
	 *  The method to save the industry map
	 *
	 * @param mapList
	 */
	public void saveMap(List<? extends IndusCodeBulkUploadVO> mapList,Long fromTypCd,Long toTypCd,String userId);
	
	/**
	 * 
	 *  The method to save the industry code
	 *
	 * @param indusCodeBulkUploadList
	 */
	public void saveIndsCode(List<? extends IndusCodeBulkUploadMasterVO> indusCodeBulkUploadList,String userId);
	
	/**
	 * The method to get code value list
	 * 
	 * 
	 */
	public List<CodeValue> getCodeValueList();
	
	/**
	 * The method to check unique inds code
	 * 
	 * 
	 */
	public boolean isUniqueIndsCode(String indsCode,Long indsCodeTypCode);
	/**
	 * The method to check inds code id availabilty
	 * 
	 * 
	 */
	public boolean isIndsCodeAvail(Long indsCodeId);
	/**
	 * The method to check unique inds code desc id availabilty
	 * 
	 * 
	 */
	public boolean isIndsCodeDescAvail(Long indsCodeDescId);
	
	/**
	 * The method to check from inds code valid
	 * 
	 * 
	 */
	public boolean isMapValid(Long indsCodeId,String indsCode,Long indsCodeTypCode);
	
	/**
	 * The method to check from inds code valid
	 * 
	 * 
	 */
	public boolean isMapValidWithoutId(String indsCode,Long indsCodeTypCode);
	
	/**
	 * The method to check prefered map indicator valid
	 * 
	 * 
	 */
	public boolean isPrfdIndcValid(Long fromIndsCodeId,Long toIndsCodeTypCode);
	
	public Long generateIndsCodeId();
	
	
	

}
