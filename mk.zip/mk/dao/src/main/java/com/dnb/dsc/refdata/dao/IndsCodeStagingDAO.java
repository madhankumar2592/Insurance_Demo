/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.dao;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.InduscodeMappingBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.IndustryCodesSearchCriteriaVO;

/**
 * This is used as the DAO interface for the Industry Code operations
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
public interface IndsCodeStagingDAO {
	
	/**
	 * Performs a hierarchy search of Industry Codes on the search db.<p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.<p>
	 * 
	 * @param industryCodesSearchCriteria
	 * @return a list of IndustryCode
	 */
	List<IndustryCode> searchIndustryCodes(IndustryCodesSearchCriteriaVO industryCodesSearchCriteria);
	
	/**
	 * The method will retrieve Industry code CrossWalks for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 * 
	 * @param industryCodeTypeCode
	 * @return list of codeValueVO
	 */
	List<CodeValueVO> retrieveCrossWalksForIndsCodeType(Long industryCodeTypeCode);
	
	/**
	 * The method will retrieve description for Industry code and type code. 
	 * 
	 * @param industryCodeTypeCode
	 * @param industryCode
	 * @return description
	 */
	String retrieveDescriptionForIndsCodeTypeCode(Long industryCodeTypeCode, String industryCode);
	
	Long retrieveIndustryCodeIdByCodeTypeCode(Long industryCodeTypeCode, String industryCode);
	/**
	 * 
	 * The method will count the records in the name search of industry codes on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchString
	 * @return countResults
	 */
	Long countSearchIndustryCodes(IndustryCodesSearchCriteriaVO industryCodesSearchCriteria);

	/**
	 * The method will search the Staging SoR for the IndustryCode based on the 
	 * industryCodeId and will return the IndustryCode entity.
	 * 
	 * @param industryCodeId
	 */
	IndustryCode retrieveIndustryCodeByIndustryCodeId(Long industryCodeId);

	/**
	 * The method will retrieve Industry code Group Levels for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 * 
	 * @param industryCodeTypeCode
	 * @param session
	 * @return list of codeValueVO
	 */
	List<CodeValueVO> retrieveGroupLevelCodes(Long industryCodeTypeCode, Long languageCode);
	
	/**
	 * 
	 * The method will fetch the language codes available for the selected
	 * Industry Code Type. The method will be invoked when the user selects the
	 * Industry Code type value.
	 * 
	 * @param industryCodeTypeCode
	 * @param groupLevelCodes
	 * @return list of codeValueVO
	 */
	List<CodeValueVO> retrieveIndustryCodeLanguages(
			Long industryCodeTypeCode, List<Long> groupLevelCodes);
	
	/**
	 * This method will update given GeoUnit to Staging SoR DB. The return would
	 * be updated GeoUnit entity. The method is invoked when the business owner
	 * approves a request and the respective changes are to be updated from the
	 * Transactional DB to the Staging SoR.
	 * 
	 * @param GeoUnit
	 * @return status
	 */
	Boolean updateIndustryCode(IndustryCode industryCode);
	
	/**
	 * The method will remove the industryCode data from the Staging DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param industryCodeId
	 * @param boolean indicating the status
	 */
	void removeApprovedIndustryCodeFromStaging(Long industryCodeId);
	/**
	 * 
	 * The method to remove the deleted Industry Code Descriptions from the Staging DB
	 *
	 * @param industryCodeDescriptionId
	 */
	void removeIndustryCodeDescription(Long industryCodeDescriptionId);
	/**
	 * 
	 * The method to remove the deleted Industry Code Map from the Staging DB
	 *
	 * @param fromIndustryCodeId
	 * @param toIndustryCodeId
	 */
	void removeIndustryCodeMap(Long fromIndustryCodeId, Long toIndustryCodeId);
	/**
	 * This method counts the IndustryCodeDescription  in the Staging DB to identify any duplicates
	 *
	 * @param industryCodeId
	 * @param industryCodeTypeCode
	 * @param industryDescription
	 * @return count
	 */
	public int countIndustryCodeDescriptionForDuplicate(String industryCodeId,
			Long industryCodeTypeCode,String industryDescription);

	/**
	 * This method will retrieve all the crosswalks available with respective count of each crosswalk
	 * @return
	 */
	List<InduscodeMappingBulkDownloadVO> retrieveCrosswalkDetails();
}
