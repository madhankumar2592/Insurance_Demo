package com.dnb.dsc.refdata.service.endpoint;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GlobalElement;
import com.dnb.dsc.refdata.core.entity.GloblalElementCrossWalk;
import com.dnb.dsc.refdata.core.vo.AddCrosswalkVO;
import com.dnb.dsc.refdata.core.vo.AddGlobalElementVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementCrosswalkSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementVO;
import com.dnb.dsc.refdata.service.GlobalElementService;

@Controller
public class GlobalElementHttpEndpoint {
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GlobalElementHttpEndpoint.class);
	
	@Autowired
	private GlobalElementService globalElementService;
	
		
	
	/**
	 * 
	 * The method will retrieve all Hints
	 * 
	 * @return Hints List
	 */
	@RequestMapping(value = "/retrieveHints.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<GlobalElementVO> retrieveHints() {
		LOGGER.info("entering GlobalElementHttpEndpoint | retrieveTopics");
		return globalElementService.retrieveHints();
	}
	
	
	/**
	 * 
	 * The method will retrieve all Hints
	 * 
	 * @return Hints List
	 */
	@RequestMapping(value = "/retrieveHintsDesc.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<GlobalElementVO> retrieveHintsDesc() {
		LOGGER.info("entering GlobalElementHttpEndpoint | retrieveTopics");
		return globalElementService.retrieveHintsDesc();
	}
		
	@RequestMapping(value = "/countAllSearchBkp.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchTopicsBkp(
			@RequestBody GlobalElementSearchVOBkp globalElementSearchVO) {
		return globalElementService.countSearchTopicsBkp(globalElementSearchVO);
	}
	
	@RequestMapping(value = "/allSearchResultBkp.service", method = RequestMethod.POST)
	public @ResponseBody
	List<GlobalElement> searchByTopicsBkp(
			@RequestBody GlobalElementSearchVOBkp globalElementSearchVO)throws Exception {
		
		return globalElementService.searchByTopicsBkp(globalElementSearchVO);
		
	}	
	
	@RequestMapping(value = "/insertGlobalElement.service", method = RequestMethod.POST)
	public @ResponseBody
	Long insertGlobalElement(@RequestBody AddGlobalElementVO addGlobalElementVO) {
		LOGGER.info("entering GlobalElementHttpEndpoint | insertGlobalElement");
		LOGGER.info("exiting GlobalElementHttpEndpoint | insertGlobalElement");
		return globalElementService.insertGlobalElement(addGlobalElementVO);
	}

		
	/**
	 * 
	 * The method will retrieve all Element details
	 * 
	 * @return Element
	 */
	
	@RequestMapping(value = "/retrieveGlobalELement.service", method = RequestMethod.POST)
	public @ResponseBody
	AddGlobalElementVO retrieveGlobalElement(@RequestBody AddGlobalElementVO addGlobalElementVO) {
		LOGGER.info("entering GlobalElementHttpEndpoint | retrieveGlobalELement.service");
		return globalElementService.retrieveGlobalElement(addGlobalElementVO);
	}
	
	@RequestMapping(value = "/retrieveGlobalELementCrosswalk.service", method = RequestMethod.POST)
	public @ResponseBody
	AddCrosswalkVO retrieveGlobalElementCrosswalk(@RequestBody AddCrosswalkVO addGlobalElementVO) {
		LOGGER.info("entering GlobalElementHttpEndpoint | retrieveGlobalELement.service");
		return globalElementService.retrieveGlobalElementCrosswalk(addGlobalElementVO);
	}
	
	@RequestMapping(value = "/editGlobalElement.service", method = RequestMethod.POST)
	public @ResponseBody
	Long editGlobalElement(@RequestBody AddGlobalElementVO addGlobalElementVO) {
		LOGGER.info("entering GlobalElementHttpEndpoint | editGlobalElement.service");
		LOGGER.info("exiting GlobalElementHttpEndpoint | editGlobalElement.service");
		return globalElementService.editGlobalElement(addGlobalElementVO);
	}
	
	@RequestMapping(value = "/{globalElementName}/isDuplicateElementName.service", method = RequestMethod.GET)
	public @ResponseBody
	Boolean isDuplicateElementName(@PathVariable("globalElementName") String globalElementName) {
		LOGGER.info("entering GlobalElementHttpEndpoint | isDuplicateElementName");		
		LOGGER.info("entering GlobalElementHttpEndpoint | isDuplicateElementName | glblEleName" +globalElementName);	
		LOGGER.info("exiting GlobalElementHttpEndpoint | isDuplicateElementName");
		return globalElementService.isDuplicateElementName(globalElementName);
	}
	
	@RequestMapping(value = "/{globalElementId}/retrieveGlobalElement.service", method = RequestMethod.GET)
	public @ResponseBody
	String retrieveGlobalElement(@PathVariable("globalElementId") Long globalElementId) {
		LOGGER.info("entering GlobalElementHttpEndpoint | retrieveGlobalElement");		
		LOGGER.info("entering GlobalElementHttpEndpoint | retrieveGlobalElement | elementID" +globalElementId);	
		LOGGER.info("exiting GlobalElementHttpEndpoint | retrieveGlobalElement");
		return globalElementService.retrieveGlobalElement(globalElementId);
	}
	

	@RequestMapping(value = "/checkGlblEleCrswlkId.service", method = RequestMethod.POST)
	public @ResponseBody
	Long checkGlblEleCrswlkId(@RequestBody GloblalElementCrossWalk crosswlk) {
		LOGGER.info("entering GlobalElementHttpEndpoint | editGlobalElement.service");
		LOGGER.info("exiting GlobalElementHttpEndpoint | editGlobalElement.service");
		return globalElementService.checkGlblEleCrswlkId(crosswlk);
	}
	
	@RequestMapping(value = "/{globalElementPlatformCode}/retrievePlatformDetails.service", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody 
	List<AddCrosswalkVO> retrievePlatformDetails(@PathVariable("globalElementPlatformCode") Long globalElementPlatformCode) {
		LOGGER.info("entering GlobalElementHttpEndpoint | retrievePlatformDetails.service");
		LOGGER.info("exiting GlobalElementHttpEndpoint | retrievePlatformDetails.service");
		List<AddCrosswalkVO> addCrosswalkVO = globalElementService.retrievePlatformDetails(globalElementPlatformCode);
		
		return addCrosswalkVO;
		
	}
	
	@RequestMapping(value = "/addNewCrosswalk.service", method = RequestMethod.POST)
	public @ResponseBody
	Long addNewCrosswalk(@RequestBody AddCrosswalkVO addCrosswalkVO) {
		LOGGER.info("entering GlobalElementHttpEndpoint | addNewCrosswalk");
		LOGGER.info("GlobalElementPlatformCode : " + addCrosswalkVO.getGlobalElementPlatformCode());
		LOGGER.info("exiting GlobalElementHttpEndpoint | addNewCrosswalk");		
		return globalElementService.addNewCrosswalk(addCrosswalkVO);
	}
	
	@RequestMapping(value = "/allCrosswalkSearchResult.service", method = RequestMethod.POST)
	public @ResponseBody
	List<GloblalElementCrossWalk> searchByCrosswalk(
			@RequestBody GlobalElementCrosswalkSearchVOBkp globalElementSearchVO)throws Exception {
		return globalElementService.crosswalkSearch(globalElementSearchVO);
	}
	
	
	@RequestMapping(value = "/{crosswalkApplied}/retrieveSearchCrossWalkCodeType.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveCrossWalksForIndsCodeType(
			@PathVariable("crosswalkApplied") Long crosswalkAppliedCode) {
	
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | retrieveCrossWalksForIndsCodeType");
		List<CodeValue> codeValueVOs = globalElementService
				.retrieveSearchCrossWalkCodeType(crosswalkAppliedCode);

		LOGGER.info("codeValueVOs : " + codeValueVOs);
		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | retrieveCrossWalksForIndsCodeType");
		return codeValueVOs;
	}
	
	@RequestMapping(value = "/countCrosswalkSearchResult.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countCrosswalkSearch(
			@RequestBody GlobalElementCrosswalkSearchVOBkp globalElementCrosswalkSearchVOBkp) {
		return globalElementService.countCrosswalkSearch(globalElementCrosswalkSearchVOBkp);
	}
	
	@RequestMapping(value = "/{globalElementPlatformCode}/{globalElementId}/retrievePlatformDetails.service", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody 
	List<AddCrosswalkVO> retrieveEditPlatformDetails(@PathVariable("globalElementPlatformCode") Long globalElementPlatformCode,
			@PathVariable("globalElementId") Long globalElementId) {
		LOGGER.info("entering GlobalElementHttpEndpoint | retrievePlatformDetails.service");
		LOGGER.info("exiting GlobalElementHttpEndpoint | retrievePlatformDetails.service");
		List<AddCrosswalkVO> addCrosswalkVO = globalElementService.retrieveEditPlatformDetails(globalElementPlatformCode,globalElementId);
		
		return addCrosswalkVO;
		
	}
	
	/**
	 * 
	 * The method will retrieve all Code Tables
	 * 
	 * @return Topics List
	 */
	
	@RequestMapping(value = "/retrievePlatformList.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<GloblalElementCrossWalk> retrievePlatformList() {
		LOGGER.info("entering GlobalElementHttpEndpoint | retrievePlatformList");
		return globalElementService.retrievePlatformList();
	}
	
	@RequestMapping(value = "/unMappedElementCount.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<GlobalElement> unMappedElementCount() {
		LOGGER.info("entering GlobalElementHttpEndpoint | unMappedElementCount");
		return globalElementService.unMappedElementCount();
	}
	
	@RequestMapping(value = "/totalUnMappedElementCount.service", method = RequestMethod.POST)
	public @ResponseBody
	Long totalUnMappedElementCount(
			@RequestBody GloblalElementCrossWalk globlalElementCrossWalk) {
		return globalElementService.totalUnMappedElementCount(globlalElementCrossWalk);
	}
	
	@RequestMapping(value = "/retrieveGroupName.service", method = RequestMethod.POST)
	public @ResponseBody
	Long retrieveGroupName(@RequestBody String groupName) {
		LOGGER.info("entering GlobalElementHttpEndpoint | retrieveGlobalELement.service");
		return globalElementService.retrieveGroupName(groupName);
	}
	
	@RequestMapping(value = "/{globalElementCrosswalkGrpNme}/{globalElementId}/retrieveGroupName.service", method = RequestMethod.GET)
    public @ResponseBody
    Long retrieveGroupName(@PathVariable("globalElementCrosswalkGrpNme") String groupName,@PathVariable("globalElementId") Long globalElementId) {
          LOGGER.info("entering GlobalElementHttpEndpoint | retrieveGroupName.service");
          return globalElementService.retrieveGroupName(groupName,globalElementId);
    }

}
