/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.SCoTSSearchCriteriaVO;

/**
 * This is used as the services interface for the SCoTS operations
 *
 * @author Cognizant
 * @version last updated : Feb 2, 2012
 * @see
 *
 */
public interface SCoTsService {

	/**
	 *
	 * The method will retrieve the SCoTS data for all the tables given as
	 * parameter from the Staging SoR. The input will be list of Code Table IDs
	 * and the user preferred language. The return will be a map with key as
	 * Code table ID and value as list of CodeValue. The method is invoked to
	 * populate the following drop downs in Add Geo Unit UI: - Geo Unit Type -
	 * Name Type - Language - Data Provider - Code Type
	 *
	 * @param codeTableIds
	 * @param langaugeCode
	 * @return
	 */
	Map<Long, List<CodeValue>> retrieveCodeValues(
			List<Long> codeTableIds, Long langaugeCode);
	Map<Long, List<CodeValue>> retrieveCodeValuesScr(
			List<Long> codeTableIds, Long langaugeCode);
	/**
	 *
	 * The method will perform the table search of SCoTS Code Tables on the
	 * search db.
	 * <p>
	 *
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 *
	 * @param SCoTSSearchCriteriaVO
	 * @return list of CodeValue
	 */
	List<CodeTable> searchCodeTables(SCoTSSearchCriteriaVO searchCriteriaVO);

	/**
	 *
	 * The method will count the records in the hierarchy search of code tables
	 * on the search db. The search will be done on the flat db based on the
	 * search criteria the user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return count of search results
	 */
	Long countSearchCodeTables(SCoTSSearchCriteriaVO searchCriteriaVO);

	/**
	 * The method will retrieve all Code Tables from the Search DB . The return
	 * type is a VO which contains the Code Table Id and the Code Table Names.
	 *
	 */
	List<CodeValueVO> retrieveCodeTableList();

	/**
	 * The method will retrieve all Code Languages from the Search DB . The
	 * return type is a VO which contains the Code Value Id and the COde Value
	 * Description (language names).
	 *
	 */
	List<CodeValueVO> retrieveCodeLanguages();

	/**
	 * The method will retrieve all systems applicable from the Search DB . The
	 * return type is a VO which contains the DNB system code and the Code Value
	 * Description.
	 *
	 * @param codeTableId
	 * @return list fo CodeValueVO
	 */
	 List<SystemApplicability> retrieveSystemApplicability(Long codeTableId, int applicabilityIndicator);

	@SuppressWarnings("rawtypes")
	List retrieveSystemForCode(String applicability, Long applicabilityCode, Boolean isStagingDB);

	List<CodeValueVO> retrieveAllSystemApplicability(String applicability);

	/**
	 * The method will retrieve all countries applicable from the Search DB .
	 * The return type is a VO which contains the DNB system code and the Code
	 * Value Description.
	 *
	 * @param codeTableId
	 * @return list of CodeValueVO
	 */
	public List<CountryApplicability> retrieveCountryApplicability(Long codeTableId, int applicabilityIndicator);

	/**
	 *
	 * The method to find the CodeTable entity by the primary key codeTableId
	 *
	 * @param codeTableId
	 * @return CodeTable entity
	 */
	CodeTable retrieveCodeTableById(Long codeTableId);

	/**
	 *
	 * The method to find the CodeTable entity by the primary key codeTableId
	 * from Transaction DB
	 *
	 * @param codeTableId
	 * @return CodeTable entity
	 */
	CodeTable reviewCodeTableChanges(Long codeTableId);

	/**
	 *
	 * The method to find the CodeValue entity by the primary key codeValueId
	 * from Transaction DB
	 *
	 * @param codeValueId
	 * @return CodeTable entity
	 */
	CodeValue reviewCodeValueChanges(Long codeValueId);

	/**
	 *
	 * The method to fetch the details of codeValues based on the codeTableId.
	 * The filter will also contain the language code, system applicability code
	 * and country applicability code.
	 *
	 * @param searchCriteriaVO
	 * @return list of codeValues
	 */
	List<CodeValue> retrieveCodeValuesByTableId(SCoTSSearchCriteriaVO searchCriteriaVO);

	/**
	 *
	 * The method to count the results of codeValues based on the codeTableId.
	 * The filter will also contain the language code, system applicability code
	 * and country applicability code.
	 *
	 * @param searchCriteriaVO
	 * @return count of codeValues
	 */
	Long countCodeValuesByTableId(SCoTSSearchCriteriaVO searchCriteriaVO);

	/**
	 *
	 * The method to fetch the count of Code Value details based on the filter
	 * condition. The Code Value will be searched based on description or on the
	 * business description.
	 *
	 * @param searchCriteriaVO
	 * @return countCodeValues
	 */
	Long countOfSearchCodeValues(SCoTSSearchCriteriaVO searchCriteriaVO);

	/**
	 *
	 * The method to fetch the Code Value details based on the filter condition.
	 * The Code Value will be searched based on description or on the business
	 * description.
	 *
	 * @param searchCriteriaVO
	 * @return codeValues
	 */
	List<CodeValue> searchCodeValues(SCoTSSearchCriteriaVO searchCriteriaVO);

        /**
	 * Retrieves CodeValue entity by codeValueId. <p>
	 *
	 * @param codeValueId
	 * @return CodeValue
	 */
	CodeValue retrieveCodeValueByCodeValueId(Long codeValueId);

	/**
	 *
	 * The method to retrieve all codeValue associations from database. The
	 * method will accept the parent and child code table Id s and will return
	 * all associations having the relationship between the specified parent and
	 * child code tables.
	 *
	 * @param parentCodeTableId
	 * @param childCodeTableId
	 * @return List<CodeValueAssociation>
	 */
	List<CodeValueAssociation> retrieveCodeValueAssociations(
			Long parentCodeTableId, Long childCodeTableId, Boolean isStagingDB);

	/**
	 *
	 * The method to retrieve all alternate schema code types from the database.
	 * The method will be invoked as a web-service to retrieve the data.
	 *
	 * @return List<CodeValueVO>
	 */
	List<CodeValueVO> retrieveAllAlternateSchemeCodes();

	/**
	 *
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the staging
	 * DB to fetch all alternate scheme codes matching the scheme type code
	 * selected by the user.
	 *
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	List<CodeValueAlternateScheme> retrieveAlternateSchemeCodes(Long schemeTypeCode);

         /**
	 * The method will persist the existing Code Table data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	Long updateCodeTable(CodeTable codeTable);

	/**
	 * The method will persist the existing codeValue data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeValue
	 */
	Long updateCodeValue(CodeValue codeValue);

	/**
	 * The method will validate the Code Table for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param codeTableId
	 */
	String lockCodeTable(Long codeTableId);


	/**
	 * The method will validate the Code Value for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param codeValueId
	 */
	
	String lockCodeValue(Long codeValueId);


	
	/**
	 * The method will validate the Alternate Scheme Codes for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param alternateSchemeTypeCode
	 */
	String lockAltSchemeCode(Long alternateSchemeTypeCode);


	/**
	 *
	 * The method to find the CountryApplicability entity by the  CodeTable
	 *
	 * @param codeValueDescription
	 * @return CountryApplicability entity
	 */
	CountryApplicability retrieveCountryByCodeTable(String codeValueDescription);

	Long updateApplicability(CodeTable systemApplicabilityList, Boolean isSystemApplicability);

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 *
	 * @param domainId
	 * @return isSaveSuccess
	 */
	Long saveApprovedCodeTable(Long domainId);


	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 *
	 * @param domainId
	 * @return isSaveSuccess
	 */
	Long saveApprovedCodeValue(Long domainId);
	
	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 *
	 * @param domainId
	 * @return isSaveSuccess
	 */
	Long saveApprovedCodeValueAlternateScheme(Long domainId);
	
	/**
	 * The method will remove the codeTable data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param codeTableId
	 */
	void removeApprovedCodeTable(Long codeTableId);
	/**
	 * The method will remove the codeValue data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param codeValueId
	 */
	void removeApprovedCodeValue(Long codeValueId);
	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 *
	 * @param domainId
	 * @param changeTypeId
	 * @return isSaveSuccess
	 */

	Long saveApprovedApplicabilities(Long domainId, Long changeTypeId);
	/**
	 * The method will remove the codeTable data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param codeTableId
	 * @param changeTypeId
	 */
	void removeApprovedTxnApplicabilities(Long codeTableId, Long changeTypeId);

    /**
	 * The method will persist the existing CodeValueAssociation in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	Long updateCodeValueAssociation(SCoTSSearchCriteriaVO sCoTSSearchCriteriaVO);
	
	 /**
	 * The method will persist the existing CodeValue Alternate Scheme in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param codeTable
	 */
	Long updateCodeValueAlternateScheme(SCoTSSearchCriteriaVO sCoTSSearchCriteriaVO);
	
	/**
	 *
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the transactional
	 * DB to fetch all alternate scheme codes matching the scheme type code
	 * selected by the user.
	 *
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	List<CodeValueAlternateScheme> reviewAlternateSchemeCodeChanges(Long schemeTypeCode);
	/**
	 * The method will remove the codeValue data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param codeValueAlternateSchemeId
	 */
	void removeApprovedCodeValueAlternateScheme(Long codeValueAlternateSchemeId);

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 *
	 * @param domainId
	 * @return associationIds
	 */
	List<Long> saveApprovedCodeRelationship(String domainId);	
	/**
	 * The method will remove the codeTable data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param domainId
	 */
	void removeApprovedCodeRelationship(List<Long> associationIds);
	List<CodeValueAssociation> retrieveParentCodeValueAssociations(Long codeValueId);
	List<CodeValueAssociation> retrieveChildCodeValueAssociations(Long codeValueId);
	/**
	 * 
	 * The method to retrieve all valid industry code group levels
	 *
	 * @return validIndustryCodeGroupLevels
	 */
	List<CodeValue> retrieveValidIndustryCodeGroupLevels();
	  /**
	 * 
	 * The method will return the max value for the next code table id
	 *
	 * @return codeTableId
	 */
    Long retrieveFirstCodeTableId();
    
	/**
	 * If applicability is "System", value of dnbSystemCode will be dnbSystemCode
	 * in sys_appy table. If it is "Market", value of dnbSystemCode will be 
	 * ctry_geo_unit_id in ctry_appy table. This method checks if the applicability 
	 * with given dnbSystemCode is already present in transactional db. If it exists, 
	 * the return map will contain isLocked=true and username=modifiedUser. Else the 
	 * map will contain isLocked=false and username="".
	 * 
	 * @param dnbSystemCode
	 * @param applicability
	 * @return map
	 */
    Map<String, Object> lockApplicabilityForEdit(Long dnbSystemCode, String applicability);
    
    /**
	 * This method will retrieve the saved records from the transaction db.
	 * @param domainName
	 * @return
     * @throws ParseException 
	 */
	Map<String, List<SavedRecord>> retrieveSavedRecordsByDomainName(String domainName) throws ParseException;
	

	/** Implemented to fix 209048785 -Edit SCoTS Approval Page**/
	       
	       Boolean update(String reason,String busdesc,Long codeValueId,String ApproverId);
	List<CodeValue> retrieveCodeValuesScores(List<Long> codeTableIds,
			Long languageCode);

	List<CodeValue> retrieveMktGrpCodes();
	
	/**
	 * The method will validate the Code Value for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param codeValueId
	 */
	
	String lockCodeRelationship(Long parentTableId,Long childTableId);
	
}