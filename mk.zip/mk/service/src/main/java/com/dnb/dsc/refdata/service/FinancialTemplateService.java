/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service;

import java.util.List;
import java.util.Map;

import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplate;

/**
 * 
 * @author Cognizant
 * @version last updated : June 19, 2012
 * @see
 * 
 */
public interface FinancialTemplateService {
	/**
	 * 
	 * The method to get the financial templates from the staging DB
	 *
	 * @param codeTableId
	 * @return
	 */
	List<CodeValueText> getFinancialTemplates(Long codeTableId);
	/**
	 * 
	 * The method to retrieve the schedules for a statement type
	 *
	 * @param statementType
	 * @return
	 */
	List<CodeValueText> getSchedulesForStatementType(Long statementType);	
	/**
	 * 
	 * The method is to update the financial template 
	 *
	 * @param fsTemplate
	 * @return
	 */
	Long updateFinancialStatementTemplate(FinancialStatementTemplate fsTemplate);
	/**
	 * 
	 * The method to save the approved financial template
	 *
	 * @param domainId
	 * @return
	 */
	Long saveApprovedFinancialTemplates(Long domainId);
	/**
	 * 
	 * The method to remove the approve financial template
	 *
	 * @param domainId
	 * @return
	 */
	Boolean removeApprovedFinancialTemplates(Long domainId);
	/**
	 * 
	 * The method is to retrieve the financial statement template by type code
	 *
	 * @param financialTemplateTypeCode
	 * @return
	 */
	FinancialStatementTemplate retrieveFinancialStatementTemplateByTypeCode(
			Long financialTemplateTypeCode, Boolean isStagingDB);
	/**
	 * 
	 * The method is to retrieve the line items for a schedule type
	 *
	 * @param scheduleType
	 * @return
	 */
	List<CodeValueText> getLineItemsForScheduleType(Long scheduleType);
	/**
	 * 
	 * The method is to retrieve the description for id
	 *
	 * @param codeValueIdList
	 * @return
	 */
	Map<Integer, String> retrieveDescForId(List<Integer> codeValueIdList);
	/**
	 * 
	 * The method is to retrieve the financial statement templates by id
	 *
	 * @param financialStatementTemplateId
	 * @return
	 */
	FinancialStatementTemplate retrieveFinancialStatementTemplateById(Long financialStatementTemplateId);
	/**
	 * 
	 * The method is to retrieve the statement types for a schedule
	 *
	 * @param scheduleCodeList
	 * @return
	 */
	List<CodeValueText> retrieveStatementForSchedules(List<Integer> scheduleCodeList);
	
	/**
     * The method return the finance template type code for a given finance template id
     *
     * @param financeTemplateId
     * @return
     */
	Long retrieveFinanceTemplateCodeById(Long financeTemplateId);
	/**
	 * This method checks if the financial Template with given financialTemplateTypeCode 
	 * is already present in transactional db. If it exists, 
	 * the return map will contain isLocked=true and username=modifiedUser. Else the 
	 * map will contain isLocked=false and username="".
	 * 
	 * @param financialTemplateTypeCode
	 * @return map
	 */
	Map<String, Object> lockFinancialTemplateForEdit(Long financialTemplateTypeCode);
}
