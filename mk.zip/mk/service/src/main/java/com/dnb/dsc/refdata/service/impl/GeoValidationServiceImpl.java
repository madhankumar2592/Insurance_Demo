/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnb.dsc.refdata.dao.GeoStagingDAO;
import com.dnb.dsc.refdata.service.GeoValidationService;

/**
 * @author Cognizant
 * @version last updated : Feb 06, 2012
 * @see
 * 
 */
@Service("GeoValidationService")
public class GeoValidationServiceImpl implements GeoValidationService {

	@Autowired
	private GeoStagingDAO stagingDAO;

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GeoValidationServiceImpl.class);

	/**
	 * Checks whether the geo unit is associated with child geo units or not.
	 * <p>
	 * Based on the validation result, proceed with/without soft delete.
	 * <p>
	 * 
	 * @param geoUnitId
	 * @return a Boolean status flag
	 */
	@Override
	public Boolean checkForChildGeoUnit(Long geoUnitId) {
		LOGGER.info("entering GeoValidationServiceImpl | validateGeoUnit");
		Long childCount = stagingDAO.validateGeoUnit(geoUnitId);
		LOGGER.info("Child Records in validation: " + childCount);
		LOGGER.info("exiting GeoValidationServiceImpl | validateGeoUnit");
		if (childCount > 0) {
			return true;
		} else {
			return false;
		}
	}

}
