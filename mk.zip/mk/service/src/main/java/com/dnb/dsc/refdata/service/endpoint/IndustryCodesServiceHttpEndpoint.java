/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.endpoint;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.InduscodeMappingBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.IndustryCodesSearchCriteriaVO;
import com.dnb.dsc.refdata.service.IndustryCodeService;

/**
 * This is the end point class implementation that connects a web service client
 * to the JAX-WS runtime. The class contains methods which are mapped to the web
 * service requests. The mapping will invoke the respective methods which in
 * turn invokes the respective service classes.
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Controller
public class IndustryCodesServiceHttpEndpoint {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(IndustryCodesServiceHttpEndpoint.class);

	@Autowired
	private IndustryCodeService industryService;

	/**
	 * Retrieves the Industry Code search Results.
	 * <p>
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param industryCodesSearchCriteria
	 * @return a list of IndustryCode
	 */
	@RequestMapping(value = "/searchIndustryCodes.service", method = RequestMethod.POST)
	public @ResponseBody
	List<IndustryCode> searchIndustryCodes(
			@RequestBody IndustryCodesSearchCriteriaVO industryCodesSearchCriteria) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | searchIndustryCodes");
		return industryService.searchIndustryCodes(industryCodesSearchCriteria);
	}

	/**
	 * The method will retrieve Industry code CrossWalks for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 * 
	 * @param industryCodeTypeCode
	 * @return list of codeValueVO
	 */
	@RequestMapping(value = "/{industryCodeTypeCode}/retrieveCrossWalksForIndsCodeType.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveCrossWalksForIndsCodeType(
			@PathVariable("industryCodeTypeCode") Long industryCodeTypeCode) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | retrieveCrossWalksForIndsCodeType");

		List<CodeValueVO> codeValueVOs = industryService
				.retrieveCrossWalksForIndsCodeType(industryCodeTypeCode);

		LOGGER.info("codeValueVOs : " + codeValueVOs);
		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | retrieveCrossWalksForIndsCodeType");
		return codeValueVOs;
	}

	/**
	 * The method will retrieve Industry code and description for the selected
	 * industry code type.
	 * 
	 * @param industryCodeTypeCode
	 * @return list of codeValueVO
	 */
	@RequestMapping(value = "/{industryCodeTypeCode}/{industryCode}/retrieveDescriptionForIndsCodeTypeCode.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	String retrieveDescriptionForIndsCodeTypeCode(
			@PathVariable("industryCodeTypeCode") Long industryCodeTypeCode,
			@PathVariable("industryCode") String industryCode) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | retrieveDescriptionForIndsCodeTypeCode");

		String description = industryService
				.retrieveDescriptionForIndsCodeTypeCode(industryCodeTypeCode,
						industryCode);

		LOGGER.info("description : " + description);
		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | retrieveDescriptionForIndsCodeTypeCode");
		return description;
	}

	@RequestMapping(value = "/{industryCodeTypeCode}/{industryCode}/retrieveIndustryCodeIdByCodeTypeCode.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	Long retrieveIndustryCodeIdByCodeTypeCode(
			@PathVariable("industryCodeTypeCode") Long industryCodeTypeCode,
			@PathVariable("industryCode") String industryCode) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | retrieveIndustryCodeIdByCodeTypeCode");

		Long industryCodeId = industryService
				.retrieveIndustryCodeIdByCodeTypeCode(industryCodeTypeCode,
						industryCode);

		LOGGER.info("industryCodeId : " + industryCodeId);
		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | retrieveIndustryCodeIdByCodeTypeCode");
		return industryCodeId;
	}

	/**
	 * 
	 * The method will count the records in the hierarchy search of industry
	 * codes on the search db. The search will be done on the flat db based on
	 * the search criteria the user had provided.
	 * 
	 * @param currencySearchCriteria
	 * @return countResults
	 */
	@RequestMapping(value = "/countSearchIndustryCodes.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchIndustryCodes(
			@RequestBody IndustryCodesSearchCriteriaVO industryCodesSearchCriteria) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | countSearchIndustryCodes");
		return industryService
				.countSearchIndustryCodes(industryCodesSearchCriteria);
	}

	/**
	 * The method will search the Staging SoR for the IndustryCode based on the
	 * IndustryCodeId and will return the IndustryCode entity.
	 * 
	 * @param industryCodeId
	 * @return IndustryCode
	 */
	@RequestMapping(value = "/{industryCodeId}/retrieveIndustryCodeByIndustryCodeId.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	IndustryCode retrieveIndustryCodeByIndustryCodeId(
			@PathVariable("industryCodeId") Long industryCodeId) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | retrieveIndustryCodeByIndustryCodeId");

		IndustryCode industryCode = industryService
				.retrieveIndustryCodeByIndustryCodeId(industryCodeId);

		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | retrieveIndustryCodeByIndustryCodeId");
		return industryCode;
	}

	/**
	 * The method will retrieve Industry code Group Levels for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 * 
	 * @param industryCodeTypeCode
	 * @param session
	 * @return list of codeValueVO
	 */
	@RequestMapping(value = "/{industryCodeTypeCode}/{languageCode}/retrieveGroupLevelCodes.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveGroupLevelCodes(
			@PathVariable("industryCodeTypeCode") Long industryCodeTypeCode,
			@PathVariable("languageCode") Long languageCode) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | retrieveGroupLevelCodes");

		List<CodeValueVO> codeValueVOs = industryService
				.retrieveGroupLevelCodes(industryCodeTypeCode, languageCode);

		LOGGER.info("codeValueVOs : " + codeValueVOs);
		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | retrieveGroupLevelCodes");
		return codeValueVOs;
	}

	/**
	 * The method will persist the existing IndustryCode data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param GeoUnit
	 * @return workflowTrackingId
	 */
	@RequestMapping(value = "/updateIndustryCode.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateIndustryCode(@RequestBody IndustryCode industryCode) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | updateIndustryCode.service");
		LOGGER.info("IndustryCodeId : " + industryCode.getIndustryCodeId());
		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | updateIndustryCode.service");
		return industryService.updateIndustryCode(industryCode);
	}

	/**
	 * 
	 * The method will fetch the language codes available for the selected
	 * Industry Code Type. The method will be invoked when the user selects the
	 * Industry Code type value.
	 * 
	 * @param industryCodeTypeCode
	 * @param groupLevelCodes
	 * @param session
	 * @return list of codeValueVO
	 */
	@RequestMapping(value = "/{industryCodeTypeCode}/retrieveIndustryCodeLanguages.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValueVO> retrieveIndustryCodeLanguages(
			@PathVariable("industryCodeTypeCode") Long industryCodeTypeCode,
			@RequestBody List<Long> groupLevelCodes) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | retrieveIndustryCodeLanguages");

		List<CodeValueVO> codeValueVOs = industryService
				.retrieveIndustryCodeLanguages(industryCodeTypeCode,
						groupLevelCodes);

		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | retrieveIndustryCodeLanguages");
		return codeValueVOs;
	}

	/**
	 * 
	 * The method to lock the industry code record for edit
	 * 
	 * @param industryCodeId
	 * @return isLocked
	 */
	@RequestMapping(value = "/{industryCodeId}/lockIndustryCode.service", method = RequestMethod.GET)
	public @ResponseBody
	String lockIndustryCode(@PathVariable("industryCodeId") Long industryCodeId) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | lockIndustryCode");
		return industryService.lockIndustryCode(industryCodeId);
	}

	/**
	 * The method will be invoked by the when the the business owner reviews the
	 * changes submitted for his approval. The user reviews the changes and he
	 * could approve or reject the request.
	 * 
	 * @param trackingId
	 */
	@RequestMapping(value = "/{domainId}/reviewIndustryCodeChanges.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	IndustryCode reviewIndustryCodeByChanges(
			@PathVariable("domainId") Long domainId) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | reviewIndustryCodeChanges");

		IndustryCode industryCode = industryService
				.reviewIndustryCodeChanges(domainId);

		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | reviewIndustryCodeChanges");
		return industryCode;
	}

	/**
	 * The method will add UiBulkDownload data in the Transactional DB.
	 * 
	 * @param UiBulkDownload
	 * @return id
	 */
	@RequestMapping(value = "/addUIBulkDownload.service", method = RequestMethod.POST)
	public @ResponseBody
	Long addUIBulkDownload(@RequestBody UiBulkDownload uiBulkDownload) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | addUIBulkDownload.service");
		LOGGER.info("IndustryCodeId : " + uiBulkDownload.getDomainName());
		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | addUIBulkDownload.service");
		return industryService.addUIBulkDownload(uiBulkDownload);
	}

	/**
	 * The method will search the Staging SoR for the UiBulkDownload based on
	 * the userId and will return the UiBulkDownload entity.
	 * 
	 * @param userId
	 * @return UiBulkDownload
	 */
	@RequestMapping(value = "/{userId}/retrieveUIBulkDownload.service", method = RequestMethod.POST)
	public @ResponseBody
	List<UiBulkDownload> retrieveUIBulkDownload(
			@PathVariable("userId") String userId) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | retrieveUIBulkDownload");

		return industryService.retrieveUIBulkDownload(userId);

	}

	/**
	 * 
	 * The method to delete an existing Industry Code. The data will be saved in
	 * the temp table. For Industry code the delete operation is a hard delete.
	 * 
	 * @param industryCodeId
	 * @param deletedUser
	 * @return isSuccess
	 */
	@RequestMapping(value = "/{industryCodeId}/{deletedUser}/deleteIndustryCode.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	Boolean deleteIndustryCode(@PathVariable Long industryCodeId, @PathVariable String deletedUser) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | deleteIndustryCode");
		LOGGER.info("IndustryCodeId : " + industryCodeId);
		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | deleteIndustryCode");
		return industryService.deleteIndustryCode(industryCodeId, deletedUser);
	}
	
	/**
	 * This method counts the IndustryCodeDescription  in the Staging DB to identify any duplicates
	 *
	 * @param industryCodeId
	 * @param industryCodeTypeCode
	 * @return count
	 */
	@RequestMapping(value = "/{industryCode}/{industryCodeTypeCode}/{industryDescription}/" +
			"countIndustryCodeDescriptionForDuplicate.service", method = RequestMethod.GET)
	public @ResponseBody
	Boolean countIndustryCodeDescriptionForDuplicate(@PathVariable("industryCode") String industryCode,
			@PathVariable("industryCodeTypeCode") Long industryCodeTypeCode,
			@PathVariable("industryDescription") String industryDescription) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | countIndustryCodeDescriptionForDuplicate");
		return industryService.countIndustryCodeDescriptionForDuplicate(industryCode, industryCodeTypeCode,industryDescription);
	}
	/**
	 * 
	 * The method will retrieve the Industry code data for all the tables given
	 * as parameter from the Staging SoR. The input will be Code Table ID of the
	 * Industry Code Type table. This method will be invoked only for search as
	 * this will fetch only the existing industry code types from inds_code
	 * table.
	 * 
	 * @param indsCodeTableId
	 * @return
	 */
	@RequestMapping(value = "/{indsCodeTableId}/retrieveIndustryCodeValues.service", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody
	Map<String, List<CodeValue>> retrieveIndustryCodeValues(
			@PathVariable("indsCodeTableId") Long indsCodeTableId) {
		LOGGER.info("entering IndustryCodesServiceHttpEndpoint | retrieveIndustryCodeValues");

		Map<String, List<CodeValue>> indsCodeValues = industryService.retrieveIndustryCodeValues(indsCodeTableId);

		LOGGER.info("exiting IndustryCodesServiceHttpEndpoint | retrieveIndustryCodeValues");
		return indsCodeValues;
	}
	
	/**
	 * This method will retrieve all the crosswalks available with respective count of each crosswalk
	 * @return
	 */
	@RequestMapping(value = "/retrieveCrosswalkDetails.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<InduscodeMappingBulkDownloadVO> retrieveCrosswalkDetails() {
		LOGGER.info("entering GlobalElementHttpEndpoint | unMappedElementCount");
		return industryService.retrieveCrosswalkDetails();
	}
}
