/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.endpoint;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeInferment;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ControlWordsSearchVO;
import com.dnb.dsc.refdata.service.ControlWordsService;

/**
 * This is the end point class implementation that connects a web service client
 * to the JAX-WS runtime. The class contains methods which are mapped to the web
 * service requests. The mapping will invoke the respective methods which in
 * turn invokes the respective service classes.
 * 
 * @author Cognizant
 * @version last updated : May 31, 2012
 * @see
 * 
 */
@Controller
public class ControlWordsHttpEndpoint {

	@Autowired
	private ControlWordsService controlWordsService;
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ControlWordsHttpEndpoint.class);
	
	@RequestMapping(value = "/retrieveAllControlWords.service", method = RequestMethod.POST)
	public @ResponseBody List<CodeValueText> retrieveAllControlWords(@RequestBody CodeValueText codeValueText) {
		LOGGER.info("entering ControlWordsHttpEndpoint | retrieveAllControlWords");
		return controlWordsService.retrieveAllControlWords();
	}
	
	@RequestMapping(value = "/retrieveControlWordsSearchResults.service", method = RequestMethod.POST)
	public @ResponseBody
	ControlWordsSearchVO retrieveControlWordsSearchResults(
			@RequestBody ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering ControlWordsHttpEndpoint | retrieveControlWordsSearchResults");
		return controlWordsService.retrieveControlWordsSearchResults(controlWordsSearchVO);
	}
	
	@RequestMapping(value = "/{dnbUnusGlsyId}/{isStagingDB}/retrieveControlWordById.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	DnbUnusGlsy retrieveControlWordById(@PathVariable("dnbUnusGlsyId") Long dnbUnusGlsyId,
			@PathVariable("isStagingDB") Boolean isStagingDB ) {
		LOGGER.info("entering ControlWordsHttpEndpoint | retrieveControlWordById");

		DnbUnusGlsy dnbUnusGlsy = controlWordsService
				.retrieveControlWordById(dnbUnusGlsyId, isStagingDB);

		LOGGER.info("exiting ControlWordsHttpEndpoint | retrieveControlWordById");
		return dnbUnusGlsy;
	}
	
	@RequestMapping(value = "/updateControlWord.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateControlWord(@RequestBody DnbUnusGlsy dnbUnusGlsy) {
		LOGGER.info("entering ControlWordsHttpEndpoint | updateControlWord.service");
		LOGGER.info("getDnbUnusGlsyId : " + dnbUnusGlsy.getDnbUnusGlsyId());
		LOGGER.info("exiting ControlWordsHttpEndpoint | updateControlWord.service");
		return controlWordsService.updateControlWord(dnbUnusGlsy);
	}

	/**
	 * 
	 * The method to retrieve all applicable country codes for the Area Code Numbers
	 *
	 * @param geoUnitTypeCode
	 * @return codeValueVOs
	 */
	@RequestMapping(value = "/{geoUnitTypeCode}/retrieveAllAreaCodeGeoUnits.service", method = RequestMethod.GET)
	public @ResponseBody List<CodeValueVO> retrieveAllAreaCodeGeoUnits(
			@PathVariable("geoUnitTypeCode") Long geoUnitTypeCode){
		LOGGER.info("entering ControlWordsHttpEndpoint | retrieveAllAreaCodeGeoUnits");
		return controlWordsService.retrieveAllAreaCodeGeoUnits(geoUnitTypeCode);
	}
	
	/**
	 * 
	 * The method will perform a hierarchy search of Area Code Numbers on the search db.<p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.<p>
	 * 
	 * @param controlWordsSearchVO
	 * @return list of CurrencyExchange
	 */
	@RequestMapping(value = "/searchAreaCodeNumbers.service", method = RequestMethod.POST)
	public @ResponseBody
	List<PhoneAreaCode> searchAreaCodeNumbers(@RequestBody ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering ControlWordsHttpEndpoint | searchAreaCodeNumbers");
		return controlWordsService.searchAreaCodeNumbers(controlWordsSearchVO);
	}
	
	/**
	 * 
	 * The method will count the records in the hierarchy search of area codes on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param controlWordsSearchVO
	 * @return countResults
	 */
	@RequestMapping(value = "/countSearchAreaCodeNumbers.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchAreaCodeNumbers(@RequestBody ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering ControlWordsHttpEndpoint | countSearchAreaCodeNumbers");
		return controlWordsService.countSearchAreaCodeNumbers(controlWordsSearchVO);
	}
	/**
	 * 
	 * The method will retrieve all Legal Form Class Codes
	 * 
	 * @return CodeValueVO List
	 */
	@RequestMapping(value = "/retrieveLegalFormClassCodes.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveLegalFormClassCodes() {
		LOGGER.info("entering ControlWordsServiceHttpEndpoint | retrieveLegalFormClassCodes");
		return controlWordsService.retrieveLegalFormClassCodes();
	}
	
	/**
	 * 
	 * The method will retrieve all Legal Form Codes
	 * 
	 * @return CodeValueVO List
	 */
	@RequestMapping(value = "/retrieveLegalFormCodes.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveLegalFormCodes() {
		LOGGER.info("entering ControlWordsServiceHttpEndpoint | retrieveLegalFormClassCodes");
		return controlWordsService.retrieveLegalFormCodes();
	}
	
	/**
	 * 
	 * The method will retrieve all Legal Form Languages
	 * 
	 * @return CodeValueVO List
	 */
	@RequestMapping(value = "/retrieveLegalFormLanguages.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveLegalFormLanguages() {
		LOGGER.info("entering ControlWordsServiceHttpEndpoint | retrieveLegalFormLanguages");
		return controlWordsService.retrieveLegalFormLanguages();
	}
	/**
	 * 
	 * The method will retrieve all Legal Form Countries
	 * 
	 * @return CodeValueVO List
	 */
	@RequestMapping(value = "/retrieveLegalFormCountries.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveLegalFormCountries() {
		LOGGER.info("entering ControlWordsServiceHttpEndpoint | retrieveLegalFormCountries");
		return controlWordsService.retrieveLegalFormCountries();
	}
	/**
	 *
	 * The method will perform a hierarchy search of Inferment Text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return list of Inferment Text
	 */
	@RequestMapping(value = "/searchLegalFormInfermentText.service", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<InfermentText> searchLegalFormInfermentText(
			@RequestBody 	ControlWordsSearchVO ctrlWrdsSearchCriteria) {
		LOGGER.info("entering ControlWordsServiceHttpEndpoint | searchInfermentText||ctrlWrdsSearchCriteria: "+ctrlWrdsSearchCriteria);
		List<InfermentText> searchLegalFormInfermentText =controlWordsService.searchLegalFormInfermentText(ctrlWrdsSearchCriteria);
		setStatusString(searchLegalFormInfermentText);
		LOGGER.info("exiting ControlWordsServiceHttpEndpoint | searchInfermentText|| searchLegalFormInfermentText: "+searchLegalFormInfermentText);
		return searchLegalFormInfermentText;
	}
	/**
	 *
	 * The method will perform a hierarchy search of Inferment Text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided and retun the count
	 *
	 * @param searchCriteriaVO
	 * @return count of Inferment Text
	 */
	@RequestMapping(value = "/countSearchLegalFormInfermentText.service", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchLegalFormInfermentText(
			@RequestBody ControlWordsSearchVO ctrlWrdsSearchCriteria) {
		LOGGER.info("entering ControlWordsServiceHttpEndpoint | searchInfermentText");
		return controlWordsService.countSearchLegalFormInfermentText(ctrlWrdsSearchCriteria);
	}
	private void setStatusString(List<InfermentText> searchResults) {
		for(InfermentText infermentText: searchResults) {
			if((infermentText.getExpirationDate()==null)||((infermentText.getExpirationDate()!=null)
					&& (infermentText.getExpirationDate().compareTo(new Date()) > 0))){
				infermentText.setStatus("Active");
			} else {
				infermentText.setStatus("Inactive");
			}
			LOGGER.info("infermentText Status : " + infermentText.getStatus());
		}
	}
    /**
     * 
     * @param codeTableId
     * @return
     */
    @RequestMapping(value = "/retrieveIndustryInfermentCode.service", method = RequestMethod.POST)
    public @ResponseBody
    List<IndustryCodeInferment> retrieveIndustryCodeTypeAndDesc(@RequestBody Integer codeTableId) {
        LOGGER.info("entering ControlWordsServiceHttpEndpoint | retrieveIndustryCodeTypeAndDesc");
        return controlWordsService.retrieveIndustryCodeTypeAndDesc(codeTableId,
                RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
    }
	
    /**
	 * Fetches the InfermentText entity by infermentTextId.<p>
	 * 
	 * @param infermentTextId
	 * @return InfermentText
	 */
	@RequestMapping(value = "/{infermentTextId}/retrieveInfermentTextByInfermentTextId.service",headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	InfermentText retrieveInfermentTextByInfermentTextId(@PathVariable("infermentTextId") Long infermentTextId) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCodeValueByCodeValueId || infermentTextId: " + infermentTextId);
		InfermentText infermentText = controlWordsService.retrieveInfermentTextByInfermentTextId(infermentTextId);
		LOGGER.info("exiting SCoTsServiceHttpEndpoint | retrieveCodeValueByCodeValueId || infermentText: " + infermentText);
		return infermentText;
	}
    /**
     * 
     * @return
     */
    @RequestMapping(value = "/retrieveLanguageCode.service", method = RequestMethod.POST)
    public @ResponseBody
    List<IndustryCodeInferment> retrieveLanguageCode() {
        LOGGER.info("entering ControlWordsServiceHttpEndpoint | retrieveLanguageCode");
        return controlWordsService.retrieveLanguageCode();
    }
    
    @RequestMapping(value = "/{industryCodeTypeCode}/retrieveIndustryCodeDescription.service", method = RequestMethod.POST)
    public @ResponseBody
    List<IndustryCode> retrieveIndustryCodeDescription(@PathVariable("industryCodeTypeCode") Long industryCodeTypeCode) {
        LOGGER.info("entering ControlWordsServiceHttpEndpoint | retrieveIndustryCodeDescription");
        return controlWordsService.retrieveIndustryCodeDescription(industryCodeTypeCode);
    }
    

    /**
     * 
     * The method will count the records in the hierarchy search of industry codes inferment on the search db. The
     * search will be done on the flat db based on the search criteria the user had provided.
     * 
     * @param currencySearchCriteria
     * @return countResults
     */
    @RequestMapping(value = "/countSearchIndustryCodesInferment.service", method = RequestMethod.POST)
    public @ResponseBody
    Long countSearchIndustryCodesInferment(@RequestBody ControlWordsSearchVO industryCodesInfermentSearchCriteria) {
        LOGGER.info("entering ControlWordsServiceHttpEndpoint | countSearchIndustryCodesInferment");
        return controlWordsService.countSearchIndustryCodesInferment(industryCodesInfermentSearchCriteria);
    }
	
    /**
	 * Fetches the InfermentText entity by infermentTextId from the transaction DB<p>
	 * 
	 * @param infermentTextId
	 * @return InfermentText
	 */
	@RequestMapping(value = "/{infermentTextId}/reviewLegalFormInfermentChanges.service",headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	InfermentText reviewLegalFormInfermentChanges(@PathVariable("infermentTextId") Long infermentTextId) {
		LOGGER.info("entering ControlWordsServiceHttpEndpoint | reviewLegalFormInfermentChanges || infermentTextId: " + infermentTextId);
		InfermentText infermentText = controlWordsService.reviewLegalFormInfermentChanges(infermentTextId);
		LOGGER.info("exiting ControlWordsServiceHttpEndpoint | reviewLegalFormInfermentChanges || infermentText: " + infermentText);
		return infermentText;
	}
	/**
     * TODO
     * 
     * @param industryCodesSearchCriteria
     * @return
     */
    @RequestMapping(value = "/searchIndustryCodesInferment.service", method = RequestMethod.POST)
    public @ResponseBody
    List<IndustryCodeInferment> searchIndustryCodesInferment(
            @RequestBody ControlWordsSearchVO industryCodesInfermentSearchCriteria) {
        LOGGER.info("entering ControlWordsServiceHttpEndpoint | searchIndustryCodesInferment");
        return controlWordsService.searchIndustryCodesInferment(industryCodesInfermentSearchCriteria);
    }
    
    /**
     * The method fetches the inferment text search view page details
     * 
     * @param industryCodesSearchCriteria
     * @return
     */
    @RequestMapping(value = "/{infermentText}/searchIndustryCodesInfermentSearchView.service",headers = "Accept=application/json", method = RequestMethod.GET)
    public @ResponseBody
    IndustryCodeInferment industryCodeInfermentSearchView(
            @PathVariable("infermentText") String infermentText) {
        LOGGER.info("entering ControlWordsServiceHttpEndpoint | industryCodeInfermentSearchView");
        return controlWordsService.industryCodeInfermentSearchView(Long.valueOf(infermentText));
    }
    
    /**
	 * 
	 * The method will validate the InfermentText for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param infermentTextId
	 * @return
	 */
	@RequestMapping(value = "/{infermentTextId}/lockInfermentText.service", method = RequestMethod.GET)
	public @ResponseBody
	Boolean lockInfermentText(@PathVariable("infermentTextId") Long infermentTextId) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | lockInfermentText");
		return controlWordsService.lockInfermentText(infermentTextId);
	}
	/**
	 * The method will persist the existing infermentText data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param infermentText
	 */
	@RequestMapping(value = "/updateInfermentText.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateLegalFormInferment(@RequestBody InfermentText infermentText) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | updateLegalFormInferment");
		return controlWordsService.updateLegalFormInferment(infermentText);
	}
	
	@RequestMapping(value = "/updatePhoneAreaCode.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updatePhoneAreaCode(@RequestBody PhoneAreaCode phoneAreaCode) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | updatePhoneAreaCode.service");
		LOGGER.info("phoneAreaCode id : " + phoneAreaCode.getPhoneAreaCodeId());
		LOGGER.info("exiting GeographyServiceHttpEndpoint | updatePhoneAreaCode.service");
		if(phoneAreaCode.getPhoneAreaCodeId() > 0L){
			DnbUnusGlsy dnbUnusGlsy = controlWordsService
				.retrieveControlWordById(phoneAreaCode.getDnbUnusGlsyId(), true);
			dnbUnusGlsy.setCountryApplicability(null);
			dnbUnusGlsy.setDnbUnusAdr(null);
			dnbUnusGlsy.setDnbUnusIndNme(null);
			dnbUnusGlsy.setPhoneAreaCode(null);
			dnbUnusGlsy.setTelecomAddress(null);
			dnbUnusGlsy.setDnbUnusTxt(phoneAreaCode.getAreaCodeNumber());
			controlWordsService.updateControlWord(dnbUnusGlsy);
		}
		return controlWordsService.updatePhoneAreaCode(phoneAreaCode);
	}
	
	@RequestMapping(value = "/{phoneAreaCodeId}/{isStagingDB}/retrievePhoneAreaCodeById.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	PhoneAreaCode retrievePhoneAreaCodeById(@PathVariable("phoneAreaCodeId") Long phoneAreaCodeId,
			@PathVariable("isStagingDB") Boolean isStagingDB ) {
		LOGGER.info("entering ControlWordsHttpEndpoint | retrievePhoneAreaCodeById");

		PhoneAreaCode phoneAreaCode = controlWordsService
				.retrievePhoneAreaCodeById(phoneAreaCodeId, isStagingDB);

		LOGGER.info("exiting ControlWordsHttpEndpoint | retrievePhoneAreaCodeById");
		return phoneAreaCode;
	}
	
	@RequestMapping(value = "/retrieveAreaCodeInfo.service", method = RequestMethod.POST)
	public @ResponseBody List<String> retrieveAreaCodeInfo(){
		LOGGER.info("entering ControlWordsHttpEndpoint | retrieveAreaCodeInfo");
		return controlWordsService.retrieveAreaCodeInfo();
	}	
	
	@RequestMapping(value = "/{phoneAreaCodeId}/lockPhoneAreaCodeForEdit.service", method = RequestMethod.GET)
	public @ResponseBody
	Boolean lockPhoneAreaCodeForEdit(@PathVariable("phoneAreaCodeId") Long phoneAreaCodeId) {
		LOGGER.info("entering ControlWordsHttpEndpoint | lockPhoneAreaCodeForEdit");
		return controlWordsService.lockPhoneAreaCodeForEdit(phoneAreaCodeId);
	}
	
	@RequestMapping(value = "/retrieveControlWordsAJAXSearchResults.service", method = RequestMethod.POST)
	public @ResponseBody
	List<DnbUnusGlsy>  retrieveControlWordsAJAXSearchResults(
			@RequestBody ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering ControlWordsHttpEndpoint | retrieveControlWordsSearchResults");
		List<DnbUnusGlsy> controlWords= controlWordsService.retrieveControlWordsSearchResults(controlWordsSearchVO).getControlWords();
		return controlWords;
	}
	/**
	 *
	 * The method will perform a hierarchy search of Inferment Text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided and retun the count
	 *
	 * @param searchCriteriaVO
	 * @return count of Inferment Text
	 */
	@RequestMapping(value = "/countSearchControlWords.service", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchControlWords(
			@RequestBody ControlWordsSearchVO ctrlWrdsSearchCriteria) {
		LOGGER.info("entering ControlWordsServiceHttpEndpoint | countSearchControlWords");
		return controlWordsService.countSearchControlWords(ctrlWrdsSearchCriteria);
	}
}
