/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.service.endpoint;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.vo.XmlSchemaSearchVO;
import com.dnb.dsc.refdata.service.XmlSchemaLabelService;

/**
 * This is the end point class implementation that connects a web service client to the JAX-WS runtime. The class
 * contains methods which are mapped to the web service requests. The mapping will invoke the respective methods which
 * in turn invokes the respective service classes.
 * 
 * @author Cognizant
 * @version last updated : Apr 13, 2012
 * @see
 * 
 */
@Controller
public class XmlSchemaLabelServiceHttpEndPoint {

    /**
     * The instance variable for Logging
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(XmlSchemaLabelServiceHttpEndPoint.class);

    @Autowired
    private XmlSchemaLabelService xmlSchemaLabelService;

	/**
	 * The end point method to search Xml Schema Element by element name or
	 * description. The method will invoke the XmlSchemaLabel Service class
	 * which will search the Xml Schema Elements based on the input parameter
	 * element name or description
	 * 
	 * 
	 * @param xmlSchemaSearchVO
	 * @return
	 */
    @RequestMapping(value = "/schemaLabelSearch.service", method = RequestMethod.POST)
    public @ResponseBody
    List<XmlSchemaElement> searchXmLSchemaLabels(@RequestBody XmlSchemaSearchVO xmlSchemaSearchVO) {
        LOGGER.info("entering XmlSchemaLabelServiceHttpEndPoint | searchXmLSchemaLabels");
        return xmlSchemaLabelService.searchXmLSchemaLabels(xmlSchemaSearchVO);
    }

	/**
	 * The method will return the xml schema element details passed Element id
	 * and will return the XmlSchemaElement entity.
	 * 
	 * @param elementId
	 * @return
	 */
    @RequestMapping(value = "/{elementId}/retrieveXmlSchemaByXmlElementId.service", headers = "Accept=application/json", method = RequestMethod.GET)
    public @ResponseBody
    XmlSchemaElement retrieveXmlSchemaByXmlElementId(@PathVariable("elementId") String elementId) {
        LOGGER.info("entering XmlSchemaLabelServiceHttpEndPoint | retrieveXmlSchemaByXmlElementId");
        XmlSchemaElement xmlSchemaElement = xmlSchemaLabelService.retrieveXmlSchemaByXmlElementId(elementId);
        LOGGER.info("exiting XmlSchemaLabelServiceHttpEndPoint | retrieveXmlSchemaByXmlElementId");
        return xmlSchemaElement;
    }
    
	/**
	 * 
	 * The method will perform the table count of xml schema element on the
	 * staging db based on the specified filter conditions.
	 * 
	 * @param XmlSchemaSearchVO
	 * @return count of XmlSchemaElement
	 */
    @RequestMapping(value = "/countSearchXmLSchemaLabels.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchXmLSchemaLabels(
			@RequestBody XmlSchemaSearchVO xmlSchemaSearchVO) {
		return xmlSchemaLabelService.countSearchXmLSchemaLabels(xmlSchemaSearchVO);
	}
	/**
	 * 
	 * The method will validate the XmlSchemaLabel for any locks (If already
	 * been opened by any other user for edit). If no lock is currently
	 * available then the method will lock the record and return FALSE
	 * indicating no lock currently. But if a lock already exists, the method
	 * will return TRUE. The lock operation will be performed in the
	 * Transactional DB.
	 * 
	 * @param xmlSchemaElementId
	 * @return
	 */
	@RequestMapping(value = "/{xmlSchemaElementId}/lockXmlSchema.service", method = RequestMethod.GET)
	public @ResponseBody
	Boolean lockXmlSchema(
			@PathVariable("xmlSchemaElementId") String xmlSchemaElementId) {
		LOGGER.info("entering XmlSchemaLabelServiceHttpEndPoint | lockXmlSchema");
		return xmlSchemaLabelService.lockXmlSchema(xmlSchemaElementId);
	}

	/**
	 * The method will persist the existing XmlSchemaElement data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param xmlSchemaElement
	 */
	@RequestMapping(value = "/updateXmlSchemaElement.service", method = RequestMethod.POST)
	public @ResponseBody
	String updateXmlSchemaElement(@RequestBody XmlSchemaElement xmlSchemaElement) {
		LOGGER.info("entering XmlSchemaLabelServiceHttpEndPoint | updateXmlSchemaElement");
		return xmlSchemaLabelService.updateXmlSchemaElement(xmlSchemaElement);
	}
	
	/**
	 * The method will return the xml schema element details passed Element id
	 * and will return the XmlSchemaElement entity.
	 * 
	 * @param elementId
	 * @return
	 */
    @RequestMapping(value = "/{elementId}/reviewXmlSchemaByXmlElementChanges.service", headers = "Accept=application/json", method = RequestMethod.GET)
    public @ResponseBody
    XmlSchemaElement reviewXmlSchemaByXmlElementChanges(@PathVariable("elementId") String elementId) {
        LOGGER.info("entering XmlSchemaLabelServiceHttpEndPoint | reviewXmlSchemaByXmlElementChanges");
        XmlSchemaElement xmlSchemaElement = xmlSchemaLabelService.reviewXmlSchemaByXmlElementChanges(elementId);
        LOGGER.info("xmlSchemaElement : " + xmlSchemaElement);
        LOGGER.info("exiting XmlSchemaLabelServiceHttpEndPoint | reviewXmlSchemaByXmlElementChanges");
        return xmlSchemaElement;
    }
}
