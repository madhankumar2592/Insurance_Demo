package com.dnb.dsc.refdata.service;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.Score;
import com.dnb.dsc.refdata.core.vo.AddNewScoreVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.GranularityValueVO;
import com.dnb.dsc.refdata.core.vo.ScoreDtlVO;
import com.dnb.dsc.refdata.core.vo.ScoreSearchVO;
import com.dnb.dsc.refdata.core.vo.ScoreVO;

/**
 * This is used as the services interface for the SCoTS operations
 *
 * @author Cognizant
 * @version last updated : Feb 2, 2012
 * @see
 *
 */

public interface ScoreService {
	
	
	
	List<CodeValueVO> retrieveGranularityCodes(String capabilityCode);
	
	Long updateGranularityCode(GranularityValueVO granularityValueVO);
	
	Long updateNewScoreCode(AddNewScoreVO addNewScoreVO);

	List<CodeValueVO> retrieveAllScoreTypeCode();
	
	List<CodeValueVO> retrieveMarketTypeCodes(Long scoreType);


	List<Score> retrievescoreVersions(Long scoreType, Long marketType);


	List<AddNewScoreVO> retrieveAttributeDetails(Long scoreType,
			Long marketType, Double scoreVersion);
	List<Long> retrieveScoreTypeCode();


	List<CodeValue> retrieveScoreTypeCodeValues(
			ScoreVO scoreVO);


	List<CodeValueVO> retrieveMarketCodeValues(ScoreVO scoreVO);


	List<Score> retrieveVersionValues(Score scoreVO);


	List<CodeValue> retrieveGranularityForScrType(ScoreVO scoreVO);


	Long updateScoreDtl(ScoreDtlVO scoreDtlVO);


	List<CodeValue> retrieveGruTypeCodeValues(ScoreVO scoreVO);


	Long countSearchScore(ScoreSearchVO searchCriteriaVO);

	Long updateNewScoreMapping(AddNewScoreVO addNewScoreVO);
	List<ScoreSearchVO> scoreSearch(ScoreSearchVO searchCriteriaVO);


	ScoreSearchVO editScoreSearch(ScoreSearchVO scoreSearchVO);


	Long updateScoreMapDtl(ScoreSearchVO scoreSearchVO);


	List<CodeValue> retrieveScrSearchScoreTypeCode(ScoreVO scoreVO);


	List<CodeValue> retrieveScrSearchGranularity(ScoreVO scoreVO);
	Long removeProdRescID(List<Long> prodDtlIdList, String deleteQuery,
			String parameter);
	Boolean checkForDuplicate(Long scoreTypeCode,Long scoreMarketCode,Double scoreVersion);
}
