/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.core.vo.SCoTSSearchCriteriaVO;
import com.dnb.dsc.refdata.dao.SCoTsStagingDAO;
import com.dnb.dsc.refdata.dao.SCoTsTransactionalDAO;
import com.dnb.dsc.refdata.service.SCoTsService;

/**
 * This is used as the services interface for the SCoTS operations
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@Service("SCoTsService")
public class SCoTsServiceImpl implements SCoTsService {

	@Autowired
	private SCoTsStagingDAO stagingDAO;

	@Autowired
	private SCoTsTransactionalDAO transactionalDAO;
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SCoTsServiceImpl.class);

	/**
	 * 
	 * The method will retrieve the SCoTS data for all the tables given as
	 * parameter from the Staging SoR. The input will be list of Code Table IDs
	 * and the user preferred language. The return will be a map with key as
	 * Code table ID and value as list of CodeValue. The method is invoked to
	 * populate the following drop downs in Add Geo Unit UI: - Geo Unit Type -
	 * Name Type - Language - Data Provider - Code Type
	 * 
	 * @param codeTableIds
	 * @param langaugeCode
	 * @return
	 */
	@Transactional("stgTransactionManager")
	public Map<Long, List<CodeValue>> retrieveCodeValues(
			List<Long> codeTableIds, Long langaugeCode) {
		LOGGER.info("entering SCoTsServiceImpl | retrieveCodeValues");
		return stagingDAO.retrieveCodeValues(codeTableIds, langaugeCode);
	}
	@Transactional("stgTransactionManager")
	public List<CodeValue> retrieveCodeValuesScores(
			List<Long> codeTableIds, Long langaugeCode) {
		LOGGER.info("entering SCoTsServiceImpl | retrieveCodeValues");
		return stagingDAO.retrieveCodeValuesScores(codeTableIds, langaugeCode);
	}
	@Transactional("stgTransactionManager")
	public List<CodeValue> retrieveMktGrpCodes() {
		LOGGER.info("entering SCoTsServiceImpl | retrieveMktGrpCodes");
		return stagingDAO.retrieveMktGrpCodes();
	}
	@Transactional("stgTransactionManager")
	public Map<Long, List<CodeValue>> retrieveCodeValuesScr(
			List<Long> codeTableIds, Long langaugeCode) {
		LOGGER.info("entering SCoTsServiceImpl | retrieveCodeValues");
		return stagingDAO.retrieveCodeValuesScr(codeTableIds, langaugeCode);
	}
	/**
	 * 
	 * The method will retrieve the SCoTS data for all the CodeValues given as
	 * parameter from the Staging SoR. The input will be list of Code Value IDs
	 * and the user preferred language. The return will be a map with key as
	 * Code Value ID and value as list of CodeValue.
	 * 
	 * @param codeValueIds
	 * @param langaugeCode
	 * @return
	 */
	@Transactional("stgTransactionManager")
	public Map<Long, List<CodeValue>> retrieveCodeValuesById(
			List<Long> codeValueIds, Long langaugeCode) {
		LOGGER.info("entering SCoTsServiceImpl | retrieveCodeValues");
		return stagingDAO.retrieveCodeValuesById(codeValueIds, langaugeCode);
	}

	/**
	 * 
	 * The method will perform the table search of SCoTS Code Tables on the
	 * search db.
	 * <p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param SCoTSSearchCriteriaVO
	 * @return list of CodeValue
	 */
	@Transactional("stgTransactionManager")
	public List<CodeTable> searchCodeTables(
			SCoTSSearchCriteriaVO searchCriteriaVO) {
		return stagingDAO.searchCodeTables(searchCriteriaVO);
	}

	/**
	 * 
	 * The method will count the records in the hierarchy search of code tables
	 * on the search db. The search will be done on the flat db based on the
	 * search criteria the user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return count of search results
	 */
	@Transactional("stgTransactionManager")
	public Long countSearchCodeTables(SCoTSSearchCriteriaVO searchCriteriaVO) {
		return stagingDAO.countSearchCodeTables(searchCriteriaVO);
	}

	/**
	 * The method will retrieve all all SCoTS table Ids.
	 */
	@Override
	public List<CodeValueVO> retrieveCodeTableList() {
		LOGGER.info("entering SCoTsServiceImpl | retriveCodeTableList");
		return stagingDAO.retrieveCodeTableList();
	}

	/**
	 * The method will retrieve all Code Languages from the Search DB . The
	 * return type is a VO which contains the Code Value Id and the COde Value
	 * Description (language names).
	 * 
	 */
	@Override
	public List<CodeValueVO> retrieveCodeLanguages() {
		LOGGER.info("entering SCoTsServiceImpl | retriveCodeLanguages");
		return stagingDAO.retrieveCodeLanguages();
	}

	/**
	 * The method will retrieve all systems applicable from the Search DB . The
	 * return type is a VO which contains the DNB system code and the Code Value
	 * Description.
	 * 
	 */
	public List<SystemApplicability> retrieveSystemApplicability(
			Long codeTableId, int applicabilityIndicator) {
		LOGGER.info("entering SCoTsServiceImpl | retrieveSystemApplicability");
		return stagingDAO.retrieveSystemApplicability(codeTableId,applicabilityIndicator);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List retrieveSystemForCode(String applicability,
			Long applicabilityCode, Boolean isStagingDB) {
		LOGGER.info("entering SCoTsServiceImpl | retrieveSystemForCode");
		if (isStagingDB) {
			return stagingDAO.retrieveSystemForCode(applicability,
					applicabilityCode);
		} else {
			List<Object> txnObjects = transactionalDAO.retrieveSystemForCode(
					applicability, applicabilityCode);
			List<Object> stgObjects = stagingDAO.retrieveSystemForCode(
					applicability, applicabilityCode);
			txnObjects.addAll(stgObjects);
			return txnObjects;
		}
	}

	@Override
	public List<CodeValueVO> retrieveAllSystemApplicability(String applicability) {
		LOGGER.info("entering SCoTsServiceImpl | retrieveAllSystemApplicability");
		return stagingDAO.retrieveAllSystemApplicability(applicability);
	}

	/**
	 * The method will retrieve all countries applicable from the Search DB .
	 * The return type is a VO which contains the DNB system code and the Code
	 * Value Description.
	 * 
	 */
	public List<CountryApplicability> retrieveCountryApplicability(
			Long codeTableId, int applicabilityIndicator) {
		LOGGER.info("entering SCoTsServiceImpl | retrieveCountryApplicability");
		return stagingDAO.retrieveCountryApplicability(codeTableId,applicabilityIndicator);
	}

	/**
	 * 
	 * The method to find the CodeTable entity by the primary key codeTableId
	 * 
	 * @param codeTableId
	 * @return CodeTable entity
	 */
	@Transactional("stgTransactionManager")
	public CodeTable retrieveCodeTableById(Long codeTableId) {
		CodeTable codeTable = stagingDAO.retrieveCodeTableById(codeTableId);
		if (codeTable != null) {
			codeTable.setSystemApplicability(retrieveSystemApplicability(codeTableId,1));
			codeTable.setCountryApplicability(retrieveCountryApplicability(codeTableId,1));
		}
		LOGGER.info("exiting SCoTsServicempl | retrieveCodeTableById | codeTable : " + codeTable);
		return codeTable;
	}

	/**
	 * 
	 * The method to find the CodeTable entity by the primary key codeTableId
	 * 
	 * @param codeTableId
	 * @return CodeTable entity
	 */
	public CodeTable reviewCodeTableChanges(Long codeTableId) {
		CodeTable txnCodeTable = transactionalDAO.retrieveCodeTableById(codeTableId);
		CodeTable stgCodeTable = retrieveCodeTableById(codeTableId);
		if (stgCodeTable != null) {
			CodeTable mergeCodeTable = txnCodeTable;
			mergeCodeTable.setSystemApplicability(mergeSystems(
					stgCodeTable.getSystemApplicability(),
					txnCodeTable.getSystemApplicability()));
			mergeCodeTable.setCountryApplicability(mergeCountries(
					stgCodeTable.getCountryApplicability(),
					txnCodeTable.getCountryApplicability()));
			LOGGER.info("exiting SCoTsServicempl | reviewCodeTableChanges | codeTable : " + mergeCodeTable);
			return mergeCodeTable;
		} else {
			return txnCodeTable;
		}
	}

	/**
	 * 
	 * The method to find the CodeValue entity by the primary key codeValueId
	 * 
	 * @param codeValueId
	 * @return CodeValue entity
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional("txnTransactionManager")
	public CodeValue reviewCodeValueChanges(Long codeValueId) {
		CodeValue txnCodeValue = transactionalDAO.retrieveCodeValueById(codeValueId);

		CodeValue stgCodeValue = null;

		try {
			stgCodeValue = stagingDAO.retrieveCodeValueByCodeValueId(codeValueId);
		} catch (Exception e) {
			LOGGER.error("Entity not found in Staging SoR "+ e.getMessage());
		}

		CodeValue mergeCodeValue = txnCodeValue;

		if(stgCodeValue != null){
			mergeCodeValue.setStgBusinessDescription(stgCodeValue.getBusinessDescription());
			mergeCodeValue.setStgReasonText(stgCodeValue.getReasonText());
			mergeCodeValue.setStgOnBehalfOfName(stgCodeValue.getOnBehalfOfName());			
		}

		/**
		 * Fix for Ticket : 
		 * Compare Code Value Texts from Staging DB and Transaction DB to identify the changes
		 * and update the change indicator to display in the approve page
		 */
		mergeCodeValue.setCodeValueTexts(stgCodeValue != null ? mergeTexts(
				stgCodeValue.getCodeValueTexts(),txnCodeValue.getCodeValueTexts()) : 
					txnCodeValue.getCodeValueTexts());
		/**
		 * Ticket : change ends * 
		 */


		mergeCodeValue
		.setSystemApplicability(stgCodeValue != null ? mergeSystems(
				stgCodeValue.getSystemApplicability(),
				txnCodeValue.getSystemApplicability()) : txnCodeValue
				.getSystemApplicability());

		mergeCodeValue
		.setCountryApplicability(stgCodeValue != null ? mergeCountries(
				stgCodeValue.getCountryApplicability(),
				txnCodeValue.getCountryApplicability()) : txnCodeValue
				.getCountryApplicability());

		if (null != txnCodeValue.getChildCodeValueAssociations() && 
				txnCodeValue.getChildCodeValueAssociations().size() > 0) {
			List<Long> childCodeValueIds = new ArrayList<Long>();
			for (CodeValueAssociation currAssn : txnCodeValue.getChildCodeValueAssociations()) {
				childCodeValueIds.add(currAssn.getChildCodeValueId());
			}

			Map<Long, List<CodeValue>> tempCodeValueMap = stagingDAO.retrieveCodeValuesById(
					childCodeValueIds, RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

			for (CodeValueAssociation currAssn : txnCodeValue.getChildCodeValueAssociations()) {
				List codeTableNames = tempCodeValueMap.get(Long.valueOf(currAssn.getChildCodeValueId()));
				for (CodeValue codeValueList : (List<CodeValue>) codeTableNames) {
					currAssn.setChildCodeTableId(codeValueList.getCodeTableId().longValue());
					currAssn.setCodeValueDescription(codeValueList.getCodeValueDescription());
				}
			}
		}
		if (null != txnCodeValue.getParentCodeValueAssociations() && 
				txnCodeValue.getParentCodeValueAssociations().size() > 0) {
			List<Long> parentCodeValueIds = new ArrayList<Long>();
			for (CodeValueAssociation currAssn : txnCodeValue.getParentCodeValueAssociations()) {
				parentCodeValueIds.add(currAssn.getParentCodeValueId());
			}

			Map<Long, List<CodeValue>> tempCodeValueMap = stagingDAO.retrieveCodeValuesById(
					parentCodeValueIds,	RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

			for (CodeValueAssociation currAssn : txnCodeValue.getParentCodeValueAssociations()) {
				List codeTableNames = tempCodeValueMap.get(Long.valueOf(currAssn.getParentCodeValueId()));
				for (CodeValue codeValueList : (List<CodeValue>) codeTableNames) {
					currAssn.setParentCodeTableId(codeValueList.getCodeTableId().longValue());
					currAssn.setCodeValueDescription(codeValueList.getCodeValueDescription());
				}
			}
		}



		LOGGER.info("exiting SCoTsServicempl | reviewCodeValueChanges  || codeValue:" + mergeCodeValue);
		return mergeCodeValue;
	}


	/**
	 * 
	 * The method will merge the Code Value Texts of Transaction DB and the
	 * Staging SoR. The return will be the merged CodeValue.
	 * 
	 * @param stgTexts
	 * @param txnTexts
	 * @return
	 */
	private List<CodeValueText> mergeTexts(
			List<CodeValueText> stgTexts,
			List<CodeValueText> txnTexts) {
		LOGGER.info("entering SCoTsServicempl || mergeTexts || initialStg: "
				+ stgTexts + " txn : " + txnTexts);
		List<Long> txnCodeValueTextIds = new ArrayList<Long>();
		List<Long> stgCodeValueTextIds = new ArrayList<Long>();
		List<CodeValueText> mergeCodeValueText = new ArrayList<CodeValueText>();
		if (stgTexts == null) {
			return txnTexts;
		}
		if (txnTexts != null) {
			for (CodeValueText txnCodeValueText : txnTexts) {
				txnCodeValueTextIds.add(txnCodeValueText.getCodeValueTextId());
			}

			for (CodeValueText stgCodeValueText : stgTexts) {
				stgCodeValueTextIds.add(stgCodeValueText.getCodeValueTextId());
			}

			for (CodeValueText txnCodeValueText : txnTexts) {
				if (stgCodeValueTextIds.contains(txnCodeValueText.getCodeValueTextId())
						&& txnCodeValueText.getExpirationDate() != null) {
					txnCodeValueText.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_EXPIRED);

				} else if (stgCodeValueTextIds.contains(txnCodeValueText.getCodeValueTextId())
						&& txnCodeValueText.getExpirationDate() == null){
					txnCodeValueText.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NO_CHANGE);
				} else {
					txnCodeValueText.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW);
				}
				mergeCodeValueText.add(txnCodeValueText);
			}
			LOGGER.info("entering SCoTsServicempl || mergeTexts || finalstg: "
					+ mergeCodeValueText);
			return mergeCodeValueText;
		} else {
			return stgTexts;
		}
	}




	/**
	 * 
	 * The method will merge the System applicability of Transaction DB and the
	 * Staging SoR. The return will be the merged CodeValue.
	 * 
	 * @param stgSystems
	 * @param txnSystems
	 * @return
	 */
	private List<SystemApplicability> mergeSystems(
			List<SystemApplicability> stgSystems,
			List<SystemApplicability> txnSystems) {
		LOGGER.info("entering SCoTsServicempl |mergeSystems || initialStg: "
				+ stgSystems + " txn : " + txnSystems);
		List<Long> txnSystemCodes = new ArrayList<Long>();
		List<Long> stgSystemCodes = new ArrayList<Long>();
		List<SystemApplicability> mergeSystems = new ArrayList<SystemApplicability>();
		if (stgSystems == null) {
			return txnSystems;
		}
		if (txnSystems != null) {
			for (SystemApplicability systemApplicability : txnSystems) {
				txnSystemCodes.add(systemApplicability.getSysAppyId());
			}

			for (SystemApplicability systemApplicability : stgSystems) {
				stgSystemCodes.add(systemApplicability.getSysAppyId());
			}

			for (SystemApplicability stgSystem : stgSystems) {
				if (!txnSystemCodes.contains(stgSystem.getSysAppyId())) {
					mergeSystems.add(stgSystem);
				}
			}

			for (SystemApplicability txnSystem : txnSystems) {
				if (stgSystemCodes.contains(txnSystem.getSysAppyId())
						&& txnSystem.getExpirationDate() == null) {
					txnSystem.setSysChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NO_CHANGE);					
				}else if(stgSystemCodes.contains(txnSystem.getSysAppyId()) && txnSystem.getExpirationDate() != null){
					txnSystem.setSysChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_CORRECTED);	
				}else{
					txnSystem.setSysChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW);
				}

				mergeSystems.add(txnSystem);
			}
			LOGGER.info("entering SCoTsServicempl |mergeSystems || finalstg: "
					+ mergeSystems);
			return mergeSystems;
		} else {
			return stgSystems;
		}
	}

	/**
	 * 
	 * The method will merge the System applicability of Transaction DB and the
	 * Staging SoR. The return will be the merged CodeValue.
	 * 
	 * @param stgSystems
	 * @param txnSystems
	 * @return
	 */
	private List<CountryApplicability> mergeCountries(
			List<CountryApplicability> stgCountries,
			List<CountryApplicability> txnCountries) {
		LOGGER.info("entering SCoTsServicempl |mergeCountries || stg: "
				+ stgCountries + " txn : " + txnCountries);
		List<Long> txnCountryCodes = new ArrayList<Long>();
		List<Long> stgCountryCodes = new ArrayList<Long>();
		List<CountryApplicability> mergeCountries = new ArrayList<CountryApplicability>();
		if (stgCountries == null) {
			return txnCountries;
		}
		if (txnCountries != null) {
			for (CountryApplicability countryApplicability : txnCountries) {
				txnCountryCodes.add(countryApplicability.getCtryAppyId());
			}

			for (CountryApplicability countryApplicability : stgCountries) {
				stgCountryCodes.add(countryApplicability.getCtryAppyId());
			}

			for (CountryApplicability stgCountry : stgCountries) {
				if (!txnCountryCodes.contains(stgCountry.getCtryAppyId())) {
					mergeCountries.add(stgCountry);
				}
			}

			for (CountryApplicability txnCountry : txnCountries) {
				if(stgCountryCodes.contains(txnCountry.getCtryAppyId())
						&& txnCountry.getExpirationDate() == null){
					txnCountry.setCtryChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NO_CHANGE);
				}else if(stgCountryCodes.contains(txnCountry.getCtryAppyId())
						&& txnCountry.getExpirationDate() != null){
					txnCountry.setCtryChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_CORRECTED);
				}else{
					txnCountry.setCtryChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW);
				}
				mergeCountries.add(txnCountry);
			}
			LOGGER.info("exiting SCoTsServicempl |mergeCountries || stg: "
					+ mergeCountries);
			return mergeCountries;
		} else {
			return stgCountries;
		}
	}

	/**
	 * 
	 * The method to fetch the details of codeValues based on the codeTableId.
	 * The filter will also contain the language code, system applicability code
	 * and country applicability code.
	 * 
	 * @param searchCriteriaVO
	 * @return list of codeValues
	 */
	@Transactional("stgTransactionManager")
	public List<CodeValue> retrieveCodeValuesByTableId(
			SCoTSSearchCriteriaVO searchCriteriaVO) {
		return stagingDAO.retrieveCodeValuesByTableId(searchCriteriaVO);
	}

	/**
	 * 
	 * The method to count the results of codeValues based on the codeTableId.
	 * The filter will also contain the language code, system applicability code
	 * and country applicability code.
	 * 
	 * @param searchCriteriaVO
	 * @return count of codeValues
	 */
	@Transactional("stgTransactionManager")
	public Long countCodeValuesByTableId(SCoTSSearchCriteriaVO searchCriteriaVO) {
		return stagingDAO.countCodeValuesByTableId(searchCriteriaVO);
	}

	/**
	 * 
	 * The method to fetch the Code Value details based on the filter condition.
	 * The Code Value will be searched based on description or on the business
	 * description.
	 * 
	 * @param searchCriteriaVO
	 * @return codeValues
	 */
	@Transactional("stgTransactionManager")
	public List<CodeValue> searchCodeValues(
			SCoTSSearchCriteriaVO searchCriteriaVO) {
		return stagingDAO.searchCodeValues(searchCriteriaVO);
	}

	/**
	 * 
	 * The method to fetch the count of Code Value details based on the filter
	 * condition. The Code Value will be searched based on description or on the
	 * business description.
	 * 
	 * @param searchCriteriaVO
	 * @return countCodeValues
	 */
	@Transactional("stgTransactionManager")
	public Long countOfSearchCodeValues(SCoTSSearchCriteriaVO searchCriteriaVO) {
		return stagingDAO.countOfSearchCodeValues(searchCriteriaVO);
	}

	/**
	 * Retrieves CodeValue entity by codeValueId.
	 * <p>
	 * 
	 * @param codeValueId
	 * @return CodeValue
	 */
	@Override
	@Transactional("stgTransactionManager")
	public CodeValue retrieveCodeValueByCodeValueId(Long codeValueId) {
		LOGGER.info("entering SCoTsServiceImpl | retrieveCodeValueByCodeValueId");
		CodeValue codeValue = null;
		try {
			codeValue = stagingDAO.retrieveCodeValueByCodeValueId(codeValueId);
		} catch (Exception e) {
			throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, e);
		}
		LOGGER.info("exiting SCoTsServiceImpl | retrieveCodeValueByCodeValueId || codeValue : "
				+ codeValue);
		return codeValue;
	}

	/**
	 * 
	 * The method to retrieve all codeValue associations from database. The
	 * method will accept the parent and child code table Id s and will return
	 * all associations having the relationship between the specified parent and
	 * child code tables.
	 * 
	 * @param parentCodeTableId
	 * @param childCodeTableId
	 * @return List<CodeValueAssociation>
	 */
	@Override
	/*@Transactional("stgTransactionManager")*/
	@Transactional("txnTransactionManager")

	public List<CodeValueAssociation> retrieveCodeValueAssociations(
			Long parentCodeTableId, Long childCodeTableId, Boolean isStagingDB) {
		if (isStagingDB) {
			return stagingDAO.retrieveCodeValueAssociations(parentCodeTableId,
					childCodeTableId, isStagingDB);
		} else {
			List<CodeValueAssociation> modifiedCodeValueAssociations = transactionalDAO
					.retrieveCodeValueAssociations(parentCodeTableId, childCodeTableId);
			//			List<CodeValueAssociation> existingCodeValueAssociations = stagingDAO
			//					.retrieveCodeValueAssociations(parentCodeTableId,
			//							childCodeTableId, !isStagingDB);
			//			modifiedCodeValueAssociations.addAll(existingCodeValueAssociations);
			return modifiedCodeValueAssociations;
		}
	}

	/**
	 * 
	 * The method to retrieve all alternate schema code types from the database.
	 * The method will be invoked as a web-service to retrieve the data.
	 * 
	 * @return List<CodeValueVO>
	 */
	@Override
	public List<CodeValueVO> retrieveAllAlternateSchemeCodes() {
		return stagingDAO.retrieveAllAlternateSchemeCodes();
	}

	/**
	 * 
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the staging
	 * DB to fetch all alternate scheme codes matching the scheme type code
	 * selected by the user.
	 * 
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	@Override
	@Transactional("stgTransactionManager")
	public List<CodeValueAlternateScheme> retrieveAlternateSchemeCodes(
			Long schemeTypeCode) {
		return stagingDAO.retrieveAlternateSchemeCodes(schemeTypeCode);
	}

	/**
	 * 
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the
	 * transactional DB to fetch all alternate scheme codes matching the scheme
	 * type code selected by the user.
	 * 
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	@SuppressWarnings("rawtypes")
	@Override
	@Transactional("txnTransactionManager")
	public List<CodeValueAlternateScheme> reviewAlternateSchemeCodeChanges(
			Long schemeTypeCode) {
		LOGGER.info("entering SCoTsServiceImpl | reviewAlternateSchemeCodeChanges");
		List<CodeValueAlternateScheme> reviewAlternateSchemeCodeChanges = transactionalDAO
				.retrieveAlternateSchemeCodes(schemeTypeCode);
		List<CodeValueAlternateScheme> altSchemes = new ArrayList<CodeValueAlternateScheme>();
		List<Long> codeValueIds = new ArrayList<Long>();
		for (CodeValueAlternateScheme cvAltSchm : reviewAlternateSchemeCodeChanges) {
			codeValueIds.add(cvAltSchm.getCodeValueId());
		}
		Map<Long, List<CodeValue>> retrieveCodeValuesById = retrieveCodeValuesById(
				codeValueIds, RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);
		for (CodeValueAlternateScheme cvAltSchm : reviewAlternateSchemeCodeChanges) {
			List codeValueResults = retrieveCodeValuesById.get(cvAltSchm
					.getCodeValueId());
			CodeValue codeValue = (CodeValue) codeValueResults.get(0);
			cvAltSchm.setCodeTableId(Long.valueOf(codeValue.getCodeTableId()));
			cvAltSchm.setCodeTableName(codeValue.getCodeTableName());
			cvAltSchm.setCodeValueDescription(codeValue
					.getCodeValueDescription());
			altSchemes.add(cvAltSchm);
		}
		return altSchemes;
	}

	/**
	 * The method will persist the existing Code Table data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param codeTable
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long updateCodeTable(CodeTable codeTable) {
		LOGGER.info("entering SCoTserviceImpl | updateCodeTable");
		LOGGER.info("entering SCoTserviceImpl | updateCodeTable" + codeTable);

		if (codeTable.getCodeTableId() < 0) {
			Long codeTableId = transactionalDAO.retrieveMaxCodeTableId();
			codeTable.setCodeTableId(codeTableId);
			for (SystemApplicability updateSystemList : codeTable
					.getSystemApplicability()) {
				updateSystemList.setCodeTableId(codeTableId);
			}
			for (CountryApplicability updateCountryList : codeTable
					.getCountryApplicability()) {
				updateCountryList.setCodeTableId(codeTableId);
			}
		}

		CodeTable codeTableReceiver = transactionalDAO
				.updateCodeTable(codeTable);
		List<SystemApplicability> systemApplicability = codeTable
				.getSystemApplicability();
		if (systemApplicability != null) {
			for (SystemApplicability updateSystem : systemApplicability) {
				SystemApplicability systemReciever = transactionalDAO
						.updateSystemApplicability(updateSystem);

				LOGGER.info("SystemApplicability updated with Id : "
						+ systemReciever.getSysAppyId());
			}
		}
		List<CountryApplicability> countryApplicability = codeTable
				.getCountryApplicability();
		if (countryApplicability != null) {
			for (CountryApplicability updateCountry : countryApplicability) {
				CountryApplicability countryReciever = transactionalDAO
						.updateCountryApplicability(updateCountry);

				LOGGER.info("CountryApplicability updated with Id : "
						+ countryReciever.getCtryAppyId());
			}
		}
		LOGGER.info("Code Table updated with Id : "
				+ codeTableReceiver.getCodeTableId());
		return codeTableReceiver.getCodeTableId();
	}

	/**
	 * The method will persist the existing codeValue data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param codeValue
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long updateCodeValue(CodeValue codeValue) {
		LOGGER.info("entering SCoTServiceImpl | updateCodeValue");
		LOGGER.info("SCoTServiceImpl | updateCodeValue | codeValue " + codeValue);
		// get the next value for cd_val_id from sequence for add functionality
		if (codeValue.getCodeValueId() < 0) {
			Long codeValueId = transactionalDAO.retrieveMaxCodeValueId();
			LOGGER.info("SCoTServiceImpl | updateCodeValue | codeValueId generated " + codeValueId);
			codeValue.setCodeValueId(codeValueId);
		}

		List<CodeValueText> codeValueTexts = codeValue.getCodeValueTexts();
		codeValue.setCodeValueTexts(null);
		// update the codeValue entity
		CodeValue codeValueReceiver = transactionalDAO.updateCodeValue(codeValue);

		LOGGER.info("SCoTServiceImpl | updateCodeValue | update completed for codeValue");
		// update the codeValueTexts
		if (codeValueTexts != null) {
			LOGGER.info("SCoTServiceImpl | updateCodeValue | updating codeValueTexts " + codeValueTexts);
			for (CodeValueText codeValueText : codeValueTexts) {
				codeValueText.setCodeValueId(codeValueReceiver.getCodeValueId());
				transactionalDAO.updateCodeValueText(codeValueText);
				LOGGER.info("SCoTServiceImpl | updateCodeValue | CodeValueText updated for codeValue : " 
						+ codeValueReceiver.getCodeValueId());
			}
			LOGGER.info("SCoTServiceImpl | updateCodeValue | update completed for codeValueTexts");
		}

		// update the systemApplicability
		List<SystemApplicability> systemApplicability = codeValue.getSystemApplicability();
		if (systemApplicability != null) {
			LOGGER.info("SCoTServiceImpl | updateCodeValue | updating systemApplicabilities");
			for (SystemApplicability updateSystem : systemApplicability) {
				updateSystem.setCodeValueId(codeValueReceiver.getCodeValueId());
				updateSystem.setCodeTableId(Long.valueOf(codeValueReceiver.getCodeTableId()));
				transactionalDAO.updateSystemApplicability(updateSystem);
			}
			LOGGER.info("SCoTServiceImpl | updateCodeValue | update completed for systemApplicabilities");
		}
		// update the countryApplicability
		List<CountryApplicability> countryApplicability = codeValue.getCountryApplicability();
		if (countryApplicability != null) {
			LOGGER.info("SCoTServiceImpl | updateCodeValue | updating countryApplicabilities");
			for (CountryApplicability updateCountry : countryApplicability) {
				updateCountry.setCodeValueId(codeValueReceiver.getCodeValueId());
				updateCountry.setCodeTableId(Long.valueOf(codeValueReceiver.getCodeTableId()));
				transactionalDAO.updateCountryApplicability(updateCountry);
			}
			LOGGER.info("SCoTServiceImpl | updateCodeValue | update completed for countryApplicabilities");
		}

		LOGGER.info("exiting SCoTServiceImpl | updateCodeValue | " + codeValueReceiver.getCodeValueId());
		return codeValueReceiver.getCodeValueId();
	}

	/**
	 * 
	 * The method will validate the Code Table for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param geoUnitId
	 * @return
	 */
	@Override
	public String lockCodeTable(Long codeTableId) {
		LOGGER.info("entering SCoTserviceImpl | lockCodeTable");
		String count = transactionalDAO.countCodeTable(codeTableId);		
		if(count == null || count.isEmpty()){
			return "false";
		}else{
			return count;
		}		
	}





	/**
	 * 
	 * The method will validate the alternateSchemeTypeCode for any locks (If
	 * already been opened by any other user for edit). If no lock is currently
	 * available then the method will lock the record and return FALSE
	 * indicating no lock currently. But if a lock already exists, the method
	 * will return TRUE. The lock operation will be performed in the
	 * Transactional DB.
	 * 
	 * @param alternateSchemeTypeCode
	 * @return
	 */
	@Override
	public String lockAltSchemeCode(Long alternateSchemeTypeCode) {
		LOGGER.info("entering SCoTserviceImpl | lockAltSchemeCode");
		String count = transactionalDAO.countAlternateSchemeTypeCode(alternateSchemeTypeCode);
		if(count == null || count.isEmpty()){
			return "false";
		}else{
			return count;
		}
	}

	/**
	 * 
	 * The method will validate the Code Value for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param codeValueId
	 * @return
	 */
	@Override
	public String lockCodeValue(Long codeValueId) {
		LOGGER.info("entering SCoTserviceImpl | lockCodeValue");
		String count = transactionalDAO.countCodeValue(codeValueId);
		if(count == null || count.isEmpty()){
			return "false";
		}else{
			return count;
		}
	}

	/**
	 * 
	 * The method to find the CountryApplicability entity by the CodeTable
	 * 
	 * @param codeValueDescription
	 * @return CountryApplicability entity
	 */
	@Transactional("stgTransactionManager")
	public CountryApplicability retrieveCountryByCodeTable(
			String codeValueDescription) {
		return stagingDAO.retrieveCountryByCodeTable(codeValueDescription);
	}

	@Override
	@Transactional("txnTransactionManager")
	public Long updateApplicability(CodeTable codeTable,
			Boolean isSystemApplicability) {
		if (isSystemApplicability) {
			for (SystemApplicability currSystem : codeTable
					.getSystemApplicability()) {
				transactionalDAO.updateSystemApplicability(currSystem);
			}
		} else {
			for (CountryApplicability currCountry : codeTable
					.getCountryApplicability()) {
				transactionalDAO.updateCountryApplicability(currCountry);
			}
		}
		return 0L;
	}

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 * 
	 * @param domainId
	 * @return isSaveSuccess
	 */
	@Override
	@Transactional("stgTransactionManager")
	public Long saveApprovedCodeTable(Long domainId) {
		
		LOGGER.info("entering SCoTserviceImpl | saveApprovedCodeTable");
		// Retrieve the IndustryCode details from the Work flow tracking table
		CodeTable codeTable = reviewCodeTableChanges(domainId);
		Long txnCodeTableId = codeTable.getCodeTableId();

		// UAT Defect Fix: Find the existence of cd_val_id in the staging database
		/*
		 * Check whether the code value id already exists in the staging. This
		 * check is to identify add code value from other request types. If this
		 * is already existing then update the existing code value.
		 */
		if(! stagingDAO.isSCoTsCodeAvailable(txnCodeTableId, "sorusr.CD_TBL")) {
			// If not already existing then retrieve the max plus one value of code value id from staging
			Long codeTableId = stagingDAO.retrieveStagingCodeId("sorusr.CD_TBL");
			LOGGER.info("SCoTserviceImpl | retrieveStagingCodeId | returned " + codeTableId);

			codeTable.setCodeTableId(codeTableId);
			if(codeTable.getCodeValues() != null) {
				LOGGER.info("SCoTserviceImpl | saveApprovedCodeTable | updating codeValues with new codeTableId");
				for(CodeValue codeValue : codeTable.getCodeValues()) {
					codeValue.setCodeTableId(codeTableId.intValue());
				}
			}
			if(codeTable.getSystemApplicability() != null) {
				LOGGER.info("SCoTserviceImpl | saveApprovedCodeTable | updating sysApplicabilitys with new codeTableId");
				for(SystemApplicability sysApplicability : codeTable.getSystemApplicability()) {
					sysApplicability.setCodeTableId(codeTableId);
				}
			}
			if(codeTable.getCountryApplicability() != null) {
				LOGGER.info("SCoTserviceImpl | saveApprovedCodeTable | updating ctryApplicabilitys with new codeTableId");
				for(CountryApplicability ctryApplicability : codeTable.getCountryApplicability()) {
					ctryApplicability.setCodeTableId(codeTableId);
				}
			}
		}

		// Updates the IndustryCode details to the Staging SoR
		stagingDAO.updateCodeTable(codeTable);

		LOGGER.info("exiting SCoTserviceImpl | saveApprovedCodeTable");
		return txnCodeTableId;
	}

	/**
	 * The method will remove the codeTable data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 * 
	 * @param codeTable
	 * @param boolean indicating the status
	 */
	@Override
	@Transactional("txnTransactionManager")
	public void removeApprovedCodeTable(Long codeTableId) {
		LOGGER.info("entering SCoTserviceImpl | removeApprovedCodeTable");
		transactionalDAO.removeApprovedCodeTable(codeTableId);
	}

	/**
	 * The method will remove the codeValue data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 * 
	 * @param codeValueId
	 * @param boolean indicating the status
	 */
	@Override
	@Transactional("txnTransactionManager")
	public void removeApprovedCodeValue(Long codeValueId) {
		LOGGER.info("entering SCoTserviceImpl | removeApprovedCodeValue");
		transactionalDAO.removeApprovedCodeValue(codeValueId);
	}

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 * 
	 * @param domainId
	 * @return isSaveSuccess
	 */
	@Override
	@Transactional("stgTransactionManager")
	public Long saveApprovedCodeValue(Long domainId) {
		LOGGER.info("entering SCoTserviceImpl | saveApprovedCodeValue");
		// Retrieve the IndustryCode details from the Work flow tracking table
		CodeValue codeValue = reviewCodeValueChanges(domainId);
		Long txnCodeValueId = codeValue.getCodeValueId();

		// UAT Defect Fix: Find the existence of cd_val_id in the staging database
		/*
		 * Check whether the code value id already exists in the staging. This
		 * check is to identify add code value from other request types. If this
		 * is already existing then update the existing code value.
		 */
		if(! stagingDAO.isSCoTsCodeAvailable(txnCodeValueId, "sorusr.CD_VAL")) {
			// If not already existing then retrieve the max plus one value of code value id from staging
			Long codeValueId = stagingDAO.retrieveStagingCodeId("sorusr.CD_VAL");
			LOGGER.info("SCoTserviceImpl | retrieveStagingCodeId | returned " + codeValueId);

			codeValue.setCodeValueId(codeValueId);
			if(codeValue.getCodeValueTexts() != null) {
				LOGGER.info("SCoTserviceImpl | saveApprovedCodeValue | updating codeValueTexts with new codeValueId");
				for(CodeValueText codeValueText : codeValue.getCodeValueTexts()) {
					codeValueText.setCodeValueId(codeValueId);
				}
			}
			if(codeValue.getCodeValueSchemes() != null) {
				LOGGER.info("SCoTserviceImpl | saveApprovedCodeValue | updating codeValueSchemes with new codeValueId");
				for(CodeValueAlternateScheme codeValueScheme : codeValue.getCodeValueSchemes()) {
					codeValueScheme.setCodeValueId(codeValueId);
				}
			}
			if(codeValue.getSystemApplicability() != null) {
				LOGGER.info("SCoTserviceImpl | saveApprovedCodeValue | updating sysApplicabilitys with new codeValueId");
				for(SystemApplicability sysApplicability : codeValue.getSystemApplicability()) {
					sysApplicability.setCodeValueId(codeValueId);
				}
			}
			if(codeValue.getCountryApplicability() != null) {
				LOGGER.info("SCoTserviceImpl | saveApprovedCodeValue | updating ctryApplicabilitys with new codeValueId");
				for(CountryApplicability ctryApplicability : codeValue.getCountryApplicability()) {
					ctryApplicability.setCodeValueId(codeValueId);
				}
			}
		}

		// Updates the IndustryCode details to the Staging SoR
		stagingDAO.updateCodeValue(codeValue);

		LOGGER.info("exiting SCoTserviceImpl | saveApprovedCodeValue");
		return txnCodeValueId;
	}

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 * 
	 * @param domainId
	 * @param changeTypeId
	 * @return isSaveSuccess
	 */
	@Override
	@Transactional("stgTransactionManager")
	public Long saveApprovedApplicabilities(Long domainId, Long changeTypeId) {
		LOGGER.info("entering SCoTserviceImpl | saveApprovedApplicabilities");
		if (RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_MARKET_APPLICABILITY
				.equals(String.valueOf(changeTypeId))) {
			// Retrieve the Country Applicability details from the transaction
			// table
			List<CountryApplicability> countryApplicabilities = retrieveTxnMarketApplicabilities(domainId);

			// Updates the Country Applicability details to the Staging SoR
			stagingDAO
			.updateApprovedCountryApplicabilities(countryApplicabilities);
		} else {
			// Retrieve the System Applicability details from the transaction
			// table
			List<SystemApplicability> systemApplicabilities = retrieveTxnSystemApplicabilities(domainId);

			// Updates the System Applicability details to the Staging SoR
			stagingDAO
			.updateApprovedSystemApplicabilities(systemApplicabilities);
		}
		LOGGER.info("exiting SCoTserviceImpl | saveApprovedApplicabilities");
		return domainId;
	}

	/**
	 * The method will remove the codeTable data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 * 
	 * @param domainId
	 * @param changeTypeId
	 */
	@Transactional("txnTransactionManager")
	public void removeApprovedTxnApplicabilities(Long domainId,
			Long changeTypeId) {
		LOGGER.info("entering SCoTsServiceImpl | removeApprovedTxnApplicabilities");
		if (RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_MARKET_APPLICABILITY
				.equals(String.valueOf(changeTypeId))) {
			// remove the Country Applicability details from the TXN SoR
			transactionalDAO.removeApprovedCountryApplicabilities(domainId);
		} else {
			// remove the System Applicability details from the TXN SoR
			transactionalDAO.removeApprovedSystemApplicabilities(domainId);
		}
		LOGGER.info("exiting SCoTsServiceImpl | removeApprovedTxnApplicabilities");
	}

	/**
	 * 
	 * The method to retrieve the MarketApplicabilities for a given market
	 * applicability type.
	 * 
	 * @param domainId
	 * @return marketApplicabilities
	 */
	private List<CountryApplicability> retrieveTxnMarketApplicabilities(
			Long domainId) {
		LOGGER.info("entering SCoTsServiceImpl | retrieveTxnMarketApplicabilities");
		return transactionalDAO.retrieveTxnMarketApplicabilities(domainId);
	}

	/**
	 * 
	 * The method to retrieve the SystemApplicabilities for a given system
	 * applicability type.
	 * 
	 * @param domainId
	 * @return systemApplicabilities
	 */
	private List<SystemApplicability> retrieveTxnSystemApplicabilities(
			Long domainId) {
		LOGGER.info("entering SCoTsServiceImpl | retrieveTxnSystemApplicabilities");
		return transactionalDAO.retrieveTxnSystemApplicabilities(domainId);
	}

	/**
	 * The method will persist the existing CodeValueAssociation in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param CodeValueAssociation
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long updateCodeValueAssociation(
			SCoTSSearchCriteriaVO sCoTSSearchCriteriaVO) {
		LOGGER.info("entering SCoTserviceImpl | updateCodeValueAssociation");
		for (CodeValueAssociation currentCodeValueAssociation : sCoTSSearchCriteriaVO
				.getCodeValueAssociations()) {
			transactionalDAO
			.updateCodeValueAssociation(currentCodeValueAssociation);
		}
		return 0L;
	}

	/**
	 * The method will persist the existing Code Value Alternate Scheme in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param CodeValueAssociation
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long updateCodeValueAlternateScheme(
			SCoTSSearchCriteriaVO sCoTSSearchCriteriaVO) {
		LOGGER.info("entering SCoTserviceImpl | updateCodeValueAssociation");
		for (CodeValueAlternateScheme currentCodeValueAlternateSchemes : sCoTSSearchCriteriaVO
				.getCodeValueAlternateSchemes()) {
			transactionalDAO
			.updateCodeValueAlternateScheme(currentCodeValueAlternateSchemes);
		}
		return sCoTSSearchCriteriaVO.getAlternateSchemeTypeCode();
	}

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 * 
	 * @param domainId
	 * @return isSaveSuccess
	 */
	@Override
	@Transactional("stgTransactionManager")
	public Long saveApprovedCodeValueAlternateScheme(Long domainId) {
		LOGGER.info("entering SCoTserviceImpl | saveApprovedCodeValue");
		// Retrieve the IndustryCode details from the Work flow tracking table
		List<CodeValueAlternateScheme> codeValueAlternateScheme =  transactionalDAO
				.retrieveAlternateSchemeCodes(domainId);

		// Updates the IndustryCode details to the Staging SoR
		stagingDAO
		.updateApprovedCodeValueAlternateSchemes(codeValueAlternateScheme);

		LOGGER.info("exiting SCoTserviceImpl | saveApprovedCodeValue");
		return domainId;
	}

	/**
	 * The method will remove the CodeValueAlternateScheme data from the
	 * Transaction DB. The method will be invoked when the business owner
	 * approves a change and the respective changes have been updated in the
	 * Staging SoR.
	 * 
	 * @param codeValueAlternateSchemeId
	 * @param boolean indicating the status
	 */
	@Override
	@Transactional("txnTransactionManager")
	public void removeApprovedCodeValueAlternateScheme(
			Long alternateSchemeTypeCode) {
		LOGGER.info("entering SCoTserviceImpl | removeApprovedCodeValueAlternateScheme");
		transactionalDAO.removeApprovedCodeValueAlternateScheme(alternateSchemeTypeCode);
	}

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 *
	 * @param domainId
	 * @return associationIds
	 */
	@Transactional("stgTransactionManager")
	public List<Long> saveApprovedCodeRelationship(String domainId) {
		LOGGER.info("entering SCoTsServiceImpl | saveApprovedCodeRelationship");
		Long parentCodeTableId = Long.valueOf(domainId.split("~")[0]);
		Long childCodeTableId = Long.valueOf(domainId.split("~")[1]);

		// Retrieve the Code Relationship details from the transaction table
		List<CodeValueAssociation> codeValueAssociations = retrieveCodeValueAssociations(
				parentCodeTableId, childCodeTableId, false);

		// Updates the Code Relationship details to the Staging SoR
		List<Long> associationIds = new ArrayList<Long>();
		for(CodeValueAssociation codeValueAssociation : codeValueAssociations) {
			CodeValueAssociation association = stagingDAO.updateCodeValueAssociation(codeValueAssociation);
			associationIds.add(association.getCodeValueAssociationId());
		}
		return associationIds;
	}

	/**
	 * The method will remove the codeTable data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param associationIds
	 */
	@Transactional("txnTransactionManager")
	public void removeApprovedCodeRelationship(List<Long> associationIds) {
		LOGGER.info("entering SCoTsServiceImpl | removeApprovedCodeRelationship | associationIds " + associationIds);
		//		Long parentCodeTableId = Long.valueOf(domainId.split("~")[0]);
		//		Long childCodeTableId = Long.valueOf(domainId.split("~")[1]);
		transactionalDAO.removeApprovedCodeRelationship(associationIds);
	}
	@Override
	@Transactional("stgTransactionManager")
	public List<CodeValueAssociation> retrieveParentCodeValueAssociations(Long codeValueId){
		return stagingDAO.retrieveParentCodeValueAssociations(codeValueId);
	}

	@Override
	@Transactional("stgTransactionManager")
	public List<CodeValueAssociation> retrieveChildCodeValueAssociations(Long codeValueId){
		return stagingDAO.retrieveChildCodeValueAssociations(codeValueId);
	}

	/**
	 * 
	 * The method to retrieve all valid industry code group levels
	 *
	 * @return validIndustryCodeGroupLevels
	 */
	@Override
	public List<CodeValue> retrieveValidIndustryCodeGroupLevels() {
		return stagingDAO.retrieveValidIndustryCodeGroupLevels();
	}
	/**
	 * 
	 * The method will return the max value for the next code table id
	 *
	 * @return codeTableId
	 */
	@Override
	public Long retrieveFirstCodeTableId(){
		return transactionalDAO.retrieveFirstCodeTableId();
	}

	/**
	 * If applicability is "System", value of dnbSystemCode will be dnbSystemCode
	 * in sys_appy table. If it is "Market", value of dnbSystemCode will be 
	 * ctry_geo_unit_id in ctry_appy table. This method checks if the applicability 
	 * with given dnbSystemCode is already present in transactional db. If it exists, 
	 * the return map will contain isLocked=true and username=modifiedUser. Else the 
	 * map will contain isLocked=false and username="".
	 * 
	 * @param dnbSystemCode
	 * @param applicability
	 * @return map
	 */
	@Override
	public Map<String, Object> lockApplicabilityForEdit(Long dnbSystemCode, String applicability){
		return transactionalDAO.lockApplicabilityForEdit(dnbSystemCode, applicability);
	}


	/**
	 * This method will retrieve the saved records from the transaction db.
	 * @param domainName
	 * @return
	 * @throws ParseException 
	 */
	@Override
	public Map<String, List<SavedRecord>> retrieveSavedRecordsByDomainName(String domainName) throws ParseException {
		return transactionalDAO.retrieveSavedRecordsByDomainName(domainName);
	}

	/** Implemented to fix 209048785 -Edit SCoTS Approval Page**/

	@Override
	@Transactional("txnTransactionManager")
	public Boolean update(String reason, String busdesc, Long codeValueId,String ApproverId) {

		LOGGER.info("Entering Scotsservice|update");
		CodeValue codeValue = new CodeValue();
		codeValue.setReasonText(reason);
		LOGGER.info("busdesc   ..............  "+busdesc);
		codeValue.setBusinessDescription(busdesc);
		codeValue.setCodeValueId(codeValueId);
		transactionalDAO.update(codeValue,ApproverId); 
		return true;
		}

	/**
	 * 
	 * The method will validate the scots Relationship for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param parentTableId
	 * @param childTableId
	 * @return lock status
	 */
	@Override
	public String lockCodeRelationship(Long parentTableId,Long childTableId) {
		LOGGER.info("entering SCoTserviceImpl | lockCodeRelationship");
		String userId = transactionalDAO.countCodeRealtionship(parentTableId,childTableId);
		if(userId == null || userId.isEmpty()){
			userId = "false";
		}
		return userId;
	}

}
