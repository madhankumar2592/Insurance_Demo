/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.endpoint;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GeoDefaultConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoHierarchy;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.entity.GeographySearch;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.entity.UserGroupMapping;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.GeoSearchCriteriaVO;
import com.dnb.dsc.refdata.service.ControlWordsService;
import com.dnb.dsc.refdata.service.CurrencyService;
import com.dnb.dsc.refdata.service.FinancialTemplateService;
import com.dnb.dsc.refdata.service.GeographyService;
import com.dnb.dsc.refdata.service.IndustryCodeService;
import com.dnb.dsc.refdata.service.SCoTsService;
import com.dnb.dsc.refdata.service.XmlSchemaLabelService;

/**
 * This is the end point class implementation that connects a web service client
 * to the JAX-WS runtime. The class contains methods which are mapped to the web
 * service requests. The mapping will invoke the respective methods which in
 * turn invokes the respective service classes.
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@Controller
public class GeographyServiceHttpEndpoint {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GeographyServiceHttpEndpoint.class);

	@Autowired
	private GeographyService geographyService;
	
	@Autowired
	private CurrencyService currencyService;

	@Autowired
	private IndustryCodeService industryService ;

	@Autowired
	private XmlSchemaLabelService xmlSchemaLabelService ;

	@Autowired
	private SCoTsService scotsService ;

	@Autowired
	private ControlWordsService controlWordsService ;
	
	@Autowired
	private FinancialTemplateService fsService;
	
	/**
	 * The end point method to search Geo Unit by name. The method will invoke
	 * the Geography Service class which will search the geo units based on the
	 * name filter condition and the user language preference.
	 * 
	 * @param nameFilter
	 * @param languageCode
	 * @return geoUnitNames
	 */
	@RequestMapping(value = "/{nameFilter}/{startIndex}/{maxResults}/{sortBy}"
			+ "/{sortOrder}/{languageCode}/searchGeoUnitByName.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<GeoUnitName> searchGeoUnitByName(
			@PathVariable("nameFilter") String nameFilter,
			@PathVariable("startIndex") int startIndex,
			@PathVariable("maxResults") int maxResults,
			@PathVariable("sortBy") String sortBy,
			@PathVariable("sortOrder") String sortOrder,
			@PathVariable("languageCode") Long languageCode) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | searchGeoUnitByName");

		List<GeoUnitName> geoUnitNames = geographyService.searchGeoUnitByName(
				nameFilter, startIndex, maxResults, sortBy, sortOrder,
				languageCode);

		LOGGER.info("exiting GeographyServiceHttpEndpoint | searchGeoUnitByName");
		return geoUnitNames;
	}

	/**
	 * The end point method to search Geo Unit by code. The method will invoke
	 * the Geography Service class which will search the geo units based on the
	 * code filter condition and the user language preference.
	 * 
	 * @param nameFilter
	 * @param languageCode
	 * @return geoUnitNames
	 */

	@RequestMapping(value = "/{codeFilter}/{startIndex}/{maxResults}/{sortBy}/"
			+ "{sortOrder}/{languageCode}/searchGeoUnitByCode.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<GeoUnitCode> searchGeoUnitByCode(
			@PathVariable("codeFilter") String codeFilter,
			@PathVariable("startIndex") int startIndex,
			@PathVariable("maxResults") int maxResults,
			@PathVariable("sortBy") String sortBy,
			@PathVariable("sortOrder") String sortOrder,
			@PathVariable("languageCode") Long languageCode) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | searchGeoUnitByCode");

		List<GeoUnitCode> geoUnitCodes = geographyService.searchGeoUnitByCode(
				codeFilter, startIndex, maxResults, sortBy, sortOrder,
				RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH);

		LOGGER.info("exiting GeographyServiceHttpEndpoint | searchGeoUnitByCode");
		return geoUnitCodes;
	}

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 * 
	 * @param geoUnitId
	 * @return
	 */
	@RequestMapping(value = "/{geoUnitId}/retrieveGeoUnitByGeoUnitId.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	GeoUnit retrieveGeoUnitByGeoUnitId(@PathVariable("geoUnitId") Long geoUnitId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveGeoUnitByGeoUnitId");

		GeoUnit geoUnit = geographyService
				.retrieveGeoUnitByGeoUnitId(geoUnitId);

		LOGGER.info("exiting GeographyServiceHttpEndpoint | retrieveGeoUnitByGeoUnitId");
		return geoUnit;
	}

	/**
	 * The method will persist the existing Geo Unit data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param GeoUnit
	 * @return workflowTrackingId
	 */
	@RequestMapping(value = "/updateGeoUnit.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateGeoUnit(@RequestBody GeoUnit geoUnit) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | updateGeoUnit.service");
		LOGGER.info("geo unit id : " + geoUnit.getGeoUnitId());
		LOGGER.info("exiting GeographyServiceHttpEndpoint | updateGeoUnit.service");
		return geographyService.updateGeoUnit(geoUnit);
	}

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@RequestMapping(value = "/{nameType}/{languageCode}/retrieveAllCountries.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveAllCountries(
			@PathVariable("nameType") Long nameType,
			@PathVariable("languageCode") Long languageCode) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveAllCountries");

		List<CodeValueVO> codeValueVOs = geographyService.retrieveAllCountries(
				nameType, languageCode);

		LOGGER.info("exiting GeographyServiceHttpEndpoint | retrieveAllCountries");
		return codeValueVOs;
	}

	/**
	 * The method will retrieve all Continent details from the Search DB based
	 * on the name type code and the user preferred language code. The return
	 * type is a VO which contains the Continent Geo Unit Id and the Continent
	 * Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@RequestMapping(value = "/{nameType}/{languageCode}/retrieveAllContinents.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveAllContinents(
			@PathVariable("nameType") Long nameType,
			@PathVariable("languageCode") Long languageCode) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveAllContinents");

		List<CodeValueVO> codeValueVOs = geographyService
				.retrieveAllContinents(nameType, languageCode);

		LOGGER.info("exiting GeographyServiceHttpEndpoint | retrieveAllContinents");
		return codeValueVOs;
	}

	/**
	 * The method will retrieve the Geo Units corresponding to the
	 * parentGeoUnit, geoUnitType, nameType and languageCode which you want to
	 * retrieve the data. The retrieval is from the Search DB. The return type
	 * is a VO which contains the Geo Unit Id and the Geo Unit name.
	 * 
	 * @param languageCode
	 * @param geoUnitType
	 * @param parentGeoUnitId
	 * @param nameType
	 */
	@RequestMapping(value = "/{languageCode}/{geoUnitType}/{parentGeoUnitId}/{nameType}/retrieveChildGeoUnitsByType.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveChildGeoUnitsByType(
			@PathVariable("languageCode") Long languageCode,
			@PathVariable("geoUnitType") Long geoUnitType,
			@PathVariable("parentGeoUnitId") Long parentGeoUnitId,
			@PathVariable("nameType") Long nameType) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveChildGeoUnitsByType");

		List<CodeValueVO> codeValueVOs = geographyService
				.retrieveChildGeoUnitsByType(languageCode, geoUnitType,
						parentGeoUnitId, nameType);

		LOGGER.info("exiting GeographyServiceHttpEndpoint | retrieveChildGeoUnitsByType");
		return codeValueVOs;
	}

	/**
	 * Performs a soft delete on the geoUnitId in the Transactional DB.
	 * <p>
	 * 
	 * The field expectedByDate will be set as Current Date.
	 * <p>
	 * 
	 * @param geoUnitId
	 * @return workflowTrackingId
	 */

	@RequestMapping(value = "/deleteGeoUnitById.service", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody
	Long deleteGeoUnitById(@RequestBody GeoUnit geoUnit) {

		LOGGER.info("entering GeographyServiceHttpEndpoint | deleteGeoUnitByGeoUnitId");
		return geographyService.deleteGeoUnitById(geoUnit.getGeoUnitId());
	}

	/**
	 * 
	 * The method will perform a hierarchy search of geo units on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return list of geographies
	 */
	@RequestMapping(value = "/searchGeographies.service", method = RequestMethod.POST)
	public @ResponseBody
	List<GeographySearch> searchGeographies(
			@RequestBody GeoSearchCriteriaVO geoSearchCriteriaVO) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | searchGeographies");
		return geographyService.searchGeographies(geoSearchCriteriaVO);
	}

	/**
	 * 
	 * The method will count the records in the hierarchy search of geo units on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param geoSearchCriteria
	 * @return countResults
	 */
	@RequestMapping(value = "/countSearchGeographies.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchGeographies(
			@RequestBody GeoSearchCriteriaVO geoSearchCriteriaVO) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | countSearchGeographies");
		return geographyService.countSearchGeographies(geoSearchCriteriaVO);
	}

	/**
	 * 
	 * The method will count the records in the name search of geo units on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchString
	 * @return countResults
	 */
	@RequestMapping(value = "/countSearchGeoUnitByName.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchGeoUnitByName(@RequestBody String searchString) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | countSearchGeoUnitByName");
		return geographyService.countSearchGeoUnitByName(searchString);
	}

	/**
	 * 
	 * The method will count the records in the code search of geo units on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchString
	 * @return countResults
	 */
	@RequestMapping(value = "/countSearchGeoUnitByCode.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchGeoUnitByCode(@RequestBody String searchString) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | countSearchGeoUnitByCode");
		return geographyService.countSearchGeoUnitByCode(searchString);
	}

	/**
	 * 
	 * The method will validate the Geo Unit for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param geoUnitId
	 * @return
	 */
	@RequestMapping(value = "/{geoUnitId}/lockGeoUnit.service", method = RequestMethod.GET)
	public @ResponseBody
	String lockGeoUnit(@PathVariable("geoUnitId") Long geoUnitId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | lockGeoUnit");
		return geographyService.lockGeoUnit(geoUnitId);
	}

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain name on which the request is approved, the domain identifier which
	 * is the unique key to identify the domain and the changeTypeId which is
	 * the key to identify the sub type for domain if any. The method will
	 * return true if the save to staging SoR is success.
	 * 
	 * @param domainName
	 * @param domainId
	 * @param changeTypeId
	 * @return isSaveSuccess
	 */
	@RequestMapping(value = "/{domain}/{domainId}/{changeTypeId}/saveApprovedChanges.service", method = RequestMethod.GET)
	public @ResponseBody 
	Boolean saveApprovedChanges(
			@PathVariable("domain") String domainName,
			@PathVariable("domainId") String domainId,
			@PathVariable("changeTypeId") Long changeTypeId) {
		try{
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedChanges");
		LOGGER.info("Request received from Workflow \ndomainName::"+domainName+"\ndomainId::"+domainId+"\nchangeTypeId::"+changeTypeId);
		Boolean isSaveSuccess = false;

		// if the change is on the Geography domain
		if (RefDataPropertiesConstants.DOMAIN_CODE_GEOGRAPHY.equals(domainName)) {
			isSaveSuccess = saveApprovedGeoUnitChanges(Long.valueOf(domainId), changeTypeId);
		}
		// if the change is on the Currency Exchange domain
		else if (RefDataPropertiesConstants.DOMAIN_CODE_CURRENCY_EXCHANGE
				.equals(domainName)) {
			isSaveSuccess = saveApprovedCurrencyExchanges(Long.valueOf(domainId));
		}
		// if the change is on the Industry Code domain
		else if (RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE
				.equals(domainName)) {
			if (RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_INDUSTRY_CODE
					.equals(String.valueOf(changeTypeId))) {
				isSaveSuccess = deleteApprovedIndustryCodes(Long.valueOf(domainId));
			} else {
				isSaveSuccess = saveApprovedIndustryCodes(Long.valueOf(domainId));
			}
		}
		// if the change is on the XML Schema Labels domain
		else if (RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS
				.equals(domainName)) {
			isSaveSuccess = saveApprovedXmlSchemaLabels(domainId);
		}
		// if the change is on the SCoTS domain
		else if (RefDataPropertiesConstants.DOMAIN_CODE_SCOTS
				.equals(domainName)) {		
			// if the change is on the SCoTS Code Table
			if (RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_CODE_TABLE
					.equals(String.valueOf(changeTypeId)) || RefDataChangeTypeConstants.CHANGE_TYPE_ADD_CODE_TABLE
					.equals(String.valueOf(changeTypeId))){
				isSaveSuccess = saveApprovedCodeTable(Long.valueOf(domainId));
				// if the change is on the SCoTS Code Value
			} else if (RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_CODE_VALUE
					.equals(String.valueOf(changeTypeId)) || RefDataChangeTypeConstants.CHANGE_TYPE_ADD_CODE_VALUE
					.equals(String.valueOf(changeTypeId))){
				isSaveSuccess = saveApprovedCodeValue(Long.valueOf(domainId));
			}
			// if the change is on the SCoTS Code Value Alternate Scheme
			else if (RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_ALTERNATE_SCHEME_CODES
					.equals(String.valueOf(changeTypeId))) {
				isSaveSuccess = saveApprovedCodeValueAlternateScheme(Long
						.valueOf(domainId));
			}
			// if the update is on the system/market applicability
			else if (RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_SYSTEM_APPLICABILITY
					.equals(String.valueOf(changeTypeId))
					|| RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_MARKET_APPLICABILITY
							.equals(String.valueOf(changeTypeId))) {
				isSaveSuccess = saveApprovedApplicabilities(Long.valueOf(domainId), changeTypeId);
			}
			// if the update is on the code relationship
			else if (RefDataChangeTypeConstants.CHANGE_TYPE_MANAGE_SCOTS_RELATIONSHIP
					.equals(String.valueOf(changeTypeId))){
				isSaveSuccess = saveApprovedCodeRelationship(domainId);
			}
		} else if (RefDataPropertiesConstants.DOMAIN_CODE_CONTROL_WORDS.equals(domainName)) {
			// if the change is on the Legal Form Inferment
			if (RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_LEGAL_FORM_INFERMENT.equals(String.valueOf(changeTypeId)) 
					|| RefDataChangeTypeConstants.CHANGE_TYPE_ADD_LEGAL_FORM_INFERMENT.equals(String.valueOf(changeTypeId))
					|| RefDataChangeTypeConstants.CHANGE_TYPE_ADD_INDUSTRY_CODE_INFERMENT.equals(String.valueOf(changeTypeId))
					|| RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_INDUSTRY_CODE_INFERMENT.equals(String.valueOf(changeTypeId))) {
				isSaveSuccess = saveApprovedInfermentText(Long.valueOf(domainId));
			} else if(RefDataChangeTypeConstants.CHANGE_TYPE_ADD_PHONE_AREA_CODE_NUMBER.equals(String.valueOf(changeTypeId)) || RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_PHONE_AREA_CODE_NUMBER.equals(String.valueOf(changeTypeId))){
				isSaveSuccess = saveApprovedPhoneAreaCode(Long.valueOf(domainId));
			} else {
				isSaveSuccess = saveApprovedControlWords(Long.valueOf(domainId), changeTypeId);
			}
		}else if (RefDataPropertiesConstants.DOMAIN_CODE_FINANCIAL_TEMPLATES
				.equals(domainName)) {
			isSaveSuccess = saveApprovedFinancialTemplates(Long.valueOf(domainId));
		}
			return isSaveSuccess;
		}catch(Exception e){
			LOGGER.info(" GeographyServiceHttpEndpoint | saveApprovedChanges"+e.getMessage());
			LOGGER.error(" GeographyServiceHttpEndpoint | saveApprovedChanges",e);
			return false;
		}
		
	}
	/**
	 * 
	 * The method will save the approved Legal Form Inferment changes to the Staging SoR.
	 * 
	 * @param domainId
	 * @param changeTypeId
	 * @return isSuccess
	 */
	private Boolean saveApprovedInfermentText(Long domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedLegalFormInferment");
		Long infermentTextId;
		try {
			infermentTextId = controlWordsService.saveApprovedInfermentText(domainId);
			// if update to Staging SoR is success then remove the
			// Inferment Text entries from the Transaction DB. The
			// delete will be based on the infr_txt_id
			controlWordsService.removeApprovedInfermentText(infermentTextId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			infermentTextId = 0L;
		}
		return infermentTextId > 0 ? true : false;
	}
	/**
	 * 
	 * The method will save the approved Geo Unit changes to the Staging SoR.
	 *
	 * @param domainId
	 * @param changeTypeId
	 * @return isSaveSuccess boolean
	 */
	private Boolean saveApprovedGeoUnitChanges(Long domainId, Long changeTypeId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedGeoUnitChanges");
		Long geoUnitId;
		try {
			geoUnitId = geographyService.saveApprovedGeoChanges(domainId, changeTypeId);
			// if update to Staging SoR is success then remove the GeoUnit entries
			// from the Transaction DB. The delete will be based on the geo_unit_id
			geographyService.removeApprovedGeoUnit(geoUnitId,changeTypeId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			geoUnitId = 0L;
		}
		return geoUnitId > 0 ? true : false;
	}
	
	/**
	 * 
	 * The method will save the approved Currency Exchange changes to the Staging SoR.
	 *
	 * @param trackingId
	 * @return isSaveSuccess boolean
	 */
	private Boolean saveApprovedCurrencyExchanges(Long domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedCurrencyExchanges");
		Long curcyExchId;
		try {
			curcyExchId = currencyService.saveApprovedCurrencyExchanges(domainId);
			// if update to Staging SoR is success then remove the
			// CurrencyExchange entries from the Transaction DB. The 
			// delete will be based on the crcy_exch_id
			currencyService.removeApprovedCurrencyExchange(curcyExchId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			curcyExchId = 0L;
		}
		return curcyExchId > 0 ? true : false;
	}
	/**
	 * 
	 * The method will save the approved Industry Code changes to the Staging SoR.
	 *
	 * @param domainId
	 * @return isSuccess
	 */
	private Boolean saveApprovedIndustryCodes(Long domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedIndustryCodes");
		Long indsCodeId;
		try {
			indsCodeId = industryService.saveApprovedIndustryCodes(domainId);
			// if update to Staging SoR is success then remove the
			// IndustryCode entries from the Transaction DB. The 
			// delete will be based on the inds_code_id
			industryService.removeApprovedIndustryCode(indsCodeId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			indsCodeId = 0L;
		}
		return indsCodeId > 0 ? true : false;
	}
	
	/**
	 * 
	 * The method will delete the approved txn from the Industry Codes Staging SoR
	 *
	 * @param domainId
	 * @return isSuccess
	 */
	private Boolean deleteApprovedIndustryCodes(Long domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | deleteApprovedIndustryCodes");
		try {
			industryService.removeApprovedIndustryCodeFromStaging(domainId);
			// if update to Staging SoR is success then remove the
			// IndustryCode entries from the Transaction DB. The 
			// delete will be based on the inds_code_id
			industryService.removeSavedRecord(domainId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
		}
		return true;
	}
	/**
	 * 
	 * The method will save the approved Xml Schema Label changes to the Staging SoR.
	 *
	 * @param domainId
	 * @return isSuccess
	 */
	private Boolean saveApprovedXmlSchemaLabels(String domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedXmlSchemaLabels");
		String xmlSchemaLabelId;
		try {
			xmlSchemaLabelId = xmlSchemaLabelService.saveApprovedXmlSchemaLabels(domainId);
			// if update to Staging SoR is success then remove the
			// XmlSchemaLabel  entries from the Transaction DB. The 
			// delete will be based on the xml_scma_lbl_id
			xmlSchemaLabelService.removeApprovedXmlSchemaLabels(xmlSchemaLabelId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			xmlSchemaLabelId = null;
		}
		return xmlSchemaLabelId != null ? true : false;
	}
	/**
	 * 
	 * The method will save the approved Code Table changes to the Staging SoR.
	 *
	 * @param domainId
	 * @return isSuccess
	 */
	private Boolean saveApprovedCodeTable(Long domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedCodeTable");
		Long codeTableId;
		try {
			codeTableId = scotsService.saveApprovedCodeTable(domainId);
			// if update to Staging SoR is success then remove the
			// CodeTable entries from the Transaction DB. The 
			// delete will be based on the cd_tbl_id
			scotsService.removeApprovedCodeTable(codeTableId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			codeTableId = 0L;
		}
		
		return codeTableId > 0 ? true : false;
	}
	
	
         /**
	 * 
	 * The method will save the approved Code Value changes to the Staging SoR.
	 *
	 * @param domainId
	 * @param changeTypeId
	 * @return isSuccess
	 */
	private Boolean saveApprovedCodeValue(Long domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedCodeValue");
		Long codeValueId;
		try {
			codeValueId = scotsService.saveApprovedCodeValue(domainId);
			// if update to Staging SoR is success then remove the
			// CodeValue entries from the Transaction DB. The 
			// delete will be based on the cd_val_id
			scotsService.removeApprovedCodeValue(codeValueId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred while saveApprovedCodeValue : " + e);
			codeValueId = 0L;
		}
		return codeValueId > 0 ? true : false;
	}
	/**
	 * 
	 * The method will save the approved Code Value Alternate Scheme changes to the Staging SoR.
	 * 
	 * @param domainId
	 * @param changeTypeId
	 * @return isSuccess
	 */
	private Boolean saveApprovedCodeValueAlternateScheme(Long domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedCodeValueAlternateScheme");
		Long alternateSchemeTypeCode;
		try {
			alternateSchemeTypeCode = scotsService.saveApprovedCodeValueAlternateScheme(domainId);
			// if update to Staging SoR is success then remove the
			// CodeValueAlternateScheme entries from the Transaction DB. The
			// delete will be based on the alt_schm_typ_cd
			scotsService.removeApprovedCodeValueAlternateScheme(alternateSchemeTypeCode);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			alternateSchemeTypeCode = 0L;
		}
		return alternateSchemeTypeCode > 0 ? true : false;
	}

	/**
	 * 
	 * The method will save the approved System applicability changes to the
	 * Staging SoR.
	 *
	 * @param domainId
	 * @param changeTypeId
	 * @return isSuccess
	 */
	private Boolean saveApprovedApplicabilities(Long domainId, Long changeTypeId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedApplicabilities");
		Long codeTableId;
		try {
			codeTableId = scotsService.saveApprovedApplicabilities(domainId, changeTypeId);
			// if update to Staging SoR is success then remove the
			// System/Market applicability entries from the Transaction DB. The 
			// delete will be based on the sys_appy_typ_cd
			scotsService.removeApprovedTxnApplicabilities(codeTableId, changeTypeId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			codeTableId = 0L;
		}
		return codeTableId > 0 ? true : false;
	}

/**
	 * 
	 * The method will save the approved SCoTS Relationship changes to the Staging SoR.
	 *
	 * @param domainId
	 * @return isSuccess
	 */
	private Boolean saveApprovedCodeRelationship(String domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedCodeRelationship");
		List<Long> associationIds;
		try {
			associationIds = scotsService.saveApprovedCodeRelationship(domainId);
			// if update to Staging SoR is success then remove the
			// Code Relationship entries from the Transaction DB. The 
			// delete will be based on the sys_appy_typ_cd
			scotsService.removeApprovedCodeRelationship(associationIds);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			associationIds = null;
		}
		return associationIds != null ? true : false;
	}

	private Boolean saveApprovedControlWords(Long domainId, Long changeTypeId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedControlWords");
		boolean isSaveSuccess = true;
		try {
			controlWordsService.saveApprovedControlWords(domainId, changeTypeId);
			controlWordsService.removeApprovedControlWords(domainId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			isSaveSuccess = false;
		}
		return isSaveSuccess;
	}

	private Boolean saveApprovedFinancialTemplates(Long domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedFinancialTemplates");
		boolean isSaveSuccess = true;
		try {
			fsService.saveApprovedFinancialTemplates(domainId);
			fsService.removeApprovedFinancialTemplates(domainId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			isSaveSuccess = false;
		}
		return isSaveSuccess;
	}

	/**
	 * The method will be invoked by the when the the business owner reviews the
	 * changes submitted for his approval. The user reviews the changes and he
	 * could approve or reject the request.
	 * 
	 * @param trackingId
	 */
	@RequestMapping(value = "/{domainId}/reviewGeoUnitChanges.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	GeoUnit reviewGeoUnitChanges(@PathVariable("domainId") Long domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | reviewGeoUnitChanges");
		return geographyService.reviewGeoUnitChanges(domainId);
	}

	/**
	 * The method will retrieve all Country Groups from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Group Geo Unit Id and the Country
	 * Names.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	@RequestMapping(value = "/{nameType}/{languageCode}/retrieveAllCountryGroups.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveAllCountryGroups(
			@PathVariable("nameType") Long nameType,
			@PathVariable("languageCode") Long languageCode) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveAllCountryGroups");

		List<CodeValueVO> codeValueVOs = geographyService
				.retrieveAllCountryGroups(nameType, languageCode);

		LOGGER.info("exiting GeographyServiceHttpEndpoint | retrieveAllCountryGroups");
		return codeValueVOs;
	}

	/**
	 * Retrieves all the country groups or the country groups under the given
	 * country group
	 * <p>
	 * The returned List of Geo Unit Names will be displayed in the search
	 * result page in Country Groups.
	 * <p>
	 * 
	 * @param nameTypeCode
	 * @param writingScriptCode
	 * @param geoUnitId
	 * @param langCode
	 * @return a List of GeoUnit Name
	 */
	@RequestMapping(value = "/{langCode}/{writingScriptCode}/{nameTypeCode}/{geoUnitId}/searchCountryGroups.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<GeoUnitName> searchCountryGroups(
			@PathVariable("nameTypeCode") Long nameTypeCode,
			@PathVariable("writingScriptCode") Long writingScriptCode,
			@PathVariable("geoUnitId") Long geoUnitId,
			@PathVariable("langCode") Long langCode) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | searchCountryGroups");

		List<GeoUnitName> countryGroupsList = geographyService
				.searchCountryGroups(langCode, writingScriptCode, nameTypeCode,
						geoUnitId);

		LOGGER.info("exiting GeographyServiceHttpEndpoint | searchCountryGroups");
		return countryGroupsList;
	}

	/**
	 * The method will persist new Geo Unit data in the Transactional DB.
	 * 
	 * @param GeoUnit
	 * @return workflowTrackingId
	 */
	@RequestMapping(value = "/insertGeoUnit.service", method = RequestMethod.POST)
	public @ResponseBody
	Long insertGeoUnit(@RequestBody GeoUnit geoUnit) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | insertGeoUnit.service");
		return geographyService.insertGeoUnit(geoUnit);
	}

	/**
	 * 
	 * The method will retrieve all geography hierarchies
	 * 
	 * @return geoHierarchies
	 */
	@RequestMapping(value = "/retrieveAllGeoHierarchies.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<GeoHierarchy> retrieveAllGeoHierarchies() {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveAllGeoHierarchies");
		return geographyService.retrieveAllGeoHierarchies();
	}
	
	/**
	 * 
	 * The method will retrieve all geography default configurations
	 * 
	 * @return geoDefaultConfigurations
	 */
	@RequestMapping(value = "/retrieveAllGeoConfigurations.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<GeoDefaultConfiguration> retrieveAllGeoConfigurations() {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveAllGeoConfigurations");
		return geographyService.retrieveAllGeoConfigurations();
	}
	
	@RequestMapping(value = "/{geoUnitId}/checkForChildGeoUnit.service", method = RequestMethod.GET)
	public @ResponseBody
	Boolean checkForChildGeoUnit(@PathVariable("geoUnitId") Long geoUnitId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | checkForChildGeoUnit");
		return geographyService.checkForChildGeoUnit(geoUnitId);
	}

	/**
	 * 
	 * The method will retrieve all user group mappings available within refdata.
	 * 
	 * @return userGroupMappings
	 */
	@RequestMapping(value = "/retrieveAllUserGroupMappings.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<UserGroupMapping> retrieveAllUserGroupMappings() {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveAllUserGroupMappings");
		return geographyService.retrieveAllUserGroupMappings();
	}
	
	@RequestMapping(value = "/{geoUnitId}/{geoUnitTypeCode}/getHierarchyByGeoUnitId.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	Map<Long, String> getHierarchyByGeoUnitId(
			@PathVariable("geoUnitId") Long geoUnitId,
			@PathVariable("geoUnitTypeCode") Long geoUnitTypeCode) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | getHierarchyByGeoUnitId");

		Map<Long, String> hierarchyList = geographyService
				.getHierarchyByGeoUnitId(geoUnitId, geoUnitTypeCode);

		LOGGER.info("exiting GeographyServiceHttpEndpoint | getHierarchyByGeoUnitId");
		return hierarchyList;
	}
	
	@RequestMapping(value = "/{parentGeoUnitId}/{geoUnitId}/{geoUnitTypeCode}/getOfficialNameByGeoUnitIdAndTypeCode.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	String getOfficialNameByGeoUnitIdAndTypeCode(
			@PathVariable("parentGeoUnitId") Long parentGeoUnitId,
			@PathVariable("geoUnitId") Long geoUnitId,
			@PathVariable("geoUnitTypeCode") Long geoUnitTypeCode) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | getOfficialNameByGeoUnitIdAndTypeCode");
		return geographyService.getOfficialNameByGeoUnitIdAndTypeCode(
				parentGeoUnitId, geoUnitId, geoUnitTypeCode);
	}

	@RequestMapping(value = "/retrieveGeoUnitsByIdList.service", method = RequestMethod.POST)
	public @ResponseBody
	Map<Long, List<GeoUnit>> retrieveGeoUnitsByIdList(
			@RequestBody List<Long> geoUnitIds) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveGeoUnitsByIdList");
		LOGGER.info("geoUnitIds : " + geoUnitIds);
		LOGGER.info("exiting GeographyServiceHttpEndpoint | retrieveGeoUnitsByIdList");
		return geographyService.retrieveGeoUnitsByIdList(geoUnitIds);
	}
	
	/**
	 * The method will search the Staging SoR for the UiBulkDownload based on
	 * the geoUnitId and will return the GeoHierarchy entity.
	 * 
	 * @param geoUnitId
	 * @return GeoHierarchy
	 */
	@RequestMapping(value = "/{geoUnitId}/retrieveGeoUnitType.service", method = RequestMethod.GET)
	public @ResponseBody
	List<GeoHierarchy> retrieveGeoUnitType(
			@PathVariable("geoUnitId") Long geoUnitId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveGeoUnitType");

		return geographyService.retrieveGeoUnitType(geoUnitId);

	}
	
	/**
	 * The method will add UiBulkDownload data in the Transactional DB.
	 * 
	 * @param UiBulkDownload
	 * @return id
	 */
	@RequestMapping(value = "/addGeoUIBulkDownload.service", method = RequestMethod.POST)
	public @ResponseBody
	Long addUIBulkDownload(@RequestBody UiBulkDownload uiBulkDownload) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | addUIBulkDownload.service");
		LOGGER.info("GeographyId : " + uiBulkDownload.getDomainName());
		LOGGER.info("exiting GeographyServiceHttpEndpoint | addUIBulkDownload.service");
		return geographyService.addUIBulkDownload(uiBulkDownload);
	}	
	
	/**
	 * The method will search the Staging SoR for the UiBulkDownload based on
	 * the geoUnitId and will return the GeoHierarchy entity.
	 * 
	 * @param geoUnitId
	 * @return GeoHierarchy
	 */
	@RequestMapping(value = "/{geoUnitId}/retrieveGeoUnitHierarchies.service", method = RequestMethod.GET)
	public @ResponseBody
	List<GeoHierarchy> rretrieveGeoUnitHierarchies(
			@PathVariable("geoUnitId") Long geoUnitId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveGeoUnitHierarchies");

		return geographyService.retrieveGeoUnitHierarchies(geoUnitId);

	}
	
	private Boolean saveApprovedPhoneAreaCode(Long domainId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | saveApprovedPhoneAreaCode");
		boolean isSaveSuccess = true;
		try {
			controlWordsService.saveApprovedPhoneAreaCode(domainId);
			controlWordsService.removeApprovedPhoneAreaCode(domainId);
		} catch (Exception e) {
			LOGGER.error("Exception occurred : " + e);
			isSaveSuccess = false;
		}
		return isSaveSuccess;
	}
	
	
	/**
	 * the method to return all geoUnit Types
	 * @return
	 */
	@RequestMapping(value = "/retrieveAllGeoUnitTypes.service", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveAllGeoUnitTypes() {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveAllGeoUnitTypes");
		return geographyService.retrieveAllGeoUnitTypes();
	}
	/**
	 * 
	 * The method to retrieve all applicable GeoUnit Names
	 *
	 * @return
	 */
	@RequestMapping(value = "/retrieveApplicableGeoNameTypes.service", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveApplicableGeoNameTypes() {
		LOGGER.info("entering GeographyServiceHttpEndpoint | retrieveApplicableGeoNameTypes");
		return geographyService.retrieveApplicableGeoNameTypes();
	}	
}
