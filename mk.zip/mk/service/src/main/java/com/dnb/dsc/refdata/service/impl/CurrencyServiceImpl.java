/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.entity.GeoCurrency;
import com.dnb.dsc.refdata.core.vo.AddGeoCurrencyVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.CurrencySearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.GeoCurrencySearchVO;
import com.dnb.dsc.refdata.dao.CrcyStagingDAO;
import com.dnb.dsc.refdata.dao.CrcyTransactionalDAO;
import com.dnb.dsc.refdata.service.CurrencyService;

/**
 * This is used as the Service implementation class for the Currency Exchange
 * operations.
 * 
 * @author Cognizant
 * @version last updated : Feb 29, 2012
 * @see
 * 
 */
@Service("CurrencyService")
public class CurrencyServiceImpl implements CurrencyService {

	@Autowired
	private CrcyStagingDAO stagingDAO;

	@Autowired
	private CrcyTransactionalDAO transactionalDAO;

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CurrencyServiceImpl.class);

	/**
	 * 
	 * The method will perform a hierarchy search of Currency Exchange on the
	 * search db.
	 * <p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param currencySearchCriteria
	 * @return list of CurrencyExchange
	 */
	@Override
	@Transactional("stgTransactionManager")
	public List<CurrencyExchange> searchCurrencyExchange(
			CurrencySearchCriteriaVO currencySearchCriteria) {
		LOGGER.info("entering CurrencyServiceImpl | searchCurrencyExchange");
		return stagingDAO.searchCurrencyExchange(currencySearchCriteria);
	}

	/**
	 * The method to retrieve all data providers for the currency exchange data.
	 * The data will be fetched from the currency exchange tables.
	 * 
	 * @param languageCode
	 */
	@Override
	@Transactional("stgTransactionManager")
	public List<CodeValueVO> retrieveCurcyExchDataProviders(Long languageCode) {
		LOGGER.info("entering CurrencyServiceImpl | retrieveCurcyExchDataProviders");
		return stagingDAO.retrieveCurcyExchDataProviders(languageCode);
	}

	/**
	 * 
	 * The method will count the records in the hierarchy search of currency
	 * units on the search db. The search will be done on the flat db based on
	 * the search criteria the user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return countResults
	 */
	@Override
	@Transactional("stgTransactionManager")
	public Long countSearchCurrencyExchange(
			CurrencySearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering CurrencyServiceImpl | countSearchCurrencyExchange");
		return stagingDAO.countSearchCurrencyExchange(searchCriteriaVO);
	}

	/**
	 * The method will persist the existing Currency Exchange data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param currencyExchange
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long updateExchangeRate(CurrencyExchange currencyExchange) {
		LOGGER.info("entering CurrencyServiceImpl | updateExchRate");
		LOGGER.info("entering CurrencyServiceImpl | updateExchRate"
				+ currencyExchange);
		CurrencyExchange currencyExchangeReceiver = transactionalDAO
				.updateExchangeRate(currencyExchange);
		LOGGER.info("Exchange Rate updated with Id : "
				+ currencyExchangeReceiver.getCurrencyExchangeId());
		return currencyExchangeReceiver.getCurrencyExchangeId();
	}

	/**
	 * 
	 * The method will validate the Currency Exchange for any locks (If already
	 * been opened by any other user for edit). If no lock is currently
	 * available then the method will lock the record and return FALSE
	 * indicating no lock currently. But if a lock already exists, the method
	 * will return TRUE. The lock operation will be performed in the
	 * Transactional DB.
	 * 
	 * @param geoUnitId
	 * @return
	 */
	@Override
	public String lockCurrencyExchange(Long currencyExchangeId) {
		LOGGER.info("entering CurrencyServiceImpl | lockCurrencyExchange");
		String count = transactionalDAO
				.countCurrencyExchange(currencyExchangeId);
		if (count == null || count.isEmpty()) {
			return "false";
		} else {
			return count;
		}
	}

	/**
	 * Invoked when the the business owner reviews the changes submitted for his
	 * approval. The user reviews the changes and he could approve or reject the
	 * request.
	 * <p>
	 * 
	 * @param trackingId
	 * @return CurrencyExchange
	 */
	@Override
	@Transactional("txnTransactionManager")
	public CurrencyExchange reviewCurrencyExchangeChanges(Long trackingId) {
		LOGGER.info("entering CurrencyServiceImpl | reviewCurrencyExchangeChanges");
		CurrencyExchange txnCrcyExchange = retrieveCurrencyExchangeByTrackingId(trackingId);
		CurrencyExchange stgCrcyExchange = retrieveCurrencyExchangeByCurrencyExchangeId(txnCrcyExchange
				.getCurrencyExchangeId());
		if (null != stgCrcyExchange) {
			if (null != stgCrcyExchange.getCurrencyExchangeRate()) {
				txnCrcyExchange.setOldCurrencyExchangeRate(stgCrcyExchange
						.getCurrencyExchangeRate());
			} else {
				txnCrcyExchange.setOldCurrencyExchangeRate(txnCrcyExchange
						.getCurrencyExchangeRate());
			}
		}
		LOGGER.info("exiting CurrencyServiceImpl | reviewCurrencyExchangeChanges");
		return txnCrcyExchange;
	}

	/**
	 * Retrieves the CurrencyExchange based on the Work-flow Tracking Id.
	 * Invoked from the Work-flow Component and the search will be performed on
	 * the Transactional DB.
	 * <p>
	 * 
	 * @param trackingId
	 * @return CurrencyExchange
	 */
	@Override
	@Transactional("txnTransactionManager")
	public CurrencyExchange retrieveCurrencyExchangeByTrackingId(Long trackingId) {
		LOGGER.info("entering CurrencyServiceImpl | retrieveCurrencyExchangeByTrackingId");
		CurrencyExchange currencyExchage = transactionalDAO
				.retrieveCurrencyExchangeByTrackingId(trackingId);
		LOGGER.info("exiting CurrencyServiceImpl | retrieveCurrencyExchangeByTrackingId");
		return currencyExchage;
	}

	/**
	 * The method will search the Staging SoR for the CurrencyExchange based on
	 * the currencyExchangeId and will return the GeoUnit entity.
	 * <p>
	 * 
	 * @param currencyExchangeId
	 * @return CurrencyExchange
	 */
	@Override
	@Transactional("stgTransactionManager")
	public CurrencyExchange retrieveCurrencyExchangeByCurrencyExchangeId(
			Long currencyExchangeId) {
		LOGGER.info("entering CurrencyServiceImpl | retrieveCurrencyExchangeByCurrencyExchangeId");
		CurrencyExchange currencyExchage = stagingDAO
				.retrieveCurrencyExchangeByCurrencyExchangeId(currencyExchangeId);
		LOGGER.info("exiting CurrencyServiceImpl | retrieveCurrencyExchangeByCurrencyExchangeId");
		return currencyExchage;
	}

	/**
	 * The method will search the Transaction SoR for the CurrencyExchange based
	 * on the currencyExchangeId and will return the GeoUnit entity.
	 * <p>
	 * 
	 * @param currencyExchangeId
	 * @return CurrencyExchange
	 */
	@Override
	@Transactional("stgTransactionManager")
	public CurrencyExchange retrieveTxnCurrencyExchangeById(
			Long currencyExchangeId) {
		LOGGER.info("entering CurrencyServiceImpl | retrieveTxnCurrencyExchangeById");
		CurrencyExchange currencyExchage = transactionalDAO
				.retrieveCurrencyExchangeByCurrencyExchangeId(currencyExchangeId);
		LOGGER.info("exiting CurrencyServiceImpl | retrieveTxnCurrencyExchangeById");
		return currencyExchage;
	}

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 * 
	 * @param domainId
	 * @return isSaveSuccess
	 */
	@Override
	@Transactional("stgTransactionManager")
	public Long saveApprovedCurrencyExchanges(Long domainId) {
		LOGGER.info("entering CurrencyServiceImpl | saveApprovedCurrencyExchanges");
		// Retrieve the currencyExchage details from the Work flow tracking
		// table
		CurrencyExchange currencyExchage = retrieveCurrencyExchangeByTrackingId(domainId);
		// Updates the currencyExchage details to the Staging SoR
		stagingDAO.updateExchangeRate(currencyExchage);

		LOGGER.info("exiting CurrencyServiceImpl | saveApprovedCurrencyExchanges");
		return currencyExchage.getCurrencyExchangeId();
	}

	/**
	 * The method will remove the crcyExch data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 * 
	 * @param currencyExchId
	 * @param boolean indicating the status
	 */
	@Override
	@Transactional("txnTransactionManager")
	public void removeApprovedCurrencyExchange(Long currencyExchId) {
		transactionalDAO.removeApprovedCurrencyExchange(currencyExchId);
	}

	/**
	 * 
	 * Performs a hierarchy search of Geo Currency on the SOR db.
	 * <p>
	 * 
	 * The search will be done on the db based on the search criteria the user
	 * had provided.
	 * 
	 * @param geoCurrencySearchVO
	 * @return list of GeoCurrency
	 */
	@Override
	public List<GeoCurrency> searchGeoCurrency(
			GeoCurrencySearchVO geoCurrencySearchVO) {
		LOGGER.info("entering CurrencyServiceImpl | searchCurrencyExchange");
		return stagingDAO.searchGeoCurrency(geoCurrencySearchVO);
	}

	/**
	 * 
	 * The method will count the records in the geo currency table based on user
	 * inputs in db. The search will be done on the SOR db based on the search
	 * criteria the user had provided.
	 * 
	 * @param geoCurrencySearchCriteria
	 * @return countResults
	 */
	@Override
	public Long countSearchGeoCurrency(GeoCurrencySearchVO geoCurrencySearchVO) {
		LOGGER.info("entering CurrencyServiceImpl | countSearchCurrencyExchange");
		return stagingDAO.countSearchGeoCurrency(geoCurrencySearchVO);
	}

	/**
	 * The method will persist the existing Geo Currency data in the SOR DB.
	 * Only the changed relational data will be inserted.
	 * 
	 * @param geoCurrency
	 */
	@Override
	@Transactional("stgTransactionManager")
	public Long insertGeoCurrency(AddGeoCurrencyVO addGeoCurrencyVO) {

		GeoCurrency geoCurrency = new GeoCurrency();
		Long geoCurrencyId = null;

		LOGGER.info("entering CurrencyServiceImpl | insertGeoCurrency");
		geoCurrencyId = stagingDAO.retrieveMaxGeoCurrencyId();
		geoCurrency.setGeoCurrencyId(geoCurrencyId);
		geoCurrency.setGeoUnitId(addGeoCurrencyVO.getGeoCrcyCountry());
		geoCurrency.setCurrencyCode(addGeoCurrencyVO.getCurrencyCode());
		geoCurrency.setEffectiveDate(addGeoCurrencyVO.getEffectiveDate());
		geoCurrency.setEndDate(null);
		geoCurrency.setCreatedUser(addGeoCurrencyVO.getCreatedUser());
		geoCurrency.setCreatedDate(addGeoCurrencyVO.getCreatedDate());
		geoCurrency.setModifiedUser(addGeoCurrencyVO.getModifiedUser());
		geoCurrency.setModifiedDate(addGeoCurrencyVO.getModifiedDate());
		GeoCurrency newGeoCurrency = stagingDAO.insertGeoCurrency(geoCurrency);

		LOGGER.info(
				"Exiting CurrencyServiceImpl | insertGeoCurrency | Added Geo Currency",
				newGeoCurrency);

		return geoCurrencyId;
	}
	
@Override
	@Transactional("stgTransactionManager")
	public GeoCurrency reviewGeoCurrency(Long geoCurrencyId) {
		LOGGER.info("entering CurrencyServiceImpl | reviewGeoCurrency");		
		GeoCurrency geoCurrency = stagingDAO.retrieveGeoCurrencyByGeoCurrencyId(geoCurrencyId);		
		LOGGER.info("exiting CurrencyServiceImpl | reviewGeoCurrency");
		return geoCurrency;
	}

	@Override
	@Transactional("stgTransactionManager")
	public Long updateGeoCurrency(GeoCurrency geoCurrency) {
		
		LOGGER.info("entering CurrencyServiceImpl | updateGeoCurrency");		
		
		GeoCurrency geoCurrencyToUpdate = stagingDAO.retrieveGeoCurrencyByGeoCurrencyId(geoCurrency.getGeoCurrencyId());
		
		geoCurrency.setGeoUnitId(geoCurrencyToUpdate.getGeoUnitId());
		geoCurrency.setCurrencyCode(geoCurrencyToUpdate.getCurrencyCode());
		geoCurrency.setEffectiveDate(geoCurrencyToUpdate.getEffectiveDate());
		geoCurrency.setCreatedDate(geoCurrencyToUpdate.getCreatedDate());
		geoCurrency.setCreatedUser(geoCurrencyToUpdate.getCreatedUser()); 
		
		GeoCurrency newGeoCurrency = stagingDAO.updateGeoCurrency(geoCurrency);
		LOGGER.info("Exiting CurrencyServiceImpl | updateGeoCurrency::"+newGeoCurrency);

		return geoCurrency.getGeoCurrencyId();
	}	
	
}
