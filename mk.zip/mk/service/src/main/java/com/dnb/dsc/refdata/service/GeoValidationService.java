/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service;

/**
 * This is used as the services interface for the Geography operations
 *
 * @author Cognizant
 * @version last updated : Feb 06, 2012
 * @see
 *
 */
public interface GeoValidationService {

	/**
	 * Validates the geoUnit to check for active child records before proceeding with the soft delete on the geoUnit.<p>
	 *
	 * @param geoUnitId
	 * @return a Boolean status flag.
	 */
	Boolean checkForChildGeoUnit(Long geoUnitId);

}
