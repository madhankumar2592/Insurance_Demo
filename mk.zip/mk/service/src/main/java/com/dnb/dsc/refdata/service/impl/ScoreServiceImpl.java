package com.dnb.dsc.refdata.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GranularityType;
import com.dnb.dsc.refdata.core.entity.Score;
import com.dnb.dsc.refdata.core.entity.ScoreDetails;
import com.dnb.dsc.refdata.core.entity.ScoreGranularity;
import com.dnb.dsc.refdata.core.entity.ScoreGranularityAssociation;
import com.dnb.dsc.refdata.core.entity.ScoreMap;
import com.dnb.dsc.refdata.core.entity.ScoreMapping;
import com.dnb.dsc.refdata.core.entity.ScoreType;
import com.dnb.dsc.refdata.core.entity.ScoreTypeAssociation;
import com.dnb.dsc.refdata.core.vo.AddNewScoreVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.EditScoreSearchVO;
import com.dnb.dsc.refdata.core.vo.GranularityDetailVO;
import com.dnb.dsc.refdata.core.vo.GranularityValueVO;
import com.dnb.dsc.refdata.core.vo.ScoreDtlVO;
import com.dnb.dsc.refdata.core.vo.ScoreSearchVO;
import com.dnb.dsc.refdata.core.vo.ScoreVO;
import com.dnb.dsc.refdata.dao.ScoreStagingDAO;
import com.dnb.dsc.refdata.service.ScoreService;


/**
 * This is used as the services interface for the Score operations
 * 
 * @author Cognizant
 * @version last updated : Aug 21, 2014
 * @see
 * 
 */
@Service("ScoreService")
public class ScoreServiceImpl implements ScoreService{
	
	
	@Autowired
	private ScoreStagingDAO stagingDAO;
	
	private static final Logger LOGGER = LoggerFactory
	.getLogger(ScoreServiceImpl.class);
	
	
	@Override
	@Transactional("stgTransactionManager")
	public List<CodeValueVO> retrieveGranularityCodes(String capabilityCode) {
		LOGGER.info("entering ScoreServiceImpl | retrieveGranularityCodes");
		return stagingDAO.retrieveGranularityCodes(capabilityCode);
	}

	@Override
	@Transactional("stgTransactionManager")
	public Long updateGranularityCode(GranularityValueVO granularityValueVO) {
		
		List<GranularityType> granuList = new ArrayList<GranularityType>();
		Long scoreTypeId = null;
		ScoreType scoreTypes = new ScoreType();
		if (granularityValueVO.getScoreTypeCode()!=null) {
			String queryScrTyp = "SELECT count(s.SCR_TYP_ID) FROM SCR_TYP s where s.SCR_TYP_CD="+granularityValueVO.getScoreTypeCode();
			Long countForScoreTypeCode = stagingDAO.retrieveMaxCount(queryScrTyp);
			ScoreType scoreType = new ScoreType();
			if(countForScoreTypeCode>0) {
				String queryScrTypId = "SELECT s.SCR_TYP_ID FROM SCR_TYP s where s.SCR_TYP_CD="+granularityValueVO.getScoreTypeCode();
				scoreTypeId = stagingDAO.retrieveMaxCount(queryScrTypId);
				ScoreType scoreTypeObj = stagingDAO.findScoreType(scoreTypeId);
				scoreTypeObj.setModifiedUser(granularityValueVO.getModifiedUser());
				scoreTypeObj.setModifiedDate(granularityValueVO.getModifiedDate());
				scoreTypes = stagingDAO.updateScoreTypeRec(scoreTypeObj);
			}else if(countForScoreTypeCode==0){
				scoreTypeId = stagingDAO.retrieveMaxScoreTypeId();
				scoreType.setScoreTypeId(scoreTypeId);
				scoreType.setScoreTypeCode(granularityValueVO.getScoreTypeCode());
				scoreType.setCreatedUser(granularityValueVO.getCreatedUser());
				scoreType.setCreatedDate(granularityValueVO.getCreatedDate());
				scoreType.setModifiedUser(granularityValueVO.getModifiedUser());
				scoreType.setModifiedDate(granularityValueVO.getModifiedDate());
				scoreType.setInactiveIndicator(1L);
				scoreTypes = stagingDAO.updateScoreTypeRec(scoreType);
			}
				
		} 
		if(granularityValueVO.getGranularityDetailVO()!=null) {
			
			for(GranularityDetailVO granularityDetailVONew : granularityValueVO.getGranularityDetailVO()) {
				Long granularityTypeId=null;
				String queryGruTyp = "SELECT count(s.SCR_GRU_ID) FROM SCR_GRU s where s.SCR_GRU_CD="+granularityDetailVONew.getGranularityTypeCode();
				Long countForGranTypeCode = stagingDAO.retrieveMaxCount(queryGruTyp);
				GranularityType granularityType = new GranularityType();
				if(countForGranTypeCode>0){
					String queryScrGruId = "SELECT s.SCR_GRU_ID FROM SCR_GRU s where s.SCR_GRU_CD="+granularityDetailVONew.getGranularityTypeCode();
					granularityTypeId = stagingDAO.retrieveMaxCount(queryScrGruId);
					GranularityType granuTypeObj = stagingDAO.findGranuType(granularityTypeId);
					granuTypeObj.setModifiedUser(granularityDetailVONew.getModifiedUser());
					granuTypeObj.setModifiedDate(granularityDetailVONew.getModifiedDate());
					stagingDAO.updateGranularityTypeRec(granuTypeObj);
					granuList.add(granuTypeObj);
				}
				else if(countForGranTypeCode==0) {
					granularityTypeId = stagingDAO.retrieveMaxGranularityTypeId();
					granularityType.setGranularityTypeId(granularityTypeId);
					granularityType.setGranularityTypeCode(granularityDetailVONew.getGranularityTypeCode());
					granularityType.setCreatedUser(granularityDetailVONew.getCreatedUser());
					granularityType.setCreatedDate(granularityDetailVONew.getCreatedDate());
					granularityType.setModifiedUser(granularityDetailVONew.getModifiedUser());
					granularityType.setModifiedDate(granularityDetailVONew.getModifiedDate());
					granularityType.setInactiveIndicator(1L);
					stagingDAO.updateGranularityTypeRec(granularityType);
					granuList.add(granularityType);
				}
				
			}
		}
		
		for(GranularityType gt : granuList) {
			Long scoreTypeAssnId=null;
			if(scoreTypeId!=null && gt.getGranularityTypeId()!=null) {
			LOGGER.info("entering ScoreServiceImpl | updateGranularityCode");
			LOGGER.info("scoreTypeId::"+scoreTypeId+"\nGranularityTypeId::"+gt.getGranularityTypeId());
			String queryGruTyp = "SELECT count(s.SCR_TYP_ASSN_ID) FROM SCR_TYP_ASSN s where s.SCR_TYP_ID="+scoreTypeId+" AND s.SCR_GRU_ID="+gt.getGranularityTypeId();
			Long countForScrTypeAssn = stagingDAO.retrieveMaxCount(queryGruTyp);
			ScoreTypeAssociation scrTypAssn = new ScoreTypeAssociation();
			if(countForScrTypeAssn>0){
				String queryScrTypAssnId = "SELECT s.SCR_TYP_ASSN_ID FROM SCR_TYP_ASSN s where s.SCR_TYP_ID="+scoreTypeId+" AND s.SCR_GRU_ID="+gt.getGranularityTypeId();
				scoreTypeAssnId = stagingDAO.retrieveMaxCount(queryScrTypAssnId);
				ScoreTypeAssociation scoreTypeAssnObj = stagingDAO.findScoreTypeAssn(scoreTypeAssnId);	
				scoreTypeAssnObj.setModifiedUser(granularityValueVO.getModifiedUser());
				scoreTypeAssnObj.setModifiedDate(granularityValueVO.getModifiedDate());
				stagingDAO.updateScoreTypeAssnRec(scoreTypeAssnObj);
			}
			else if(countForScrTypeAssn==0) {
				scoreTypeAssnId = stagingDAO.retrieveMaxScoreTypeAssnId();
				scrTypAssn.setScoreTypeAssociationId(scoreTypeAssnId);
				scrTypAssn.setScoreTypeId(scoreTypeId);
				scrTypAssn.setGranularityTypeId(gt.getGranularityTypeId());
				scrTypAssn.setCreatedUser(granularityValueVO.getCreatedUser());
				scrTypAssn.setCreatedDate(granularityValueVO.getCreatedDate());
				scrTypAssn.setModifiedUser(granularityValueVO.getModifiedUser());
				scrTypAssn.setModifiedDate(granularityValueVO.getModifiedDate());
				stagingDAO.updateScoreTypeAssnRec(scrTypAssn);
			}
			
			String queryGruAttrTyp = "SELECT count(s.SCR_GRU_ID) FROM SCR_GRU_ASSN s where s. SCR_GRU_ID="+gt.getGranularityTypeId();
			Long countForScrGruAssn = stagingDAO.retrieveMaxCount(queryGruAttrTyp);
			ScoreGranularityAssociation scrGruAssn = new ScoreGranularityAssociation();
			if(countForScrGruAssn==0) {
				String queryGruTypDesc = "select cd_val_desc from cd_val_txt where lang_cd=39 and WRIT_SCRP_CD = 19349 and expn_dt is null and cd_val_id="+gt.getGranularityTypeCode();
				String codeValDescription = stagingDAO.retrieveCodeValueDescription(queryGruTypDesc);
				if(codeValDescription.toLowerCase().contains("raw score")) {
					for(int itr=1;itr<3;itr++) {
//				
					Long scrGruAssnId = stagingDAO.retrieveMaxScoreGranularityAssnValueId();
					scrGruAssn.setGranularityTypeAssociationId(scrGruAssnId);
					scrGruAssn.setGranularityTypeId(gt.getGranularityTypeId());
					scrGruAssn.setAttributeTypeId((long) itr);
					scrGruAssn.setCreatedUser(granularityValueVO.getCreatedUser());
					scrGruAssn.setCreatedDate(granularityValueVO.getCreatedDate());
					scrGruAssn.setModifiedUser(granularityValueVO.getModifiedUser());
					scrGruAssn.setModifiedDate(granularityValueVO.getModifiedDate());
					stagingDAO.updateScoreGranuAssnRec(scrGruAssn);
					}
				}else {
					
					Long scrGruAssnId = stagingDAO.retrieveMaxScoreGranularityAssnValueId();
					scrGruAssn.setGranularityTypeAssociationId(scrGruAssnId);
					scrGruAssn.setGranularityTypeId(gt.getGranularityTypeId());
					scrGruAssn.setAttributeTypeId(3L);
					scrGruAssn.setCreatedUser(granularityValueVO.getCreatedUser());
					scrGruAssn.setCreatedDate(granularityValueVO.getCreatedDate());
					scrGruAssn.setModifiedUser(granularityValueVO.getModifiedUser());
					scrGruAssn.setModifiedDate(granularityValueVO.getModifiedDate());
					stagingDAO.updateScoreGranuAssnRec(scrGruAssn);
				}
				
			}
			}
		}
		Long updatedScoreTypeCode = scoreTypes.getScoreTypeId();
		LOGGER.info("updated scoreTypeCode : " + updatedScoreTypeCode);

		
		return updatedScoreTypeCode;
	}

	@Override
	@Transactional("stgTransactionManager")
	public Long updateNewScoreCode(AddNewScoreVO addNewScoreVO) {

		Long scoreTypeId = null;
		Long scoreId = null;
		Score scores = new Score();
		if (addNewScoreVO.getScoreTypeCode() != null) {
			String queryScrTyp = "SELECT count(s.SCR_TYP_ID) FROM SCR_TYP s where s.SCR_TYP_CD="
					+ addNewScoreVO.getScoreTypeCode();
			Long countForScoreTypeCode = stagingDAO
					.retrieveMaxCount(queryScrTyp);
			Score score = new Score();
			ScoreType scoreType = new ScoreType();
			if (countForScoreTypeCode > 0) {
				String queryScrTypId = "SELECT s.SCR_TYP_ID FROM SCR_TYP s where s.SCR_TYP_CD="
						+ addNewScoreVO.getScoreTypeCode();
				scoreTypeId = stagingDAO.retrieveMaxCount(queryScrTypId);
				ScoreType scoreTypeObj = stagingDAO.findScoreType(scoreTypeId);
				scoreTypeObj.setModifiedUser(addNewScoreVO.getModifiedUser());
				scoreTypeObj.setModifiedDate(addNewScoreVO.getModifiedDate());
				stagingDAO.updateScoreTypeRec(scoreTypeObj);
			} else if (countForScoreTypeCode == 0) {
				scoreTypeId = stagingDAO.retrieveMaxScoreTypeId();
				scoreType.setScoreTypeId(scoreTypeId);
				scoreType.setScoreTypeCode(addNewScoreVO.getScoreTypeCode());
				scoreType.setInactiveIndicator(1L);
				scoreType.setCreatedUser(addNewScoreVO.getCreatedUser());
				scoreType.setCreatedDate(addNewScoreVO.getCreatedDate());
				scoreType.setModifiedUser(addNewScoreVO.getModifiedUser());
				scoreType.setModifiedDate(addNewScoreVO.getModifiedDate());
				stagingDAO.updateScoreTypeRec(scoreType);
			}
			List<Long> mktcds = addNewScoreVO.getMarketCodeList();
			for(Long marketCode : mktcds){
			String queryScr = "SELECT count(s.SCR_ID) FROM SCR s where s.SCR_TYP_ID="
					+ scoreTypeId
					+ "AND SCR_MKT_CD="
					+ marketCode
					+ "AND SCR_VER="
					+ addNewScoreVO.getScoreVersion();
			Long countForScoreType = stagingDAO.retrieveMaxCount(queryScr);
			if (countForScoreType > 0) {
				String queryScrId = "SELECT s.SCR_ID FROM SCR s where s.SCR_TYP_ID="
						+ scoreTypeId
						+ "AND SCR_MKT_CD="
						+ marketCode
						+ "AND SCR_VER="
						+ addNewScoreVO.getScoreVersion();
				scoreId = stagingDAO.retrieveMaxCount(queryScrId);
				Score scoreObj = stagingDAO.findScore(scoreId);
				scoreObj.setModifiedUser(addNewScoreVO.getModifiedUser());
				scoreObj.setModifiedDate(addNewScoreVO.getModifiedDate());
				scores = stagingDAO.updateNewScoreTypeRec(scoreObj);
			} else if (countForScoreType == 0) {
				scoreId = stagingDAO.retrieveMaxScoreId();
				score.setScoreId(scoreId);
				score.setScoreVersion(addNewScoreVO.getScoreVersion());
				score.setScoreTypeId(scoreTypeId);
				score.setScoreMarketCode(marketCode);
				score.setCreatedUser(addNewScoreVO.getCreatedUser());
				score.setCreatedDate(addNewScoreVO.getCreatedDate());
				score.setModifiedUser(addNewScoreVO.getModifiedUser());
				score.setModifiedDate(addNewScoreVO.getModifiedDate());
				score.setInactiveIndicator(1L);
				scores = stagingDAO.updateNewScoreTypeRec(score);
			}
			}

		}
		Long updatedScore = scores.getScoreId();
		LOGGER.info("updated scoreTypeCode : " + updatedScore);

		return updatedScore;
	}


		@Override
		@Transactional("stgTransactionManager")
		public List<CodeValueVO> retrieveAllScoreTypeCode() {
			LOGGER.info("entering ScoreServiceImpl | retrieveAllScoreTypeCode");
			return stagingDAO.retrieveAllScoreTypeCode();
		}


		@Override
		@Transactional("stgTransactionManager")
		public List<CodeValueVO> retrieveMarketTypeCodes(Long scoreType) {
			LOGGER.info("entering ScoreServiceImpl | retrieveMarketTypeCodes");
			return stagingDAO.retrieveMarketTypeCodes(scoreType);
		}

		@Override
		@Transactional("stgTransactionManager")
		public List<Score> retrievescoreVersions(Long scoreType, Long marketType) {
			LOGGER.info("entering ScoreServiceImpl | retrievescoreVersions");
			return stagingDAO.retrievescoreVersions(scoreType, marketType);
		}


		@Override
		public List<AddNewScoreVO> retrieveAttributeDetails(Long scoreType,
				Long marketType, Double scoreVersion) {
			LOGGER.info("entering ScoreServiceImpl | retrieveAttributeDetails");
			return stagingDAO.retrieveAttributeDetails(scoreType, marketType, scoreVersion);
		}
		@Override
		public List<Long> retrieveScoreTypeCode() {
			return stagingDAO.retrieveScoreTypeCode();
		}


		@Override
		public List<CodeValue> retrieveScoreTypeCodeValues(
				ScoreVO scoreVO) {
			List<CodeValue> codeValues = stagingDAO.retrieveScoreTypeCodeValues(scoreVO);
			return codeValues;
		}


		@Override
		public List<CodeValueVO> retrieveMarketCodeValues(ScoreVO scoreVO) {
			List<CodeValueVO> codeValues = stagingDAO.retrieveMarketCodeValues(scoreVO);
			return codeValues;
		}


		@Override
		public List<Score> retrieveVersionValues(Score scoreVO) {
			List<Score> versions = stagingDAO.retrieveVersionValues(scoreVO);
			return versions;
		}


		@Override
		public List<CodeValue> retrieveGranularityForScrType(ScoreVO scoreVO) {
			List<CodeValue> codeValues = stagingDAO.retrieveGranularityForScrType(scoreVO);
			return codeValues;
		}


		@SuppressWarnings("unused")
		@Override
		@Transactional("stgTransactionManager")
		public Long updateScoreDtl(ScoreDtlVO scoreDtlVO) {		
			ScoreDetails scoreDtl = new ScoreDetails();
			ScoreDetails updatedScoreDtail  = new ScoreDetails(); 
			Long retreivedScoreId = stagingDAO.retreiveIds("select SCR_ID from scr where SCR_MKT_CD = "+scoreDtlVO.getScoreMarketCode()+" and SCR_VER = "+scoreDtlVO.getScoreVersion()+" and   SCR_TYP_ID in (select SCR_TYP_ID from scr_typ where SCR_TYP_CD = "+ scoreDtlVO.getScoreTypeCode()+")");		
			List<Long> scoreAssnIds = new ArrayList<Long>();
			for (ScoreGranularity scrGranulrity : scoreDtlVO.getScoreGranularity()) {
				if(scrGranulrity.getScoreGraCode() != null){
				Long scrGraCode = scrGranulrity.getScoreGraCode();
				scoreAssnIds.add(stagingDAO.retreiveIds("select scr_typ_assn_id from scr_typ_assn where scr_gru_id = (select SCR_GRU_ID from scr_gru where scr_gru_cd = "+scrGraCode+") and scr_typ_id =(select SCR_TYP_ID from scr_typ where SCR_TYP_CD = "+ scoreDtlVO.getScoreTypeCode()+")"));
				}
			}	
			for(Long scoreAssnId : scoreAssnIds){

				Long count = stagingDAO.retreiveIds("select count(SCR_DTL_ID) from SCR_DTL where SCR_ID = "+retreivedScoreId+" and SCR_TYP_ASSN_ID = "+scoreAssnId+"");		
				if(count>0){
					Long scrDtlID = stagingDAO.retreiveIds("select SCR_DTL_ID from SCR_DTL where SCR_ID = "+retreivedScoreId+" and SCR_TYP_ASSN_ID = "+scoreAssnId+"");		
					ScoreDetails scoreDtls = stagingDAO.findScrDtl(scrDtlID);
					scoreDtls.setModifiedDate(new Date());
					scoreDtls.setModifiedUser(scoreDtlVO.getLoggedInUser());
					ScoreDetails updatedScrDtls = stagingDAO.updateScoreDetail(scoreDtls);
				}
				else{
				Long scoreDetId = stagingDAO.retreiveIds("SELECT SORUSR.SCR_DTL_ID_SEQ.nextval from dual");
				scoreDtl.setScoreDetId(scoreDetId);
				scoreDtl.setScoreId(retreivedScoreId);
				scoreDtl.setScoreTypAssnId(scoreAssnId);
				scoreDtl.setCreatedDate(new Date());
				scoreDtl.setCreatedUser(scoreDtlVO.getLoggedInUser());
				scoreDtl.setModifiedDate(new Date());
				scoreDtl.setModifiedUser(scoreDtlVO.getLoggedInUser());
				ScoreDetails updatedScoreDtails = stagingDAO.updateScoreDetail(scoreDtl);
				}
			}
		return retreivedScoreId;
		}
	@Transactional("stgTransactionManager")
		public Long updateNewScoreMapping(AddNewScoreVO addNewScoreVO) {
			Long scoreId = null;
			List<String> granList = addNewScoreVO.getScrGranuValueList();
			String[] ids = granList.get(0).split("~#");
			scoreId = Long.valueOf(ids[0]);
			String queryScr = "SELECT max(PRNT_SCR_ID) from scr_map where SCR_ID = "+scoreId+"";
			Long maxPrntId = stagingDAO.retrieveMax(queryScr);
			boolean flag = false;
			Long valPrnt = 0L;
			
			//
			String[] granIds = Arrays.copyOfRange(ids, 1, ids.length);
			//String idVals = Arrays.toString(granIds);
	    	//idVals = idVals.replace("[", "").replace("]", "");
			List<Long> prntIds = stagingDAO.retrieveLongList("SELECT distinct(prnt_scr_id) from scr_map where SCR_ID = "+scoreId+"");
			
			for(int i=0;i<granIds.length;i++){
				for(Long prntId : prntIds){
				Long count = stagingDAO.retreiveIds("select count(SCR_MAP_ID) from scr_map where SCR_ID = "+scoreId+" and SCR_GRU_ASSN_ID = "+granIds[i]+" and  PRNT_SCR_ID = "+prntId+"");		
				if(!(count>0)){						
					ScoreMapping granularityMap = new ScoreMapping();
					granularityMap.setScoreId(scoreId);
					granularityMap.setScoreAttributeValue("0");
					granularityMap.setScoreGruAssociationId(Long.valueOf(granIds[i]));
					granularityMap.setParentScoreId(prntId);	
					granularityMap.setInactiveIndc(1L);
					Long scoreMapId = stagingDAO.retrieveMaxScoreMapId();
					granularityMap.setScoreMapId(scoreMapId);
					granularityMap.setCreatedDate(addNewScoreVO.getCreatedDate());
					granularityMap.setCreatedUser(addNewScoreVO.getCreatedUser());
					granularityMap.setModifiedDate(addNewScoreVO.getModifiedDate());
					granularityMap.setModifiedUser(addNewScoreVO.getModifiedUser());
					stagingDAO.updateNewScoreMapRec(granularityMap);					
					}
				}
			}
			
			//
			
			
			for(int i=1;i<granList.size();i++){		
				String[] value = granList.get(i).split("~#"); 
					for(int j=0;j<value.length;j++){
						if((value[j].length()==0) || (value[j]==null)) {
							value[j]="0";
						}
						if(!(flag)){
						ScoreMapping granularityMap = new ScoreMapping();
						granularityMap.setScoreId(scoreId);
						granularityMap.setScoreAttributeValue(value[j]);
						granularityMap.setScoreGruAssociationId(Long.valueOf(ids[j+1]));
						valPrnt = maxPrntId+1L;
						granularityMap.setParentScoreId(valPrnt);	
						granularityMap.setInactiveIndc(1L);
						Long scoreMapId = stagingDAO.retrieveMaxScoreMapId();
						granularityMap.setScoreMapId(scoreMapId);
						granularityMap.setCreatedDate(addNewScoreVO.getCreatedDate());
						granularityMap.setCreatedUser(addNewScoreVO.getCreatedUser());
						granularityMap.setModifiedDate(addNewScoreVO.getModifiedDate());
						granularityMap.setModifiedUser(addNewScoreVO.getModifiedUser());
						stagingDAO.updateNewScoreMapRec(granularityMap);
						}
						else {	
							ScoreMapping granularityMap = new ScoreMapping();
							granularityMap.setScoreId(scoreId);
							granularityMap.setScoreAttributeValue(value[j]);
							granularityMap.setScoreGruAssociationId(Long.valueOf(ids[j+1]));
							granularityMap.setParentScoreId(valPrnt);
							granularityMap.setInactiveIndc(1L);
							Long scoreMapId = stagingDAO.retrieveMaxScoreMapId();
							granularityMap.setScoreMapId(scoreMapId);
							granularityMap.setCreatedDate(addNewScoreVO.getCreatedDate());
							granularityMap.setCreatedUser(addNewScoreVO.getCreatedUser());
							granularityMap.setModifiedDate(addNewScoreVO.getModifiedDate());
							granularityMap.setModifiedUser(addNewScoreVO.getModifiedUser());
							stagingDAO.updateNewScoreMapRec(granularityMap);
						}
				}
					flag = true;
					valPrnt = valPrnt+1L;				
			}
			
			return scoreId;
		}

		@Override
		public List<CodeValue> retrieveGruTypeCodeValues(ScoreVO scoreVO) {
			List<CodeValue> codeValues = stagingDAO.retrieveGruTypeCodeValues(scoreVO);
			return codeValues;
		}

		public static <T extends Object> List<List<T>> split(List<T> list, int targetSize) {
		    List<List<T>> lists = new ArrayList<List<T>>();
		    for (int i = 0; i < list.size(); i += targetSize) {
		        lists.add(list.subList(i, Math.min(i + targetSize, list.size())));
		    }
		    return lists;
		}
		
		@Transactional("stgTransactionManager")
		public Long countSearchScore(ScoreSearchVO searchCriteriaVO) {
			String query = "";	
			int targetSize = 999;
			String[] mktCd = searchCriteriaVO.getMkt_cd().split(",");
			List<String> mktCdList = new ArrayList<String>( Arrays.asList( mktCd ) );

			List<List<String>> lists = split(mktCdList, targetSize);
			String strMktCd = "";
	    	String orVal = "OR";
	    	String append = " scr.scr_mkt_cd in (";
	    	String end = ") ";
	    	for(List<String> lis: lists){
		    	String[] val = lis.toArray(new String[lis.size()]);
		    	String valStr = Arrays.toString(val);
		    	valStr = valStr.replace("[", "").replace("]", "");
		    	if(strMktCd.equalsIgnoreCase("")){
		    		strMktCd = strMktCd + " scr.scr_mkt_cd in ("+valStr+") ";
		    	}
		    	else if(valStr.length()>0)
		    	{
		    	strMktCd = strMktCd + orVal + append +valStr+end;
		    	}
			}
	    	
	    	//
			String[] scr_typ_cd = searchCriteriaVO.getSr_typ_cd().split(",");
			List<String> scr_typ_cdList = new ArrayList<String>( Arrays.asList( scr_typ_cd ) );

			List<List<String>> lisrts = split(scr_typ_cdList, targetSize);
			String scrtycd = "";
	    	String appendScr_typ_cd = " scr_typ_cd in (";
	    	for(List<String> lis: lisrts){
		    	String[] val = lis.toArray(new String[lis.size()]);
		    	String valStr = Arrays.toString(val);
		    	valStr = valStr.replace("[", "").replace("]", "");
		    	if(scrtycd.equalsIgnoreCase("")){
		    		scrtycd = scrtycd + " scr_typ_cd in ("+valStr+") ";
		    	}
		    	else if(valStr.length()>0)
		    	{
		    		scrtycd = scrtycd + orVal + appendScr_typ_cd +valStr+end;
		    	}
			}
	    	//
	    	
	    	//
	    	String[] scr_gru_cd = null;
	    	List<String> scr_gru_cdList = null;
	    	String scrgrucd = "";
	    	if((searchCriteriaVO.getSr_gru_cd() != null )){
			scr_gru_cd = searchCriteriaVO.getSr_gru_cd().split(",");
			scr_gru_cdList = new ArrayList<String>( Arrays.asList( scr_gru_cd ) );

			List<List<String>> lisrs = split(scr_gru_cdList, targetSize);
			
	    	String appendScr_gru_cd = " scr_gru_cd in (";
	    	for(List<String> lis: lisrs){
		    	String[] val = lis.toArray(new String[lis.size()]);
		    	String valStr = Arrays.toString(val);
		    	valStr = valStr.replace("[", "").replace("]", "");
		    	if(scrgrucd.equalsIgnoreCase("")){
		    		scrgrucd = scrgrucd + " scr_gru_cd in ("+valStr+") ";
		    	}
		    	else if(valStr.length()>0)
		    	{
		    		scrgrucd = scrgrucd + orVal + appendScr_gru_cd +valStr+end;
		    	}
			}
	    	}
	    	//
	    	
	    	
			if((!(searchCriteriaVO.getSr_gru_cd() != null )) || ((("").equalsIgnoreCase(searchCriteriaVO.getSr_gru_cd())))){
				//if(!(("").equalsIgnoreCase(searchCriteriaVO.getSr_gru_cd()))){
					query = "SELECT "+
							" count(*) as cnt"+
							" from GEO_UNIT_NME,(SELECT "+
							" CD_VAL_ID as scr_typ_cd_id,CD_VAL_SHRT_DESC as scr_typ_cd_shrt_d,CD_VAL_DESC as scr_typ_cd_val_d,"+
							" subquery6.scr_gru_cd_id,subquery6.scr_gru_cd_shrt_d,subquery6.scr_gru_cd_val_d,subquery6.scr_id as scr_id,subquery6.scr_gru_cd as scr_gru_cd,subquery6.scr_gru_id as scr_gru_id,subquery6.scr_typ_assn_id as scr_typ_assn_id,subquery6.scr_typ_id as scr_typ_id,"+
							" subquery6.scr_mkt_cd as scr_mkt_cd,subquery6.scr_typ_cd as scr_typ_cd,subquery6.scr_vers "+
							" from CD_VAL_TXT,(SELECT CD_VAL_ID as scr_gru_cd_id,CD_VAL_SHRT_DESC as scr_gru_cd_shrt_d,CD_VAL_DESC as scr_gru_cd_val_d,subquery5.scr_id as scr_id,subquery5.scr_gru_cd as scr_gru_cd,subquery5.scr_gru_id as scr_gru_id,subquery5.scr_typ_assn_id as scr_typ_assn_id,subquery5.scr_typ_id as scr_typ_id,"+
							" subquery5.scr_mkt_cd as scr_mkt_cd,subquery5.scr_typ_cd as scr_typ_cd,subquery5.scr_vers from CD_VAL_TXT,(SELECT subquery3.scr_id as scr_id,scr_gru.scr_gru_cd as scr_gru_cd,subquery3.scr_gru_id as scr_gru_id,subquery3.scr_typ_assn_id as scr_typ_assn_id,subquery3.scr_typ_id as scr_typ_id,"+
							" subquery3.scr_mkt_cd as scr_mkt_cd,subquery3.scr_typ_cd as scr_typ_cd,subquery3.scr_vers from scr_gru,(SELECT scr_typ_assn.scr_gru_id as scr_gru_id,subquery2.scr_typ_assn_id as scr_typ_assn_id,subquery2.scr_id as scr_id,subquery2.scr_typ_id as scr_typ_id,"+
							" subquery2.scr_mkt_cd as scr_mkt_cd,subquery2.scr_typ_cd as scr_typ_cd,subquery2.scr_vers  from scr_typ_assn,(SELECT scr_dtl.scr_typ_assn_id as scr_typ_assn_id, subquery1.scr_id as scr_id,subquery1.scr_typ_id as scr_typ_id,"+
							" subquery1.scr_mkt_cd as scr_mkt_cd,subquery1.scr_typ_cd as scr_typ_cd,subquery1.scr_vers"+
							" FROM scr_dtl,"+
							"  (SELECT scr.scr_id,scr.scr_typ_id,scr.scr_mkt_cd,subquery4.scr_typ_cd as scr_typ_cd,scr.scr_ver as scr_vers"+
							" FROM scr,"+
							"  (select scr_typ_id,scr_typ_cd from scr_typ where ("+scrtycd+")"+") subquery4"+
							" WHERE subquery4.scr_typ_id = scr.scr_typ_id and ("+strMktCd+")"+
							" ) subquery1 "+
							" WHERE subquery1.scr_id = scr_dtl.scr_id) subquery2"+
							" WHERE subquery2.scr_typ_assn_id = scr_typ_assn.scr_typ_assn_id) subquery3"+ 
							" WHERE subquery3.scr_gru_id = scr_gru.scr_gru_id) subquery5 "+ 
							" WHERE subquery5.scr_gru_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.EXPN_DT is null and  CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6"+ 
							" WHERE subquery6.scr_typ_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.EXPN_DT is null and  CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7"+
							" WHERE subquery7.scr_mkt_cd = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32 order by GEO_UNIT_NME.GEO_NME";
				//}
			}
			else{
				 query = "SELECT "+
					" count(*) as cnt"+
					" from GEO_UNIT_NME,(SELECT "+
					" CD_VAL_ID as scr_typ_cd_id,CD_VAL_SHRT_DESC as scr_typ_cd_shrt_d,CD_VAL_DESC as scr_typ_cd_val_d,"+
					" subquery6.scr_gru_cd_id,subquery6.scr_gru_cd_shrt_d,subquery6.scr_gru_cd_val_d,subquery6.scr_id as scr_id,subquery6.scr_gru_cd as scr_gru_cd,subquery6.scr_gru_id as scr_gru_id,subquery6.scr_typ_assn_id as scr_typ_assn_id,subquery6.scr_typ_id as scr_typ_id,"+
					" subquery6.scr_mkt_cd as scr_mkt_cd,subquery6.scr_typ_cd as scr_typ_cd,subquery6.scr_vers "+
					" from CD_VAL_TXT,(SELECT CD_VAL_ID as scr_gru_cd_id,CD_VAL_SHRT_DESC as scr_gru_cd_shrt_d,CD_VAL_DESC as scr_gru_cd_val_d,subquery5.scr_id as scr_id,subquery5.scr_gru_cd as scr_gru_cd,subquery5.scr_gru_id as scr_gru_id,subquery5.scr_typ_assn_id as scr_typ_assn_id,subquery5.scr_typ_id as scr_typ_id,"+
					" subquery5.scr_mkt_cd as scr_mkt_cd,subquery5.scr_typ_cd as scr_typ_cd,subquery5.scr_vers from CD_VAL_TXT,(SELECT subquery3.scr_id as scr_id,scr_gru.scr_gru_cd as scr_gru_cd,subquery3.scr_gru_id as scr_gru_id,subquery3.scr_typ_assn_id as scr_typ_assn_id,subquery3.scr_typ_id as scr_typ_id,"+
					" subquery3.scr_mkt_cd as scr_mkt_cd,subquery3.scr_typ_cd as scr_typ_cd,subquery3.scr_vers from scr_gru,(SELECT scr_typ_assn.scr_gru_id as scr_gru_id,subquery2.scr_typ_assn_id as scr_typ_assn_id,subquery2.scr_id as scr_id,subquery2.scr_typ_id as scr_typ_id,"+
					" subquery2.scr_mkt_cd as scr_mkt_cd,subquery2.scr_typ_cd as scr_typ_cd,subquery2.scr_vers  from scr_typ_assn,(SELECT scr_dtl.scr_typ_assn_id as scr_typ_assn_id, subquery1.scr_id as scr_id,subquery1.scr_typ_id as scr_typ_id,"+
					" subquery1.scr_mkt_cd as scr_mkt_cd,subquery1.scr_typ_cd as scr_typ_cd,subquery1.scr_vers"+
					" FROM scr_dtl,"+
					"  (SELECT scr.scr_id,scr.scr_typ_id,scr.scr_mkt_cd,subquery4.scr_typ_cd as scr_typ_cd,scr.scr_ver as scr_vers"+
					" FROM scr,"+
					"  (select scr_typ_id,scr_typ_cd from scr_typ where ("+scrtycd+")"+") subquery4"+
					" WHERE subquery4.scr_typ_id = scr.scr_typ_id and ("+strMktCd+")"+
					" ) subquery1 "+
					" WHERE subquery1.scr_id = scr_dtl.scr_id) subquery2"+
					" WHERE subquery2.scr_typ_assn_id = scr_typ_assn.scr_typ_assn_id and scr_typ_assn.scr_gru_id in (SELECT scr_gru_id from scr_gru where ("+scrgrucd+")"+")) subquery3"+ 
					" WHERE subquery3.scr_gru_id = scr_gru.scr_gru_id) subquery5 "+ 
					" WHERE subquery5.scr_gru_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.EXPN_DT is null and  CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6"+ 
					" WHERE subquery6.scr_typ_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.EXPN_DT is null and  CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7"+
					" WHERE subquery7.scr_mkt_cd = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32 order by GEO_UNIT_NME.GEO_NME";
			}
			return stagingDAO.retreiveIds(query);
		}


		@Override
		@Transactional("stgTransactionManager")
		public List<ScoreSearchVO> scoreSearch(ScoreSearchVO searchCriteriaVO) {
			return stagingDAO.scoreSearch(searchCriteriaVO);

		}
		@Override
		@Transactional("stgTransactionManager")
		public ScoreSearchVO editScoreSearch(ScoreSearchVO scoreSearchVO) {
			return stagingDAO.editScoreSearch(scoreSearchVO);
		}
		
		
		@SuppressWarnings("unused")
		@Transactional("stgTransactionManager")		
		public Long updateScoreMapDtl(ScoreSearchVO scoreSearchVO) {			 
			 
			Long scoreId = scoreSearchVO.getScr_id();  
			scoreSearchVO.getMarketCode(); 
			scoreSearchVO.getScrVersion();
			scoreSearchVO.getLoggedInUser();
			
			List<EditScoreSearchVO> editScoreSearchList =  scoreSearchVO.getEditScoreSearchLit();
						
			Score score = stagingDAO.findScr(scoreId);
			
			score.setScoreMarketCode(scoreSearchVO.getMarketCode());
			score.setScoreVersion(scoreSearchVO.getScrVersion());
			score.setModifiedUser(scoreSearchVO.getLoggedInUser());
			score.setModifiedDate(new Date());
			Score updatedScore = stagingDAO.updateScore(score);
			try{
			if(editScoreSearchList.size()>0){
			for(EditScoreSearchVO edit : editScoreSearchList){
				ScoreMap scoreMap = stagingDAO.findScrMap(edit.getScr_map_id());
				scoreMap.setScrAttrVal(edit.getScr_attr_val());
				scoreMap.setModifiedUser(scoreSearchVO.getLoggedInUser());
				scoreMap.setModifiedDate(new Date());
				ScoreMap updatedScoreMap = stagingDAO.updateScoreMap(scoreMap);
			}	
			}
			}
			catch(Exception e){
				
			}
			

			// Granularity Delete - Starts
			String deleteQuery = "ScoreMapping.removeScoreMappingById";
			String parameter = "scoreMapId";		
			String prodParameter ="scoreId";
			List<Long> scrMapIdList = new ArrayList<Long>();
			List<Long> scrGruIdLst = new ArrayList<Long>();
			boolean flag = false;
			try{
			if(editScoreSearchList.size()>0){
			for(EditScoreSearchVO edit : editScoreSearchList){
				scrMapIdList.add(edit.getScr_map_id());				
			}
			scrGruIdLst = stagingDAO.retreiveScoreMappingId(scrMapIdList,scoreId);		
			}
			else{
				flag = true; 	
			}
			}
			catch(NullPointerException e){
			flag = true;	
			}
			catch(Exception e){
				
			}
			
			if(scrGruIdLst.size()>0){
			stagingDAO.removeID(scrMapIdList,deleteQuery,parameter,scoreId,prodParameter);
			List<Long> scrDtlIdLst = stagingDAO.retreiveScrDtlId(scrGruIdLst,scoreId);
			Long value = null;
			//List<Long> scoreDetailIdList = stagingDAO.retrieveScoreDtlId(scoreId);
			List<Long> prodScrMapIDList =  stagingDAO.retrieveProdScoreMapId(scrDtlIdLst);
			//ScrProdRemoveVO scrProd = new ScrProdRemoveVO();
			String deleteQueryScrDtlId = "ScoreDetails.removeScoreDetailsById";
			if(prodScrMapIDList !=null && prodScrMapIDList.size()>0){
				String deleteQueryProdResc = "ProdRescScrGru.removeProdRescScrGruById";
				/*removeProdRescID(prodScrMapIDList, deleteQueryProdResc,
						"scrDtlId");*/
				stagingDAO.removeProdRescID(prodScrMapIDList, deleteQueryProdResc,
						"prodRescToScrGruId");
				stagingDAO.removeProdRescID(scrDtlIdLst, deleteQueryScrDtlId,
				"scrDtlId");
				
			}
			else{
				if(scrDtlIdLst !=null && scrDtlIdLst.size()>0){	
					
					stagingDAO.removeProdRescID(scrDtlIdLst, deleteQueryScrDtlId,
					"scrDtlId");
				}	
			}
			}
			if(flag){
				String deleteQuerys = "ScoreMapping.removeScoreMappingId";
				String parameters = "scoreMapId";		
				String prodParameters ="scoreId";
				stagingDAO.removeID(deleteQuerys,parameters,scoreId,prodParameters);
				List<Long> scrDtlIdLst = stagingDAO.retreiveScrDtlId(scoreId);
				Long value = null;
				List<Long> prodScrMapIDList =  stagingDAO.retrieveProdScoreMapId(scrDtlIdLst);
				String deleteQueryScrDtlId = "ScoreDetails.removeScoreDetailsById";
				if(prodScrMapIDList !=null && prodScrMapIDList.size()>0){
					String deleteQueryProdResc = "ProdRescScrGru.removeProdRescScrGruById";
					
					stagingDAO.removeProdRescID(prodScrMapIDList, deleteQueryProdResc,
							"prodRescToScrGruId");
					stagingDAO.removeProdRescID(scrDtlIdLst, deleteQueryScrDtlId,
					"scrDtlId");
					
				}
				else{
					if(scrDtlIdLst !=null && scrDtlIdLst.size()>0){	
						
						stagingDAO.removeProdRescID(scrDtlIdLst, deleteQueryScrDtlId,
						"scrDtlId");
					}	
				}
			}
			
			//Granularity Delete - Ends
			
			return updatedScore.getScoreId();
			//return scrProd;
		}
		//@Transactional("stgTransactionManager")
		@Transactional(readOnly = false,value="stgTransactionManager", propagation = Propagation.REQUIRES_NEW)
		public Long removeProdRescID(List<Long> prodDtlIdList, String deleteQuery,
				String parameter){
			stagingDAO.removeProdRescID(prodDtlIdList, deleteQuery,
					parameter);
			return 1L;
		}
		
		
		
		
 //////////Score search page changes
		public List<CodeValue> retrieveScrSearchScoreTypeCode(ScoreVO scoreVO) {
			
			return stagingDAO.retrieveScrSearchScoreTypeCode(scoreVO);
		}


		public List<CodeValue> retrieveScrSearchGranularity(ScoreVO scoreVO) {
			
			return stagingDAO.retrieveScrSearchGranularity(scoreVO);
		}

		@Override
		public Boolean checkForDuplicate(Long scoreTypeCode, Long scoreMarketCode,
				Double scoreVersion) {
			LOGGER.info("Inside ScoreServiceImpl | checkForDuplicate");
			Long scrTypId = stagingDAO.retrieveScoreTypeId("SELECT DISTINCT SCR_TYP_ID FROM SCR_TYP WHERE SCR_TYP_CD="+scoreTypeCode);
			LOGGER.info("Inside ScoreServiceImpl | checkForDuplicate | scrTypId"+scrTypId);			
			return stagingDAO.checkForDuplicate(scrTypId,scoreMarketCode,scoreVersion);
		}
		
}
