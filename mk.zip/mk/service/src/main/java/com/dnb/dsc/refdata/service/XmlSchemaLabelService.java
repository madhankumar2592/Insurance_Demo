/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.service;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.vo.XmlSchemaSearchVO;

/**
 * This is used as the services interface for the Xml Schema Label operations
 * 
 * @author Cognizant
 * @version last updated : Apr 13, 2012
 * @see
 * 
 */
public interface XmlSchemaLabelService {

    /**
     * The method will search for the xml schema elements by element name or description. The user will type in the
     * element name or description and the dao layer will retrieve the names satisfying the filter
     * 
     * @param xmlSchemaSearchVO
     * @return list of XmlSchemaElement
     */
    public List<XmlSchemaElement> searchXmLSchemaLabels(XmlSchemaSearchVO xmlSchemaSearchVO);

    /**
     * The method will search for the xml schema elements details by element id. The user will pass the element id and
     * the dao layer will retrieve the corresponfing details
     * 
     * @param elementId
     * @return XmlSchemaElement
     */
    public XmlSchemaElement retrieveXmlSchemaByXmlElementId(String elementId);
    
	/**
	 * 
	 * The method will perform the table count of xml schema element on the
	 * staging db based on the specified filter conditions.
	 * 
	 * @param XmlSchemaSearchVO
	 * @return count of XmlSchemaElement
	 */
    Long countSearchXmLSchemaLabels(XmlSchemaSearchVO xmlSchemaSearchVO);
    
	/**
	 * The method will persist the existing XmlSchemaElement data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param xmlSchemaElement
	 */
	String updateXmlSchemaElement(XmlSchemaElement xmlSchemaElement);
	
	/**
	 * The method will validate the XmlSchemaElement for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param xmlSchemaElementId
	 */
	Boolean lockXmlSchema(String xmlSchemaElementId);
	/**
	 * The method will search for the xml schema elements details by element id
	 * from the transaction DB. The user will pass the element id and the dao
	 * layer will retrieve the corresponfing details
	 * 
	 * @param elementId
	 * @return XmlSchemaElement
	 */
	public XmlSchemaElement reviewXmlSchemaByXmlElementChanges(String elementId);

	/**
	 * The method will persist the existing XmlSchemaElement data in the Staging
	 * DB. The service method need to perform validation to identify the records
	 * which have been updated from the UI.
	 * 
	 * @param xmlSchemaElementId
	 */
	String saveApprovedXmlSchemaLabels(String xmlSchemaElementId);
	/**
	 * The method will remove the XmlSchemaElementLabelDetail data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 * 
	 * @param xmlSchemaElementId
	 */
	void removeDeletedXmlSchemaLabelDetail(Long xmlSchemaElementLabelDetailId);
	/**
	 * The method will remove the XmlSchemaElement data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 * 
	 * @param xmlSchemaElementId
	 */
	void removeApprovedXmlSchemaLabels(String xmlSchemaElementId);
}
