package com.dnb.dsc.refdata.service.endpoint;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.Product;
import com.dnb.dsc.refdata.core.vo.AddNewProductsVO;
import com.dnb.dsc.refdata.core.vo.ProductScoreMappingVO;
import com.dnb.dsc.refdata.core.vo.ProductScoreReportVO;
import com.dnb.dsc.refdata.core.vo.ProductSearchVO;
import com.dnb.dsc.refdata.core.vo.ProductVO;
import com.dnb.dsc.refdata.service.ProductService;

@Controller
public class ProductServiceHttpEndpoint {
	@Autowired
	private ProductService productService;

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ProductServiceHttpEndpoint.class);

	@RequestMapping(value = "/retrieveProdTypeCodeVals.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveProductTypeCodeValues(
			@RequestBody ProductVO productSearchVO) throws Exception {
		try {
			LOGGER.info("entering ProductServiceHttpEndpoint | retrieveProductTypeCodeValues");
			return productService
					.retrieveProductTypeCodeValues(productSearchVO);
		} catch (Exception e) {
			LOGGER.error("ProductServiceHttpEndpoint | retrieveProductTypeCodeValues", e);
			return null;
		}

	}

	@RequestMapping(value = "/retrieveRescTypeCodeVals.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveResourceTypeCodeValues(
			@RequestBody ProductVO productSearchVO) throws Exception {
		LOGGER.info("entering ProductServiceHttpEndpoint | retrieveResourceTypeCodeValues");
		return productService.retrieveResourceTypeCodeValues(productSearchVO);
	}

	@RequestMapping(value = "/countSearchProduct.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchProduct(@RequestBody ProductSearchVO productSearchVO) {
		return productService.countSearchProduct(productSearchVO);
	}

	@RequestMapping(value = "/productSearchResult.service", method = RequestMethod.POST)
	public @ResponseBody
	List<ProductSearchVO> scoreSearch(
			@RequestBody ProductSearchVO productSearchVO) throws Exception {

		return productService.productSearch(productSearchVO);

	}

	@RequestMapping(value = "/updateNewProducts.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateNewProducts(@RequestBody AddNewProductsVO addNewProductsVO) {
		LOGGER.info("entering ProductServiceHttpEndpoint | updateNewProducts.service");
		LOGGER.info("exiting ProductServiceHttpEndpoint | updateNewProducts.service");
		return productService.updateNewProducts(addNewProductsVO);
	}

	@RequestMapping(value = "/retrieveProductDetail.service", method = RequestMethod.POST)
	public @ResponseBody
	AddNewProductsVO retrieveProductDetail(
			@RequestBody ProductSearchVO productSearchVO) {
		LOGGER.info("entering ProductServiceHttpEndpoint | updateNewProducts.service");
		LOGGER.info("exiting ProductServiceHttpEndpoint | updateNewProducts.service");
		return productService.retrieveProductDetail(productSearchVO);
	}

	@RequestMapping(value = "/editProducts.service", method = RequestMethod.POST)
	public @ResponseBody
	Long editProducts(@RequestBody AddNewProductsVO addNewProductsVO) {
		LOGGER.info("entering ProductServiceHttpEndpoint | editProducts.service");
		LOGGER.info("exiting ProductServiceHttpEndpoint | editProducts.service");
		return productService.editProducts(addNewProductsVO);
	}

	@RequestMapping(value = "/countOfProductScrRpt.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countOfProductScrRpt(
			@RequestBody ProductScoreReportVO productScoreReportVO) {
		return productService.countOfProductScrRpt(productScoreReportVO);
	}

	@RequestMapping(value = "/productScrReport.service", method = RequestMethod.POST)
	public @ResponseBody
	List<ProductScoreReportVO> productScrReport(
			@RequestBody ProductScoreReportVO productScoreReportVO)
			throws Exception {

		return productService.productScrReport(productScoreReportVO);

	}

	@RequestMapping(value = "/{scoreType}/retrieveGranularityCodes.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveGranularityCodes(
			@PathVariable("scoreType") Long scoreType) {
		LOGGER.info("entering ProductServiceHttpEndpoint | retrieveGranularityCodes");

		List<CodeValue> codeValue = productService
				.retrieveGranularityCodes(scoreType);

		LOGGER.info("CodeValueVOs : " + codeValue);
		LOGGER.info("exiting ProductServiceHttpEndpoint | retrieveGranularityCodes");
		return codeValue;
	}

	@RequestMapping(value = "/retrieveProductCodeValues.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveProductCodeValues(
			@RequestBody AddNewProductsVO addNewProductsVO) throws Exception {
		LOGGER.info("entering ProductServiceHttpEndpoint | retrieveProductCodeValues");
		return productService.retrieveProductCodeValues(addNewProductsVO);
	}

	@RequestMapping(value = "/{prodCode}/retrieveProdFamCode.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveProdFamCode(@PathVariable("prodCode") Long prodCode) {
		LOGGER.info("entering ProductServiceHttpEndpoint | retrieveProdFamCode");

		List<CodeValue> codeValue = productService
				.retrieveProdFamCode(prodCode);

		LOGGER.info("CodeValueVOs : " + codeValue);
		LOGGER.info("exiting ProductServiceHttpEndpoint | retrieveProdFamCode");
		return codeValue;
	}

	@RequestMapping(value = "/{prodCode}/retrieveProdVers.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<Product> retrieveProdVers(@PathVariable("prodCode") Long prodCode) {
		LOGGER.info("entering ProductServiceHttpEndpoint | retrieveProdVers");

		List<Product> productVers = productService.retrieveProdVers(prodCode);

		LOGGER.info("CodeValueVOs : " + productVers);
		LOGGER.info("exiting ProductServiceHttpEndpoint | retrieveProdVers");
		return productVers;
	}

	@RequestMapping(value = "/{prodCode}/retrieveResource.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveResource(@PathVariable("prodCode") Long prodCode) {
		LOGGER.info("entering ProductServiceHttpEndpoint | retrieveResource");

		List<CodeValue> codeValue = productService.retrieveResource(prodCode);

		LOGGER.info("CodeValueVOs : " + codeValue);
		LOGGER.info("exiting ProductServiceHttpEndpoint | retrieveResource");
		return codeValue;
	}

	@RequestMapping(value = "/{famCode}/{prodCode}/retrieveFamProdVersion.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<Product> retrieveFamProdVersion(
			@PathVariable("prodCode") Long prodCode,
			@PathVariable("famCode") Long famCode) {
		LOGGER.info("entering ProductServiceHttpEndpoint | retrieveFamProdVersion");

		List<Product> codeValue = productService.retrieveFamProdVersion(
				famCode, prodCode);

		LOGGER.info("CodeValueVOs : " + codeValue);
		LOGGER.info("exiting ProductServiceHttpEndpoint | retrieveFamProdVersion");
		return codeValue;
	}

	@RequestMapping(value = "/{famCode}/{prodCode}/retrieveFamVerResource.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveFamVerResource(
			@PathVariable("prodCode") Long prodCode,
			@PathVariable("famCode") Long famCode) {
		LOGGER.info("entering ProductServiceHttpEndpoint | retrieveFamVerResource");

		List<CodeValue> codeValue = productService.retrieveFamVerResource(
				famCode, prodCode);

		LOGGER.info("CodeValueVOs : " + codeValue);
		LOGGER.info("exiting ProductServiceHttpEndpoint | retrieveFamVerResource");
		return codeValue;
	}

	@RequestMapping(value = "/{famCode}/{prodCode}/{prodVer}/retrieveProdFamVerResource.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveProdFamVerResource(
			@PathVariable("prodCode") Long prodCode,
			@PathVariable("famCode") Long famCode,
			@PathVariable("prodVer") Long prodVer) {
		LOGGER.info("entering ProductServiceHttpEndpoint | retrieveProdFamVerResource");

		List<CodeValue> codeValue = productService.retrieveProdFamVerResource(
				famCode, prodCode, prodVer);

		LOGGER.info("CodeValueVOs : " + codeValue);
		LOGGER.info("exiting ProductServiceHttpEndpoint | retrieveProdFamVerResource");
		return codeValue;
	}

	@RequestMapping(value = "/updateProdRescScoreGranMapDtl.service", method = RequestMethod.POST)
	public @ResponseBody
	ProductScoreMappingVO updateProdRescScoreGranMapDtl(
			@RequestBody ProductScoreMappingVO productScoreMappingVO) {
		LOGGER.info("entering ProductServiceHttpEndpoint | updateProdRescScoreGranMapDtl");
		return productService
				.updateProdRescScoreGranMapDtl(productScoreMappingVO);
	}

	@RequestMapping(value = "/retreiveProdRescScoreGranMapDtl.service", method = RequestMethod.POST)
	public @ResponseBody
	ProductScoreMappingVO retreiveProdRescScoreGranMapDtl(
			@RequestBody ProductScoreMappingVO productScoreMappingVO) {
		LOGGER.info("entering ProductServiceHttpEndpoint | retreiveProdRescScoreGranMapDtl");
		return productService
				.retreiveProdRescScoreGranMapDtl(productScoreMappingVO);
	}
	
	@RequestMapping(value = "/{prodAvailId}/retrieveProductMarketDetails.service",headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<Long> retrieveProductMarketDetails(@PathVariable("prodAvailId") Long prodAvailId) {
		LOGGER.info("entering ProductServiceHttpEndpoint | retreiveProdRescScoreGranMapDtl");
		return productService.retrieveProductMarketDetails(prodAvailId);
	}
	
}
