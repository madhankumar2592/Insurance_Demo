package com.dnb.dsc.refdata.service;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GlobalElement;
import com.dnb.dsc.refdata.core.entity.GloblalElementCrossWalk;
import com.dnb.dsc.refdata.core.vo.AddCrosswalkVO;
import com.dnb.dsc.refdata.core.vo.AddGlobalElementVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementCrosswalkSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementVO;

/**
 * This is used as the services interface for the Global Element operations
 *
 * @author Cognizant
 * 
 *
 */
public interface GlobalElementService {
	
	/**
	 * The method will retrieve all Topics from the  DB . The return
	 * type is a VO which contains all the topic names.
	 *
	 */	
	
	Long countSearchTopicsBkp(GlobalElementSearchVOBkp globalElementSearchVO);
	
	List<GlobalElement> searchByTopicsBkp(GlobalElementSearchVOBkp globalElementSearchVO);

	List<GlobalElementVO> retrieveHints();

	List<GlobalElementVO> retrieveHintsDesc();

	Long insertGlobalElement(AddGlobalElementVO addGlobalElementVO);

	AddGlobalElementVO retrieveGlobalElement(
			AddGlobalElementVO addGlobalElementVO);

	Long editGlobalElement(AddGlobalElementVO addGlobalElementVO);

	Boolean isDuplicateElementName(String glblEleName);

	Long checkGlblEleCrswlkId(GloblalElementCrossWalk crosswlk);

	String retrieveGlobalElement(Long elementID);

	List<AddCrosswalkVO> retrievePlatformDetails(
			Long globalElementPlatformCode);

	Long addNewCrosswalk(AddCrosswalkVO addCrosswalkVO);

	List<GloblalElementCrossWalk> crosswalkSearch(
			GlobalElementCrosswalkSearchVOBkp globalElementSearchVO);

	List<CodeValue> retrieveSearchCrossWalkCodeType(Long crosswalkAppliedCode);

	Long countCrosswalkSearch(
			GlobalElementCrosswalkSearchVOBkp globalElementCrosswalkSearchVOBkp);

	List<AddCrosswalkVO> retrieveEditPlatformDetails(
			Long globalElementPlatformCode, Long globalElementId);

	Long editNewCrosswalk(AddCrosswalkVO addCrosswalkVO);

	List<GloblalElementCrossWalk> retrievePlatformList();

	List<GlobalElement> unMappedElementCount();

	Long totalUnMappedElementCount(
			GloblalElementCrossWalk globlalElementCrossWalk);
	AddCrosswalkVO retrieveGlobalElementCrosswalk(
			AddCrosswalkVO addGlobalElementVO);

	Long retrieveGroupName(String groupName);

	Long retrieveGroupName(String groupName,Long globalElementId);
}
