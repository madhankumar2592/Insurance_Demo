/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeInferment;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ControlWordsSearchVO;

/**
 * This is used as the services interface for the Control Words operations
 * 
 * @author Cognizant
 * @version last updated : May 31, 2012
 * @see
 * 
 */
public interface ControlWordsService {
	/**
	 * 
	 * The method to retrieve all control words type codes
	 *
	 * @return
	 */
	List<CodeValueText> retrieveAllControlWords();
	/**
	 * 
	 * The method to retrieve the control words search results
	 *
	 * @param controlWordsSearchVO
	 * @return
	 */
	ControlWordsSearchVO retrieveControlWordsSearchResults(ControlWordsSearchVO controlWordsSearchVO);
	/**
	 * 
	 * The method to retrieve control word by control word identifier
	 *
	 * @param dnbUnusGlsyId
	 * @return
	 */
	DnbUnusGlsy retrieveControlWordById(Long dnbUnusGlsyId, Boolean isStagingDB);
	/**
	 * 
	 * The method to update control word
	 *
	 * @param dnbUnusGlsy
	 * @return
	 */
	Long updateControlWord(DnbUnusGlsy dnbUnusGlsy);

	/**
	 * 
	 * The method to retrieve all applicable country codes for the Area Code Numbers
	 *
	 * @param geoUnitTypeCode
	 * @return codeValueVOs
	 */
	List<CodeValueVO> retrieveAllAreaCodeGeoUnits(Long geoUnitTypeCode);
	
	/**
	 * 
	 * Performs a hierarchy search of Phone Area Code on the search db.<p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param controlWordsSearchVO
	 * @return list of PhoneAreaCode
	 */
	List<PhoneAreaCode> searchAreaCodeNumbers(ControlWordsSearchVO controlWordsSearchVO);

	/**
	 * 
	 * The method will count the records in the hierarchy search of control words on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param controlWordsSearchVO
	 * @return countResults
	 */
	Long countSearchAreaCodeNumbers(ControlWordsSearchVO controlWordsSearchVO);
	/**
	 * 
	 * The method to save the control words changes after the user approval
	 *
	 * @param domainId
	 * @param changeTypeId
	 * @return
	 */
	Long saveApprovedControlWords(Long domainId, Long changeTypeId);
	/**
	 * 
	 * The method to remove the control words data from transaction DB after user approval
	 *
	 * @param domainId
	 */
	void removeApprovedControlWords(Long domainId);
	/**
	 * The method will retrieve all Legal Form Class Codes from the Search DB . The return
	 * type is a VO which contains the Legal Form Class Codes and Code Value Descriptions.
	 *
	 */
	List<CodeValueVO> retrieveLegalFormClassCodes();
	/**
	 * The method will retrieve all Legal Form Codes from the Search DB . The return
	 * type is a VO which contains the Legal Form Codes and Code Value Descriptions.
	 *
	 */
	List<CodeValueVO> retrieveLegalFormCodes();
	/**
	 * The method will retrieve all Legal Form Languages from the Search DB . The return
	 * type is a VO which contains the Legal Form Languages and Code Value Descriptions.
	 *
	 */
	List<CodeValueVO> retrieveLegalFormLanguages();
	/**
	 * The method will retrieve all Legal Form Countries from the Search DB . The return
	 * type is a VO which contains the Legal Form Country and Code Value Descriptions.
	 *
	 */
	List<CodeValueVO> retrieveLegalFormCountries();
	/**
	 *
	 * The method will perform a hierarchy search of Inferment Text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return list of Inferment Text
	 */
	List<InfermentText> searchLegalFormInfermentText(ControlWordsSearchVO ctrlWrdsSearchCriteria);
	/**
	 *
	 * The method will perform a hierarchy search of Inferment Text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided and will return the total numbr of records found.
	 *
	 * @param searchCriteriaVO
	 * @return count of Inferment Text
	 */
	Long countSearchLegalFormInfermentText(ControlWordsSearchVO ctrlWrdsSearchCriteria);
    /**
	 * Retrieves InfermentText entity by infermentTextId. <p>
	 *
	 * @param infermentText
	 * @return InfermentText
	 */
	InfermentText retrieveInfermentTextByInfermentTextId(Long infermentText);
	
    /**
	 * Retrieves InfermentText entity by infermentTextId from the transaction DB. <p>
	 *
	 * @param infermentText
	 * @return InfermentText
	 */
	InfermentText reviewLegalFormInfermentChanges(Long infermentText);
	/**
	 * 
	 * Fetches the InfermentText entity by the  key infermentTextId.<p>
	 * 
	 * @param infermentTextId
	 * @return InfermentText entity
     * @throws Exception 
	 */
    List<IndustryCodeInferment> retrieveIndustryCodeTypeAndDesc(Integer codeTableId,Long languageCode);
	/**
	 * 
	 * The method to retrieve all language codes in control words
	 *
	 * @return
	 */
    List<IndustryCodeInferment> retrieveLanguageCode();
	/**
	 * 
	 * The method to retrieve industry code description
	 *
	 * @param industryCodeTypeCode
	 * @return
	 */
    List<IndustryCode> retrieveIndustryCodeDescription(Long industryCodeTypeCode);
	/**
	 * 
	 * The method to count the search results of industry code inferment
	 *
	 * @param industryCodesInfermentSearchCriteria
	 * @return
	 */
    Long countSearchIndustryCodesInferment(ControlWordsSearchVO industryCodesInfermentSearchCriteria);
	/**
	 * 
	 * The method to retrieve the search results of industry code inferment
	 *
	 * @param industryCodesInfermentSearchCriteria
	 * @return
	 */
    List<IndustryCodeInferment> searchIndustryCodesInferment(ControlWordsSearchVO industryCodesInfermentSearchCriteria);
	/**
	 * 
	 * The method to retrieve the search results of industry code inferment
	 *
	 * @param infermentText
	 * @return
	 */
    IndustryCodeInferment industryCodeInfermentSearchView(Long infermentText);
	/**
	 * The method will validate the InfermentText for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param infermentTextId
	 */
	Boolean lockInfermentText(Long infermentTextId);
	/**
	 * The method will persist the existing infermentText data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param infermentText
	 */
	Long updateLegalFormInferment(InfermentText infermentText);
	/**
	 * The method will persist the existing infermentText data in the staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param infermentTextId
	 */
	Long saveApprovedInfermentText(Long infermentTextId) throws Exception;
	/**
	 * The method will delete the approved infermentText data in the transaction
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param infermentText
	 */
	void removeApprovedInfermentText(Long infermentTextId);
	/**
	 * 
	 * The method to retrieve the list of all industry codes
	 *
	 * @param industryCodeId
	 * @return
	 */
	List<IndustryCode> retreiveIndustryCodeList(Long industryCodeId);
    /**
     * 
     * The method to retrieve the inferment text by the domain identifier
     *
     * @param domainId
     * @return
     */
	InfermentText retreiveInfermentTextByDomainId(Long domainId);
	/**
	 * 
	 * The method to update the phone area code
	 *
	 * @param phoneAreaCode
	 * @return
	 */
	Long updatePhoneAreaCode(PhoneAreaCode phoneAreaCode);
	/**
	 * 
	 * The method to retrieve the phone area code by id
	 *
	 * @param phoneAreaCodeId
	 * @return
	 */
	PhoneAreaCode retrievePhoneAreaCodeById(Long phoneAreaCodeId, Boolean isStagingDB);
	/**
	 * 
	 * The method to save the approved phone area codes
	 *
	 * @param domainId
	 * @return
	 */
	Long saveApprovedPhoneAreaCode(Long domainId);
	/**
	 * 
	 * The method to remove the approved phone area code details from the transaction DB
	 *
	 * @param domainId
	 */
	void removeApprovedPhoneAreaCode(Long domainId);
	/**
	 * 
	 * The method to retrieve the area code info
	 *
	 * @return
	 */
	List<String> retrieveAreaCodeInfo();
	
	Boolean lockPhoneAreaCodeForEdit(Long phoneAreaCodeId);
	
	Long countSearchControlWords(ControlWordsSearchVO controlWordsSearchVO);
}
