/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.endpoint;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.entity.GeoCurrency;
import com.dnb.dsc.refdata.core.vo.AddGeoCurrencyVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.CurrencySearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.GeoCurrencySearchVO;
import com.dnb.dsc.refdata.service.CurrencyService;

/**
 * This is the end point class implementation that connects a web service client
 * to the JAX-WS runtime. The class contains methods which are mapped to the web
 * service requests. The mapping will invoke the respective methods which in
 * turn invokes the respective service classes.
 * 
 * @author Cognizant
 * @version last updated : Feb 29, 2012
 * @see
 * 
 */
@Controller
public class CurrencyServiceHttpEndpoint {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CurrencyServiceHttpEndpoint.class);

	@Autowired
	private CurrencyService currencyService;
	
	/**
	 * 
	 * The method will perform a hierarchy search of Currency Exchange on the search db.<p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.<p>
	 * 
	 * @param currencySearchCriteria
	 * @return list of CurrencyExchange
	 */
	@RequestMapping(value = "/searchCurrencyExchange.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CurrencyExchange> searchCurrencyExchange(
			@RequestBody CurrencySearchCriteriaVO currencySearchCriteria) {
		LOGGER.info("entering CurrencyServiceHttpEndpoint | searchCurrencyExchange");
		return currencyService.searchCurrencyExchange(currencySearchCriteria);
	}
	
	/**
	 * The method to retrieve all data providers for the currency exchange data.
	 * The data will be fetched from the currency exchange tables.
	 * 
	 * @param languageCode
	 */
	@RequestMapping(value = "/{languageCode}/retrieveCurcyExchDataProviders.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveCurcyExchDataProviders(
			@PathVariable("languageCode") Long languageCode) {
		LOGGER.info("entering CurrencyServiceHttpEndpoint | retrieveCurcyExchDataProviders");

		List<CodeValueVO> codeValueVOs = currencyService
				.retrieveCurcyExchDataProviders(languageCode);

		LOGGER.info("exiting CurrencyServiceHttpEndpoint | retrieveCurcyExchDataProviders");
		return codeValueVOs;
	}
	
	/**
	 * 
	 * The method will count the records in the hierarchy search of currencies on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param currencySearchCriteria
	 * @return countResults
	 */
	@RequestMapping(value = "/countSearchCurrencyExchange.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchCurrencyExchange(
			@RequestBody CurrencySearchCriteriaVO currencySearchCriteriaVO) {
		LOGGER.info("entering CurrencyServiceHttpEndpoint | countSearchCurrencyExchange");
		return currencyService.countSearchCurrencyExchange(currencySearchCriteriaVO);
	}

	/**
	 * The method will persist the existing Currency Exchange data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param currencyExchange
	 */
	@RequestMapping(value = "/updateExchangeRate.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateExchangeRate(@RequestBody CurrencyExchange currencyExchange) {
		LOGGER.info("entering CurrencyServiceHttpEndpoint | countSearchCurrencies");
		return currencyService.updateExchangeRate(currencyExchange);
	}
	
	/**
	 * 
	 * The method will validate the Currency Exchange for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param geoUnitId
	 * @return
	 */
	@RequestMapping(value = "/{currencyExchangeId}/lockCurrencyExchange.service", method = RequestMethod.GET)
	public @ResponseBody
	String lockCurrencyExchange(@PathVariable("currencyExchangeId") Long currencyExchangeId) {
		LOGGER.info("entering GeographyServiceHttpEndpoint | lockGeoUnit");
		return currencyService.lockCurrencyExchange(currencyExchangeId);
	}

        /**
	 * Invoked when the the business owner reviews the
	 * changes submitted for his approval. The user reviews the changes and he
	 * could approve or reject the request.<p>
	 * 
	 * @param trackingId
	 * @return CurrencyExchange
	 */
	@RequestMapping(value = "/{trackingId}/reviewCurrencyExchangeChanges.service", headers = "Accept=application/json",
			method = RequestMethod.GET)
	public @ResponseBody
	CurrencyExchange reviewCurrencyExchangeChanges(@PathVariable("trackingId") Long trackingId) {
		LOGGER.info("entering CurrencyServiceHttpEndpoint | reviewCurrencyExchangeChanges");
		CurrencyExchange crcyExchangeMap = currencyService.reviewCurrencyExchangeChanges(trackingId);
		LOGGER.info("exiting CurrencyServiceHttpEndpoint | reviewCurrencyExchangeChanges");
		return crcyExchangeMap;
		
	}
	
	/**
	 * 
	 * The method will count the records in the geo currency table based on
	 * user inputs in db. The search will be done on the SOR db based on
	 * the search criteria the user had provided.
	 * 
	 * @param geoCurrencySearchCriteria
	 * @return countResults
	 */
	@RequestMapping(value = "/countSearchGeoCurrency.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchGeoCrcy(
			@RequestBody GeoCurrencySearchVO geoCurrencySearchVO) {
		LOGGER.info("entering CurrencyServiceHttpEndpoint | countSearchGeoCrcy");
		return currencyService.countSearchGeoCurrency(geoCurrencySearchVO);
	}
	
	/**
	 * 
	 * The method will perform a search of Geo Currency on the SOR db.<p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.<p>
	 * 
	 * @param geoCurrencySearchVO
	 * @return list of GeoCurrency
	 */
	@RequestMapping(value = "/searchGeoCurrency.service", method = RequestMethod.POST)
	public @ResponseBody
	List<GeoCurrency> searchGeoCrcy(
			@RequestBody GeoCurrencySearchVO geoCurrencySearchVO) {
		LOGGER.info("entering CurrencyServiceHttpEndpoint | searchGeoCrcy");
		return currencyService.searchGeoCurrency(geoCurrencySearchVO);
	}
	
	@RequestMapping(value = "/insertGeoCurrency.service", method = RequestMethod.POST)
	public @ResponseBody
	Long insertGeoCurrency(@RequestBody AddGeoCurrencyVO addGeoCurrencyVO) {
		LOGGER.info("entering CurrencyServiceHttpEndpoint | insertGeoCurrency");
		LOGGER.info("exiting CurrencyServiceHttpEndpoint | insertGeoCurrency");
		return currencyService.insertGeoCurrency(addGeoCurrencyVO);
	}
	
	     /**
		 * Invoked when the the business owner reviews the
		 * changes submitted for his approval. The user reviews the changes and he
		 * could approve or reject the request.<p>
		 * 
		 * @param trackingId
		 * @return CurrencyExchange
		 */
		@RequestMapping(value = "/{geoCurrencyId}/reviewGeoCurrency.service", headers = "Accept=application/json",
				method = RequestMethod.GET)
		public @ResponseBody
		GeoCurrency reviewGeoCurrency(@PathVariable("geoCurrencyId") Long geoCurrencyId) {
			LOGGER.info("entering CurrencyServiceHttpEndpoint | reviewCurrencyExchangeChanges");
			GeoCurrency geoCrcyMap = currencyService.reviewGeoCurrency(geoCurrencyId);
			LOGGER.info("exiting CurrencyServiceHttpEndpoint | reviewCurrencyExchangeChanges");
			return geoCrcyMap;
			
		}
		
		@RequestMapping(value = "/updateGeoCurrency.service", method = RequestMethod.POST)
		public @ResponseBody
		Long updateGeoCurrency(@RequestBody GeoCurrency geoCurrency) {
			LOGGER.info("entering CurrencyServiceHttpEndpoint | insertGeoCurrency");
			LOGGER.info("exiting CurrencyServiceHttpEndpoint | insertGeoCurrency");
			return currencyService.updateGeoCurrency(geoCurrency);
		}
}
