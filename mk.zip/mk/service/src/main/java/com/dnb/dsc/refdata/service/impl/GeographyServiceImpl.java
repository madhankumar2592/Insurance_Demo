/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.constant.RefDataUIConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GeoCodeConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoDefaultConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoHierarchy;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.entity.GeographySearch;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.entity.UserGroupMapping;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.GeoSearchCriteriaVO;
import com.dnb.dsc.refdata.dao.GeoStagingDAO;
import com.dnb.dsc.refdata.dao.GeoTransactionalDAO;
import com.dnb.dsc.refdata.service.GeoValidationService;
import com.dnb.dsc.refdata.service.GeographyService;

/**
 * This is used as the services interface for the Geography operations
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 *
 */
@Service("GeographyService")
public class GeographyServiceImpl implements GeographyService {

	@Autowired
	private GeoTransactionalDAO transactionalDAO;

	@Autowired
	private GeoStagingDAO stagingDAO;

	@Autowired
	private GeoValidationService geoValidationService;

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GeographyServiceImpl.class);

	/**
	 * The method will search for the geo units by name. The user will type in
	 * the filter condition in the name field and the dao layer will retrieve
	 * the names satisfying the filter
	 *
	 * @param nameFilter
	 * @param langaugeCode
	 * @return geoUnitNames the list of geo names
	 */
	@Override
	public List<GeoUnitName> searchGeoUnitByName(String nameFilter,
			int startIndex, int maxResults, String sortBy, String sortOrder,
			Long langaugeCode) {
		LOGGER.info("entering GeographyServiceImpl | searchByName");
		return stagingDAO.searchGeoUnitByName(nameFilter, startIndex,
				maxResults, sortBy, sortOrder, langaugeCode);
	}

	/**
	 * The method will search for the geo units by code. The user will type in
	 * the filter condition in the code field and the dao layer will retrieve
	 * the codes satisfying the filter
	 *
	 * @param codeFilter
	 * @param langaugeCode
	 * @return geoUnitCodes the list of geo codes
	 */
	@Override
	public List<GeoUnitCode> searchGeoUnitByCode(String codeFilter,
			int startIndex, int maxResults, String sortBy, String sortOrder,
			Long langaugeCode) {
		LOGGER.info("entering GeographyServiceImpl | searchByCode");
		return stagingDAO.searchGeoUnitByCode(codeFilter, startIndex,
				maxResults, sortBy, sortOrder, langaugeCode);
	}

	/**
	 * The method will perform a soft delete on the geoUnitId in the
	 * Transactional DB. The expiredByDate will be set as current date.
	 * <p>
	 *
	 * @param geoUnitId
	 * @return workflowTrackingId
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long deleteGeoUnitById(Long geoUnitId) {
		LOGGER.info("entering GeographyServiceImpl | deleteGeoUnitByGeoUnitId");

		GeoUnit geoUnit = stagingDAO.retrieveGeoUnitForDelete(geoUnitId);
			geoUnit.setExpiredByDate(new Date());
		transactionalDAO.deleteGeoUnit(geoUnit);
		return geoUnit.getGeoUnitId();
	}

	/**
	 *
	 * The method will validate the Geo Unit for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param geoUnitId
	 * @return
	 */
	@Override
	public String lockGeoUnit(Long geoUnitId) {
		LOGGER.info("entering GeographyServiceImpl | lockGeoUnit");
		String count = transactionalDAO.countGeoUnit(geoUnitId);
		if(count != null){
			return count;
		}else{
			return "false";
		}
	}

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 *
	 * @param geoUnitId
	 */
	@Override
	@Transactional("stgTransactionManager")
	public GeoUnit retrieveGeoUnitByGeoUnitId(Long geoUnitId) {

		LOGGER.info("entering GeographyServiceImpl | retrieveGeoUnitByGeoUnitId");
		GeoUnit geoUnit = stagingDAO.retrieveGeoUnitByGeoUnitId(geoUnitId);
		LOGGER.info("geoUnit : " + geoUnit);

		// retrieve the GeoUnits with the current GeoUnit as the parent
		if (geoUnit != null
				&& RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY_GROUP
						.equals(geoUnit.getGeoUnitTypeCode())) {
			geoUnit.setChildGeoUnitAssociations(retrieveChildGeoUnitAssociations(
					geoUnit.getGeoUnitId(),
					RefDataPropertiesConstants.DATABASE_STAGING_SOR));
			geoUnit.setParentGeoUnitAssociations(null);
		}
		return geoUnit;
	}

	/**
	 * The method will retrieve the Geo Unit based on the Workflow Tracking Id.
	 * This method will be invoked from the Workflow Component and the search
	 * will be performed on the Transactional DB.
	 *
	 * @param trackingId
	 * @param geoUnit
	 */
	@Override
	@Transactional("txnTransactionManager")
	public GeoUnit retreiveGeoUnitByDomainId(Long domainId) {
		LOGGER.info("entering GeographyServiceImpl | retreiveGeoUnitByDomainId");
		GeoUnit geoUnit = transactionalDAO
				.retrieveGeoUnitByGeoUnitId(domainId);
		LOGGER.info("Retrieved Geo Unit :  " + geoUnit.getGeoUnitId());

		// retrieve the GeoUnits with the current GeoUnit as the parent
		if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY_GROUP
				.equals(geoUnit.getGeoUnitTypeCode())) {
			geoUnit.setChildGeoUnitAssociations(retrieveChildGeoUnitAssociations(
					geoUnit.getGeoUnitId(),
					RefDataPropertiesConstants.DATABASE_TRANSACTION_DB));
			geoUnit.setParentGeoUnitAssociations(null);
		}
		return geoUnit;
	}

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 *
	 * @param nameType
	 * @param languageCode
	 */
	@Override
	public List<CodeValueVO> retrieveAllCountries(Long nameType,
			Long languageCode) {
		LOGGER.info("entering GeographyServiceImpl | retrieveAllCountries");
		return stagingDAO.retrieveAllCountries(nameType, languageCode);
	}

	/**
	 * The method will retrieve all Continent details from the Search DB based
	 * on the name type code and the user preferred language code. The return
	 * type is a VO which contains the Continent Geo Unit Id and the Continent
	 * Name.
	 *
	 * @param nameType
	 * @param languageCode
	 */
	@Override
	public List<CodeValueVO> retrieveAllContinents(Long nameType,
			Long languageCode) {
		LOGGER.info("entering GeographyServiceImpl | retrieveAllCountries");
		return stagingDAO.retrieveAllContinents(nameType, languageCode);
	}

	/**
	 * The method will retrieve the Geo Units corresponding to the
	 * parentGeoUnit, geoUnitType, nameType and languageCode which you want to
	 * retrieve the data. The retrieval is from the Search DB. The return type
	 * is a VO which contains the Geo Unit Id and the Geo Unit name.
	 *
	 * @param languageCode
	 * @param geoUnitType
	 * @param parentGeoUnitId
	 * @param nameType
	 */
	@Override
	public List<CodeValueVO> retrieveChildGeoUnitsByType(Long languageCode,
			Long geoUnitType, Long parentGeoUnitId, Long nameType) {
		LOGGER.info("entering GeographyServiceImpl | retrieveChildGeoUnitsByType");
		return stagingDAO.retrieveChildGeoUnitsByType(languageCode,
				geoUnitType, parentGeoUnitId, nameType);
	}

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 *
	 * @param domainId
	 * @param changeTypeId
	 */
	@Override
	@Transactional("stgTransactionManager")
	public Long saveApprovedGeoChanges(Long domainId, Long changeTypeId) {
		LOGGER.info("entering GeographyServiceImpl | saveApprovedChanges");
		// Retrieve the Geo unit details from the Work flow tracking table
		GeoUnit geoUnit = retrieveTxnGeoUnitById(domainId);

		if(RefDataChangeTypeConstants.CHANGE_TYPE_ADD_GEO_UNIT.equals(String.valueOf(changeTypeId))) {
			generateWorldBaseCode(geoUnit);
		}
		
		// Updates the Geo unit details to the Staging SoR
		stagingDAO.updateGeoUnit(geoUnit);

		LOGGER.info("exiting GeographyServiceImpl | saveApprovedChanges");
		return geoUnit.getGeoUnitId();
	}

	/**
	 * The method will remove the geo unit data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param geoUnitId
	 * @param boolean indicating the status
	 */
	@Override
	@Transactional("txnTransactionManager")
	public void removeApprovedGeoUnit(Long geoUnitId,Long changeTypeId) {
		transactionalDAO.removeApprovedGeoUnit(geoUnitId,changeTypeId);
	}

	/**
	 * The method will persist the existing Geo Unit data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param GeoUnit
	 * @return workflowTrackingId
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long updateGeoUnit(GeoUnit geoUnit) {
		GeoUnit updatedGeoUnit = transactionalDAO.updateGeoUnit(geoUnit);
		// the child geo unit associations will be updated in case of country groups
		if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY_GROUP.equals(geoUnit.getGeoUnitTypeCode())
				&& geoUnit.getChildGeoUnitAssociations() != null) {
			for(GeoUnitAssociation childAssociation : geoUnit.getChildGeoUnitAssociations())
			transactionalDAO.insertGeoUnitAssociations(childAssociation);
		}
		
		LOGGER.info("GeoUnit added with Id : " + updatedGeoUnit.getGeoUnitId());
		return updatedGeoUnit.getGeoUnitId();
	}

	/**
	 *
	 * The method will perform a hierarchy search of geo units on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return list of geographies
	 */
	public List<GeographySearch> searchGeographies(
			GeoSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering GeographyServiceImpl | searchGeographies");
		return transactionalDAO.searchGeographies(searchCriteriaVO);
	}

	/**
	 *
	 * The method will count the records in the hierarchy search of geo units on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return countResults
	 */
	public Long countSearchGeographies(GeoSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering GeographyServiceImpl | countSearchGeographies");
		return transactionalDAO.countSearchGeographies(searchCriteriaVO);
	}

	/**
	 *
	 * The method will count the records in the name search of geo units on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 *
	 * @param searchString
	 * @return countResults
	 */
	public Long countSearchGeoUnitByName(String searchString) {
		LOGGER.info("entering GeographyServiceImpl | countSearchGeoUnitByName");
		return stagingDAO.countSearchGeoUnitByName(searchString);
	}

	/**
	 *
	 * The method will count the records in the code search of geo units on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 *
	 * @param searchString
	 * @return countResults
	 */
	public Long countSearchGeoUnitByCode(String searchString) {
		LOGGER.info("entering GeographyServiceImpl | countSearchGeoUnitByCode");
		return stagingDAO.countSearchGeoUnitByCode(searchString);
	}

	/**
	 *
	 * The method will identify all child entities for the specified GeoUnit Id
	 *
	 * @param geoUnitId
	 * @param dbName
	 * @return
	 */
	private List<GeoUnitAssociation> retrieveChildGeoUnitAssociations(
			Long geoUnitId, String dbName) {
		LOGGER.info("entering GeographyServiceImpl | retrieveChildGeoUnitAssociations");
		LOGGER.info("GeographyServiceImpl | retrieveChildGeoUnitAssociations | geoUnitId : " + geoUnitId);
		LOGGER.info("GeographyServiceImpl | retrieveChildGeoUnitAssociations | dbName : " + dbName);
		List<GeoUnitAssociation> associations = null;
		if (RefDataPropertiesConstants.DATABASE_STAGING_SOR.equals(dbName)) {
			associations = stagingDAO
					.retrieveChildGeoUnitAssociations(geoUnitId);
		} else if (RefDataPropertiesConstants.DATABASE_TRANSACTION_DB
				.equals(dbName)) {
			associations = transactionalDAO
					.retrieveChildGeoUnitAssociations(geoUnitId);
		}
		LOGGER.info("child associations : " + associations);
		LOGGER.info("exiting GeographyServiceImpl | retrieveChildGeoUnitAssociations");
		return associations;
	}

	/**
	 * The method will be invoked by the when the the business owner reviews the
	 * changes submitted for his approval. The user reviews the changes and he
	 * could approve or reject the request. The method will fetch the details
	 * from Staging SoR and Transaction DB to merge and form the GeoUnit for
	 * review.
	 *
	 * @param trackingId
	 */
	@Override
	@Transactional("txnTransactionManager")
	public GeoUnit reviewGeoUnitChanges(Long domainId) {
		LOGGER.info("entering GeographyServiceImpl | reviewGeoUnitChanges");
		// retrieve the GeoUnit data from the Transaction DB
		GeoUnit txnGeoUnit = retreiveGeoUnitByDomainId(domainId);
		// retrieve the GeoUnit data from the Staging SoR
		GeoUnit stgGeoUnit = retrieveGeoUnitByGeoUnitId(txnGeoUnit
				.getGeoUnitId());

		// merge both the GeoUnits and form the GeoUnit for review
		if (stgGeoUnit != null) {
			return mergeGeoUnits(stgGeoUnit, txnGeoUnit);
		} else {
			LOGGER.info("txnGeoUnit : " + txnGeoUnit);
			return txnGeoUnit;
		}
	}

	/**
	 *
	 * The method will merge the data from the transaction DB and the Staging
	 * SoR. The fields containing the changes will be put in a map for all the
	 * identified fields.
	 *
	 * @param stgGeoUnit
	 * @param txnGeoUnit
	 * @return GeoUnit
	 */
	private GeoUnit mergeGeoUnits(GeoUnit stgGeoUnit, GeoUnit txnGeoUnit) {
		LOGGER.info("entering GeographyServiceImpl | mergeGeoUnits");
		GeoUnit mergeGeoUnit = new GeoUnit();
		mergeGeoUnit.setGeoUnitId(txnGeoUnit.getGeoUnitId());
		mergeGeoUnit.setGeoUnitTypeCode(txnGeoUnit.getGeoUnitTypeCode());
		mergeGeoUnit.setDnbComment(txnGeoUnit.getDnbComment());
		mergeGeoUnit.setEffectiveDate(txnGeoUnit.getEffectiveDate());
		mergeGeoUnit.setExpirationDate(txnGeoUnit.getExpirationDate());
		mergeGeoUnit.setExpiredByDate(txnGeoUnit.getExpiredByDate());
		mergeGeoUnit.setCreatedDate(txnGeoUnit.getCreatedDate());
		mergeGeoUnit.setCreatedUser(txnGeoUnit.getCreatedUser());
		mergeGeoUnit.setModifiedDate(txnGeoUnit.getModifiedDate());
		mergeGeoUnit.setModifiedUser(txnGeoUnit.getModifiedUser());

		// merge the GeoUnit Codes
		mergeGeoUnit.setGeoUnitCodes(mergeGeoUnitCodes(
				stgGeoUnit.getGeoUnitCodes(), txnGeoUnit.getGeoUnitCodes()));

		// merge the GeoUnit Names
		mergeGeoUnit.setGeoUnitNames(mergeGeoUnitNames(
				stgGeoUnit.getGeoUnitNames(), txnGeoUnit.getGeoUnitNames()));

		mergeGeoUnit
				.setParentGeoUnitAssociations(mergeGeoUnitAssociations(
						stgGeoUnit.getParentGeoUnitAssociations(),txnGeoUnit.getParentGeoUnitAssociations()));

		mergeGeoUnit
				.setChildGeoUnitAssociations(mergeGeoUnitAssociations(
						stgGeoUnit.getChildGeoUnitAssociations(),txnGeoUnit.getChildGeoUnitAssociations()));

		LOGGER.info("mergeGeoUnit : " + mergeGeoUnit);
		LOGGER.info("exiting GeographyServiceImpl | mergeGeoUnits");
		return mergeGeoUnit;
	}

	/**
	 *
	 * The method will merge the GeoUnitAssociation entities of Transaction DB and the
	 * Staging SoR. The return will be the merged GeoUnitNames.
	 *
	 * @param stgGeoUnitAssociations
	 * @param txnGeoUnitAssociations
	 * @return mergeGeoUnitAssociations
	 */
	private List<GeoUnitAssociation> mergeGeoUnitAssociations(
			List<GeoUnitAssociation> stgGeoUnitAssociations, List<GeoUnitAssociation> txnGeoUnitAssociations) {
		LOGGER.info("entering GeographyServiceImpl | mergeGeoUnitAssociations");
		LOGGER.info("GeographyServiceImpl | mergeGeoUnitAssociations | stgGeoUnitAssociations : " + stgGeoUnitAssociations);
		LOGGER.info("GeographyServiceImpl | mergeGeoUnitAssociations | txnGeoUnitAssociations : " + txnGeoUnitAssociations);

		List<GeoUnitAssociation> mergeGeoUnitAssociations = new ArrayList<GeoUnitAssociation>();
		List<Long> txnGeoUnitAssociationIds = new ArrayList<Long>();
		// identify the list of GeoUnitAssociationIds currently available in the
		// Staging SoR
		List<Long> stgGeoUnitAssociationIds = new ArrayList<Long>();
		if (txnGeoUnitAssociations != null) {
			for (GeoUnitAssociation stgGeoUnitAssociation : stgGeoUnitAssociations) {
				stgGeoUnitAssociationIds.add(stgGeoUnitAssociation.getGeoUnitAssociationId());
			}
			
			// Loop through the GeoUnitAssociations from Transaction DB
			for (GeoUnitAssociation txnGeoUnitAssociation : txnGeoUnitAssociations) {
				// If the GeoUnitAssociation is already available in the Staging SoR
				// then assume it is either a GeoUnitName UPDATE or DELETE
				if (stgGeoUnitAssociationIds.contains(txnGeoUnitAssociation.getGeoUnitAssociationId())) {
					// To identify UPDATE or DELETE, loop through the Staging SoR
					for (GeoUnitAssociation stgGeoUnitAssociation : stgGeoUnitAssociations) {

						if (txnGeoUnitAssociation.getGeoUnitAssociationId().equals(
								stgGeoUnitAssociation.getGeoUnitAssociationId())) {
							// If the ExpiredByDate field has NOT been modified then
							// assume it is a UPDATE operation in the Transaction DB
							if ((txnGeoUnitAssociation.getExpiredByDate()) != (
									stgGeoUnitAssociation.getExpiredByDate())) {
								txnGeoUnitAssociation.setChangeIndicator(
										RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED);
								mergeGeoUnitAssociations.add(txnGeoUnitAssociation);
								break;
							}
						}
					}
				}
				// If the geoUnitCOdeId is not existing in the GeoUnitAssociations
				// from Staging SoR then assume it as NEW addition.
				else {
					txnGeoUnitAssociation
							.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW);
					mergeGeoUnitAssociations.add(txnGeoUnitAssociation);
				}
				txnGeoUnitAssociationIds.add(txnGeoUnitAssociation.getGeoUnitAssociationId());
			}
		}
		
		if (stgGeoUnitAssociations != null) {
			for (GeoUnitAssociation stgGeoUnitAssociation : stgGeoUnitAssociations) {
				if (!txnGeoUnitAssociationIds.contains(stgGeoUnitAssociation.getGeoUnitAssociationId())) {
					stgGeoUnitAssociation.setChangeIndicator(
							RefDataPropertiesConstants.WQ_REVIEW_RECORD_NO_CHANGE);
					mergeGeoUnitAssociations.add(stgGeoUnitAssociation);
				}
			}
		}
		LOGGER.info("exiting GeographyServiceImpl | mergeGeoUnitAssociations");
		return mergeGeoUnitAssociations;
	}
	/**
	 *
	 * The method will merge the GeoUnitCode entities of Transaction DB and the
	 * Staging SoR. The return will be the merged GeoUnitCodes.
	 *
	 * @param stgGeoUnitCodes
	 * @param txnGeoUnitCodes
	 * @return mergeGeoUnitCodes
	 */
	private List<GeoUnitCode> mergeGeoUnitCodes(
			List<GeoUnitCode> stgGeoUnitCodes, List<GeoUnitCode> txnGeoUnitCodes) {
		LOGGER.info("entering GeographyServiceImpl | mergeGeoUnitCodes");

		List<GeoUnitCode> mergeGeoUnitCodes = new ArrayList<GeoUnitCode>();
		List<Long> txnGeoUnitCodeIds = new ArrayList<Long>();
		// identify the list of GeoUnitCodeIds currently available in the
		// Staging SoR
		List<Long> stgGeoUnitCodeIds = new ArrayList<Long>();
		if (txnGeoUnitCodes != null) {
			for (GeoUnitCode stgGeoUnitCode : stgGeoUnitCodes) {
				stgGeoUnitCodeIds.add(stgGeoUnitCode.getGeoUnitCodeId());
			}

			// Loop through the GeoUnitNames from Transaction DB
			for (GeoUnitCode txnGeoUnitCode : txnGeoUnitCodes) {
				// If the GeoUnitName is already available in the Staging SoR
				// then assume it is either a GeoUnitName UPDATE or DELETE
				if (stgGeoUnitCodeIds.contains(txnGeoUnitCode.getGeoUnitCodeId())) {
					// To identify UPDATE or DELETE, loop through the Staging SoR
					for (GeoUnitCode stgGeoUnitCode : stgGeoUnitCodes) {

						if (txnGeoUnitCode.getGeoUnitCodeId().equals(
								stgGeoUnitCode.getGeoUnitCodeId())) {
							// If the ExpiredByDate field has NOT been modified then
							// assume it is a UPDATE operation in the Transaction DB
							if ((txnGeoUnitCode.getExpiredByDate()) !=(
									stgGeoUnitCode.getExpiredByDate())) {
								txnGeoUnitCode.setChangeIndicator(
										RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED);
								mergeGeoUnitCodes.add(txnGeoUnitCode);
								break;
							}
						}
					}
				}
				// If the geoUnitCOdeId is not existing in the GeoUnitCodes
				// from Staging SoR then assume it as NEW addition.
				else {
					txnGeoUnitCode
							.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW);
					mergeGeoUnitCodes.add(txnGeoUnitCode);
				}
				txnGeoUnitCodeIds.add(txnGeoUnitCode.getGeoUnitCodeId());
			}
		}

		for (GeoUnitCode stgGeoUnitCode : stgGeoUnitCodes) {
			if (!txnGeoUnitCodeIds.contains(stgGeoUnitCode.getGeoUnitCodeId())) {
				stgGeoUnitCode.setChangeIndicator(
						RefDataPropertiesConstants.WQ_REVIEW_RECORD_NO_CHANGE);
				mergeGeoUnitCodes.add(stgGeoUnitCode);
			}
		}

		LOGGER.info("exiting GeographyServiceImpl | mergeGeoUnitCodes");
		return mergeGeoUnitCodes;
	}

	/**
	 *
	 * The method will merge the GeoUnitName entities of Transaction DB and the
	 * Staging SoR. The return will be the merged GeoUnitNames.
	 *
	 * @param stgGeoUnitNames
	 * @param txnGeoUnitNames
	 * @return mergeGeoUnitNames
	 */
	private List<GeoUnitName> mergeGeoUnitNames(
			List<GeoUnitName> stgGeoUnitNames, List<GeoUnitName> txnGeoUnitNames) {
		LOGGER.info("entering GeographyServiceImpl | mergeGeoUnitNames");

		List<GeoUnitName> mergeGeoUnitNames = new ArrayList<GeoUnitName>();
		List<Long> txnGeoUnitNameIds = new ArrayList<Long>();
		// identify the list of GeoUnitCodeIds currently available in the
		// Staging SoR
		List<Long> stgGeoUnitNameIds = new ArrayList<Long>();
		if (txnGeoUnitNames != null) {
			for (GeoUnitName stgGeoUnitName : stgGeoUnitNames) {
				stgGeoUnitNameIds.add(stgGeoUnitName.getGeoUnitNameId());
			}

			// Loop through the GeoUnitNames from Transaction DB
			for (GeoUnitName txnGeoUnitName : txnGeoUnitNames) {
				// If the GeoUnitName is already available in the Staging SoR
				// then assume it is either a GeoUnitName UPDATE or DELETE
				if (stgGeoUnitNameIds.contains(txnGeoUnitName.getGeoUnitNameId())) {
					// To identify UPDATE or DELETE, loop through the Staging SoR
					for (GeoUnitName stgGeoUnitName : stgGeoUnitNames) {

						if (txnGeoUnitName.getGeoUnitNameId().equals(
								stgGeoUnitName.getGeoUnitNameId())) {
							// If the ExpiredByDate field has NOT been modified then
							// assume it is a UPDATE operation in the Transaction DB
							if ((txnGeoUnitName.getExpiredByDate()) != (
									stgGeoUnitName.getExpiredByDate())) {
								txnGeoUnitName.setChangeIndicator(
										RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED);
								mergeGeoUnitNames.add(txnGeoUnitName);
								break;
							}
						}
					}
				}
				// If the geoUnitCOdeId is not existing in the GeoUnitCodes
				// from Staging SoR then assume it as NEW addition.
				else {
					txnGeoUnitName
							.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW);
					mergeGeoUnitNames.add(txnGeoUnitName);
				}
				txnGeoUnitNameIds.add(txnGeoUnitName.getGeoUnitNameId());
			}
		}

		for (GeoUnitName stgGeoUnitName : stgGeoUnitNames) {
			if (!txnGeoUnitNameIds.contains(stgGeoUnitName.getGeoUnitNameId())) {
				stgGeoUnitName.setChangeIndicator(
						RefDataPropertiesConstants.WQ_REVIEW_RECORD_NO_CHANGE);
				mergeGeoUnitNames.add(stgGeoUnitName);
			}
		}
		LOGGER.info("exiting GeographyServiceImpl | mergeGeoUnitCodes");
		return mergeGeoUnitNames;
	}

	/**
	 * The method will retrieve all Country Groups from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Group Geo Unit Id and the Country
	 * Names.
	 *
	 * @param nameType
	 * @param languageCode
	 */
	@Override
	public List<CodeValueVO> retrieveAllCountryGroups(Long nameType,
			Long languageCode) {
		LOGGER.info("entering GeographyServiceImpl | retrieveAllCountryGroups");
		return stagingDAO.retrieveAllCountryGroups(nameType, languageCode);
	}

	/**
	 * Retrieves all the country groups or the country groups under the given
	 * country group
	 * <p>
	 * The returned List of Geo Unit Names will be displayed in the search
	 * result page in Country Groups.
	 * <p>
	 *
	 * @param langCode
	 * @param writingScriptCode
	 * @param nameTypeCode
	 * @param geoUnitId
	 * @return a List of GeoUnitName
	 */
	@Override
	public List<GeoUnitName> searchCountryGroups(Long langCode,
			Long writingScriptCode, Long nameTypeCode, Long geoUnitId) {
		LOGGER.info("entering GeographyServiceImpl | searchCountryGroups");
		return stagingDAO.retrieveCountryGroups(langCode, writingScriptCode,
				nameTypeCode, geoUnitId);
	}

	/**
	 * The method will persist new Geo Unit data in the Transactional DB.
	 *
	 * @param GeoUnit
	 * @return workflowTrackingId
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long insertGeoUnit(GeoUnit geoUnit) {
		Long geoUnitId = stagingDAO.retrieveMaxGeoUnitId(geoUnit.getGeoUnitTypeCode());
		geoUnit.setGeoUnitId(geoUnitId);
		/*
		 * Updating the GeoUnitName and GeoUnitCode with geoUnitId
		 */
		if(geoUnit.getGeoUnitCodes() != null) {
			for(GeoUnitCode geoUnitCode : geoUnit.getGeoUnitCodes()) {
				geoUnitCode.setGeoUnitId(geoUnitId);
			}
		}
		if(geoUnit.getGeoUnitNames() != null) {
			for(GeoUnitName geoUnitName : geoUnit.getGeoUnitNames()) {
				geoUnitName.setGeoUnitId(geoUnitId);
			}
		}
		/*
		 * childGeoUnitAssociations in GeoUnit is transient and hence has to be
		 * persisted separately. It's made transient for performance reasons
		 */
		if (geoUnit.getChildGeoUnitAssociations() != null) {
			for (GeoUnitAssociation childGeoUnitAssociation : geoUnit.getChildGeoUnitAssociations()) {
				childGeoUnitAssociation.setParentGeoUnitId(geoUnitId);
			}
		}
		if (geoUnit.getParentGeoUnitAssociations() != null) {
			for (GeoUnitAssociation prntGeoUnitAssociation : geoUnit.getParentGeoUnitAssociations()) {
				prntGeoUnitAssociation.setChildGeoUnitId(geoUnitId);
			}
		}
		
		/**
		 * Below code is added to insert the country group child details in the GEO_UNIT_ASSN table
		 * Ticket # 214141000
		 */
		if (RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY_GROUP.equals(geoUnit.getGeoUnitTypeCode())
				&& geoUnit.getChildGeoUnitAssociations() != null) {
			for(GeoUnitAssociation childAssociation : geoUnit.getChildGeoUnitAssociations())
			transactionalDAO.insertGeoUnitAssociations(childAssociation);
		}
		
		LOGGER.info("GeoUnit before save : " + geoUnit);

		transactionalDAO.updateGeoUnit(geoUnit);
		LOGGER.info("GeoUnit added with Id : " + geoUnit.getGeoUnitId());

		return geoUnit.getGeoUnitId();
	}

	/**
	 *
	 * The method will retrieve all geography hierarchies
	 *
	 * @return geoHierarchies
	 */
	@Override
	public List<GeoHierarchy> retrieveAllGeoHierarchies() {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveAllGeoHierarchies");
		return transactionalDAO.retrieveAllGeoHierarchies();
	}

	/**
	 *
	 * The method will retrieve all geography default configurations
	 *
	 * @return geoDefaultConfigurations
	 */
	@Override
	public List<GeoDefaultConfiguration> retrieveAllGeoConfigurations() {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveAllGeoConfigurations");
		return transactionalDAO.retrieveAllGeoConfigurations();
	}

	@Override
	public Boolean checkForChildGeoUnit(Long geoUnitId) {
		LOGGER.info("entering GeographyServiceImpl | checkForChildGeoUnit");
		return geoValidationService.checkForChildGeoUnit(geoUnitId);
	}

	/**
	 * The method will search the Transaction SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 *
	 * @param geoUnitId
	 */
	@Override
	@Transactional("txnTransactionManager")
	public GeoUnit retrieveTxnGeoUnitById(Long geoUnitId) {

		LOGGER.info("entering GeographyServiceImpl | retrieveTxnGeoUnitById");
		GeoUnit geoUnit = transactionalDAO.retrieveGeoUnitByGeoUnitId(geoUnitId);
		LOGGER.info("geoUnit : " + geoUnit);

		// retrieve the GeoUnits with the current GeoUnit as the parent
		if (geoUnit != null
				&& RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY_GROUP
						.equals(geoUnit.getGeoUnitTypeCode())) {
			geoUnit.setChildGeoUnitAssociations(retrieveChildGeoUnitAssociations(
					geoUnit.getGeoUnitId(),
					RefDataPropertiesConstants.DATABASE_STAGING_SOR));
			geoUnit.setParentGeoUnitAssociations(null);
		}
		return geoUnit;
	}

	/**
	 *
	 * The method will retrieve all user group mappings available within refdata.
	 *
	 * @return userGroupMappings
	 */
	@Override
	public List<UserGroupMapping> retrieveAllUserGroupMappings() {
		LOGGER.info("entering GeoStagingDAOImpl | retrieveAllUserGroupMappings");
		return transactionalDAO.retrieveAllUserGroupMappings();
	}

	@Override
	public Map<Long, String> getHierarchyByGeoUnitId(Long geoUnitId, Long geoUnitTypeCode){
		List<GeoHierarchy> hierarchyList = transactionalDAO.getHierarchyByGeoUnitId(geoUnitId);

		Map<Long, GeoHierarchy> hierarchyMap = new HashMap<Long, GeoHierarchy>();
		for(GeoHierarchy currGH : hierarchyList){
			hierarchyMap.put(currGH.getChildGeoUnitTypeCode(), currGH);
		}

		Map<Long, String> parentRelationshipMap = new HashMap<Long, String>();
		GeoHierarchy currHierarchy = null;
		GeoHierarchy childHierarchy = null;
		while(hierarchyMap.get(geoUnitTypeCode) != null){
			currHierarchy = hierarchyMap.get(geoUnitTypeCode);
			if(currHierarchy == null){
				break;
			}
			childHierarchy = hierarchyMap.get(currHierarchy.getParentGeoUnitTypeCode());
			if(childHierarchy == null){
				if(currHierarchy.getIsRootIndicator()){
					parentRelationshipMap.put(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY,
							RefDataUIConstants.HIERARCHY_COUNTRY_TEXT);
				}
			}else{
				parentRelationshipMap.put(childHierarchy.getChildGeoUnitTypeCode(),
					childHierarchy.getChildGeoUnitTypeDescription());
			}
			geoUnitTypeCode = currHierarchy.getParentGeoUnitTypeCode();
		}

		return parentRelationshipMap;
	}

	@Override
	public String getOfficialNameByGeoUnitIdAndTypeCode(Long parentGeoUnitId, Long geoUnitId, Long geoUnitTypeCode) {
		return stagingDAO.getOfficialNameByGeoUnitIdAndTypeCode(parentGeoUnitId, geoUnitId, geoUnitTypeCode);
	}

	@Override
	public Map<Long, List<GeoUnit>> retrieveGeoUnitsByIdList(List<Long> geoUnitIds){
		List<GeoUnit> geoUnitList = stagingDAO.retrieveGeoUnitsByIdList(geoUnitIds);
		List<GeoUnit> geoUnitListByLanguageCode = null;
		Map<Long, List<GeoUnit>> geoUnitMap = new HashMap<Long, List<GeoUnit>>();
		for(GeoUnit geoUnit : geoUnitList){
			if(geoUnitMap.get(geoUnit.getGeoUnitId()) == null) {
				geoUnitListByLanguageCode = new ArrayList<GeoUnit>();
			} else {
				geoUnitListByLanguageCode = geoUnitMap.get(geoUnit.getGeoUnitId());
			}
			geoUnitListByLanguageCode.add(geoUnit);
			geoUnitMap.put(geoUnit.getGeoUnitId(), geoUnitListByLanguageCode);
		}
		return geoUnitMap;
	}

	/**
	 * The method will search the Transaction SoR for the GeoHierarchy based on the
	 * geoUnitId and will return the GeoHierarchy entity.
	 * 
	 * @param geoUnitId
	 */
	@Override
	@Transactional("txnTransactionManager")
	public List<GeoHierarchy> retrieveGeoUnitType(Long geoUnitId) {

		LOGGER.info("entering GeographyServiceImpl | retrieveGeoUnitType");
		List<GeoHierarchy> geoHierarchyList = transactionalDAO
				.retrieveGeoUnitType(geoUnitId);
		LOGGER.info("GeoHierarchy : " + geoHierarchyList);
		return geoHierarchyList;
	}
	
	/**
	 * The method will add UiBulkDownload data  in the
	 * Transactional DB. 
	 * 
	 * @param UiBulkDownload
	 * @return id
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long addUIBulkDownload(UiBulkDownload uiBulkDownload) {
		
		return transactionalDAO.addUIBulkDownload(uiBulkDownload);		
		
	}
	
	/**
	 * The method will search the Transaction SoR for the GeoHierarchy based on the
	 * geoUnitId and will return the GeoHierarchy entity.
	 * 
	 * @param geoUnitId
	 */
	@Override
	@Transactional("stgTransactionManager")
	public List<GeoHierarchy> retrieveGeoUnitHierarchies(Long geoUnitId) {

		LOGGER.info("entering GeographyServiceImpl | retrieveGeoUnitHierarchies");
		List<GeoHierarchy> geoHierarchyList = transactionalDAO
				.retrieveGeoUnitHierarchies(geoUnitId);
		LOGGER.info("GeoHierarchy : " + geoHierarchyList);
		return geoHierarchyList;
	}

	/**
	 * the method to return all geoUnit Types
	 * @return
	 */
	@Override
	@Transactional("stgTransactionManager")
	public List<CodeValue> retrieveAllGeoUnitTypes() {

		LOGGER.info("entering GeographyServiceImpl | retrieveAllGeoUnitTypes");
		List<CodeValue> geoUnitTypesList =stagingDAO.retrieveAllGeoUnitTypes();
		LOGGER.info("retrieveAllGeoUnitTypes : " + geoUnitTypesList);
		return geoUnitTypesList;
	}
	/**
	 * 
	 * The method to retrieve all applicable GeoUnit Names
	 *
	 * @return
	 */
	@Transactional("stgTransactionManager")
	public List<CodeValue> retrieveApplicableGeoNameTypes() {

		LOGGER.info("entering GeographyServiceImpl | retrieveApplicableGeoNameTypes");
		List<CodeValue> geoUnitNameTypes = stagingDAO.retrieveApplicableGeoNameTypes();
		LOGGER.info("exiting GeographyServiceImpl | retrieveApplicableGeoNameTypes | returned : " + geoUnitNameTypes);
		return geoUnitNameTypes;
	}
	/**
	 * 
	 * The method to generate the world base code if it is added as a GeoUnit
	 * Code. The rule to generate a worldbase code has been taken from the
	 * analysis sheet provided by the DA team.
	 * 
	 * @param geoUnit
	 */
	private void generateWorldBaseCode(GeoUnit geoUnit) {
		LOGGER.info("entering GeographyServiceImpl | generateWorldBaseCode");
		
		for(GeoUnitCode geoUnitCode : geoUnit.getGeoUnitCodes()) {
			if(RefDataPropertiesConstants.CODE_GEOGRAPHIC_CODE_TYPE_WBCODE.equals(geoUnitCode.getGeoCodeTypeCode())) {

				/*
				 * If the specified geo_unit is a country then the rule is to
				 * get the max of WB codes within the country.
				 */
				if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY.equals(geoUnit.getGeoUnitTypeCode())) {
					String wbCode = findNextValueOfCountryGeoCode(geoUnitCode.getGeoCodeTypeCode());
					geoUnitCode.setGeoCode(wbCode);
				} else {
					/*
					 * For all geo_units other than country, obtain the config details from the db
					 */
					List<GeoCodeConfiguration> codeConfigurations = 
						retrieveGeoUnitCodeConfigurations(RefDataPropertiesConstants.CODE_GEOGRAPHIC_CODE_TYPE_WBCODE);
					LOGGER.info("GeographyServiceImpl | generateWorldBaseCode | codeConfigurations : " + codeConfigurations);
					
					Long countryGeoUnitId = findCountryGeoUnitIdForGeoUnit(geoUnit);
					if(countryGeoUnitId != null) {
						for(GeoCodeConfiguration codeConfiguration : codeConfigurations) {
							if(codeConfiguration.getGeoUnitId().equals(countryGeoUnitId) && 
									codeConfiguration.getGeoUnitTypeCode().equals(geoUnit.getGeoUnitTypeCode())) {
								
								Long uniqueWithInGeoUnitId = findUniqueWithInGeoUnitId(
										geoUnit.getParentGeoUnitAssociations(),
										codeConfiguration.getUniqueWithInGeoUnitTypeCode());
								codeConfiguration.setUniqueWithInGeoUnitId(uniqueWithInGeoUnitId);
								
								geoUnitCode.setGeoCode(findNextValueOfGeoCode(codeConfiguration));
							}
						}
					}
				}
			}
		}
		
		LOGGER.info("exiting GeographyServiceImpl | generateWorldBaseCode");
	}

	/**
	 * 
	 * The method to retrieve the geo unit code configurations. The config table
	 * has been designed as per the analysis sheet by the DA team. The analysis
	 * sheet will be available in the common intra sharepoint.
	 * 
	 * @param codeTypeCode
	 * @return geoCodeConfigurations
	 */
	private List<GeoCodeConfiguration> retrieveGeoUnitCodeConfigurations(Long codeTypeCode) {
		LOGGER.info("entering GeographyServiceImpl | retrieveGeoUnitCodeConfigurations");
		return transactionalDAO.retrieveGeoUnitCodeConfigurations(codeTypeCode);
	}

	/**
	 * 
	 * The method to obtain the current GeoUnit's country Geo Unit Id. The
	 * method will iterate through the GeoUnit Association to identify the
	 * country.
	 * 
	 * @param geoUnit
	 * @return geoUnitId
	 */
	private Long findCountryGeoUnitIdForGeoUnit(GeoUnit geoUnit) {
		LOGGER.info("entering GeographyServiceImpl | findCountryGeoUnitIdForGeoUnit");
		Long countryGeoUnitId = null;
		/*
		 * Identify the parentGeoUnits with the geo_unit ids in the geo_unit's parent field  
		 */
		List<Long> parentGeoUnitIds = new ArrayList<Long>();
		for(GeoUnitAssociation parentAssociation : geoUnit.getParentGeoUnitAssociations()) {
			parentGeoUnitIds.add(parentAssociation.getParentGeoUnitId());
		}
		Map<Long, List<GeoUnit>> mapOfParentGeoUnits = retrieveGeoUnitsByIdList(parentGeoUnitIds);
		
		for (GeoUnitAssociation parentAssociation : geoUnit.getParentGeoUnitAssociations()) {
			GeoUnit parentGeoUnit = mapOfParentGeoUnits.get(parentAssociation.getParentGeoUnitId()).get(0);
			parentAssociation.setParentGeoUnit(parentGeoUnit);
			
			if(RefDataPropertiesConstants.CODE_GEO_UNIT_TYPE_COUNTRY.equals(parentGeoUnit.getGeoUnitTypeCode())) {
				countryGeoUnitId = parentGeoUnit.getGeoUnitId();
			}
		}
		
		LOGGER.info("GeographyServiceImpl | findCountryGeoUnitIdForGeoUnit | countryGeoUnitId : " + countryGeoUnitId);
		LOGGER.info("exiting GeographyServiceImpl | findCountryGeoUnitIdForGeoUnit");
		return countryGeoUnitId;
	}

	/**
	 * 
	 * The method will find the next WB code based on the configuration
	 * mentioned in the GeoCodeConfiguration entity. This method will return the
	 * next code to be assigned.
	 * 
	 * @param geoCodeTypeCode
	 * @param geoUnitTypeCode
	 * @param uniqueWithInGeoUnitTypeCode
	 * @param uniqueWithInGeoUnitId
	 * @return wbCode
	 */
	private String findNextValueOfGeoCode(GeoCodeConfiguration codeConfiguration) {
		LOGGER.info("entering GeographyServiceImpl | findNextValueOfGeoCode");
		
		String wbCode = stagingDAO.findMaxValueOfGeoCode(
				codeConfiguration.getGeoCodeTypeCode(), codeConfiguration.getGeoUnitTypeCode(),
				codeConfiguration.getUniqueWithInGeoUnitTypeCode(), codeConfiguration.getUniqueWithInGeoUnitId());
		LOGGER.info("GeographyServiceImpl | findNextValueOfGeoCode | current max wbCode : " + wbCode);
		
		String paddedWbCode = String.valueOf(Long.valueOf(wbCode) + 1);		
		if (codeConfiguration.isPaddingIndicator()) {
			paddedWbCode = String.format("%0" + codeConfiguration.getCodeMaximumLength() + "d", 
					Long.valueOf(wbCode) + 1);
		} 
		
		LOGGER.info("GeographyServiceImpl | findNextValueOfGeoCode | next wbCode : " + paddedWbCode);
		LOGGER.info("exiting GeographyServiceImpl | findNextValueOfGeoCode");
		return paddedWbCode;
	}

	/**
	 * 
	 * The method will identify the unique within geo_unit from the specified
	 * type code. If the WB code rule says
	 * "Maximum Value of Territory WorldBase Code within the Country", the
	 * method will identify the geo_unit id for the country under which the
	 * currently added geo_unit resides. This will iterate through the
	 * geo_unit's association details and identify the geo_unit id.
	 * 
	 * @param parentAssociations
	 * @param uniqueWithInGeoUnitTypeCode
	 * @return uniqueWithInGeoUnitId
	 */
	private Long findUniqueWithInGeoUnitId(
			List<GeoUnitAssociation> parentAssociations,
			Long uniqueWithInGeoUnitTypeCode) {
		LOGGER.info("entering GeographyServiceImpl | findUniqueWithInGeoUnitId");
		Long uniqueWithInGeoUnitId = 0L;
		
		for(GeoUnitAssociation parentAssociation : parentAssociations) {
			if(uniqueWithInGeoUnitTypeCode.equals(parentAssociation.getParentGeoUnit().getGeoUnitTypeCode())) {
				uniqueWithInGeoUnitId = parentAssociation.getParentGeoUnit().getGeoUnitId();
			}
		}
		LOGGER.info("GeographyServiceImpl | findNextWBCode | uniqueWithInGeoUnitId : " + uniqueWithInGeoUnitId);
		LOGGER.info("exiting GeographyServiceImpl | findUniqueWithInGeoUnitId");
		return uniqueWithInGeoUnitId;
	}
	
	/**
	 * 
	 * The method will find the next WB code based on the configuration
	 * mentioned in the GeoCodeConfiguration entity. This method will return the
	 * next code to be assigned for a Country.
	 * 
	 * @param geoCodeTypeCode
	 * @return wbCode
	 */
	private String findNextValueOfCountryGeoCode(Long geoCodeTypeCode) {
		LOGGER.info("entering GeographyServiceImpl | findNextValueOfCountryGeoCode");
		
		String wbCode = stagingDAO.findMaxValueOfCountryGeoCode(geoCodeTypeCode);
		LOGGER.info("GeographyServiceImpl | findNextValueOfCountryGeoCode | current max wbCode : " + wbCode);
		
		String paddedWbCode = String.format("%06d", Long.valueOf(wbCode) + 1);
		
		LOGGER.info("GeographyServiceImpl | findNextValueOfGeoCode | next wbCode : " + paddedWbCode);
		LOGGER.info("exiting GeographyServiceImpl | findNextValueOfCountryGeoCode");
		return paddedWbCode;
	}
}