package com.dnb.dsc.refdata.service.endpoint;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.Score;
import com.dnb.dsc.refdata.core.vo.AddNewScoreVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.GranularityValueVO;
import com.dnb.dsc.refdata.core.vo.ScoreDtlVO;
import com.dnb.dsc.refdata.core.vo.ScoreSearchVO;
import com.dnb.dsc.refdata.core.vo.ScoreVO;
import com.dnb.dsc.refdata.service.ScoreService;



/**
 * This is the end point class implementation that connects a web service client
 * to the JAX-WS runtime. The class contains methods which are mapped to the web
 * service requests. The mapping will invoke the respective methods which in
 * turn invokes the respective service classes.
 * 
 * @author Cognizant
 * @version last updated : Aug 21, 2014
 * @see
 * 
 */

@Controller
public class ScoreServiceHttpEndpoint {
	
	@Autowired
	private ScoreService scoreService;
	
	
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ScoreServiceHttpEndpoint.class);
	
	@RequestMapping(value = "/{capabilityCode}/retrieveGranularityCodes.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveGranularityCodes(
			@PathVariable("capabilityCode") String capabilityCode)
			 {
		LOGGER.info("entering ScoreServiceHttpEndpoint | retrieveGranularityCodes");

		List<CodeValueVO> CodeValueVOs = scoreService
				.retrieveGranularityCodes(capabilityCode);

		LOGGER.info("CodeValueVOs : " + CodeValueVOs);
		LOGGER.info("exiting ScoreServiceHttpEndpoint | retrieveGranularityCodes");
		return CodeValueVOs;
	}

	@RequestMapping(value = "/updateGranularityCode.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateGranularityCode(@RequestBody GranularityValueVO granularityValueVO) {
		LOGGER.info("entering ScoreServiceHttpEndpoint | updateGranularityCode.service");
		LOGGER.info("ScoreTypeCode : " + granularityValueVO.getScoreTypeCode());
		LOGGER.info("exiting ScoreServiceHttpEndpoint | updateGranularityCode.service");
		return scoreService.updateGranularityCode(granularityValueVO);
	}

	
	@RequestMapping(value = "/updateNewScoreCode.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateNewScoreCode(@RequestBody AddNewScoreVO addNewScoreVO) {
		LOGGER.info("entering ScoreServiceHttpEndpoint | updateNewScoreCode.service");
		LOGGER.info("ScoreTypeCode : " + addNewScoreVO.getScoreTypeCode());
		LOGGER.info("exiting ScoreServiceHttpEndpoint | updateNewScoreCode.service");
		return scoreService.updateNewScoreCode(addNewScoreVO);
	}
	
	@RequestMapping(value = "/retrieveAllScoreTypeCode.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveAllScoreTypeCode() {
		LOGGER.info("entering ScoreServiceHttpEndpoint | retrieveAllScoreTypeCode");

		List<CodeValueVO> codeValueVOs = scoreService.retrieveAllScoreTypeCode();

		LOGGER.info("exiting ScoreServiceHttpEndpoint | retrieveAllScoreTypeCode");
		return codeValueVOs;
	}
	
	
	@RequestMapping(value = "/{scoreType}/retrieveMarketTypeCodes.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveMarketTypeCodes(
			@PathVariable("scoreType") Long scoreType)
			 {
		LOGGER.info("entering ScoreServiceHttpEndpoint | retrieveMarketTypeCodes");

		List<CodeValueVO> CodeValueVOs = scoreService
				.retrieveMarketTypeCodes(scoreType);

		LOGGER.info("CodeValueVOs : " + CodeValueVOs);
		LOGGER.info("exiting ScoreServiceHttpEndpoint | retrieveMarketTypeCodes");
		return CodeValueVOs;
	}
	
	
	@RequestMapping(value = "/{scoreType}/{marketType}/retrievescoreVersions.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<Score> retrievescoreVersions(
			@PathVariable("scoreType") Long scoreType,
			@PathVariable("marketType") Long marketType)
			 {
		LOGGER.info("entering ScoreServiceHttpEndpoint | retrievescoreVersions");

		List<Score> Scores = scoreService
				.retrievescoreVersions(scoreType, marketType);

		LOGGER.info("Score : " + Scores);
		LOGGER.info("exiting ScoreServiceHttpEndpoint | retrievescoreVersions");
		return Scores;
	}
	
	
	@RequestMapping(value = "/{scoreType}/{marketType}/{scoreVersion}/retrieveAttributeDetails.service", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<AddNewScoreVO> retrieveAttributeDetails(
			@PathVariable("scoreType") Long scoreType,
			@PathVariable("marketType") Long marketType,
			@PathVariable("scoreVersion") Double scoreVersion)
			 {
		LOGGER.info("entering ScoreServiceHttpEndpoint | retrieveAttributeDetails");

		List<AddNewScoreVO> AddNewScoreVOs = scoreService
				.retrieveAttributeDetails(scoreType, marketType, scoreVersion);

		LOGGER.info("Score : " + AddNewScoreVOs);
		LOGGER.info("exiting ScoreServiceHttpEndpoint | retrieveAttributeDetails");
		return AddNewScoreVOs;
	}
	
//
	@RequestMapping(value = "/retrieveScoreTypeCode.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<Long> retrieveScoreTypeCode() {
		LOGGER.info("entering ScoreServiceHttpEndpoint | retrieveScoreTypeCode");

		List<Long> codeValueVOs = scoreService.retrieveScoreTypeCode();

		LOGGER.info("exiting ScoreServiceHttpEndpoint | retrieveScoreTypeCode");
		return codeValueVOs;
	}
	
		@RequestMapping(value = "/updateNewScoreMapping.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateNewScoreMapping(@RequestBody AddNewScoreVO addNewScoreVO) {
		LOGGER.info("entering ScoreServiceHttpEndpoint | updateNewScoreMapping.service");
		LOGGER.info("ScoreTypeCode : " + addNewScoreVO.getScoreTypeCode());
		LOGGER.info("exiting ScoreServiceHttpEndpoint | updateNewScoreMapping.service");
		return scoreService.updateNewScoreMapping(addNewScoreVO);
	}
	
	@RequestMapping(value = "/retrieveScoreTypeCodeValues.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveScoreTypeCodeValues(@RequestBody  ScoreVO scoreVO) throws Exception {
		LOGGER.info("entering ScoreServiceHttpEndpoint | retrieveScoreTypeCodeValues");
		return scoreService.retrieveScoreTypeCodeValues(scoreVO);
	}
	
	@RequestMapping(value = "/retrieveMarketCodeValues.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValueVO> retrieveMarketCodeValues(@RequestBody  ScoreVO scoreVO) throws Exception {
		LOGGER.info("entering ScoreServiceHttpEndpoint | retrieveMarketCodeValues");
		return scoreService.retrieveMarketCodeValues(scoreVO);
	}
	@RequestMapping(value = "/retrieveVersionValues.service", method = RequestMethod.POST)
	public @ResponseBody
	List<Score> retrieveVersionValues(@RequestBody  Score scoreVO) throws Exception {
		LOGGER.info("entering ScoreServiceHttpEndpoint | retrieveVersionValues");
		return scoreService.retrieveVersionValues(scoreVO);
	}
	@RequestMapping(value = "/retrieveGranularityForScrType.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveGranularityForScrType(@RequestBody  ScoreVO scoreVO) throws Exception {
		LOGGER.info("entering ScoreServiceHttpEndpoint | retrieveGranularityForScrType");
		return scoreService.retrieveGranularityForScrType(scoreVO);
	}
	@RequestMapping(value = "/updateScoreDtl.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateScoreDtl(@RequestBody ScoreDtlVO scoreDtlVO) {
		LOGGER.info("entering ScoreServiceHttpEndpoint | updateScoreDtl.service");
		return scoreService.updateScoreDtl(scoreDtlVO);
	}
	//
	@RequestMapping(value = "/retrieveGruTypeCodeValues.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveGruTypeCodeValues(@RequestBody  ScoreVO scoreVO) throws Exception {
		LOGGER.info("entering ScoreServiceHttpEndpoint | retrieveGruTypeCodeValues");
		return scoreService.retrieveGruTypeCodeValues(scoreVO);
	}
	@RequestMapping(value = "/countSearchScore.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchScore(
			@RequestBody ScoreSearchVO searchCriteriaVO) {
		return scoreService.countSearchScore(searchCriteriaVO);
	}
	@RequestMapping(value = "/scoreSearchResult.service", method = RequestMethod.POST)
	public @ResponseBody
	List<ScoreSearchVO> scoreSearch(
			@RequestBody ScoreSearchVO searchCriteriaVO)throws Exception {
		
		return scoreService.scoreSearch(searchCriteriaVO);
		
	}	
	@RequestMapping(value = "/editScoreSearch.service", method = RequestMethod.POST)
	public @ResponseBody
	ScoreSearchVO editScoreSearch(@RequestBody ScoreSearchVO scoreSearchVO) {
		LOGGER.info("entering ScoreServiceHttpEndpoint | editScoreSearch.service");
		return scoreService.editScoreSearch(scoreSearchVO);
	}
	@RequestMapping(value = "/updateScoreMapDtl.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateScoreMapDtl(@RequestBody ScoreSearchVO scoreSearchVO) {
		LOGGER.info("entering ScoreServiceHttpEndpoint | updateScoreMapDtl.service");
		return scoreService.updateScoreMapDtl(scoreSearchVO);
	}
	
	/*@RequestMapping(value = "/retrieveProductTypeCodeVals.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveProductTypeCodeValues(@RequestBody  ProductSearchVO productSearchVO) throws Exception {
		LOGGER.info("entering ProductServiceHttpEndpoint | retrieveProductTypeCodeValues");
		return productService.retrieveProductTypeCodeValues(productSearchVO);
	}
	@RequestMapping(value = "/retrieveResourceTypeCodeVals.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveResourceTypeCodeValues(@RequestBody  ProductSearchVO productSearchVO) throws Exception {
		LOGGER.info("entering ProductServiceHttpEndpoint | retrieveResourceTypeCodeValues");
		return productService.retrieveResourceTypeCodeValues(productSearchVO);
	}*/
	
	////////// Score Search Pages changes
	@RequestMapping(value = "/retrieveScrSearchScoreTypeCode.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveScrSearchScoreTypeCode(@RequestBody ScoreVO scoreVO) {
		LOGGER.info("entering ScoreServiceHttpEndpoint | updateScoreMapDtl.service");
		return scoreService.retrieveScrSearchScoreTypeCode(scoreVO);
	}
	
	@RequestMapping(value = "/retrieveScrSearchGranularity.service", method = RequestMethod.POST)
	public @ResponseBody	
	List<CodeValue> retrieveScrSearchGranularity(@RequestBody ScoreVO scoreVO) {
		LOGGER.info("entering ScoreServiceHttpEndpoint | updateScoreMapDtl.service");
		return scoreService.retrieveScrSearchGranularity(scoreVO);
	}
	
	@RequestMapping(value = "/{scoreTypeCode}/{scoreMarketCode}/{scoreVersion}/checkForDuplicate.service", method = RequestMethod.GET)
	public @ResponseBody
	Boolean checkForDuplicate(@PathVariable("scoreTypeCode") Long scoreTypeCode,
			@PathVariable("scoreMarketCode") Long scoreMarketCode,
			@PathVariable("scoreVersion") Double scoreVersion)	{
		LOGGER.info("entering SCoTsServiceHttpEndpoint | checkForDuplicate");		
		return scoreService.checkForDuplicate(scoreTypeCode, scoreMarketCode, scoreVersion);

	}

}
