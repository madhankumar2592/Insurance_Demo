/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeInferment;
import com.dnb.dsc.refdata.core.entity.DnbUnusTlcmAdr;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsyCtryAppy;
import com.dnb.dsc.refdata.core.entity.InfermentTextCountryApplicability;
import com.dnb.dsc.refdata.core.entity.LegalFormInferment;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.ControlWordsSearchVO;
import com.dnb.dsc.refdata.dao.CtrlWrdsStagingDAO;
import com.dnb.dsc.refdata.dao.CtrlWrdsTransactionalDAO;
import com.dnb.dsc.refdata.service.ControlWordsService;

/**
 * This is used as the services implementation for the Control Words operations
 *
 * @author Cognizant
 * @version last updated : May 31, 2012
 * @see
 *
 */
@Service("ControlWordsService")
public class ControlWordsServiceImpl implements ControlWordsService {
	
	
	@Autowired
	private CtrlWrdsStagingDAO stagingDAO;
	
	@Autowired
	private CtrlWrdsTransactionalDAO transactionalDAO;
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ControlWordsServiceImpl.class);
	
	@Override
	public List<CodeValueText> retrieveAllControlWords() {
		LOGGER.info("entering ControlWordsServiceImpl | retrieveAllControlWords");
		return stagingDAO.retrieveAllControlWords();
	}

	@Override
	public ControlWordsSearchVO retrieveControlWordsSearchResults(ControlWordsSearchVO controlWordsSearchVO){
		controlWordsSearchVO.setControlWords(stagingDAO.searchByOffensiveWord(controlWordsSearchVO));
		setStatusString(controlWordsSearchVO.getControlWords());
				return controlWordsSearchVO;
	}

	@Override
	@Transactional("stgTransactionManager")
	public DnbUnusGlsy retrieveControlWordById(Long dnbUnusGlsyId, Boolean isStagingDB) {

		LOGGER.info("entering ControlWordsServiceImpl | retrieveControlWordById");
		DnbUnusGlsy dnbUnusGlsy = null;
		if(isStagingDB){
			dnbUnusGlsy = stagingDAO.retrieveControlWordById(dnbUnusGlsyId);
		}else{
			dnbUnusGlsy = transactionalDAO.retrieveControlWordById(dnbUnusGlsyId);
		}
		LOGGER.info("dnbUnusGlsy : " + dnbUnusGlsy);
		return dnbUnusGlsy;
	}

	@Override
	@Transactional("txnTransactionManager")
	public Long updateControlWord(DnbUnusGlsy dnbUnusGlsy) {	
		DnbUnusGlsy updatedDnbUnusGlsy = transactionalDAO.updateControlWord(dnbUnusGlsy);	
		LOGGER.info("DnbUnusGlsy added with Id : " + updatedDnbUnusGlsy.getDnbUnusGlsyId());
		return updatedDnbUnusGlsy.getDnbUnusGlsyId();
	}

	/**
	 * 
	 * The method to retrieve all applicable country codes for the Area Code Numbers
	 *
	 * @param geoUnitTypeCode
	 * @return codeValueVOs
	 */
	public List<CodeValueVO> retrieveAllAreaCodeGeoUnits(Long geoUnitTypeCode) {
		return stagingDAO.retrieveAllAreaCodeGeoUnits(geoUnitTypeCode);
	}
	
	/**
	 * 
	 * Performs a hierarchy search of Phone Area Code on the search db.<p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param controlWordsSearchVO
	 * @return list of PhoneAreaCode
	 */
	public List<PhoneAreaCode> searchAreaCodeNumbers(ControlWordsSearchVO controlWordsSearchVO) {
		return stagingDAO.searchAreaCodeNumbers(controlWordsSearchVO);
	}

	/**
	 * 
	 * The method will count the records in the hierarchy search of control words on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param controlWordsSearchVO
	 * @return countResults
	 */
	public Long countSearchAreaCodeNumbers(ControlWordsSearchVO controlWordsSearchVO) {
		return stagingDAO.countSearchAreaCodeNumbers(controlWordsSearchVO);
	}
	
	@Override
	@Transactional("stgTransactionManager")
	public Long saveApprovedControlWords(Long domainId, Long changeTypeId) {
		LOGGER.info("entering ControlWordsServiceImpl | saveApprovedControlWords");
		DnbUnusGlsy dnbUnusGlsy = transactionalDAO.retrieveControlWordById(domainId);
		stagingDAO.updateControlWord(dnbUnusGlsy);
		if(dnbUnusGlsy.getCountryApplicability() != null){
			for(DnbUnusGlsyCtryAppy ctry : dnbUnusGlsy.getCountryApplicability()){
				stagingDAO.updateDnbUnusGlsyCtryAppy(ctry);
			}	
		}
		if(dnbUnusGlsy.getDnbUnusIndNme() != null){
			stagingDAO.updateDnbUnusIndNme(dnbUnusGlsy.getDnbUnusIndNme());
		}
		if(dnbUnusGlsy.getDnbUnusAdr() != null){
			stagingDAO.updateDnbUnusAdr(dnbUnusGlsy.getDnbUnusAdr());
		}
		if(dnbUnusGlsy.getTelecomAddress() != null){
			for(DnbUnusTlcmAdr dnbUnusTlcmAdr : dnbUnusGlsy.getTelecomAddress()){
				stagingDAO.updateDnbUnusTlcmAdr(dnbUnusTlcmAdr);
			}
		}
		if(dnbUnusGlsy.getPhoneAreaCode() != null){
			stagingDAO.updatePhoneAreaCode(dnbUnusGlsy.getPhoneAreaCode());
		}
		LOGGER.info("exiting ControlWordsServiceImpl | saveApprovedControlWords");
		return dnbUnusGlsy.getDnbUnusGlsyId();
	}
	
	@Override
	@Transactional("txnTransactionManager")
	public void removeApprovedControlWords(Long domainId) {
		transactionalDAO.removeApprovedControlWord(domainId);
	}
@Override
	public List<CodeValueVO> retrieveLegalFormClassCodes() {
		LOGGER.info("entering ControlWordsServiceImpl | retrieveLegalFormClassCodes");
		return stagingDAO.retrieveLegalFormClassCodes();
	}
	/**
	 * The method will retrieve all Legal FormCodes.
	 */
	@Override
	public List<CodeValueVO> retrieveLegalFormCodes() {
		LOGGER.info("entering ControlWordsServiceImpl | retrieveLegalFormCodes");
		return stagingDAO.retrieveLegalFormCodes();
	}
	/**
	 * The method will retrieve all Legal Form Languages.
	 */
	@Override
	public List<CodeValueVO> retrieveLegalFormLanguages() {
		LOGGER.info("entering ControlWordsServiceImpl | retrieveLegalFormLanguages");
		return stagingDAO.retrieveLegalFormLanguages();
	}
	/**
	 * The method will retrieve all Legal Form Countries.
	 */
	@Override
	public List<CodeValueVO> retrieveLegalFormCountries() {
		LOGGER.info("entering ControlWordsServiceImpl | retrieveLegalFormCountries");
		return stagingDAO.retrieveLegalFormCountries();
	}
	
	/**
	 *
	 * The method will perform a hierarchy search of Inferment Text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return list of Inferment Text
	 */
	@Override
	public List<InfermentText> searchLegalFormInfermentText(
			ControlWordsSearchVO ctrlWrdsSearchCriteria) {
		LOGGER.info("entering ControlWordsServiceImpl | searchInfermentText");
		return stagingDAO.searchLegalFormInfermentText(ctrlWrdsSearchCriteria);
	}
	/**
	 *
	 * The method will perform a hierarchy search of Inferment Text on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided and will return the count.
	 *
	 * @param searchCriteriaVO
	 * @return count of Inferment Text
	 */
	@Override
	public Long countSearchLegalFormInfermentText(
			ControlWordsSearchVO ctrlWrdsSearchCriteria) {
		LOGGER.info("entering ControlWordsServiceImpl | searchInfermentText");
		return stagingDAO.countSearchLegalFormInfermentText(ctrlWrdsSearchCriteria);
	}
	/**
	 * Retrieves InfermentText entity by infermentTextId.
	 * <p>
	 * 
	 * @param infermentTextId
	 * @return InfermentText
	 */
	@Override
	@Transactional("stgTransactionManager")
	public InfermentText retrieveInfermentTextByInfermentTextId(Long infermentTextId) {
		LOGGER.info("entering ControlWordsServiceImpl | retrieveInfermentTextByInfermentTextId");
		InfermentText infermentText = null;
		
		infermentText = stagingDAO.retrieveInfermentTextByInfermentTextId(infermentTextId);
		
		if(infermentText != null) {
			Long industryCodeId = 0L;
            for(IndustryCodeInferment industryCodeInferment: infermentText.getIndustryCodeInferment()){                        
                industryCodeId = industryCodeInferment.getIndustryCodeId();                        
            } 
            List<IndustryCode> industryCode = stagingDAO.retreiveIndustryCodeList(industryCodeId);
            infermentText.setIndustryCodeList(industryCode);
		}
		LOGGER.info("exiting ControlWordsServiceImpl | retrieveInfermentTextByInfermentTextId || infermentText : "
				+ infermentText);
		return infermentText;
	}
	/**
	 * This method reviews InfermentText changes by  merging the inferment text entities from both
	 * staging and transaction DB.
	 * <p>
	 * 
	 * @param infermentTextId
	 * @return InfermentText
	 */
	@Override
	@Transactional("txnTransactionManager")
	public InfermentText reviewLegalFormInfermentChanges(Long infermentTextId) {
		LOGGER.info("entering ControlWordsServiceImpl | reviewLegalFormInfermentChanges");
		InfermentText txnInfermentText = null;
		try {
			txnInfermentText = retreiveInfermentTextByDomainId(infermentTextId);
		} catch(Exception e) {
			LOGGER.info("No data available in transaction DB");
		}
		List<IndustryCode> industryCodeList = new ArrayList<IndustryCode>();
		InfermentText stgInfermentText = retrieveInfermentTextByInfermentTextId(infermentTextId);
		
		if(txnInfermentText != null) {
			if (stgInfermentText != null) {		
				txnInfermentText.setCountryApplicabilities(mergeCountries(
						stgInfermentText.getCountryApplicabilities(),
						txnInfermentText.getCountryApplicabilities()));
			}
		} else {
			txnInfermentText = stgInfermentText;
		}
        Long industryCodeId = 0L;
        for(IndustryCodeInferment industryCodeInferment: txnInfermentText.getIndustryCodeInferment()){               
            industryCodeId = industryCodeInferment.getIndustryCodeId();
            List<IndustryCode> industryCode = stagingDAO.retreiveIndustryCodeList(industryCodeId);
            industryCodeList.addAll(industryCode);
        } 
        
        txnInfermentText.setIndustryCodeList(industryCodeList); 
		
		LOGGER.info("exiting ControlWordsServiceImpl | retrieveInfermentTextByInfermentTextId " +
				"| txnInfermentText : "	+ txnInfermentText);
		return txnInfermentText;
	}
	
	
	/**
     * TODO
     *
     * @param industryCodeId
     * @return
     */
	 @Override
	 @Transactional("stgTransactionManager")
    public List<IndustryCode> retreiveIndustryCodeList(Long industryCodeId){
	     LOGGER.info("entering ControlWordsServiceImpl | retreiveIndustryCodeList");
	     return stagingDAO.retreiveIndustryCodeList(industryCodeId);
    }
	
	
	
	/**
     * The method will retrive the Industry Code types based on the codeTableId and will return the
     * IndustryCodeInferment entity.
     * <p>
     * 
     * @param codeTableId
     * @param languageCode
     * @return List<IndustryCodeInferment>
     */
    @Override
    @Transactional("stgTransactionManager")
    public List<IndustryCodeInferment> retrieveIndustryCodeTypeAndDesc(Integer codeTableId, Long languageCode) {
        LOGGER.info("entering ControlWordsServiceImpl | retrieveIndustryCodeTypeAndDesc");
        return stagingDAO.retrieveIndustryCodeTypeAndDesc(codeTableId, languageCode);

    }
    
    
    
    @Override
    @Transactional("stgTransactionManager")
    public List<IndustryCodeInferment> retrieveLanguageCode() {
        LOGGER.info("entering ControlWordsServiceImpl | retrieveLanguageCode");
        return stagingDAO.retrieveLanguageCode();

    }
    
    
    @Override
    @Transactional("stgTransactionManager")
    public List<IndustryCode> retrieveIndustryCodeDescription(Long industryCodeTypeCode) {
        LOGGER.info("entering ControlWordsServiceImpl | retrieveIndustryCodeDescription");
        return stagingDAO.retrieveIndustryCodeDescription(industryCodeTypeCode);
    }
    
    
    
    /**
    *
    * The method will count the records in the hierarchy search of industry
    * codes inferment on the search db. The search will be done on the flat db based on
    * the search criteria the user had provided.
    *
    * @param searchCriteriaVO
    * @return countResults
    */
   @Override
   @Transactional("stgTransactionManager")
   public Long countSearchIndustryCodesInferment(
           ControlWordsSearchVO industryCodesInfermentSearchCriteria) {
       LOGGER.info("entering ControlWordsServiceImpl | countSearchIndustryCodesInferment");
       return stagingDAO.countSearchIndustryCodesInferment(industryCodesInfermentSearchCriteria);
   }
   
   /**
   *
   * Performs a hierarchy search of Industry Codes on the search db.
   * <p>
   *
   * The search will be done on the flat db based on the search criteria the
   * user had provided.
   * <p>
   *
   * @param industryCodesSearchCriteria
   * @return list of IndustryCode
   */
  @Override
  @Transactional("stgTransactionManager")
  public List<IndustryCodeInferment> searchIndustryCodesInferment(ControlWordsSearchVO industryCodesInfermentSearchCriteria) {
      LOGGER.info("entering ControlWordsServiceImpl | searchIndustryCodesInferment");

      List<IndustryCodeInferment> indsCodesInfermentList = (List<IndustryCodeInferment>) stagingDAO
              .searchIndustryCodesInferment(industryCodesInfermentSearchCriteria);

      LOGGER.info("exiting ControlWordsServiceImpl | searchIndustryCodesInferment");
      return indsCodesInfermentList;
  }
  
  @Override
  @Transactional("stgTransactionManager")
  public IndustryCodeInferment industryCodeInfermentSearchView(Long infermentText){
      
      LOGGER.info("entering ControlWordsServiceImpl | industryCodeInfermentSearchView");
      
      IndustryCodeInferment indsCodesInfermentView = (IndustryCodeInferment) stagingDAO
      .industryCodeInfermentSearchView(infermentText);
      
      LOGGER.info("exiting ControlWordsServiceImpl | industryCodeInfermentSearchView");
      return indsCodesInfermentView;
      
  }
  
  /**
	 * 
	 * The method will validate the InfermentText for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param infermentTextId
	 * @return
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Boolean lockInfermentText(Long infermentTextId) {
		LOGGER.info("entering ControlWordsServiceImpl | lockInfermentText");
		int count = transactionalDAO.countInfermentText(infermentTextId);
		return count == 0 ? false : true;
	}
	
	/**
	 * The method will persist the existing Inferment Text data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param infermentText
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long updateLegalFormInferment(InfermentText infermentText) {
		LOGGER.info("entering ControlWordsServiceImpl | updateLegalFormInferment");
		LOGGER.info("infermentText " + infermentText);
		// update the InfermentText entity
		if (infermentText.getInfermentTextId() == -1L) {
			Long infermentTextId = transactionalDAO.retrieveMaxInfermentTextId();
			infermentText.setInfermentTextId(infermentTextId);
			if(null!= infermentText.getLegalFormInferments()) {
				List<LegalFormInferment> legalFormInferments = new ArrayList<LegalFormInferment>();
				for (LegalFormInferment currLegal : infermentText
						.getLegalFormInferments()) {
					currLegal.setInfermentTextId(infermentTextId);
					legalFormInferments.add(currLegal);
				}
				infermentText.setLegalFormInferments(legalFormInferments);
			} else if (null!= infermentText.getIndustryCodeInferment()) {
				List<IndustryCodeInferment> indsCdInferments = new ArrayList<IndustryCodeInferment>();
				for (IndustryCodeInferment currInds : infermentText.getIndustryCodeInferment()) {
					currInds.setInfermentTextId(infermentTextId);
					indsCdInferments.add(currInds);
				}
				infermentText.setIndustryCodeInferment(indsCdInferments);
			}
			List<InfermentTextCountryApplicability> countryApplicabilities = new ArrayList<InfermentTextCountryApplicability>();
			for (InfermentTextCountryApplicability country : infermentText.getCountryApplicabilities()) {
				country.setInfermentTextId(infermentTextId);
				country.setInfermentTextCountryApplicabilityId(transactionalDAO.retrieveMaxInfermentTextCountryApplicabilityId());
				countryApplicabilities.add(country);
			}
			infermentText.setCountryApplicabilities(countryApplicabilities);
			LOGGER.info("after updating infermentTextId : "
					+ infermentText);
		}
		
		InfermentText infermentTextReceiver = transactionalDAO
				.updateLegalFormInferment(infermentText);

		LOGGER.info("Inferment Text updated with Id : "
				+ infermentTextReceiver.getInfermentTextId());

		return infermentTextReceiver.getInfermentTextId();
	}
	/**
	 * The method will persist the existing infermentText data in the staging
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param infermentTextId
	 * @throws Exception 
	 */
	@Override
	@Transactional("stgTransactionManager")
	public Long saveApprovedInfermentText(Long infermentTextId) throws Exception {
		LOGGER.info("entering ControlWordsServiceImpl | saveApprovedInfermentText");
		LOGGER.info("infermentTextId " + infermentTextId);
		// update the codeValue entity
		InfermentText infermentText = transactionalDAO.retrieveInfermentTextByInfermentTextId(infermentTextId);
		InfermentText infermentTextReceiver = stagingDAO.saveApprovedInfermentText(infermentText);

		LOGGER.info("Inferment Text updated with Id : " + infermentTextReceiver.getInfermentTextId());

		return infermentTextReceiver.getInfermentTextId();
	}
	/**
	 * The method will delete the approved infermentText data in the transaction
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param infermentText
	 */
	@Override
	@Transactional("txnTransactionManager")
	public void removeApprovedInfermentText(Long infermentTextId) {
		LOGGER.info("entering ControlWordsServiceImpl | removeApprovedInfermentText");
		LOGGER.info("infermentTextId " + infermentTextId);
		// update the codeValue entity
		transactionalDAO.removeApprovedInfermentText(infermentTextId);
	}
	/**
	 * 
	 * The method will merge the Country applicability of Transaction DB and the
	 * Staging SoR. The return will be the merged list of countries.
	 * 
	 * @param stgCountries
	 * @param txnCountries
	 * @return mergeCountries
	 */
	private List<InfermentTextCountryApplicability> mergeCountries(
			List<InfermentTextCountryApplicability> stgCountries,
			List<InfermentTextCountryApplicability> txnCountries) {
		LOGGER.info("entering ControlWordsServiceImpl |mergeCountries || stg: "
				+ stgCountries + " txn : " + txnCountries);
		List<Long> txnCountryCodes = new ArrayList<Long>();
		List<Long> stgCountryCodes = new ArrayList<Long>();
		List<InfermentTextCountryApplicability> mergeCountries = new ArrayList<InfermentTextCountryApplicability>();
		if (stgCountries == null) {
			return txnCountries;
		}
		if (txnCountries != null) {
			for (InfermentTextCountryApplicability countryApplicability : txnCountries) {
				txnCountryCodes.add(countryApplicability.getInfermentTextCountryApplicabilityId());
			}

			for (InfermentTextCountryApplicability stgCountry : stgCountries) {
				if (!txnCountryCodes.contains(stgCountry.getInfermentTextCountryApplicabilityId())) {
					mergeCountries.add(stgCountry);
				}
			}
			for (InfermentTextCountryApplicability countryApplicability : stgCountries) {
				stgCountryCodes.add(countryApplicability.getInfermentTextCountryApplicabilityId());
			}
			for (InfermentTextCountryApplicability txnCountry : txnCountries) {
				if ((!stgCountryCodes.contains(txnCountry.getInfermentTextCountryApplicabilityId()))
						||txnCountry.getExpirationDate()!=null){
					mergeCountries.add(txnCountry);
				}
			}
			LOGGER.info("entering ControlWordsServiceImpl |mergeCountries || stg: "
					+ mergeCountries);
			return mergeCountries;
		} else {
			return stgCountries;
		}
	}
	/**
	 * The method will retrieve the InfermentText based on the Workflow Tracking Id.
	 * This method will be invoked from the Workflow Component and the search
	 * will be performed on the Transactional DB.
	 *
	 * @param trackingId
	 * @param InfermentText
	 */
	@Override
	@Transactional("txnTransactionManager")
	public InfermentText retreiveInfermentTextByDomainId(Long domainId) {
		LOGGER.info("entering ControlWordsServiceImpl | retreiveGeoUnitByDomainId");
		InfermentText infermentText = transactionalDAO
				.retrieveInfermentTextByInfermentTextId(domainId);
		LOGGER.info("Retrieved InfermentText :  " + infermentText.getInfermentTextId());
		return infermentText;
	}
	@Override
	@Transactional("txnTransactionManager")
	public Long updatePhoneAreaCode(PhoneAreaCode phoneAreaCode) {
		if(phoneAreaCode.getPhoneAreaCodeId() == 0L){
			phoneAreaCode.setPhoneAreaCodeId(transactionalDAO.retrieveMaxPhoneAreaCodeId());
			DnbUnusGlsy dnbUnusGlsy = new DnbUnusGlsy();
			dnbUnusGlsy.setEffvDt(phoneAreaCode.getEffvDt());
			dnbUnusGlsy.setDnbUnusGlsyTypCd(RefDataPropertiesConstants.DNB_UBUS_GLSY_TYPE_CODE_PHONE_AREA_CODE);
			dnbUnusGlsy.setAlwdWthOthWdIndc(false);
			dnbUnusGlsy.setStopPrcsRecIndc(false);
			dnbUnusGlsy.setCountryApplicability(null);
			dnbUnusGlsy.setTelecomAddress(null);
			dnbUnusGlsy.setDnbUnusAdr(null);
			dnbUnusGlsy.setDnbUnusIndNme(null);
			dnbUnusGlsy.setDnbUnusTxt(phoneAreaCode.getAreaCodeNumber());
			dnbUnusGlsy.setCreatedUser(phoneAreaCode.getCreatedUser());
			dnbUnusGlsy.setCreatedDate(phoneAreaCode.getCreatedDate());
			dnbUnusGlsy.setModifiedUser(phoneAreaCode.getModifiedUser());
			dnbUnusGlsy.setModifiedDate(phoneAreaCode.getModifiedDate());
			Long dnbUnusGlsyId=updateControlWord(dnbUnusGlsy);
			phoneAreaCode.setDnbUnusGlsyId(dnbUnusGlsyId);
		}	
		PhoneAreaCode updatedPhoneAreaCode = transactionalDAO.updatePhoneAreaCode(phoneAreaCode);	
		LOGGER.info("PhoneAreaCode added with Id : " + updatedPhoneAreaCode.getPhoneAreaCodeId());
		return updatedPhoneAreaCode.getPhoneAreaCodeId();
	}
	
	@Override
	@Transactional("stgTransactionManager")
	public PhoneAreaCode retrievePhoneAreaCodeById(Long phoneAreaCodeId, Boolean isStagingDB) {

		LOGGER.info("entering ControlWordsServiceImpl | retrievePhoneAreaCodeById");
		PhoneAreaCode phoneAreaCode = null;
		if(isStagingDB){
			phoneAreaCode = stagingDAO.retrievePhoneAreaCodeById(phoneAreaCodeId);
		}else{
			phoneAreaCode = transactionalDAO.retrievePhoneAreaCodeById(phoneAreaCodeId);
		}
		LOGGER.info("PhoneAreaCode : " + phoneAreaCode);
		return phoneAreaCode;
	}
	
	@Override
	@Transactional("stgTransactionManager")
	public Long saveApprovedPhoneAreaCode(Long domainId) {
		LOGGER.info("entering ControlWordsServiceImpl | saveApprovedPhoneAreaCode");
		PhoneAreaCode phoneAreaCode = transactionalDAO.retrievePhoneAreaCodeById(domainId);
	
		if(phoneAreaCode.getDnbUnusGlsyId() !=null ){
		DnbUnusGlsy dnbUnusGlsy = transactionalDAO.retrieveControlWordById(phoneAreaCode.getDnbUnusGlsyId());
		
		if(dnbUnusGlsy!=null){
			dnbUnusGlsy.setCountryApplicability(null);
			dnbUnusGlsy.setDnbUnusAdr(null);
			dnbUnusGlsy.setDnbUnusIndNme(null);
			dnbUnusGlsy.setPhoneAreaCode(null);
			dnbUnusGlsy.setTelecomAddress(null);
			dnbUnusGlsy.setDnbUnusTxt(phoneAreaCode.getAreaCodeNumber());
		stagingDAO.updateControlWord(dnbUnusGlsy);
		}
		}				
		stagingDAO.updatePhoneAreaCode(phoneAreaCode);
		return phoneAreaCode.getPhoneAreaCodeId();
	}
	
	@Override
	@Transactional("txnTransactionManager")
	public void removeApprovedPhoneAreaCode(Long domainId) {
		transactionalDAO.removeApprovedPhoneAreaCode(domainId);
	}
	
	public List<String> retrieveAreaCodeInfo(){
		return stagingDAO.retrieveAreaCodeInfo();
	}
	
	@Override
	public Boolean lockPhoneAreaCodeForEdit(Long phoneAreaCodeId) {
		LOGGER.info("entering ControlWordsServiceImpl | lockPhoneAreaCodeForEdit");
		int count = transactionalDAO.countPhoneAreaCode(phoneAreaCodeId);
		return count == 0 ? false : true;
	}
	private void setStatusString(List<DnbUnusGlsy> searchResults) {
		for(DnbUnusGlsy dnbUnusGlsy: searchResults) {
			if((dnbUnusGlsy.getExpnDt()==null)||((dnbUnusGlsy.getExpnDt()!=null)
					&& (dnbUnusGlsy.getExpnDt().compareTo(new Date()) > 0))){
				dnbUnusGlsy.setStatus("Active");
			} else {
				dnbUnusGlsy.setStatus("Inactive");
			}
			LOGGER.info("infermentText Status : " + dnbUnusGlsy.getStatus());
		}
	}
	
	/**
	 * 
	 * The method to count the search results of control words
	 *
	 * @param controlWordsSearchVO
	 * @return
	 */
	@Override
	public Long countSearchControlWords(ControlWordsSearchVO controlWordsSearchVO) {
		LOGGER.info("entering CtrlWrdsStagingDAOImpl | searchByOffensiveWord");
		return stagingDAO.countSearchControlWords(controlWordsSearchVO);
	}

}
