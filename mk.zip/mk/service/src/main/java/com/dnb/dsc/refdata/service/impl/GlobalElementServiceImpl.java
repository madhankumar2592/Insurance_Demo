package com.dnb.dsc.refdata.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.PersistenceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GlobalElement;
import com.dnb.dsc.refdata.core.entity.GlobalElementDetail;
import com.dnb.dsc.refdata.core.entity.GlobalElementHistory;
import com.dnb.dsc.refdata.core.entity.GloblalElementCrossWalk;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.AddCrosswalkVO;
import com.dnb.dsc.refdata.core.vo.AddGlobalElementVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementCrosswalkSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementDetailVO;
import com.dnb.dsc.refdata.core.vo.GlobalElementSearchVOBkp;
import com.dnb.dsc.refdata.core.vo.GlobalElementVO;
import com.dnb.dsc.refdata.core.vo.ReferenceDataExceptionVO;
import com.dnb.dsc.refdata.dao.GlobalElementStagingDAO;
import com.dnb.dsc.refdata.service.GlobalElementService;


@Service("GlobalElementService")
public class GlobalElementServiceImpl implements GlobalElementService{
	
	@Autowired
	private GlobalElementStagingDAO stagingDAO;

	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GlobalElementStagingDAO.class);


	
	@Override
	public Long countSearchTopicsBkp(
			GlobalElementSearchVOBkp globalElementSearchVO) {
		LOGGER.info("entering GeographyServiceImpl | countSearchGeographies");
		return stagingDAO.countSearchTopicsBkp(globalElementSearchVO);
	}


	@Override
	public List<GlobalElement> searchByTopicsBkp(
			GlobalElementSearchVOBkp globalElementSearchVO) {
		LOGGER.info("entering GeographyServiceImpl | searchByTopics");
		return stagingDAO.searchByTopicsBkp(globalElementSearchVO);
	}


	@Override
	public List<GlobalElementVO> retrieveHints() {
		LOGGER.info("entering GlobalElementServiceImpl | retrieveHints");
		return stagingDAO.retrieveHints();
	}


	@Override
	public List<GlobalElementVO> retrieveHintsDesc() {
		LOGGER.info("entering GlobalElementServiceImpl | retrieveHints");
		return stagingDAO.retrieveHintsDesc();
	}


	@SuppressWarnings("unused")
	@Override
	@Transactional("stgTransactionManager")
	public Long insertGlobalElement(AddGlobalElementVO addGlobalElementVO) {
		
		
		String longDesc = null;
		for (GlobalElementDetailVO globalElementDetail : addGlobalElementVO.getGlobalElementDetailVO()) {
			longDesc = globalElementDetail.getLongDescription();
		}
		
		GlobalElement globalElement = new GlobalElement();
		Long globalElementId = null;
		
			globalElementId = stagingDAO.retrieveMaxGlobalElementId();
			LOGGER.info("New globalElementId " + globalElementId);
			globalElement.setGlobalElementId(globalElementId);
			globalElement.setGlobalElementTypeCode(addGlobalElementVO.getGlobalElementTypeCode());
			globalElement.setGlobalElementTopicCategoryCode(addGlobalElementVO.getGlobalElementTopicCategoryCode());
			globalElement.setGlobalElementName(addGlobalElementVO.getGlobalElementName());
			globalElement.setEffectiveDate(addGlobalElementVO.getEffectiveDate());
			globalElement.setExpirationDate(addGlobalElementVO.getExpirationDate());
			globalElement.setGlobalElementComment(addGlobalElementVO.getGlobalElementComment());			
			globalElement.setCreatedDate(addGlobalElementVO.getCreatedDate());
			globalElement.setCreatedUser(addGlobalElementVO.getCreatedUser());
			globalElement.setModifiedDate(addGlobalElementVO.getModifiedDate());
			globalElement.setModifiedUser(addGlobalElementVO.getModifiedUser());
			GlobalElement newGlobalElement = new GlobalElement();
			LOGGER.info("New product" + globalElement);			
			newGlobalElement = stagingDAO.insertGlobalElement(globalElement);
			// update Global Element details
			Long busEleNameMetaDataCode = 29655L;
			Long shortDescMetaDataCode = 29656L;
			Long longDescMetaDataCode = 29657L;
			//Update Business Element Name
			updateGlobalElementDetails(addGlobalElementVO, globalElementId,busEleNameMetaDataCode);
			//Update Short Description
			updateGlobalElementDetails(addGlobalElementVO, globalElementId,shortDescMetaDataCode);
			//Update Long Description
			if(longDesc != null && !longDesc.isEmpty()){
				updateGlobalElementDetails(addGlobalElementVO, globalElementId,longDescMetaDataCode);
			}
			//Update Global Element History 
			//updateGlobalElementHistory(addGlobalElementVO, globalElementId, metaDataCode);
			//Update Business Element Name
			updateGlobalElementHistory(addGlobalElementVO, globalElementId,busEleNameMetaDataCode);
			//Update Short Description
			updateGlobalElementHistory(addGlobalElementVO, globalElementId,shortDescMetaDataCode);
			//Update Long Description
			if(longDesc != null && !longDesc.isEmpty()){
				updateGlobalElementHistory(addGlobalElementVO, globalElementId,longDescMetaDataCode);
			}
		
		return globalElementId;
	}
	
	/**
	 * @param addNewProductsVO
	 * @param prod_id
	 */
	@SuppressWarnings("unused")
	private void updateGlobalElementDetails(AddGlobalElementVO addGlobalElementVO,
			Long globalElementId,Long metaDataCode) {
		GlobalElementDetail newGlblEleDetail = new GlobalElementDetail();
		for (GlobalElementDetailVO globalElementDetail : addGlobalElementVO.getGlobalElementDetailVO()) {
			if(metaDataCode == 29655){
				globalElementDetail.setGlobalElementMetadataValue(addGlobalElementVO.getGlobalElementName());
			}
			if(metaDataCode == 29657){
				globalElementDetail.setGlobalElementMetadataValue(globalElementDetail.getLongDescription());
			}
			if(metaDataCode == 29656){
				globalElementDetail.setGlobalElementMetadataValue(globalElementDetail.getShortDescription());
			}
			
			
			if (metaDataCode != null) {
					
				Long globalElementDetailId = null;
				if (globalElementId != null) {
					GlobalElementDetail glblEleDetail = new GlobalElementDetail();
					
						globalElementDetailId = stagingDAO
								.retrieveMaxGlobalElementDetailId();
						
						
						glblEleDetail.setGlobalElementDetailId(globalElementDetailId);
						glblEleDetail.setGlobalElementId(globalElementId);
						glblEleDetail.setGlobalElementMetadataCode(metaDataCode);
						glblEleDetail.setGlobalElementMetadataValue(globalElementDetail.getGlobalElementMetadataValue());
						glblEleDetail.setGlobalElementMetadataLangCode(39L);
						glblEleDetail.setGlobalElementMetadataTypeCode(globalElementDetail.getGlobalElementMetadataTypeCode());
						glblEleDetail.setGlobalElementDetailComment(addGlobalElementVO.getGlobalElementDetailComment());
						
						glblEleDetail.setCreatedDate(addGlobalElementVO
								.getCreatedDate());
						glblEleDetail.setCreatedUser(addGlobalElementVO
								.getCreatedUser());
						glblEleDetail.setModifiedDate(addGlobalElementVO
								.getModifiedDate());
						glblEleDetail.setModifiedUser(addGlobalElementVO
								.getModifiedUser());
						LOGGER.info("New Global Element details" + glblEleDetail);
						newGlblEleDetail = stagingDAO
								.updateGlobalElementDetails(glblEleDetail);
				}				
			}
		}
	}
	
	
	/**
	 * @param addNewProductsVO
	 * @param prod_id
	 */
	@SuppressWarnings("unused")
	private void updateGlobalElementHistory(AddGlobalElementVO addGlobalElementVO,
			Long globalElementId,Long metaDataCode) {
		Date currentDate = new Date();
		GlobalElementHistory glblEleHistory = new GlobalElementHistory();
		
		GlobalElementHistory newGlblEleHistory = new GlobalElementHistory();
		
			for (GlobalElementDetailVO globalElementDetail : addGlobalElementVO.getGlobalElementDetailVO()) {
			
			if(metaDataCode == 29655){
				glblEleHistory.setGlobalElementMetadataValue(addGlobalElementVO.getGlobalElementName());
			}
			if(metaDataCode == 29657){
				glblEleHistory.setGlobalElementMetadataValue(globalElementDetail.getLongDescription());
			}
			if(metaDataCode == 29656){
				glblEleHistory.setGlobalElementMetadataValue(globalElementDetail.getShortDescription());
			}
			
			
			if (metaDataCode != null) {
					
				Long globalElementHistoryId = null;
				if (globalElementId != null) {
										
					globalElementHistoryId = stagingDAO
								.retrieveMaxGlobalElementHistoryId();
						
						
					glblEleHistory.setGlobalElementHistoryId(globalElementHistoryId);
					glblEleHistory.setGlobalElementId(globalElementId);
					glblEleHistory.setGlobalElementTypeCode(addGlobalElementVO.getGlobalElementTypeCode());
					glblEleHistory.setGlobalElementTopicCategoryCode(addGlobalElementVO.getGlobalElementTopicCategoryCode());
					glblEleHistory.setGlobalElementMetadataCode(metaDataCode);
					//glblEleHistory.setGlobalElementMetadataValue(globalElementHistory.getGlobalElementMetadataValue());
					glblEleHistory.setGlobalElementMetadataTypeCode(globalElementDetail.getGlobalElementMetadataTypeCode());
					glblEleHistory.setGlobalElementMetadataLangCode(39L);
					glblEleHistory.setGlobalElementName(addGlobalElementVO.getGlobalElementName());
					glblEleHistory.setEffectiveDate(addGlobalElementVO.getEffectiveDate());
					glblEleHistory.setExpirationDate(addGlobalElementVO.getExpirationDate());
					glblEleHistory.setGlobalElementComment(addGlobalElementVO.getGlobalElementComment());	
					glblEleHistory.setGlobalElementDetailComment(addGlobalElementVO.getGlobalElementDetailComment());
					//glblEleHistory.setGlobalElementCWComment(globalElementHistory.getGlobalElementCWComment());
					glblEleHistory.setGlobalElementHistoryDate(currentDate);
						
					glblEleHistory.setCreatedDate(addGlobalElementVO
								.getCreatedDate());
					glblEleHistory.setCreatedUser(addGlobalElementVO
								.getCreatedUser());
					glblEleHistory.setModifiedDate(addGlobalElementVO
								.getModifiedDate());
					glblEleHistory.setModifiedUser(addGlobalElementVO
								.getModifiedUser());
						LOGGER.info("New Global Element details" + glblEleHistory);
						newGlblEleHistory = stagingDAO
								.updateGlobalElementHistory(glblEleHistory);
				}				
			}
		}
	}


	@Override
	public AddGlobalElementVO retrieveGlobalElement(
			AddGlobalElementVO addGlobalElementVO) {
		LOGGER.info("entering GlobalElementServiceImpl | retrieveGlobalElement");
		
		AddGlobalElementVO globalElementDtl = new AddGlobalElementVO();
		
		String query ="Select GLBL_ELE_ID,GLBL_ELE_TYP_CD,GLBL_ELE_TOPC_CATG_CD,GLBL_ELE_NME,GLBL_ELE_EFFV_DT,GLBL_ELE_EXPN_DT,GLBL_ELE_CMNT from GLBL_ELE_RLS_2 where GLBL_ELE_ID="+addGlobalElementVO.getGlobalElementId()+"";
		
		List<GlobalElement> globalElementBkp = stagingDAO.retrieveGlobalElement(query);
		
		for(GlobalElement glblEle : globalElementBkp)
		{
			globalElementDtl.setGlobalElementId(glblEle.getGlobalElementId());
			globalElementDtl.setGlobalElementTypeCode(glblEle.getGlobalElementTypeCode());
			globalElementDtl.setGlobalElementTopicCategoryCode(glblEle.getGlobalElementTopicCategoryCode());
			globalElementDtl.setGlobalElementName(glblEle.getGlobalElementName());
			globalElementDtl.setEffectiveDate(glblEle.getEffectiveDate());
			globalElementDtl.setExpirationDate(glblEle.getExpirationDate());			
			globalElementDtl.setGlobalElementComment(glblEle.getGlobalElementComment());
		}
		
		 
		String detailQuery = "SELECT GLBL_ELE_DTL_ID,GLBL_ELE_ID,GLBL_ELE_MTDT_CD,GLBL_ELE_MTDT_VAL,GLBL_ELE_MTDT_DATA_TYP_CD,GLBL_ELE_MTDT_LANG_CD,GLBL_ELE_DTL_CMNT from glbl_ele_dtl_rls_2 where GLBL_ELE_ID="+addGlobalElementVO.getGlobalElementId()+"";
					
		List<GlobalElementDetailVO> glblElemntDetail = stagingDAO.retrieveGlobalElementDetail(detailQuery);
		
		for(GlobalElementDetailVO elemntDtl : glblElemntDetail ){
			
			if(elemntDtl.getGlobalElementMetadataCode() == 29657){
				globalElementDtl.setLongDescription(elemntDtl.getGlobalElementMetadataValue());
			}
			else if(elemntDtl.getGlobalElementMetadataCode() == 29656){
				globalElementDtl.setShortDescription(elemntDtl.getGlobalElementMetadataValue());
			}
			else if(elemntDtl.getGlobalElementMetadataLangCode() != null){
				globalElementDtl.setGlobalElementMetadataLangCode(elemntDtl.getGlobalElementMetadataLangCode());
			}
			
				globalElementDtl.setGlobalElementDetailComment(elemntDtl.getGlobalElementDetailComment());
			
		}
		
		globalElementDtl.setGlobalElementDetailVO(glblElemntDetail);
		
		return globalElementDtl;
	}

//Working on crosswalk
	@Override
	public AddCrosswalkVO retrieveGlobalElementCrosswalk(
			AddCrosswalkVO addGlobalElementVO) {
		LOGGER.info("entering GlobalElementServiceImpl | retrieveGlobalElementCrosswalk");
		AddCrosswalkVO addCrosswalkVOResult = new AddCrosswalkVO();
		String query = "SELECT * FROM GLBL_ELE_CROSS_WALK WHERE GLBL_ELE_ID = (SELECT GLBL_ELE_ID FROM GLBL_ELE_CROSS_WALK WHERE GLBL_ELE_CW_ID="+addGlobalElementVO.getGlobalElementCrosswalkId()+")";
		List<GloblalElementCrossWalk> globalElementCrosswalkList = stagingDAO.retrieveGlobalElementCrosswalk(query);
		addCrosswalkVOResult.setGlobalElementPlatformCode(globalElementCrosswalkList.get(0).getGlobalElementPlatformCode());
		addCrosswalkVOResult.setGloblalElementCrossWalk(globalElementCrosswalkList);
		LOGGER.info("exiting GlobalElementServiceImpl | retrieveGlobalElementCrosswalk");
		return addCrosswalkVOResult;
	}
	
	@Override
	@Transactional("stgTransactionManager")
	public Long editGlobalElement(AddGlobalElementVO addGlobalElementVO) {
		
		//Long globalELement_id = addGlobalElementVO.getGlobalElementId();		
		//Long elemntID = updateGlobalElement(addGlobalElementVO);
		
		GlobalElement globalElement = new GlobalElement();
		
		GlobalElement existing_element = new GlobalElement();
		
		Long elemnt_id = null;
		
		elemnt_id = stagingDAO
				.retreiveData("SELECT GLBL_ELE_ID FROM GLBL_ELE_RLS_2 WHERE GLBL_ELE_ID ="+addGlobalElementVO.getGlobalElementId());
		LOGGER.info("Existing element id" + elemnt_id);
		if(elemnt_id != null){
		//GlobalElement_Bkp existing_element = stagingDAO.findElementExistingId(elemnt_id);
		existing_element.setGlobalElementId(addGlobalElementVO.getGlobalElementId());
		existing_element.setGlobalElementTypeCode(addGlobalElementVO.getGlobalElementTypeCode());
		existing_element.setGlobalElementTopicCategoryCode(addGlobalElementVO.getGlobalElementTopicCategoryCode());
		existing_element.setGlobalElementName(addGlobalElementVO.getGlobalElementName());
		existing_element.setEffectiveDate(addGlobalElementVO.getEffectiveDate());
		existing_element.setExpirationDate(addGlobalElementVO.getExpirationDate());
		existing_element.setGlobalElementComment(addGlobalElementVO.getGlobalElementComment());
		existing_element.setCreatedDate(addGlobalElementVO.getCreatedDate());
		existing_element.setCreatedUser(addGlobalElementVO.getCreatedUser());
		existing_element.setModifiedDate(addGlobalElementVO.getModifiedDate());
		existing_element.setModifiedUser(addGlobalElementVO.getModifiedUser());
		
		LOGGER.info("Existing product" + existing_element);
		globalElement = stagingDAO.insertGlobalElement(existing_element);
		}
		
		String longDesc = null;
		longDesc = addGlobalElementVO.getLongDescription();
		
		Long busEleNameMetaDataCode = 29655L;
		Long shortDescMetaDataCode = 29656L;
		Long longDescMetaDataCode = 29657L;
		//Update Business Element Name
		updateEditGlobalElementDetails(addGlobalElementVO, elemnt_id,busEleNameMetaDataCode);
		//Update Short Description
		updateEditGlobalElementDetails(addGlobalElementVO, elemnt_id,shortDescMetaDataCode);
		//Update Long Description
		if(longDesc != null && !longDesc.isEmpty()){
			updateEditGlobalElementDetails(addGlobalElementVO, elemnt_id,longDescMetaDataCode);
		}
		//Update Global Element History 
		//Update Business Element Name
		updateEditGlobalElementHistory(addGlobalElementVO, elemnt_id,busEleNameMetaDataCode);
		//Update Short Description
		updateEditGlobalElementHistory(addGlobalElementVO, elemnt_id,shortDescMetaDataCode);
		//Update Long Description
		if(longDesc != null && !longDesc.isEmpty()){
			updateEditGlobalElementHistory(addGlobalElementVO, elemnt_id,longDescMetaDataCode);
		}

		return globalElement.getGlobalElementId();
	}

	/**
	 * @param addNewProductsVO
	 * @param prod_id
	 */
	@SuppressWarnings("unused")
	@Transactional("stgTransactionManager")
	private void updateEditGlobalElementDetails(AddGlobalElementVO addGlobalElementVO,
			Long globalElementId,Long metaDataCode) {
		GlobalElementDetail newGlblEleDetail = new GlobalElementDetail();		

		GlobalElementDetail glblEleDetail = new GlobalElementDetail();	
	
							
			if(metaDataCode == 29655){
				glblEleDetail.setGlobalElementMetadataValue(addGlobalElementVO.getGlobalElementName());
			}
			if(metaDataCode == 29657){
				glblEleDetail.setGlobalElementMetadataValue(addGlobalElementVO.getLongDescription());
			}
			if(metaDataCode == 29656){
				glblEleDetail.setGlobalElementMetadataValue(addGlobalElementVO.getShortDescription());
			}
			
			if (metaDataCode != null) {
		
				Long count = stagingDAO.retreiveData("Select count(GLBL_ELE_DTL_ID) from GLBL_ELE_DTL_RLS_2 where GLBL_ELE_ID ="+addGlobalElementVO.getGlobalElementId()+" and GLBL_ELE_MTDT_CD="+metaDataCode+"");
				
				if(count > 0){
				
		Long globalElementDetailId = stagingDAO.retreiveData("Select GLBL_ELE_DTL_ID from GLBL_ELE_DTL_RLS_2 where GLBL_ELE_ID ="+addGlobalElementVO.getGlobalElementId()+" and GLBL_ELE_MTDT_CD="+metaDataCode+"");
		
					
			if (globalElementDetailId != null && globalElementDetailId != 0L) {
													
						
						glblEleDetail.setGlobalElementDetailId(globalElementDetailId);
						glblEleDetail.setGlobalElementId(globalElementId);
						glblEleDetail.setGlobalElementMetadataCode(metaDataCode);
						//glblEleDetail.setGlobalElementMetadataValue(globalElementDetail.getGlobalElementMetadataValue());
						glblEleDetail.setGlobalElementMetadataLangCode(39L);						
						glblEleDetail.setGlobalElementDetailComment(addGlobalElementVO.getGlobalElementDetailComment());
						glblEleDetail.setCreatedDate(addGlobalElementVO.getCreatedDate());
						glblEleDetail.setCreatedUser(addGlobalElementVO.getCreatedUser());
						glblEleDetail.setModifiedDate(addGlobalElementVO.getModifiedDate());
						glblEleDetail.setModifiedUser(addGlobalElementVO.getModifiedUser());
						//glblEleDetail.setGlobalElementMetadataTypeCode(globalElementDetail.getGlobalElementMetadataTypeCode());
						
						LOGGER.info("Update Global Element details" + glblEleDetail);
						newGlblEleDetail = stagingDAO
								.updateGlobalElementDetails(glblEleDetail);
				}
				}
			
			else {
				Long glbl_elemnt_dtl_id = stagingDAO.retrieveMaxGlobalElementDetailId();
				glblEleDetail.setGlobalElementDetailId(glbl_elemnt_dtl_id);
				glblEleDetail.setGlobalElementId(globalElementId);
				glblEleDetail.setGlobalElementMetadataCode(metaDataCode);
				//glblEleDetail.setGlobalElementMetadataValue(globalElementDetail.getGlobalElementMetadataValue());
				glblEleDetail.setGlobalElementMetadataLangCode(39L);						
				glblEleDetail.setGlobalElementDetailComment(addGlobalElementVO.getGlobalElementDetailComment());
				glblEleDetail.setCreatedDate(addGlobalElementVO.getCreatedDate());
				glblEleDetail.setCreatedUser(addGlobalElementVO.getCreatedUser());
				glblEleDetail.setModifiedDate(addGlobalElementVO.getModifiedDate());
				glblEleDetail.setModifiedUser(addGlobalElementVO.getModifiedUser());
				//glblEleDetail.setGlobalElementMetadataTypeCode(globalElementDetail.getGlobalElementMetadataTypeCode());
				
				LOGGER.info("Update Global Element details" + glblEleDetail);
				newGlblEleDetail = stagingDAO
						.updateGlobalElementDetails(glblEleDetail);
				
			}
			
			}
		}
	
	/**
	 * @param addNewProductsVO
	 * @param prod_id
	 */
	@SuppressWarnings("unused")
	@Transactional("stgTransactionManager")
	private void updateEditGlobalElementHistory(AddGlobalElementVO addGlobalElementVO,
			Long globalElementId,Long metaDataCode) {
		Date currentDate = new Date();
		
		GlobalElementHistory newGlblEleHistory = new GlobalElementHistory();
		
		GlobalElementHistory glblEleHistory = new GlobalElementHistory();
								
			if(metaDataCode == 29655){
				glblEleHistory.setGlobalElementMetadataValue(addGlobalElementVO.getGlobalElementName());
			}
			if(metaDataCode == 29657){
				glblEleHistory.setGlobalElementMetadataValue(addGlobalElementVO.getLongDescription());
			}
			if(metaDataCode == 29656){
				glblEleHistory.setGlobalElementMetadataValue(addGlobalElementVO.getShortDescription());
			}			
			
			if (metaDataCode != null) {
				
				Long count_hist_id = stagingDAO.retreiveData("Select count(GLBL_ELE_HIST_ID) from GLBL_ELE_HIST where GLBL_ELE_ID ="+addGlobalElementVO.getGlobalElementId()+" and GLBL_ELE_MTDT_CD="+metaDataCode+""); ;
				
				if(count_hist_id > 0){
					
				Long globalElementHistoryId = stagingDAO.retreiveData("Select GLBL_ELE_HIST_ID from GLBL_ELE_HIST where GLBL_ELE_ID ="+addGlobalElementVO.getGlobalElementId()+" and GLBL_ELE_MTDT_CD="+metaDataCode+"");
				if (globalElementHistoryId != null && globalElementHistoryId != 0L) {
																	
						
					glblEleHistory.setGlobalElementHistoryId(globalElementHistoryId);
					glblEleHistory.setGlobalElementId(globalElementId);
					glblEleHistory.setGlobalElementTypeCode(addGlobalElementVO.getGlobalElementTypeCode());
					glblEleHistory.setGlobalElementTopicCategoryCode(addGlobalElementVO.getGlobalElementTopicCategoryCode());
					glblEleHistory.setGlobalElementMetadataCode(metaDataCode);
					//glblEleHistory.setGlobalElementMetadataValue(globalElementHistory.getGlobalElementMetadataValue());
					//glblEleHistory.setGlobalElementMetadataTypeCode(globalElementDetail.getGlobalElementMetadataTypeCode());
					glblEleHistory.setGlobalElementMetadataLangCode(39L);
					glblEleHistory.setGlobalElementName(addGlobalElementVO.getGlobalElementName());
					glblEleHistory.setEffectiveDate(addGlobalElementVO.getEffectiveDate());
					glblEleHistory.setExpirationDate(addGlobalElementVO.getExpirationDate());
					glblEleHistory.setGlobalElementComment(addGlobalElementVO.getGlobalElementComment());	
					glblEleHistory.setGlobalElementDetailComment(addGlobalElementVO.getGlobalElementDetailComment());
					//glblEleHistory.setGlobalElementCWComment(globalElementHistory.getGlobalElementCWComment());
					glblEleHistory.setGlobalElementHistoryDate(currentDate);	
					glblEleHistory.setCreatedDate(addGlobalElementVO.getCreatedDate());
					glblEleHistory.setCreatedUser(addGlobalElementVO.getCreatedUser());
					glblEleHistory.setModifiedDate(addGlobalElementVO.getModifiedDate());
					glblEleHistory.setModifiedUser(addGlobalElementVO.getModifiedUser());
						LOGGER.info("Update Global Element details" + glblEleHistory);
						newGlblEleHistory = stagingDAO
								.updateGlobalElementHistory(glblEleHistory);
				}
				}else{
					Long new_globalElementHistoryId = stagingDAO.retrieveMaxGlobalElementHistoryId();
					glblEleHistory.setGlobalElementHistoryId(new_globalElementHistoryId);
					glblEleHistory.setGlobalElementId(globalElementId);
					glblEleHistory.setGlobalElementTypeCode(addGlobalElementVO.getGlobalElementTypeCode());
					glblEleHistory.setGlobalElementTopicCategoryCode(addGlobalElementVO.getGlobalElementTopicCategoryCode());
					glblEleHistory.setGlobalElementMetadataCode(metaDataCode);
					//glblEleHistory.setGlobalElementMetadataValue(globalElementHistory.getGlobalElementMetadataValue());
					//glblEleHistory.setGlobalElementMetadataTypeCode(globalElementDetail.getGlobalElementMetadataTypeCode());
					glblEleHistory.setGlobalElementMetadataLangCode(39L);
					glblEleHistory.setGlobalElementName(addGlobalElementVO.getGlobalElementName());
					glblEleHistory.setEffectiveDate(addGlobalElementVO.getEffectiveDate());
					glblEleHistory.setExpirationDate(addGlobalElementVO.getExpirationDate());
					glblEleHistory.setGlobalElementComment(addGlobalElementVO.getGlobalElementComment());	
					glblEleHistory.setGlobalElementDetailComment(addGlobalElementVO.getGlobalElementDetailComment());
					//glblEleHistory.setGlobalElementCWComment(globalElementHistory.getGlobalElementCWComment());
					glblEleHistory.setGlobalElementHistoryDate(currentDate);	
					glblEleHistory.setCreatedDate(addGlobalElementVO.getCreatedDate());
					glblEleHistory.setCreatedUser(addGlobalElementVO.getCreatedUser());
					glblEleHistory.setModifiedDate(addGlobalElementVO.getModifiedDate());
					glblEleHistory.setModifiedUser(addGlobalElementVO.getModifiedUser());
						LOGGER.info("Update Global Element details" + glblEleHistory);
						newGlblEleHistory = stagingDAO
								.updateGlobalElementHistory(glblEleHistory);
				}				
			}		
	}


	@Override
	@Transactional("stgTransactionManager")
	public Boolean isDuplicateElementName(String glblEleName) {
		Boolean nameExists = false;
		Long count = stagingDAO.retreiveData("Select count(GLBL_ELE_NME) from GLBL_ELE_RLS_2 where GLBL_ELE_NME='"+glblEleName+"'");
		LOGGER.info("In GlobalElementServiceImpl |isDuplicateElementName| nameCount" + count);
		if(count>0){
			nameExists = true;
		}
		LOGGER.info("Exiting GlobalElementServiceImpl |isDuplicateElementName| nameExists" +nameExists);
		return nameExists;
	}
	


	@Override
	public Long checkGlblEleCrswlkId(GloblalElementCrossWalk crosswalk) {
		LOGGER.info("entering GlobalElementServiceImpl | checkGlblEleCrswlkId");
		
		Long count = stagingDAO.retreiveData("Select count(GLBL_ELE_ID) from GLBL_ELE_CROSS_WALK where GLBL_ELE_ID="+crosswalk.getGlobalElementId()+"");
		return count;
	}

	
	public String retrieveGlobalElement(Long elementID) {
		String elementName = null;
		Long count = stagingDAO.retreiveData("Select count(GLBL_ELE_ID) from GLBL_ELE_RLS_2 where GLBL_ELE_ID="+elementID+"");
		LOGGER.info("In GlobalElementServiceImpl |retrieveGlobalElement| IDCount" + count);
		if(count>0){
			elementName = stagingDAO.retreiveEleNme("Select GLBL_ELE_NME from GLBL_ELE_RLS_2 where GLBL_ELE_ID="+elementID+"");
		}
		else{
			elementName ="false";
		}
		LOGGER.info("Exiting GlobalElementServiceImpl |elementName| nameExists" +elementName);
		return elementName;
	}


	@Override
	public List<AddCrosswalkVO> retrievePlatformDetails(
			Long globalElementPlatformCode) {
		
		LOGGER.info("In GlobalElementServiceImpl |retrievePlatformDetails");
		String query = "Select sa.cd_val_id as codeValueId,cvt.cd_val_desc as codeValueDescription from sys_appy sa, cd_val_txt cvt WHERE sa.dnb_sys_cd="+globalElementPlatformCode+" AND sa.cd_val_id=cvt.cd_val_id and cvt.lang_cd=39 AND sa.expn_dt IS NULL AND cvt.expn_dt IS NULL union select cvt.cd_val_id as codeValueId ,cvt.cd_val_desc as codeValueDescription from cd_val_txt  cvt where cvt.lang_cd=39 and cvt.cd_val_id in (select cd_val_id from cd_val where cd_tbl_id=726) and cvt.expn_dt is null";
		//String query2 = "select cvt.cd_val_id as codeValueId ,cvt.cd_val_desc as codeValueDescription from cd_val_txt  cvt where cvt.lang_cd=39 and cvt.cd_val_id in (select cd_val_id from cd_val where cd_tbl_id=726) and cvt.expn_dt is null";
		List<AddCrosswalkVO> addCrosswalkVOs= new ArrayList<AddCrosswalkVO>();
		List<SystemApplicability> result = stagingDAO.retrievePlatformDetails(query);
	
		for(SystemApplicability codeValue : result){
			AddCrosswalkVO addCrosswalkVO = new AddCrosswalkVO();
			addCrosswalkVO.setMetadataCode(codeValue.getCodeValueId());
			addCrosswalkVO.setMetadataValue(codeValue.getCodeValueDescription());	
			addCrosswalkVOs.add(addCrosswalkVO);
		}
		
		LOGGER.info("Exiting GlobalElementServiceImpl |retrievePlatformDetails");
		try{
			return addCrosswalkVOs;
			}catch(PersistenceException ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_PERSISTENCE, ex);
			}catch(Exception ex){
				throw new ReferenceDataExceptionVO(RefDataPropertiesConstants.ERROR_CODE_SYSTEM, ex);
			}
		
	}


	@Override
	@Transactional("stgTransactionManager")
	public Long addNewCrosswalk(AddCrosswalkVO addCrosswalkVO) {
		
		GloblalElementCrossWalk globlalElementCrossWalk = new GloblalElementCrossWalk();
		Long crosswalkId = null;		
		if(null!= addCrosswalkVO.getIsEdit() && addCrosswalkVO.getIsEdit().equals("isEdit")){
			//delete old records
			int deleteCount=stagingDAO.deleteCrosswalk(addCrosswalkVO);//"DELETE FROM SORUSR.GLBL_ELE_CROSS_WALK WHERE GLBL_ELE_ID='"+addCrosswalkVO.getGlobalElementId()+"'");
			LOGGER.info("Number of existing records deleted " + deleteCount);
		}
		for(GloblalElementCrossWalk cwlkEntered : addCrosswalkVO.getGloblalElementCrossWalk()){
			if(cwlkEntered.getGlobalElementMetadataCode() != null && cwlkEntered.getGlobalElementMetadataValue() != null && 
					cwlkEntered.getGlobalElementCrosswalkGrpNme() != null){
					crosswalkId = stagingDAO.retrieveMaxCrossWalkId();
					globlalElementCrossWalk.setGlobalElementCrosswalkId(crosswalkId);
					globlalElementCrossWalk.setGlobalElementId(addCrosswalkVO.getGlobalElementId());
					globlalElementCrossWalk.setGlobalElementMetadataCode(cwlkEntered.getGlobalElementMetadataCode());					
					globlalElementCrossWalk.setGlobalElementMetadataValue(cwlkEntered.getGlobalElementMetadataValue());
					globlalElementCrossWalk.setGlobalElementPlatformCode(addCrosswalkVO.getGlobalElementPlatformCode());
					globlalElementCrossWalk.setGlobalElementCrosswalkGrpNme(cwlkEntered.getGlobalElementCrosswalkGrpNme());
					globlalElementCrossWalk.setGlobalElementCrosswalkCommnet(null);
					globlalElementCrossWalk.setCreatedUser(addCrosswalkVO.getCreatedUser());
					globlalElementCrossWalk.setModifiedUser(addCrosswalkVO.getModifiedUser());
					globlalElementCrossWalk.setCreatedDate(addCrosswalkVO.getCreatedDate());
					globlalElementCrossWalk.setModifiedDate(addCrosswalkVO.getModifiedDate());
					stagingDAO.addNewCrosswalk(globlalElementCrossWalk);
			}
		}
		
		return crosswalkId;
	}


	
	@Override
	public List<GloblalElementCrossWalk> crosswalkSearch(
			GlobalElementCrosswalkSearchVOBkp globalElementSearchVO) {
		return stagingDAO.crosswalkSearch(globalElementSearchVO);
	}


	@Override
	@Transactional("stgTransactionManager")
	public List<CodeValue> retrieveSearchCrossWalkCodeType(
			Long crosswalkAppied) {
		LOGGER.info("entering IndustryCodesServiceImpl | retrieveCrossWalksForIndsCodeType");
		
		return stagingDAO
				.retrieveSearchCrossWalkCodeType(crosswalkAppied);
	}


	@Override
	public Long countCrosswalkSearch(
			GlobalElementCrosswalkSearchVOBkp globalElementCrosswalkSearchVOBkp) {
		LOGGER.info("entering GeographyServiceImpl | countSearchGeographies");
		return stagingDAO.countCrosswalkSearch(globalElementCrosswalkSearchVOBkp);
	}


	@Override
	public List<AddCrosswalkVO> retrieveEditPlatformDetails(
			Long globalElementPlatformCode, Long globalElementId) {
		
		LOGGER.info("In GlobalElementServiceImpl |retrieveEditPlatformDetails");
		
		AddCrosswalkVO addCrosswalkVO = new AddCrosswalkVO();
		
		String eleTypQuery="select distinct cw1.glbl_ele_mtdt_cd from glbl_ele_cross_walk cw, glbl_ele_cross_walk cw1,cd_val_txt cvt, sys_appy sa where " +
				"sa.dnb_sys_cd="+globalElementPlatformCode+" and cw.glbl_ele_id="+globalElementId+" and sa.cd_val_id=cw.glbl_ele_mtdt_cd and cvt.cd_val_id=sa.cd_val_id and cvt.lang_cd=39 and " +
				"sa.expn_dt IS NULL AND cvt.expn_dt IS NULL and cw1.glbl_ele_mtdt_cd in (select cd_val_id from cd_val where cd_tbl_id=726) and cw.glbl_ele_id=cw1.glbl_ele_id";
		
		Long eleTyp = stagingDAO.retrieveEleTypCd(eleTypQuery);
		
	
		
		addCrosswalkVO.setGlobalElementTypeCode(eleTyp);
		
		String query="select cw.glbl_ele_mtdt_cd,cvt.cd_val_desc,cw.glbl_ele_mtdt_val from glbl_ele_cross_walk cw, cd_val_txt cvt, sys_appy sa where sa.dnb_sys_cd ="+globalElementPlatformCode+" and cw.glbl_ele_id="+globalElementId+" and sa.cd_val_id=cw.glbl_ele_mtdt_cd and cvt.cd_val_id=sa.cd_val_id and cvt.lang_cd=39 and sa.expn_dt IS NULL AND cvt.expn_dt IS NULL";
		
		List<AddCrosswalkVO> result = stagingDAO.retrieveEditPlatformDetails(query);	
		
		
		
		return result;
	}


	@Override
	public Long editNewCrosswalk(AddCrosswalkVO addCrosswalkVO) {
		GloblalElementCrossWalk globlalElementCrossWalk = new GloblalElementCrossWalk();
		Long crosswalkId = null;		
		String ElementTypeDesc = null;
		List<String> metacodeValueList = addCrosswalkVO.getMetacodeValueList();
		
		for(int i=0;i<metacodeValueList.size();i++){			
			String[] value = metacodeValueList.get(i).split("#~"); 			
				for(int j=0;j<value.length;j++){
					crosswalkId = stagingDAO.retreiveData("Select GLBL_ELE_CW_ID from GLBL_ELE_CROSS_WALK where GLBL_ELE_ID ="+addCrosswalkVO.getGlobalElementId()+" and GLBL_ELE_MTDT_CD="+Long.valueOf(value[j])+"and GLBL_ELE_PLFM_CD="+addCrosswalkVO.getGlobalElementPlatformCode());
					
					globlalElementCrossWalk.setGlobalElementCrosswalkId(crosswalkId);
					globlalElementCrossWalk.setGlobalElementId(addCrosswalkVO.getGlobalElementId());
					globlalElementCrossWalk.setGlobalElementMetadataCode(Long.valueOf(value[j]));
					j++;
					globlalElementCrossWalk.setGlobalElementMetadataValue(value[j]);
					globlalElementCrossWalk.setGlobalElementPlatformCode(addCrosswalkVO.getGlobalElementPlatformCode());
					globlalElementCrossWalk.setGlobalElementCrosswalkCommnet(null);
					globlalElementCrossWalk.setCreatedUser(addCrosswalkVO.getCreatedUser());
					globlalElementCrossWalk.setModifiedUser(addCrosswalkVO.getModifiedUser());
					globlalElementCrossWalk.setCreatedDate(addCrosswalkVO.getCreatedDate());
					globlalElementCrossWalk.setModifiedDate(addCrosswalkVO.getModifiedDate());
					stagingDAO.addNewCrosswalk(globlalElementCrossWalk);
				}
		}
		
		GloblalElementCrossWalk newGloblalElementCrossWalk = new GloblalElementCrossWalk();
		if(addCrosswalkVO.getGlobalElementTypeCode() != null || addCrosswalkVO.getGlobalElementTypeCode() != 0){
			crosswalkId = stagingDAO.retreiveData("Select GLBL_ELE_CW_ID from GLBL_ELE_CROSS_WALK where GLBL_ELE_ID ="+addCrosswalkVO.getGlobalElementId()+" and GLBL_ELE_MTDT_CD="+addCrosswalkVO.getGlobalElementTypeCode()+"and GLBL_ELE_PLFM_CD="+addCrosswalkVO.getGlobalElementPlatformCode());
			if(crosswalkId != 0 || crosswalkId != null){			
			String query = "select cd_val_desc from cd_val_txt where lang_cd=39 and expn_dt is null and cd_val_id="+addCrosswalkVO.getGlobalElementTypeCode();
			ElementTypeDesc = stagingDAO.retreiveEleTypDesc(query);
			newGloblalElementCrossWalk.setGlobalElementCrosswalkId(crosswalkId);
			newGloblalElementCrossWalk.setGlobalElementId(addCrosswalkVO.getGlobalElementId());
			newGloblalElementCrossWalk.setGlobalElementMetadataCode(addCrosswalkVO.getGlobalElementTypeCode());			
			newGloblalElementCrossWalk.setGlobalElementMetadataValue(ElementTypeDesc);
			newGloblalElementCrossWalk.setGlobalElementPlatformCode(addCrosswalkVO.getGlobalElementPlatformCode());
			newGloblalElementCrossWalk.setGlobalElementCrosswalkCommnet(null);
			newGloblalElementCrossWalk.setCreatedUser(addCrosswalkVO.getCreatedUser());
			newGloblalElementCrossWalk.setModifiedUser(addCrosswalkVO.getModifiedUser());
			newGloblalElementCrossWalk.setCreatedDate(addCrosswalkVO.getCreatedDate());
			newGloblalElementCrossWalk.setModifiedDate(addCrosswalkVO.getModifiedDate());
			stagingDAO.addNewCrosswalk(newGloblalElementCrossWalk);
		}else{
			crosswalkId = stagingDAO.retrieveMaxCrossWalkId();
			String query = "select cd_val_desc from cd_val_txt where lang_cd=39 and expn_dt is null and cd_val_id="+addCrosswalkVO.getGlobalElementTypeCode();
			ElementTypeDesc = stagingDAO.retreiveEleTypDesc(query);
			newGloblalElementCrossWalk.setGlobalElementCrosswalkId(crosswalkId);
			newGloblalElementCrossWalk.setGlobalElementId(addCrosswalkVO.getGlobalElementId());
			newGloblalElementCrossWalk.setGlobalElementMetadataCode(addCrosswalkVO.getGlobalElementTypeCode());			
			newGloblalElementCrossWalk.setGlobalElementMetadataValue(ElementTypeDesc);
			newGloblalElementCrossWalk.setGlobalElementPlatformCode(addCrosswalkVO.getGlobalElementPlatformCode());
			newGloblalElementCrossWalk.setGlobalElementCrosswalkCommnet(null);
			newGloblalElementCrossWalk.setCreatedUser(addCrosswalkVO.getCreatedUser());
			newGloblalElementCrossWalk.setModifiedUser(addCrosswalkVO.getModifiedUser());
			newGloblalElementCrossWalk.setCreatedDate(addCrosswalkVO.getCreatedDate());
			newGloblalElementCrossWalk.setModifiedDate(addCrosswalkVO.getModifiedDate());
			stagingDAO.addNewCrosswalk(newGloblalElementCrossWalk);
		}
		
		
	}
		return crosswalkId;
		
	}


	@Override
	public List<GloblalElementCrossWalk> retrievePlatformList() {
		LOGGER.info("entering GlobalElementServiceImpl | retrieveTopics");
		return stagingDAO.retrievePlatformList();
	}


	@Override
	@Transactional("stgTransactionManager")
	public List<GlobalElement> unMappedElementCount() {
		LOGGER.info("entering GlobalElementServiceImpl | unMappedElementCount");			
		return stagingDAO.retrieveUnMappedCountList();
	}
	
	@Override
	@Transactional("stgTransactionManager")
	public Long totalUnMappedElementCount(
			GloblalElementCrossWalk globlalElementCrossWalk) {
		LOGGER.info("entering GlobalElementServiceImpl | unMappedElementCount");
		Long unMappedElementCount = stagingDAO.totalUnMappedElementCount();
		
		return unMappedElementCount;
	}
	
	@Override
	public Long retrieveGroupName(
			String addGlobalElementVO) {
		LOGGER.info("entering GlobalElementServiceImpl | retrieveGlobalElement");
		return stagingDAO.retrieveGroupName(addGlobalElementVO.trim());
		
	
	}
	
	@Override
    @Transactional("stgTransactionManager")
    public Long retrieveGroupName(String groupName,Long globalElementId) {
          LOGGER.info("entering GlobalElementServiceImpl | retrieveGroupName");
          return stagingDAO.retrieveGroupName(groupName.trim(),globalElementId);
    }

	
}
