/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.endpoint;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplate;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.service.FinancialTemplateService;
import com.dnb.dsc.refdata.service.IndustryCodeService;

/**
 * @author Cognizant
 * @version last updated : June 19, 2012
 * @see
 *
 */
@Controller
public class FinancialTemplateServiceHttpEndpoint {

	private static final Logger LOGGER = LoggerFactory
	.getLogger(FinancialTemplateServiceHttpEndpoint.class);

	@Autowired
	private FinancialTemplateService ftService;
	
	@Autowired
	private IndustryCodeService indsCodeService; 
	
	/**
	 * 
	 * The method to retrieve the financial templates
	 *
	 * @param codeTableId
	 * @return
	 */
	@RequestMapping(value = "/{codeTableId}/getFinancialTemplates.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueText> getFinancialTemplates(
			@PathVariable("codeTableId") Long codeTableId) {
		LOGGER.info("entering FinancialTemplateServiceHttpEndpoint | getFinancialTemplates");
		return ftService.getFinancialTemplates(codeTableId);
	}
	
	@RequestMapping(value = "/{statementType}/getSchedulesForStatementType.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueText> getSchedulesForStatementType(
			@PathVariable("statementType") Long statementType) {
		LOGGER.info("entering FinancialTemplateServiceHttpEndpoint | getSchedulesForStatementType");
		return ftService.getSchedulesForStatementType(statementType);
	}
	
	@RequestMapping(value = "/updateFinancialStatementTemplate.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateFinancialStatementTemplate(@RequestBody FinancialStatementTemplate fsTemplate) {
		LOGGER.info("entering FinancialTemplateServiceHttpEndpoint | updateFinancialStatementTemplate.service");
		return ftService.updateFinancialStatementTemplate(fsTemplate);
	}
	
	@RequestMapping(value = "/{financialTemplateTypeCode}/{isStagingDB}/retrieveFinancialStatementTemplateByTypeCode.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	FinancialStatementTemplate retrieveFinancialStatementTemplateByTypeCode(@PathVariable("financialTemplateTypeCode") Long financialTemplateTypeCode,
			@PathVariable("isStagingDB") Boolean isStagingDB ) {
		LOGGER.info("entering FinancialTemplateServiceHttpEndpoint | retrieveFinancialStatementTemplateByTypeCode");
		return ftService.retrieveFinancialStatementTemplateByTypeCode(financialTemplateTypeCode, isStagingDB);
	}
	
	@RequestMapping(value = "/{scheduleType}/getLineItemsForScheduleType.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueText> getLineItemsForScheduleType(
			@PathVariable("scheduleType") Long scheduleType) {
		LOGGER.info("entering FinancialTemplateServiceHttpEndpoint | getLineItemsForScheduleType");
		return ftService.getLineItemsForScheduleType(scheduleType);
	}
	
	@RequestMapping(value = "/retrieveDescForId.service", method = RequestMethod.POST)
	public @ResponseBody
	Map<Integer, String> retrieveDescForId(
			@RequestBody List<Integer> codeValueIdList) {
		LOGGER.info("entering FinancialTemplateServiceHttpEndpoint | retrieveDescForId");
		return ftService.retrieveDescForId(codeValueIdList);
	}
	@RequestMapping(value = "/{financialStatementTemplateId}/getFinancialStatementTemplateById.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	FinancialStatementTemplate retrieveFinancialStatementTemplateById(
			@PathVariable("financialStatementTemplateId") Long financialStatementTemplateId) {
		LOGGER.info("entering FinancialTemplateServiceHttpEndpoint | retrieveFinancialStatementTemplateById");
		return ftService.retrieveFinancialStatementTemplateById(financialStatementTemplateId);
	}
	
	@RequestMapping(value = "/retrieveStatementForSchedules.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValueText> retrieveStatementForSchedules(
			@RequestBody List<Integer> scheduleCodeList) {
		LOGGER.info("entering FinancialTemplateServiceHttpEndpoint | retrieveStatementForSchedules");
		return ftService.retrieveStatementForSchedules(scheduleCodeList);
	}
	
	/**
	 * The method return the finance template type code for a given finance template id
	 *
	 * @param financeTemplateId
	 * @return
	 */
	@RequestMapping(value = "/retrieveFinanceTemplateCodeById.service", method = RequestMethod.POST)
	public @ResponseBody
	Long retrieveFinanceTemplateCodeById(@RequestBody Long financeTemplateId){
	    LOGGER.info("entering FinancialTemplateServiceHttpEndpoint | retrieveFinanceTemplateCodeById");
	    return ftService.retrieveFinanceTemplateCodeById(financeTemplateId);
	    
	}
	/**
	 * 
	 * The method to insert the saved record transaction to the ui_svd_rec
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param deletedUser
	 * @param userComment
	 * @return
	 */
	@RequestMapping(value = "/{domainId}/{domainName}/{changeType}/{deletedUser}/{userComment}/insertSavedRecord.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	Long insertSavedRecord(
			@PathVariable("domainId") Long domainId,
			@PathVariable("domainName") String domainName,
			@PathVariable("changeType") String changeType,
			@PathVariable("deletedUser") String deletedUser,
			@PathVariable("userComment") String userComment) {
		LOGGER.info("entering FinancialTemplateServiceHttpEndpoint | insertSavedRecord");
		SavedRecord savedRecord = indsCodeService.insertSavedRecord(domainId,
				domainName, changeType, deletedUser, userComment); 
		return savedRecord.getSavedRecordId();
	}
}
