/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.entity.XmlSchemaElementLabelDetails;
import com.dnb.dsc.refdata.core.vo.XmlSchemaSearchVO;
import com.dnb.dsc.refdata.dao.IndsTransactionalDAO;
import com.dnb.dsc.refdata.dao.XmlLabelsStagingDAO;
import com.dnb.dsc.refdata.dao.XmlLabelsTransactionalDAO;
import com.dnb.dsc.refdata.service.IndustryCodeService;
import com.dnb.dsc.refdata.service.XmlSchemaLabelService;

/**
 * This is used as the services class for the Xml Schema Label operations
 * 
 * @author Cognizant
 * @version last updated : Apr 13, 2012
 * @see
 * 
 */
@Service("XmlSchemaLabelService")
public class XmlSchemaLabelServiceImpl implements XmlSchemaLabelService {

    /**
     * The instance variable for Logging
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(XmlSchemaLabelServiceImpl.class);

    @Autowired
    private XmlLabelsStagingDAO xmlLabelsStagingDAO;

    @Autowired
    private XmlLabelsTransactionalDAO xmlLabelsTransactionalDAO;
    
    @Autowired
	private IndsTransactionalDAO indsTransactionalDAO;
    
    @Autowired
	private IndustryCodeService indsService;
    
    
    /**
     * The method will search for the xml schema elements by element name or description. The user will type in the
     * element name or description and the dao layer will retrieve the names satisfying the filter
     * 
     * @param xmlSchemaSearchVO
     * @return list of XmlSchemaElement
     */
    @Transactional("stgTransactionManager")
    public List<XmlSchemaElement> searchXmLSchemaLabels(XmlSchemaSearchVO xmlSchemaSearchVO) {
        LOGGER.info("entering XmlSchemaLabelServiceImpl | searchXmLSchemaLabels");
        return xmlLabelsStagingDAO.searchXmLSchemaLabels(xmlSchemaSearchVO);
    }

    /**
     * The method will search for the xml schema elements details by element id. The user will pass the element id and
     * the dao layer will retrieve the corresponfing details
     * 
     * @param elementId
     * @return XmlSchemaElement
     */
    @Transactional("stgTransactionManager")
    public XmlSchemaElement retrieveXmlSchemaByXmlElementId(String elementId) {
        XmlSchemaElement xmlSchemaElement = xmlLabelsStagingDAO.retrieveXmlSchemaByXmlElementId(elementId);
        LOGGER.info("xmlSchemaElement is "+xmlSchemaElement);
        return xmlSchemaElement;
    }

	/**
	 * 
	 * The method will perform the table count of xml schema element on the
	 * staging db based on the specified filter conditions.
	 * 
	 * @param XmlSchemaSearchVO
	 * @return count of XmlSchemaElement
	 */
    public Long countSearchXmLSchemaLabels(XmlSchemaSearchVO xmlSchemaSearchVO) {
    	return xmlLabelsStagingDAO.countSearchXmLSchemaLabels(xmlSchemaSearchVO);
    }
    /**
	 * The method will persist the existing XmlSchemaElement data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param xmlSchemaElement
	 * @return workflowTrackingId
	 */
	@Override
	@Transactional("txnTransactionManager")
	public String updateXmlSchemaElement(XmlSchemaElement xmlSchemaElement) {
		LOGGER.info("entering XmlSchemaLabelServiceImpl | updateXmlSchemaElement");
		List<SavedRecord> savedRecords = new ArrayList<SavedRecord>();
		/*
		 * For existing xmlSchemaElement - update
		 * Populate the savedRecord with the details of the xmlSchemaElementId 
		 */
		if (xmlSchemaElement.getXmlSchemaElementLabelDetails() != null) {
			for (XmlSchemaElementLabelDetails currDetail : xmlSchemaElement.getXmlSchemaElementLabelDetails()) {
				if(RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED.equals(currDetail.getChangeIndicator())) {
					savedRecords.add(
							indsService.populateSavedRecord(currDetail.getXmlSchemaElementLabelDetailsId(), 
							RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS, 
							RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_XML_SCHEMA_LABEL,  
							currDetail.getModifiedUser(), 
							"XMLSCMADTL:" + currDetail.getXmlSchemaElementId() + "#"));
				}
			}
		}
		xmlSchemaElement.setXmlSchemaElementXPath(null);
		
		LOGGER.info("XmlSchemaLabelServiceImpl | updateXmlSchemaElement | update xmlSchemaElement " + xmlSchemaElement);
		XmlSchemaElement updatedXmlSchemaElement = xmlLabelsTransactionalDAO.updateXmlSchemaElement(xmlSchemaElement);
		LOGGER.info("XmlSchemaLabelServiceImpl | updateXmlSchemaElement | updated with Id : " + updatedXmlSchemaElement.getXmlSchemaElementId());

		/**
		 * Insert the saved records into the transaction DB
		 */
		LOGGER.info("XmlSchemaLabelServiceImpl | updateXmlSchemaElement | SavedRecords : " + savedRecords);
		for(SavedRecord savedRecord : savedRecords) {
			indsTransactionalDAO.insertSavedRecord(savedRecord);
		}
		
		LOGGER.info("XmlSchemaLabelServiceImpl | updateXmlSchemaElement | Done " 
				+ updatedXmlSchemaElement.getXmlSchemaElementId());
		return updatedXmlSchemaElement.getXmlSchemaElementId();
	}
	/**
	 *
	 * The method will validate the Currency Exchange for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 *
	 * @param geoUnitId
	 * @return
	 */
	@Override
	public Boolean lockXmlSchema(String xmlSchemaElementId) {
		LOGGER.info("entering XmlSchemaLabelServiceImpl | lockXmlSchema");
		int count = xmlLabelsTransactionalDAO.countXmlSchema(xmlSchemaElementId);
		LOGGER.info("exiting XmlSchemaLabelServiceImpl | lockXmlSchema ||count :"+count);
		return count == 0 ? false : true;
	}
	
	  /**
     * The method will search for the xml schema elements details by element id. The user will pass the element id and
     * the dao layer will retrieve the corresponding details
     * 
     * @param elementId
     * @return XmlSchemaElement
     */
	@Transactional("txnTransactionManager")
    public XmlSchemaElement reviewXmlSchemaByXmlElementChanges(String elementId) {
		LOGGER.info("entering XmlSchemaLabelServiceImpl | reviewXmlSchemaByXmlElementChanges");
		List<SavedRecord> savedRecords = indsTransactionalDAO.retrieveSavedRecords(null, 
				RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS, null,elementId);
		LOGGER.info("savedRecords : " + savedRecords);
		
        XmlSchemaElement txnXmlSchemaElement = xmlLabelsTransactionalDAO.retrieveXmlSchemaByXmlElementId(elementId);
        XmlSchemaElement stgXmlSchemaElement = xmlLabelsStagingDAO.retrieveXmlSchemaByXmlElementId(elementId);

        LOGGER.info("exiting XmlSchemaLabelServiceImpl | reviewXmlSchemaByXmlElementChanges");
		return mergeXmlSchemaDetails(stgXmlSchemaElement, txnXmlSchemaElement, savedRecords);
    }
	/**
	 * This method is to merge the XmlSchemaElementLabelDetails of staging and transaction db
	 * @param stgXmlSchemaElementDetails
	 * @param txnXmlSchemaElementDetails
	 * @param savedRecords
	 * @return XmlSchemaElement
	 */
	private XmlSchemaElement mergeXmlSchemaDetails(
			XmlSchemaElement stgXmlSchemaElement, 
			XmlSchemaElement txnXmlSchemaElement,
			List<SavedRecord> savedRecords) {
		List<XmlSchemaElementLabelDetails> stgXmlSchemaElementDetails = 
			stgXmlSchemaElement.getXmlSchemaElementLabelDetails();
		List<XmlSchemaElementLabelDetails> txnXmlSchemaElementDetails = 
			txnXmlSchemaElement.getXmlSchemaElementLabelDetails();
		
		XmlSchemaElement mergedXmlSchemaElement = new XmlSchemaElement();
		mergedXmlSchemaElement.setXmlSchemaElementId(txnXmlSchemaElement.getXmlSchemaElementId());
		mergedXmlSchemaElement.setXmlSchemaRecordTypeCd(txnXmlSchemaElement.getXmlSchemaRecordTypeCd());
		mergedXmlSchemaElement.setDataElementName(txnXmlSchemaElement.getDataElementName());
		mergedXmlSchemaElement.setDataElementDescription(txnXmlSchemaElement.getDataElementDescription());
		mergedXmlSchemaElement.setXmlSchemaElementXPath(stgXmlSchemaElement.getXmlSchemaElementXPath());
		
		List<Long> txnDomainIds = new ArrayList<Long>();
		List<Long> stgDomainIds = new ArrayList<Long>();
		List<XmlSchemaElementLabelDetails> xmlSchemaElementLabelDetails = new ArrayList<XmlSchemaElementLabelDetails>();
		// retrieve the list of saved records
		List<Long> savedRecordDomainIds = new ArrayList<Long>();
		for(SavedRecord savedRecord :savedRecords ) {
			savedRecordDomainIds.add(savedRecord.getDomainId());
		}
		// retrieve the element id for all the element label details in staging SoR.
		for(XmlSchemaElementLabelDetails xmlSchemaElementLabelDetail :stgXmlSchemaElementDetails ) {
			stgDomainIds.add(xmlSchemaElementLabelDetail.getXmlSchemaElementLabelDetailsId());
		}
		// iterate and update the change descriptions
		for(XmlSchemaElementLabelDetails xmlSchemaElementLabelDetail : txnXmlSchemaElementDetails ) {
			if(savedRecordDomainIds.contains(xmlSchemaElementLabelDetail.getXmlSchemaElementLabelDetailsId())) {
				xmlSchemaElementLabelDetail.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED);
			}
			else if(stgDomainIds.contains(xmlSchemaElementLabelDetail.getXmlSchemaElementLabelDetailsId())){
				xmlSchemaElementLabelDetail.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_CORRECTED);
			} else {
				xmlSchemaElementLabelDetail.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW);
			}
			txnDomainIds.add(xmlSchemaElementLabelDetail.getXmlSchemaElementLabelDetailsId());
			xmlSchemaElementLabelDetails.add(xmlSchemaElementLabelDetail);
		}
		// add the descriptions available in staging but no in transaction DB
		for(XmlSchemaElementLabelDetails xmlSchemaElementLabelDetail :stgXmlSchemaElementDetails ) {
			if(!txnDomainIds.contains(xmlSchemaElementLabelDetail.getXmlSchemaElementLabelDetailsId())) {
				xmlSchemaElementLabelDetail.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NO_CHANGE);
				xmlSchemaElementLabelDetails.add(xmlSchemaElementLabelDetail);
			}
		}
		mergedXmlSchemaElement.setXmlSchemaElementLabelDetails(xmlSchemaElementLabelDetails);
		return mergedXmlSchemaElement;
    }
    
    /**
	 * The method will persist the existing XmlSchemaElement data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 *
	 * @param xmlSchemaElement
	 * @return workflowTrackingId
	 */
	@Override
	@Transactional("stgTransactionManager")
	public String saveApprovedXmlSchemaLabels(String xmlSchemaElementId) {
		XmlSchemaElement xmlSchemaElement = xmlLabelsTransactionalDAO.retrieveXmlSchemaByXmlElementId(
				xmlSchemaElementId);
		LOGGER.info("xmlSchemaElement : " + xmlSchemaElement);
		
		List<SavedRecord> savedRecords = indsTransactionalDAO.retrieveSavedRecords(
				null, RefDataPropertiesConstants.DOMAIN_CODE_XML_SCHEMA_LABELS, null,xmlSchemaElementId );
		xmlSchemaElement.setXmlSchemaElementLabelDetails(
				removeDeletedXmlSchemaElementDescriptions(
						xmlSchemaElement.getXmlSchemaElementLabelDetails(),
						savedRecords));
		XmlSchemaElement updatedXmlSchemaElement = xmlLabelsStagingDAO.updateXmlSchemaElement(xmlSchemaElement);
		LOGGER.info("updated xmlSchemaElement with Id : " + updatedXmlSchemaElement.getXmlSchemaElementId());

		return updatedXmlSchemaElement.getXmlSchemaElementId();
	}
	/**
	 * 
	 * The method to remove the deleted XML schema element descriptions
	 *
	 * @param xmlSchemaElementLabelDetails
	 * @param savedRecords
	 * @return
	 */
	private List<XmlSchemaElementLabelDetails> removeDeletedXmlSchemaElementDescriptions(
			List<XmlSchemaElementLabelDetails> xmlSchemaElementLabelDetails,
			List<SavedRecord> savedRecords){
		List<Long> savedRecordDomainIds= new ArrayList<Long>();
		List<XmlSchemaElementLabelDetails> xmlSchemaElementLabelDetailsForInsert= 
			new ArrayList<XmlSchemaElementLabelDetails>();
	
		for(SavedRecord savedRecord :savedRecords ) {
			savedRecordDomainIds.add(savedRecord.getDomainId());
		}
		for(XmlSchemaElementLabelDetails xmlSchemaElementLabelDetail :xmlSchemaElementLabelDetails ) {
			if(savedRecordDomainIds.contains(xmlSchemaElementLabelDetail.getXmlSchemaElementLabelDetailsId())) {
				//remove from staging DB as it is present in savedRecords
				removeDeletedXmlSchemaLabelDetail(xmlSchemaElementLabelDetail.getXmlSchemaElementLabelDetailsId());
				indsService.removeSavedRecord(xmlSchemaElementLabelDetail.getXmlSchemaElementLabelDetailsId());
			}else  {
				// it is a new xmlSchemaElementLabelDetail. Add it to the lit of
				// inserts to the staging DB
				xmlSchemaElementLabelDetailsForInsert.add(xmlSchemaElementLabelDetail);
			}
		}
		return xmlSchemaElementLabelDetailsForInsert;
	}
	/**
	 * The method will remove the xmlSchema data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param industryCodeId
	 * @param boolean indicating the status
	 */
	@Override
	@Transactional("stgTransactionManager")
	public void removeDeletedXmlSchemaLabelDetail(Long xmlSchemaElementLabelDetailId) {
		xmlLabelsStagingDAO.removeDeletedXmlSchemaLabelDetail(xmlSchemaElementLabelDetailId);
	}
	/**
	 * The method will remove the industryCode data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param industryCodeId
	 * @param boolean indicating the status
	 */
	@Override
	@Transactional("txnTransactionManager")
	public void removeApprovedXmlSchemaLabels(String xmlSchemaElementId) {
		xmlLabelsTransactionalDAO.removeApprovedXmlSchemaLabels(xmlSchemaElementId);
	}
}
