/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.constant.RefDataChangeTypeConstants;
import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeDescription;
import com.dnb.dsc.refdata.core.entity.IndustryCodeMap;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.InduscodeMappingBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.IndustryCodesSearchCriteriaVO;
import com.dnb.dsc.refdata.dao.IndsCodeStagingDAO;
import com.dnb.dsc.refdata.dao.IndsTransactionalDAO;
import com.dnb.dsc.refdata.dao.SCoTsStagingDAO;
import com.dnb.dsc.refdata.service.IndustryCodeService;

/**
 * This is used as the Service implementation class for the Currency Exchange
 * operations.
 *
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 *
 */
@Service("IndustryCodeService")
public class IndustryCodesServiceImpl implements IndustryCodeService {

	@Autowired
	private IndsCodeStagingDAO stagingDAO;

	@Autowired
	private IndsTransactionalDAO transactionalDAO;
	
	@Autowired
	private SCoTsStagingDAO scotsStagingDAO;

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(IndustryCodesServiceImpl.class);

	/**
	 *
	 * Performs a hierarchy search of Industry Codes on the search db.
	 * <p>
	 *
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 *
	 * @param industryCodesSearchCriteria
	 * @return list of IndustryCode
	 */
	@Override
	@Transactional("stgTransactionManager")
	public List<IndustryCode> searchIndustryCodes(
			IndustryCodesSearchCriteriaVO industryCodesSearchCriteria) {
		LOGGER.info("entering IndustryCodesServiceImpl | searchIndustryCodes");
	
		List<IndustryCode> indsCodesList = (List<IndustryCode>) stagingDAO
				.searchIndustryCodes(industryCodesSearchCriteria);

		LOGGER.info("exiting IndustryCodesServiceImpl | searchIndustryCodes");
		return indsCodesList;
	}

	/**
	 * The method will retrieve Industry code CrossWalks for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 *
	 * @param industryCodeTypeCode
	 * @return list of codeValueVO
	 */
	@Override
	@Transactional("stgTransactionManager")
	public List<CodeValueVO> retrieveCrossWalksForIndsCodeType(
			Long industryCodeTypeCode) {
		LOGGER.info("entering IndustryCodesServiceImpl | retrieveCrossWalksForIndsCodeType");
		return stagingDAO
				.retrieveCrossWalksForIndsCodeType(industryCodeTypeCode);
	}

	/**
	 * The method will retrieve description for Industry code and type code.
	 *
	 * @param industryCodeTypeCode
	 * @param industryCode
	 * @return description
	 */
	@Override
	@Transactional("stgTransactionManager")
	public String retrieveDescriptionForIndsCodeTypeCode(
			Long industryCodeTypeCode, String industryCode) {
		LOGGER.info("entering IndustryCodesServiceImpl | retrieveDescriptionForIndsCodeTypeCode");
		return stagingDAO.retrieveDescriptionForIndsCodeTypeCode(
				industryCodeTypeCode, industryCode);
	}

	@Override
	@Transactional("stgTransactionManager")
	public Long retrieveIndustryCodeIdByCodeTypeCode(Long industryCodeTypeCode,
			String industryCode) {
		LOGGER.info("entering IndustryCodesServiceImpl | retrieveIndustryCodeIdByCodeTypeCode");
		return stagingDAO.retrieveIndustryCodeIdByCodeTypeCode(
				industryCodeTypeCode, industryCode);
	}

	/**
	 * The method will retrieve Industry code Group Levels for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 *
	 * @param industryCodeTypeCode
	 * @param session
	 * @return list of codeValueVO
	 */
	@Override
	@Transactional("stgTransactionManager")
	public List<CodeValueVO> retrieveGroupLevelCodes(Long industryCodeTypeCode, Long languageCode) {
		LOGGER.info("entering IndustryCodesServiceImpl | retrieveGroupLevelCodes");
		return stagingDAO.retrieveGroupLevelCodes(industryCodeTypeCode, languageCode);
	}

	/**
	 *
	 * The method will count the records in the hierarchy search of industry
	 * codes on the search db. The search will be done on the flat db based on
	 * the search criteria the user had provided.
	 *
	 * @param searchCriteriaVO
	 * @return countResults
	 */
	@Override
	public Long countSearchIndustryCodes(
			IndustryCodesSearchCriteriaVO industryCodesSearchCriteria) {
		LOGGER.info("entering IndustryCodesServiceImpl | countSearchIndustryCodes");
		return stagingDAO.countSearchIndustryCodes(industryCodesSearchCriteria);
	}

	/**
	 * The method will search the Staging SoR for the IndustryCode based on the
	 * IndustryCodeId and will return the IndustryCode entity.
	 *
	 * @param industryCodeId
	 */
	@Override
	@Transactional("stgTransactionManager")
	public IndustryCode retrieveIndustryCodeByIndustryCodeId(Long industryCodeId) {

		LOGGER.info("entering IndustryCodesServiceImpl | retrieveIndustryCodeByIndustryCodeId");
		IndustryCode industryCode = stagingDAO
				.retrieveIndustryCodeByIndustryCodeId(industryCodeId);
		LOGGER.info("IndustryCode : " + industryCode);
		return industryCode;
	}

	/**
	 * The method will persist the existing IndustryCode data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 *
	 * @param IndustryCode
	 * @return workflowTrackingId
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long updateIndustryCode(IndustryCode industryCode) {
		List<SavedRecord> savedRecords = new ArrayList<SavedRecord>();
		/*
		 * For Add new industry code where the industryCodeId is <= 0
		 */
		if (industryCode.getIndustryCodeId() == -1L) {
			List<IndustryCodeDescription> indsCodeDesc = new ArrayList<IndustryCodeDescription>();
			List<IndustryCodeMap> indsCodeMaps = new ArrayList<IndustryCodeMap>();
			Long industryCodeId = transactionalDAO.retrieveMaxIndustryCodeId();
			industryCode.setIndustryCodeId(industryCodeId);
			for (IndustryCodeDescription currDescription : industryCode.getIndustryCodeDescriptions()) {
				currDescription.setIndustryCodeId(industryCodeId);
				indsCodeDesc.add(currDescription);
			}
			industryCode.setIndustryCodeDescriptions(indsCodeDesc);
			if (industryCode.getIndustryCodeMaps() != null) {
				for (IndustryCodeMap currMap : industryCode.getIndustryCodeMaps()) {
					currMap.getIndustryCodeMapPK().setFromIndustryCodeId(industryCodeId);
					indsCodeMaps.add(currMap);
				}
			}
			industryCode.setIndustryCodeMaps(indsCodeMaps);
		} else {
			/*
			 * For existing industry code - update
			 * Populate the savedRecord with the details of the industry code description id 
			 */
			if(industryCode.getIndustryCodeDescriptions() != null) {
				for (IndustryCodeDescription currDescription : industryCode.getIndustryCodeDescriptions()) {
					if(RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED.equals(currDescription.getChangeIndicator())) {
						savedRecords.add(populateSavedRecord(currDescription.getIndustryCodeId(), 
								RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE, 
								RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_INDUSTRY_CODE,  
								currDescription.getModifiedUser(), 
								"INDSCODEDESC:" + currDescription.getIndustryCodeDescriptionId() + "#"));
					}
				}
			}
			/*
			 * For existing industry code - update
			 * Populate the savedRecord with the details of the industry code mapping id 
			 */
			if (industryCode.getIndustryCodeMaps() != null) {
				for (IndustryCodeMap currMap : industryCode.getIndustryCodeMaps()) {
					if(RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED.equals(currMap.getChangeIndicator())) {
						savedRecords.add(
								populateSavedRecord(currMap.getIndustryCodeMapPK().getFromIndustryCodeId(), 
								RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE, 
								RefDataChangeTypeConstants.CHANGE_TYPE_UPDATE_INDUSTRY_CODE,  
								currMap.getModifiedUser(), 
								"INDSCODEMAP:" + currMap.getIndustryCodeMapPK().getToIndustryCodeId() + "#"));
					}
				}
			}			
		}

		IndustryCode updatedIndustryCode = transactionalDAO.updateIndustryCode(industryCode);
		LOGGER.info("updated industryCode with Id : " + updatedIndustryCode.getIndustryCodeId());

		/*
		 * Insert the saved records into the transaction DB
		 */
		LOGGER.info("SavedRecords : " + savedRecords);
		for(SavedRecord savedRecord : savedRecords) {
			transactionalDAO.insertSavedRecord(savedRecord);
		}
		
		return updatedIndustryCode.getIndustryCodeId();
	}

	/**
	 *
	 * The method will fetch the language codes available for the selected
	 * Industry Code Type. The method will be invoked when the user selects the
	 * Industry Code type value.
	 *
	 * @param industryCodeTypeCode
	 * @param groupLevelCodes
	 * @return list of codeValueVO
	 */
	@Transactional("stgTransactionManager")
	public List<CodeValueVO> retrieveIndustryCodeLanguages(
			Long industryCodeTypeCode, List<Long> groupLevelCodes) {
		LOGGER.info("entering IndustryCodesServiceImpl | retrieveIndustryCodeLanguages");
		return stagingDAO.retrieveIndustryCodeLanguages(industryCodeTypeCode,
				groupLevelCodes);
	}

	/**
	 *
	 * The method to lock the industry code record for edit
	 *
	 * @param industryCodeId
	 * @return isLocked
	 */
	@Override
	public String lockIndustryCode(Long industryCodeId) {
		LOGGER.info("entering IndustryCodesServiceImpl | lockIndustryCode");
		String count = transactionalDAO.countIndustryCode(industryCodeId);
		
		// for delete operation we will save in the saved records table.
		String countDeleted = transactionalDAO.countSavedRecord(industryCodeId);
		
		return count == null ? (countDeleted == null ? "false" : countDeleted) : count;
	}

	/**
	 * The method will be invoked by the when the the business owner reviews the
	 * changes submitted for his approval. The user reviews the changes and he
	 * could approve or reject the request. The method will fetch the details
	 * from Staging SoR and Transaction DB to merge and form the IndustryCode for
	 * review.
	 *
	 * @param domainId
	 */
	@Override
	@Transactional("txnTransactionManager")
	public IndustryCode reviewIndustryCodeChanges(Long domainId) {
		LOGGER.info("entering IndustryCodesServiceImpl | reviewIndustryCodeChanges");
		
		List<SavedRecord> savedRecords = transactionalDAO.retrieveSavedRecords(null, 
				RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE, domainId,null);
		LOGGER.info("savedRecords : " + savedRecords);
		Boolean isFullDelete = isDeletedSavedRecord(savedRecords, RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE, 
				String.valueOf(domainId), null, null, true);
		
		IndustryCode txnIndustryCode = null;
		if(!isFullDelete) {
			// retrieve the IndustryCode data from the Transaction DB
			txnIndustryCode = retrieveIndustryCodeByDomainId(domainId);
		}
		// retrieve the IndustryCode data from the Staging SoR
		IndustryCode stgIndustryCode = retrieveIndustryCodeByIndustryCodeId(domainId);

		// merge both the IndustryCodes and form the IndustryCode for review
		if(isFullDelete) {
			populateLastModifiedDetails(stgIndustryCode, savedRecords);
			return newIndustryCodes(stgIndustryCode, RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED);
		} else if (stgIndustryCode != null) {
			return mergeIndustryCodes(stgIndustryCode, txnIndustryCode, savedRecords);
		} else {
			LOGGER.info("mergeIndustryCode : " + txnIndustryCode);
			return newIndustryCodes(txnIndustryCode, RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW);
		}
	}

	/**
	 *
	 * The method will set the indicator list for a new Industry Code .
	 *
	 * 
	 * @param txnIndustryCode
	 * @return IndustryCode
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	
	private IndustryCode newIndustryCodes(IndustryCode txnIndustryCode, String status){
		List<String> indicatorList = new ArrayList();
		List<String> codeList = new ArrayList();
		codeList.add(txnIndustryCode.getIndustryCode());
		indicatorList.add(status);
		txnIndustryCode.setIndustryCodeList(codeList);
		txnIndustryCode.setChangeIndicatorList(indicatorList);
		List<IndustryCodeMap> txnIndustryCodeMaps = txnIndustryCode.getIndustryCodeMaps();
		for (IndustryCodeMap txnIndustryCodeMap : txnIndustryCodeMaps) {
			txnIndustryCodeMap.setChangeIndicator(status);
		}
		List<IndustryCodeDescription> txnIndustryCodeDescriptions = txnIndustryCode.getIndustryCodeDescriptions();
		for (IndustryCodeDescription txnIndustryCodeDescription : txnIndustryCodeDescriptions) {
			txnIndustryCodeDescription.setChangeIndicator(status);
		}
		
		return txnIndustryCode;
	}

	/**
	 *
	 * The method will merge the data from the transaction DB and the Staging
	 * SoR. The fields containing the changes will be put in a map for all the
	 * identified fields.
	 *
	 * @param stgIndustryCode
	 * @param txnIndustryCode
	 * @param savedRecords
	 * @return IndustryCode
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private IndustryCode mergeIndustryCodes(IndustryCode stgIndustryCode, IndustryCode txnIndustryCode, 
			List<SavedRecord> savedRecords) {
		LOGGER.info("entering IndustryCodesServiceImpl  | mergeIndustryCodes");
		IndustryCode mergeIndustryCode = new IndustryCode();
		List<String> indicatorList = new ArrayList();
		List<String> codeList = new ArrayList();
		mergeIndustryCode.setIndustryCodeId(txnIndustryCode.getIndustryCodeId());
		mergeIndustryCode.setIndustryCode(txnIndustryCode.getIndustryCode());
		mergeIndustryCode.setIndustryCodeTypeCode(txnIndustryCode.getIndustryCodeTypeCode());
		mergeIndustryCode.setIndustryCodeGroupLvelCode(txnIndustryCode.getIndustryCodeGroupLvelCode());
		mergeIndustryCode.setCreatedDate(txnIndustryCode.getCreatedDate());
		mergeIndustryCode.setCreatedUser(txnIndustryCode.getCreatedUser());
		mergeIndustryCode.setModifiedDate(txnIndustryCode.getModifiedDate());
		mergeIndustryCode.setModifiedUser(txnIndustryCode.getModifiedUser());

		if (stgIndustryCode.getIndustryCode().equals(txnIndustryCode.getIndustryCode())) {
			indicatorList.add(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NO_CHANGE);
		} else {
			indicatorList.add(RefDataPropertiesConstants.WQ_REVIEW_RECORD_OLD);
			indicatorList.add(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW);
		}
		codeList.add(stgIndustryCode.getIndustryCode());
		codeList.add(txnIndustryCode.getIndustryCode());

		mergeIndustryCode.setChangeIndicatorList(indicatorList);
		mergeIndustryCode.setIndustryCodeList(codeList);

		// merge the Industry Code Descriptions
		mergeIndustryCode.setIndustryCodeDescriptions(mergeIndustryCodeDescriptions(
						stgIndustryCode,
						txnIndustryCode, savedRecords));

		// merge the Industry Code Maps
		mergeIndustryCode.setIndustryCodeMaps(mergeIndustryCodeMaps(
				stgIndustryCode.getIndustryCodeMaps(),
				txnIndustryCode.getIndustryCodeMaps(), savedRecords));

		LOGGER.info("exiting IndustryCodesServiceImpl  | mergeIndustryCodes || mergeIndustryCode: "
				+ mergeIndustryCode);

		return mergeIndustryCode;
	}

	/**
	 *
	 * The method will merge the IndustryCodeMap entities of Transaction DB and
	 * the Staging SoR. The return will be the merged IndustryCodeDescriptions.
	 *
	 * @param stgIndustryCodeMaps
	 * @param txnIndustryCodeMaps
	 * @param savedRecords
	 * @return mergeIndustryCodeMaps
	 */
	private List<IndustryCodeMap> mergeIndustryCodeMaps(
			List<IndustryCodeMap> stgIndustryCodeMaps,
			List<IndustryCodeMap> txnIndustryCodeMaps, List<SavedRecord> savedRecords) {
		LOGGER.info("entering IndustryCodesServiceImpl | mergeIndustryCodeMaps");

		List<IndustryCodeMap> mergeIndustryCodeMaps = new ArrayList<IndustryCodeMap>();
		List<Long> txnIndustryCodeMapIds = new ArrayList<Long>();
		// identify the list of IndustryCodeMaps currently available in the
		// Staging SoR
		List<Long> stgIndustryFromCodeIds = new ArrayList<Long>();
		List<Long> stgIndustryToCodeIds = new ArrayList<Long>();
		if (txnIndustryCodeMaps != null) {
			for (IndustryCodeMap stgIndustryCodeMap : stgIndustryCodeMaps) {
				stgIndustryFromCodeIds.add(stgIndustryCodeMap.getIndustryCodeMapPK().getFromIndustryCodeId());
			}
			for (IndustryCodeMap stgIndustryCodeMap : stgIndustryCodeMaps) {
				stgIndustryToCodeIds.add(stgIndustryCodeMap.getIndustryCodeMapPK().getToIndustryCodeId());
			}
			// Loop through the IndustryCodeMaps from Transaction DB
			for (IndustryCodeMap txnIndustryCodeMap : txnIndustryCodeMaps) {
				
				// Check if the record is available among the deleted records (savedRecords)
				if(isDeletedSavedRecord(savedRecords, 
						String.valueOf(txnIndustryCodeMap.getIndustryCodeMapPK().getFromIndustryCodeId()), 
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE, 
						String.valueOf(txnIndustryCodeMap.getIndustryCodeMapPK().getToIndustryCodeId()), 
						"INDSCODEMAP", false)) {
					txnIndustryCodeMap.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED);
				}
				// If the IndustryCodeMap is already available in the Staging SoR
				// then assume it is either a IndustryCodeMap UPDATE or DELETE
				else if (stgIndustryFromCodeIds.contains(txnIndustryCodeMap.getIndustryCodeMapPK().getFromIndustryCodeId())
						&& stgIndustryToCodeIds.contains(
								txnIndustryCodeMap.getIndustryCodeMapPK().getToIndustryCodeId())) {
					// Assume it is UPDATE as there is no expiry date field available
					txnIndustryCodeMap.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_CORRECTED);
				}
				// If the FromIndustryCodeId is not existing in the IndustryCodeMaps
				// from Staging SoR then assume it as NEW addition.
				else {
					txnIndustryCodeMap.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW);
				}
				mergeIndustryCodeMaps.add(txnIndustryCodeMap);
				txnIndustryCodeMapIds.add(txnIndustryCodeMap.getIndustryCodeMapPK().getToIndustryCodeId());
			}
		}
		for (IndustryCodeMap stgIndustryCodeMap : stgIndustryCodeMaps) {
			if (!txnIndustryCodeMapIds.contains(stgIndustryCodeMap.getIndustryCodeMapPK().getToIndustryCodeId())) {
				stgIndustryCodeMap.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NO_CHANGE);
				mergeIndustryCodeMaps.add(stgIndustryCodeMap);
			}
		}
		LOGGER.info("exiting IndustryCodesServiceImpl | mergeIndustryCodeMaps : ||" + mergeIndustryCodeMaps);
		return mergeIndustryCodeMaps;
	}

	/**
	 *
	 * The method will merge the IndustryCodeDescription entities of Transaction
	 * DB and the Staging SoR. The return will be the merged
	 * IndustryCodeDescriptions.
	 *
	 * @param stgIndustryCodeDescriptions
	 * @param txnIndustryCodeDescriptions
	 * @param savedRecords
	 * @return mergeIndustryCodeDescriptions
	 */
	private List<IndustryCodeDescription> mergeIndustryCodeDescriptions(
			IndustryCode stgIndustryCode,
			IndustryCode txnIndustryCode, List<SavedRecord> savedRecords) {
		LOGGER.info("entering IndustryCodesServiceImpl | mergeIndustryCodeDescriptions");

		List<IndustryCodeDescription> mergeIndustryCodeDescriptions = new ArrayList<IndustryCodeDescription>();
		List<Long> txnIndustryCodeDescriptionIds = new ArrayList<Long>();
		// identify the list of industryCodeDescriptionIds currently available
		// in the Staging SoR
		List<Long> stgIndustryCodeDescriptionIds = new ArrayList<Long>();
		if (txnIndustryCode.getIndustryCodeDescriptions() != null) {
			for (IndustryCodeDescription stgIndustryCodeDescription : stgIndustryCode.getIndustryCodeDescriptions()) {
				stgIndustryCodeDescriptionIds.add(stgIndustryCodeDescription
						.getIndustryCodeDescriptionId());
			}
			// Loop through the IndustryCodeDescriptions from Transaction DB
			for (IndustryCodeDescription txnIndustryCodeDescription : txnIndustryCode.getIndustryCodeDescriptions()) {
				
				// Check if the record is available among the deleted records (savedRecords)
				if(isDeletedSavedRecord(savedRecords, 
						String.valueOf(txnIndustryCodeDescription.getIndustryCodeId()), 
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE, 
						String.valueOf(txnIndustryCodeDescription.getIndustryCodeDescriptionId()), 
						"INDSCODEDESC", false)) {
					txnIndustryCodeDescription.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_DELETED);
				}
				
				// If the IndustryCodeDescription is already available in the
				// Staging SoR then assume it is either a IndustryCodeDescription UPDATE or DELETE
				else if (stgIndustryCodeDescriptionIds.contains(txnIndustryCodeDescription.getIndustryCodeDescriptionId())) {
					// To identify UPDATE or DELETE, loop through the Staging SoR
					txnIndustryCodeDescription.setChangeIndicator(
							RefDataPropertiesConstants.WQ_REVIEW_RECORD_CORRECTED);
					if(countIndustryCodeDescriptionForDuplicate(txnIndustryCode.getIndustryCode(),
							txnIndustryCode.getIndustryCodeTypeCode(), txnIndustryCodeDescription.getIndustryDescription())) {
						txnIndustryCodeDescription.setChangeIndicator(
								RefDataPropertiesConstants.WQ_REVIEW_RECORD_CORRECTED + ","
								+RefDataPropertiesConstants.WQ_REVIEW_RECORD_DUPLICATE);
					}
				} 
				
				// If the geoUnitCOdeId is not existing in the GeoUnitCodes
				// from Staging SoR then assume it as NEW addition.
				else {
					txnIndustryCodeDescription.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW);
					if(countIndustryCodeDescriptionForDuplicate(txnIndustryCode.getIndustryCode(),
							txnIndustryCode.getIndustryCodeTypeCode(), txnIndustryCodeDescription.getIndustryDescription())) {
						txnIndustryCodeDescription.setChangeIndicator(
								RefDataPropertiesConstants.WQ_REVIEW_RECORD_NEW + ","
								+RefDataPropertiesConstants.WQ_REVIEW_RECORD_DUPLICATE);
					}
				}
				mergeIndustryCodeDescriptions.add(txnIndustryCodeDescription);
				txnIndustryCodeDescriptionIds.add(txnIndustryCodeDescription.getIndustryCodeDescriptionId());
			}
		}
		for (IndustryCodeDescription stgIndustryCodeDescription : stgIndustryCode.getIndustryCodeDescriptions()) {
			if (!txnIndustryCodeDescriptionIds.contains(stgIndustryCodeDescription.getIndustryCodeDescriptionId())) {
				stgIndustryCodeDescription.setChangeIndicator(RefDataPropertiesConstants.WQ_REVIEW_RECORD_NO_CHANGE);
				mergeIndustryCodeDescriptions.add(stgIndustryCodeDescription);
			}
		}
		LOGGER.info("exiting IndustryCodesServiceImpl | mergeIndustryCodeDescriptions");
		return mergeIndustryCodeDescriptions;
	}

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 *
	 * @param domainId
	 * @return isSaveSuccess
	 */
	@Override
	@Transactional("stgTransactionManager")
	public Long saveApprovedIndustryCodes(Long domainId) {
		LOGGER.info("entering IndustryCodesServiceImpl | saveApprovedIndustryCodes");
		// Retrieve the IndustryCode details from the Work flow tracking table
		IndustryCode industryCode = retrieveIndustryCodeByDomainId(domainId);

		// Updates the IndustryCode details to the Staging SoR
		stagingDAO.updateIndustryCode(industryCode);
		
		List<SavedRecord> savedRecords = retrieveSavedRecords(
				null, RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE, domainId,null);
		removeIndustryCodeDescriptions(industryCode.getIndustryCodeDescriptions(), savedRecords);
		removeIndustryCodeMaps(industryCode.getIndustryCodeMaps(), savedRecords);
		LOGGER.info("exiting IndustryCodesServiceImpl | saveApprovedIndustryCodes");
		return industryCode.getIndustryCodeId();
	}

	/**
	 * The method will remove the industryCode data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param industryCodeId
	 * @param boolean indicating the status
	 */
	@Override
	@Transactional("txnTransactionManager")
	public void removeApprovedIndustryCode(Long industryCodeId) {
		transactionalDAO.removeApprovedIndustryCode(industryCodeId);
	}
	/**
	 * The method will search the Staging SoR for the IndustryCode based on the
	 * domainId and will return the IndustryCode entity.
	 *
	 * @param domainId
	 */
	@Override
	@Transactional("stgTransactionManager")
	public IndustryCode retrieveIndustryCodeByDomainId(Long domainId) {

		LOGGER.info("entering IndustryCodesServiceImpl | retrieveIndustryCodeByDomainId");
		IndustryCode industryCode = transactionalDAO
				.retrieveIndustryCodeByIndustryCodeId(domainId);
		LOGGER.info("IndustryCode : " + industryCode);
		return industryCode;
	}
	
	/**
	 * The method will add UiBulkDownload data  in the
	 * Transactional DB. 
	 * 
	 * @param UiBulkDownload
	 * @return id
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Long addUIBulkDownload(UiBulkDownload uiBulkDownload) {
		return transactionalDAO.addUIBulkDownload(uiBulkDownload);
	}
	
	/**
	 * The method will search the Staging SoR for the UiBulkDownload based on the
	 * userId and will return the UiBulkDownload entity.
	 * 
	 * @param userId
	 */
	@Override
	@Transactional("txnTransactionManager")
	public List<UiBulkDownload> retrieveUIBulkDownload(String userId) {

		LOGGER.info("entering IndustryCodesServiceImpl | retrieveUIBulkDownload");
		List<UiBulkDownload> uiBulkDownloadList = transactionalDAO.retrieveUIBulkDownload(userId);
		LOGGER.info("exiting IndustryCodesServiceImpl | retrieveUIBulkDownload");
		return uiBulkDownloadList;
	}

	/**
	 * 
	 * The method to delete an existing Industry Code. The data will be saved in
	 * the temp table. For Industry code the delete operation is a hard delete.
	 * 
	 * @param industryCodeId
	 * @param deletedUser
	 * @return isSuccess
	 */
	@Override
	@Transactional("txnTransactionManager")
	public Boolean deleteIndustryCode(Long industryCodeId, String deletedUser) {
		LOGGER.info("entering IndustryCodesServiceImpl | deleteIndustryCode");
		Long savedRecordId = transactionalDAO.insertSavedRecord(populateSavedRecord(industryCodeId,
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE,
						RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_INDUSTRY_CODE, deletedUser, null));
		return savedRecordId != null ? true : false;
	}
	
	/**
	 * The method will remove the industryCode data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 * 
	 * @param industryCodeId
	 */
	@Override
	@Transactional("stgTransactionManager")
	public void removeApprovedIndustryCodeFromStaging(Long industryCodeId) {
		LOGGER.info("entering IndustryCodesServiceImpl | removeApprovedIndustryCodeFromStaging");
		stagingDAO.removeApprovedIndustryCodeFromStaging(industryCodeId);
		LOGGER.info("exiting IndustryCodesServiceImpl | removeApprovedIndustryCodeFromStaging");
	}
	
	/**
	 * The method will remove the industryCode data from the Transaction DB
	 * Saved Record. The method will be invoked when the business owner approves
	 * a change and the respective changes have been updated in the Txn SoR.
	 * 
	 * @param industryCodeId
	 * @param boolean indicating the status
	 */
	@Override
	@Transactional("txnTransactionManager")
	public void removeSavedRecord(Long industryCodeId) {
		transactionalDAO.removeSavedRecord(industryCodeId);
	}
	
	/**
	 * 
	 * The method to populate the savedRecord entity
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param deletedUser
	 * @param userComment
	 * @return savedRecord
	 */
	@Override
	public SavedRecord populateSavedRecord(Long domainId, String domainName, String changeType, String deletedUser, 
			String userComment) {
		SavedRecord savedRecord = new SavedRecord();
		savedRecord.setUserId(deletedUser);
		savedRecord.setDomainId(domainId);
		savedRecord.setDomainName(domainName);
		savedRecord.setChangeTypeCode(Long.valueOf(changeType));
		savedRecord.setCreatedDate(new Date());
		savedRecord.setUserComment(userComment);
		LOGGER.info("savedRecord : " + savedRecord);
		return savedRecord;
	}
	
	/**
	 * 
	 * The method to retrieve the savedRecords based on domainName and domain
	 * Identifier
	 * 
	 * @param userId
	 * @param domainName
	 * @param domainId
	 * @return savedRecords
	 */
	@Override
	public List<SavedRecord> retrieveSavedRecords(String userId, String domainName, Long domainId,String userComment) {
		return transactionalDAO.retrieveSavedRecords(userId, domainName, domainId,userComment);
	}
	
	/**
	 * 
	 * The method to check whether a full delete is saved in the txn DB for the specified domain Id
	 *
	 * @param savedRecords
	 * @param domainId
	 * @param domainName
	 * @param subDomainId
	 * @param subDomainName
	 * @param isFullDeleteRequired
	 * @return isDelete
	 */
	private Boolean isDeletedSavedRecord(List<SavedRecord> savedRecords, String domainId, String domainName, 
			String subDomainId, String subDomainName, boolean isFullDeleteRequired) {
		Boolean isDelete = false;
		
		if(savedRecords != null) {
			// If check is to identify the full entity delete
			if(isFullDeleteRequired) {
				for(SavedRecord savedRecord : savedRecords) {
					if(RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_INDUSTRY_CODE.equals(
							String.valueOf(savedRecord.getChangeTypeCode()))) {
						isDelete = true;
						break;
					}
				}
			} else {
				for(SavedRecord savedRecord : savedRecords) {
					String[] userComments = savedRecord.getUserComment().split("#");
					for(int indx = 0; indx < userComments.length; indx++) {
						LOGGER.info("userComments[" + indx + "] : " + userComments[indx]);
						if(userComments[indx] != null) {
							String[] domainDtls = userComments[indx].split(":");
							LOGGER.info("domainDtls[0] : " + domainDtls[0] + "| domainDtls[1] : " + domainDtls[1]);
							if(subDomainName.equals(domainDtls[0]) && subDomainId.equals(domainDtls[1])) {
								isDelete = true;
								break;
							}
						}
					}
				}
			}
		}
		return isDelete;
	}
	
	/**
	 * 
	 * The method to remove the deleted Industry Code Descriptions from the Staging DB
	 *
	 * @param industryCodeDescs
	 * @param savedRecords
	 */
	private void removeIndustryCodeDescriptions(List<IndustryCodeDescription> industryCodeDescs, 
			List<SavedRecord> savedRecords) {
		LOGGER.info("entering IndustryCodesServiceImpl | removeIndustryCodeDescriptions");
		if(industryCodeDescs != null) {
			for(IndustryCodeDescription industryCodeDesc : industryCodeDescs) {
				if(isDeletedSavedRecord(savedRecords, String.valueOf(industryCodeDesc.getIndustryCodeId()), 
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE, 
						String.valueOf(industryCodeDesc.getIndustryCodeDescriptionId()), "INDSCODEDESC", false)) {

					stagingDAO.removeIndustryCodeDescription(industryCodeDesc.getIndustryCodeDescriptionId());
				}
			}
		}
		LOGGER.info("exiting IndustryCodesServiceImpl | removeIndustryCodeDescriptions");
	}
	/**
	 * 
	 * The method to remove the deleted Industry Code Descriptions from the Staging DB
	 *
	 * @param industryCodeDescs
	 * @param savedRecords
	 */
	private void removeIndustryCodeMaps(List<IndustryCodeMap> industryCodeMaps, 
			List<SavedRecord> savedRecords) {
		LOGGER.info("entering IndustryCodesServiceImpl | removeIndustryCodeDescriptions");
		if(industryCodeMaps != null) {
			for(IndustryCodeMap industryCodeMap : industryCodeMaps) {
				if(isDeletedSavedRecord(savedRecords, String.valueOf(industryCodeMap.getIndustryCodeMapPK().getFromIndustryCodeId()), 
						RefDataPropertiesConstants.DOMAIN_CODE_INDUSTRY_CODE, 
						String.valueOf(industryCodeMap.getIndustryCodeMapPK().getToIndustryCodeId()), "INDSCODEMAP", false)) {

					stagingDAO.removeIndustryCodeMap(
							industryCodeMap.getIndustryCodeMapPK().getFromIndustryCodeId(), 
							industryCodeMap.getIndustryCodeMapPK().getToIndustryCodeId());
				}
			}
		}
		LOGGER.info("exiting IndustryCodesServiceImpl | removeIndustryCodeDescriptions");
	}
	
	/**
	 * 
	 * The method to populate the last modified user details to the Industry Code. 
	 *
	 * @param industryCode
	 * @param savedRecords
	 */
	private void populateLastModifiedDetails(IndustryCode industryCode, List<SavedRecord> savedRecords) {
		for(SavedRecord savedRecord : savedRecords) {
			if (RefDataChangeTypeConstants.CHANGE_TYPE_DELETE_INDUSTRY_CODE.equals(
					String.valueOf(savedRecord.getChangeTypeCode())) && savedRecord.getDomainId().equals(
							industryCode.getIndustryCodeId())) {
				industryCode.setModifiedDate(savedRecord.getCreatedDate());
				industryCode.setModifiedUser(savedRecord.getUserId());
			}
		}
	}
	/**
	 * This method counts the IndustryCodeDescription  in the Staging DB to identify any duplicates
	 *
	 * @param industryCodeId
	 * @param industryCodeTypeCode
	 * @return count
	 */
	@Override
	public Boolean countIndustryCodeDescriptionForDuplicate(String industryCode,
			Long industryCodeTypeCode, String industryDescription) {
		LOGGER.info("entering IndustryCodesServiceImpl | countIndustryCodeDescriptionForDuplicate");
		int count =stagingDAO.countIndustryCodeDescriptionForDuplicate(industryCode, industryCodeTypeCode,industryDescription);
		return count == 0 ? false : true;
	}
	
	/**
	 * 
	 * The method to insert the saved record transaction to the ui_svd_rec
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param deletedUser
	 * @param userComment
	 * @return
	 */
	@Override
	@Transactional("txnTransactionManager")
	public SavedRecord insertSavedRecord(Long domainId, String domainName,
			String changeType, String deletedUser, String userComment) {
		LOGGER.info("entering IndustryCodesServiceImpl | insertSavedRecord");
		SavedRecord savedRecord = populateSavedRecord(domainId, domainName,
				changeType, deletedUser, userComment);
		Long savedRecordId = transactionalDAO.insertSavedRecord(savedRecord);
		
		savedRecord.setSavedRecordId(savedRecordId);		
		LOGGER.info("savedRecord " + savedRecord);
		LOGGER.info("exiting IndustryCodesServiceImpl | insertSavedRecord");
		return savedRecord;
	}
	
	/**
	 * 
	 * The method will retrieve the Industry code data for all the tables given
	 * as parameter from the Staging SoR. The input will be Code Table ID of the
	 * Industry Code Type table. This method will be invoked only for search as
	 * this will fetch only the existing industry code types from inds_code
	 * table.
	 * 
	 * @param indsCodeTableId
	 * @return
	 */
	public Map<String, List<CodeValue>> retrieveIndustryCodeValues(Long indsCodeTableId) {
		LOGGER.info("entering IndustryCodesServiceImpl | retrieveIndustryCodeValues");
		List<CodeValue> codeValues = scotsStagingDAO.retrieveIndustryCodeValues(indsCodeTableId);
		LOGGER.info("retrieveIndustryCodeValues codeValues " + codeValues);
		
		Map<String, List<CodeValue>> resultMap = new HashMap<String, List<CodeValue>>();
		resultMap.put(String.valueOf(indsCodeTableId), codeValues);
		LOGGER.info("exiting IndustryCodesServiceImpl | retrieveIndustryCodeValues");
		return resultMap;
	}

	/**
	 * This method will retrieve all the crosswalks available with respective count of each crosswalk
	 * @return
	 */
	@Override
	@Transactional("stgTransactionManager")
	public List<InduscodeMappingBulkDownloadVO> retrieveCrosswalkDetails() {
		LOGGER.info("entering IndustryCodesServiceImpl | retrieveCrosswalkDetails");			
		return stagingDAO.retrieveCrosswalkDetails();
	}
}
