/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.entity.GeoCurrency;
import com.dnb.dsc.refdata.core.vo.AddGeoCurrencyVO;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.CurrencySearchCriteriaVO;
import com.dnb.dsc.refdata.core.vo.GeoCurrencySearchVO;


/**
 * This is used as the service interface for the Currency Exchange operations
 * 
 * @author Cognizant
 * @version last updated : Feb 29, 2012
 * @see
 * 
 */
public interface CurrencyService {

	/**
	 * 
	 * Performs a hierarchy search of Currency Exchange on the search db.<p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param currencySearchCriteria
	 * @return list of CurrencyExchange
	 */
	List<CurrencyExchange> searchCurrencyExchange(CurrencySearchCriteriaVO currencySearchCriteria);

	/**
	 * The method to retrieve all data providers for the currency exchange data.
	 * The data will be fetched from the currency exchange tables.
	 * 
	 * @param languageCode
	 */
	List<CodeValueVO> retrieveCurcyExchDataProviders(Long languageCode);
	
	/**
	 * 
	 * The method will count the records in the hierarchy search of currencies on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return countResults
	 */
	Long countSearchCurrencyExchange(CurrencySearchCriteriaVO searchCriteriaVO);
	
	/**
	 * The method will persist the existing Currency Exchange data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param currencyExchange
	 */
	Long updateExchangeRate(CurrencyExchange currencyExchange);

	/**
	 * The method will validate the Currency Exchange for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param geoUnitId
	 */
	String lockCurrencyExchange(Long currencyExchangeId);

        /**
	 * Invokes when the the business owner reviews the
	 * changes submitted for his approval. <p>
	 * The user reviews the changes and he could approve or reject the request. The method will fetch the details
	 * from Staging SoR and Transaction DB to merge and form the CurrencyExchange for review.<p>
	 * 
	 * @param trackingId
	 * @return currencyExchange
	 */
	CurrencyExchange reviewCurrencyExchangeChanges(Long trackingId);
	
	/**
	 * Retrieves the CurrencyExchange based on the Work-flow Tracking Id.
	 * Invoked from the Work-flow Component and the search
	 * will be performed on the Transactional DB.<p>
	 * 
	 * @param trackingId
	 * @return CurrencyExchange
	 */
	CurrencyExchange retrieveCurrencyExchangeByTrackingId(Long trackingId);
	
	/**
	 * The method will search the Staging SoR for the CurrencyExchange based on the 
	 * currencyExchangeId and will return the GeoUnit entity.<p>
	 * 
	 * @param currencyExchangeId
	 * @return CurrencyExchange
	 */
	CurrencyExchange retrieveCurrencyExchangeByCurrencyExchangeId(Long currencyExchangeId);

	/**
	 * The method will search the Transaction SoR for the CurrencyExchange based
	 * on the currencyExchangeId and will return the GeoUnit entity.
	 * <p>
	 * 
	 * @param currencyExchangeId
	 * @return CurrencyExchange
	 */
	CurrencyExchange retrieveTxnCurrencyExchangeById(Long currencyExchangeId);
	
	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 * 
	 * @param domainId
	 * @return isSaveSuccess
	 */
	Long saveApprovedCurrencyExchanges(Long domainId);
	
	/**
	 * The method will remove the crcyExch data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 * 
	 * @param currencyExchId
	 * @param boolean indicating the status
	 */
	void removeApprovedCurrencyExchange(Long currencyExchId);

	/**
	 * 
	 * Performs a hierarchy search of Geo Currency on the SOR db.<p>
	 * 
	 * The search will be done on the db based on the search criteria the
	 * user had provided.
	 * 
	 * @param geoCurrencySearchVO
	 * @return list of GeoCurrency
	 */
	List<GeoCurrency> searchGeoCurrency(
			GeoCurrencySearchVO geoCurrencySearchVO);

	/**
	 * 
	 * The method will count the records in the geo currency table based on
	 * user inputs in db. The search will be done on the SOR db based on
	 * the search criteria the user had provided.
	 * 
	 * @param geoCurrencySearchVO
	 * @return countResults
	 */
	Long countSearchGeoCurrency(GeoCurrencySearchVO geoCurrencySearchVO);

	/**
	 * @param addGeoCurrencyVO
	 * @return
	 */
	Long insertGeoCurrency(AddGeoCurrencyVO addGeoCurrencyVO);
	
	GeoCurrency reviewGeoCurrency(Long geoCurrencyId);

	Long updateGeoCurrency(GeoCurrency geoCurrency);
}
