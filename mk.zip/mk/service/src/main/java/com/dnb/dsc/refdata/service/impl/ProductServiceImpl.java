package com.dnb.dsc.refdata.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.MarketGroup;
import com.dnb.dsc.refdata.core.entity.ProdRescScrGru;
import com.dnb.dsc.refdata.core.entity.Product;
import com.dnb.dsc.refdata.core.entity.ProductAvailability;
import com.dnb.dsc.refdata.core.entity.ProductDetails;
import com.dnb.dsc.refdata.core.entity.ProductGroup;
import com.dnb.dsc.refdata.core.entity.ProductMarket;
import com.dnb.dsc.refdata.core.entity.Resource;
import com.dnb.dsc.refdata.core.entity.ResourceDetails;
import com.dnb.dsc.refdata.core.entity.ResourceGroup;
import com.dnb.dsc.refdata.core.entity.ResourceMapping;
import com.dnb.dsc.refdata.core.entity.SalesChannel;
import com.dnb.dsc.refdata.core.entity.SalesChannelDetails;
import com.dnb.dsc.refdata.core.entity.Score;
import com.dnb.dsc.refdata.core.vo.AddNewProductsVO;
import com.dnb.dsc.refdata.core.vo.ProductMetaData;
import com.dnb.dsc.refdata.core.vo.ProductResources;
import com.dnb.dsc.refdata.core.vo.ProductScoreMappingVO;
import com.dnb.dsc.refdata.core.vo.ProductScoreReportVO;
import com.dnb.dsc.refdata.core.vo.ProductSearchVO;
import com.dnb.dsc.refdata.core.vo.ProductVO;
import com.dnb.dsc.refdata.core.vo.ResourceMetadataVO;
import com.dnb.dsc.refdata.core.vo.SalesMetadataVO;
import com.dnb.dsc.refdata.core.vo.ScoreMappingListVO;
import com.dnb.dsc.refdata.dao.ProductStagingDAO;
import com.dnb.dsc.refdata.service.ProductService;

@Service("ProductService")
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductStagingDAO stagingDAO;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ProductServiceImpl.class);

	@Override
	public List<CodeValue> retrieveProductTypeCodeValues(
			ProductVO productSearchVO) {
		List<CodeValue> codeValues = stagingDAO
				.retrieveProductTypeCodeValues(productSearchVO);
		return codeValues;
	}

	@Override
	public List<CodeValue> retrieveResourceTypeCodeValues(
			ProductVO productSearchVO) {
		List<CodeValue> codeValues = stagingDAO
				.retrieveResourceTypeCodeValues(productSearchVO);
		return codeValues;
	}

	public static <T extends Object> List<List<T>> split(List<T> list,
			int targetSize) {
		List<List<T>> lists = new ArrayList<List<T>>();
		for (int i = 0; i < list.size(); i += targetSize) {
			lists.add(list.subList(i, Math.min(i + targetSize, list.size())));
		}
		return lists;
	}

	@Transactional("stgTransactionManager")
	public Long countSearchProduct(ProductSearchVO productSearchVO) {
		String query = "";
		int targetSize = 999;
		String[] mktCd = productSearchVO.getMkt_cd().split(",");
		List<String> mktCdList = new ArrayList<String>(Arrays.asList(mktCd));

		List<List<String>> lists = split(mktCdList, targetSize);
		String strMktCd = "";
		String orVal = "OR";
		String append = " PROD_MKT.MKT_CD in (";
		String end = ") ";
		for (List<String> lis : lists) {
			String[] val = lis.toArray(new String[lis.size()]);
			String valStr = Arrays.toString(val);
			valStr = valStr.replace("[", "").replace("]", "");
			if (strMktCd.equalsIgnoreCase("")) {
				strMktCd = strMktCd + " PROD_MKT.MKT_CD in (" + valStr + ") ";
			} else if (valStr.length() > 0) {
				strMktCd = strMktCd + orVal + append + valStr + end;
			}
		}

		//
		String[] product_cd = productSearchVO.getProduct_cd().split(",");
		List<String> product_cdList = new ArrayList<String>(
				Arrays.asList(product_cd));

		List<List<String>> lisrts = split(product_cdList, targetSize);
		String productcd = "";
		String appendproduct_cd = " PROD_CD in (";
		for (List<String> lis : lisrts) {
			String[] val = lis.toArray(new String[lis.size()]);
			String valStr = Arrays.toString(val);
			valStr = valStr.replace("[", "").replace("]", "");
			if (productcd.equalsIgnoreCase("")) {
				productcd = productcd + " PROD_CD in (" + valStr + ") ";
			} else if (valStr.length() > 0) {
				productcd = productcd + orVal + appendproduct_cd + valStr + end;
			}
		}
		//

		//
		String[] resc_cd = null;
		List<String> resc_cdList = null;
		String resccd = "";
		if ((productSearchVO.getResc_cd() != null)) {
			resc_cd = productSearchVO.getResc_cd().split(",");
			resc_cdList = new ArrayList<String>(Arrays.asList(resc_cd));

			List<List<String>> lisrs = split(resc_cdList, targetSize);

			String appendresc_cd = " RESC.RESC_CD in (";
			for (List<String> lis : lisrs) {
				String[] val = lis.toArray(new String[lis.size()]);
				String valStr = Arrays.toString(val);
				valStr = valStr.replace("[", "").replace("]", "");
				if (resccd.equalsIgnoreCase("")) {
					resccd = resccd + " RESC.RESC_CD in (" + valStr + ") ";
				} else if (valStr.length() > 0) {
					resccd = resccd + orVal + appendresc_cd + valStr + end;
				}
			}
		}

		if ((!(productSearchVO.getResc_cd() != null))
				|| ((("").equalsIgnoreCase(productSearchVO.getResc_cd())))) {

			query = "SELECT count(*) as cnt   from CD_VAL_TXT,  (SELECT   subquery17.prodAvailId,subquery17.saleChnlid,subquery17.prodMktId,  subquery17.mktCd,  subquery17.prodId,subquery17.prodFamCd,  subquery17.prodCd,subquery17.prodInacIndc,subquery17.prodVers,subquery17.rescMapId,  subquery17.rescId,subquery17.bilgSysCd,subquery17.rescVers,  subquery17.rescCd,subquery17.rescTypCd,subquery17.bilgSysTypCd,  subquery17.countryCode,  subquery17.countryDesc,subquery17.productCode,subquery17.prodCodeShrtDesc,  subquery17.prodCodeDesc,  subquery17.rescCode,subquery17.rescCodeShrtDesc,subquery17.rescCodeDesc,subquery17.prodGrpId,subquery17.prodGrpCd,  subquery17.prodDtlId,subquery17.prodDtlMtdtCd,subquery17.prodDtlMtdCdVal,  subquery17.mktGrpId,subquery17.mktGrpCd,  subquery17.rescGrpId,subquery17.rescGrpCd,  subquery17.rescDtlID,subquery17.rescDtlMtdtCd,subquery17.rescMtdtVal,  subquery17.slsChnlDtlID,subquery17.slsChnlDtlMtdtCd,  subquery17.slsChnlDtlMtdtVal,  subquery17.prodGrpCdShrtDesc,subquery17.prodGrpCdDesc,  subquery17.prodDtlMtdtCdShrtDesc,subquery17.prodDtlMtdtCdDesc,  subquery17.mktGrpCdShrtDesc,subquery17.mktGrpCdDesc,  subquery17.rescGrpCdShrtDesc,subquery17.rescGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery16.prodAvailId,subquery16.saleChnlid,subquery16.prodMktId,  subquery16.mktCd,  subquery16.prodId,subquery16.prodFamCd,  subquery16.prodCd,subquery16.prodInacIndc,subquery16.prodVers,subquery16.rescMapId,  subquery16.rescId,subquery16.bilgSysCd,subquery16.rescVers,  subquery16.rescCd,subquery16.rescTypCd,subquery16.bilgSysTypCd,  subquery16.countryCode,  subquery16.countryDesc,subquery16.productCode,subquery16.prodCodeShrtDesc,  subquery16.prodCodeDesc,  subquery16.rescCode,subquery16.rescCodeShrtDesc,subquery16.rescCodeDesc,subquery16.prodGrpId,subquery16.prodGrpCd,  subquery16.prodDtlId,subquery16.prodDtlMtdtCd,subquery16.prodDtlMtdCdVal,  subquery16.mktGrpId,subquery16.mktGrpCd,  subquery16.rescGrpId,subquery16.rescGrpCd,  subquery16.rescDtlID,subquery16.rescDtlMtdtCd,subquery16.rescMtdtVal,  subquery16.slsChnlDtlID,subquery16.slsChnlDtlMtdtCd,  subquery16.slsChnlDtlMtdtVal,  subquery16.prodGrpCdShrtDesc,subquery16.prodGrpCdDesc,  subquery16.prodDtlMtdtCdShrtDesc,subquery16.prodDtlMtdtCdDesc,  subquery16.mktGrpCdShrtDesc,subquery16.mktGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescGrpCdDesc  from CD_VAL_TXT,  (SELECT   subquery15.prodAvailId,subquery15.saleChnlid,subquery15.prodMktId,  subquery15.mktCd,  subquery15.prodId,subquery15.prodFamCd,  subquery15.prodCd,subquery15.prodInacIndc,subquery15.prodVers,subquery15.rescMapId,  subquery15.rescId,subquery15.bilgSysCd,subquery15.rescVers,  subquery15.rescCd,subquery15.rescTypCd,subquery15.bilgSysTypCd,  subquery15.countryCode,  subquery15.countryDesc,subquery15.productCode,subquery15.prodCodeShrtDesc,  subquery15.prodCodeDesc,  subquery15.rescCode,subquery15.rescCodeShrtDesc,subquery15.rescCodeDesc,subquery15.prodGrpId,subquery15.prodGrpCd,  subquery15.prodDtlId,subquery15.prodDtlMtdtCd,subquery15.prodDtlMtdCdVal,  subquery15.mktGrpId,subquery15.mktGrpCd,  subquery15.rescGrpId,subquery15.rescGrpCd,  subquery15.rescDtlID,subquery15.rescDtlMtdtCd,subquery15.rescMtdtVal,  subquery15.slsChnlDtlID,subquery15.slsChnlDtlMtdtCd,  subquery15.slsChnlDtlMtdtVal,  subquery15.prodGrpCdShrtDesc,subquery15.prodGrpCdDesc,  subquery15.prodDtlMtdtCdShrtDesc,subquery15.prodDtlMtdtCdDesc,   GEO_UNIT_NME.GEO_NME as mktGrpCdShrtDesc, GEO_UNIT_NME.GEO_NME as mktGrpCdDesc  from GEO_UNIT_NME, GEO_UNIT,  (SELECT   subquery14.prodAvailId,subquery14.saleChnlid,subquery14.prodMktId,  subquery14.mktCd,  subquery14.prodId,subquery14.prodFamCd,  subquery14.prodCd,subquery14.prodInacIndc,subquery14.prodVers,subquery14.rescMapId,  subquery14.rescId,subquery14.bilgSysCd,subquery14.rescVers,  subquery14.rescCd,subquery14.rescTypCd,subquery14.bilgSysTypCd,  subquery14.countryCode,  subquery14.countryDesc,subquery14.productCode,subquery14.prodCodeShrtDesc,  subquery14.prodCodeDesc,  subquery14.rescCode,subquery14.rescCodeShrtDesc,subquery14.rescCodeDesc,subquery14.prodGrpId,subquery14.prodGrpCd,  subquery14.prodDtlId,subquery14.prodDtlMtdtCd,subquery14.prodDtlMtdCdVal,  subquery14.mktGrpId,subquery14.mktGrpCd,  subquery14.rescGrpId,subquery14.rescGrpCd,  subquery14.rescDtlID,subquery14.rescDtlMtdtCd,subquery14.rescMtdtVal,  subquery14.slsChnlDtlID,subquery14.slsChnlDtlMtdtCd,  subquery14.slsChnlDtlMtdtVal,  subquery14.prodGrpCdShrtDesc,subquery14.prodGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery13.prodAvailId,subquery13.saleChnlid,subquery13.prodMktId,  subquery13.mktCd,  subquery13.prodId,subquery13.prodFamCd,  subquery13.prodCd,subquery13.prodInacIndc,subquery13.prodVers,subquery13.rescMapId,  subquery13.rescId,subquery13.bilgSysCd,subquery13.rescVers,  subquery13.rescCd,subquery13.rescTypCd,subquery13.bilgSysTypCd,  subquery13.countryCode,  subquery13.countryDesc,subquery13.productCode,subquery13.prodCodeShrtDesc,  subquery13.prodCodeDesc,  subquery13.rescCode,subquery13.rescCodeShrtDesc,subquery13.rescCodeDesc,subquery13.prodGrpId,subquery13.prodGrpCd,  subquery13.prodDtlId,subquery13.prodDtlMtdtCd,subquery13.prodDtlMtdCdVal,  subquery13.mktGrpId,subquery13.mktGrpCd,  subquery13.rescGrpId,subquery13.rescGrpCd,  subquery13.rescDtlID,subquery13.rescDtlMtdtCd,subquery13.rescMtdtVal,  subquery13.slsChnlDtlID,subquery13.slsChnlDtlMtdtCd,  subquery13.slsChnlDtlMtdtVal,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodGrpCdDesc  from CD_VAL_TXT,  ( SELECT   subquery12.prodAvailId,subquery12.saleChnlid,subquery12.prodMktId,  subquery12.mktCd,  subquery12.prodId,subquery12.prodFamCd,  subquery12.prodCd,subquery12.prodInacIndc,subquery12.prodVers,subquery12.rescMapId,  subquery12.rescId,subquery12.bilgSysCd,subquery12.rescVers,  subquery12.rescCd,subquery12.rescTypCd,subquery12.bilgSysTypCd,  subquery12.countryCode,  subquery12.countryDesc,subquery12.productCode,subquery12.prodCodeShrtDesc,  subquery12.prodCodeDesc,  subquery12.rescCode,subquery12.rescCodeShrtDesc,subquery12.rescCodeDesc,subquery12.prodGrpId,subquery12.prodGrpCd,  subquery12.prodDtlId,subquery12.prodDtlMtdtCd,subquery12.prodDtlMtdCdVal,  subquery12.mktGrpId,subquery12.mktGrpCd,  subquery12.rescGrpId,subquery12.rescGrpCd,  subquery12.rescDtlID,subquery12.rescDtlMtdtCd,subquery12.rescMtdtVal,  SLS_CHNL_DTL.SLS_CHNL_DTL_ID as slsChnlDtlID,SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_CD as slsChnlDtlMtdtCd,  SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_VAL as slsChnlDtlMtdtVal  from SLS_CHNL_DTL,   (SELECT   subquery11.prodAvailId,subquery11.saleChnlid,subquery11.prodMktId,  subquery11.mktCd,  subquery11.prodId,subquery11.prodFamCd,  subquery11.prodCd,subquery11.prodInacIndc,subquery11.prodVers,subquery11.rescMapId,  subquery11.rescId,subquery11.bilgSysCd,subquery11.rescVers,  subquery11.rescCd,subquery11.rescTypCd,subquery11.bilgSysTypCd,  subquery11.countryCode,  subquery11.countryDesc,subquery11.productCode,subquery11.prodCodeShrtDesc,  subquery11.prodCodeDesc,  subquery11.rescCode,subquery11.rescCodeShrtDesc,subquery11.rescCodeDesc,subquery11.prodGrpId,subquery11.prodGrpCd,  subquery11.prodDtlId,subquery11.prodDtlMtdtCd,subquery11.prodDtlMtdCdVal,  subquery11.mktGrpId,subquery11.mktGrpCd,  subquery11.rescGrpId,subquery11.rescGrpCd,  RESC_DTL.RESC_DTL_ID as rescDtlID,RESC_DTL.RESC_DTL_MTDT_CD as rescDtlMtdtCd,RESC_DTL.RESC_MTDT_VAL as rescMtdtVal  from RESC_DTL,  (SELECT   subquery10.prodAvailId,subquery10.saleChnlid,subquery10.prodMktId,  subquery10.mktCd,  subquery10.prodId,subquery10.prodFamCd,  subquery10.prodCd,subquery10.prodInacIndc,subquery10.prodVers,subquery10.rescMapId,  subquery10.rescId,subquery10.bilgSysCd,subquery10.rescVers,  subquery10.rescCd,subquery10.rescTypCd,subquery10.bilgSysTypCd,  subquery10.countryCode,  subquery10.countryDesc,subquery10.productCode,subquery10.prodCodeShrtDesc,  subquery10.prodCodeDesc,  subquery10.rescCode,subquery10.rescCodeShrtDesc,subquery10.rescCodeDesc,subquery10.prodGrpId,subquery10.prodGrpCd,  subquery10.prodDtlId,subquery10.prodDtlMtdtCd,subquery10.prodDtlMtdCdVal,  subquery10.mktGrpId,subquery10.mktGrpCd,  RESC_GRP.RESC_GRP_ID as rescGrpId,RESC_GRP.RESC_GRP_CD as rescGrpCd  from RESC_GRP,  (SELECT   subquery9.prodAvailId,"
					+ " subquery9.saleChnlid,subquery9.prodMktId,  subquery9.mktCd,  subquery9.prodId,subquery9.prodFamCd,  subquery9.prodCd,subquery9.prodInacIndc,subquery9.prodVers,subquery9.rescMapId,  subquery9.rescId,subquery9.bilgSysCd,subquery9.rescVers,  subquery9.rescCd,subquery9.rescTypCd,subquery9.bilgSysTypCd,  subquery9.countryCode,  subquery9.countryDesc,subquery9.productCode,subquery9.prodCodeShrtDesc,  subquery9.prodCodeDesc,  subquery9.rescCode,subquery9.rescCodeShrtDesc,subquery9.rescCodeDesc,subquery9.prodGrpId,subquery9.prodGrpCd,  subquery9.prodDtlId,subquery9.prodDtlMtdtCd,subquery9.prodDtlMtdCdVal,  MKT_GRP.MKT_GRP_ID as mktGrpId,MKT_GRP.MKT_GRP_CD as mktGrpCd  from MKT_GRP,  ( SELECT   subquery8.prodAvailId,subquery8.saleChnlid,subquery8.prodMktId,  subquery8.mktCd,  subquery8.prodId,subquery8.prodFamCd,  subquery8.prodCd,subquery8.prodInacIndc,subquery8.prodVers,subquery8.rescMapId,  subquery8.rescId,subquery8.bilgSysCd,subquery8.rescVers,  subquery8.rescCd,subquery8.rescTypCd,subquery8.bilgSysTypCd,  subquery8.countryCode,  subquery8.countryDesc,subquery8.productCode,subquery8.prodCodeShrtDesc,  subquery8.prodCodeDesc,  subquery8.rescCode,subquery8.rescCodeShrtDesc,subquery8.rescCodeDesc,subquery8.prodGrpId,subquery8.prodGrpCd,  PROD_DTL.PROD_DTL_ID as prodDtlId,PROD_DTL.PROD_DTL_MTDT_CD as prodDtlMtdtCd,PROD_DTL.PROD_DTL_MTDT_VAL as prodDtlMtdCdVal  from PROD_DTL,  ( SELECT   subquery7.prodAvailId,subquery7.saleChnlid,subquery7.prodMktId,  subquery7.mktCd,  subquery7.prodId,subquery7.prodFamCd,  subquery7.prodCd,subquery7.prodInacIndc,subquery7.prodVers,subquery7.rescMapId,  subquery7.rescId,subquery7.bilgSysCd,subquery7.rescVers,  subquery7.rescCd,subquery7.rescTypCd,subquery7.bilgSysTypCd,  subquery7.countryCode,  subquery7.countryDesc,subquery7.productCode,subquery7.prodCodeShrtDesc,  subquery7.prodCodeDesc,  subquery7.rescCode,subquery7.rescCodeShrtDesc,subquery7.rescCodeDesc,PROD_GRP.prod_grp_id as prodGrpId,PROD_GRP.prod_grp_cd as prodGrpCd  from PROD_GRP,  (SELECT   subquery6.PROD_AVLBID as prodAvailId,subquery6.SLS_CHNL_ID as saleChnlid,subquery6.PROD_MKT_ID as prodMktId,  subquery6.MKT_CD as mktCd,  subquery6.PRODID as prodId,subquery6.PROD_FAM_CD as prodFamCd,  subquery6.PROD_CD as prodCd,subquery6.INAC_INDC as prodInacIndc,subquery6.PROD_VERS as prodVers,subquery6.RESC_MAP_ID as rescMapId,  subquery6.RESCID as rescId,subquery6.BILG_SYS_CODE as bilgSysCd,subquery6.RESC_VERS as rescVers,  subquery6.RESC_CD as rescCd,subquery6.RESC_TYP_CODE as rescTypCd,subquery6.BILG_SYS_TYP_CD as bilgSysTypCd,  subquery6.countryCode as countryCode,  subquery6.countryDesc as countryDesc,subquery6.productCode as productCode,subquery6.prodCodeShrtDesc as prodCodeShrtDesc,  subquery6.prodCodeDesc,  CD_VAL_TXT.CD_VAL_ID as rescCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as rescCodeShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescCodeDesc  from CD_VAL_TXT,  (SELECT   subquery5.PROD_AVLBID,subquery5.SLS_CHNL_ID,subquery5.PROD_MKT_ID,subquery5.MKT_CD,  subquery5.PRODID,subquery5.PROD_FAM_CD,subquery5.PROD_CD,subquery5.INAC_INDC,subquery5.PROD_VERS,subquery5.RESC_MAP_ID,  subquery5.RESCID,subquery5.BILG_SYS_CODE,subquery5.RESC_VERS,  subquery5.RESC_CD,subquery5.RESC_TYP_CODE,subquery5.BILG_SYS_TYP_CD,subquery5.countryCode,  subquery5.countryDesc,CD_VAL_TXT.CD_VAL_ID as productCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as prodCodeShrtDesc,  CD_VAL_TXT.CD_VAL_DESC as prodCodeDesc  from CD_VAL_TXT,  (SELECT   subquery4.PROD_AVLBID,subquery4.SLS_CHNL_ID,subquery4.PROD_MKT_ID,subquery4.MKT_CD,  subquery4.PRODID,subquery4.PROD_FAM_CD,subquery4.PROD_CD,subquery4.INAC_INDC,subquery4.PROD_VERS,subquery4.RESC_MAP_ID,  subquery4.RESCID,subquery4.BILG_SYS_CODE,subquery4.RESC_VERS,  subquery4.RESC_CD,subquery4.RESC_TYP_CODE,subquery4.BILG_SYS_TYP_CD,GEO_UNIT_NME.GEO_UNIT_ID as countryCode,  GEO_UNIT_NME.GEO_NME as countryDesc  from GEO_UNIT_NME ,  (SELECT   subquery3.PROD_AVLBID,subquery3.SLS_CHNL_ID,subquery3.PROD_MKT_ID,subquery3.MKT_CD,  subquery3.PRODID,subquery3.PROD_FAM_CD,subquery3.PROD_CD,subquery3.INAC_INDC,subquery3.PROD_VERS,subquery3.RESC_MAP_ID,  subquery3.RESC_ID as RESCID,RESC.RESC_ID,RESC.BILG_SYS_CODE,RESC.RESC_VERS,RESC.RESC_CD,RESC.RESC_TYP_CODE,RESC.BILG_SYS_TYP_CD   from RESC,  (SELECT   subquery2.PROD_AVLBID,subquery2.SLS_CHNL_ID,subquery2.PROD_MKT_ID,subquery2.MKT_CD,  subquery2.PRODID ,subquery2.PROD_FAM_CD,subquery2.PROD_CD,subquery2.INAC_INDC,subquery2.PROD_VERS,RESC_MAP.RESC_MAP_ID,  RESC_MAP.RESC_ID,RESC_MAP.PROD_ID from RESC_MAP,  (SELECT   PROD_AVLB.PROD_AVLB_ID,PROD_AVLB.PROD_ID,PROD_AVLB.SLS_CHNL_ID,PROD_MKT.PROD_MKT_ID,PROD_MKT.PROD_AVLB_ID as PROD_AVLBID,PROD_MKT.MKT_CD,  subquery1.PROD_ID as PRODID,subquery1.PROD_FAM_CD,subquery1.PROD_CD,subquery1.INAC_INDC,subquery1.PROD_VERS   from PROD_MKT,PROD_AVLB,(SELECT PROD_ID,PROD_FAM_CD,PROD_CD,INAC_INDC,PROD_VERS from PROD where    ("
					+ productcd
					+ ")"
					+ ") subquery1   WHERE PROD_MKT.PROD_AVLB_ID = PROD_AVLB.PROD_AVLB_ID and PROD_AVLB.PROD_ID = subquery1.PROD_ID and    ("
					+ strMktCd
					+ ")"
					+ ") subquery2  WHERE  RESC_MAP.PROD_ID = subquery2.PRODID) subquery3  WHERE subquery3.RESC_ID = RESC.RESC_ID ) subquery4  WHERE subquery4.MKT_CD = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32   order by GEO_UNIT_NME.GEO_NME) subquery5  WHERE subquery5.PROD_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null  order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6  WHERE subquery6.RESC_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7  WHERE subquery7.prodId = PROD_GRP.prod_id) subquery8  WHERE subquery8.prodId = PROD_DTL.prod_id) subquery9  WHERE subquery9.prodMktId = MKT_GRP.PROD_MKT_ID) subquery10  WHERE subquery10.rescId = RESC_GRP.RESC_ID) subquery11  WHERE subquery11.rescId = RESC_DTL.RESC_ID) subquery12  WHERE subquery12.saleChnlid = SLS_CHNL_DTL.SLS_CHNL_ID) subquery13  WHERE subquery13.prodGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery14  WHERE subquery14.prodDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery15  WHERE subquery15.mktGrpCd =  GEO_UNIT_NME.GEO_UNIT_ID and 1=1  and GEO_UNIT.GEO_UNIT_ID=GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and "
					+ " GEO_UNIT_NME.GEO_NME_TYP_CD = 32 and GEO_UNIT.GEO_UNIT_TYP_CD=130 order by GEO_UNIT_NME.GEO_NME) subquery16  WHERE subquery16.rescGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery17  WHERE subquery17.rescDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery18  WHERE subquery18.slsChnlDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC";

		} else {

			query = " SELECT count(*) as cnt   from CD_VAL_TXT,  (SELECT   subquery17.prodAvailId,subquery17.saleChnlid,subquery17.prodMktId,  subquery17.mktCd,  subquery17.prodId,subquery17.prodFamCd,  subquery17.prodCd,subquery17.prodInacIndc,subquery17.prodVers,subquery17.rescMapId,  subquery17.rescId,subquery17.bilgSysCd,subquery17.rescVers,  subquery17.rescCd,subquery17.rescTypCd,subquery17.bilgSysTypCd,  subquery17.countryCode,  subquery17.countryDesc,subquery17.productCode,subquery17.prodCodeShrtDesc,  subquery17.prodCodeDesc,  subquery17.rescCode,subquery17.rescCodeShrtDesc,subquery17.rescCodeDesc,subquery17.prodGrpId,subquery17.prodGrpCd,  subquery17.prodDtlId,subquery17.prodDtlMtdtCd,subquery17.prodDtlMtdCdVal,  subquery17.mktGrpId,subquery17.mktGrpCd,  subquery17.rescGrpId,subquery17.rescGrpCd,  subquery17.rescDtlID,subquery17.rescDtlMtdtCd,subquery17.rescMtdtVal,  subquery17.slsChnlDtlID,subquery17.slsChnlDtlMtdtCd,  subquery17.slsChnlDtlMtdtVal,  subquery17.prodGrpCdShrtDesc,subquery17.prodGrpCdDesc,  subquery17.prodDtlMtdtCdShrtDesc,subquery17.prodDtlMtdtCdDesc,  subquery17.mktGrpCdShrtDesc,subquery17.mktGrpCdDesc,  subquery17.rescGrpCdShrtDesc,subquery17.rescGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery16.prodAvailId,subquery16.saleChnlid,subquery16.prodMktId,  subquery16.mktCd,  subquery16.prodId,subquery16.prodFamCd,  subquery16.prodCd,subquery16.prodInacIndc,subquery16.prodVers,subquery16.rescMapId,  subquery16.rescId,subquery16.bilgSysCd,subquery16.rescVers,  subquery16.rescCd,subquery16.rescTypCd,subquery16.bilgSysTypCd,  subquery16.countryCode,  subquery16.countryDesc,subquery16.productCode,subquery16.prodCodeShrtDesc,  subquery16.prodCodeDesc,  subquery16.rescCode,subquery16.rescCodeShrtDesc,subquery16.rescCodeDesc,subquery16.prodGrpId,subquery16.prodGrpCd,  subquery16.prodDtlId,subquery16.prodDtlMtdtCd,subquery16.prodDtlMtdCdVal,  subquery16.mktGrpId,subquery16.mktGrpCd,  subquery16.rescGrpId,subquery16.rescGrpCd,  subquery16.rescDtlID,subquery16.rescDtlMtdtCd,subquery16.rescMtdtVal,  subquery16.slsChnlDtlID,subquery16.slsChnlDtlMtdtCd,  subquery16.slsChnlDtlMtdtVal,  subquery16.prodGrpCdShrtDesc,subquery16.prodGrpCdDesc,  subquery16.prodDtlMtdtCdShrtDesc,subquery16.prodDtlMtdtCdDesc,  subquery16.mktGrpCdShrtDesc,subquery16.mktGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescGrpCdDesc  from CD_VAL_TXT,  (SELECT   subquery15.prodAvailId,subquery15.saleChnlid,subquery15.prodMktId,  subquery15.mktCd,  subquery15.prodId,subquery15.prodFamCd,  subquery15.prodCd,subquery15.prodInacIndc,subquery15.prodVers,subquery15.rescMapId,  subquery15.rescId,subquery15.bilgSysCd,subquery15.rescVers,  subquery15.rescCd,subquery15.rescTypCd,subquery15.bilgSysTypCd,  subquery15.countryCode,  subquery15.countryDesc,subquery15.productCode,subquery15.prodCodeShrtDesc,  subquery15.prodCodeDesc,  subquery15.rescCode,subquery15.rescCodeShrtDesc,subquery15.rescCodeDesc,subquery15.prodGrpId,subquery15.prodGrpCd,  subquery15.prodDtlId,subquery15.prodDtlMtdtCd,subquery15.prodDtlMtdCdVal,  subquery15.mktGrpId,subquery15.mktGrpCd,  subquery15.rescGrpId,subquery15.rescGrpCd,  subquery15.rescDtlID,subquery15.rescDtlMtdtCd,subquery15.rescMtdtVal,  subquery15.slsChnlDtlID,subquery15.slsChnlDtlMtdtCd,  subquery15.slsChnlDtlMtdtVal,  subquery15.prodGrpCdShrtDesc,subquery15.prodGrpCdDesc,  subquery15.prodDtlMtdtCdShrtDesc,subquery15.prodDtlMtdtCdDesc,  GEO_UNIT_NME.GEO_NME as mktGrpCdShrtDesc,GEO_UNIT_NME.GEO_NME as mktGrpCdDesc  from GEO_UNIT_NME, GEO_UNIT,  (SELECT   subquery14.prodAvailId,subquery14.saleChnlid,subquery14.prodMktId,  subquery14.mktCd,  subquery14.prodId,subquery14.prodFamCd,  subquery14.prodCd,subquery14.prodInacIndc,subquery14.prodVers,subquery14.rescMapId,  subquery14.rescId,subquery14.bilgSysCd,subquery14.rescVers,  subquery14.rescCd,subquery14.rescTypCd,subquery14.bilgSysTypCd,  subquery14.countryCode,  subquery14.countryDesc,subquery14.productCode,subquery14.prodCodeShrtDesc,  subquery14.prodCodeDesc,  subquery14.rescCode,subquery14.rescCodeShrtDesc,subquery14.rescCodeDesc,subquery14.prodGrpId,subquery14.prodGrpCd,  subquery14.prodDtlId,subquery14.prodDtlMtdtCd,subquery14.prodDtlMtdCdVal,  subquery14.mktGrpId,subquery14.mktGrpCd,  subquery14.rescGrpId,subquery14.rescGrpCd,  subquery14.rescDtlID,subquery14.rescDtlMtdtCd,subquery14.rescMtdtVal,  subquery14.slsChnlDtlID,subquery14.slsChnlDtlMtdtCd,  subquery14.slsChnlDtlMtdtVal,  subquery14.prodGrpCdShrtDesc,subquery14.prodGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery13.prodAvailId,subquery13.saleChnlid,subquery13.prodMktId,  subquery13.mktCd,  subquery13.prodId,subquery13.prodFamCd,  subquery13.prodCd,subquery13.prodInacIndc,subquery13.prodVers,subquery13.rescMapId,  subquery13.rescId,subquery13.bilgSysCd,subquery13.rescVers,  subquery13.rescCd,subquery13.rescTypCd,subquery13.bilgSysTypCd,  subquery13.countryCode,  subquery13.countryDesc,subquery13.productCode,subquery13.prodCodeShrtDesc,  subquery13.prodCodeDesc,  subquery13.rescCode,subquery13.rescCodeShrtDesc,subquery13.rescCodeDesc,subquery13.prodGrpId,subquery13.prodGrpCd,  subquery13.prodDtlId,subquery13.prodDtlMtdtCd,subquery13.prodDtlMtdCdVal,  subquery13.mktGrpId,subquery13.mktGrpCd,  subquery13.rescGrpId,subquery13.rescGrpCd,  subquery13.rescDtlID,subquery13.rescDtlMtdtCd,subquery13.rescMtdtVal,  subquery13.slsChnlDtlID,subquery13.slsChnlDtlMtdtCd,  subquery13.slsChnlDtlMtdtVal,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodGrpCdDesc  from CD_VAL_TXT,  ( SELECT   subquery12.prodAvailId,subquery12.saleChnlid,subquery12.prodMktId,  subquery12.mktCd,  subquery12.prodId,subquery12.prodFamCd,  subquery12.prodCd,subquery12.prodInacIndc,subquery12.prodVers,subquery12.rescMapId,  subquery12.rescId,subquery12.bilgSysCd,subquery12.rescVers,  subquery12.rescCd,subquery12.rescTypCd,subquery12.bilgSysTypCd,  subquery12.countryCode,  subquery12.countryDesc,subquery12.productCode,subquery12.prodCodeShrtDesc,  subquery12.prodCodeDesc,  subquery12.rescCode,subquery12.rescCodeShrtDesc,subquery12.rescCodeDesc,subquery12.prodGrpId,subquery12.prodGrpCd,  subquery12.prodDtlId,subquery12.prodDtlMtdtCd,subquery12.prodDtlMtdCdVal,  subquery12.mktGrpId,subquery12.mktGrpCd,  subquery12.rescGrpId,subquery12.rescGrpCd,  subquery12.rescDtlID,subquery12.rescDtlMtdtCd,subquery12.rescMtdtVal,  SLS_CHNL_DTL.SLS_CHNL_DTL_ID as slsChnlDtlID,SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_CD as slsChnlDtlMtdtCd,  SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_VAL as slsChnlDtlMtdtVal  from SLS_CHNL_DTL,   (SELECT   subquery11.prodAvailId,subquery11.saleChnlid,subquery11.prodMktId,  subquery11.mktCd,  subquery11.prodId,subquery11.prodFamCd,  subquery11.prodCd,subquery11.prodInacIndc,subquery11.prodVers,subquery11.rescMapId,  subquery11.rescId,subquery11.bilgSysCd,subquery11.rescVers,  subquery11.rescCd,subquery11.rescTypCd,subquery11.bilgSysTypCd,  subquery11.countryCode,  subquery11.countryDesc,subquery11.productCode,subquery11.prodCodeShrtDesc,  subquery11.prodCodeDesc,  subquery11.rescCode,subquery11.rescCodeShrtDesc,subquery11.rescCodeDesc,subquery11.prodGrpId,subquery11.prodGrpCd,  subquery11.prodDtlId,subquery11.prodDtlMtdtCd,subquery11.prodDtlMtdCdVal,  subquery11.mktGrpId,subquery11.mktGrpCd,  subquery11.rescGrpId,subquery11.rescGrpCd,  RESC_DTL.RESC_DTL_ID as rescDtlID,RESC_DTL.RESC_DTL_MTDT_CD as rescDtlMtdtCd,RESC_DTL.RESC_MTDT_VAL as rescMtdtVal  from RESC_DTL,  (SELECT   subquery10.prodAvailId,subquery10.saleChnlid,subquery10.prodMktId,  subquery10.mktCd,  subquery10.prodId,subquery10.prodFamCd,  subquery10.prodCd,subquery10.prodInacIndc,subquery10.prodVers,subquery10.rescMapId,  subquery10.rescId,subquery10.bilgSysCd,subquery10.rescVers,  subquery10.rescCd,subquery10.rescTypCd,subquery10.bilgSysTypCd,  subquery10.countryCode,  subquery10.countryDesc,subquery10.productCode,subquery10.prodCodeShrtDesc,  subquery10.prodCodeDesc,  subquery10.rescCode,subquery10.rescCodeShrtDesc,subquery10.rescCodeDesc,subquery10.prodGrpId,subquery10.prodGrpCd,  subquery10.prodDtlId,subquery10.prodDtlMtdtCd,subquery10.prodDtlMtdCdVal,  subquery10.mktGrpId,subquery10.mktGrpCd,  RESC_GRP.RESC_GRP_ID as rescGrpId,RESC_GRP.RESC_GRP_CD as rescGrpCd  from RESC_GRP,  (SELECT   subquery9.prodAvailId,subquery9.saleChnlid,subquery9.prodMktId,  subquery9.mktCd,  subquery9.prodId,subquery9.prodFamCd,  subquery9.prodCd,subquery9.prodInacIndc,subquery9.prodVers,subquery9.rescMapId,"
					+ " subquery9.rescId,subquery9.bilgSysCd,subquery9.rescVers,  subquery9.rescCd,subquery9.rescTypCd,subquery9.bilgSysTypCd,  subquery9.countryCode,  subquery9.countryDesc,subquery9.productCode,subquery9.prodCodeShrtDesc,  subquery9.prodCodeDesc,  subquery9.rescCode,subquery9.rescCodeShrtDesc,subquery9.rescCodeDesc,subquery9.prodGrpId,subquery9.prodGrpCd,  subquery9.prodDtlId,subquery9.prodDtlMtdtCd,subquery9.prodDtlMtdCdVal,  MKT_GRP.MKT_GRP_ID as mktGrpId,MKT_GRP.MKT_GRP_CD as mktGrpCd  from MKT_GRP,  ( SELECT   subquery8.prodAvailId,subquery8.saleChnlid,subquery8.prodMktId,  subquery8.mktCd,  subquery8.prodId,subquery8.prodFamCd,  subquery8.prodCd,subquery8.prodInacIndc,subquery8.prodVers,subquery8.rescMapId,  subquery8.rescId,subquery8.bilgSysCd,subquery8.rescVers,  subquery8.rescCd,subquery8.rescTypCd,subquery8.bilgSysTypCd,  subquery8.countryCode,  subquery8.countryDesc,subquery8.productCode,subquery8.prodCodeShrtDesc,  subquery8.prodCodeDesc,  subquery8.rescCode,subquery8.rescCodeShrtDesc,subquery8.rescCodeDesc,subquery8.prodGrpId,subquery8.prodGrpCd,  PROD_DTL.PROD_DTL_ID as prodDtlId,PROD_DTL.PROD_DTL_MTDT_CD as prodDtlMtdtCd,PROD_DTL.PROD_DTL_MTDT_VAL as prodDtlMtdCdVal  from PROD_DTL,  ( SELECT   subquery7.prodAvailId,subquery7.saleChnlid,subquery7.prodMktId,  subquery7.mktCd,  subquery7.prodId,subquery7.prodFamCd,  subquery7.prodCd,subquery7.prodInacIndc,subquery7.prodVers,subquery7.rescMapId,  subquery7.rescId,subquery7.bilgSysCd,subquery7.rescVers,  subquery7.rescCd,subquery7.rescTypCd,subquery7.bilgSysTypCd,  subquery7.countryCode,  subquery7.countryDesc,subquery7.productCode,subquery7.prodCodeShrtDesc,  subquery7.prodCodeDesc,  subquery7.rescCode,subquery7.rescCodeShrtDesc,subquery7.rescCodeDesc,PROD_GRP.prod_grp_id as prodGrpId,PROD_GRP.prod_grp_cd as prodGrpCd  from PROD_GRP,  (SELECT   subquery6.PROD_AVLBID as prodAvailId,subquery6.SLS_CHNL_ID as saleChnlid,subquery6.PROD_MKT_ID as prodMktId,  subquery6.MKT_CD as mktCd,  subquery6.PRODID as prodId,subquery6.PROD_FAM_CD as prodFamCd,  subquery6.PROD_CD as prodCd,subquery6.INAC_INDC as prodInacIndc,subquery6.PROD_VERS as prodVers,subquery6.RESC_MAP_ID as rescMapId,  subquery6.RESCID as rescId,subquery6.BILG_SYS_CODE as bilgSysCd,subquery6.RESC_VERS as rescVers,  subquery6.RESC_CD as rescCd,subquery6.RESC_TYP_CODE as rescTypCd,subquery6.BILG_SYS_TYP_CD as bilgSysTypCd,  subquery6.countryCode as countryCode,  subquery6.countryDesc as countryDesc,subquery6.productCode as productCode,subquery6.prodCodeShrtDesc as prodCodeShrtDesc,  subquery6.prodCodeDesc,  CD_VAL_TXT.CD_VAL_ID as rescCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as rescCodeShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescCodeDesc  from CD_VAL_TXT,  (SELECT   subquery5.PROD_AVLBID,subquery5.SLS_CHNL_ID,subquery5.PROD_MKT_ID,subquery5.MKT_CD,  subquery5.PRODID,subquery5.PROD_FAM_CD,subquery5.PROD_CD,subquery5.INAC_INDC,subquery5.PROD_VERS,subquery5.RESC_MAP_ID,  subquery5.RESCID,subquery5.BILG_SYS_CODE,subquery5.RESC_VERS,  subquery5.RESC_CD,subquery5.RESC_TYP_CODE,subquery5.BILG_SYS_TYP_CD,subquery5.countryCode,  subquery5.countryDesc,CD_VAL_TXT.CD_VAL_ID as productCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as prodCodeShrtDesc,  CD_VAL_TXT.CD_VAL_DESC as prodCodeDesc  from CD_VAL_TXT,  (SELECT   subquery4.PROD_AVLBID,subquery4.SLS_CHNL_ID,subquery4.PROD_MKT_ID,subquery4.MKT_CD,  subquery4.PRODID,subquery4.PROD_FAM_CD,subquery4.PROD_CD,subquery4.INAC_INDC,subquery4.PROD_VERS,subquery4.RESC_MAP_ID,  subquery4.RESCID,subquery4.BILG_SYS_CODE,subquery4.RESC_VERS,  subquery4.RESC_CD,subquery4.RESC_TYP_CODE,subquery4.BILG_SYS_TYP_CD,GEO_UNIT_NME.GEO_UNIT_ID as countryCode,  GEO_UNIT_NME.GEO_NME as countryDesc  from GEO_UNIT_NME ,  (SELECT   subquery3.PROD_AVLBID,subquery3.SLS_CHNL_ID,subquery3.PROD_MKT_ID,subquery3.MKT_CD,  subquery3.PRODID,subquery3.PROD_FAM_CD,subquery3.PROD_CD,subquery3.INAC_INDC,subquery3.PROD_VERS,subquery3.RESC_MAP_ID,  subquery3.RESC_ID as RESCID,RESC.RESC_ID,RESC.BILG_SYS_CODE,RESC.RESC_VERS,RESC.RESC_CD,RESC.RESC_TYP_CODE,RESC.BILG_SYS_TYP_CD   from RESC,  (SELECT   subquery2.PROD_AVLBID,subquery2.SLS_CHNL_ID,subquery2.PROD_MKT_ID,subquery2.MKT_CD,  subquery2.PRODID ,subquery2.PROD_FAM_CD,subquery2.PROD_CD,subquery2.INAC_INDC,subquery2.PROD_VERS,RESC_MAP.RESC_MAP_ID,  RESC_MAP.RESC_ID,RESC_MAP.PROD_ID from RESC_MAP,  (SELECT   PROD_AVLB.PROD_AVLB_ID,PROD_AVLB.PROD_ID,PROD_AVLB.SLS_CHNL_ID,PROD_MKT.PROD_MKT_ID,PROD_MKT.PROD_AVLB_ID as PROD_AVLBID,PROD_MKT.MKT_CD,  subquery1.PROD_ID as PRODID,subquery1.PROD_FAM_CD,subquery1.PROD_CD,subquery1.INAC_INDC,subquery1.PROD_VERS   from PROD_MKT,PROD_AVLB,(SELECT PROD_ID,PROD_FAM_CD,PROD_CD,INAC_INDC,PROD_VERS from PROD where    ("
					+ productcd
					+ ")"
					+ ") subquery1   WHERE PROD_MKT.PROD_AVLB_ID = PROD_AVLB.PROD_AVLB_ID and PROD_AVLB.PROD_ID = subquery1.PROD_ID and    ("
					+ strMktCd
					+ ")"
					+ ") subquery2  WHERE  RESC_MAP.PROD_ID = subquery2.PRODID) subquery3  WHERE subquery3.RESC_ID = RESC.RESC_ID and ("
					+ resccd
					+ ")"
					+ ") subquery4  WHERE subquery4.MKT_CD = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32   order by GEO_UNIT_NME.GEO_NME) subquery5  WHERE subquery5.PROD_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6  WHERE subquery6.RESC_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7  WHERE subquery7.prodId = PROD_GRP.prod_id) subquery8  WHERE subquery8.prodId = PROD_DTL.prod_id) subquery9  WHERE subquery9.prodMktId = MKT_GRP.PROD_MKT_ID) subquery10  WHERE subquery10.rescId = RESC_GRP.RESC_ID) subquery11  WHERE subquery11.rescId = RESC_DTL.RESC_ID) subquery12  WHERE subquery12.saleChnlid = SLS_CHNL_DTL.SLS_CHNL_ID) subquery13  WHERE subquery13.prodGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null  order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery14  WHERE subquery14.prodDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery15  WHERE subquery15.mktGrpCd =  GEO_UNIT_NME.GEO_UNIT_ID and 1=1  and GEO_UNIT.GEO_UNIT_ID=GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and "
					+ " GEO_UNIT_NME.GEO_NME_TYP_CD = 32 and GEO_UNIT.GEO_UNIT_TYP_CD=130 order by GEO_UNIT_NME.GEO_NME) subquery16  WHERE subquery16.rescGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery17  WHERE subquery17.rescDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery18  WHERE subquery18.slsChnlDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC";

		}
		return stagingDAO.retreiveIds(query);
	}

	@Override
	@Transactional("stgTransactionManager")
	public List<ProductSearchVO> productSearch(ProductSearchVO productSearchVO) {
		return stagingDAO.productSearch(productSearchVO);
	}

	public Long updateNewProd(AddNewProductsVO addNewProductsVO) {
		Product new_prod = new Product();
		Long prod_id = null;
		Long count_prod = stagingDAO
				.retreiveData("SELECT count(PROD_ID) FROM PROD WHERE PROD_ID="+addNewProductsVO.getProdId());
		Product prod = new Product();
		if (count_prod > 0) {
			prod_id = stagingDAO
					.retreiveData("SELECT PROD_ID FROM PROD WHERE PROD_ID ="+addNewProductsVO.getProdId());
			LOGGER.info("Existing product id" + prod_id);
			Product existing_prod = stagingDAO.findProductUsingId(prod_id);
			existing_prod.setProductVersion(addNewProductsVO.getProductVersion());
			existing_prod.setProductFamCode(addNewProductsVO.getProductFamilyCode());
			existing_prod.setModifiedDate(addNewProductsVO.getModifiedDate());
			existing_prod.setModifiedUser(addNewProductsVO.getModifiedUser());
			
			LOGGER.info("Existing product" + existing_prod);
			new_prod = stagingDAO.updateProduct(existing_prod);
		} else {
			prod_id = stagingDAO.retrieveMaxProductId();
			LOGGER.info("New product id" + prod_id);
			prod.setProductId(prod_id);
			prod.setProductCode(addNewProductsVO.getProductCode());
			prod.setProductVersion(addNewProductsVO.getProductVersion());
			prod.setProductFamCode(addNewProductsVO.getProductFamilyCode());
			prod.setCreatedDate(addNewProductsVO.getCreatedDate());
			prod.setCreatedUser(addNewProductsVO.getCreatedUser());
			prod.setModifiedDate(addNewProductsVO.getModifiedDate());
			prod.setModifiedUser(addNewProductsVO.getModifiedUser());
			prod.setInactiveIndicator(1L);
			LOGGER.info("New product" + prod);
			new_prod = stagingDAO.updateProduct(prod);
		}
		return new_prod.getProductId();
	}

	@SuppressWarnings("unused")
	@Override
	@Transactional("stgTransactionManager")
	public Long updateNewProducts(AddNewProductsVO addNewProductsVO) {
		Product new_prod = new Product();
		Long prod_id = null;
		Long count_prod = stagingDAO
				.retreiveData("SELECT count(PROD_ID) FROM PROD WHERE PROD_CD = "
						+ addNewProductsVO.getProductCode()
						+ " AND (PROD_VERS = "
						+ addNewProductsVO.getProductVersion()
						+ " OR PROD_VERS IS NULL) AND (PROD_FAM_CD = "
						+ addNewProductsVO.getProductFamilyCode()
						+ " OR PROD_FAM_CD IS NULL)");
		Product prod = new Product();
		if (count_prod > 0) {
			prod_id = stagingDAO
					.retreiveData("SELECT PROD_ID FROM PROD WHERE PROD_CD = "
							+ addNewProductsVO.getProductCode()
							+ " AND (PROD_VERS = "
							+ addNewProductsVO.getProductVersion()
							+ " OR PROD_VERS IS NULL) AND (PROD_FAM_CD = "
							+ addNewProductsVO.getProductFamilyCode()
							+ " OR PROD_FAM_CD IS NULL)");
			LOGGER.info("Existing product id" + prod_id);
			Product existing_prod = stagingDAO.findProductUsingId(prod_id);
			existing_prod.setModifiedDate(addNewProductsVO.getModifiedDate());
			existing_prod.setModifiedUser(addNewProductsVO.getModifiedUser());
			LOGGER.info("Existing product" + existing_prod);
			new_prod = stagingDAO.updateProduct(existing_prod);
		} else {
			prod_id = stagingDAO.retrieveMaxProductId();
			LOGGER.info("New product id" + prod_id);
			prod.setProductId(prod_id);
			prod.setProductCode(addNewProductsVO.getProductCode());
			prod.setProductVersion(addNewProductsVO.getProductVersion());
			prod.setProductFamCode(addNewProductsVO.getProductFamilyCode());
			prod.setCreatedDate(addNewProductsVO.getCreatedDate());
			prod.setCreatedUser(addNewProductsVO.getCreatedUser());
			prod.setModifiedDate(addNewProductsVO.getModifiedDate());
			prod.setModifiedUser(addNewProductsVO.getModifiedUser());
			prod.setInactiveIndicator(1L);
			LOGGER.info("New product" + prod);
			new_prod = stagingDAO.updateProduct(prod);
		}
		// update product group
		updateProductGroup(addNewProductsVO, prod_id);

		// update product details
		updateProductDetails(addNewProductsVO, prod_id);

		// update sales channel
		Long sales_channel_id = updateSalesChannel(addNewProductsVO);

		// update sales channel details
		updateSalesChannelDetails(addNewProductsVO, sales_channel_id);

		// update product availability
		Long prod_avail_id = updateProductAvailability(addNewProductsVO,
				prod_id, sales_channel_id);

		// update product market
		List<Long> prod_market_id_list = updateProductMarket(addNewProductsVO,
				prod_avail_id);

		// update market group
		updateMarketGroup(addNewProductsVO, prod_market_id_list);

		// update resource
		List<Long> resource_id_list = updateResource(addNewProductsVO);

		// update resource mapping
		updateResourceMapping(addNewProductsVO, prod_id, resource_id_list);

		List<ProductResources> prodRescList = addNewProductsVO
				.getProductResources();
		List<ProductResources> prodRescLst = new ArrayList<ProductResources>();
		for (ProductResources prodResc : prodRescList) {
			try {
				if (prodResc.getResourceCode() == null) {
					prodRescLst.add(prodResc);
				}
			} catch (Exception e) {
				LOGGER.error("ProductServiceImpl | updateNewProducts", e);
			}
		}
		prodRescList.removeAll(prodRescLst);
		addNewProductsVO.setProductResources(prodRescList);

		// update resource group
		updateResourceGroup(addNewProductsVO, resource_id_list);

		// update resource details
		// updateResourceDetails(addNewProductsVO, resource_id_list);

		return prod_id;
	}

	/**
	 * @param addNewProductsVO
	 * @param resource_id_list
	 */
	@SuppressWarnings("unused")
	private void updateResourceGroup(AddNewProductsVO addNewProductsVO,
			List<Long> resource_id_list) {
		ResourceGroup new_resource_group = new ResourceGroup();
		for (int id = 0; id < resource_id_list.size(); id++) {
			Long resources_id = resource_id_list.get(id);
			Long resource_group_code = addNewProductsVO.getProductResources()
					.get(id).getResourceGroupCode();
			Long count_resource_group = stagingDAO
					.retreiveData("SELECT count(RESC_GRP_ID) FROM RESC_GRP WHERE RESC_ID = "
							+ resources_id
							+ " AND RESC_GRP_CD = "
							+ resource_group_code + "");
			ResourceGroup resource_group = new ResourceGroup();
			if (count_resource_group > 0) {
				Long existing_resource_group_id = stagingDAO
						.retreiveData("SELECT RESC_GRP_ID FROM RESC_GRP WHERE RESC_ID = "
								+ resources_id
								+ " AND RESC_GRP_CD = "
								+ resource_group_code + "");
				ResourceGroup existing_resource_group = stagingDAO
						.findResourceGroupUsingId(existing_resource_group_id);
				existing_resource_group.setModifiedDate(addNewProductsVO
						.getModifiedDate());
				existing_resource_group.setModifiedUser(addNewProductsVO
						.getModifiedUser());
				LOGGER.info("Existing ResourceGroup" + existing_resource_group);
				new_resource_group = stagingDAO
						.updateResourceGroup(existing_resource_group);
			} else {
				resource_group.setRescGrpId(stagingDAO
						.retrieveMaxResourceGroupId());
				resource_group.setRescId(resources_id);
				resource_group.setRescGrpCd(resource_group_code);
				resource_group
						.setCreatedDate(addNewProductsVO.getCreatedDate());
				resource_group
						.setCreatedUser(addNewProductsVO.getCreatedUser());
				resource_group.setModifiedDate(addNewProductsVO
						.getModifiedDate());
				resource_group.setModifiedUser(addNewProductsVO
						.getModifiedUser());
				LOGGER.info("New ResourceGroup" + resource_group);
				new_resource_group = stagingDAO
						.updateResourceGroup(resource_group);
			}
		}
	}

	/**
	 * @param addNewProductsVO
	 * @param prod_id
	 * @param resource_id_list
	 */
	@SuppressWarnings("unused")
	private void updateResourceMapping(AddNewProductsVO addNewProductsVO,
			Long prod_id, List<Long> resource_id_list) {
		ResourceMapping new_resource_mapping = new ResourceMapping();
		for (Long resources_id : resource_id_list) {
			if (resources_id != null) {
				Long count_resource_mapping = stagingDAO
						.retreiveData("SELECT count(RESC_MAP_ID) FROM RESC_MAP WHERE RESC_ID = "
								+ resources_id
								+ " AND PROD_ID = "
								+ prod_id
								+ "");
				ResourceMapping resource_mapping = new ResourceMapping();
				if (count_resource_mapping > 0) {
					Long existing_resource_mapping_id = stagingDAO
							.retreiveData("SELECT RESC_MAP_ID FROM RESC_MAP WHERE RESC_ID = "
									+ resources_id
									+ " AND PROD_ID = "
									+ prod_id + "");
					ResourceMapping existing_resource_mapping = stagingDAO
							.findResourceMappingUsingId(existing_resource_mapping_id);
					existing_resource_mapping.setModifiedDate(addNewProductsVO
							.getModifiedDate());
					existing_resource_mapping.setModifiedUser(addNewProductsVO
							.getModifiedUser());
					LOGGER.info("Existing ResourceMapping"
							+ existing_resource_mapping);
					new_resource_mapping = stagingDAO
							.updateResourceMapping(existing_resource_mapping);
				} else {
					resource_mapping.setRescMapId(stagingDAO
							.retrieveMaxResourceMappingId());
					resource_mapping.setRescId(resources_id);
					resource_mapping.setProductId(prod_id);
					resource_mapping.setCreatedDate(addNewProductsVO
							.getCreatedDate());
					resource_mapping.setCreatedUser(addNewProductsVO
							.getCreatedUser());
					resource_mapping.setModifiedDate(addNewProductsVO
							.getModifiedDate());
					resource_mapping.setModifiedUser(addNewProductsVO
							.getModifiedUser());
					LOGGER.info("New ResourceMapping" + resource_mapping);
					new_resource_mapping = stagingDAO
							.updateResourceMapping(resource_mapping);
				}
			}
		}
	}

	/**
	 * @param addNewProductsVO
	 * @return
	 */
	@SuppressWarnings("unused")
	private List<Long> updateResource(AddNewProductsVO addNewProductsVO) {
		Resource new_resource = new Resource();
		List<Long> resource_id_list = new ArrayList<Long>();
		ResourceDetails new_resource_details = new ResourceDetails();
		for (ProductResources prod_resources : addNewProductsVO
				.getProductResources()) {
			if (prod_resources.getBillingSysCode() != null) {
				Long resource_id = null;
				Long count_resource = 0L;
				if (prod_resources.getResourceVersion() == null) {
					count_resource = stagingDAO
							.retreiveData("SELECT count(RESC_ID) FROM RESC WHERE BILG_SYS_CODE = "
									+ prod_resources.getBillingSysCode()
									+ " AND (RESC_VERS IS NULL) AND RESC_CD = "
									+ prod_resources.getResourceCode()
									+ " AND (RESC_TYP_CODE = '"
									+ prod_resources.getResourceType()
									+ "' OR RESC_TYP_CODE IS NULL) AND (BILG_SYS_TYP_CD = "
									+ prod_resources.getBillingSysType()
									+ " OR BILG_SYS_TYP_CD IS NULL)");
				} else {
					count_resource = stagingDAO
							.retreiveData("SELECT count(RESC_ID) FROM RESC WHERE BILG_SYS_CODE = "
									+ prod_resources.getBillingSysCode()
									+ " AND (RESC_VERS = "
									+ prod_resources.getResourceVersion()
									+ ") AND RESC_CD = "
									+ prod_resources.getResourceCode()
									+ " AND (RESC_TYP_CODE = '"
									+ prod_resources.getResourceType()
									+ "' OR RESC_TYP_CODE IS NULL) AND (BILG_SYS_TYP_CD = "
									+ prod_resources.getBillingSysType()
									+ " OR BILG_SYS_TYP_CD IS NULL)");
				}
				Resource resource = new Resource();
				if (count_resource > 0) {
					resource_id = stagingDAO
							.retreiveData("SELECT RESC_ID FROM RESC WHERE BILG_SYS_CODE = "
									+ prod_resources.getBillingSysCode()
									+ " AND (RESC_VERS = "
									+ prod_resources.getResourceVersion()
									+ " OR RESC_VERS IS NULL) AND RESC_CD = "
									+ prod_resources.getResourceCode()
									+ " AND (RESC_TYP_CODE = '"
									+ prod_resources.getResourceType()
									+ "'  OR RESC_TYP_CODE IS NULL) AND (BILG_SYS_TYP_CD = "
									+ prod_resources.getBillingSysType()
									+ " OR BILG_SYS_TYP_CD IS NULL)");
					resource_id_list.add(resource_id);
					Resource existing_resource = stagingDAO
							.findResourceUsingId(resource_id);

					existing_resource.setModifiedDate(addNewProductsVO
							.getModifiedDate());
					existing_resource.setModifiedUser(addNewProductsVO
							.getModifiedUser());
					LOGGER.info("Existing Resource" + existing_resource);
					new_resource = stagingDAO.updateResource(existing_resource);

					for (ResourceMetadataVO resource_metadata : prod_resources
							.getResourceMetadata()) {
						if (resource_metadata.getResourceMetadataCode() != null
								&& resource_metadata.getResourceMetadataValue() != null) {

							LOGGER.info("resource metacode"
									+ resource_metadata
											.getResourceMetadataCode());
							LOGGER.info("resource metavalue"
									+ resource_metadata
											.getResourceMetadataValue());

							Long resource_metadata_code = resource_metadata
									.getResourceMetadataCode();
							String resource_metadata_value = resource_metadata
									.getResourceMetadataValue();
							Long count_resource_details = stagingDAO
									.retreiveData("SELECT count(RESC_DTL_ID) FROM RESC_DTL WHERE RESC_ID = "
											+ resource_id
											+ " AND RESC_MTDT_VAL = '"
											+ resource_metadata_value
											+ " AND RESC_DTL_MTDT_CD = "
											+ resource_metadata_code + "'");
							ResourceDetails resource_details = new ResourceDetails();
							if (count_resource_details > 0) {
								Long existing_resource_details_id = stagingDAO
										.retreiveData("SELECT RESC_DTL_ID FROM RESC_DTL WHERE RESC_ID = "
												+ resource_id
												+ " AND RESC_MTDT_VAL = '"
												+ resource_metadata_value
												+ " AND RESC_DTL_MTDT_CD = "
												+ resource_metadata_code + "'");
								ResourceDetails existing_resource_details = stagingDAO
										.findResourceDetailsUsingId(existing_resource_details_id);
								existing_resource_details
										.setModifiedDate(addNewProductsVO
												.getModifiedDate());
								existing_resource_details
										.setModifiedUser(addNewProductsVO
												.getModifiedUser());
								LOGGER.info("Existing ResourceDetails"
										+ existing_resource_details);
								new_resource_details = stagingDAO
										.updateResourceDetails(existing_resource_details);
							} else {
								resource_details.setRescDtlId(stagingDAO
										.retrieveMaxResourceDetailsId());
								resource_details.setRescId(resource_id);
								resource_details
										.setRescDtlMetaDataCode(resource_metadata_code);
								resource_details
										.setRescDtlMetaDataVal(resource_metadata_value);
								resource_details
										.setCreatedDate(addNewProductsVO
												.getCreatedDate());
								resource_details
										.setCreatedUser(addNewProductsVO
												.getCreatedUser());
								resource_details
										.setModifiedDate(addNewProductsVO
												.getModifiedDate());
								resource_details
										.setModifiedUser(addNewProductsVO
												.getModifiedUser());
								LOGGER.info("New ResourceDetails"
										+ resource_details);
								new_resource_details = stagingDAO
										.updateResourceDetails(resource_details);
							}
						}
					}

				} else {
					resource_id = stagingDAO.retrieveMaxResourceId();
					resource_id_list.add(resource_id);
					resource.setRescId(resource_id);
					resource.setBilgSysCode(prod_resources.getBillingSysCode());
					resource.setRescVersion(prod_resources.getResourceVersion());
					resource.setBilgSysTypeCode(prod_resources
							.getBillingSysType());
					resource.setRescCode(prod_resources.getResourceCode());
					resource.setRescTypeCode(prod_resources.getResourceType());
					resource.setCreatedDate(addNewProductsVO.getCreatedDate());
					resource.setCreatedUser(addNewProductsVO.getCreatedUser());
					resource.setModifiedDate(addNewProductsVO.getModifiedDate());
					resource.setModifiedUser(addNewProductsVO.getModifiedUser());
					resource.setInactiveIndicator(1L);
					LOGGER.info("New Resource" + resource);
					new_resource = stagingDAO.updateResource(resource);

					for (ResourceMetadataVO resource_metadata : prod_resources
							.getResourceMetadata()) {
						if (resource_metadata.getResourceMetadataCode() != null
								&& resource_metadata.getResourceMetadataValue() != null) {

							LOGGER.info("resource metacode"
									+ resource_metadata
											.getResourceMetadataCode());
							LOGGER.info("resource metavalue"
									+ resource_metadata
											.getResourceMetadataValue());

							Long resource_metadata_code = resource_metadata
									.getResourceMetadataCode();
							String resource_metadata_value = resource_metadata
									.getResourceMetadataValue();
							Long count_resource_details = stagingDAO
									.retreiveData("SELECT count(RESC_DTL_ID) FROM RESC_DTL WHERE RESC_ID = "
											+ resource_id
											+ " AND RESC_MTDT_VAL = '"
											+ resource_metadata_value
											+ " AND RESC_DTL_MTDT_CD = "
											+ resource_metadata_code + "'");
							ResourceDetails resource_details = new ResourceDetails();
							if (count_resource_details > 0) {
								Long existing_resource_details_id = stagingDAO
										.retreiveData("SELECT RESC_DTL_ID FROM RESC_DTL WHERE RESC_ID = "
												+ resource_id
												+ " AND RESC_MTDT_VAL = '"
												+ resource_metadata_value
												+ " AND RESC_DTL_MTDT_CD = "
												+ resource_metadata_code + "'");
								ResourceDetails existing_resource_details = stagingDAO
										.findResourceDetailsUsingId(existing_resource_details_id);
								existing_resource_details
										.setModifiedDate(addNewProductsVO
												.getModifiedDate());
								existing_resource_details
										.setModifiedUser(addNewProductsVO
												.getModifiedUser());
								LOGGER.info("Existing ResourceDetails"
										+ existing_resource_details);
								new_resource_details = stagingDAO
										.updateResourceDetails(existing_resource_details);
							} else {
								resource_details.setRescDtlId(stagingDAO
										.retrieveMaxResourceDetailsId());
								resource_details.setRescId(resource_id);
								resource_details
										.setRescDtlMetaDataCode(resource_metadata_code);
								resource_details
										.setRescDtlMetaDataVal(resource_metadata_value);
								resource_details
										.setCreatedDate(addNewProductsVO
												.getCreatedDate());
								resource_details
										.setCreatedUser(addNewProductsVO
												.getCreatedUser());
								resource_details
										.setModifiedDate(addNewProductsVO
												.getModifiedDate());
								resource_details
										.setModifiedUser(addNewProductsVO
												.getModifiedUser());
								LOGGER.info("New ResourceDetails"
										+ resource_details);
								new_resource_details = stagingDAO
										.updateResourceDetails(resource_details);
							}
						}
					}

				}
			}
		}
		return resource_id_list;
	}

	/**
	 * @param addNewProductsVO
	 * @param prod_market_id_list
	 */
	@SuppressWarnings("unused")
	private void updateMarketGroup(AddNewProductsVO addNewProductsVO,
			List<Long> prod_market_id_list) {
		MarketGroup new_market_group = new MarketGroup();
		for (Long prod_market_id : prod_market_id_list) {
			Long count_market_group = stagingDAO
					.retreiveData("SELECT count(MKT_GRP_ID) FROM MKT_GRP WHERE MKT_GRP_CD = "
							+ addNewProductsVO.getMarketGroupCode()
							+ " AND PROD_MKT_ID = " + prod_market_id + "");
			MarketGroup market_group = new MarketGroup();
			if (count_market_group > 0) {
				Long existing_market_group_id = stagingDAO
						.retreiveData("SELECT MKT_GRP_ID FROM MKT_GRP WHERE MKT_GRP_CD = "
								+ addNewProductsVO.getMarketGroupCode()
								+ " AND PROD_MKT_ID = " + prod_market_id + "");
				MarketGroup existing_market_group = stagingDAO
						.findMarketGroupUsingId(existing_market_group_id);
				existing_market_group.setModifiedDate(addNewProductsVO
						.getModifiedDate());
				existing_market_group.setModifiedUser(addNewProductsVO
						.getModifiedUser());
				LOGGER.info("Existing MarketGroup" + existing_market_group);
				new_market_group = stagingDAO
						.updateMarketGroup(existing_market_group);
			} else {
				market_group.setMktGrpId(stagingDAO.retrieveMaxMarketGroupId());
				market_group.setMktGrpCd(addNewProductsVO.getMarketGroupCode());
				market_group.setProductMktId(prod_market_id);
				market_group.setCreatedDate(addNewProductsVO.getCreatedDate());
				market_group.setCreatedUser(addNewProductsVO.getCreatedUser());
				market_group
						.setModifiedDate(addNewProductsVO.getModifiedDate());
				market_group
						.setModifiedUser(addNewProductsVO.getModifiedUser());
				LOGGER.info("New MarketGroup" + market_group);
				new_market_group = stagingDAO.updateMarketGroup(market_group);
			}
		}
	}

	/**
	 * @param addNewProductsVO
	 * @param prod_avail_id
	 * @return
	 */
	@SuppressWarnings("unused")
	private List<Long> updateProductMarket(AddNewProductsVO addNewProductsVO,
			Long prod_avail_id) {
		ProductMarket new_prod_market = new ProductMarket();
		List<Long> prod_market_id_list = new ArrayList<Long>();
		for (Long marketCode : addNewProductsVO.getCountryList()) {
			Long prod_market_id = null;
			if (prod_avail_id != null) {
				Long count_prod_market = stagingDAO
						.retreiveData("SELECT count(PROD_MKT_ID) FROM PROD_MKT WHERE PROD_AVLB_ID = "
								+ prod_avail_id
								+ " AND MKT_CD = "
								+ marketCode
								+ "");
				ProductMarket prod_market = new ProductMarket();
				if (count_prod_market > 0) {
					prod_market_id = stagingDAO
							.retreiveData("SELECT PROD_MKT_ID FROM PROD_MKT WHERE PROD_AVLB_ID = "
									+ prod_avail_id
									+ " AND MKT_CD = "
									+ marketCode + "");
					prod_market_id_list.add(prod_market_id);
					ProductMarket existing_prod_market = stagingDAO
							.findProductMarketUsingId(prod_market_id);
					existing_prod_market.setModifiedDate(addNewProductsVO
							.getModifiedDate());
					existing_prod_market.setModifiedUser(addNewProductsVO
							.getModifiedUser());
					LOGGER.info("Existing ProductMarket" + existing_prod_market);
					new_prod_market = stagingDAO
							.updateProductMarket(existing_prod_market);
				} else {
					prod_market_id = stagingDAO.retrieveMaxProductMarketId();
					prod_market_id_list.add(prod_market_id);
					prod_market.setProductMktId(prod_market_id);
					prod_market.setProductAvlbId(prod_avail_id);
					prod_market.setMktCd(marketCode);
					prod_market.setCreatedDate(addNewProductsVO
							.getCreatedDate());
					prod_market.setCreatedUser(addNewProductsVO
							.getCreatedUser());
					prod_market.setModifiedDate(addNewProductsVO
							.getModifiedDate());
					prod_market.setModifiedUser(addNewProductsVO
							.getModifiedUser());
					LOGGER.info("New ProductMarket" + prod_market);
					new_prod_market = stagingDAO
							.updateProductMarket(prod_market);
				}
			}
		}
		return prod_market_id_list;
	}

	/**
	 * @param addNewProductsVO
	 * @param prod_id
	 * @param sales_channel_id
	 * @return
	 */
	@SuppressWarnings("unused")
	private Long updateProductAvailability(AddNewProductsVO addNewProductsVO,
			Long prod_id, Long sales_channel_id) {
		ProductAvailability new_prod_avail = new ProductAvailability();
		Long prod_avail_id = null;
		if (prod_id != null) {
			Long count_prod_avail = stagingDAO
					.retreiveData("SELECT count(PROD_AVLB_ID) FROM PROD_AVLB WHERE PROD_ID = "
							+ prod_id
							+ " AND SLS_CHNL_ID = "
							+ sales_channel_id + "");
			ProductAvailability prod_avail = new ProductAvailability();
			if (count_prod_avail > 0) {
				prod_avail_id = stagingDAO
						.retreiveData("SELECT PROD_AVLB_ID FROM PROD_AVLB WHERE PROD_ID = "
								+ prod_id
								+ " AND SLS_CHNL_ID = "
								+ sales_channel_id + "");
				ProductAvailability existing_prod_avail = stagingDAO
						.findProductAvailabilityUsingId(prod_avail_id);
				existing_prod_avail.setModifiedDate(addNewProductsVO
						.getModifiedDate());
				existing_prod_avail.setModifiedUser(addNewProductsVO
						.getModifiedUser());
				LOGGER.info("Existing ProductAvailability"
						+ existing_prod_avail);
				new_prod_avail = stagingDAO
						.updateProductAvailability(existing_prod_avail);
			} else {
				prod_avail_id = stagingDAO.retrieveMaxProductAvailabilityId();
				prod_avail.setProductAvlbId(prod_avail_id);
				prod_avail.setSalesChnlId(sales_channel_id);
				prod_avail.setProductId(prod_id);
				prod_avail.setCreatedDate(addNewProductsVO.getCreatedDate());
				prod_avail.setCreatedUser(addNewProductsVO.getCreatedUser());
				prod_avail.setModifiedDate(addNewProductsVO.getModifiedDate());
				prod_avail.setModifiedUser(addNewProductsVO.getModifiedUser());
				LOGGER.info("New ProductAvailability" + prod_avail);
				new_prod_avail = stagingDAO
						.updateProductAvailability(prod_avail);
			}
		}
		return prod_avail_id;
	}

	/**
	 * @param addNewProductsVO
	 * @param sales_channel_id
	 */
	@SuppressWarnings("unused")
	private void updateSalesChannelDetails(AddNewProductsVO addNewProductsVO,
			Long sales_channel_id) {
		SalesChannelDetails new_sales_channel_details = new SalesChannelDetails();
		LOGGER.info("addNewProductsVO.getSalesMetadata().size()::"
				+ addNewProductsVO.getSalesMetadata().size());
		for (SalesMetadataVO salesMetadata : addNewProductsVO
				.getSalesMetadata()) {
			if (salesMetadata.getSalesMetadataCode() != null
					&& salesMetadata.getSalesMetadataValue() != null) {
				Long sales_chnl_dtl = null;
				LOGGER.info("salesMetaCode"
						+ salesMetadata.getSalesMetadataCode());
				LOGGER.info("salemetavalue"
						+ salesMetadata.getSalesMetadataValue());
				if (sales_channel_id != null) {

					Long count_sales_channel_details = stagingDAO
							.retreiveData("SELECT count(SLS_CHNL_DTL_ID) FROM SLS_CHNL_DTL WHERE SLS_CHNL_DTL_MTDT_CD = "
									+ salesMetadata.getSalesMetadataCode()
									+ " AND SLS_CHNL_DTL_MTDT_VAL = '"
									+ salesMetadata.getSalesMetadataValue()
									+ "' AND SLS_CHNL_ID = "
									+ sales_channel_id
									+ "");
					SalesChannelDetails sales_channel_details = new SalesChannelDetails();
					if (count_sales_channel_details > 0) {
						sales_chnl_dtl = stagingDAO
								.retreiveData("SELECT SLS_CHNL_DTL_ID FROM SLS_CHNL_DTL WHERE SLS_CHNL_DTL_MTDT_CD = "
										+ salesMetadata.getSalesMetadataCode()
										+ " AND SLS_CHNL_DTL_MTDT_VAL = '"
										+ salesMetadata.getSalesMetadataValue()
										+ "' AND SLS_CHNL_ID = "
										+ sales_channel_id + "");
						SalesChannelDetails existing_sales_channel_details = stagingDAO
								.findSalesChannelDetailsUsingId(sales_chnl_dtl);
						existing_sales_channel_details
								.setModifiedDate(addNewProductsVO
										.getModifiedDate());
						existing_sales_channel_details
								.setModifiedUser(addNewProductsVO
										.getModifiedUser());
						LOGGER.info("Existing Sales channel details"
								+ existing_sales_channel_details);
						new_sales_channel_details = stagingDAO
								.updateSalesChannelDetails(existing_sales_channel_details);
					} else {
						sales_chnl_dtl = stagingDAO
								.retrieveMaxSalesChannelDetailsId();
						sales_channel_details.setSalesChnlDtlId(sales_chnl_dtl);
						sales_channel_details
								.setSalesChnlDtlMetaDataCode(salesMetadata
										.getSalesMetadataCode());
						sales_channel_details
								.setSalesChnlDtlMetaDataVal(salesMetadata
										.getSalesMetadataValue());
						sales_channel_details.setSalesChnlId(sales_channel_id);
						sales_channel_details.setCreatedDate(addNewProductsVO
								.getCreatedDate());
						sales_channel_details.setCreatedUser(addNewProductsVO
								.getCreatedUser());
						sales_channel_details.setModifiedDate(addNewProductsVO
								.getModifiedDate());
						sales_channel_details.setModifiedUser(addNewProductsVO
								.getModifiedUser());
						LOGGER.info("New Sales channel details"
								+ sales_channel_details);
						new_sales_channel_details = stagingDAO
								.updateSalesChannelDetails(sales_channel_details);
					}
				}
			}
		}
	}

	/**
	 * @param addNewProductsVO
	 * @return
	 */
	@SuppressWarnings("unused")
	private Long updateSalesChannel(AddNewProductsVO addNewProductsVO) {
		SalesChannel new_sales_channel = new SalesChannel();
		Long sales_channel_id = null;
		Long count_sales_channel = stagingDAO
				.retreiveData("SELECT count(SLS_CHNL_ID) FROM SLS_CHNL WHERE SLS_CHNL_ID ="+addNewProductsVO.getSaleChnlid());
		SalesChannel sales_channel = new SalesChannel();
		if (count_sales_channel > 0) {
			sales_channel_id = stagingDAO
					.retreiveData("SELECT SLS_CHNL_ID FROM SLS_CHNL WHERE SLS_CHNL_ID ="+addNewProductsVO.getSaleChnlid());
			SalesChannel existing_sales_channel = stagingDAO
					.findSalesChannelUsingId(sales_channel_id);
			existing_sales_channel.setSalesChnlVers(addNewProductsVO.getSalesVersion());
			existing_sales_channel.setSalesChnlCode(addNewProductsVO.getSalesChannelCode());
			existing_sales_channel.setModifiedDate(addNewProductsVO
					.getModifiedDate());
			existing_sales_channel.setModifiedUser(addNewProductsVO
					.getModifiedUser());
			LOGGER.info("Existing Sales channel" + existing_sales_channel);
			new_sales_channel = stagingDAO
					.updateSalesChannel(existing_sales_channel);
		} else {
			sales_channel_id = stagingDAO.retrieveMaxSalesChannelId();
			sales_channel.setSalesChnlId(sales_channel_id);
			sales_channel.setSalesChnlCode(addNewProductsVO
					.getSalesChannelCode());
			sales_channel.setSalesChnlVers(addNewProductsVO.getSalesVersion());
			sales_channel.setCreatedDate(addNewProductsVO.getCreatedDate());
			sales_channel.setCreatedUser(addNewProductsVO.getCreatedUser());
			sales_channel.setModifiedDate(addNewProductsVO.getModifiedDate());
			sales_channel.setModifiedUser(addNewProductsVO.getModifiedUser());
			sales_channel.setInactiveIndicator(1L);
			LOGGER.info("New Sales channel" + sales_channel);
			new_sales_channel = stagingDAO.updateSalesChannel(sales_channel);
		}
		return sales_channel_id;
	}

	/**
	 * @param addNewProductsVO
	 * @param prod_id
	 */
	@SuppressWarnings("unused")
	private void updateProductDetails(AddNewProductsVO addNewProductsVO,
			Long prod_id) {
		ProductDetails new_prod_detail = new ProductDetails();
		for (ProductMetaData prdctMeta : addNewProductsVO.getProductMetaData()) {
			if (prdctMeta.getProductMetadataCode() != null
					&& prdctMeta.getProductMetadataValue() != null) {
				Long product_dtl_id = null;
				if (prod_id != null) {
					Long count_prod_detail = stagingDAO
							.retreiveData("SELECT count(PROD_DTL_ID) FROM PROD_DTL WHERE PROD_DTL_MTDT_CD = "
									+ prdctMeta.getProductMetadataCode()
									+ " AND PROD_DTL_MTDT_VAL = '"
									+ prdctMeta.getProductMetadataValue()
									+ "' AND PROD_ID = " + prod_id + "");
					ProductDetails prod_detail = new ProductDetails();
					if (count_prod_detail > 0) {
						product_dtl_id = stagingDAO
								.retreiveData("SELECT PROD_DTL_ID FROM PROD_DTL WHERE PROD_DTL_MTDT_CD = "
										+ prdctMeta.getProductMetadataCode()
										+ " AND PROD_DTL_MTDT_VAL = '"
										+ prdctMeta.getProductMetadataValue()
										+ "' AND PROD_ID = " + prod_id + "");
						ProductDetails existing_prod_details = stagingDAO
								.findProductDetailsUsingId(product_dtl_id);
						existing_prod_details.setModifiedDate(addNewProductsVO
								.getModifiedDate());
						existing_prod_details.setModifiedUser(addNewProductsVO
								.getModifiedUser());
						LOGGER.info("Existing product details"
								+ existing_prod_details);
						new_prod_detail = stagingDAO
								.updateProductDetails(existing_prod_details);
					} else {
						product_dtl_id = stagingDAO
								.retrieveMaxProductDetailId();
						prod_detail.setProductDtlId(product_dtl_id);
						prod_detail.setProductDtlMetDatCode(prdctMeta
								.getProductMetadataCode());
						prod_detail.setProductDtlMetDatVal(prdctMeta
								.getProductMetadataValue());
						prod_detail.setProductID(prod_id);
						prod_detail.setCreatedDate(addNewProductsVO
								.getCreatedDate());
						prod_detail.setCreatedUser(addNewProductsVO
								.getCreatedUser());
						prod_detail.setModifiedDate(addNewProductsVO
								.getModifiedDate());
						prod_detail.setModifiedUser(addNewProductsVO
								.getModifiedUser());
						LOGGER.info("New product details" + prod_detail);
						new_prod_detail = stagingDAO
								.updateProductDetails(prod_detail);
					}
				}
			}
		}
	}

	/**
	 * @param addNewProductsVO
	 * @param prod_id
	 */
	private Long updateProductDetailsMetaData(ProductMetaData prdctMeta,
			Long prod_id, Date modifiedDate, String modifiedUser) {
		ProductDetails new_prod_detail = new ProductDetails();

		if (prdctMeta.getProductMetadataCode() != null
				&& prdctMeta.getProductMetadataValue() != null) {
			Long product_dtl_id = null;
			if (prod_id != null) {
				Long count_prod_detail = stagingDAO
						.retreiveData("SELECT count(PROD_DTL_ID) FROM PROD_DTL WHERE PROD_DTL_MTDT_CD = "
								+ prdctMeta.getProductMetadataCode()
								+ " AND PROD_DTL_MTDT_VAL = '"
								+ prdctMeta.getProductMetadataValue()
								+ "' AND PROD_ID = " + prod_id + "");
				ProductDetails prod_detail = new ProductDetails();
				if (count_prod_detail > 0) {
					product_dtl_id = stagingDAO
							.retreiveData("SELECT PROD_DTL_ID FROM PROD_DTL WHERE PROD_DTL_MTDT_CD = "
									+ prdctMeta.getProductMetadataCode()
									+ " AND PROD_DTL_MTDT_VAL = '"
									+ prdctMeta.getProductMetadataValue()
									+ "' AND PROD_ID = " + prod_id + "");
					ProductDetails existing_prod_details = stagingDAO
							.findProductDetailsUsingId(product_dtl_id);
					existing_prod_details.setModifiedDate(modifiedDate);
					existing_prod_details.setModifiedUser(modifiedUser);
					LOGGER.info("Existing product details"
							+ existing_prod_details);
					new_prod_detail = stagingDAO
							.updateProductDetails(existing_prod_details);
				} else {
					product_dtl_id = stagingDAO.retrieveMaxProductDetailId();
					prod_detail.setProductDtlId(product_dtl_id);
					prod_detail.setProductDtlMetDatCode(prdctMeta
							.getProductMetadataCode());
					prod_detail.setProductDtlMetDatVal(prdctMeta
							.getProductMetadataValue());
					prod_detail.setProductID(prod_id);
					prod_detail.setCreatedDate(new Date());
					prod_detail.setCreatedUser(modifiedUser);
					prod_detail.setModifiedDate(modifiedDate);
					prod_detail.setModifiedUser(modifiedUser);
					LOGGER.info("New product details" + prod_detail);
					new_prod_detail = stagingDAO
							.updateProductDetails(prod_detail);
				}
			}
		}

		return new_prod_detail.getProductDtlId();
	}

	/**
	 * @param addNewProductsVO
	 * @param prod_id
	 */
	@SuppressWarnings("unused")
	private void updateProductGroup(AddNewProductsVO addNewProductsVO,
			Long prod_id) {
		ProductGroup new_prod_grp = new ProductGroup();
		Long count_prod_grp = stagingDAO
				.retreiveData("SELECT count(PROD_GRP_ID) FROM PROD_GRP WHERE PROD_GRP_CD = "
						+ addNewProductsVO.getProductGroupCode()
						+ " AND PROD_ID = " + prod_id + "");
		ProductGroup prod_grp = new ProductGroup();
		if (count_prod_grp > 0) {
			Long existing_prod_grp_id = stagingDAO
					.retreiveData("SELECT PROD_GRP_ID FROM PROD_GRP WHERE PROD_GRP_CD = "
							+ addNewProductsVO.getProductGroupCode()
							+ " AND PROD_ID = " + prod_id + "");
			ProductGroup existing_prod_grp = stagingDAO
					.findProductGroupUsingId(existing_prod_grp_id);
			existing_prod_grp.setModifiedDate(addNewProductsVO
					.getModifiedDate());
			existing_prod_grp.setModifiedUser(addNewProductsVO
					.getModifiedUser());
			LOGGER.info("Existing product group" + existing_prod_grp);
			new_prod_grp = stagingDAO.updateProductGroup(existing_prod_grp);
		} else {
			prod_grp.setProductGrpId(stagingDAO.retrieveMaxProductGroupId());
			prod_grp.setProductGrpCode(addNewProductsVO.getProductGroupCode());
			prod_grp.setProductId(prod_id);
			prod_grp.setCreatedDate(addNewProductsVO.getCreatedDate());
			prod_grp.setCreatedUser(addNewProductsVO.getCreatedUser());
			prod_grp.setModifiedDate(addNewProductsVO.getModifiedDate());
			prod_grp.setModifiedUser(addNewProductsVO.getModifiedUser());
			LOGGER.info("New product group" + prod_grp);
			new_prod_grp = stagingDAO.updateProductGroup(prod_grp);
		}
	}

	@SuppressWarnings("unused")
	@Override
	public AddNewProductsVO retrieveProductDetail(
			ProductSearchVO productSearchVO) {
		AddNewProductsVO addNewProductsVO = new AddNewProductsVO();

		Product product = stagingDAO.findProduct(productSearchVO.getProdId());
		// ProductAvailability productAvailability =
		// stagingDAO.findProductAvailability(productSearchVO.getProdAvailId());
		SalesChannel salesChannel = stagingDAO.findSalesChannel(productSearchVO
				.getSaleChnlid());
		ProductMarket productMarket = stagingDAO
				.findProductMarket(productSearchVO.getProdMktId());
		// ResourceMapping resourceMapping=
		// stagingDAO.findResourceMapping(productSearchVO.getRescMapId());
		Resource resource = stagingDAO
				.findResource(productSearchVO.getRescId());
		ProductGroup productGroup = stagingDAO.findProductGroup(productSearchVO
				.getProdGrpId());
		MarketGroup marketGroup = stagingDAO.findMarketGroup(productSearchVO
				.getMktGrpId());
		ResourceGroup resourceGroup = stagingDAO
				.findResourceGroup(productSearchVO.getRescGrpId());
		ResourceDetails resourceDetails = stagingDAO
				.findResourceDetails(productSearchVO.getRescDtlID());
		SalesChannelDetails salesChannelDetails = stagingDAO
				.findSalesChannelDetails(productSearchVO.getSlsChnlDtlID());
		String query = "select PROD_DTL_ID,PROD_DTL_MTDT_CD,PROD_DTL_MTDT_VAL from PROD_DTL where PROD_ID ="
				+ productSearchVO.getProdId() + " ";
		List<ProductMetaData> prodMetDataList = stagingDAO
				.retreiveProdDtlInfo(query);
		addNewProductsVO.setProductMetaData(prodMetDataList);
		addNewProductsVO.setProductCode(product.getProductCode());
		addNewProductsVO.setProductVersion(product.getProductVersion());
		addNewProductsVO.setProductFamilyCode(product.getProductFamCode());
		addNewProductsVO.setProductGroupCode(productGroup.getProductGrpCode());

		addNewProductsVO.setSalesChannelCode(salesChannel.getSalesChnlCode());
		addNewProductsVO.setSalesVersion(salesChannel.getSalesChnlVers());
		String sales_query = "select SLS_CHNL_DTL_ID,SLS_CHNL_DTL_MTDT_CD,SLS_CHNL_DTL_MTDT_VAL from SLS_CHNL_DTL where SLS_CHNL_ID ="
				+ productSearchVO.getSaleChnlid() + "";
		List<SalesMetadataVO> salesMetadataList = stagingDAO
				.retrieveSalesDtlInfo(sales_query);
		addNewProductsVO.setSalesMetadata(salesMetadataList);

		List<Long> countryList = new ArrayList<Long>();
		countryList.add(productMarket.getMktCd());

		addNewProductsVO.setCountryList(countryList);
		addNewProductsVO.setCountry(productMarket.getMktCd());
		addNewProductsVO.setMarketGroupCode(marketGroup.getMktGrpCd());

		// Product Resource Multiple Block - Starts

		List<Long> rescIdList = stagingDAO.retrieveRescId(productSearchVO
				.getProdId());
		List<ProductResources> productResourcesList = new ArrayList<ProductResources>();

		for (Long rescId : rescIdList) {

			String qry = "select q1.RESC_ID,q1.BILG_SYS_CODE,q1.RESC_VERS,q1.RESC_CD,q1.RESC_TYP_CODE,q1.BILG_SYS_TYP_CD,"
					+ " resc_grp.RESC_GRP_ID,resc_grp.RESC_GRP_CD"
					+ " from resc_grp,"
					+ " (select RESC_ID,BILG_SYS_CODE,RESC_VERS,RESC_CD,RESC_TYP_CODE,BILG_SYS_TYP_CD from resc where RESC_ID = "
					+ rescId + " )q1" + " where resc_grp.RESC_ID = q1.RESC_ID";
			ProductResources prodResc = stagingDAO.retreiveRescDetails(qry);

			String rescDtlQry = "select resc_dtl.RESC_DTL_ID,resc_dtl.RESC_DTL_MTDT_CD,resc_dtl.RESC_MTDT_VAL"
					+ " from resc_dtl,"
					+ " (select RESC_ID from resc where RESC_ID = "
					+ rescId
					+ " )q1" + " where resc_dtl.RESC_ID = q1.RESC_ID";

			List<ResourceMetadataVO> prodRescDtl = stagingDAO
					.retreiveRescMetaDetails(rescDtlQry);
			prodResc.setResourceMetadata(prodRescDtl);
			productResourcesList.add(prodResc);
		}
		addNewProductsVO.setProductResources(productResourcesList);

		// Product Resource Multiple Block - Ends

		return addNewProductsVO;
	}

	@SuppressWarnings("unused")
	private void deleteRescData(AddNewProductsVO addNewProductVO,
			List<Long> resource_id_list) {

		Long prod_Id = addNewProductVO.getProdId();

		if (resource_id_list.size() > 0) {
			String resc_id = resource_id_list.toString();
			resc_id = resc_id.replace("[", "").replace("]", "");
			String rescIdQuery = "select resc_id from resc_map where prod_id ="
					+ prod_Id + " and resc_id not in (" + resc_id + ")";
			LOGGER.info("Query resc_map_id_query : " + rescIdQuery);
			// get resc_id that need to be deleted for that product
			List<Long> rescIdList = stagingDAO.retrieveRescIds(rescIdQuery);

			// get resc_map_id for those resc_id that need to be deleted
			String resc_id_list = rescIdList.toString();
			resc_id_list = resc_id_list.replace("[", "").replace("]", "");

			String rescMapId_query = "select resc_map_id from resc_map where prod_id ="
					+ prod_Id + " and resc_id in (" + resc_id_list + ")";
			LOGGER.info("Query resc_map_id_query : " + rescMapId_query);
			List<Long> rescMapId = stagingDAO.retrieveMapIds(rescMapId_query);

			// Delete query for resource details
			String rescId = rescIdList.toString();
			rescId = rescId.replace("[", "").replace("]", "");
			String deleteRescDtl = "DELETE FROM resc_dtl c where c.resc_id  in ("
					+ rescId + ")";
			stagingDAO.removeRescDtl(deleteRescDtl);

			// Check if these map id present in prod-resc-to-scr-gru and delete
			// them
			String mapIds = rescMapId.toString();
			mapIds = mapIds.replace("[", "").replace("]", "");
			Long count_mapId = stagingDAO
					.countMapId("Select count(resc_map_id) from prod_resc_to_scr_gru where resc_map_id in ("
							+ mapIds + ")");
			if (count_mapId > 0) {
				String deleteProdRescToScrGrn = "Delect from prod_resc_to_scr_gru where resc_map_id in ("
						+ mapIds + ")";
				stagingDAO.removeProdRescToScrGrn(deleteProdRescToScrGrn);
			}

			// delete those map ids from resc_map
			String deleteMapIds = "Delete from resc_map where resc_map_id in ("
					+ mapIds + ")";
			stagingDAO.removeMapIds(deleteMapIds);

			// delete rescid from resc
			String deleteRescId = "Delete from resc where resc_id in ("
					+ rescId + ")";
			stagingDAO.removeRescId(deleteRescId);
		}
	}

	@SuppressWarnings("unused")
	private List<Long> updateResourceData(AddNewProductsVO addNewProductsVO) {
		LOGGER.info("Inside ProductServiceImpl | updateResourceData");
		Resource new_resource = new Resource();
		List<Long> resource_id_list = new ArrayList<Long>();
		ResourceDetails new_resource_details = new ResourceDetails();
		for (ProductResources prod_resources : addNewProductsVO
				.getProductResources()) {
			if (prod_resources.getBillingSysCode() != null || !(prod_resources.getBillingSysCode().isEmpty())) {
				Long resource_id = null;
				Long count_resource = 0L;
				if (prod_resources.getResourceVersion() == null) {
					count_resource = stagingDAO
							.retreiveData("SELECT count(RESC_ID) FROM RESC WHERE BILG_SYS_CODE = "
									+ prod_resources.getBillingSysCode()
									+ " AND (RESC_VERS IS NULL) AND RESC_CD = "
									+ prod_resources.getResourceCode()
									+ " AND (RESC_TYP_CODE = '"
									+ prod_resources.getResourceType()
									+ "' OR RESC_TYP_CODE IS NULL)");
				} else {
					count_resource = stagingDAO
							.retreiveData("SELECT count(RESC_ID) FROM RESC WHERE BILG_SYS_CODE = "
									+ prod_resources.getBillingSysCode()
									+ " AND (RESC_VERS = "
									+ prod_resources.getResourceVersion()
									+ ") AND RESC_CD = "
									+ prod_resources.getResourceCode()
									+ " AND (RESC_TYP_CODE = '"
									+ prod_resources.getResourceType()
									+ "' OR RESC_TYP_CODE IS NULL)");
				}
				// Long
				// count_resource=stagingDAO.retreiveData("SELECT count(RESC_ID) FROM RESC WHERE BILG_SYS_CODE = "+prod_resources.getBillingSysCode()+" AND (RESC_VERS = "+prod_resources.getResourceVersion()+" OR RESC_VERS IS NULL) AND RESC_CD = "+prod_resources.getResourceCode()+" AND (RESC_TYP_CODE = '"+prod_resources.getResourceType()+"' OR RESC_TYP_CODE IS NULL) AND (BILG_SYS_TYP_CD = "+prod_resources.getBillingSysType()+" OR BILG_SYS_TYP_CD IS NULL)");
				Resource resource = new Resource();
				if (count_resource > 0) {
					if (prod_resources.getResourceVersion() == null) {
						resource_id = stagingDAO
								.retreiveData("SELECT RESC_ID FROM RESC WHERE BILG_SYS_CODE = "
										+ prod_resources.getBillingSysCode()
										+ " AND ( RESC_VERS IS NULL) AND RESC_CD = "
										+ prod_resources.getResourceCode()
										+ " AND (RESC_TYP_CODE = '"
										+ prod_resources.getResourceType()
										+ "'  OR RESC_TYP_CODE IS NULL)");
					} else {
						resource_id = stagingDAO
								.retreiveData("SELECT RESC_ID FROM RESC WHERE BILG_SYS_CODE = "
										+ prod_resources.getBillingSysCode()
										+ " AND (RESC_VERS = "
										+ prod_resources.getResourceVersion()
										+ " ) AND RESC_CD = "
										+ prod_resources.getResourceCode()
										+ " AND (RESC_TYP_CODE = '"
										+ prod_resources.getResourceType()
										+ "'  OR RESC_TYP_CODE IS NULL)");

					}
					resource_id_list.add(resource_id);
					Resource existing_resource = stagingDAO
							.findResourceUsingId(resource_id);
					existing_resource.setBilgSysTypeCode(prod_resources.getBillingSysType());
					existing_resource.setModifiedDate(addNewProductsVO
							.getModifiedDate());
					existing_resource.setModifiedUser(addNewProductsVO
							.getModifiedUser());
					LOGGER.info("Existing Resource" + existing_resource);
					new_resource = stagingDAO.updateResource(existing_resource);

					List<Long> rescDtlIdList = new ArrayList<Long>();
					for (ResourceMetadataVO resource_metadata : prod_resources
							.getResourceMetadata()) {
						if (resource_metadata.getResourceMetadataCode() != null
								&& resource_metadata.getResourceMetadataValue() != null) {

							LOGGER.info("resource metacode"
									+ resource_metadata
											.getResourceMetadataCode());
							LOGGER.info("resource metavalue"
									+ resource_metadata
											.getResourceMetadataValue());

							Long resource_metadata_code = resource_metadata
									.getResourceMetadataCode();
							String resource_metadata_value = resource_metadata
									.getResourceMetadataValue();
							Long count_resource_details = stagingDAO
									.retreiveData("SELECT count(RESC_DTL_ID) FROM RESC_DTL WHERE RESC_ID = "
											+ resource_id
											+ " AND RESC_MTDT_VAL = '"
											+ resource_metadata_value
											+ " AND RESC_DTL_MTDT_CD = "
											+ resource_metadata_code + "'");
							ResourceDetails resource_details = new ResourceDetails();
							if (count_resource_details > 0) {
								Long existing_resource_details_id = stagingDAO
										.retreiveData("SELECT RESC_DTL_ID FROM RESC_DTL WHERE RESC_ID = "
												+ resource_id
												+ " AND RESC_MTDT_VAL = '"
												+ resource_metadata_value
												+ " AND RESC_DTL_MTDT_CD = "
												+ resource_metadata_code + "'");
								ResourceDetails existing_resource_details = stagingDAO
										.findResourceDetailsUsingId(existing_resource_details_id);
								existing_resource_details
										.setModifiedDate(addNewProductsVO
												.getModifiedDate());
								existing_resource_details
										.setModifiedUser(addNewProductsVO
												.getModifiedUser());
								LOGGER.info("Existing ResourceDetails"
										+ existing_resource_details);
								new_resource_details = stagingDAO
										.updateResourceDetails(existing_resource_details);
							} else {
								resource_details.setRescDtlId(stagingDAO
										.retrieveMaxResourceDetailsId());
								resource_details.setRescId(resource_id);
								resource_details
										.setRescDtlMetaDataCode(resource_metadata_code);
								resource_details
										.setRescDtlMetaDataVal(resource_metadata_value);
								resource_details
										.setCreatedDate(addNewProductsVO
												.getCreatedDate());
								resource_details
										.setCreatedUser(addNewProductsVO
												.getCreatedUser());
								resource_details
										.setModifiedDate(addNewProductsVO
												.getModifiedDate());
								resource_details
										.setModifiedUser(addNewProductsVO
												.getModifiedUser());
								LOGGER.info("New ResourceDetails"
										+ resource_details);
								new_resource_details = stagingDAO
										.updateResourceDetails(resource_details);
							}
							rescDtlIdList.add(new_resource_details
									.getRescDtlId());
						}
					}

					if (rescDtlIdList.size() > 0) {
						String rescDtl = rescDtlIdList.toString();
						rescDtl = rescDtl.replace("[", "").replace("]", "");
						String deleteQuery = "ResourceDetails.removeRescDtlById";
						String parameter = "rescDtlId";
						String rescParameter = "rescId";

						stagingDAO.removeRescDtlId(rescDtlIdList, deleteQuery,
								parameter, rescParameter, resource_id);
					}

				} else {
					resource_id = stagingDAO.retrieveMaxResourceId();
					resource_id_list.add(resource_id);
					resource.setRescId(resource_id);
					resource.setBilgSysCode(prod_resources.getBillingSysCode());
					resource.setRescVersion(prod_resources.getResourceVersion());
					resource.setBilgSysTypeCode(prod_resources
							.getBillingSysType());
					resource.setRescCode(prod_resources.getResourceCode());
					resource.setRescTypeCode(prod_resources.getResourceType());
					resource.setCreatedDate(addNewProductsVO.getCreatedDate());
					resource.setCreatedUser(addNewProductsVO.getCreatedUser());
					resource.setModifiedDate(addNewProductsVO.getModifiedDate());
					resource.setModifiedUser(addNewProductsVO.getModifiedUser());
					resource.setInactiveIndicator(1L);
					LOGGER.info("New Resource" + resource);
					new_resource = stagingDAO.updateResource(resource);

					List<Long> rescDtlIdList = new ArrayList<Long>();
					for (ResourceMetadataVO resource_metadata : prod_resources
							.getResourceMetadata()) {
						if (resource_metadata.getResourceMetadataCode() != null
								&& resource_metadata.getResourceMetadataValue() != null) {

							LOGGER.info("resource metacode"
									+ resource_metadata
											.getResourceMetadataCode());
							LOGGER.info("resource metavalue"
									+ resource_metadata
											.getResourceMetadataValue());

							Long resource_metadata_code = resource_metadata
									.getResourceMetadataCode();
							String resource_metadata_value = resource_metadata
									.getResourceMetadataValue();
							Long count_resource_details = stagingDAO
									.retreiveData("SELECT count(RESC_DTL_ID) FROM RESC_DTL WHERE RESC_ID = "
											+ resource_id
											+ " AND RESC_MTDT_VAL = '"
											+ resource_metadata_value
											+ " AND RESC_DTL_MTDT_CD = "
											+ resource_metadata_code + "'");
							ResourceDetails resource_details = new ResourceDetails();
							if (count_resource_details > 0) {
								Long existing_resource_details_id = stagingDAO
										.retreiveData("SELECT RESC_DTL_ID FROM RESC_DTL WHERE RESC_ID = "
												+ resource_id
												+ " AND RESC_MTDT_VAL = '"
												+ resource_metadata_value
												+ " AND RESC_DTL_MTDT_CD = "
												+ resource_metadata_code + "'");
								ResourceDetails existing_resource_details = stagingDAO
										.findResourceDetailsUsingId(existing_resource_details_id);
								existing_resource_details
										.setModifiedDate(addNewProductsVO
												.getModifiedDate());
								existing_resource_details
										.setModifiedUser(addNewProductsVO
												.getModifiedUser());
								LOGGER.info("Existing ResourceDetails"
										+ existing_resource_details);
								new_resource_details = stagingDAO
										.updateResourceDetails(existing_resource_details);
							} else {
								resource_details.setRescDtlId(stagingDAO
										.retrieveMaxResourceDetailsId());
								resource_details.setRescId(resource_id);
								resource_details
										.setRescDtlMetaDataCode(resource_metadata_code);
								resource_details
										.setRescDtlMetaDataVal(resource_metadata_value);
								resource_details
										.setCreatedDate(addNewProductsVO
												.getCreatedDate());
								resource_details
										.setCreatedUser(addNewProductsVO
												.getCreatedUser());
								resource_details
										.setModifiedDate(addNewProductsVO
												.getModifiedDate());
								resource_details
										.setModifiedUser(addNewProductsVO
												.getModifiedUser());
								LOGGER.info("New ResourceDetails"
										+ resource_details);
								new_resource_details = stagingDAO
										.updateResourceDetails(resource_details);
							}
							rescDtlIdList.add(new_resource_details
									.getRescDtlId());
						}

					}
					if (rescDtlIdList.size() > 0) {
						String rescDtl = rescDtlIdList.toString();
						rescDtl = rescDtl.replace("[", "").replace("]", "");
						String deleteQuery = "ResourceDetails.removeRescDtlById";
						String parameter = "rescDtlId";
						String rescParameter = "rescId";
						
						stagingDAO.removeRescDtlId(rescDtlIdList, deleteQuery,
								parameter, rescParameter, resource_id);
					}

				}
			}
		}
		return resource_id_list;
	}

	@SuppressWarnings("unused")
	@Override
	@Transactional("stgTransactionManager")
	public Long editProducts(AddNewProductsVO addNewProductsVO) {
		Long prod_id = addNewProductsVO.getProdId();
		// Long updateNewProd(AddNewProductsVO addNewProductsVO)

		// Update Product
		Long prodid = updateNewProd(addNewProductsVO);
		// update product group
		updateProductGroup(addNewProductsVO, prod_id);

		// update product details
		// Product Detail Delete/Insert/Update - Starts
		List<Long> prodDtlIdList = new ArrayList<Long>();
		for (ProductMetaData prodMetaData : addNewProductsVO
				.getProductMetaData()) {
			if (prodMetaData.getProductMetadataCode() != null
					&& prodMetaData.getProductMetadataValue() != null) {
				Long prodDtlId = updateProductDetailsMetaData(prodMetaData,
						addNewProductsVO.getProdId(),
						addNewProductsVO.getModifiedDate(),
						addNewProductsVO.getModifiedUser());
				prodDtlIdList.add(prodDtlId);
			}
		}
		if (prodDtlIdList.size() > 0) {
			String prodDtl = prodDtlIdList.toString();
			prodDtl = prodDtl.replace("[", "").replace("]", "");
			String deleteQuery = "ProductDetails.removeproductDtlById";
			String parameter = "productDtlId";
			String prodParameter = "productID";
			// stagingDAO.removeDtlID(prodDtl,deleteQuery,parameter,prod_id,prodParameter);
			stagingDAO.removeDtlID(prodDtlIdList, deleteQuery, parameter,
					prod_id, prodParameter);
		}
		// Product Detail Delete/Insert/Update - Ends

		// update sales channel
		Long sales_channel_id = updateSalesChannel(addNewProductsVO);

		// ////////////////////////////Logic for sales channel details
		// update//////////////////////////
		List<Long> salesChnlDtlIdList = new ArrayList<Long>();
		for (SalesMetadataVO salesMetadata : addNewProductsVO
				.getSalesMetadata()) {
			if (salesMetadata.getSalesMetadataCode() != null
					&& salesMetadata.getSalesMetadataValue() != null) {
				Long salesChnlDtlId = updateSalesChannelDetailsMetadata(
						salesMetadata, addNewProductsVO.getSaleChnlid(),
						addNewProductsVO.getModifiedDate(),
						addNewProductsVO.getModifiedUser());
				salesChnlDtlIdList.add(salesChnlDtlId);
			}
		}
		if (salesChnlDtlIdList.size() > 0) {
			String salesDtl = salesChnlDtlIdList.toString();
			salesDtl = salesDtl.replace("[", "").replace("]", "");
			String deleteQuery = "SalesChannelDetails.removesalesDtlById";
			String parameter = "salesChnlDtlId";
			String salesParameter = "salesChnlId";

			stagingDAO.removeSalesDtlId(salesChnlDtlIdList, deleteQuery,
					parameter, sales_channel_id, salesParameter);
		}
		// /////////////////////////////////////////////////////////////////////////////////////////////

		// update product availability
		Long prod_avail_id = updateProductAvailability(addNewProductsVO,
				prod_id, sales_channel_id);

		// update product market

		List<Long> prod_market_id_list = new ArrayList<Long>();
		Long prod_avlb_id = stagingDAO
				.retreiveData("select prod_avlb_id from prod_avlb where SLS_CHNL_ID ="
						+ addNewProductsVO.getSaleChnlid()
						+ " and PROD_ID = "
						+ addNewProductsVO.getProdId() + "");
		for (Long marketCode : addNewProductsVO.getCountryList()) {
			//
			Long count_prod_market = stagingDAO
					.retreiveData("SELECT count(PROD_MKT_ID) FROM PROD_MKT WHERE PROD_AVLB_ID = "
							+ prod_avlb_id + " AND MKT_CD = " + marketCode + "");
			ProductMarket prod_market = new ProductMarket();
			ProductMarket prod_markt = new ProductMarket();
			Long prod_market_id = null;
			if (count_prod_market > 0) {
				prod_market_id = stagingDAO
						.retreiveData("SELECT PROD_MKT_ID FROM PROD_MKT WHERE PROD_AVLB_ID = "
								+ prod_avlb_id
								+ " AND MKT_CD = "
								+ marketCode
								+ "");
				ProductMarket existing_prod_market = stagingDAO
						.findProductMarketUsingId(prod_market_id);
				existing_prod_market.setModifiedDate(addNewProductsVO
						.getModifiedDate());
				existing_prod_market.setModifiedUser(addNewProductsVO
						.getModifiedUser());
				LOGGER.info("Existing ProductMarket" + existing_prod_market);
				prod_markt = stagingDAO
						.updateProductMarket(existing_prod_market);
			} else {
				prod_market_id = stagingDAO.retrieveMaxProductMarketId();
				prod_market.setProductMktId(prod_market_id);
				prod_market.setProductAvlbId(prod_avlb_id);
				prod_market.setMktCd(marketCode);
				prod_market.setCreatedDate(addNewProductsVO.getCreatedDate());
				prod_market.setCreatedUser(addNewProductsVO.getCreatedUser());
				prod_market.setModifiedDate(addNewProductsVO.getModifiedDate());
				prod_market.setModifiedUser(addNewProductsVO.getModifiedUser());
				LOGGER.info("New ProductMarket" + prod_market);
				prod_markt = stagingDAO.updateProductMarket(prod_market);
			}
			//
			prod_market_id_list.add(prod_markt.getProductMktId());

		}

		// update market group
		updateMarketGroup(addNewProductsVO, prod_market_id_list);

		// update resource
		List<Long> resource_id_list = updateResourceData(addNewProductsVO);

		// update resource mapping
		updateResourceMapping(addNewProductsVO, prod_id, resource_id_list);
		List<ProductResources> prodRescList = addNewProductsVO
				.getProductResources();
		List<ProductResources> prodRescLst = new ArrayList<ProductResources>();
		for (ProductResources prodResc : prodRescList) {
			try {
				if (prodResc.getResourceCode() == null) {
					prodRescLst.add(prodResc);
				}
			} catch (Exception e) {
				LOGGER.error("ProductServiceImpl | editProducts", e);
			}
		}
		prodRescList.removeAll(prodRescLst);
		addNewProductsVO.setProductResources(prodRescList);
		// update resource group
		updateResourceGroup(addNewProductsVO, resource_id_list);

		// Product Resource - Delete block - Starts

		List<Long> resource_id_lst = resource_id_list; // Retained Resc ID - not
														// in //update resource
		List<Long> rescMapList = stagingDAO.retrieveRescId(prod_id); // All Resc
																		// ID
		List<ResourceMapping> rescMapLst = stagingDAO.retrieveAllRescId(
				prod_id, resource_id_lst); // resc id not present in
											// resource_id_lst

		String deleteQuery = "ResourceDetails.removerescDtlById";
		String parameter = "rescIdNot";
		String prodParameter = "rescId";
		stagingDAO.removeRescDtlID(resource_id_lst, deleteQuery, parameter,
				rescMapList, prodParameter); // Resc Dtl Id deletion

		Set<Long> rescMapId = new HashSet<Long>();
		Set<Long> rescId = new HashSet<Long>();

		for (ResourceMapping rescMap : rescMapLst) {
			rescMapId.add(rescMap.getRescMapId());
		}
		for (ResourceMapping rescMap : rescMapLst) {
			rescId.add(rescMap.getRescId());
		}
		if (rescMapId.size() > 0) {
			List<Long> rescMaplist = new ArrayList<Long>(rescMapId);

			String deleteQueryProdResc = "ProdRescScrGru.removeProdRescScrGraById";
			stagingDAO.removeProdRescID(rescMaplist, deleteQueryProdResc,
					"rescMapId"); // Prod Resc Scr Gran Map Id deletion

			String deleteQueryRescMap = "ResourceMapping.removeRescMapById";
			stagingDAO.removeProdRescID(rescMaplist, deleteQueryRescMap,
					"rescMapId"); // Resc Map Id deletion

			if (rescId.size() > 0) {

				List<Long> rescIdList = new ArrayList<Long>(rescId);

				String deleteQueryRescGrp = "ResourceGroup.removeRescGrpById";
				stagingDAO.removeProdRescID(rescIdList, deleteQueryRescGrp,
						"rescId"); // Resc Grp Id deletion

				String deleteQueryResc = "Resource.removeRescById";
				stagingDAO.removeProdRescID(rescIdList, deleteQueryResc,
						"rescId"); // Resc Id deletion

			}

		}

		// Product Resource - Delete block - Ends

		return addNewProductsVO.getProdId();

	}

	private Long updateSalesChannelDetailsMetadata(
			SalesMetadataVO salesMetadata, Long saleChnlid, Date modifiedDate,
			String modifiedUser) {

		SalesChannelDetails new_sales_channel_details = new SalesChannelDetails();

		if (salesMetadata.getSalesMetadataCode() != null
				&& salesMetadata.getSalesMetadataValue() != null) {
			Long sales_chnl_dtl = null;
			if (saleChnlid != null) {

				Long count_sales_channel_details = stagingDAO
						.retreiveData("SELECT count(SLS_CHNL_DTL_ID) FROM SLS_CHNL_DTL WHERE SLS_CHNL_DTL_MTDT_CD = "
								+ salesMetadata.getSalesMetadataCode()
								+ " AND SLS_CHNL_DTL_MTDT_VAL = '"
								+ salesMetadata.getSalesMetadataValue()
								+ "' AND SLS_CHNL_ID = " + saleChnlid + "");
				SalesChannelDetails sales_channel_details = new SalesChannelDetails();
				if (count_sales_channel_details > 0) {
					sales_chnl_dtl = stagingDAO
							.retreiveData("SELECT SLS_CHNL_DTL_ID FROM SLS_CHNL_DTL WHERE SLS_CHNL_DTL_MTDT_CD = "
									+ salesMetadata.getSalesMetadataCode()
									+ " AND SLS_CHNL_DTL_MTDT_VAL = '"
									+ salesMetadata.getSalesMetadataValue()
									+ "' AND SLS_CHNL_ID = " + saleChnlid + "");
					SalesChannelDetails existing_sales_channel_details = stagingDAO
							.findSalesChannelDetailsUsingId(sales_chnl_dtl);
					existing_sales_channel_details
							.setModifiedDate(modifiedDate);
					existing_sales_channel_details
							.setModifiedUser(modifiedUser);
					LOGGER.info("Existing Sales channel details"
							+ existing_sales_channel_details);
					new_sales_channel_details = stagingDAO
							.updateSalesChannelDetails(existing_sales_channel_details);
				} else {
					sales_chnl_dtl = stagingDAO
							.retrieveMaxSalesChannelDetailsId();
					sales_channel_details.setSalesChnlDtlId(sales_chnl_dtl);
					sales_channel_details
							.setSalesChnlDtlMetaDataCode(salesMetadata
									.getSalesMetadataCode());
					sales_channel_details
							.setSalesChnlDtlMetaDataVal(salesMetadata
									.getSalesMetadataValue());
					sales_channel_details.setSalesChnlId(saleChnlid);
					sales_channel_details.setCreatedDate(new Date());
					sales_channel_details.setCreatedUser(modifiedUser);
					sales_channel_details.setModifiedDate(modifiedDate);
					sales_channel_details.setModifiedUser(modifiedUser);
					LOGGER.info("New Sales channel details"
							+ sales_channel_details);
					new_sales_channel_details = stagingDAO
							.updateSalesChannelDetails(sales_channel_details);
				}
			}
		}
		return new_sales_channel_details.getSalesChnlDtlId();
	}

	@Override
	public Long countOfProductScrRpt(ProductScoreReportVO productScoreReportVO) {

		String query = "";
		int targetSize = 999;
		String[] mktCd = productScoreReportVO.getMkt_cd().split(",");
		List<String> mktCdList = new ArrayList<String>(Arrays.asList(mktCd));

		List<List<String>> lists = split(mktCdList, targetSize);
		String strMktCd = "";
		String orVal = "OR";
		String append = " PROD_MKT.MKT_CD in (";
		String end = ") ";
		for (List<String> lis : lists) {
			String[] val = lis.toArray(new String[lis.size()]);
			String valStr = Arrays.toString(val);
			valStr = valStr.replace("[", "").replace("]", "");
			if (strMktCd.equalsIgnoreCase("")) {
				strMktCd = strMktCd + " PROD_MKT.MKT_CD in (" + valStr + ") ";
			} else if (valStr.length() > 0) {
				strMktCd = strMktCd + orVal + append + valStr + end;
			}
		}
		String[] product_cd = productScoreReportVO.getProduct_cd().split(",");
		List<String> product_cdList = new ArrayList<String>(
				Arrays.asList(product_cd));

		List<List<String>> lisrts = split(product_cdList, targetSize);
		String productcd = "";
		String appendproduct_cd = " PROD_CD in (";
		for (List<String> lis : lisrts) {
			String[] val = lis.toArray(new String[lis.size()]);
			String valStr = Arrays.toString(val);
			valStr = valStr.replace("[", "").replace("]", "");
			if (productcd.equalsIgnoreCase("")) {
				productcd = productcd + " PROD_CD in (" + valStr + ") ";
			} else if (valStr.length() > 0) {
				productcd = productcd + orVal + appendproduct_cd + valStr + end;
			}
		}
		String[] resc_cd = null;
		List<String> resc_cdList = null;
		String resccd = "";
		if ((productScoreReportVO.getResc_cd() != null)) {
			resc_cd = productScoreReportVO.getResc_cd().split(",");
			resc_cdList = new ArrayList<String>(Arrays.asList(resc_cd));

			List<List<String>> lisrs = split(resc_cdList, targetSize);

			String appendresc_cd = " RESC.RESC_CD in (";
			for (List<String> lis : lisrs) {
				String[] val = lis.toArray(new String[lis.size()]);
				String valStr = Arrays.toString(val);
				valStr = valStr.replace("[", "").replace("]", "");
				if (resccd.equalsIgnoreCase("")) {
					resccd = resccd + " RESC.RESC_CD in (" + valStr + ") ";
				} else if (valStr.length() > 0) {
					resccd = resccd + orVal + appendresc_cd + valStr + end;
				}
			}
		}

		String[] mktCdScr = productScoreReportVO.getMkt_cd_scr().split(",");
		List<String> mktCdScrList = new ArrayList<String>(
				Arrays.asList(mktCdScr));

		List<List<String>> listsScr = split(mktCdScrList, targetSize);
		String strMktCdScr = "";
		String appendScr = " scr.scr_mkt_cd in (";
		for (List<String> lis : listsScr) {
			String[] val = lis.toArray(new String[lis.size()]);
			String valStr = Arrays.toString(val);
			valStr = valStr.replace("[", "").replace("]", "");
			if (strMktCdScr.equalsIgnoreCase("")) {
				strMktCdScr = strMktCdScr + " scr.scr_mkt_cd in (" + valStr
						+ ") ";
			} else if (valStr.length() > 0) {
				strMktCdScr = strMktCdScr + orVal + appendScr + valStr + end;
			}
		}

		String[] scr_typ_cd = productScoreReportVO.getSr_typ_cd().split(",");
		List<String> scr_typ_cdList = new ArrayList<String>(
				Arrays.asList(scr_typ_cd));

		List<List<String>> lisrtsScr = split(scr_typ_cdList, targetSize);
		String scrtycd = "";
		String appendScr_typ_cd = " scr_typ_cd in (";
		for (List<String> lis : lisrtsScr) {
			String[] val = lis.toArray(new String[lis.size()]);
			String valStr = Arrays.toString(val);
			valStr = valStr.replace("[", "").replace("]", "");
			if (scrtycd.equalsIgnoreCase("")) {
				scrtycd = scrtycd + " scr_typ_cd in (" + valStr + ") ";
			} else if (valStr.length() > 0) {
				scrtycd = scrtycd + orVal + appendScr_typ_cd + valStr + end;
			}
		}
		String[] scr_gru_cd = null;
		List<String> scr_gru_cdList = null;
		String scrgrucd = "";
		if ((productScoreReportVO.getSr_gru_cd() != null)) {
			scr_gru_cd = productScoreReportVO.getSr_gru_cd().split(",");
			scr_gru_cdList = new ArrayList<String>(Arrays.asList(scr_gru_cd));

			List<List<String>> lisrs = split(scr_gru_cdList, targetSize);

			String appendScr_gru_cd = " scr_gru_cd in (";
			for (List<String> lis : lisrs) {
				String[] val = lis.toArray(new String[lis.size()]);
				String valStr = Arrays.toString(val);
				valStr = valStr.replace("[", "").replace("]", "");
				if (scrgrucd.equalsIgnoreCase("")) {
					scrgrucd = scrgrucd + " scr_gru_cd in (" + valStr + ") ";
				} else if (valStr.length() > 0) {
					scrgrucd = scrgrucd + orVal + appendScr_gru_cd + valStr
							+ end;
				}
			}
		}

		if ((!(productScoreReportVO.getResc_cd() != null))
				|| ((("").equalsIgnoreCase(productScoreReportVO.getResc_cd())))) {
			if ((!(productScoreReportVO.getSr_gru_cd() != null))
					|| ((("").equalsIgnoreCase(productScoreReportVO
							.getSr_gru_cd())))) {

				query = "SELECT count(*) as cnt from (SELECT  query1.scr_mkt_cd_id,query1.country_name, query1.scr_typ_cd_id as scr_typ_cd_id,query1.scr_typ_cd_shrt_d as scr_typ_cd_shrt_d,query1.scr_typ_cd_val_d as scr_typ_cd_val_d, query1.scr_gru_cd_id as scr_gru_cd_id,query1.scr_gru_cd_shrt_d as scr_gru_cd_shrt_d,query1.scr_gru_cd_val_d as scr_gru_cd_val_d, query1.scr_id as scr_id,query1.scr_gru_cd as scr_gru_cd,query1.scr_gru_id as scr_gru_id,query1.scr_typ_assn_id as scr_typ_assn_id, query1.scr_typ_id as scr_typ_id, query1.scr_mkt_cd as scr_mkt_cd,query1.scr_typ_cd as scr_typ_cd,query1.scr_dtl_id,prod_resc_to_scr_gru.prod_resc_to_scr_gru_ID as prodScrMapId,query1.scr_vers   from prod_resc_to_scr_gru,(SELECT  GEO_UNIT_ID as scr_mkt_cd_id,GEO_NME as country_name, subquery7.scr_typ_cd_id as scr_typ_cd_id,subquery7.scr_typ_cd_shrt_d as scr_typ_cd_shrt_d,subquery7.scr_typ_cd_val_d as scr_typ_cd_val_d, subquery7.scr_gru_cd_id as scr_gru_cd_id,subquery7.scr_gru_cd_shrt_d as scr_gru_cd_shrt_d,subquery7.scr_gru_cd_val_d as scr_gru_cd_val_d,subquery7.scr_id as scr_id,subquery7.scr_gru_cd as scr_gru_cd,subquery7.scr_gru_id as scr_gru_id,subquery7.scr_typ_assn_id as scr_typ_assn_id,subquery7.scr_typ_id as scr_typ_id, subquery7.scr_mkt_cd as scr_mkt_cd,subquery7.scr_typ_cd as scr_typ_cd,subquery7.scr_dtl_id,subquery7.scr_vers   from GEO_UNIT_NME,(SELECT   CD_VAL_ID as scr_typ_cd_id,CD_VAL_SHRT_DESC as scr_typ_cd_shrt_d,CD_VAL_DESC as scr_typ_cd_val_d,  subquery6.scr_gru_cd_id,subquery6.scr_gru_cd_shrt_d,subquery6.scr_gru_cd_val_d,subquery6.scr_id as scr_id,subquery6.scr_gru_cd as scr_gru_cd,subquery6.scr_gru_id as scr_gru_id,subquery6.scr_typ_assn_id as scr_typ_assn_id,subquery6.scr_typ_id as scr_typ_id,  subquery6.scr_mkt_cd as scr_mkt_cd,subquery6.scr_typ_cd as scr_typ_cd,subquery6.scr_dtl_id,subquery6.scr_vers    from CD_VAL_TXT,(SELECT CD_VAL_ID as scr_gru_cd_id,CD_VAL_SHRT_DESC as scr_gru_cd_shrt_d,CD_VAL_DESC as scr_gru_cd_val_d,subquery5.scr_id as scr_id,subquery5.scr_gru_cd as scr_gru_cd,subquery5.scr_gru_id as scr_gru_id,subquery5.scr_typ_assn_id as scr_typ_assn_id,subquery5.scr_typ_id as scr_typ_id,  subquery5.scr_mkt_cd as scr_mkt_cd,subquery5.scr_typ_cd as scr_typ_cd,subquery5.scr_dtl_id,subquery5.scr_vers  from CD_VAL_TXT,(  SELECT subquery3.scr_id as scr_id,scr_gru.scr_gru_cd as scr_gru_cd,subquery3.scr_gru_id as scr_gru_id,subquery3.scr_typ_assn_id as scr_typ_assn_id,subquery3.scr_typ_id as scr_typ_id,  subquery3.scr_mkt_cd as scr_mkt_cd,subquery3.scr_typ_cd as scr_typ_cd,subquery3.scr_dtl_id,subquery3.scr_vers  from scr_gru,(SELECT scr_typ_assn.scr_gru_id as scr_gru_id,subquery2.scr_typ_assn_id as scr_typ_assn_id,subquery2.scr_id as scr_id,subquery2.scr_typ_id as scr_typ_id,  subquery2.scr_mkt_cd as scr_mkt_cd,subquery2.scr_typ_cd as scr_typ_cd,subquery2.scr_dtl_id,subquery2.scr_vers   from scr_typ_assn,(SELECT scr_dtl.scr_typ_assn_id as scr_typ_assn_id, subquery1.scr_id as scr_id,subquery1.scr_typ_id as scr_typ_id,  subquery1.scr_mkt_cd as scr_mkt_cd,subquery1.scr_typ_cd as scr_typ_cd,scr_dtl.scr_dtl_id as scr_dtl_id,subquery1.scr_vers   FROM scr_dtl,   (SELECT scr.scr_id,scr.scr_typ_id,scr.scr_mkt_cd,subquery4.scr_typ_cd as scr_typ_cd,scr.scr_ver as scr_vers   FROM scr,   (select scr_typ_id,scr_typ_cd from scr_typ where ("
						+ scrtycd
						+ ")"
						+ ") subquery4  WHERE subquery4.scr_typ_id = scr.scr_typ_id and ("
						+ strMktCdScr
						+ ")"
						+ ") subquery1   WHERE subquery1.scr_id = scr_dtl.scr_id) subquery2  WHERE subquery2.scr_typ_assn_id = scr_typ_assn.scr_typ_assn_id) subquery3   WHERE subquery3.scr_gru_id = scr_gru.scr_gru_id) subquery5    WHERE subquery5.scr_gru_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6   WHERE subquery6.scr_typ_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7  WHERE subquery7.scr_mkt_cd = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32 order by GEO_UNIT_NME.GEO_NME) query1  WHERE query1.scr_dtl_id = prod_resc_to_scr_gru.SCR_DTL_ID) qur1  JOIN   (SELECT   query2.prodAvailId,query2.saleChnlid,query2.prodMktId,  query2.mktCd,  query2.prodId,query2.prodFamCd,  query2.prodCd,query2.prodInacIndc,query2.prodVers,query2.rescMapId,  query2.rescId,query2.bilgSysCd,query2.rescVers,  query2.rescCd,query2.rescTypCd,query2.bilgSysTypCd,  query2.countryCode,  query2.countryDesc,query2.productCode,query2.prodCodeShrtDesc,  query2.prodCodeDesc,  query2.rescCode,query2.rescCodeShrtDesc,query2.rescCodeDesc,query2.prodGrpId,query2.prodGrpCd,  query2.prodDtlId,query2.prodDtlMtdtCd,query2.prodDtlMtdCdVal,  query2.mktGrpId,query2.mktGrpCd,  query2.rescGrpId,query2.rescGrpCd,  query2.rescDtlID,query2.rescDtlMtdtCd,query2.rescMtdtVal,  query2.slsChnlDtlID,query2.slsChnlDtlMtdtCd,  query2.slsChnlDtlMtdtVal,  query2.prodGrpCdShrtDesc,query2.prodGrpCdDesc,  query2.prodDtlMtdtCdShrtDesc,query2.prodDtlMtdtCdDesc,  query2.mktGrpCdShrtDesc,query2.mktGrpCdDesc,  query2.rescGrpCdShrtDesc,query2.rescGrpCdDesc,  query2.rescDtlMtdtCdShrtDesc,query2.rescDtlMtdtCdDesc,  query2.slsChnlDtlMtdtCdShrtDesc,query2.slsChnlDtlMtdtCdDesc,prod_resc_to_scr_gru.prod_resc_to_scr_gru_ID as prodScrMapId from prod_resc_to_scr_gru, (SELECT   subquery18.prodAvailId,subquery18.saleChnlid,subquery18.prodMktId,  subquery18.mktCd,  subquery18.prodId,subquery18.prodFamCd,  subquery18.prodCd,subquery18.prodInacIndc,subquery18.prodVers,subquery18.rescMapId,  subquery18.rescId,subquery18.bilgSysCd,subquery18.rescVers,  subquery18.rescCd,subquery18.rescTypCd,subquery18.bilgSysTypCd,  subquery18.countryCode,  subquery18.countryDesc,subquery18.productCode,subquery18.prodCodeShrtDesc,  subquery18.prodCodeDesc,  subquery18.rescCode,subquery18.rescCodeShrtDesc,subquery18.rescCodeDesc,subquery18.prodGrpId,subquery18.prodGrpCd,  subquery18.prodDtlId,subquery18.prodDtlMtdtCd,subquery18.prodDtlMtdCdVal,  subquery18.mktGrpId,subquery18.mktGrpCd,  subquery18.rescGrpId,subquery18.rescGrpCd,  subquery18.rescDtlID,subquery18.rescDtlMtdtCd,subquery18.rescMtdtVal,  subquery18.slsChnlDtlID,subquery18.slsChnlDtlMtdtCd,  subquery18.slsChnlDtlMtdtVal,  subquery18.prodGrpCdShrtDesc,subquery18.prodGrpCdDesc,  subquery18.prodDtlMtdtCdShrtDesc,subquery18.prodDtlMtdtCdDesc,  subquery18.mktGrpCdShrtDesc,subquery18.mktGrpCdDesc,  subquery18.rescGrpCdShrtDesc,subquery18.rescGrpCdDesc,  subquery18.rescDtlMtdtCdShrtDesc,subquery18.rescDtlMtdtCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as slsChnlDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as slsChnlDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery17.prodAvailId,subquery17.saleChnlid,subquery17.prodMktId,  subquery17.mktCd,  subquery17.prodId,subquery17.prodFamCd,  subquery17.prodCd,subquery17.prodInacIndc,subquery17.prodVers,subquery17.rescMapId,  subquery17.rescId,subquery17.bilgSysCd,subquery17.rescVers,  subquery17.rescCd,subquery17.rescTypCd,subquery17.bilgSysTypCd,  subquery17.countryCode,  subquery17.countryDesc,subquery17.productCode,subquery17.prodCodeShrtDesc,  subquery17.prodCodeDesc,  subquery17.rescCode,subquery17.rescCodeShrtDesc,subquery17.rescCodeDesc,subquery17.prodGrpId,subquery17.prodGrpCd,  subquery17.prodDtlId,subquery17.prodDtlMtdtCd,subquery17.prodDtlMtdCdVal,  subquery17.mktGrpId,subquery17.mktGrpCd,  subquery17.rescGrpId,subquery17.rescGrpCd,  subquery17.rescDtlID,subquery17.rescDtlMtdtCd,subquery17.rescMtdtVal,  subquery17.slsChnlDtlID,subquery17.slsChnlDtlMtdtCd,  subquery17.slsChnlDtlMtdtVal,  subquery17.prodGrpCdShrtDesc,subquery17.prodGrpCdDesc,  subquery17.prodDtlMtdtCdShrtDesc,subquery17.prodDtlMtdtCdDesc,  subquery17.mktGrpCdShrtDesc,subquery17.mktGrpCdDesc,  subquery17.rescGrpCdShrtDesc,subquery17.rescGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery16.prodAvailId,subquery16.saleChnlid,subquery16.prodMktId,  subquery16.mktCd,  subquery16.prodId,subquery16.prodFamCd,  subquery16.prodCd,subquery16.prodInacIndc,subquery16.prodVers,subquery16.rescMapId,  subquery16.rescId,subquery16.bilgSysCd,subquery16.rescVers,  subquery16.rescCd,subquery16.rescTypCd,subquery16.bilgSysTypCd,  subquery16.countryCode,  subquery16.countryDesc,subquery16.productCode,subquery16.prodCodeShrtDesc,  subquery16.prodCodeDesc,  subquery16.rescCode,subquery16.rescCodeShrtDesc,subquery16.rescCodeDesc,subquery16.prodGrpId,subquery16.prodGrpCd,  subquery16.prodDtlId,subquery16.prodDtlMtdtCd,subquery16.prodDtlMtdCdVal,  subquery16.mktGrpId,subquery16.mktGrpCd,  subquery16.rescGrpId,subquery16.rescGrpCd,  subquery16.rescDtlID,subquery16.rescDtlMtdtCd,subquery16.rescMtdtVal,  subquery16.slsChnlDtlID,subquery16.slsChnlDtlMtdtCd,  subquery16.slsChnlDtlMtdtVal,  subquery16.prodGrpCdShrtDesc,subquery16.prodGrpCdDesc,  subquery16.prodDtlMtdtCdShrtDesc,subquery16.prodDtlMtdtCdDesc,  subquery16.mktGrpCdShrtDesc,subquery16.mktGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescGrpCdDesc  from CD_VAL_TXT,  (SELECT   subquery15.prodAvailId,subquery15.saleChnlid,subquery15.prodMktId,  subquery15.mktCd,  subquery15.prodId,subquery15.prodFamCd,  subquery15.prodCd,subquery15.prodInacIndc,subquery15.prodVers,subquery15.rescMapId,  subquery15.rescId,subquery15.bilgSysCd,subquery15.rescVers,  subquery15.rescCd,subquery15.rescTypCd,subquery15.bilgSysTypCd,  subquery15.countryCode,  subquery15.countryDesc,subquery15.productCode,subquery15.prodCodeShrtDesc,  subquery15.prodCodeDesc,  subquery15.rescCode,subquery15.rescCodeShrtDesc,subquery15.rescCodeDesc,subquery15.prodGrpId,subquery15.prodGrpCd,  subquery15.prodDtlId,subquery15.prodDtlMtdtCd,subquery15.prodDtlMtdCdVal,  subquery15.mktGrpId,subquery15.mktGrpCd,  subquery15.rescGrpId,subquery15.rescGrpCd,  subquery15.rescDtlID,subquery15.rescDtlMtdtCd,subquery15.rescMtdtVal,  subquery15.slsChnlDtlID,subquery15.slsChnlDtlMtdtCd,  subquery15.slsChnlDtlMtdtVal,  subquery15.prodGrpCdShrtDesc,subquery15.prodGrpCdDesc,  subquery15.prodDtlMtdtCdShrtDesc,subquery15.prodDtlMtdtCdDesc,  GEO_UNIT_NME.GEO_NME as mktGrpCdShrtDesc,GEO_UNIT_NME.GEO_NME as mktGrpCdDesc  from GEO_UNIT_NME, GEO_UNIT,  (SELECT   subquery14.prodAvailId,subquery14.saleChnlid,subquery14.prodMktId,  subquery14.mktCd,  subquery14.prodId,subquery14.prodFamCd,  subquery14.prodCd,subquery14.prodInacIndc,subquery14.prodVers,subquery14.rescMapId,  subquery14.rescId,subquery14.bilgSysCd,subquery14.rescVers,  subquery14.rescCd,subquery14.rescTypCd,subquery14.bilgSysTypCd,  subquery14.countryCode,  subquery14.countryDesc,subquery14.productCode,subquery14.prodCodeShrtDesc,  subquery14.prodCodeDesc,  subquery14.rescCode,subquery14.rescCodeShrtDesc,subquery14.rescCodeDesc,subquery14.prodGrpId,subquery14.prodGrpCd,  subquery14.prodDtlId,subquery14.prodDtlMtdtCd,subquery14.prodDtlMtdCdVal,  subquery14.mktGrpId,subquery14.mktGrpCd,  subquery14.rescGrpId,subquery14.rescGrpCd,  subquery14.rescDtlID,subquery14.rescDtlMtdtCd,subquery14.rescMtdtVal,  subquery14.slsChnlDtlID,subquery14.slsChnlDtlMtdtCd,  subquery14.slsChnlDtlMtdtVal,  subquery14.prodGrpCdShrtDesc,subquery14.prodGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery13.prodAvailId,subquery13.saleChnlid,subquery13.prodMktId,  subquery13.mktCd,  subquery13.prodId,subquery13.prodFamCd,  subquery13.prodCd,subquery13.prodInacIndc,subquery13.prodVers,subquery13.rescMapId,  subquery13.rescId,subquery13.bilgSysCd,subquery13.rescVers,  subquery13.rescCd,subquery13.rescTypCd,subquery13.bilgSysTypCd,  subquery13.countryCode,  subquery13.countryDesc,subquery13.productCode,subquery13.prodCodeShrtDesc,  subquery13.prodCodeDesc,  subquery13.rescCode,subquery13.rescCodeShrtDesc,subquery13.rescCodeDesc,subquery13.prodGrpId,subquery13.prodGrpCd,  subquery13.prodDtlId,subquery13.prodDtlMtdtCd,subquery13.prodDtlMtdCdVal,  subquery13.mktGrpId,subquery13.mktGrpCd,  subquery13.rescGrpId,subquery13.rescGrpCd,  subquery13.rescDtlID,subquery13.rescDtlMtdtCd,subquery13.rescMtdtVal,  subquery13.slsChnlDtlID,subquery13.slsChnlDtlMtdtCd,  subquery13.slsChnlDtlMtdtVal,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodGrpCdDesc  from CD_VAL_TXT,  ( SELECT   subquery12.prodAvailId,subquery12.saleChnlid,subquery12.prodMktId,  subquery12.mktCd,  subquery12.prodId,subquery12.prodFamCd,  subquery12.prodCd,subquery12.prodInacIndc,subquery12.prodVers,subquery12.rescMapId,  subquery12.rescId,subquery12.bilgSysCd,subquery12.rescVers,  subquery12.rescCd,subquery12.rescTypCd,subquery12.bilgSysTypCd,  subquery12.countryCode,  subquery12.countryDesc,subquery12.productCode,subquery12.prodCodeShrtDesc,  subquery12.prodCodeDesc,  subquery12.rescCode,subquery12.rescCodeShrtDesc,subquery12.rescCodeDesc,subquery12.prodGrpId,subquery12.prodGrpCd,  subquery12.prodDtlId,subquery12.prodDtlMtdtCd,subquery12.prodDtlMtdCdVal,  subquery12.mktGrpId,subquery12.mktGrpCd,  subquery12.rescGrpId,subquery12.rescGrpCd,  subquery12.rescDtlID,subquery12.rescDtlMtdtCd,subquery12.rescMtdtVal,  SLS_CHNL_DTL.SLS_CHNL_DTL_ID as slsChnlDtlID,SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_CD as slsChnlDtlMtdtCd,  SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_VAL as slsChnlDtlMtdtVal  from SLS_CHNL_DTL,   (SELECT   subquery11.prodAvailId,subquery11.saleChnlid,subquery11.prodMktId,  subquery11.mktCd,  subquery11.prodId,subquery11.prodFamCd,  subquery11.prodCd,subquery11.prodInacIndc,subquery11.prodVers,subquery11.rescMapId,  subquery11.rescId,subquery11.bilgSysCd,subquery11.rescVers,  subquery11.rescCd,subquery11.rescTypCd,subquery11.bilgSysTypCd,  subquery11.countryCode,  subquery11.countryDesc,subquery11.productCode,subquery11.prodCodeShrtDesc,  subquery11.prodCodeDesc,  subquery11.rescCode,subquery11.rescCodeShrtDesc,subquery11.rescCodeDesc,subquery11.prodGrpId,subquery11.prodGrpCd,  subquery11.prodDtlId,subquery11.prodDtlMtdtCd,subquery11.prodDtlMtdCdVal,  subquery11.mktGrpId,subquery11.mktGrpCd,  subquery11.rescGrpId,subquery11.rescGrpCd,  RESC_DTL.RESC_DTL_ID as rescDtlID,RESC_DTL.RESC_DTL_MTDT_CD as rescDtlMtdtCd,RESC_DTL.RESC_MTDT_VAL as rescMtdtVal  from RESC_DTL,  (SELECT   subquery10.prodAvailId,subquery10.saleChnlid,subquery10.prodMktId,  subquery10.mktCd,  subquery10.prodId,subquery10.prodFamCd,  subquery10.prodCd,subquery10.prodInacIndc,subquery10.prodVers,subquery10.rescMapId,  subquery10.rescId,subquery10.bilgSysCd,subquery10.rescVers,  subquery10.rescCd,subquery10.rescTypCd,subquery10.bilgSysTypCd,  subquery10.countryCode,  subquery10.countryDesc,subquery10.productCode,subquery10.prodCodeShrtDesc,  subquery10.prodCodeDesc,  subquery10.rescCode,subquery10.rescCodeShrtDesc,subquery10.rescCodeDesc,subquery10.prodGrpId,subquery10.prodGrpCd,  subquery10.prodDtlId,subquery10.prodDtlMtdtCd,subquery10.prodDtlMtdCdVal,  subquery10.mktGrpId,subquery10.mktGrpCd,  RESC_GRP.RESC_GRP_ID as rescGrpId,RESC_GRP.RESC_GRP_CD as rescGrpCd  from RESC_GRP,  (SELECT   subquery9.prodAvailId,subquery9.saleChnlid,subquery9.prodMktId,  subquery9.mktCd,  subquery9.prodId,subquery9.prodFamCd,  subquery9.prodCd,subquery9.prodInacIndc,subquery9.prodVers,subquery9.rescMapId,  subquery9.rescId,subquery9.bilgSysCd,subquery9.rescVers,  subquery9.rescCd,subquery9.rescTypCd,subquery9.bilgSysTypCd,  subquery9.countryCode,  subquery9.countryDesc,subquery9.productCode,subquery9.prodCodeShrtDesc,  subquery9.prodCodeDesc,  subquery9.rescCode,subquery9.rescCodeShrtDesc,subquery9.rescCodeDesc,subquery9.prodGrpId,subquery9.prodGrpCd,  subquery9.prodDtlId,subquery9.prodDtlMtdtCd,subquery9.prodDtlMtdCdVal,  MKT_GRP.MKT_GRP_ID as mktGrpId,MKT_GRP.MKT_GRP_CD as mktGrpCd  from MKT_GRP,  ( SELECT   subquery8.prodAvailId,subquery8.saleChnlid,subquery8.prodMktId,  subquery8.mktCd,  subquery8.prodId,subquery8.prodFamCd,  subquery8.prodCd,subquery8.prodInacIndc,subquery8.prodVers,subquery8.rescMapId,  subquery8.rescId,subquery8.bilgSysCd,subquery8.rescVers,  subquery8.rescCd,subquery8.rescTypCd,subquery8.bilgSysTypCd,  subquery8.countryCode,  subquery8.countryDesc,subquery8.productCode,subquery8.prodCodeShrtDesc,  subquery8.prodCodeDesc,  subquery8.rescCode,subquery8.rescCodeShrtDesc,subquery8.rescCodeDesc,subquery8.prodGrpId,subquery8.prodGrpCd,  PROD_DTL.PROD_DTL_ID as prodDtlId,PROD_DTL.PROD_DTL_MTDT_CD as prodDtlMtdtCd,PROD_DTL.PROD_DTL_MTDT_VAL as prodDtlMtdCdVal  from PROD_DTL,  ( SELECT   subquery7.prodAvailId,subquery7.saleChnlid,subquery7.prodMktId,  subquery7.mktCd,  subquery7.prodId,subquery7.prodFamCd,  subquery7.prodCd,subquery7.prodInacIndc,subquery7.prodVers,subquery7.rescMapId,  subquery7.rescId,subquery7.bilgSysCd,subquery7.rescVers,  subquery7.rescCd,subquery7.rescTypCd,subquery7.bilgSysTypCd,  subquery7.countryCode,  subquery7.countryDesc,subquery7.productCode,subquery7.prodCodeShrtDesc,  subquery7.prodCodeDesc,  subquery7.rescCode,subquery7.rescCodeShrtDesc,subquery7.rescCodeDesc,PROD_GRP.prod_grp_id as prodGrpId,PROD_GRP.prod_grp_cd as prodGrpCd  from PROD_GRP,  (SELECT   subquery6.PROD_AVLBID as prodAvailId,subquery6.SLS_CHNL_ID as saleChnlid,subquery6.PROD_MKT_ID as prodMktId,  subquery6.MKT_CD as mktCd,  subquery6.PRODID as prodId,subquery6.PROD_FAM_CD as prodFamCd,  subquery6.PROD_CD as prodCd,subquery6.INAC_INDC as prodInacIndc,subquery6.PROD_VERS as prodVers,subquery6.RESC_MAP_ID as rescMapId,  subquery6.RESCID as rescId,subquery6.BILG_SYS_CODE as bilgSysCd,subquery6.RESC_VERS as rescVers,  subquery6.RESC_CD as rescCd,subquery6.RESC_TYP_CODE as rescTypCd,subquery6.BILG_SYS_TYP_CD as bilgSysTypCd,  subquery6.countryCode as countryCode,  subquery6.countryDesc as countryDesc,subquery6.productCode as productCode,subquery6.prodCodeShrtDesc as prodCodeShrtDesc,  subquery6.prodCodeDesc,  CD_VAL_TXT.CD_VAL_ID as rescCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as rescCodeShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescCodeDesc  from CD_VAL_TXT,  (SELECT   subquery5.PROD_AVLBID,subquery5.SLS_CHNL_ID,subquery5.PROD_MKT_ID,subquery5.MKT_CD,  subquery5.PRODID,subquery5.PROD_FAM_CD,subquery5.PROD_CD,subquery5.INAC_INDC,subquery5.PROD_VERS,subquery5.RESC_MAP_ID,  subquery5.RESCID,subquery5.BILG_SYS_CODE,subquery5.RESC_VERS,  subquery5.RESC_CD,subquery5.RESC_TYP_CODE,subquery5.BILG_SYS_TYP_CD,subquery5.countryCode,  subquery5.countryDesc,CD_VAL_TXT.CD_VAL_ID as productCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as prodCodeShrtDesc,  CD_VAL_TXT.CD_VAL_DESC as prodCodeDesc  from CD_VAL_TXT,  (SELECT   subquery4.PROD_AVLBID,subquery4.SLS_CHNL_ID,subquery4.PROD_MKT_ID,subquery4.MKT_CD,  subquery4.PRODID,subquery4.PROD_FAM_CD,subquery4.PROD_CD,subquery4.INAC_INDC,subquery4.PROD_VERS,subquery4.RESC_MAP_ID,  subquery4.RESCID,subquery4.BILG_SYS_CODE,subquery4.RESC_VERS,  subquery4.RESC_CD,subquery4.RESC_TYP_CODE,subquery4.BILG_SYS_TYP_CD,GEO_UNIT_NME.GEO_UNIT_ID as countryCode,  GEO_UNIT_NME.GEO_NME as countryDesc  from GEO_UNIT_NME ,  (SELECT   subquery3.PROD_AVLBID,subquery3.SLS_CHNL_ID,subquery3.PROD_MKT_ID,subquery3.MKT_CD,  subquery3.PRODID,subquery3.PROD_FAM_CD,subquery3.PROD_CD,subquery3.INAC_INDC,subquery3.PROD_VERS,subquery3.RESC_MAP_ID,  subquery3.RESC_ID as RESCID,RESC.RESC_ID,RESC.BILG_SYS_CODE,RESC.RESC_VERS,RESC.RESC_CD,RESC.RESC_TYP_CODE,RESC.BILG_SYS_TYP_CD   from RESC,  (SELECT   subquery2.PROD_AVLBID,subquery2.SLS_CHNL_ID,subquery2.PROD_MKT_ID,subquery2.MKT_CD,  subquery2.PRODID ,subquery2.PROD_FAM_CD,subquery2.PROD_CD,subquery2.INAC_INDC,subquery2.PROD_VERS,RESC_MAP.RESC_MAP_ID,  RESC_MAP.RESC_ID,RESC_MAP.PROD_ID from RESC_MAP,  (SELECT   PROD_AVLB.PROD_AVLB_ID,PROD_AVLB.PROD_ID,PROD_AVLB.SLS_CHNL_ID,PROD_MKT.PROD_MKT_ID,PROD_MKT.PROD_AVLB_ID as PROD_AVLBID,PROD_MKT.MKT_CD,  subquery1.PROD_ID as PRODID,subquery1.PROD_FAM_CD,subquery1.PROD_CD,subquery1.INAC_INDC,subquery1.PROD_VERS   from PROD_MKT,PROD_AVLB,(SELECT PROD_ID,PROD_FAM_CD,PROD_CD,INAC_INDC,PROD_VERS from PROD where     ("
						+ productcd
						+ ")"
						+ ") subquery1   WHERE PROD_MKT.PROD_AVLB_ID = PROD_AVLB.PROD_AVLB_ID and PROD_AVLB.PROD_ID = subquery1.PROD_ID and   ("
						+ strMktCd
						+ ")"
						+ ") subquery2  WHERE  RESC_MAP.PROD_ID = subquery2.PRODID) subquery3  WHERE subquery3.RESC_ID = RESC.RESC_ID ) subquery4  WHERE subquery4.MKT_CD = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32   order by GEO_UNIT_NME.GEO_NME) subquery5  WHERE subquery5.PROD_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6  WHERE subquery6.RESC_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7  WHERE subquery7.prodId = PROD_GRP.prod_id) subquery8  WHERE subquery8.prodId = PROD_DTL.prod_id) subquery9  WHERE subquery9.prodMktId = MKT_GRP.PROD_MKT_ID) subquery10  WHERE subquery10.rescId = RESC_GRP.RESC_ID) subquery11  WHERE subquery11.rescId = RESC_DTL.RESC_ID) subquery12 WHERE subquery12.saleChnlid = SLS_CHNL_DTL.SLS_CHNL_ID) subquery13  WHERE subquery13.prodGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery14  WHERE subquery14.prodDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null  order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery15  WHERE subquery15.mktGrpCd =  GEO_UNIT_NME.GEO_UNIT_ID and 1=1  and GEO_UNIT.GEO_UNIT_ID=GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and"
						+ " GEO_UNIT_NME.GEO_NME_TYP_CD = 32 and GEO_UNIT.GEO_UNIT_TYP_CD=130 order by GEO_UNIT_NME.GEO_NME) subquery16  WHERE subquery16.rescGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery17  WHERE subquery17.rescDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery18  WHERE subquery18.slsChnlDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) query2  WHERE query2.rescMapId = prod_resc_to_scr_gru.resc_map_id) qur2 ON qur1.prodScrMapId = qur2.prodScrMapId";

			} else {

				query = "SELECT count(*) as cnt from (SELECT  query1.scr_mkt_cd_id,query1.country_name, query1.scr_typ_cd_id as scr_typ_cd_id,query1.scr_typ_cd_shrt_d as scr_typ_cd_shrt_d,query1.scr_typ_cd_val_d as scr_typ_cd_val_d, query1.scr_gru_cd_id as scr_gru_cd_id,query1.scr_gru_cd_shrt_d as scr_gru_cd_shrt_d,query1.scr_gru_cd_val_d as scr_gru_cd_val_d, query1.scr_id as scr_id,query1.scr_gru_cd as scr_gru_cd,query1.scr_gru_id as scr_gru_id,query1.scr_typ_assn_id as scr_typ_assn_id, query1.scr_typ_id as scr_typ_id, query1.scr_mkt_cd as scr_mkt_cd,query1.scr_typ_cd as scr_typ_cd,query1.scr_dtl_id,prod_resc_to_scr_gru.prod_resc_to_scr_gru_ID as prodScrMapId,query1.scr_vers   from prod_resc_to_scr_gru,(SELECT  GEO_UNIT_ID as scr_mkt_cd_id,GEO_NME as country_name, subquery7.scr_typ_cd_id as scr_typ_cd_id,subquery7.scr_typ_cd_shrt_d as scr_typ_cd_shrt_d,subquery7.scr_typ_cd_val_d as scr_typ_cd_val_d, subquery7.scr_gru_cd_id as scr_gru_cd_id,subquery7.scr_gru_cd_shrt_d as scr_gru_cd_shrt_d,subquery7.scr_gru_cd_val_d as scr_gru_cd_val_d,subquery7.scr_id as scr_id,subquery7.scr_gru_cd as scr_gru_cd,subquery7.scr_gru_id as scr_gru_id,subquery7.scr_typ_assn_id as scr_typ_assn_id,subquery7.scr_typ_id as scr_typ_id, subquery7.scr_mkt_cd as scr_mkt_cd,subquery7.scr_typ_cd as scr_typ_cd,subquery7.scr_dtl_id,subquery7.scr_vers   from GEO_UNIT_NME,(SELECT   CD_VAL_ID as scr_typ_cd_id,CD_VAL_SHRT_DESC as scr_typ_cd_shrt_d,CD_VAL_DESC as scr_typ_cd_val_d,  subquery6.scr_gru_cd_id,subquery6.scr_gru_cd_shrt_d,subquery6.scr_gru_cd_val_d,subquery6.scr_id as scr_id,subquery6.scr_gru_cd as scr_gru_cd,subquery6.scr_gru_id as scr_gru_id,subquery6.scr_typ_assn_id as scr_typ_assn_id,subquery6.scr_typ_id as scr_typ_id,  subquery6.scr_mkt_cd as scr_mkt_cd,subquery6.scr_typ_cd as scr_typ_cd,subquery6.scr_dtl_id,subquery6.scr_vers    from CD_VAL_TXT,(SELECT CD_VAL_ID as scr_gru_cd_id,CD_VAL_SHRT_DESC as scr_gru_cd_shrt_d,CD_VAL_DESC as scr_gru_cd_val_d,subquery5.scr_id as scr_id,subquery5.scr_gru_cd as scr_gru_cd,subquery5.scr_gru_id as scr_gru_id,subquery5.scr_typ_assn_id as scr_typ_assn_id,subquery5.scr_typ_id as scr_typ_id,  subquery5.scr_mkt_cd as scr_mkt_cd,subquery5.scr_typ_cd as scr_typ_cd,subquery5.scr_dtl_id,subquery5.scr_vers  from CD_VAL_TXT,(  SELECT subquery3.scr_id as scr_id,scr_gru.scr_gru_cd as scr_gru_cd,subquery3.scr_gru_id as scr_gru_id,subquery3.scr_typ_assn_id as scr_typ_assn_id,subquery3.scr_typ_id as scr_typ_id,  subquery3.scr_mkt_cd as scr_mkt_cd,subquery3.scr_typ_cd as scr_typ_cd,subquery3.scr_dtl_id,subquery3.scr_vers  from scr_gru,(SELECT scr_typ_assn.scr_gru_id as scr_gru_id,subquery2.scr_typ_assn_id as scr_typ_assn_id,subquery2.scr_id as scr_id,subquery2.scr_typ_id as scr_typ_id,  subquery2.scr_mkt_cd as scr_mkt_cd,subquery2.scr_typ_cd as scr_typ_cd,subquery2.scr_dtl_id,subquery2.scr_vers   from scr_typ_assn,(SELECT scr_dtl.scr_typ_assn_id as scr_typ_assn_id, subquery1.scr_id as scr_id,subquery1.scr_typ_id as scr_typ_id,  subquery1.scr_mkt_cd as scr_mkt_cd,subquery1.scr_typ_cd as scr_typ_cd,scr_dtl.scr_dtl_id as scr_dtl_id,subquery1.scr_vers   FROM scr_dtl,   (SELECT scr.scr_id,scr.scr_typ_id,scr.scr_mkt_cd,subquery4.scr_typ_cd as scr_typ_cd,scr.scr_ver as scr_vers   FROM scr,   (select scr_typ_id,scr_typ_cd from scr_typ where ("
						+ scrtycd
						+ ")"
						+ ") subquery4  WHERE subquery4.scr_typ_id = scr.scr_typ_id and ("
						+ strMktCdScr
						+ ")"
						+ ") subquery1   WHERE subquery1.scr_id = scr_dtl.scr_id) subquery2  WHERE subquery2.scr_typ_assn_id = scr_typ_assn.scr_typ_assn_id and scr_typ_assn.scr_gru_id in (SELECT scr_gru_id from scr_gru where ("
						+ scrgrucd
						+ ")"
						+ ")) subquery3   WHERE subquery3.scr_gru_id = scr_gru.scr_gru_id) subquery5    WHERE subquery5.scr_gru_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6   WHERE subquery6.scr_typ_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7  WHERE subquery7.scr_mkt_cd = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32 order by GEO_UNIT_NME.GEO_NME) query1  WHERE query1.scr_dtl_id = prod_resc_to_scr_gru.SCR_DTL_ID) qur1  JOIN   (SELECT   query2.prodAvailId,query2.saleChnlid,query2.prodMktId,  query2.mktCd,  query2.prodId,query2.prodFamCd,  query2.prodCd,query2.prodInacIndc,query2.prodVers,query2.rescMapId,  query2.rescId,query2.bilgSysCd,query2.rescVers,  query2.rescCd,query2.rescTypCd,query2.bilgSysTypCd,  query2.countryCode,  query2.countryDesc,query2.productCode,query2.prodCodeShrtDesc,  query2.prodCodeDesc,  query2.rescCode,query2.rescCodeShrtDesc,query2.rescCodeDesc,query2.prodGrpId,query2.prodGrpCd,  query2.prodDtlId,query2.prodDtlMtdtCd,query2.prodDtlMtdCdVal,  query2.mktGrpId,query2.mktGrpCd,  query2.rescGrpId,query2.rescGrpCd,  query2.rescDtlID,query2.rescDtlMtdtCd,query2.rescMtdtVal,  query2.slsChnlDtlID,query2.slsChnlDtlMtdtCd,  query2.slsChnlDtlMtdtVal,  query2.prodGrpCdShrtDesc,query2.prodGrpCdDesc,  query2.prodDtlMtdtCdShrtDesc,query2.prodDtlMtdtCdDesc,  query2.mktGrpCdShrtDesc,query2.mktGrpCdDesc,  query2.rescGrpCdShrtDesc,query2.rescGrpCdDesc,  query2.rescDtlMtdtCdShrtDesc,query2.rescDtlMtdtCdDesc,  query2.slsChnlDtlMtdtCdShrtDesc,query2.slsChnlDtlMtdtCdDesc,prod_resc_to_scr_gru.prod_resc_to_scr_gru_ID as prodScrMapId from prod_resc_to_scr_gru, (SELECT   subquery18.prodAvailId,subquery18.saleChnlid,subquery18.prodMktId,  subquery18.mktCd,  subquery18.prodId,subquery18.prodFamCd,  subquery18.prodCd,subquery18.prodInacIndc,subquery18.prodVers,subquery18.rescMapId,  subquery18.rescId,subquery18.bilgSysCd,subquery18.rescVers,  subquery18.rescCd,subquery18.rescTypCd,subquery18.bilgSysTypCd,  subquery18.countryCode,  subquery18.countryDesc,subquery18.productCode,subquery18.prodCodeShrtDesc,  subquery18.prodCodeDesc,  subquery18.rescCode,subquery18.rescCodeShrtDesc,subquery18.rescCodeDesc,subquery18.prodGrpId,subquery18.prodGrpCd,  subquery18.prodDtlId,subquery18.prodDtlMtdtCd,subquery18.prodDtlMtdCdVal,  subquery18.mktGrpId,subquery18.mktGrpCd,  subquery18.rescGrpId,subquery18.rescGrpCd,  subquery18.rescDtlID,subquery18.rescDtlMtdtCd,subquery18.rescMtdtVal,  subquery18.slsChnlDtlID,subquery18.slsChnlDtlMtdtCd,  subquery18.slsChnlDtlMtdtVal,  subquery18.prodGrpCdShrtDesc,subquery18.prodGrpCdDesc,  subquery18.prodDtlMtdtCdShrtDesc,subquery18.prodDtlMtdtCdDesc,  subquery18.mktGrpCdShrtDesc,subquery18.mktGrpCdDesc,  subquery18.rescGrpCdShrtDesc,subquery18.rescGrpCdDesc,  subquery18.rescDtlMtdtCdShrtDesc,subquery18.rescDtlMtdtCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as slsChnlDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as slsChnlDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery17.prodAvailId,subquery17.saleChnlid,subquery17.prodMktId,  subquery17.mktCd,  subquery17.prodId,subquery17.prodFamCd,  subquery17.prodCd,subquery17.prodInacIndc,subquery17.prodVers,subquery17.rescMapId,  subquery17.rescId,subquery17.bilgSysCd,subquery17.rescVers,  subquery17.rescCd,subquery17.rescTypCd,subquery17.bilgSysTypCd,  subquery17.countryCode,  subquery17.countryDesc,subquery17.productCode,subquery17.prodCodeShrtDesc,  subquery17.prodCodeDesc,  subquery17.rescCode,subquery17.rescCodeShrtDesc,subquery17.rescCodeDesc,subquery17.prodGrpId,subquery17.prodGrpCd,  subquery17.prodDtlId,subquery17.prodDtlMtdtCd,subquery17.prodDtlMtdCdVal,  subquery17.mktGrpId,subquery17.mktGrpCd,  subquery17.rescGrpId,subquery17.rescGrpCd,  subquery17.rescDtlID,subquery17.rescDtlMtdtCd,subquery17.rescMtdtVal,  subquery17.slsChnlDtlID,subquery17.slsChnlDtlMtdtCd,  subquery17.slsChnlDtlMtdtVal,  subquery17.prodGrpCdShrtDesc,subquery17.prodGrpCdDesc,  subquery17.prodDtlMtdtCdShrtDesc,subquery17.prodDtlMtdtCdDesc,  subquery17.mktGrpCdShrtDesc,subquery17.mktGrpCdDesc,  subquery17.rescGrpCdShrtDesc,subquery17.rescGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery16.prodAvailId,subquery16.saleChnlid,subquery16.prodMktId,  subquery16.mktCd,  subquery16.prodId,subquery16.prodFamCd,  subquery16.prodCd,subquery16.prodInacIndc,subquery16.prodVers,subquery16.rescMapId,  subquery16.rescId,subquery16.bilgSysCd,subquery16.rescVers,  subquery16.rescCd,subquery16.rescTypCd,subquery16.bilgSysTypCd,  subquery16.countryCode,  subquery16.countryDesc,subquery16.productCode,subquery16.prodCodeShrtDesc,  subquery16.prodCodeDesc,  subquery16.rescCode,subquery16.rescCodeShrtDesc,subquery16.rescCodeDesc,subquery16.prodGrpId,subquery16.prodGrpCd,  subquery16.prodDtlId,subquery16.prodDtlMtdtCd,subquery16.prodDtlMtdCdVal,  subquery16.mktGrpId,subquery16.mktGrpCd,  subquery16.rescGrpId,subquery16.rescGrpCd,  subquery16.rescDtlID,subquery16.rescDtlMtdtCd,subquery16.rescMtdtVal,  subquery16.slsChnlDtlID,subquery16.slsChnlDtlMtdtCd,  subquery16.slsChnlDtlMtdtVal,  subquery16.prodGrpCdShrtDesc,subquery16.prodGrpCdDesc,  subquery16.prodDtlMtdtCdShrtDesc,subquery16.prodDtlMtdtCdDesc,  subquery16.mktGrpCdShrtDesc,subquery16.mktGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescGrpCdDesc  from CD_VAL_TXT,  (SELECT   subquery15.prodAvailId,subquery15.saleChnlid,subquery15.prodMktId,  subquery15.mktCd,  subquery15.prodId,subquery15.prodFamCd,  subquery15.prodCd,subquery15.prodInacIndc,subquery15.prodVers,subquery15.rescMapId,  subquery15.rescId,subquery15.bilgSysCd,subquery15.rescVers,  subquery15.rescCd,subquery15.rescTypCd,subquery15.bilgSysTypCd,  subquery15.countryCode,  subquery15.countryDesc,subquery15.productCode,subquery15.prodCodeShrtDesc,  subquery15.prodCodeDesc,  subquery15.rescCode,subquery15.rescCodeShrtDesc,subquery15.rescCodeDesc,subquery15.prodGrpId,subquery15.prodGrpCd,  subquery15.prodDtlId,subquery15.prodDtlMtdtCd,subquery15.prodDtlMtdCdVal,  subquery15.mktGrpId,subquery15.mktGrpCd,  subquery15.rescGrpId,subquery15.rescGrpCd,  subquery15.rescDtlID,subquery15.rescDtlMtdtCd,subquery15.rescMtdtVal,  subquery15.slsChnlDtlID,subquery15.slsChnlDtlMtdtCd,  subquery15.slsChnlDtlMtdtVal,  subquery15.prodGrpCdShrtDesc,subquery15.prodGrpCdDesc,  subquery15.prodDtlMtdtCdShrtDesc,subquery15.prodDtlMtdtCdDesc,  GEO_UNIT_NME.GEO_NME as mktGrpCdShrtDesc,GEO_UNIT_NME.GEO_NME as mktGrpCdDesc  from GEO_UNIT_NME, GEO_UNIT,  (SELECT   subquery14.prodAvailId,subquery14.saleChnlid,subquery14.prodMktId,  subquery14.mktCd,  subquery14.prodId,subquery14.prodFamCd,  subquery14.prodCd,subquery14.prodInacIndc,subquery14.prodVers,subquery14.rescMapId,  subquery14.rescId,subquery14.bilgSysCd,subquery14.rescVers,  subquery14.rescCd,subquery14.rescTypCd,subquery14.bilgSysTypCd,  subquery14.countryCode,  subquery14.countryDesc,subquery14.productCode,subquery14.prodCodeShrtDesc,  subquery14.prodCodeDesc,  subquery14.rescCode,subquery14.rescCodeShrtDesc,subquery14.rescCodeDesc,subquery14.prodGrpId,subquery14.prodGrpCd,  subquery14.prodDtlId,subquery14.prodDtlMtdtCd,subquery14.prodDtlMtdCdVal,  subquery14.mktGrpId,subquery14.mktGrpCd,  subquery14.rescGrpId,subquery14.rescGrpCd,  subquery14.rescDtlID,subquery14.rescDtlMtdtCd,subquery14.rescMtdtVal,  subquery14.slsChnlDtlID,subquery14.slsChnlDtlMtdtCd,  subquery14.slsChnlDtlMtdtVal,  subquery14.prodGrpCdShrtDesc,subquery14.prodGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery13.prodAvailId,subquery13.saleChnlid,subquery13.prodMktId,  subquery13.mktCd,  subquery13.prodId,subquery13.prodFamCd,  subquery13.prodCd,subquery13.prodInacIndc,subquery13.prodVers,subquery13.rescMapId,  subquery13.rescId,subquery13.bilgSysCd,subquery13.rescVers,  subquery13.rescCd,subquery13.rescTypCd,subquery13.bilgSysTypCd,  subquery13.countryCode,  subquery13.countryDesc,subquery13.productCode,subquery13.prodCodeShrtDesc,  subquery13.prodCodeDesc,  subquery13.rescCode,subquery13.rescCodeShrtDesc,subquery13.rescCodeDesc,subquery13.prodGrpId,subquery13.prodGrpCd,  subquery13.prodDtlId,subquery13.prodDtlMtdtCd,subquery13.prodDtlMtdCdVal,  subquery13.mktGrpId,subquery13.mktGrpCd,  subquery13.rescGrpId,subquery13.rescGrpCd,  subquery13.rescDtlID,subquery13.rescDtlMtdtCd,subquery13.rescMtdtVal,  subquery13.slsChnlDtlID,subquery13.slsChnlDtlMtdtCd,  subquery13.slsChnlDtlMtdtVal,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodGrpCdDesc  from CD_VAL_TXT,  ( SELECT   subquery12.prodAvailId,subquery12.saleChnlid,subquery12.prodMktId,  subquery12.mktCd,  subquery12.prodId,subquery12.prodFamCd,  subquery12.prodCd,subquery12.prodInacIndc,subquery12.prodVers,subquery12.rescMapId,  subquery12.rescId,subquery12.bilgSysCd,subquery12.rescVers,  subquery12.rescCd,subquery12.rescTypCd,subquery12.bilgSysTypCd,  subquery12.countryCode,  subquery12.countryDesc,subquery12.productCode,subquery12.prodCodeShrtDesc,  subquery12.prodCodeDesc,  subquery12.rescCode,subquery12.rescCodeShrtDesc,subquery12.rescCodeDesc,subquery12.prodGrpId,subquery12.prodGrpCd,  subquery12.prodDtlId,subquery12.prodDtlMtdtCd,subquery12.prodDtlMtdCdVal,  subquery12.mktGrpId,subquery12.mktGrpCd,  subquery12.rescGrpId,subquery12.rescGrpCd,  subquery12.rescDtlID,subquery12.rescDtlMtdtCd,subquery12.rescMtdtVal,  SLS_CHNL_DTL.SLS_CHNL_DTL_ID as slsChnlDtlID,SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_CD as slsChnlDtlMtdtCd,  SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_VAL as slsChnlDtlMtdtVal  from SLS_CHNL_DTL,   (SELECT   subquery11.prodAvailId,subquery11.saleChnlid,subquery11.prodMktId,  subquery11.mktCd,  subquery11.prodId,subquery11.prodFamCd,  subquery11.prodCd,subquery11.prodInacIndc,subquery11.prodVers,subquery11.rescMapId,  subquery11.rescId,subquery11.bilgSysCd,subquery11.rescVers,  subquery11.rescCd,subquery11.rescTypCd,subquery11.bilgSysTypCd,  subquery11.countryCode,  subquery11.countryDesc,subquery11.productCode,subquery11.prodCodeShrtDesc,  subquery11.prodCodeDesc,  subquery11.rescCode,subquery11.rescCodeShrtDesc,subquery11.rescCodeDesc,subquery11.prodGrpId,subquery11.prodGrpCd,  subquery11.prodDtlId,subquery11.prodDtlMtdtCd,subquery11.prodDtlMtdCdVal,  subquery11.mktGrpId,subquery11.mktGrpCd,  subquery11.rescGrpId,subquery11.rescGrpCd,  RESC_DTL.RESC_DTL_ID as rescDtlID,RESC_DTL.RESC_DTL_MTDT_CD as rescDtlMtdtCd,RESC_DTL.RESC_MTDT_VAL as rescMtdtVal  from RESC_DTL,  (SELECT   subquery10.prodAvailId,subquery10.saleChnlid,subquery10.prodMktId,  subquery10.mktCd,  subquery10.prodId,subquery10.prodFamCd,  subquery10.prodCd,subquery10.prodInacIndc,subquery10.prodVers,subquery10.rescMapId,  subquery10.rescId,subquery10.bilgSysCd,subquery10.rescVers,  subquery10.rescCd,subquery10.rescTypCd,subquery10.bilgSysTypCd,  subquery10.countryCode,  subquery10.countryDesc,subquery10.productCode,subquery10.prodCodeShrtDesc,  subquery10.prodCodeDesc,  subquery10.rescCode,subquery10.rescCodeShrtDesc,subquery10.rescCodeDesc,subquery10.prodGrpId,subquery10.prodGrpCd,  subquery10.prodDtlId,subquery10.prodDtlMtdtCd,subquery10.prodDtlMtdCdVal,  subquery10.mktGrpId,subquery10.mktGrpCd,  RESC_GRP.RESC_GRP_ID as rescGrpId,RESC_GRP.RESC_GRP_CD as rescGrpCd  from RESC_GRP,  (SELECT   subquery9.prodAvailId,subquery9.saleChnlid,subquery9.prodMktId,  subquery9.mktCd,  subquery9.prodId,subquery9.prodFamCd,  subquery9.prodCd,subquery9.prodInacIndc,subquery9.prodVers,subquery9.rescMapId,  subquery9.rescId,subquery9.bilgSysCd,subquery9.rescVers,  subquery9.rescCd,subquery9.rescTypCd,subquery9.bilgSysTypCd,  subquery9.countryCode,  subquery9.countryDesc,subquery9.productCode,subquery9.prodCodeShrtDesc,  subquery9.prodCodeDesc,  subquery9.rescCode,subquery9.rescCodeShrtDesc,subquery9.rescCodeDesc,subquery9.prodGrpId,subquery9.prodGrpCd,  subquery9.prodDtlId,subquery9.prodDtlMtdtCd,subquery9.prodDtlMtdCdVal,  MKT_GRP.MKT_GRP_ID as mktGrpId,MKT_GRP.MKT_GRP_CD as mktGrpCd  from MKT_GRP,  ( SELECT   subquery8.prodAvailId,subquery8.saleChnlid,subquery8.prodMktId,  subquery8.mktCd,  subquery8.prodId,subquery8.prodFamCd,  subquery8.prodCd,subquery8.prodInacIndc,subquery8.prodVers,subquery8.rescMapId,  subquery8.rescId,subquery8.bilgSysCd,subquery8.rescVers,  subquery8.rescCd,subquery8.rescTypCd,subquery8.bilgSysTypCd,  subquery8.countryCode,  subquery8.countryDesc,subquery8.productCode,subquery8.prodCodeShrtDesc,  subquery8.prodCodeDesc,  subquery8.rescCode,subquery8.rescCodeShrtDesc,subquery8.rescCodeDesc,subquery8.prodGrpId,subquery8.prodGrpCd,  PROD_DTL.PROD_DTL_ID as prodDtlId,PROD_DTL.PROD_DTL_MTDT_CD as prodDtlMtdtCd,PROD_DTL.PROD_DTL_MTDT_VAL as prodDtlMtdCdVal  from PROD_DTL,  ( SELECT   subquery7.prodAvailId,subquery7.saleChnlid,subquery7.prodMktId,  subquery7.mktCd,  subquery7.prodId,subquery7.prodFamCd,  subquery7.prodCd,subquery7.prodInacIndc,subquery7.prodVers,subquery7.rescMapId,  subquery7.rescId,subquery7.bilgSysCd,subquery7.rescVers,  subquery7.rescCd,subquery7.rescTypCd,subquery7.bilgSysTypCd,  subquery7.countryCode,  subquery7.countryDesc,subquery7.productCode,subquery7.prodCodeShrtDesc,  subquery7.prodCodeDesc,  subquery7.rescCode,subquery7.rescCodeShrtDesc,subquery7.rescCodeDesc,PROD_GRP.prod_grp_id as prodGrpId,PROD_GRP.prod_grp_cd as prodGrpCd  from PROD_GRP,  (SELECT   subquery6.PROD_AVLBID as prodAvailId,subquery6.SLS_CHNL_ID as saleChnlid,subquery6.PROD_MKT_ID as prodMktId,  subquery6.MKT_CD as mktCd,  subquery6.PRODID as prodId,subquery6.PROD_FAM_CD as prodFamCd,  subquery6.PROD_CD as prodCd,subquery6.INAC_INDC as prodInacIndc,subquery6.PROD_VERS as prodVers,subquery6.RESC_MAP_ID as rescMapId,  subquery6.RESCID as rescId,subquery6.BILG_SYS_CODE as bilgSysCd,subquery6.RESC_VERS as rescVers,  subquery6.RESC_CD as rescCd,subquery6.RESC_TYP_CODE as rescTypCd,subquery6.BILG_SYS_TYP_CD as bilgSysTypCd,  subquery6.countryCode as countryCode,  subquery6.countryDesc as countryDesc,subquery6.productCode as productCode,subquery6.prodCodeShrtDesc as prodCodeShrtDesc,  subquery6.prodCodeDesc,  CD_VAL_TXT.CD_VAL_ID as rescCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as rescCodeShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescCodeDesc  from CD_VAL_TXT,  (SELECT   subquery5.PROD_AVLBID,subquery5.SLS_CHNL_ID,subquery5.PROD_MKT_ID,subquery5.MKT_CD,  subquery5.PRODID,subquery5.PROD_FAM_CD,subquery5.PROD_CD,subquery5.INAC_INDC,subquery5.PROD_VERS,subquery5.RESC_MAP_ID,  subquery5.RESCID,subquery5.BILG_SYS_CODE,subquery5.RESC_VERS,  subquery5.RESC_CD,subquery5.RESC_TYP_CODE,subquery5.BILG_SYS_TYP_CD,subquery5.countryCode,  subquery5.countryDesc,CD_VAL_TXT.CD_VAL_ID as productCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as prodCodeShrtDesc,  CD_VAL_TXT.CD_VAL_DESC as prodCodeDesc  from CD_VAL_TXT,  (SELECT   subquery4.PROD_AVLBID,subquery4.SLS_CHNL_ID,subquery4.PROD_MKT_ID,subquery4.MKT_CD,  subquery4.PRODID,subquery4.PROD_FAM_CD,subquery4.PROD_CD,subquery4.INAC_INDC,subquery4.PROD_VERS,subquery4.RESC_MAP_ID,  subquery4.RESCID,subquery4.BILG_SYS_CODE,subquery4.RESC_VERS,  subquery4.RESC_CD,subquery4.RESC_TYP_CODE,subquery4.BILG_SYS_TYP_CD,GEO_UNIT_NME.GEO_UNIT_ID as countryCode,  GEO_UNIT_NME.GEO_NME as countryDesc  from GEO_UNIT_NME ,  (SELECT   subquery3.PROD_AVLBID,subquery3.SLS_CHNL_ID,subquery3.PROD_MKT_ID,subquery3.MKT_CD,  subquery3.PRODID,subquery3.PROD_FAM_CD,subquery3.PROD_CD,subquery3.INAC_INDC,subquery3.PROD_VERS,subquery3.RESC_MAP_ID,  subquery3.RESC_ID as RESCID,RESC.RESC_ID,RESC.BILG_SYS_CODE,RESC.RESC_VERS,RESC.RESC_CD,RESC.RESC_TYP_CODE,RESC.BILG_SYS_TYP_CD   from RESC,  (SELECT   subquery2.PROD_AVLBID,subquery2.SLS_CHNL_ID,subquery2.PROD_MKT_ID,subquery2.MKT_CD,  subquery2.PRODID ,subquery2.PROD_FAM_CD,subquery2.PROD_CD,subquery2.INAC_INDC,subquery2.PROD_VERS,RESC_MAP.RESC_MAP_ID,  RESC_MAP.RESC_ID,RESC_MAP.PROD_ID from RESC_MAP,  (SELECT   PROD_AVLB.PROD_AVLB_ID,PROD_AVLB.PROD_ID,PROD_AVLB.SLS_CHNL_ID,PROD_MKT.PROD_MKT_ID,PROD_MKT.PROD_AVLB_ID as PROD_AVLBID,PROD_MKT.MKT_CD,  subquery1.PROD_ID as PRODID,subquery1.PROD_FAM_CD,subquery1.PROD_CD,subquery1.INAC_INDC,subquery1.PROD_VERS   from PROD_MKT,PROD_AVLB,(SELECT PROD_ID,PROD_FAM_CD,PROD_CD,INAC_INDC,PROD_VERS from PROD where     ("
						+ productcd
						+ ")"
						+ ") subquery1   WHERE PROD_MKT.PROD_AVLB_ID = PROD_AVLB.PROD_AVLB_ID and PROD_AVLB.PROD_ID = subquery1.PROD_ID and   ("
						+ strMktCd
						+ ")"
						+ ") subquery2  WHERE  RESC_MAP.PROD_ID = subquery2.PRODID) subquery3  WHERE subquery3.RESC_ID = RESC.RESC_ID ) subquery4  WHERE subquery4.MKT_CD = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32   order by GEO_UNIT_NME.GEO_NME) subquery5  WHERE subquery5.PROD_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6  WHERE subquery6.RESC_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7  WHERE subquery7.prodId = PROD_GRP.prod_id) subquery8  WHERE subquery8.prodId = PROD_DTL.prod_id) subquery9  WHERE subquery9.prodMktId = MKT_GRP.PROD_MKT_ID) subquery10  WHERE subquery10.rescId = RESC_GRP.RESC_ID) subquery11  WHERE subquery11.rescId = RESC_DTL.RESC_ID) subquery12 WHERE subquery12.saleChnlid = SLS_CHNL_DTL.SLS_CHNL_ID) subquery13  WHERE subquery13.prodGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery14  WHERE subquery14.prodDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery15  WHERE subquery15.mktGrpCd =  GEO_UNIT_NME.GEO_UNIT_ID and 1=1  and GEO_UNIT.GEO_UNIT_ID=GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and"
						+ " GEO_UNIT_NME.GEO_NME_TYP_CD = 32 and GEO_UNIT.GEO_UNIT_TYP_CD=130 order by GEO_UNIT_NME.GEO_NME) subquery16  WHERE subquery16.rescGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349  and CD_VAL_TXT.EXPN_DT is null  order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery17  WHERE subquery17.rescDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null  order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery18  WHERE subquery18.slsChnlDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) query2  WHERE query2.rescMapId = prod_resc_to_scr_gru.resc_map_id) qur2 ON qur1.prodScrMapId = qur2.prodScrMapId";

			}
		} else {
			if ((!(productScoreReportVO.getSr_gru_cd() != null))
					|| ((("").equalsIgnoreCase(productScoreReportVO
							.getSr_gru_cd())))) {

				query = "SELECT count(*) as cnt from (SELECT  query1.scr_mkt_cd_id,query1.country_name, query1.scr_typ_cd_id as scr_typ_cd_id,query1.scr_typ_cd_shrt_d as scr_typ_cd_shrt_d,query1.scr_typ_cd_val_d as scr_typ_cd_val_d, query1.scr_gru_cd_id as scr_gru_cd_id,query1.scr_gru_cd_shrt_d as scr_gru_cd_shrt_d,query1.scr_gru_cd_val_d as scr_gru_cd_val_d, query1.scr_id as scr_id,query1.scr_gru_cd as scr_gru_cd,query1.scr_gru_id as scr_gru_id,query1.scr_typ_assn_id as scr_typ_assn_id, query1.scr_typ_id as scr_typ_id, query1.scr_mkt_cd as scr_mkt_cd,query1.scr_typ_cd as scr_typ_cd,query1.scr_dtl_id,prod_resc_to_scr_gru.prod_resc_to_scr_gru_ID as prodScrMapId,query1.scr_vers   from prod_resc_to_scr_gru,(SELECT  GEO_UNIT_ID as scr_mkt_cd_id,GEO_NME as country_name, subquery7.scr_typ_cd_id as scr_typ_cd_id,subquery7.scr_typ_cd_shrt_d as scr_typ_cd_shrt_d,subquery7.scr_typ_cd_val_d as scr_typ_cd_val_d, subquery7.scr_gru_cd_id as scr_gru_cd_id,subquery7.scr_gru_cd_shrt_d as scr_gru_cd_shrt_d,subquery7.scr_gru_cd_val_d as scr_gru_cd_val_d,subquery7.scr_id as scr_id,subquery7.scr_gru_cd as scr_gru_cd,subquery7.scr_gru_id as scr_gru_id,subquery7.scr_typ_assn_id as scr_typ_assn_id,subquery7.scr_typ_id as scr_typ_id, subquery7.scr_mkt_cd as scr_mkt_cd,subquery7.scr_typ_cd as scr_typ_cd,subquery7.scr_dtl_id,subquery7.scr_vers   from GEO_UNIT_NME,(SELECT   CD_VAL_ID as scr_typ_cd_id,CD_VAL_SHRT_DESC as scr_typ_cd_shrt_d,CD_VAL_DESC as scr_typ_cd_val_d,  subquery6.scr_gru_cd_id,subquery6.scr_gru_cd_shrt_d,subquery6.scr_gru_cd_val_d,subquery6.scr_id as scr_id,subquery6.scr_gru_cd as scr_gru_cd,subquery6.scr_gru_id as scr_gru_id,subquery6.scr_typ_assn_id as scr_typ_assn_id,subquery6.scr_typ_id as scr_typ_id,  subquery6.scr_mkt_cd as scr_mkt_cd,subquery6.scr_typ_cd as scr_typ_cd,subquery6.scr_dtl_id,subquery6.scr_vers    from CD_VAL_TXT,(SELECT CD_VAL_ID as scr_gru_cd_id,CD_VAL_SHRT_DESC as scr_gru_cd_shrt_d,CD_VAL_DESC as scr_gru_cd_val_d,subquery5.scr_id as scr_id,subquery5.scr_gru_cd as scr_gru_cd,subquery5.scr_gru_id as scr_gru_id,subquery5.scr_typ_assn_id as scr_typ_assn_id,subquery5.scr_typ_id as scr_typ_id,  subquery5.scr_mkt_cd as scr_mkt_cd,subquery5.scr_typ_cd as scr_typ_cd,subquery5.scr_dtl_id,subquery5.scr_vers  from CD_VAL_TXT,(  SELECT subquery3.scr_id as scr_id,scr_gru.scr_gru_cd as scr_gru_cd,subquery3.scr_gru_id as scr_gru_id,subquery3.scr_typ_assn_id as scr_typ_assn_id,subquery3.scr_typ_id as scr_typ_id,  subquery3.scr_mkt_cd as scr_mkt_cd,subquery3.scr_typ_cd as scr_typ_cd,subquery3.scr_dtl_id,subquery3.scr_vers  from scr_gru,(SELECT scr_typ_assn.scr_gru_id as scr_gru_id,subquery2.scr_typ_assn_id as scr_typ_assn_id,subquery2.scr_id as scr_id,subquery2.scr_typ_id as scr_typ_id,  subquery2.scr_mkt_cd as scr_mkt_cd,subquery2.scr_typ_cd as scr_typ_cd,subquery2.scr_dtl_id,subquery2.scr_vers   from scr_typ_assn,(SELECT scr_dtl.scr_typ_assn_id as scr_typ_assn_id, subquery1.scr_id as scr_id,subquery1.scr_typ_id as scr_typ_id,  subquery1.scr_mkt_cd as scr_mkt_cd,subquery1.scr_typ_cd as scr_typ_cd,scr_dtl.scr_dtl_id as scr_dtl_id,subquery1.scr_vers   FROM scr_dtl,   (SELECT scr.scr_id,scr.scr_typ_id,scr.scr_mkt_cd,subquery4.scr_typ_cd as scr_typ_cd,scr.scr_ver as scr_vers   FROM scr,   (select scr_typ_id,scr_typ_cd from scr_typ where ("
						+ scrtycd
						+ ")"
						+ ") subquery4  WHERE subquery4.scr_typ_id = scr.scr_typ_id and ("
						+ strMktCdScr
						+ ")"
						+ ") subquery1   WHERE subquery1.scr_id = scr_dtl.scr_id) subquery2  WHERE subquery2.scr_typ_assn_id = scr_typ_assn.scr_typ_assn_id) subquery3   WHERE subquery3.scr_gru_id = scr_gru.scr_gru_id) subquery5    WHERE subquery5.scr_gru_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6   WHERE subquery6.scr_typ_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7  WHERE subquery7.scr_mkt_cd = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32 order by GEO_UNIT_NME.GEO_NME) query1  WHERE query1.scr_dtl_id = prod_resc_to_scr_gru.SCR_DTL_ID) qur1  JOIN   (SELECT   query2.prodAvailId,query2.saleChnlid,query2.prodMktId,  query2.mktCd,  query2.prodId,query2.prodFamCd,  query2.prodCd,query2.prodInacIndc,query2.prodVers,query2.rescMapId,  query2.rescId,query2.bilgSysCd,query2.rescVers,  query2.rescCd,query2.rescTypCd,query2.bilgSysTypCd,  query2.countryCode,  query2.countryDesc,query2.productCode,query2.prodCodeShrtDesc,  query2.prodCodeDesc,  query2.rescCode,query2.rescCodeShrtDesc,query2.rescCodeDesc,query2.prodGrpId,query2.prodGrpCd,  query2.prodDtlId,query2.prodDtlMtdtCd,query2.prodDtlMtdCdVal,  query2.mktGrpId,query2.mktGrpCd,  query2.rescGrpId,query2.rescGrpCd,  query2.rescDtlID,query2.rescDtlMtdtCd,query2.rescMtdtVal,  query2.slsChnlDtlID,query2.slsChnlDtlMtdtCd,  query2.slsChnlDtlMtdtVal,  query2.prodGrpCdShrtDesc,query2.prodGrpCdDesc,  query2.prodDtlMtdtCdShrtDesc,query2.prodDtlMtdtCdDesc,  query2.mktGrpCdShrtDesc,query2.mktGrpCdDesc,  query2.rescGrpCdShrtDesc,query2.rescGrpCdDesc,  query2.rescDtlMtdtCdShrtDesc,query2.rescDtlMtdtCdDesc,  query2.slsChnlDtlMtdtCdShrtDesc,query2.slsChnlDtlMtdtCdDesc,prod_resc_to_scr_gru.prod_resc_to_scr_gru_ID as prodScrMapId from prod_resc_to_scr_gru, (SELECT   subquery18.prodAvailId,subquery18.saleChnlid,subquery18.prodMktId,  subquery18.mktCd,  subquery18.prodId,subquery18.prodFamCd,  subquery18.prodCd,subquery18.prodInacIndc,subquery18.prodVers,subquery18.rescMapId,  subquery18.rescId,subquery18.bilgSysCd,subquery18.rescVers,  subquery18.rescCd,subquery18.rescTypCd,subquery18.bilgSysTypCd,  subquery18.countryCode,  subquery18.countryDesc,subquery18.productCode,subquery18.prodCodeShrtDesc,  subquery18.prodCodeDesc,  subquery18.rescCode,subquery18.rescCodeShrtDesc,subquery18.rescCodeDesc,subquery18.prodGrpId,subquery18.prodGrpCd,  subquery18.prodDtlId,subquery18.prodDtlMtdtCd,subquery18.prodDtlMtdCdVal,  subquery18.mktGrpId,subquery18.mktGrpCd,  subquery18.rescGrpId,subquery18.rescGrpCd,  subquery18.rescDtlID,subquery18.rescDtlMtdtCd,subquery18.rescMtdtVal,  subquery18.slsChnlDtlID,subquery18.slsChnlDtlMtdtCd,  subquery18.slsChnlDtlMtdtVal,  subquery18.prodGrpCdShrtDesc,subquery18.prodGrpCdDesc,  subquery18.prodDtlMtdtCdShrtDesc,subquery18.prodDtlMtdtCdDesc,  subquery18.mktGrpCdShrtDesc,subquery18.mktGrpCdDesc,  subquery18.rescGrpCdShrtDesc,subquery18.rescGrpCdDesc,  subquery18.rescDtlMtdtCdShrtDesc,subquery18.rescDtlMtdtCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as slsChnlDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as slsChnlDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery17.prodAvailId,subquery17.saleChnlid,subquery17.prodMktId,  subquery17.mktCd,  subquery17.prodId,subquery17.prodFamCd,  subquery17.prodCd,subquery17.prodInacIndc,subquery17.prodVers,subquery17.rescMapId,  subquery17.rescId,subquery17.bilgSysCd,subquery17.rescVers,  subquery17.rescCd,subquery17.rescTypCd,subquery17.bilgSysTypCd,  subquery17.countryCode,  subquery17.countryDesc,subquery17.productCode,subquery17.prodCodeShrtDesc,  subquery17.prodCodeDesc,  subquery17.rescCode,subquery17.rescCodeShrtDesc,subquery17.rescCodeDesc,subquery17.prodGrpId,subquery17.prodGrpCd,  subquery17.prodDtlId,subquery17.prodDtlMtdtCd,subquery17.prodDtlMtdCdVal,  subquery17.mktGrpId,subquery17.mktGrpCd,  subquery17.rescGrpId,subquery17.rescGrpCd,  subquery17.rescDtlID,subquery17.rescDtlMtdtCd,subquery17.rescMtdtVal,  subquery17.slsChnlDtlID,subquery17.slsChnlDtlMtdtCd,  subquery17.slsChnlDtlMtdtVal,  subquery17.prodGrpCdShrtDesc,subquery17.prodGrpCdDesc,  subquery17.prodDtlMtdtCdShrtDesc,subquery17.prodDtlMtdtCdDesc,  subquery17.mktGrpCdShrtDesc,subquery17.mktGrpCdDesc,  subquery17.rescGrpCdShrtDesc,subquery17.rescGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery16.prodAvailId,subquery16.saleChnlid,subquery16.prodMktId,  subquery16.mktCd,  subquery16.prodId,subquery16.prodFamCd,  subquery16.prodCd,subquery16.prodInacIndc,subquery16.prodVers,subquery16.rescMapId,  subquery16.rescId,subquery16.bilgSysCd,subquery16.rescVers,  subquery16.rescCd,subquery16.rescTypCd,subquery16.bilgSysTypCd,  subquery16.countryCode,  subquery16.countryDesc,subquery16.productCode,subquery16.prodCodeShrtDesc,  subquery16.prodCodeDesc,  subquery16.rescCode,subquery16.rescCodeShrtDesc,subquery16.rescCodeDesc,subquery16.prodGrpId,subquery16.prodGrpCd,  subquery16.prodDtlId,subquery16.prodDtlMtdtCd,subquery16.prodDtlMtdCdVal,  subquery16.mktGrpId,subquery16.mktGrpCd,  subquery16.rescGrpId,subquery16.rescGrpCd,  subquery16.rescDtlID,subquery16.rescDtlMtdtCd,subquery16.rescMtdtVal,  subquery16.slsChnlDtlID,subquery16.slsChnlDtlMtdtCd,  subquery16.slsChnlDtlMtdtVal,  subquery16.prodGrpCdShrtDesc,subquery16.prodGrpCdDesc,  subquery16.prodDtlMtdtCdShrtDesc,subquery16.prodDtlMtdtCdDesc,  subquery16.mktGrpCdShrtDesc,subquery16.mktGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescGrpCdDesc  from CD_VAL_TXT,  (SELECT   subquery15.prodAvailId,subquery15.saleChnlid,subquery15.prodMktId,  subquery15.mktCd,  subquery15.prodId,subquery15.prodFamCd,  subquery15.prodCd,subquery15.prodInacIndc,subquery15.prodVers,subquery15.rescMapId,  subquery15.rescId,subquery15.bilgSysCd,subquery15.rescVers,  subquery15.rescCd,subquery15.rescTypCd,subquery15.bilgSysTypCd,  subquery15.countryCode,  subquery15.countryDesc,subquery15.productCode,subquery15.prodCodeShrtDesc,  subquery15.prodCodeDesc,  subquery15.rescCode,subquery15.rescCodeShrtDesc,subquery15.rescCodeDesc,subquery15.prodGrpId,subquery15.prodGrpCd,  subquery15.prodDtlId,subquery15.prodDtlMtdtCd,subquery15.prodDtlMtdCdVal,  subquery15.mktGrpId,subquery15.mktGrpCd,  subquery15.rescGrpId,subquery15.rescGrpCd,  subquery15.rescDtlID,subquery15.rescDtlMtdtCd,subquery15.rescMtdtVal,  subquery15.slsChnlDtlID,subquery15.slsChnlDtlMtdtCd,  subquery15.slsChnlDtlMtdtVal,  subquery15.prodGrpCdShrtDesc,subquery15.prodGrpCdDesc,  subquery15.prodDtlMtdtCdShrtDesc,subquery15.prodDtlMtdtCdDesc,  GEO_UNIT_NME.GEO_NME as mktGrpCdShrtDesc,GEO_UNIT_NME.GEO_NME as mktGrpCdDesc  from GEO_UNIT_NME, GEO_UNIT,  (SELECT   subquery14.prodAvailId,subquery14.saleChnlid,subquery14.prodMktId,  subquery14.mktCd,  subquery14.prodId,subquery14.prodFamCd,  subquery14.prodCd,subquery14.prodInacIndc,subquery14.prodVers,subquery14.rescMapId,  subquery14.rescId,subquery14.bilgSysCd,subquery14.rescVers,  subquery14.rescCd,subquery14.rescTypCd,subquery14.bilgSysTypCd,  subquery14.countryCode,  subquery14.countryDesc,subquery14.productCode,subquery14.prodCodeShrtDesc,  subquery14.prodCodeDesc,  subquery14.rescCode,subquery14.rescCodeShrtDesc,subquery14.rescCodeDesc,subquery14.prodGrpId,subquery14.prodGrpCd,  subquery14.prodDtlId,subquery14.prodDtlMtdtCd,subquery14.prodDtlMtdCdVal,  subquery14.mktGrpId,subquery14.mktGrpCd,  subquery14.rescGrpId,subquery14.rescGrpCd,  subquery14.rescDtlID,subquery14.rescDtlMtdtCd,subquery14.rescMtdtVal,  subquery14.slsChnlDtlID,subquery14.slsChnlDtlMtdtCd,  subquery14.slsChnlDtlMtdtVal,  subquery14.prodGrpCdShrtDesc,subquery14.prodGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery13.prodAvailId,subquery13.saleChnlid,subquery13.prodMktId,  subquery13.mktCd,  subquery13.prodId,subquery13.prodFamCd,  subquery13.prodCd,subquery13.prodInacIndc,subquery13.prodVers,subquery13.rescMapId,  subquery13.rescId,subquery13.bilgSysCd,subquery13.rescVers,  subquery13.rescCd,subquery13.rescTypCd,subquery13.bilgSysTypCd,  subquery13.countryCode,  subquery13.countryDesc,subquery13.productCode,subquery13.prodCodeShrtDesc,  subquery13.prodCodeDesc,  subquery13.rescCode,subquery13.rescCodeShrtDesc,subquery13.rescCodeDesc,subquery13.prodGrpId,subquery13.prodGrpCd,  subquery13.prodDtlId,subquery13.prodDtlMtdtCd,subquery13.prodDtlMtdCdVal,  subquery13.mktGrpId,subquery13.mktGrpCd,  subquery13.rescGrpId,subquery13.rescGrpCd,  subquery13.rescDtlID,subquery13.rescDtlMtdtCd,subquery13.rescMtdtVal,  subquery13.slsChnlDtlID,subquery13.slsChnlDtlMtdtCd,  subquery13.slsChnlDtlMtdtVal,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodGrpCdDesc  from CD_VAL_TXT,  ( SELECT   subquery12.prodAvailId,subquery12.saleChnlid,subquery12.prodMktId,  subquery12.mktCd,  subquery12.prodId,subquery12.prodFamCd,  subquery12.prodCd,subquery12.prodInacIndc,subquery12.prodVers,subquery12.rescMapId,  subquery12.rescId,subquery12.bilgSysCd,subquery12.rescVers,  subquery12.rescCd,subquery12.rescTypCd,subquery12.bilgSysTypCd,  subquery12.countryCode,  subquery12.countryDesc,subquery12.productCode,subquery12.prodCodeShrtDesc,  subquery12.prodCodeDesc,  subquery12.rescCode,subquery12.rescCodeShrtDesc,subquery12.rescCodeDesc,subquery12.prodGrpId,subquery12.prodGrpCd,  subquery12.prodDtlId,subquery12.prodDtlMtdtCd,subquery12.prodDtlMtdCdVal,  subquery12.mktGrpId,subquery12.mktGrpCd,  subquery12.rescGrpId,subquery12.rescGrpCd,  subquery12.rescDtlID,subquery12.rescDtlMtdtCd,subquery12.rescMtdtVal,  SLS_CHNL_DTL.SLS_CHNL_DTL_ID as slsChnlDtlID,SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_CD as slsChnlDtlMtdtCd,  SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_VAL as slsChnlDtlMtdtVal  from SLS_CHNL_DTL,   (SELECT   subquery11.prodAvailId,subquery11.saleChnlid,subquery11.prodMktId,  subquery11.mktCd,  subquery11.prodId,subquery11.prodFamCd,  subquery11.prodCd,subquery11.prodInacIndc,subquery11.prodVers,subquery11.rescMapId,  subquery11.rescId,subquery11.bilgSysCd,subquery11.rescVers,  subquery11.rescCd,subquery11.rescTypCd,subquery11.bilgSysTypCd,  subquery11.countryCode,  subquery11.countryDesc,subquery11.productCode,subquery11.prodCodeShrtDesc,  subquery11.prodCodeDesc,  subquery11.rescCode,subquery11.rescCodeShrtDesc,subquery11.rescCodeDesc,subquery11.prodGrpId,subquery11.prodGrpCd,  subquery11.prodDtlId,subquery11.prodDtlMtdtCd,subquery11.prodDtlMtdCdVal,  subquery11.mktGrpId,subquery11.mktGrpCd,  subquery11.rescGrpId,subquery11.rescGrpCd,  RESC_DTL.RESC_DTL_ID as rescDtlID,RESC_DTL.RESC_DTL_MTDT_CD as rescDtlMtdtCd,RESC_DTL.RESC_MTDT_VAL as rescMtdtVal  from RESC_DTL,  (SELECT   subquery10.prodAvailId,subquery10.saleChnlid,subquery10.prodMktId,  subquery10.mktCd,  subquery10.prodId,subquery10.prodFamCd,  subquery10.prodCd,subquery10.prodInacIndc,subquery10.prodVers,subquery10.rescMapId,  subquery10.rescId,subquery10.bilgSysCd,subquery10.rescVers,  subquery10.rescCd,subquery10.rescTypCd,subquery10.bilgSysTypCd,  subquery10.countryCode,  subquery10.countryDesc,subquery10.productCode,subquery10.prodCodeShrtDesc,  subquery10.prodCodeDesc,  subquery10.rescCode,subquery10.rescCodeShrtDesc,subquery10.rescCodeDesc,subquery10.prodGrpId,subquery10.prodGrpCd,  subquery10.prodDtlId,subquery10.prodDtlMtdtCd,subquery10.prodDtlMtdCdVal,  subquery10.mktGrpId,subquery10.mktGrpCd,  RESC_GRP.RESC_GRP_ID as rescGrpId,RESC_GRP.RESC_GRP_CD as rescGrpCd  from RESC_GRP,  (SELECT   subquery9.prodAvailId,subquery9.saleChnlid,subquery9.prodMktId,  subquery9.mktCd,  subquery9.prodId,subquery9.prodFamCd,  subquery9.prodCd,subquery9.prodInacIndc,subquery9.prodVers,subquery9.rescMapId,  subquery9.rescId,subquery9.bilgSysCd,subquery9.rescVers,  subquery9.rescCd,subquery9.rescTypCd,subquery9.bilgSysTypCd,  subquery9.countryCode,  subquery9.countryDesc,subquery9.productCode,subquery9.prodCodeShrtDesc,  subquery9.prodCodeDesc,  subquery9.rescCode,subquery9.rescCodeShrtDesc,subquery9.rescCodeDesc,subquery9.prodGrpId,subquery9.prodGrpCd,  subquery9.prodDtlId,subquery9.prodDtlMtdtCd,subquery9.prodDtlMtdCdVal,  MKT_GRP.MKT_GRP_ID as mktGrpId,MKT_GRP.MKT_GRP_CD as mktGrpCd  from MKT_GRP,  ( SELECT   subquery8.prodAvailId,subquery8.saleChnlid,subquery8.prodMktId,  subquery8.mktCd,  subquery8.prodId,subquery8.prodFamCd,  subquery8.prodCd,subquery8.prodInacIndc,subquery8.prodVers,subquery8.rescMapId,  subquery8.rescId,subquery8.bilgSysCd,subquery8.rescVers,  subquery8.rescCd,subquery8.rescTypCd,subquery8.bilgSysTypCd,  subquery8.countryCode,  subquery8.countryDesc,subquery8.productCode,subquery8.prodCodeShrtDesc,  subquery8.prodCodeDesc,  subquery8.rescCode,subquery8.rescCodeShrtDesc,subquery8.rescCodeDesc,subquery8.prodGrpId,subquery8.prodGrpCd,  PROD_DTL.PROD_DTL_ID as prodDtlId,PROD_DTL.PROD_DTL_MTDT_CD as prodDtlMtdtCd,PROD_DTL.PROD_DTL_MTDT_VAL as prodDtlMtdCdVal  from PROD_DTL,  ( SELECT   subquery7.prodAvailId,subquery7.saleChnlid,subquery7.prodMktId,  subquery7.mktCd,  subquery7.prodId,subquery7.prodFamCd,  subquery7.prodCd,subquery7.prodInacIndc,subquery7.prodVers,subquery7.rescMapId,  subquery7.rescId,subquery7.bilgSysCd,subquery7.rescVers,  subquery7.rescCd,subquery7.rescTypCd,subquery7.bilgSysTypCd,  subquery7.countryCode,  subquery7.countryDesc,subquery7.productCode,subquery7.prodCodeShrtDesc,  subquery7.prodCodeDesc,  subquery7.rescCode,subquery7.rescCodeShrtDesc,subquery7.rescCodeDesc,PROD_GRP.prod_grp_id as prodGrpId,PROD_GRP.prod_grp_cd as prodGrpCd  from PROD_GRP,  (SELECT   subquery6.PROD_AVLBID as prodAvailId,subquery6.SLS_CHNL_ID as saleChnlid,subquery6.PROD_MKT_ID as prodMktId,  subquery6.MKT_CD as mktCd,  subquery6.PRODID as prodId,subquery6.PROD_FAM_CD as prodFamCd,  subquery6.PROD_CD as prodCd,subquery6.INAC_INDC as prodInacIndc,subquery6.PROD_VERS as prodVers,subquery6.RESC_MAP_ID as rescMapId,  subquery6.RESCID as rescId,subquery6.BILG_SYS_CODE as bilgSysCd,subquery6.RESC_VERS as rescVers,  subquery6.RESC_CD as rescCd,subquery6.RESC_TYP_CODE as rescTypCd,subquery6.BILG_SYS_TYP_CD as bilgSysTypCd,  subquery6.countryCode as countryCode,  subquery6.countryDesc as countryDesc,subquery6.productCode as productCode,subquery6.prodCodeShrtDesc as prodCodeShrtDesc,  subquery6.prodCodeDesc,  CD_VAL_TXT.CD_VAL_ID as rescCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as rescCodeShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescCodeDesc  from CD_VAL_TXT,  (SELECT   subquery5.PROD_AVLBID,subquery5.SLS_CHNL_ID,subquery5.PROD_MKT_ID,subquery5.MKT_CD,  subquery5.PRODID,subquery5.PROD_FAM_CD,subquery5.PROD_CD,subquery5.INAC_INDC,subquery5.PROD_VERS,subquery5.RESC_MAP_ID,  subquery5.RESCID,subquery5.BILG_SYS_CODE,subquery5.RESC_VERS,  subquery5.RESC_CD,subquery5.RESC_TYP_CODE,subquery5.BILG_SYS_TYP_CD,subquery5.countryCode,  subquery5.countryDesc,CD_VAL_TXT.CD_VAL_ID as productCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as prodCodeShrtDesc,  CD_VAL_TXT.CD_VAL_DESC as prodCodeDesc  from CD_VAL_TXT,  (SELECT   subquery4.PROD_AVLBID,subquery4.SLS_CHNL_ID,subquery4.PROD_MKT_ID,subquery4.MKT_CD,  subquery4.PRODID,subquery4.PROD_FAM_CD,subquery4.PROD_CD,subquery4.INAC_INDC,subquery4.PROD_VERS,subquery4.RESC_MAP_ID,  subquery4.RESCID,subquery4.BILG_SYS_CODE,subquery4.RESC_VERS,  subquery4.RESC_CD,subquery4.RESC_TYP_CODE,subquery4.BILG_SYS_TYP_CD,GEO_UNIT_NME.GEO_UNIT_ID as countryCode,  GEO_UNIT_NME.GEO_NME as countryDesc  from GEO_UNIT_NME ,  (SELECT   subquery3.PROD_AVLBID,subquery3.SLS_CHNL_ID,subquery3.PROD_MKT_ID,subquery3.MKT_CD,  subquery3.PRODID,subquery3.PROD_FAM_CD,subquery3.PROD_CD,subquery3.INAC_INDC,subquery3.PROD_VERS,subquery3.RESC_MAP_ID,  subquery3.RESC_ID as RESCID,RESC.RESC_ID,RESC.BILG_SYS_CODE,RESC.RESC_VERS,RESC.RESC_CD,RESC.RESC_TYP_CODE,RESC.BILG_SYS_TYP_CD   from RESC,  (SELECT   subquery2.PROD_AVLBID,subquery2.SLS_CHNL_ID,subquery2.PROD_MKT_ID,subquery2.MKT_CD,  subquery2.PRODID ,subquery2.PROD_FAM_CD,subquery2.PROD_CD,subquery2.INAC_INDC,subquery2.PROD_VERS,RESC_MAP.RESC_MAP_ID,  RESC_MAP.RESC_ID,RESC_MAP.PROD_ID from RESC_MAP,  (SELECT   PROD_AVLB.PROD_AVLB_ID,PROD_AVLB.PROD_ID,PROD_AVLB.SLS_CHNL_ID,PROD_MKT.PROD_MKT_ID,PROD_MKT.PROD_AVLB_ID as PROD_AVLBID,PROD_MKT.MKT_CD,  subquery1.PROD_ID as PRODID,subquery1.PROD_FAM_CD,subquery1.PROD_CD,subquery1.INAC_INDC,subquery1.PROD_VERS   from PROD_MKT,PROD_AVLB,(SELECT PROD_ID,PROD_FAM_CD,PROD_CD,INAC_INDC,PROD_VERS from PROD where    ("
						+ productcd
						+ ")"
						+ ") subquery1   WHERE PROD_MKT.PROD_AVLB_ID = PROD_AVLB.PROD_AVLB_ID and PROD_AVLB.PROD_ID = subquery1.PROD_ID and   ("
						+ strMktCd
						+ ")"
						+ ") subquery2  WHERE  RESC_MAP.PROD_ID = subquery2.PRODID) subquery3  WHERE subquery3.RESC_ID = RESC.RESC_ID  and ("
						+ resccd
						+ ")"
						+ ") subquery4  WHERE subquery4.MKT_CD = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32   order by GEO_UNIT_NME.GEO_NME) subquery5  WHERE subquery5.PROD_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6  WHERE subquery6.RESC_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7  WHERE subquery7.prodId = PROD_GRP.prod_id) subquery8  WHERE subquery8.prodId = PROD_DTL.prod_id) subquery9  WHERE subquery9.prodMktId = MKT_GRP.PROD_MKT_ID) subquery10  WHERE subquery10.rescId = RESC_GRP.RESC_ID) subquery11  WHERE subquery11.rescId = RESC_DTL.RESC_ID) subquery12 WHERE subquery12.saleChnlid = SLS_CHNL_DTL.SLS_CHNL_ID) subquery13  WHERE subquery13.prodGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery14  WHERE subquery14.prodDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery15  WHERE subquery15.mktGrpCd =  GEO_UNIT_NME.GEO_UNIT_ID and 1=1  and GEO_UNIT.GEO_UNIT_ID=GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and"
						+ " GEO_UNIT_NME.GEO_NME_TYP_CD = 32 and GEO_UNIT.GEO_UNIT_TYP_CD=130 order by GEO_UNIT_NME.GEO_NME) subquery16  WHERE subquery16.rescGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery17  WHERE subquery17.rescDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349  and CD_VAL_TXT.EXPN_DT is null  order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery18  WHERE subquery18.slsChnlDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null  order by CD_VAL_TXT.CD_VAL_SHRT_DESC) query2  WHERE query2.rescMapId = prod_resc_to_scr_gru.resc_map_id) qur2 ON qur1.prodScrMapId = qur2.prodScrMapId";

			} else {

				query = "SELECT count(*) as cnt from (SELECT  query1.scr_mkt_cd_id,query1.country_name, query1.scr_typ_cd_id as scr_typ_cd_id,query1.scr_typ_cd_shrt_d as scr_typ_cd_shrt_d,query1.scr_typ_cd_val_d as scr_typ_cd_val_d, query1.scr_gru_cd_id as scr_gru_cd_id,query1.scr_gru_cd_shrt_d as scr_gru_cd_shrt_d,query1.scr_gru_cd_val_d as scr_gru_cd_val_d, query1.scr_id as scr_id,query1.scr_gru_cd as scr_gru_cd,query1.scr_gru_id as scr_gru_id,query1.scr_typ_assn_id as scr_typ_assn_id, query1.scr_typ_id as scr_typ_id, query1.scr_mkt_cd as scr_mkt_cd,query1.scr_typ_cd as scr_typ_cd,query1.scr_dtl_id,prod_resc_to_scr_gru.prod_resc_to_scr_gru_ID as prodScrMapId,query1.scr_vers   from prod_resc_to_scr_gru,(SELECT  GEO_UNIT_ID as scr_mkt_cd_id,GEO_NME as country_name, subquery7.scr_typ_cd_id as scr_typ_cd_id,subquery7.scr_typ_cd_shrt_d as scr_typ_cd_shrt_d,subquery7.scr_typ_cd_val_d as scr_typ_cd_val_d, subquery7.scr_gru_cd_id as scr_gru_cd_id,subquery7.scr_gru_cd_shrt_d as scr_gru_cd_shrt_d,subquery7.scr_gru_cd_val_d as scr_gru_cd_val_d,subquery7.scr_id as scr_id,subquery7.scr_gru_cd as scr_gru_cd,subquery7.scr_gru_id as scr_gru_id,subquery7.scr_typ_assn_id as scr_typ_assn_id,subquery7.scr_typ_id as scr_typ_id, subquery7.scr_mkt_cd as scr_mkt_cd,subquery7.scr_typ_cd as scr_typ_cd,subquery7.scr_dtl_id,subquery7.scr_vers   from GEO_UNIT_NME,(SELECT   CD_VAL_ID as scr_typ_cd_id,CD_VAL_SHRT_DESC as scr_typ_cd_shrt_d,CD_VAL_DESC as scr_typ_cd_val_d,  subquery6.scr_gru_cd_id,subquery6.scr_gru_cd_shrt_d,subquery6.scr_gru_cd_val_d,subquery6.scr_id as scr_id,subquery6.scr_gru_cd as scr_gru_cd,subquery6.scr_gru_id as scr_gru_id,subquery6.scr_typ_assn_id as scr_typ_assn_id,subquery6.scr_typ_id as scr_typ_id,  subquery6.scr_mkt_cd as scr_mkt_cd,subquery6.scr_typ_cd as scr_typ_cd,subquery6.scr_dtl_id,subquery6.scr_vers    from CD_VAL_TXT,(SELECT CD_VAL_ID as scr_gru_cd_id,CD_VAL_SHRT_DESC as scr_gru_cd_shrt_d,CD_VAL_DESC as scr_gru_cd_val_d,subquery5.scr_id as scr_id,subquery5.scr_gru_cd as scr_gru_cd,subquery5.scr_gru_id as scr_gru_id,subquery5.scr_typ_assn_id as scr_typ_assn_id,subquery5.scr_typ_id as scr_typ_id,  subquery5.scr_mkt_cd as scr_mkt_cd,subquery5.scr_typ_cd as scr_typ_cd,subquery5.scr_dtl_id,subquery5.scr_vers  from CD_VAL_TXT,(  SELECT subquery3.scr_id as scr_id,scr_gru.scr_gru_cd as scr_gru_cd,subquery3.scr_gru_id as scr_gru_id,subquery3.scr_typ_assn_id as scr_typ_assn_id,subquery3.scr_typ_id as scr_typ_id,  subquery3.scr_mkt_cd as scr_mkt_cd,subquery3.scr_typ_cd as scr_typ_cd,subquery3.scr_dtl_id,subquery3.scr_vers  from scr_gru,(SELECT scr_typ_assn.scr_gru_id as scr_gru_id,subquery2.scr_typ_assn_id as scr_typ_assn_id,subquery2.scr_id as scr_id,subquery2.scr_typ_id as scr_typ_id,  subquery2.scr_mkt_cd as scr_mkt_cd,subquery2.scr_typ_cd as scr_typ_cd,subquery2.scr_dtl_id,subquery2.scr_vers   from scr_typ_assn,(SELECT scr_dtl.scr_typ_assn_id as scr_typ_assn_id, subquery1.scr_id as scr_id,subquery1.scr_typ_id as scr_typ_id,  subquery1.scr_mkt_cd as scr_mkt_cd,subquery1.scr_typ_cd as scr_typ_cd,scr_dtl.scr_dtl_id as scr_dtl_id,subquery1.scr_vers   FROM scr_dtl,   (SELECT scr.scr_id,scr.scr_typ_id,scr.scr_mkt_cd,subquery4.scr_typ_cd as scr_typ_cd,scr.scr_ver as scr_vers   FROM scr,   (select scr_typ_id,scr_typ_cd from scr_typ where ("
						+ scrtycd
						+ ")"
						+ ") subquery4  WHERE subquery4.scr_typ_id = scr.scr_typ_id and ("
						+ strMktCdScr
						+ ")"
						+ ") subquery1   WHERE subquery1.scr_id = scr_dtl.scr_id) subquery2  WHERE subquery2.scr_typ_assn_id = scr_typ_assn.scr_typ_assn_id and scr_typ_assn.scr_gru_id in (SELECT scr_gru_id from scr_gru where ("
						+ scrgrucd
						+ ")"
						+ ")) subquery3   WHERE subquery3.scr_gru_id = scr_gru.scr_gru_id) subquery5    WHERE subquery5.scr_gru_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6   WHERE subquery6.scr_typ_cd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7  WHERE subquery7.scr_mkt_cd = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32 order by GEO_UNIT_NME.GEO_NME) query1  WHERE query1.scr_dtl_id = prod_resc_to_scr_gru.SCR_DTL_ID) qur1  JOIN   (SELECT   query2.prodAvailId,query2.saleChnlid,query2.prodMktId,  query2.mktCd,  query2.prodId,query2.prodFamCd,  query2.prodCd,query2.prodInacIndc,query2.prodVers,query2.rescMapId,  query2.rescId,query2.bilgSysCd,query2.rescVers,  query2.rescCd,query2.rescTypCd,query2.bilgSysTypCd,  query2.countryCode,  query2.countryDesc,query2.productCode,query2.prodCodeShrtDesc,  query2.prodCodeDesc,  query2.rescCode,query2.rescCodeShrtDesc,query2.rescCodeDesc,query2.prodGrpId,query2.prodGrpCd,  query2.prodDtlId,query2.prodDtlMtdtCd,query2.prodDtlMtdCdVal,  query2.mktGrpId,query2.mktGrpCd,  query2.rescGrpId,query2.rescGrpCd,  query2.rescDtlID,query2.rescDtlMtdtCd,query2.rescMtdtVal,  query2.slsChnlDtlID,query2.slsChnlDtlMtdtCd,  query2.slsChnlDtlMtdtVal,  query2.prodGrpCdShrtDesc,query2.prodGrpCdDesc,  query2.prodDtlMtdtCdShrtDesc,query2.prodDtlMtdtCdDesc,  query2.mktGrpCdShrtDesc,query2.mktGrpCdDesc,  query2.rescGrpCdShrtDesc,query2.rescGrpCdDesc,  query2.rescDtlMtdtCdShrtDesc,query2.rescDtlMtdtCdDesc,  query2.slsChnlDtlMtdtCdShrtDesc,query2.slsChnlDtlMtdtCdDesc,prod_resc_to_scr_gru.prod_resc_to_scr_gru_ID as prodScrMapId from prod_resc_to_scr_gru, (SELECT   subquery18.prodAvailId,subquery18.saleChnlid,subquery18.prodMktId,  subquery18.mktCd,  subquery18.prodId,subquery18.prodFamCd,  subquery18.prodCd,subquery18.prodInacIndc,subquery18.prodVers,subquery18.rescMapId,  subquery18.rescId,subquery18.bilgSysCd,subquery18.rescVers,  subquery18.rescCd,subquery18.rescTypCd,subquery18.bilgSysTypCd,  subquery18.countryCode,  subquery18.countryDesc,subquery18.productCode,subquery18.prodCodeShrtDesc,  subquery18.prodCodeDesc,  subquery18.rescCode,subquery18.rescCodeShrtDesc,subquery18.rescCodeDesc,subquery18.prodGrpId,subquery18.prodGrpCd,  subquery18.prodDtlId,subquery18.prodDtlMtdtCd,subquery18.prodDtlMtdCdVal,  subquery18.mktGrpId,subquery18.mktGrpCd,  subquery18.rescGrpId,subquery18.rescGrpCd,  subquery18.rescDtlID,subquery18.rescDtlMtdtCd,subquery18.rescMtdtVal,  subquery18.slsChnlDtlID,subquery18.slsChnlDtlMtdtCd,  subquery18.slsChnlDtlMtdtVal,  subquery18.prodGrpCdShrtDesc,subquery18.prodGrpCdDesc,  subquery18.prodDtlMtdtCdShrtDesc,subquery18.prodDtlMtdtCdDesc,  subquery18.mktGrpCdShrtDesc,subquery18.mktGrpCdDesc,  subquery18.rescGrpCdShrtDesc,subquery18.rescGrpCdDesc,  subquery18.rescDtlMtdtCdShrtDesc,subquery18.rescDtlMtdtCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as slsChnlDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as slsChnlDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery17.prodAvailId,subquery17.saleChnlid,subquery17.prodMktId,  subquery17.mktCd,  subquery17.prodId,subquery17.prodFamCd,  subquery17.prodCd,subquery17.prodInacIndc,subquery17.prodVers,subquery17.rescMapId,  subquery17.rescId,subquery17.bilgSysCd,subquery17.rescVers,  subquery17.rescCd,subquery17.rescTypCd,subquery17.bilgSysTypCd,  subquery17.countryCode,  subquery17.countryDesc,subquery17.productCode,subquery17.prodCodeShrtDesc,  subquery17.prodCodeDesc,  subquery17.rescCode,subquery17.rescCodeShrtDesc,subquery17.rescCodeDesc,subquery17.prodGrpId,subquery17.prodGrpCd,  subquery17.prodDtlId,subquery17.prodDtlMtdtCd,subquery17.prodDtlMtdCdVal,  subquery17.mktGrpId,subquery17.mktGrpCd,  subquery17.rescGrpId,subquery17.rescGrpCd,  subquery17.rescDtlID,subquery17.rescDtlMtdtCd,subquery17.rescMtdtVal,  subquery17.slsChnlDtlID,subquery17.slsChnlDtlMtdtCd,  subquery17.slsChnlDtlMtdtVal,  subquery17.prodGrpCdShrtDesc,subquery17.prodGrpCdDesc,  subquery17.prodDtlMtdtCdShrtDesc,subquery17.prodDtlMtdtCdDesc,  subquery17.mktGrpCdShrtDesc,subquery17.mktGrpCdDesc,  subquery17.rescGrpCdShrtDesc,subquery17.rescGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery16.prodAvailId,subquery16.saleChnlid,subquery16.prodMktId,  subquery16.mktCd,  subquery16.prodId,subquery16.prodFamCd,  subquery16.prodCd,subquery16.prodInacIndc,subquery16.prodVers,subquery16.rescMapId,  subquery16.rescId,subquery16.bilgSysCd,subquery16.rescVers,  subquery16.rescCd,subquery16.rescTypCd,subquery16.bilgSysTypCd,  subquery16.countryCode,  subquery16.countryDesc,subquery16.productCode,subquery16.prodCodeShrtDesc,  subquery16.prodCodeDesc,  subquery16.rescCode,subquery16.rescCodeShrtDesc,subquery16.rescCodeDesc,subquery16.prodGrpId,subquery16.prodGrpCd,  subquery16.prodDtlId,subquery16.prodDtlMtdtCd,subquery16.prodDtlMtdCdVal,  subquery16.mktGrpId,subquery16.mktGrpCd,  subquery16.rescGrpId,subquery16.rescGrpCd,  subquery16.rescDtlID,subquery16.rescDtlMtdtCd,subquery16.rescMtdtVal,  subquery16.slsChnlDtlID,subquery16.slsChnlDtlMtdtCd,  subquery16.slsChnlDtlMtdtVal,  subquery16.prodGrpCdShrtDesc,subquery16.prodGrpCdDesc,  subquery16.prodDtlMtdtCdShrtDesc,subquery16.prodDtlMtdtCdDesc,  subquery16.mktGrpCdShrtDesc,subquery16.mktGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as rescGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescGrpCdDesc  from CD_VAL_TXT,  (SELECT   subquery15.prodAvailId,subquery15.saleChnlid,subquery15.prodMktId,  subquery15.mktCd,  subquery15.prodId,subquery15.prodFamCd,  subquery15.prodCd,subquery15.prodInacIndc,subquery15.prodVers,subquery15.rescMapId,  subquery15.rescId,subquery15.bilgSysCd,subquery15.rescVers,  subquery15.rescCd,subquery15.rescTypCd,subquery15.bilgSysTypCd,  subquery15.countryCode,  subquery15.countryDesc,subquery15.productCode,subquery15.prodCodeShrtDesc,  subquery15.prodCodeDesc,  subquery15.rescCode,subquery15.rescCodeShrtDesc,subquery15.rescCodeDesc,subquery15.prodGrpId,subquery15.prodGrpCd,  subquery15.prodDtlId,subquery15.prodDtlMtdtCd,subquery15.prodDtlMtdCdVal,  subquery15.mktGrpId,subquery15.mktGrpCd,  subquery15.rescGrpId,subquery15.rescGrpCd,  subquery15.rescDtlID,subquery15.rescDtlMtdtCd,subquery15.rescMtdtVal,  subquery15.slsChnlDtlID,subquery15.slsChnlDtlMtdtCd,  subquery15.slsChnlDtlMtdtVal,  subquery15.prodGrpCdShrtDesc,subquery15.prodGrpCdDesc,  subquery15.prodDtlMtdtCdShrtDesc,subquery15.prodDtlMtdtCdDesc,  GEO_UNIT_NME.GEO_NME as mktGrpCdShrtDesc,GEO_UNIT_NME.GEO_NME as mktGrpCdDesc  from GEO_UNIT_NME, GEO_UNIT,  (SELECT   subquery14.prodAvailId,subquery14.saleChnlid,subquery14.prodMktId,  subquery14.mktCd,  subquery14.prodId,subquery14.prodFamCd,  subquery14.prodCd,subquery14.prodInacIndc,subquery14.prodVers,subquery14.rescMapId,  subquery14.rescId,subquery14.bilgSysCd,subquery14.rescVers,  subquery14.rescCd,subquery14.rescTypCd,subquery14.bilgSysTypCd,  subquery14.countryCode,  subquery14.countryDesc,subquery14.productCode,subquery14.prodCodeShrtDesc,  subquery14.prodCodeDesc,  subquery14.rescCode,subquery14.rescCodeShrtDesc,subquery14.rescCodeDesc,subquery14.prodGrpId,subquery14.prodGrpCd,  subquery14.prodDtlId,subquery14.prodDtlMtdtCd,subquery14.prodDtlMtdCdVal,  subquery14.mktGrpId,subquery14.mktGrpCd,  subquery14.rescGrpId,subquery14.rescGrpCd,  subquery14.rescDtlID,subquery14.rescDtlMtdtCd,subquery14.rescMtdtVal,  subquery14.slsChnlDtlID,subquery14.slsChnlDtlMtdtCd,  subquery14.slsChnlDtlMtdtVal,  subquery14.prodGrpCdShrtDesc,subquery14.prodGrpCdDesc,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodDtlMtdtCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodDtlMtdtCdDesc  from CD_VAL_TXT,  (SELECT   subquery13.prodAvailId,subquery13.saleChnlid,subquery13.prodMktId,  subquery13.mktCd,  subquery13.prodId,subquery13.prodFamCd,  subquery13.prodCd,subquery13.prodInacIndc,subquery13.prodVers,subquery13.rescMapId,  subquery13.rescId,subquery13.bilgSysCd,subquery13.rescVers,  subquery13.rescCd,subquery13.rescTypCd,subquery13.bilgSysTypCd,  subquery13.countryCode,  subquery13.countryDesc,subquery13.productCode,subquery13.prodCodeShrtDesc,  subquery13.prodCodeDesc,  subquery13.rescCode,subquery13.rescCodeShrtDesc,subquery13.rescCodeDesc,subquery13.prodGrpId,subquery13.prodGrpCd,  subquery13.prodDtlId,subquery13.prodDtlMtdtCd,subquery13.prodDtlMtdCdVal,  subquery13.mktGrpId,subquery13.mktGrpCd,  subquery13.rescGrpId,subquery13.rescGrpCd,  subquery13.rescDtlID,subquery13.rescDtlMtdtCd,subquery13.rescMtdtVal,  subquery13.slsChnlDtlID,subquery13.slsChnlDtlMtdtCd,  subquery13.slsChnlDtlMtdtVal,  CD_VAL_TXT.CD_VAL_SHRT_DESC as prodGrpCdShrtDesc,CD_VAL_TXT.CD_VAL_DESC as prodGrpCdDesc  from CD_VAL_TXT,  ( SELECT   subquery12.prodAvailId,subquery12.saleChnlid,subquery12.prodMktId,  subquery12.mktCd,  subquery12.prodId,subquery12.prodFamCd,  subquery12.prodCd,subquery12.prodInacIndc,subquery12.prodVers,subquery12.rescMapId,  subquery12.rescId,subquery12.bilgSysCd,subquery12.rescVers,  subquery12.rescCd,subquery12.rescTypCd,subquery12.bilgSysTypCd,  subquery12.countryCode,  subquery12.countryDesc,subquery12.productCode,subquery12.prodCodeShrtDesc,  subquery12.prodCodeDesc,  subquery12.rescCode,subquery12.rescCodeShrtDesc,subquery12.rescCodeDesc,subquery12.prodGrpId,subquery12.prodGrpCd,  subquery12.prodDtlId,subquery12.prodDtlMtdtCd,subquery12.prodDtlMtdCdVal,  subquery12.mktGrpId,subquery12.mktGrpCd,  subquery12.rescGrpId,subquery12.rescGrpCd,  subquery12.rescDtlID,subquery12.rescDtlMtdtCd,subquery12.rescMtdtVal,  SLS_CHNL_DTL.SLS_CHNL_DTL_ID as slsChnlDtlID,SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_CD as slsChnlDtlMtdtCd,  SLS_CHNL_DTL.SLS_CHNL_DTL_MTDT_VAL as slsChnlDtlMtdtVal  from SLS_CHNL_DTL,   (SELECT   subquery11.prodAvailId,subquery11.saleChnlid,subquery11.prodMktId,  subquery11.mktCd,  subquery11.prodId,subquery11.prodFamCd,  subquery11.prodCd,subquery11.prodInacIndc,subquery11.prodVers,subquery11.rescMapId,  subquery11.rescId,subquery11.bilgSysCd,subquery11.rescVers,  subquery11.rescCd,subquery11.rescTypCd,subquery11.bilgSysTypCd,  subquery11.countryCode,  subquery11.countryDesc,subquery11.productCode,subquery11.prodCodeShrtDesc,  subquery11.prodCodeDesc,  subquery11.rescCode,subquery11.rescCodeShrtDesc,subquery11.rescCodeDesc,subquery11.prodGrpId,subquery11.prodGrpCd,  subquery11.prodDtlId,subquery11.prodDtlMtdtCd,subquery11.prodDtlMtdCdVal,  subquery11.mktGrpId,subquery11.mktGrpCd,  subquery11.rescGrpId,subquery11.rescGrpCd,  RESC_DTL.RESC_DTL_ID as rescDtlID,RESC_DTL.RESC_DTL_MTDT_CD as rescDtlMtdtCd,RESC_DTL.RESC_MTDT_VAL as rescMtdtVal  from RESC_DTL,  (SELECT   subquery10.prodAvailId,subquery10.saleChnlid,subquery10.prodMktId,  subquery10.mktCd,  subquery10.prodId,subquery10.prodFamCd,  subquery10.prodCd,subquery10.prodInacIndc,subquery10.prodVers,subquery10.rescMapId,  subquery10.rescId,subquery10.bilgSysCd,subquery10.rescVers,  subquery10.rescCd,subquery10.rescTypCd,subquery10.bilgSysTypCd,  subquery10.countryCode,  subquery10.countryDesc,subquery10.productCode,subquery10.prodCodeShrtDesc,  subquery10.prodCodeDesc,  subquery10.rescCode,subquery10.rescCodeShrtDesc,subquery10.rescCodeDesc,subquery10.prodGrpId,subquery10.prodGrpCd,  subquery10.prodDtlId,subquery10.prodDtlMtdtCd,subquery10.prodDtlMtdCdVal,  subquery10.mktGrpId,subquery10.mktGrpCd,  RESC_GRP.RESC_GRP_ID as rescGrpId,RESC_GRP.RESC_GRP_CD as rescGrpCd  from RESC_GRP,  (SELECT   subquery9.prodAvailId,subquery9.saleChnlid,subquery9.prodMktId,  subquery9.mktCd,  subquery9.prodId,subquery9.prodFamCd,  subquery9.prodCd,subquery9.prodInacIndc,subquery9.prodVers,subquery9.rescMapId,  subquery9.rescId,subquery9.bilgSysCd,subquery9.rescVers,  subquery9.rescCd,subquery9.rescTypCd,subquery9.bilgSysTypCd,  subquery9.countryCode,  subquery9.countryDesc,subquery9.productCode,subquery9.prodCodeShrtDesc,  subquery9.prodCodeDesc,  subquery9.rescCode,subquery9.rescCodeShrtDesc,subquery9.rescCodeDesc,subquery9.prodGrpId,subquery9.prodGrpCd,  subquery9.prodDtlId,subquery9.prodDtlMtdtCd,subquery9.prodDtlMtdCdVal,  MKT_GRP.MKT_GRP_ID as mktGrpId,MKT_GRP.MKT_GRP_CD as mktGrpCd  from MKT_GRP,  ( SELECT   subquery8.prodAvailId,subquery8.saleChnlid,subquery8.prodMktId,  subquery8.mktCd,  subquery8.prodId,subquery8.prodFamCd,  subquery8.prodCd,subquery8.prodInacIndc,subquery8.prodVers,subquery8.rescMapId,  subquery8.rescId,subquery8.bilgSysCd,subquery8.rescVers,  subquery8.rescCd,subquery8.rescTypCd,subquery8.bilgSysTypCd,  subquery8.countryCode,  subquery8.countryDesc,subquery8.productCode,subquery8.prodCodeShrtDesc,  subquery8.prodCodeDesc,  subquery8.rescCode,subquery8.rescCodeShrtDesc,subquery8.rescCodeDesc,subquery8.prodGrpId,subquery8.prodGrpCd,  PROD_DTL.PROD_DTL_ID as prodDtlId,PROD_DTL.PROD_DTL_MTDT_CD as prodDtlMtdtCd,PROD_DTL.PROD_DTL_MTDT_VAL as prodDtlMtdCdVal  from PROD_DTL,  ( SELECT   subquery7.prodAvailId,subquery7.saleChnlid,subquery7.prodMktId,  subquery7.mktCd,  subquery7.prodId,subquery7.prodFamCd,  subquery7.prodCd,subquery7.prodInacIndc,subquery7.prodVers,subquery7.rescMapId,  subquery7.rescId,subquery7.bilgSysCd,subquery7.rescVers,  subquery7.rescCd,subquery7.rescTypCd,subquery7.bilgSysTypCd,  subquery7.countryCode,  subquery7.countryDesc,subquery7.productCode,subquery7.prodCodeShrtDesc,  subquery7.prodCodeDesc,  subquery7.rescCode,subquery7.rescCodeShrtDesc,subquery7.rescCodeDesc,PROD_GRP.prod_grp_id as prodGrpId,PROD_GRP.prod_grp_cd as prodGrpCd  from PROD_GRP,  (SELECT   subquery6.PROD_AVLBID as prodAvailId,subquery6.SLS_CHNL_ID as saleChnlid,subquery6.PROD_MKT_ID as prodMktId,  subquery6.MKT_CD as mktCd,  subquery6.PRODID as prodId,subquery6.PROD_FAM_CD as prodFamCd,  subquery6.PROD_CD as prodCd,subquery6.INAC_INDC as prodInacIndc,subquery6.PROD_VERS as prodVers,subquery6.RESC_MAP_ID as rescMapId,  subquery6.RESCID as rescId,subquery6.BILG_SYS_CODE as bilgSysCd,subquery6.RESC_VERS as rescVers,  subquery6.RESC_CD as rescCd,subquery6.RESC_TYP_CODE as rescTypCd,subquery6.BILG_SYS_TYP_CD as bilgSysTypCd,  subquery6.countryCode as countryCode,  subquery6.countryDesc as countryDesc,subquery6.productCode as productCode,subquery6.prodCodeShrtDesc as prodCodeShrtDesc,  subquery6.prodCodeDesc,  CD_VAL_TXT.CD_VAL_ID as rescCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as rescCodeShrtDesc,CD_VAL_TXT.CD_VAL_DESC as rescCodeDesc  from CD_VAL_TXT,  (SELECT   subquery5.PROD_AVLBID,subquery5.SLS_CHNL_ID,subquery5.PROD_MKT_ID,subquery5.MKT_CD,  subquery5.PRODID,subquery5.PROD_FAM_CD,subquery5.PROD_CD,subquery5.INAC_INDC,subquery5.PROD_VERS,subquery5.RESC_MAP_ID,  subquery5.RESCID,subquery5.BILG_SYS_CODE,subquery5.RESC_VERS,  subquery5.RESC_CD,subquery5.RESC_TYP_CODE,subquery5.BILG_SYS_TYP_CD,subquery5.countryCode,  subquery5.countryDesc,CD_VAL_TXT.CD_VAL_ID as productCode,CD_VAL_TXT.CD_VAL_SHRT_DESC as prodCodeShrtDesc,  CD_VAL_TXT.CD_VAL_DESC as prodCodeDesc  from CD_VAL_TXT,  (SELECT   subquery4.PROD_AVLBID,subquery4.SLS_CHNL_ID,subquery4.PROD_MKT_ID,subquery4.MKT_CD,  subquery4.PRODID,subquery4.PROD_FAM_CD,subquery4.PROD_CD,subquery4.INAC_INDC,subquery4.PROD_VERS,subquery4.RESC_MAP_ID,  subquery4.RESCID,subquery4.BILG_SYS_CODE,subquery4.RESC_VERS,  subquery4.RESC_CD,subquery4.RESC_TYP_CODE,subquery4.BILG_SYS_TYP_CD,GEO_UNIT_NME.GEO_UNIT_ID as countryCode,  GEO_UNIT_NME.GEO_NME as countryDesc  from GEO_UNIT_NME ,  (SELECT   subquery3.PROD_AVLBID,subquery3.SLS_CHNL_ID,subquery3.PROD_MKT_ID,subquery3.MKT_CD,  subquery3.PRODID,subquery3.PROD_FAM_CD,subquery3.PROD_CD,subquery3.INAC_INDC,subquery3.PROD_VERS,subquery3.RESC_MAP_ID,  subquery3.RESC_ID as RESCID,RESC.RESC_ID,RESC.BILG_SYS_CODE,RESC.RESC_VERS,RESC.RESC_CD,RESC.RESC_TYP_CODE,RESC.BILG_SYS_TYP_CD   from RESC,  (SELECT   subquery2.PROD_AVLBID,subquery2.SLS_CHNL_ID,subquery2.PROD_MKT_ID,subquery2.MKT_CD,  subquery2.PRODID ,subquery2.PROD_FAM_CD,subquery2.PROD_CD,subquery2.INAC_INDC,subquery2.PROD_VERS,RESC_MAP.RESC_MAP_ID,  RESC_MAP.RESC_ID,RESC_MAP.PROD_ID from RESC_MAP,  (SELECT   PROD_AVLB.PROD_AVLB_ID,PROD_AVLB.PROD_ID,PROD_AVLB.SLS_CHNL_ID,PROD_MKT.PROD_MKT_ID,PROD_MKT.PROD_AVLB_ID as PROD_AVLBID,PROD_MKT.MKT_CD,  subquery1.PROD_ID as PRODID,subquery1.PROD_FAM_CD,subquery1.PROD_CD,subquery1.INAC_INDC,subquery1.PROD_VERS   from PROD_MKT,PROD_AVLB,(SELECT PROD_ID,PROD_FAM_CD,PROD_CD,INAC_INDC,PROD_VERS from PROD where     ("
						+ productcd
						+ ")"
						+ ") subquery1   WHERE PROD_MKT.PROD_AVLB_ID = PROD_AVLB.PROD_AVLB_ID and PROD_AVLB.PROD_ID = subquery1.PROD_ID and   ("
						+ strMktCd
						+ ")"
						+ ") subquery2  WHERE  RESC_MAP.PROD_ID = subquery2.PRODID) subquery3  WHERE subquery3.RESC_ID = RESC.RESC_ID  and ("
						+ resccd
						+ ")"
						+ ") subquery4  WHERE subquery4.MKT_CD = GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and GEO_UNIT_NME.GEO_NME_TYP_CD = 32   order by GEO_UNIT_NME.GEO_NME) subquery5  WHERE subquery5.PROD_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null  order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery6  WHERE subquery6.RESC_CD = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery7  WHERE subquery7.prodId = PROD_GRP.prod_id) subquery8  WHERE subquery8.prodId = PROD_DTL.prod_id) subquery9  WHERE subquery9.prodMktId = MKT_GRP.PROD_MKT_ID) subquery10  WHERE subquery10.rescId = RESC_GRP.RESC_ID) subquery11  WHERE subquery11.rescId = RESC_DTL.RESC_ID) subquery12 WHERE subquery12.saleChnlid = SLS_CHNL_DTL.SLS_CHNL_ID) subquery13  WHERE subquery13.prodGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery14  WHERE subquery14.prodDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery15  WHERE subquery15.mktGrpCd =  GEO_UNIT_NME.GEO_UNIT_ID and 1=1  and GEO_UNIT.GEO_UNIT_ID=GEO_UNIT_NME.GEO_UNIT_ID and GEO_UNIT_NME.LANG_CD = 39 and"
						+ " GEO_UNIT_NME.GEO_NME_TYP_CD = 32 and GEO_UNIT.GEO_UNIT_TYP_CD=130 order by GEO_UNIT_NME.GEO_NME) subquery16  WHERE subquery16.rescGrpCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery17  WHERE subquery17.rescDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null   order by CD_VAL_TXT.CD_VAL_SHRT_DESC) subquery18  WHERE subquery18.slsChnlDtlMtdtCd = CD_VAL_TXT.CD_VAL_ID and CD_VAL_TXT.LANG_CD = 39 and CD_VAL_TXT.WRIT_SCRP_CD = 19349 and CD_VAL_TXT.EXPN_DT is null  order by CD_VAL_TXT.CD_VAL_SHRT_DESC) query2  WHERE query2.rescMapId = prod_resc_to_scr_gru.resc_map_id) qur2 ON qur1.prodScrMapId = qur2.prodScrMapId";

			}

		}

		return stagingDAO.retreiveIds(query);
	}

	@Override
	public List<ProductScoreReportVO> productScrReport(
			ProductScoreReportVO productScoreReportVO) {
		return stagingDAO.productScrReport(productScoreReportVO);
	}

	@Override
	public List<CodeValue> retrieveGranularityCodes(Long scoreType) {
		LOGGER.info("entering ProductServiceImpl | retrieveGranularityCodes");
		return stagingDAO.retrieveGranularityCodes(scoreType);
	}

	@Override
	public List<CodeValue> retrieveProductCodeValues(
			AddNewProductsVO addNewProductsVO) {
		LOGGER.info("entering ProductServiceImpl | retrieveProductCodeValues");
		List<CodeValue> codeValues = stagingDAO
				.retrieveProductCodeValues(addNewProductsVO);
		return codeValues;
	}

	@Override
	public List<CodeValue> retrieveProdFamCode(Long prodCode) {
		LOGGER.info("entering ProductServiceImpl | retrieveProdFamCode");
		return stagingDAO.retrieveProdFamCode(prodCode);
	}

	@Override
	public List<Product> retrieveProdVers(Long prodCode) {
		LOGGER.info("entering ProductServiceImpl | retrieveProdVers");
		return stagingDAO.retrieveProdVers(prodCode);
	}

	@Override
	public List<CodeValue> retrieveResource(Long prodCode) {
		LOGGER.info("entering ProductServiceImpl | retrieveResource");
		return stagingDAO.retrieveResource(prodCode);
	}

	@Override
	public List<Product> retrieveFamProdVersion(Long famCode, Long prodCode) {
		LOGGER.info("entering ProductServiceImpl | retrieveFamProdVersion");
		return stagingDAO.retrieveFamProdVersion(famCode, prodCode);
	}

	@Override
	public List<CodeValue> retrieveFamVerResource(Long famCode, Long prodCode) {
		LOGGER.info("entering ProductServiceImpl | retrieveFamVerResource");
		return stagingDAO.retrieveFamVerResource(famCode, prodCode);
	}

	@Override
	public List<CodeValue> retrieveProdFamVerResource(Long famCode,
			Long prodCode, Long prodVer) {
		LOGGER.info("entering ProductServiceImpl | retrieveProdFamVerResource");
		return stagingDAO
				.retrieveProdFamVerResource(famCode, prodCode, prodVer);
	}

	@Override
	@Transactional("stgTransactionManager")
	public ProductScoreMappingVO updateProdRescScoreGranMapDtl(
			ProductScoreMappingVO productScoreMappingVO) {
		if (productScoreMappingVO.getIsSearch().equals("true")) {
			return searchProductResourceScoreGranularity(productScoreMappingVO);
		} else {
			if (productScoreMappingVO.getIsSearch().equals("falsePSerch")) {
				return insertProductResourceScoreGranularitys(productScoreMappingVO);
			} else {
				return insertProductResourceScoreGranularity(productScoreMappingVO);
			}
		}
	}

	private ProductScoreMappingVO searchProductResourceScoreGranularity(
			ProductScoreMappingVO productScoreMappingVO) {
		// Search logic - Starts
		List<ScoreMappingListVO> scoreMappingList = productScoreMappingVO
				.getScoreMappingList();
		// List<Long> scoreIdList = new ArrayList<Long>();
		Map<Long, Score> scoreDtlMap = new HashMap<Long, Score>();
		Score score = null;
		for (ScoreMappingListVO scrMapping : scoreMappingList) {
			Long scrTypeId = stagingDAO
					.retreiveData("select scr_typ_id from scr_typ where scr_typ_cd ="
							+ scrMapping.getScoreTypeCode());
			List<Long> scoreDtlIdList = stagingDAO
					.retreiveScrTypAssnIds("select scr_dtl_id from scr_dtl where scr_id =(select scr_id from scr where scr_typ_id in ("
							+ scrTypeId
							+ ") and scr_mkt_cd = "
							+ scrMapping.getScoreMarketCode()
							+ " and scr_ver = "
							+ scrMapping.getScoreVersion()
							+ ")");
			score = new Score();
			score.setScoreMarketCode(scrMapping.getScoreMarketCode());
			score.setScoreVersion(scrMapping.getScoreVersion());
			score.setScoreTypeId(scrMapping.getScoreTypeCode());
			for (Long scoreDtlId : scoreDtlIdList) {
				scoreDtlMap.put(scoreDtlId, score);
			}
		}
		// To get the prod id
		String prodIdQuery = "select prod_id from prod where prod_cd = "
				+ productScoreMappingVO.getProductCode() + " ";
		productScoreMappingVO.getProductCode();
		try {
			// prod_fam_cd
			if (productScoreMappingVO.getProductFamilyCode() != null) {
				prodIdQuery = prodIdQuery + " and prod_fam_cd ="
						+ productScoreMappingVO.getProductFamilyCode() + " ";
			}
		} catch (Exception e) {
			LOGGER.error(
					"ProductServiceImpl | searchProductResourceScoreGranularity",
					e);
		}
		try {
			// prod_vers
			if (productScoreMappingVO.getProductVersion() != null) {
				prodIdQuery = prodIdQuery + " and prod_vers = "
						+ productScoreMappingVO.getProductVersion() + " ";
			}
		} catch (Exception e) {
			LOGGER.error(
					"ProductServiceImpl | searchProductResourceScoreGranularity",
					e);
		}
		Long prodId = stagingDAO.retreiveData(prodIdQuery);
		List<Long> resourceMapIdList = stagingDAO
				.retreiveScrTypAssnIds("select resc_map_id from resc_map where prod_id ="
						+ prodId);
		Map<Long, Set<Long>> granularityCodeMap = new HashMap<Long, Set<Long>>();
		Set<Long> granularityCodeList = null;
		Set<Long> resourceCodesList = new HashSet<Long>();
		for (Long scoreDtlId : scoreDtlMap.keySet()) {
			granularityCodeList = new HashSet<Long>();
			for (Long resourceMapId : resourceMapIdList) {
				Long count_prod_scr_map = stagingDAO
						.retreiveData("SELECT count(PROD_RESC_TO_SCR_GRU_ID) from prod_resc_to_scr_gru where RESC_MAP_ID ="
								+ resourceMapId
								+ " and SCR_DTL_ID = "
								+ scoreDtlId + "");
				if (count_prod_scr_map > 0) {
					Long scoreTypeAssnId = stagingDAO
							.retreiveData("SELECT SCR_TYP_ASSN_ID FROM SCR_DTL WHERE SCR_DTL_ID="
									+ scoreDtlId);
					granularityCodeList
							.add(stagingDAO
									.retreiveData("SELECT DISTINCT(SCR_GRU_CD) FROM SCR_GRU WHERE SCR_GRU_ID IN(SELECT DISTINCT(SCR_GRU_ID) FROM SCR_TYP_ASSN WHERE SCR_TYP_ASSN_ID="
											+ scoreTypeAssnId + ")"));
					granularityCodeMap.put(scoreDtlId, granularityCodeList);
					Long resourceId = stagingDAO
							.retreiveData("SELECT RESC_ID FROM RESC_MAP WHERE RESC_MAP_ID="
									+ resourceMapId);
					resourceCodesList
							.add(stagingDAO
									.retreiveData("SELECT DISTINCT(RESC_CD) FROM RESC WHERE RESC_ID IN (SELECT DISTINCT(RESC_ID) FROM RESC_MAP WHERE RESC_MAP_ID="
											+ resourceId + ")"));
				}
			}
		}
		Set<String> granularityCodes = null;
		productScoreMappingVO.setResourceString(resourceCodesList.toString()
				.replace("[", "").replace("]", ""));
		for (ScoreMappingListVO scrMapping : scoreMappingList) {
			granularityCodes = new HashSet<String>();
			for (Long scoreDtlId : granularityCodeMap.keySet()) {
				if (scoreDtlMap.containsKey(scoreDtlId)
						&& scrMapping.getScoreVersion() == scoreDtlMap.get(
								scoreDtlId).getScoreVersion()
						&& scrMapping.getScoreMarketCode() == scoreDtlMap.get(
								scoreDtlId).getScoreMarketCode()
						&& scrMapping.getScoreTypeCode() == scoreDtlMap.get(
								scoreDtlId).getScoreTypeId()) {
					granularityCodes.add(granularityCodeMap.get(scoreDtlId)
							.toString());

				}
			}
			scrMapping.setGranularityString("");
			scrMapping.setGranularityString(granularityCodes.toString()
					.replace("[", "").replace("]", ""));
			LOGGER.info("scrMapping.getGranularityString():::"
					+ scrMapping.getGranularityString());
		}
		productScoreMappingVO.setScoreMappingList(scoreMappingList);
		return productScoreMappingVO;
		// Search logic - Ends
	}

	@SuppressWarnings("unused")
	private ProductScoreMappingVO searchProductResourceScoreGranularitys(
			ProductScoreMappingVO productScoreMappingVO) {
		// Search logic - Starts
		List<ScoreMappingListVO> scoreMappingList = productScoreMappingVO
				.getScoreMappingList();
		
		Map<Long, Score> scoreDtlMap = new HashMap<Long, Score>();
		Score score = null;
		for (ScoreMappingListVO scrMapping : scoreMappingList) {
			
			Long scrTypeId = stagingDAO
					.retreiveData("select scr_typ_id from scr_typ where scr_typ_cd ="
							+ scrMapping.getScoreTypeCode());
			List<Long> scoreDtlIdList = stagingDAO
					.retreiveScrTypAssnIds("select scr_dtl_id from scr_dtl where scr_id in (select distinct scr_id from scr where scr_typ_id in ("
							+ scrTypeId
							+ ") and scr_mkt_cd = "
							+ scrMapping.getScoreMarketCode()
							+ " and scr_ver = "
							+ scrMapping.getScoreVersion()
							+ ")");
			score = new Score();
			score.setScoreMarketCode(scrMapping.getScoreMarketCode());
			score.setScoreVersion(scrMapping.getScoreVersion());
			score.setScoreTypeId(scrMapping.getScoreTypeCode());
			for (Long scoreDtlId : scoreDtlIdList) {
				scoreDtlMap.put(scoreDtlId, score);
			}
		}
		// To get the prod id
		String prodIdQuery = "select prod_id from prod where prod_cd = "
				+ productScoreMappingVO.getProductCode() + " ";
		productScoreMappingVO.getProductCode();
		try {
			// prod_fam_cd
			if (productScoreMappingVO.getProductFamilyCode() != null) {
				prodIdQuery = prodIdQuery + " and prod_fam_cd ="
						+ productScoreMappingVO.getProductFamilyCode() + " ";
			}
		} catch (Exception e) {
			LOGGER.error(
					"ProductServiceImpl | searchProductResourceScoreGranularitys",
					e);
		}
		try {
			// prod_vers
			if (productScoreMappingVO.getProductVersion() != null) {
				prodIdQuery = prodIdQuery + " and prod_vers = "
						+ productScoreMappingVO.getProductVersion() + " ";
			}
		} catch (Exception e) {
			LOGGER.error(
					"ProductServiceImpl | searchProductResourceScoreGranularitys",
					e);
		}
		Long prodId = stagingDAO.retreiveData(prodIdQuery);

		List<Long> resourceMapIdList = new ArrayList<Long>();
		resourceMapIdList.add(productScoreMappingVO.getRescMapId());
		Map<Long, Set<Long>> granularityCodeMap = new HashMap<Long, Set<Long>>();
		Set<Long> granularityCodeList = null;
		Set<Long> resourceCodesList = new HashSet<Long>();
		for (Long scoreDtlId : scoreDtlMap.keySet()) {
			granularityCodeList = new HashSet<Long>();
			for (Long resourceMapId : resourceMapIdList) {
				Long count_prod_scr_map = stagingDAO
						.retreiveData("SELECT count(PROD_RESC_TO_SCR_GRU_ID) from prod_resc_to_scr_gru where RESC_MAP_ID ="
								+ resourceMapId
								+ " and SCR_DTL_ID = "
								+ scoreDtlId + "");
				if (count_prod_scr_map > 0) {
					Long scoreTypeAssnId = stagingDAO
							.retreiveData("SELECT SCR_TYP_ASSN_ID FROM SCR_DTL WHERE SCR_DTL_ID="
									+ scoreDtlId);
					granularityCodeList
							.add(stagingDAO
									.retreiveData("SELECT DISTINCT(SCR_GRU_CD) FROM SCR_GRU WHERE SCR_GRU_ID IN(SELECT DISTINCT(SCR_GRU_ID) FROM SCR_TYP_ASSN WHERE SCR_TYP_ASSN_ID="
											+ scoreTypeAssnId + ")"));
					granularityCodeMap.put(scoreDtlId, granularityCodeList);
					Long resourceId = stagingDAO
							.retreiveData("SELECT RESC_ID FROM RESC_MAP WHERE RESC_MAP_ID="
									+ resourceMapId);
					resourceCodesList
							.add(stagingDAO
									.retreiveData("SELECT DISTINCT(RESC_CD) FROM RESC WHERE RESC_ID IN (SELECT DISTINCT(RESC_ID) FROM RESC_MAP WHERE RESC_MAP_ID="
											+ resourceMapId + ")"));
				}
			}
		}
		Set<String> granularityCodes = null;
		productScoreMappingVO.setResourceString(resourceCodesList.toString()
				.replace("[", "").replace("]", ""));
		for (ScoreMappingListVO scrMapping : scoreMappingList) {
			granularityCodes = new HashSet<String>();
			for (Long scoreDtlId : granularityCodeMap.keySet()) {
				if (scoreDtlMap.containsKey(scoreDtlId)
						&& scrMapping.getScoreVersion() == scoreDtlMap.get(
								scoreDtlId).getScoreVersion()
						&& scrMapping.getScoreMarketCode() == scoreDtlMap.get(
								scoreDtlId).getScoreMarketCode()
						&& scrMapping.getScoreTypeCode() == scoreDtlMap.get(
								scoreDtlId).getScoreTypeId()) {
					granularityCodes.add(granularityCodeMap.get(scoreDtlId)
							.toString());

				}
			}
			scrMapping.setGranularityString("");
			scrMapping.setGranularityString(granularityCodes.toString()
					.replace("[", "").replace("]", ""));
			LOGGER.info("scrMapping.getGranularityString()::"
					+ scrMapping.getGranularityString());
		}
		productScoreMappingVO.setScoreMappingList(scoreMappingList);
		return productScoreMappingVO;
		// Search logic - Ends
	}

	@Transactional("stgTransactionManager")
	private ProductScoreMappingVO insertProductResourceScoreGranularitys(
			ProductScoreMappingVO productScoreMappingVO) {
		List<Long> scr_dtl_id_list_itms = new ArrayList<Long>();
		try {
			if (productScoreMappingVO.getScoreMappingList().size() > 0) {
				// To get the score dtl id
				for (ScoreMappingListVO scoreMappingList : productScoreMappingVO
						.getScoreMappingList()) {
					String[] granArr = scoreMappingList
							.getGranularityCodesString().split(",");
					List<String> granArrList = new ArrayList<String>(
							Arrays.asList(granArr));
					int targetSize = 999;
					List<List<String>> lisrtsScr = split(granArrList,
							targetSize);
					String grancd = "";
					String orVal = "OR";
					String end = ") ";
					String appendgrancd = " scr_gru_cd in (";
					for (List<String> lis : lisrtsScr) {
						String[] val = lis.toArray(new String[lis.size()]);
						String valStr = Arrays.toString(val);
						valStr = valStr.replace("[", "").replace("]", "");
						if (grancd.equalsIgnoreCase("")) {
							grancd = grancd + " scr_gru_cd in (" + valStr
									+ ") ";
						} else if (valStr.length() > 0) {
							grancd = grancd + orVal + appendgrancd + valStr
									+ end;
						}
					}
					Long scr_id = stagingDAO
							.retreiveData("select scr_id from scr where scr_typ_id in (select scr_typ_id from scr_typ where scr_typ_cd ="
									+ scoreMappingList.getScoreTypeCode()
									+ ") and scr_mkt_cd = "
									+ scoreMappingList.getScoreMarketCode()
									+ " and scr_ver = "
									+ scoreMappingList.getScoreVersion() + "");
					String scr_typ_assn_Query = "select scr_typ_assn_id from scr_typ_assn where scr_gru_id in (select scr_gru_id from scr_gru where "
							+ " ("
							+ grancd
							+ ") )  and scr_typ_id in (select scr_typ_id from scr_typ where scr_typ_cd ="
							+ scoreMappingList.getScoreTypeCode() + ")";
					LOGGER.info("Query scr_typ_assn_Query : "
							+ scr_typ_assn_Query);
					List<Long> scr_typ_assn_id_list = stagingDAO
							.retreiveScrTypAssnIds(scr_typ_assn_Query);
					String scr_typ_assn_id = scr_typ_assn_id_list.toString();
					scr_typ_assn_id = scr_typ_assn_id.replace("[", "").replace(
							"]", "");

					String scr_dtl_id_query = "select scr_dtl_id from scr_dtl where scr_id ="
							+ scr_id
							+ " and scr_typ_assn_id in ("
							+ scr_typ_assn_id + ")";
					LOGGER.info("Query scr_dtl_id_query : " + scr_dtl_id_query);

					List<Long> scr_dtl_id_list = stagingDAO
							.retreiveScrTypAssnIds(scr_dtl_id_query);
					for (Long scrDtlId : scr_dtl_id_list) {
						scr_dtl_id_list_itms.add(scrDtlId);
					}
					// To get the resource mapping id
					String[] rescArr = productScoreMappingVO
							.getResourceString().split(",");
					List<String> rescArrList = new ArrayList<String>(
							Arrays.asList(rescArr));
					List<List<String>> lisrtsresc = split(rescArrList,
							targetSize);
					String resccd = "";
					String appendresccd = " resc_cd in (";
					for (List<String> lis : lisrtsresc) {
						String[] val = lis.toArray(new String[lis.size()]);
						String valStr = Arrays.toString(val);
						valStr = valStr.replace("[", "").replace("]", "");
						if (resccd.equalsIgnoreCase("")) {
							resccd = resccd + " resc_cd in (" + valStr + ") ";
						} else if (valStr.length() > 0) {
							resccd = resccd + orVal + appendresccd + valStr
									+ end;
						}
					}
					// To get the prod id
					String prod_id_query = "select prod_id from prod where prod_cd = "
							+ productScoreMappingVO.getProductCode() + " ";
					productScoreMappingVO.getProductCode();
					try {
						// prod_fam_cd
						if (productScoreMappingVO.getProductFamilyCode() != null) {
							prod_id_query = prod_id_query
									+ " and prod_fam_cd ="
									+ productScoreMappingVO
											.getProductFamilyCode() + " ";
						}
					} catch (Exception e) {
						LOGGER.error(
								"ProductServiceImpl | insertProductResourceScoreGranularitys",
								e);
					}
					try {
						// prod_vers
						if (productScoreMappingVO.getProductVersion() != null) {
							prod_id_query = prod_id_query + " and prod_vers = "
									+ productScoreMappingVO.getProductVersion()
									+ " ";
						}
					} catch (Exception e) {
						LOGGER.error(
								"ProductServiceImpl | insertProductResourceScoreGranularitys",
								e);
					}
					Long prod_id = stagingDAO.retreiveData(prod_id_query);
					String resc_id_query = "select resc_id from resc where ("
							+ resccd + ")";
					LOGGER.info("Query resc_id_query : " + resc_id_query);

					List<Long> resc_id_list = stagingDAO
							.retreiveScrTypAssnIds(resc_id_query);

					String resc_id = resc_id_list.toString();
					resc_id = resc_id.replace("[", "").replace("]", "");

					String resc_map_id_query = "select resc_map_id from resc_map where prod_id ="
							+ prod_id + " and resc_id in (" + resc_id + ")";
					LOGGER.info("Query resc_map_id_query : "
							+ resc_map_id_query);
					List<Long> resc_map_id_list = new ArrayList<Long>();
					resc_map_id_list.add(productScoreMappingVO.getRescMapId());

					Long prodRescScrGruId = null;
					for (Long scr_dtl_id : scr_dtl_id_list) {
						for (Long resc_map_id : resc_map_id_list) {
							Long count_prod_scr_map = stagingDAO
									.retreiveData("SELECT count(PROD_RESC_TO_SCR_GRU_ID) from prod_resc_to_scr_gru where RESC_MAP_ID ="
											+ resc_map_id
											+ " and SCR_DTL_ID = "
											+ scr_dtl_id
											+ "");
							if (count_prod_scr_map > 0) {
								prodRescScrGruId = stagingDAO
										.retreiveData("SELECT PROD_RESC_TO_SCR_GRU_ID from prod_resc_to_scr_gru where RESC_MAP_ID ="
												+ resc_map_id
												+ " and SCR_DTL_ID = "
												+ scr_dtl_id + "");
								ProdRescScrGru prodRescScrGruExist = stagingDAO
										.findProdRescScrGruId(prodRescScrGruId);
								prodRescScrGruExist.setModifiedDate(new Date());
								prodRescScrGruExist
										.setModifiedUser(productScoreMappingVO
												.getLoggedInUser());
								LOGGER.info("Existing product"
										+ prodRescScrGruExist);
								stagingDAO
										.updateProdRescScrGru(prodRescScrGruExist);
							} else {
								prodRescScrGruId = stagingDAO
										.retreiveIds("Select prod_to_scr_map_id_seq.nextval from dual");
								ProdRescScrGru prodRescScrGru = new ProdRescScrGru();
								prodRescScrGru
										.setProdRescToScrGruId(prodRescScrGruId);
								prodRescScrGru.setRescMapId(resc_map_id);
								prodRescScrGru.setScrDtlId(scr_dtl_id);
								prodRescScrGru.setCreatedDate(new Date());
								prodRescScrGru
										.setCreatedUser(productScoreMappingVO
												.getLoggedInUser());
								prodRescScrGru.setModifiedDate(new Date());
								prodRescScrGru
										.setModifiedUser(productScoreMappingVO
												.getLoggedInUser());
								stagingDAO.updateProdRescScrGru(prodRescScrGru);
							}
						}
					}
				}
				// prod_resc_scr_gru deletion

				List<Long> prodScrMapIDList = stagingDAO
						.retrieveProdScoreMapId(scr_dtl_id_list_itms,
								productScoreMappingVO.getRescMapId());

				if (prodScrMapIDList != null) {
					String deleteQueryProdResc = "ProdRescScrGru.removeProdRescScrGruId";
					stagingDAO.removeProdRescID(prodScrMapIDList,
							deleteQueryProdResc, // -----------
													// prod_resc_scr_gran_map
													// table record deletion
							"prodRescToScrGruId");
				}

			}
		} catch (NullPointerException nullPntrExcep) {
			// prod_resc_scr_gru deletion - All mappings for that particular
			// Product-Score

			List<Long> prodScrMapIDList = stagingDAO
					.retrieveProdScoreMapId(productScoreMappingVO
							.getRescMapId());

			if (prodScrMapIDList != null) {
				String deleteQueryProdResc = "ProdRescScrGru.removeProdRescScrGruId";
				stagingDAO.removeProdRescID(prodScrMapIDList,
						deleteQueryProdResc, // -----------
												// prod_resc_scr_gran_map table
												// record deletion
						"prodRescToScrGruId");
			}
			LOGGER.error("NullPointerException::", nullPntrExcep);
		} catch (Exception e) {

			LOGGER.error("ProductServiceImpl | updateNewProducts", e);
		}

		return productScoreMappingVO;
	}

	private ProductScoreMappingVO insertProductResourceScoreGranularity(
			ProductScoreMappingVO productScoreMappingVO) {
		// To get the score dtl id
		if (productScoreMappingVO.getIsSearch().equalsIgnoreCase("falsePSerch")) {
			for (ScoreMappingListVO scoreMappingList : productScoreMappingVO
					.getScoreMappingList()) {
				String[] granArr = scoreMappingList.getGranularityString()
						.split(",");
				List<String> granArrList = new ArrayList<String>(
						Arrays.asList(granArr));
				int targetSize = 999;
				List<List<String>> lisrtsScr = split(granArrList, targetSize);
				String grancd = "";
				String orVal = "OR";
				String end = ") ";
				String appendgrancd = " scr_gru_cd in (";
				for (List<String> lis : lisrtsScr) {
					String[] val = lis.toArray(new String[lis.size()]);
					String valStr = Arrays.toString(val);
					valStr = valStr.replace("[", "").replace("]", "");
					if (grancd.equalsIgnoreCase("")) {
						grancd = grancd + " scr_gru_cd in (" + valStr + ") ";
					} else if (valStr.length() > 0) {
						grancd = grancd + orVal + appendgrancd + valStr + end;
					}
				}
			
				Long scr_id = stagingDAO
						.retreiveData("select distinct scr_id from scr_dtl where scr_id in (select scr_id from scr where scr_typ_id in (select scr_typ_id from scr_typ where scr_typ_cd ="
								+ scoreMappingList.getScoreTypeCode()
								+ ") and scr_mkt_cd = "
								+ scoreMappingList.getScoreMarketCode()
								+ " and scr_ver = "
								+ scoreMappingList.getScoreVersion() + ")");
				String scr_typ_assn_Query = "select scr_typ_assn_id from scr_typ_assn where scr_gru_id in (select scr_gru_id from scr_gru where "
						+ " ("
						+ grancd
						+ ") )  and scr_typ_id in (select scr_typ_id from scr_typ where scr_typ_cd ="
						+ scoreMappingList.getScoreTypeCode() + ")";
				LOGGER.info("Query scr_typ_assn_Query : " + scr_typ_assn_Query);
				List<Long> scr_typ_assn_id_list = stagingDAO
						.retreiveScrTypAssnIds(scr_typ_assn_Query);
				String scr_typ_assn_id = scr_typ_assn_id_list.toString();
				scr_typ_assn_id = scr_typ_assn_id.replace("[", "").replace("]",
						"");

				String scr_dtl_id_query = "select scr_dtl_id from scr_dtl where scr_id ="
						+ scr_id
						+ " and scr_typ_assn_id in ("
						+ scr_typ_assn_id + ")";
				LOGGER.info("Query scr_dtl_id_query : " + scr_dtl_id_query);

				List<Long> scr_dtl_id_list = stagingDAO
						.retreiveScrTypAssnIds(scr_dtl_id_query);

				// To get the resource mapping id
				String[] rescArr = productScoreMappingVO.getResourceString()
						.split(",");
				List<String> rescArrList = new ArrayList<String>(
						Arrays.asList(rescArr));
				List<List<String>> lisrtsresc = split(rescArrList, targetSize);
				String resccd = "";
				String appendresccd = " resc_cd in (";
				for (List<String> lis : lisrtsresc) {
					String[] val = lis.toArray(new String[lis.size()]);
					String valStr = Arrays.toString(val);
					valStr = valStr.replace("[", "").replace("]", "");
					if (resccd.equalsIgnoreCase("")) {
						resccd = resccd + " resc_cd in (" + valStr + ") ";
					} else if (valStr.length() > 0) {
						resccd = resccd + orVal + appendresccd + valStr + end;
					}
				}
				// To get the prod id
				String prod_id_query = "select prod_id from prod where prod_cd = "
						+ productScoreMappingVO.getProductCode() + " ";
				productScoreMappingVO.getProductCode();
				try {
					// prod_fam_cd
					if (productScoreMappingVO.getProductFamilyCode() != null) {
						prod_id_query = prod_id_query + " and prod_fam_cd ="
								+ productScoreMappingVO.getProductFamilyCode()
								+ " ";
					}
				} catch (Exception e) {
					LOGGER.error(
							"ProductServiceImpl | insertProductResourceScoreGranularity",
							e);
				}
				try {
					// prod_vers
					if (productScoreMappingVO.getProductVersion() != null) {
						prod_id_query = prod_id_query + " and prod_vers = "
								+ productScoreMappingVO.getProductVersion()
								+ " ";
					}
				} catch (Exception e) {
					LOGGER.error(
							"ProductServiceImpl | insertProductResourceScoreGranularity",
							e);
				}
				Long prod_id = stagingDAO.retreiveData(prod_id_query);
				String resc_id_query = "select resc_id from resc where ("
						+ resccd + ")";
				LOGGER.info("Query resc_id_query : " + resc_id_query);

				List<Long> resc_id_list = stagingDAO
						.retreiveScrTypAssnIds(resc_id_query);

				String resc_id = resc_id_list.toString();
				resc_id = resc_id.replace("[", "").replace("]", "");

				String resc_map_id_query = "select resc_map_id from resc_map where prod_id ="
						+ prod_id + " and resc_id in (" + resc_id + ")";
				LOGGER.info("Query resc_map_id_query : " + resc_map_id_query);

				List<Long> resc_map_id_list = stagingDAO
						.retreiveScrTypAssnIds(resc_map_id_query);
				Long prodRescScrGruId = null;
				for (Long scr_dtl_id : scr_dtl_id_list) {
					for (Long resc_map_id : resc_map_id_list) {
						Long count_prod_scr_map = stagingDAO
								.retreiveData("SELECT count(PROD_RESC_TO_SCR_GRU_ID) from prod_resc_to_scr_gru where RESC_MAP_ID ="
										+ resc_map_id
										+ " and SCR_DTL_ID = "
										+ scr_dtl_id + "");
						if (count_prod_scr_map > 0) {
							prodRescScrGruId = stagingDAO
									.retreiveData("SELECT PROD_RESC_TO_SCR_GRU_ID from prod_resc_to_scr_gru where RESC_MAP_ID ="
											+ resc_map_id
											+ " and SCR_DTL_ID = "
											+ scr_dtl_id
											+ "");
							ProdRescScrGru prodRescScrGruExist = stagingDAO
									.findProdRescScrGruId(prodRescScrGruId);
							prodRescScrGruExist.setModifiedDate(new Date());
							prodRescScrGruExist
									.setModifiedUser(productScoreMappingVO
											.getLoggedInUser());
							LOGGER.info("Existing product"
									+ prodRescScrGruExist);
							stagingDAO
									.updateProdRescScrGru(prodRescScrGruExist);
						} else {
							prodRescScrGruId = stagingDAO
									.retreiveIds("Select prod_to_scr_map_id_seq.nextval from dual");
							ProdRescScrGru prodRescScrGru = new ProdRescScrGru();
							prodRescScrGru
									.setProdRescToScrGruId(prodRescScrGruId);
							prodRescScrGru.setRescMapId(resc_map_id);
							prodRescScrGru.setScrDtlId(scr_dtl_id);
							prodRescScrGru.setCreatedDate(new Date());
							prodRescScrGru.setCreatedUser(productScoreMappingVO
									.getLoggedInUser());
							prodRescScrGru.setModifiedDate(new Date());
							prodRescScrGru
									.setModifiedUser(productScoreMappingVO
											.getLoggedInUser());
							stagingDAO.updateProdRescScrGru(prodRescScrGru);
						}
					}
				}
			}
		} else {
			for (ScoreMappingListVO scoreMappingList : productScoreMappingVO
					.getScoreMappingList()) {
				String[] granArr = scoreMappingList.getGranularityString()
						.split(",");
				List<String> granArrList = new ArrayList<String>(
						Arrays.asList(granArr));
				int targetSize = 999;
				List<List<String>> lisrtsScr = split(granArrList, targetSize);
				String grancd = "";
				String orVal = "OR";
				String end = ") ";
				String appendgrancd = " scr_gru_cd in (";
				for (List<String> lis : lisrtsScr) {
					String[] val = lis.toArray(new String[lis.size()]);
					String valStr = Arrays.toString(val);
					valStr = valStr.replace("[", "").replace("]", "");
					if (grancd.equalsIgnoreCase("")) {
						grancd = grancd + " scr_gru_cd in (" + valStr + ") ";
					} else if (valStr.length() > 0) {
						grancd = grancd + orVal + appendgrancd + valStr + end;
					}
				}
				Long scr_id = stagingDAO
						.retreiveData("select distinct scr_id from scr_dtl where scr_id in (select scr_id from scr where scr_typ_id in (select scr_typ_id from scr_typ where scr_typ_cd ="
								+ scoreMappingList.getScoreTypeCode()
								+ ") and scr_mkt_cd = "
								+ scoreMappingList.getScoreMarketCode()
								+ " and scr_ver = "
								+ scoreMappingList.getScoreVersion() + ")");
				String scr_typ_assn_Query = "select scr_typ_assn_id from scr_typ_assn where scr_gru_id in (select scr_gru_id from scr_gru where "
						+ " ("
						+ grancd
						+ ") )  and scr_typ_id in (select scr_typ_id from scr_typ where scr_typ_cd ="
						+ scoreMappingList.getScoreTypeCode() + ")";
				LOGGER.info("Query scr_typ_assn_Query : " + scr_typ_assn_Query);
				List<Long> scr_typ_assn_id_list = stagingDAO
						.retreiveScrTypAssnIds(scr_typ_assn_Query);
				String scr_typ_assn_id = scr_typ_assn_id_list.toString();
				scr_typ_assn_id = scr_typ_assn_id.replace("[", "").replace("]",
						"");

				String scr_dtl_id_query = "select scr_dtl_id from scr_dtl where scr_id ="
						+ scr_id
						+ " and scr_typ_assn_id in ("
						+ scr_typ_assn_id + ")";
				LOGGER.info("Query scr_dtl_id_query : " + scr_dtl_id_query);

				List<Long> scr_dtl_id_list = stagingDAO
						.retreiveScrTypAssnIds(scr_dtl_id_query);

				// To get the resource mapping id
				String[] rescArr = productScoreMappingVO.getResourceString()
						.split(",");
				List<String> rescArrList = new ArrayList<String>(
						Arrays.asList(rescArr));
				List<List<String>> lisrtsresc = split(rescArrList, targetSize);
				String resccd = "";
				String appendresccd = " resc_cd in (";
				for (List<String> lis : lisrtsresc) {
					String[] val = lis.toArray(new String[lis.size()]);
					String valStr = Arrays.toString(val);
					valStr = valStr.replace("[", "").replace("]", "");
					if (resccd.equalsIgnoreCase("")) {
						resccd = resccd + " resc_cd in (" + valStr + ") ";
					} else if (valStr.length() > 0) {
						resccd = resccd + orVal + appendresccd + valStr + end;
					}
				}
				// To get the prod id
				String prod_id_query = "select prod_id from prod where prod_cd = "
						+ productScoreMappingVO.getProductCode() + " ";
				productScoreMappingVO.getProductCode();
				try {
					// prod_fam_cd
					if (productScoreMappingVO.getProductFamilyCode() != null) {
						prod_id_query = prod_id_query + " and prod_fam_cd ="
								+ productScoreMappingVO.getProductFamilyCode()
								+ " ";
					}
				} catch (Exception e) {
					LOGGER.error(
							"ProductServiceImpl | insertProductResourceScoreGranularity",
							e);
				}
				try {
					// prod_vers
					if (productScoreMappingVO.getProductVersion() != null) {
						prod_id_query = prod_id_query + " and prod_vers = "
								+ productScoreMappingVO.getProductVersion()
								+ " ";
					}
				} catch (Exception e) {
					LOGGER.error(
							"ProductServiceImpl | insertProductResourceScoreGranularity",
							e);
				}
				Long prod_id = stagingDAO.retreiveData(prod_id_query);
				String resc_id_query = "select resc_id from resc where ("
						+ resccd + ")";
				LOGGER.info("Query resc_id_query : " + resc_id_query);

				List<Long> resc_id_list = stagingDAO
						.retreiveScrTypAssnIds(resc_id_query);
				String resc_id = resc_id_list.toString();
				resc_id = resc_id.replace("[", "").replace("]", "");

				String resc_map_id_query = "select resc_map_id from resc_map where prod_id ="
						+ prod_id + " and resc_id in (" + resc_id + ")";
				LOGGER.info("Query resc_map_id_query : " + resc_map_id_query);
				List<Long> resc_map_id_list = stagingDAO
						.retreiveScrTypAssnIds(resc_map_id_query);
				Long prodRescScrGruId = null;
				for (Long scr_dtl_id : scr_dtl_id_list) {
					for (Long resc_map_id : resc_map_id_list) {
						Long count_prod_scr_map = stagingDAO
								.retreiveData("SELECT count(PROD_RESC_TO_SCR_GRU_ID) from prod_resc_to_scr_gru where RESC_MAP_ID ="
										+ resc_map_id
										+ " and SCR_DTL_ID = "
										+ scr_dtl_id + "");
						if (count_prod_scr_map > 0) {
							prodRescScrGruId = stagingDAO
									.retreiveData("SELECT PROD_RESC_TO_SCR_GRU_ID from prod_resc_to_scr_gru where RESC_MAP_ID ="
											+ resc_map_id
											+ " and SCR_DTL_ID = "
											+ scr_dtl_id
											+ "");
							ProdRescScrGru prodRescScrGruExist = stagingDAO
									.findProdRescScrGruId(prodRescScrGruId);
							prodRescScrGruExist.setModifiedDate(new Date());
							prodRescScrGruExist
									.setModifiedUser(productScoreMappingVO
											.getLoggedInUser());
							LOGGER.info("Existing product"
									+ prodRescScrGruExist);
							stagingDAO
									.updateProdRescScrGru(prodRescScrGruExist);
						} else {
							prodRescScrGruId = stagingDAO
									.retreiveIds("Select prod_to_scr_map_id_seq.nextval from dual");
							ProdRescScrGru prodRescScrGru = new ProdRescScrGru();
							prodRescScrGru
									.setProdRescToScrGruId(prodRescScrGruId);
							prodRescScrGru.setRescMapId(resc_map_id);
							prodRescScrGru.setScrDtlId(scr_dtl_id);
							prodRescScrGru.setCreatedDate(new Date());
							prodRescScrGru.setCreatedUser(productScoreMappingVO
									.getLoggedInUser());
							prodRescScrGru.setModifiedDate(new Date());
							prodRescScrGru
									.setModifiedUser(productScoreMappingVO
											.getLoggedInUser());
							stagingDAO.updateProdRescScrGru(prodRescScrGru);
						}
					}
				}
			}
		}
		return productScoreMappingVO;
	}

	@Override
	@Transactional("stgTransactionManager")
	public ProductScoreMappingVO retreiveProdRescScoreGranMapDtl(
			ProductScoreMappingVO productScoreMappingVO) {
		return retreiveProdRescScoreDtl(productScoreMappingVO);
	}

	private ProductScoreMappingVO retreiveProdRescScoreDtl(
			ProductScoreMappingVO productScoreMappingVO) {
		ProductScoreMappingVO productScoreMapVO = new ProductScoreMappingVO();
		// Setting product Detail information
		productScoreMapVO = stagingDAO
				.retreiveProdDetails(productScoreMappingVO.getRescMapId());
		// Setting the Score values
		List<ScoreMappingListVO> scoreMappingList = stagingDAO
				.retreiveScrDetails(productScoreMappingVO.getRescMapId());
		productScoreMapVO.setScoreMappingList(scoreMappingList);
		productScoreMapVO.setRescMapId(productScoreMappingVO.getRescMapId());
		return searchProductResourceScoreGranularitys(productScoreMapVO);

	}

	@Override
	@Transactional("stgTransactionManager")
	public List<Long> retrieveProductMarketDetails(Long prodAvailId) {
		LOGGER.info("entering ProductServiceImpl | retrieveProductMarketDetails");
		return stagingDAO.retrieveProductMarketDetails(prodAvailId);
	}
}
