package com.dnb.dsc.refdata.service;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.Product;
import com.dnb.dsc.refdata.core.vo.AddNewProductsVO;
import com.dnb.dsc.refdata.core.vo.ProductScoreMappingVO;
import com.dnb.dsc.refdata.core.vo.ProductScoreReportVO;
import com.dnb.dsc.refdata.core.vo.ProductSearchVO;
import com.dnb.dsc.refdata.core.vo.ProductVO;

public interface ProductService {

	List<CodeValue> retrieveProductTypeCodeValues(
			ProductVO productSearchVO);

	List<CodeValue> retrieveResourceTypeCodeValues(
			ProductVO productSearchVO);

	Long countSearchProduct(ProductSearchVO productSearchVO);

	List<ProductSearchVO> productSearch(ProductSearchVO productSearchVO);
	
	Long updateNewProducts(AddNewProductsVO addNewProductsVO);

	AddNewProductsVO retrieveProductDetail(ProductSearchVO productSearchVO);

	Long editProducts(AddNewProductsVO addNewProductsVO);

	Long countOfProductScrRpt(ProductScoreReportVO productScoreReportVO);

	List<ProductScoreReportVO> productScrReport(
			ProductScoreReportVO productScoreReportVO);

	List<CodeValue> retrieveGranularityCodes(Long scoreType);

	List<CodeValue> retrieveProductCodeValues(AddNewProductsVO addNewProductsVO);

	List<CodeValue> retrieveProdFamCode(Long prodCode);

	List<Product> retrieveProdVers(Long prodCode);

	List<CodeValue> retrieveResource(Long prodCode);

	List<Product> retrieveFamProdVersion(Long famCode, Long prodCode);

	List<CodeValue> retrieveFamVerResource(Long famCode, Long prodCode);

	List<CodeValue> retrieveProdFamVerResource(Long famCode, Long prodCode,
			Long prodVer);

	//Long updateProdRescScoreGranMapDtl(
		//	ProductScoreMappingVO productScoreMappingVO);

	ProductScoreMappingVO updateProdRescScoreGranMapDtl(
			ProductScoreMappingVO productScoreMappingVO);

	ProductScoreMappingVO retreiveProdRescScoreGranMapDtl(
			ProductScoreMappingVO productScoreMappingVO);

	List<Long> retrieveProductMarketDetails(Long prodAvailId);
}
