/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service;

import java.util.List;
import java.util.Map;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.InduscodeMappingBulkDownloadVO;
import com.dnb.dsc.refdata.core.vo.IndustryCodesSearchCriteriaVO;



/**
 * This is used as the service interface for the Industry Code operations
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
public interface IndustryCodeService {

	/**
	 * Performs a hierarchy search of Industry Codes on the search db.<p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.<p>
	 * 
	 * @param industryCodesSearchCriteria
	 * @return a list of IndustryCode
	 */
	List<IndustryCode> searchIndustryCodes(IndustryCodesSearchCriteriaVO industryCodesSearchCriteria);
	
	/**
	 * The method will retrieve Industry code CrossWalks for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 * 
	 * @param industryCodeTypeCode
	 * @return list of codeValueVO
	 */
	List<CodeValueVO> retrieveCrossWalksForIndsCodeType(Long industryCodeTypeCode);

	/**
	 * The method will retrieve description for Industry code and type code. 
	 * 
	 * @param industryCodeTypeCode
	 * @param industryCode
	 * @return description
	 */
	String retrieveDescriptionForIndsCodeTypeCode(Long industryCodeTypeCode, String industryCode);
	
	Long retrieveIndustryCodeIdByCodeTypeCode(Long industryCodeTypeCode, String industryCode);
	
	/**
	 * The method will retrieve Industry code Group Levels for the selected
	 * industry code type. The method will be invoked on change of the industry
	 * code table drop down.
	 * 
	 * @param industryCodeTypeCode
	 * @param session
	 * @return list of codeValueVO
	 */
	List<CodeValueVO> retrieveGroupLevelCodes(Long industryCodeTypeCode, Long languageCode);
	
	/**
	 * 
	 * The method will count the records in the hierarchy search of industry codes on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return countResults
	 */
	Long countSearchIndustryCodes(IndustryCodesSearchCriteriaVO industryCodesSearchCriteria);
	
	/**
	 * The method will search the Staging SoR for the IndustryCode based on the 
	 * IndustryCodeId and will return the IndustryCode entity.
	 * 
	 * @param geoUnitId
	 */
	IndustryCode retrieveIndustryCodeByIndustryCodeId(Long industryCodeId);
	
	/**
	 * The method will persist the existing IndustryCode data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param geoUnit
	 */
	Long updateIndustryCode(IndustryCode industryCode);
	
	/**
	 * 
	 * The method will fetch the language codes available for the selected
	 * Industry Code Type. The method will be invoked when the user selects the
	 * Industry Code type value.
	 * 
	 * @param industryCodeTypeCode
	 * @param groupLevelCodes
	 * @return list of codeValueVO
	 */
	List<CodeValueVO> retrieveIndustryCodeLanguages(
			Long industryCodeTypeCode, List<Long> groupLevelCodes);
	
	/**
	 * 
	 * The method to lock the industry code record for edit
	 *
	 * @param industryCodeId
	 * @return isLocked
	 */
	String lockIndustryCode(Long industryCodeId);
	
	/**
	 * The method will be invoked by the when the the business owner reviews the
	 * changes submitted for his approval. The user reviews the changes and he
	 * could approve or reject the request. The method will fetch the details
	 * from Staging SoR and Transaction DB to merge and form the GeoUnit for
	 * review.
	 * 
	 * @param trackingId
	 */
	IndustryCode reviewIndustryCodeChanges(Long domainId);
	
	/**
	 * The method will search the Staging SoR for the IndustryCode based on the
	 * domainId and will return the IndustryCode entity.
	 * 
	 * @param domainId
	 */
	IndustryCode retrieveIndustryCodeByDomainId(Long domainId);
	
	
	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 * 
	 * @param domainId
	 * @return isSaveSuccess
	 */
	Long saveApprovedIndustryCodes(Long domainId);
	
	/**
	 * The method will remove the industryCode data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 * 
	 * @param industryCodeId
	 */
	void removeApprovedIndustryCode(Long industryCodeId);
	
	/**
	 * The method will add UiBulkDownload IndustryCode data in the Transactional
	 * DB.
	 * 
	 * @param UiBulkDownload
	 */
	Long addUIBulkDownload(UiBulkDownload uiBulkDownload);
	
	/**
	 * The method will retrieve UiBulkDownload IndustryCode data in the Transactional
	 * DB.
	 * 
	 * @param userId
	 */
	List<UiBulkDownload> retrieveUIBulkDownload(String userId);
	/**
	 * 
	 * The method to delete an existing Industry Code. The data will be saved in
	 * the temp table. For Industry code the delete operation is a hard delete.
	 * 
	 * @param industryCodeId
	 * @param deletedUser
	 * @return isSuccess
	 */
	Boolean deleteIndustryCode(Long industryCodeId, String deletedUser);
		
	/**
	 * The method will remove the industryCode data from the Staging DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 *
	 * @param industryCodeId
	 * @param boolean indicating the status
	 */
	void removeApprovedIndustryCodeFromStaging(Long industryCodeId);
	
	/**
	 * The method will remove the industryCode data from the Transaction DB
	 * Saved Record. The method will be invoked when the business owner approves
	 * a change and the respective changes have been updated in the Txn SoR.
	 * 
	 * @param industryCodeId
	 * @param boolean indicating the status
	 */
	void removeSavedRecord(Long industryCodeId);
	
	/**
	 * 
	 * The method to retrieve the savedRecords based on domainName and domain
	 * Identifier
	 * 
	 * @param userId
	 * @param domainName
	 * @param domainId
	 * @param userCommnet
	 * @return savedRecords
	 */
    List<SavedRecord> retrieveSavedRecords(String userId, String domainName, Long domainId, String userComment);
    
	/**
	 * 
	 * The method to populate the savedRecord entity
	 * 
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param deletedUser
	 * @param userComment
	 * @return savedRecord
	 */
	public SavedRecord populateSavedRecord(Long domainId, String domainName,
			String changeType, String deletedUser, String userComment);
	
	/**
	 * This method counts the IndustryCodeDescription  in the Staging DB to identify any duplicates
	 *
	 * @param industryCode
	 * @param industryCodeTypeCode
	 * @param industryDescription
	 * @return count
	 */
	public Boolean countIndustryCodeDescriptionForDuplicate(String industryCode,
			Long industryCodeTypeCode, String industryDescription);
	/**
	 * 
	 * The method to insert the saved record transaction to the ui_svd_rec
	 *
	 * @param domainId
	 * @param domainName
	 * @param changeType
	 * @param deletedUser
	 * @param userComment
	 * @return
	 */
	public SavedRecord insertSavedRecord(Long domainId, String domainName,
			String changeType, String deletedUser, String userComment);
	
	/**
	 * 
	 * The method will retrieve the Industry code data for all the tables given
	 * as parameter from the Staging SoR. The input will be Code Table ID of the
	 * Industry Code Type table. This method will be invoked only for search as
	 * this will fetch only the existing industry code types from inds_code
	 * table.
	 * 
	 * @param indsCodeTableId
	 * @return
	 */
	public Map<String, List<CodeValue>> retrieveIndustryCodeValues(Long indsCodeTableId);

	/**
	 * This method will retrieve all the crosswalks available with respective count of each crosswalk
	 * @return
	 */
	List<InduscodeMappingBulkDownloadVO> retrieveCrosswalkDetails();
}
