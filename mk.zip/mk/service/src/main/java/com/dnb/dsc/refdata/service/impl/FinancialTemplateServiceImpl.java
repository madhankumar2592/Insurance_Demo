/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.FinancialStatementSchedule;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplate;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateInternalLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateLineItem;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplateOwnerLineItem;
import com.dnb.dsc.refdata.dao.FinancialTemplateStagingDAO;
import com.dnb.dsc.refdata.dao.FinancialTemplateTransactionalDAO;
import com.dnb.dsc.refdata.service.FinancialTemplateService;

/**
 * 
 * @author Cognizant
 * @version last updated : June 19, 2012
 * @see
 * 
 */
@Service("FinancialTemplateService")
public class FinancialTemplateServiceImpl implements FinancialTemplateService {

	@Autowired
	private FinancialTemplateTransactionalDAO transactionalDAO;

	@Autowired
	private FinancialTemplateStagingDAO stagingDAO;
    
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(FinancialTemplateServiceImpl.class);

	@Override
	public List<CodeValueText> getFinancialTemplates(Long codeTableId){
		LOGGER.info("FinancialTemplateServiceImpl - getFinancialTemplates");
		return stagingDAO.getFinancialTemplates(codeTableId);
	}
	
	@Override
	public List<CodeValueText> getSchedulesForStatementType(Long statementType){
		LOGGER.info("FinancialTemplateServiceImpl - getSchedulesForStatementType");
		return stagingDAO.getSchedulesForStatementType(statementType);
	}
	
	@Override
	@Transactional("txnTransactionManager")
	public Long updateFinancialStatementTemplate(FinancialStatementTemplate fsTemplate) {
		List<FinancialStatementSchedule> fsScheduleList =  fsTemplate.getFinancialStatementScheduleList();
		fsTemplate.setFinancialStatementScheduleList(null);
		if(fsTemplate.getFinancialStatementTemplateId() == -1L){
			fsTemplate.setFinancialStatementTemplateId(transactionalDAO.retrieveMaxFinanceTemplateId());
		}
		FinancialStatementTemplate updatedFsTemplate = transactionalDAO.updateFinancialStatementTemplate(fsTemplate);
		if(fsScheduleList != null){
			for(FinancialStatementSchedule schedule : fsScheduleList){
				List<FinancialStatementTemplateLineItem> lineItemList = schedule.getFinancialStatementTemplateLineItemList();
				schedule.setFinancialStatementTemplateLineItemList(null);
				schedule.setFinancialStatementTemplateId(updatedFsTemplate.getFinancialStatementTemplateId());
				if(schedule.getFinancialStatementScheduleId() == -1L){
					schedule.setFinancialStatementScheduleId(transactionalDAO.retrieveMaxScheduleId());
				}
				FinancialStatementSchedule updatedSchedule = transactionalDAO.updateFinancialStatementSchedule(schedule);
				if(lineItemList != null){
					for(FinancialStatementTemplateLineItem lineItem : lineItemList){
						FinancialStatementTemplateInternalLineItem internalLineItem = lineItem.getFinancialStatementTemplateInternalLineItem();
						FinancialStatementTemplateOwnerLineItem ownerLineItem = lineItem.getFinancialStatementTemplateOwnerLineItem();
						lineItem.setFinancialStatementTemplateInternalLineItem(null);
						lineItem.setFinancialStatementTemplateOwnerLineItem(null);
						lineItem.setFinancialStatementScheduleId(updatedSchedule.getFinancialStatementScheduleId());
						if(lineItem.getFinancialStatementTemplateLineItemId() == -1L){
							lineItem.setFinancialStatementTemplateLineItemId(transactionalDAO.retrieveMaxLineItemId());
						}
						
						if(lineItem.getEffectiveFromDate() == null){
							lineItem.setEffectiveFromDate(new Date());
						}
						FinancialStatementTemplateLineItem updatedLineItem = transactionalDAO.updateFinancialStatementTemplateLineItem(lineItem);
						if(internalLineItem != null) {
							internalLineItem.setFinancialStatementTemplateLineItemId(updatedLineItem.getFinancialStatementTemplateLineItemId());
							transactionalDAO.updateFinancialStatementTemplateInternalLineItem(internalLineItem);
						}
						if(ownerLineItem != null) {
							ownerLineItem.setFinancialStatementTemplateLineItemId(updatedLineItem.getFinancialStatementTemplateLineItemId());
							transactionalDAO.updateFinancialStatementTemplateOwnerLineItem(ownerLineItem);
						}
					}
				}
			}
		}
		LOGGER.info("fsTemplate added with Id : " + updatedFsTemplate.getFinancialStatementTemplateId());
		return updatedFsTemplate.getFinancialStatementTemplateId();
	}
	
	@Override
	@Transactional("stgTransactionManager")
	public Long saveApprovedFinancialTemplates(Long domainId) {
		LOGGER.info("entering FinancialTemplateServiceImpl | saveApprovedFinancialTemplates");
		FinancialStatementTemplate fsTemplate = transactionalDAO.retrieveFinancialStatementTemplateById(domainId);
		FinancialStatementTemplate stagingFsTemplate = stagingDAO.retrieveFinancialStatementTemplateByTypeCode(fsTemplate.getFinancialTemplateTypeCode());
		if(stagingFsTemplate != null){
			stagingFsTemplate.setEffectiveToDate(new Date());
			stagingFsTemplate.setModifiedDate(new Date());
			stagingFsTemplate.setModifiedUser(fsTemplate.getModifiedUser());
			stagingDAO.updateFinancialStatementTemplate(stagingFsTemplate);
		}
		List<FinancialStatementSchedule> fsScheduleList =  fsTemplate.getFinancialStatementScheduleList();
		fsTemplate.setFinancialStatementScheduleList(null);
		FinancialStatementTemplate updatedFsTemplate = stagingDAO.updateFinancialStatementTemplate(fsTemplate);
		if(fsScheduleList != null){
			for(FinancialStatementSchedule schedule : fsScheduleList){
				List<FinancialStatementTemplateLineItem> lineItemList = schedule.getFinancialStatementTemplateLineItemList();
				schedule.setFinancialStatementTemplateLineItemList(null);
				schedule.setFinancialStatementTemplateId(updatedFsTemplate.getFinancialStatementTemplateId());
				FinancialStatementSchedule updatedSchedule = stagingDAO.updateFinancialStatementSchedule(schedule);
				if(lineItemList != null){
					for(FinancialStatementTemplateLineItem lineItem : lineItemList){
						FinancialStatementTemplateInternalLineItem internalLineItem = lineItem.getFinancialStatementTemplateInternalLineItem();
						FinancialStatementTemplateOwnerLineItem ownerLineItem = lineItem.getFinancialStatementTemplateOwnerLineItem();
						lineItem.setFinancialStatementTemplateInternalLineItem(null);
						lineItem.setFinancialStatementTemplateOwnerLineItem(null);
						lineItem.setFinancialStatementScheduleId(updatedSchedule.getFinancialStatementScheduleId());
						FinancialStatementTemplateLineItem updatedLineItem = stagingDAO.updateFinancialStatementTemplateLineItem(lineItem);
						internalLineItem.setFinancialStatementTemplateLineItemId(updatedLineItem.getFinancialStatementTemplateLineItemId());
						ownerLineItem.setFinancialStatementTemplateLineItemId(updatedLineItem.getFinancialStatementTemplateLineItemId());
						stagingDAO.updateFinancialStatementTemplateInternalLineItem(internalLineItem);
						stagingDAO.updateFinancialStatementTemplateOwnerLineItem(ownerLineItem);
					}
				}
			}
		}
		
		LOGGER.info("exiting FinancialTemplateServiceImpl | saveApprovedFinancialTemplates");
		return fsTemplate.getFinancialStatementTemplateId();
	}
	
	@Override
	@Transactional("txnTransactionManager")
	public Boolean removeApprovedFinancialTemplates(Long domainId) {
		return transactionalDAO.removeApprovedFinancialTemplate(domainId);
	}
	
	@Override
	@Transactional("stgTransactionManager")
	public FinancialStatementTemplate retrieveFinancialStatementTemplateByTypeCode(Long financialTemplateTypeCode, Boolean isStagingDB){
		FinancialStatementTemplate fsTemplate = null;
		if(isStagingDB){
			fsTemplate = stagingDAO.retrieveFinancialStatementTemplateByTypeCode(financialTemplateTypeCode);
			Map <String, Object> lockStatus = lockFinancialTemplateForEdit(fsTemplate.getFinancialTemplateTypeCode());
			fsTemplate.setIsLocked((Boolean)lockStatus.get("isLocked"));
			fsTemplate.setLockedUser((String)lockStatus.get("username"));
		}else{
			fsTemplate = transactionalDAO.retrieveFinancialStatementTemplateByTypeCode(financialTemplateTypeCode);
		}
		LOGGER.info("fsTemplate : " + fsTemplate);
		return fsTemplate;
	}
	
	@Override
	public List<CodeValueText> getLineItemsForScheduleType(Long scheduleType){
		LOGGER.info("FinancialTemplateServiceImpl - getLineItemsForScheduleType");
		return stagingDAO.getLineItemsForScheduleType(scheduleType);
	}
	
	@Transactional("stgTransactionManager")
	public Map<Integer, String> retrieveDescForId(
			List<Integer> codeValueIdList) {
		LOGGER.info("entering FinancialTemplateServiceImpl | retrieveDescForId");
		return stagingDAO.retrieveDescForId(codeValueIdList);
	}
	@Transactional("txnTransactionManager")
	public FinancialStatementTemplate retrieveFinancialStatementTemplateById(Long financialStatementTemplateId){
		LOGGER.info("entering FinancialTemplateServiceImpl || retrieveFinancialStatementTemplateById");
		FinancialStatementTemplate financialStatementTemplate =transactionalDAO.retrieveFinancialStatementTemplateById(financialStatementTemplateId);
		LOGGER.info("FinancialStatementTemplate  ||"+financialStatementTemplate);
		return financialStatementTemplate; 				
	}
	
	@Override
	@Transactional("stgTransactionManager")
	public List<CodeValueText> retrieveStatementForSchedules(
			List<Integer> scheduleCodeList) {
		LOGGER.info("entering FinancialTemplateServiceImpl | retrieveStatementForSchedules");
		return stagingDAO.retrieveStatementForSchedules(scheduleCodeList);
	}
	

    /**
     * The method return the finance template type code for a given finance template id
     *
     * @param financeTemplateId
     * @return
     */
	@Transactional("txnTransactionManager")
	public Long retrieveFinanceTemplateCodeById(Long financeTemplateId){
	    LOGGER.info("entering FinancialTemplateServiceImpl | retrieveFinanceTemplateCodeById");
	    return transactionalDAO.retrieveFinanceTemplateCodeById(financeTemplateId);
	}
	/**
	 * This method checks if the financial Template with given financialTemplateTypeCode 
	 * is already present in transactional db. If it exists, 
	 * the return map will contain isLocked=true and username=modifiedUser. Else the 
	 * map will contain isLocked=false and username="".
	 * 
	 * @param financialTemplateTypeCode
	 * @return map
	 */
	@Override
	public Map<String, Object> lockFinancialTemplateForEdit(Long financialTemplateTypeCode){
		return transactionalDAO.lockFinancialTemplateForEdit(financialTemplateTypeCode);
	}
}
