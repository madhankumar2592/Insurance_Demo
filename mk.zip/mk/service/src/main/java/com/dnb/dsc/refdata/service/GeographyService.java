/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service;

import java.util.List;
import java.util.Map;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.GeoDefaultConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoHierarchy;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.entity.GeographySearch;
import com.dnb.dsc.refdata.core.entity.UserGroupMapping;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.GeoSearchCriteriaVO;
import com.dnb.dsc.refdata.core.entity.UiBulkDownload;

/**
 * This is used as the services interface for the Geography operations
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
public interface GeographyService {

	/**
	 * The method will search for the geo units by name. The user will type in
	 * the filter condition in the name field and the dao layer will retrieve
	 * the names satisfying the filter
	 * 
	 * @param nameFilter
	 * @param langaugeCode
	 * @return geoUnitNames the list of geo names
	 */
	List<GeoUnitName> searchGeoUnitByName(String nameFilter, int startIndex,
			int maxResults, String sortBy, String sortOrder, Long langaugeCode);

	/**
	 * The method will search for the geo units by code. The user will type in
	 * the filter condition in the code field and the dao layer will retrieve
	 * the codes satisfying the filter
	 * 
	 * @param codeFilter
	 * @param langaugeCode
	 * @return geoUnitCodes the list of geo codes
	 */
	List<GeoUnitCode> searchGeoUnitByCode(String codeFilter, int startIndex,
			int maxResults, String sortBy, String sortOrder, Long langaugeCode);

	/**
	 * The method will perform a soft delete on the geoUnitId in the
	 * Transactional DB. The expiredByDate will be set as current date.
	 * 
	 * @param geoUnitId
	 * @return workflowTrackingId
	 */
	Long deleteGeoUnitById(Long geoUnitId);

	/**
	 * The method will validate the Geo Unit for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param geoUnitId
	 */
	String lockGeoUnit(Long geoUnitId);

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 * 
	 * @param geoUnitId
	 */
	GeoUnit retrieveGeoUnitByGeoUnitId(Long geoUnitId);

	/**
	 * The method will retrieve the Geo Unit based on the Work-flow Tracking Id.
	 * This method will be invoked from the Work-flow Component and the search
	 * will be performed on the Transactional DB.
	 * 
	 * @param trackingId
	 */
	GeoUnit retreiveGeoUnitByDomainId(Long domainId);

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Geo Unit Id and the Country Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	List<CodeValueVO> retrieveAllCountries(Long nameType, Long languageCode);

	/**
	 * The method will retrieve all Continent details from the Search DB based
	 * on the name type code and the user preferred language code. The return
	 * type is a VO which contains the Continent Geo Unit Id and the Continent
	 * Name.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	List<CodeValueVO> retrieveAllContinents(Long nameType, Long languageCode);

	/**
	 * The method will retrieve the Geo Units corresponding to the
	 * parentGeoUnit, geoUnitType, nameType and languageCode which you want to
	 * retrieve the data. The retrieval is from the Search DB. The return type
	 * is a VO which contains the Geo Unit Id and the Geo Unit name.
	 * 
	 * @param languageCode
	 * @param geoUnitType
	 * @param parentGeoUnitId
	 * @param nameType
	 */
	List<CodeValueVO> retrieveChildGeoUnitsByType(Long languageCode,
			Long geoUnitType, Long parentGeoUnitId, Long nameType);

	/**
	 * The method will be invoked by the Work-flow Component to save the
	 * approved data to the Staging SoR. The input to the method will be the
	 * domain identifier which is the unique key to identify the domain. The
	 * method will return true if the save to staging SoR is success.
	 * 
	 * @param domainId
	 * @param changeTypeId
	 * @return geoUnitId
	 */
	Long saveApprovedGeoChanges(Long domainId, Long changeTypeId);

	/**
	 * The method will remove the geo unit data from the Transaction DB. The
	 * method will be invoked when the business owner approves a change and the
	 * respective changes have been updated in the Staging SoR.
	 * 
	 * @param geoUnitId
	 * @param boolean indicating the status
	 */
	void removeApprovedGeoUnit(Long geoUnitId, Long changeTypeId);

	/**
	 * The method will persist the existing Geo Unit data in the Transactional
	 * DB. Only the changed relational data will be inserted. The service method
	 * need to perform validation to identify the records which have been
	 * updated from the UI.
	 * 
	 * @param geoUnit
	 */
	Long updateGeoUnit(GeoUnit geoUnit);

	/**
	 * 
	 * The method will perform a hierarchy search of geo units on the search db.
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return list of geographies
	 */
	List<GeographySearch> searchGeographies(GeoSearchCriteriaVO searchCriteriaVO);

	/**
	 * 
	 * The method will count the records in the hierarchy search of geo units on
	 * the search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return countResults
	 */
	Long countSearchGeographies(GeoSearchCriteriaVO searchCriteriaVO);

	/**
	 * 
	 * The method will count the records in the name search of geo units on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchString
	 * @return countResults
	 */
	Long countSearchGeoUnitByName(String searchString);

	/**
	 * 
	 * The method will count the records in the code search of geo units on the
	 * search db. The search will be done on the flat db based on the search
	 * criteria the user had provided.
	 * 
	 * @param searchString
	 * @return countResults
	 */
	Long countSearchGeoUnitByCode(String searchString);

	/**
	 * The method will be invoked by the when the the business owner reviews the
	 * changes submitted for his approval. The user reviews the changes and he
	 * could approve or reject the request. The method will fetch the details
	 * from Staging SoR and Transaction DB to merge and form the GeoUnit for
	 * review.
	 * 
	 * @param trackingId
	 */
	GeoUnit reviewGeoUnitChanges(Long domainId);

	/**
	 * The method will retrieve all Country Groups from the Search DB based on
	 * the name type code and the user preferred language code. The return type
	 * is a VO which contains the Country Group Geo Unit Id and the Country
	 * Names.
	 * 
	 * @param nameType
	 * @param languageCode
	 */
	List<CodeValueVO> retrieveAllCountryGroups(Long nameType, Long languageCode);

	/**
	 * Retrieves all the country groups or the country groups under the given
	 * country group
	 * <p>
	 * The returned List of Geo Unit Names will be displayed in the search
	 * result page in Country Groups.
	 * <p>
	 * 
	 * @param langCode
	 * @param writingScriptCode
	 * @param nameTypeCode
	 * @param geoUnitId
	 * @return a List of GeoUnitName
	 */
	List<GeoUnitName> searchCountryGroups(Long langCode,
			Long writingScriptCode, Long nameTypeCode, Long geoUnitId);

	/**
	 * The method will insert new Geo Unit data in the Transactional DB.
	 * 
	 * @param geoUnit
	 */
	Long insertGeoUnit(GeoUnit geoUnit);

	/**
	 * 
	 * The method will retrieve all geography hierarchies
	 * 
	 * @return geoHierarchies
	 */
	List<GeoHierarchy> retrieveAllGeoHierarchies();
	
	/**
	 * 
	 * The method will retrieve all geography default configurations
	 * 
	 * @return geoDefaultConfigurations
	 */
	List<GeoDefaultConfiguration> retrieveAllGeoConfigurations();
	
	Boolean checkForChildGeoUnit(Long geoUnitId);
	
	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 * 
	 * @param geoUnitId
	 */
	GeoUnit retrieveTxnGeoUnitById(Long geoUnitId);
	
	/**
	 * 
	 * The method will retrieve all user group mappings available within refdata.
	 * 
	 * @return userGroupMappings
	 */
	List<UserGroupMapping> retrieveAllUserGroupMappings();
	
	Map<Long, String> getHierarchyByGeoUnitId(Long geoUnitId, Long geoUnitTypeCode);

	String getOfficialNameByGeoUnitIdAndTypeCode(Long parentGeoUnitId,
			Long geoUnitId, Long geoUnitTypeCode);
	
	Map<Long, List<GeoUnit>> retrieveGeoUnitsByIdList(List<Long> geoUnitIds);
	
	/**
	 * 
	 * The method will retrieve all GeoUnitType based on the GeoUnitId
	 * 
	 * @return GeoUnitType
	 */	
	List<GeoHierarchy> retrieveGeoUnitType(Long geoUnitId);
	/**
	 * The method will add UiBulkDownload Geography data in the Transactional
	 * DB.
	 * 
	 * @param UiBulkDownload
	 */
	Long addUIBulkDownload(UiBulkDownload uiBulkDownload);
	/**
	 * 
	 * The method will retrieve all GeoUnitType based on the GeoUnitId
	 * 
	 * @return GeoUnitType
	 */	
	List<GeoHierarchy> retrieveGeoUnitHierarchies(Long geoUnitId);
	/**
	 * the method to return all geoUnit Types
	 * @return
	 */
	List<CodeValue> retrieveAllGeoUnitTypes();
	/**
	 * 
	 * The method to retrieve all applicable GeoUnit Names
	 *
	 * @return
	 */
	List<CodeValue> retrieveApplicableGeoNameTypes();
}
