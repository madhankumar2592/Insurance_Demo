/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.endpoint;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SavedRecord;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.SCoTSSearchCriteriaVO;
import com.dnb.dsc.refdata.service.SCoTsService;

/**
 * This is the end point class implementation that connects a web service client
 * to the JAX-WS runtime. The class contains methods which are mapped to the web
 * service requests. The mapping will invoke the respective methods which in
 * turn invokes the respective service classes.
 * 
 * @author Cognizant
 * @version last updated : Feb 2, 2012
 * @see
 * 
 */
@Controller
public class SCoTsServiceHttpEndpoint {

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SCoTsServiceHttpEndpoint.class);

	@Autowired
	private SCoTsService scotsService;

	/**
	 * 
	 * The method will retrieve the SCoTS data for all the tables given as
	 * parameter from the Staging SoR. The input will be list of Code Table IDs
	 * and the user preferred language. The return will be a map with key as
	 * Code table ID and value as list of CodeValue. The method is invoked to
	 * populate the following drop downs in Add Geo Unit UI: - Geo Unit Type -
	 * Name Type - Language - Data Provider - Code Type
	 * 
	 * @param codeTableIds
	 * @param langaugeCode
	 * @return
	 */
	@RequestMapping(value = "/{languageCode}/retrieveCodeValues.service", method = RequestMethod.POST)
	public @ResponseBody
	Map<Long, List<CodeValue>> retrieveCodeValues(
			@RequestBody List<Long> codeTableIds,
			@PathVariable("languageCode") Long languageCode) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCodeValues");

		LOGGER.info("codeTableIds : " + codeTableIds);
		LOGGER.info("languageCode : " + languageCode);

		Map<Long, List<CodeValue>> codeValueMap = scotsService
				.retrieveCodeValues(codeTableIds, languageCode);

		LOGGER.info("exiting SCoTsServiceHttpEndpoint | retrieveCodeValues");
		return codeValueMap;
	}
	@RequestMapping(value = "/{languageCode}/retrieveCodeValuesScores.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveCodeValuesScores(
			@RequestBody List<Long> codeTableIds,
			@PathVariable("languageCode") Long languageCode) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCodeValues");

		LOGGER.info("codeTableIds : " + codeTableIds);
		LOGGER.info("languageCode : " + languageCode);

		List<CodeValue> codeValueMap = scotsService
				.retrieveCodeValuesScores(codeTableIds, languageCode);

		LOGGER.info("exiting SCoTsServiceHttpEndpoint | retrieveCodeValues");
		return codeValueMap;
	}
	@RequestMapping(value = "/retrieveMktGrpCodes.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveMktGrpCodes() {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveMktGrpCodes");

		//LOGGER.info("codeTableIds : " + codeTableIds);
		//LOGGER.info("languageCode : " + languageCode);

		List<CodeValue> codeValueMap = scotsService.retrieveMktGrpCodes();

		LOGGER.info("exiting SCoTsServiceHttpEndpoint | retrieveMktGrpCodes");
		return codeValueMap;
	}
	@RequestMapping(value = "/{languageCode}/retrieveCodeValuesScr.service", method = RequestMethod.POST)
	public @ResponseBody
	Map<Long, List<CodeValue>> retrieveCodeValuesScr(
			@RequestBody List<Long> codeTableIds,
			@PathVariable("languageCode") Long languageCode) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCodeValues");

		LOGGER.info("codeTableIds : " + codeTableIds);
		LOGGER.info("languageCode : " + languageCode);

		Map<Long, List<CodeValue>> codeValueMap = scotsService
				.retrieveCodeValuesScr(codeTableIds, languageCode);

		LOGGER.info("exiting SCoTsServiceHttpEndpoint | retrieveCodeValues");
		return codeValueMap;
	}
	/**
	 * 
	 * The method will perform the table search of SCoTS Code Tables on the
	 * search db.
	 * <p>
	 * 
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 * <p>
	 * 
	 * @param SCoTSSearchCriteriaVO
	 * @return list of CodeValue
	 */
	@RequestMapping(value = "/searchCodeTables.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeTable> searchCodeTables(
			@RequestBody SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | searchCodeTables");
		return scotsService.searchCodeTables(searchCriteriaVO);
	}

	/**
	 * 
	 * The method will count the records in the hierarchy search of code tables
	 * on the search db. The search will be done on the flat db based on the
	 * search criteria the user had provided.
	 * 
	 * @param searchCriteriaVO
	 * @return count of search results
	 */
	@RequestMapping(value = "/countSearchCodeTables.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countSearchCodeTables(
			@RequestBody SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | countSearchCodeTables");
		return scotsService.countSearchCodeTables(searchCriteriaVO);
	}

	/**
	 * 
	 * The method will retrieve all Code Tables
	 * 
	 * @return CodeValueVO List
	 */
	@RequestMapping(value = "/retrieveCodeTableList.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveCodeTabeList() {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCodeTableList");
		return scotsService.retrieveCodeTableList();
	}

	/**
	 * 
	 * The method will retrieve all Code Languages
	 * 
	 * @return CodeValueVO List
	 */
	@RequestMapping(value = "/retrieveCodeLanguages.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveCodeLanguages() {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCodeLnaguages");
		return scotsService.retrieveCodeLanguages();
	}

	/**
	 * 
	 * The method will retrieve all applicable systems
	 * 
	 * @return CodeValueVO List
	 */
	@RequestMapping(value = "/{codeTableId}/{applicabilityIndicator}/retrieveSystemApplicability.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<SystemApplicability> retrieveSystemApplicability(
			@PathVariable("codeTableId") Long codeTableId,
			@PathVariable("applicabilityIndicator") int applicabilityIndicator) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveSystemApplicability");
		List<SystemApplicability> codeValueVOs = scotsService
				.retrieveSystemApplicability(codeTableId, applicabilityIndicator);

		LOGGER.info("exiting SCoTsServiceHttpEndpoint | retrieveSystemApplicability");
		return codeValueVOs;
	}

	/**
	 * 
	 * The method will retrieve all applicable systems
	 * 
	 * @return CodeValueVO List
	 */
	@RequestMapping(value = "/{applicability}/retrieveAllSystemApplicability.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveAllSystemApplicability(
			@PathVariable("applicability") String applicability) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveAllSystemApplicability");
		List<CodeValueVO> codeValueVOs = scotsService
				.retrieveAllSystemApplicability(applicability);
		LOGGER.info("exiting SCoTsServiceHttpEndpoint | retrieveAllSystemApplicability");
		return codeValueVOs;
	}

	/**
	 * 
	 * The method will retrieve all applicable countries
	 * 
	 * @return CodeValueVO List
	 */
	@RequestMapping(value = "/{codeTableId}/{applicabilityIndicator}/retrieveCountryApplicability.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CountryApplicability> retrieveCountryApplicability(
			@PathVariable("codeTableId") Long codeTableId,
			@PathVariable("applicabilityIndicator") int applicabilityIndicator) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCountryApplicability");
		List<CountryApplicability> codeValueVOs = scotsService
				.retrieveCountryApplicability(codeTableId,applicabilityIndicator);

		LOGGER.info("exiting SCoTsServiceHttpEndpoint | retrieveCountryApplicability");
		return codeValueVOs;
	}

	/**
	 * 
	 * The method to find the CodeTable entity by the primary key codeTableId
	 * 
	 * @param codeTableId
	 * @return CodeTable entity
	 */
	@RequestMapping(value = "/{codeTableId}/retrieveCodeTableById.service",headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	CodeTable retrieveCodeTableById(@PathVariable("codeTableId") Long codeTableId) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCodeTableById || codeTableId: " + codeTableId);
		return scotsService.retrieveCodeTableById(codeTableId);

	}

	/**
	 * 
	 * The method to find the CodeTable entity by the primary key codeTableId
	 * 
	 * @param codeTableId
	 * @return CodeTable entity
	 */
	@RequestMapping(value = "/{codeTableId}/reviewCodeTableChanges.service",headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	CodeTable reviewCodeTableChanges(@PathVariable("codeTableId") Long codeTableId) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | reviewCodeTableChanges || codeTableId: " + codeTableId);
		return scotsService.reviewCodeTableChanges(codeTableId);

	}
	/**
	 * 
	 * The method to find the CodeTable entity by the primary key codeValueId
	 * 
	 * @param codeValueId
	 * @return codeValue entity
	 */
	@RequestMapping(value = "/{codeValueId}/reviewCodeValueChanges.service",headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	CodeValue reviewCodeValueChanges(@PathVariable("codeValueId") Long codeValueId) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | reviewCodeValueChanges || codeValueId: " + codeValueId);
		return scotsService.reviewCodeValueChanges(codeValueId);

	}

	/**
	 * 
	 * The method to fetch the details of codeValues based on the codeTableId.
	 * The filter will also contain the language code, system applicability code
	 * and country applicability code.
	 * 
	 * @param searchCriteriaVO
	 * @return list of codeValues
	 */
	@RequestMapping(value = "/retrieveCodeValuesByTableId.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> retrieveCodeValuesByTableId(
			@RequestBody SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCodeValuesByTableId");
		return scotsService.retrieveCodeValuesByTableId(searchCriteriaVO);
	}

	/**
	 * 
	 * The method to count the results of codeValues based on the codeTableId.
	 * The filter will also contain the language code, system applicability code
	 * and country applicability code.
	 * 
	 * @param searchCriteriaVO
	 * @return count of codeValues
	 */
	@RequestMapping(value = "/countCodeValuesByTableId.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countCodeValuesByTableId(
			@RequestBody SCoTSSearchCriteriaVO searchCriteriaVO) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | countCodeValuesByTableId");
		return scotsService.countCodeValuesByTableId(searchCriteriaVO);
	}

	/**
	 * 
	 * The method to fetch the Code Value details based on the filter condition.
	 * The Code Value will be searched based on description or on the business
	 * description.
	 * 
	 * @param searchCriteriaVO
	 * @return codeValues
	 */
	@RequestMapping(value = "/searchCodeValues.service", method = RequestMethod.POST)
	public @ResponseBody
	List<CodeValue> searchCodeValues(
			@RequestBody SCoTSSearchCriteriaVO searchCriteriaVO) {
		return scotsService.searchCodeValues(searchCriteriaVO);
	}

	/**
	 * 
	 * The method to fetch the count of Code Value details based on the filter
	 * condition. The Code Value will be searched based on description or on the
	 * business description.
	 * 
	 * @param searchCriteriaVO
	 * @return countCodeValues
	 */
	@RequestMapping(value = "/countOfSearchCodeValues.service", method = RequestMethod.POST)
	public @ResponseBody
	Long countOfSearchCodeValues(
			@RequestBody SCoTSSearchCriteriaVO searchCriteriaVO) {
		return scotsService.countOfSearchCodeValues(searchCriteriaVO);
	}

	/**
	 * Fetches the CodeValueText entity by codeValueId.<p>
	 * 
	 * @param codeValueId
	 * @return CodeValueText
	 */
	@RequestMapping(value = "/{codeValueId}/retrieveCodeValueByCodeValueId.service",headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	CodeValue retrieveCodeValueByCodeValueId(@PathVariable("codeValueId") Long codeValueId) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCodeValueByCodeValueId || codeValueId: " + codeValueId);
		CodeValue codeValue = scotsService.retrieveCodeValueByCodeValueId(codeValueId);
		if(codeValue != null){
			codeValue.setParentCodeValueAssociations(
					scotsService.retrieveParentCodeValueAssociations(codeValue.getCodeValueId()));
			codeValue.setChildCodeValueAssociations(
					scotsService.retrieveChildCodeValueAssociations(codeValue.getCodeValueId()));
		}
		LOGGER.info("exiting SCoTsServiceHttpEndpoint | retrieveCodeValueByCodeValueId || codeValue: " + codeValue);
		return codeValue;

	}

	/**
	 * 
	 * The method to retrieve all codeValue associations from database. The
	 * method will accept the parent and child code table Id s and will return
	 * all associations having the relationship between the specified parent and
	 * child code tables.
	 * 
	 * @param parentCodeTableId
	 * @param childCodeTableId
	 * @return List<CodeValueAssociation>
	 */
	@RequestMapping(value = "/{parentCodeTableId}/{childCodeTableId}/{isStagingDB}/retrieveCodeValueAssociations.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueAssociation> retrieveCodeValueAssociations(
			@PathVariable("parentCodeTableId") Long parentCodeTableId,
			@PathVariable("childCodeTableId") Long childCodeTableId,
			@PathVariable("isStagingDB") Boolean isStagingDB
			) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCodeValueAssociations");		
		return scotsService.retrieveCodeValueAssociations(parentCodeTableId, childCodeTableId, isStagingDB);	
	}

	/**
	 * 
	 * The method to retrieve all alternate schema code types from the database.
	 * The method will be invoked as a web-service to retrieve the data.
	 * 
	 * @return List<CodeValueVO>
	 */
	@RequestMapping(value = "/retrieveAllAlternateSchemeCodes.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueVO> retrieveAllAlternateSchemeCodes() {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveAllAlternateSchemeCodes");
		return scotsService.retrieveAllAlternateSchemeCodes();
	}
	/**
	 * 
	 * The method will retrieve all applicable systems
	 * 
	 * @return SystemApplicability List
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/{applicability}/{applicabilityCode}/{isStagingDB}/retrieveSystemForCode.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List retrieveSystemForCode(
			@PathVariable("applicability") String applicability,
			@PathVariable("applicabilityCode") Long applicabilityCode,
			@PathVariable("isStagingDB") Boolean isStagingDB) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveSystemForCode");
		return scotsService
				.retrieveSystemForCode(applicability, applicabilityCode, isStagingDB);
	}


	/**
	 * 
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the staging
	 * DB to fetch all alternate scheme codes matching the scheme type code
	 * selected by the user.
	 * 
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	@RequestMapping(value = "/{schemeTypeCode}/retrieveAlternateSchemeCodes.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueAlternateScheme> retrieveAlternateSchemeCodes(
			@PathVariable("schemeTypeCode") Long schemeTypeCode) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveAlternateSchemeCodes");		
		return scotsService.retrieveAlternateSchemeCodes(schemeTypeCode);	
	}

	/**
	 * 
	 * The method to retrieve all alternate scheme codes based on the scheme
	 * type code filter condition. The search will be performed on the transaction
	 * DB to fetch all alternate scheme codes matching the scheme type code
	 * selected by the user.
	 * 
	 * @param schemeTypeCode
	 * @return List<CodeValueAlternateScheme>
	 */
	@RequestMapping(value = "/{schemeTypeCode}/reviewAlternateSchemeCodeChangess.service", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValueAlternateScheme> reviewAlternateSchemeCodeChanges(
			@PathVariable("schemeTypeCode") Long schemeTypeCode) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | reviewAlternateSchemeCodeChanges");		
		return scotsService.reviewAlternateSchemeCodeChanges(schemeTypeCode);	
	}

	/**
	 * The method will persist the existing Code Table data in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param codeTable
	 */
	@RequestMapping(value = "/updateCodeTable.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateCodeTable(@RequestBody CodeTable codeTable) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | updateCodeTable");
		return scotsService.updateCodeTable(codeTable);
	}

	/**
	 * The method will persist the existing codeValue data in the
	 * Transaction DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param codeValue
	 */
	@RequestMapping(value = "/updateCodeValue.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateCodeValue(@RequestBody CodeValue codeValue) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | updateCodeValue");		
		Long codeValueId = scotsService.updateCodeValue(codeValue);
		LOGGER.info("exiting SCoTsServiceHttpEndpoint | updateCodeValue | " + codeValueId);
		return codeValueId;
	}

	/**
	 * 
	 * The method will validate the Code Table for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transaction DB.
	 * 
	 * @param codeTableId
	 * @return
	 */
	@RequestMapping(value = "/{codeTableId}/lockCodeTable.service", method = RequestMethod.GET)
	public @ResponseBody
	String lockCodeTable(@PathVariable("codeTableId") Long codeTableId) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | lockCodeTable");
		return scotsService.lockCodeTable(codeTableId);
	}



	/**
	 * 
	 * The method will validate the  Alternate Scheme Codes for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param codeValueId
	 * @return
	 */
	@RequestMapping(value = "/{alternateSchemeTypeCode}/lockAltSchemeCode.service", method = RequestMethod.GET)
	public @ResponseBody
	String lockAltSchemeCode(@PathVariable("alternateSchemeTypeCode") Long alternateSchemeTypeCode) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | lockAltSchemeCode");
		return scotsService.lockAltSchemeCode(alternateSchemeTypeCode);
	}

	/**
	 * 
	 * The method will validate the CodeValue for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transactional DB.
	 * 
	 * @param codeValueId
	 * @return
	 */
	@RequestMapping(value = "/{codeValueId}/lockCodeValue.service", method = RequestMethod.GET)
	public @ResponseBody
	String lockCodeValue(@PathVariable("codeValueId") Long codeValueId) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | codeValueId");
		return scotsService.lockCodeValue(codeValueId);
	}

	/**
	 *
	 * The method to find the CountryApplicability entity by the codeTable
	 * @param codeValueDescription
	 * @return CountryApplicability entity
	 */
	@RequestMapping(value = "/{codeValueDescription}/retrieveCountryByCodeTable.service", method = RequestMethod.GET)
	public @ResponseBody
	CountryApplicability retrieveCountryByCodeTable(@PathVariable("codeValueDescription") String codeValueDescription) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveCountryByCodeTable || codeValueDescription: " + codeValueDescription);
		return scotsService.retrieveCountryByCodeTable(codeValueDescription);

	}

	@RequestMapping(value = "/{isSystemApplicability}/updateApplicability.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateApplicability(
			@RequestBody CodeTable codeTable, 
			@PathVariable("isSystemApplicability") Boolean isSystemApplicability) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | updateApplicability");
		return scotsService.updateApplicability(codeTable, isSystemApplicability);
	}

	/**
	 * The method will persist the edited Code Value association in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param currencyExchange
	 */
	@RequestMapping(value = "/updateCodeValueAssociation.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateCodeValueAssociation(@RequestBody SCoTSSearchCriteriaVO sCoTSSearchCriteriaVO) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | updateCodeValueAssociation");
		return scotsService.updateCodeValueAssociation(sCoTSSearchCriteriaVO);
	}
	/**
	 * The method will persist the edited Code Value Alternate Scheme in the
	 * Transactional DB. Only the changed relational data will be inserted. The
	 * service method need to perform validation to identify the records which
	 * have been updated from the UI.
	 * 
	 * @param currencyExchange
	 */
	@RequestMapping(value = "/updateCodeValueAlternateScheme.service", method = RequestMethod.POST)
	public @ResponseBody
	Long updateCodeValueAlternateScheme(@RequestBody SCoTSSearchCriteriaVO sCoTSSearchCriteriaVO) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | updateCodeValueAlternateScheme");
		return scotsService.updateCodeValueAlternateScheme(sCoTSSearchCriteriaVO);
	}

	/**
	 * 
	 * The method to retrieve all valid industry code group levels
	 *
	 * @return validIndustryCodeGroupLevels
	 */
	@RequestMapping(value = "/retrieveValidIndustryCodeGroupLevels.service", method = RequestMethod.GET)
	public @ResponseBody
	List<CodeValue> retrieveValidIndustryCodeGroupLevels() {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveValidIndustryCodeGroupLevels");
		return scotsService.retrieveValidIndustryCodeGroupLevels();
	}

	/**
	 * If applicability is "System", value of dnbSystemCode will be dnbSystemCode
	 * in sys_appy table. If it is "Market", value of dnbSystemCode will be 
	 * ctry_geo_unit_id in ctry_appy table. This method checks if the applicability 
	 * with given dnbSystemCode is already present in transactional db. If it exists, 
	 * the return map will contain isLocked=true and username=modifiedUser. Else the 
	 * map will contain isLocked=false and username="".
	 * 
	 * @param dnbSystemCode
	 * @param applicability
	 * @return map
	 */
	@RequestMapping(value = "/{dnbSystemCode}/{applicability}/lockApplicabilityForEdit.service", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> lockApplicabilityForEdit(@PathVariable("dnbSystemCode") Long dnbSystemCode,
			@PathVariable("applicability") String applicability){
		LOGGER.info("entering SCoTsServiceHttpEndpoint | lockApplicabilityForEdit");
		return scotsService.lockApplicabilityForEdit(dnbSystemCode, applicability);
	}

	@RequestMapping(value = "/{domainName}/retrieveSavedRecordByDomainName.service", method = RequestMethod.GET)
	public @ResponseBody
	Map<String,List<SavedRecord>> retrieveSavedRecordByDomainName(@PathVariable("domainName") String domainName) throws ParseException{
		LOGGER.info("entering SCoTsServiceHttpEndpoint | retrieveSavedRecordByDomainName");
		return scotsService.retrieveSavedRecordsByDomainName(domainName);
	}

	/** Implemented to fix 209048785 -Edit SCoTS Approval Page**/

	@RequestMapping(value = "/{reasonText}/{businessDescription}/{cdvalid}/{ApproverId}/update.service", method = RequestMethod.GET)
	public @ResponseBody Boolean update (@PathVariable("reasonText") String reasonText,
			@PathVariable("businessDescription") String businessDescription,@PathVariable("cdvalid") Long cdvalid,@PathVariable("ApproverId") String ApproverId )

	{
		LOGGER.info("entering SCoTsServiceHttpEndpoint | update");
		scotsService.update(reasonText,businessDescription,cdvalid,ApproverId);
		return true;


	}
	/**
	 * 
	 * The method will validate the Scots Relation for any locks (If already been
	 * opened by any other user for edit). If no lock is currently available
	 * then the method will lock the record and return FALSE indicating no lock
	 * currently. But if a lock already exists, the method will return TRUE. The
	 * lock operation will be performed in the Transaction DB.
	 * 
	 * @param parentCodeTableId
	 * @param childCodeTableId
	 * @return lock status
	 */
	@RequestMapping(value = "/{parentCodeTableId}/{childCodeTableId}/lockCodeRelationship.service", method = RequestMethod.GET)
	public @ResponseBody
	String lockCodeRelationship(@PathVariable("parentCodeTableId") Long parentCodeTableId,
			@PathVariable("childCodeTableId") Long childCodeTableId) {
		LOGGER.info("entering SCoTsServiceHttpEndpoint | lockCodeRelationship");
		return scotsService.lockCodeRelationship(parentCodeTableId,childCodeTableId);
	}

}
