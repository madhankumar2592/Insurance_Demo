package com.dnb.dsc.refdata.service.impl;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.IndustryCodesSearchCriteriaVO;
import com.dnb.dsc.refdata.service.IndustryCodeService;

/**
 * This is the test class for services interface for the Industry Code
 * operations
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-service-test.xml" })
public class IndustryCodesServiceTest {

	@Autowired
	private IndustryCodeService industryCodeService;
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(IndustryCodesServiceTest.class);

	/**
	 *
	 * Performs a hierarchy search of Industry Codes on the search db.
	 */
	@Test
	public void testSearchIndustryCodes() {
		LOGGER.info("entering IndustryCodesServiceTest | testSearchIndustryCodes");

		IndustryCodesSearchCriteriaVO industryCodesSearchCriteria = new IndustryCodesSearchCriteriaVO();
		industryCodesSearchCriteria.setSortOrder("asc");
		industryCodesSearchCriteria.setSortBy("1");
		industryCodesSearchCriteria.setMaxResults(10);
		industryCodesSearchCriteria.setRowIndex(1);
		industryCodesSearchCriteria.setIndustryCodeTypeCode("3844");

		List<IndustryCode> indsCodesList = industryCodeService
				.searchIndustryCodes(industryCodesSearchCriteria);
		Assert.assertEquals(10, indsCodesList.size());

	}

	/**
	 * The method will retrieve Industry code CrossWalks for the selected
	 * industry code type.
	 */
	@Test
	public void testRetrieveCrossWalksForIndsCodeType() {
		LOGGER.info("entering IndustryCodesServiceTest | testRetrieveCrossWalksForIndsCodeType");

		Long industryCodeTypeCode = 3844L;
		List<CodeValueVO> crossWalksList = industryCodeService
				.retrieveCrossWalksForIndsCodeType(industryCodeTypeCode);
		Assert.assertEquals(1, crossWalksList.size());
	}

	/**
	 * The method will retrieve description for Industry code and type code.
	 */
	@Test
	public void testRetrieveDescriptionForIndsCodeTypeCode() {
		LOGGER.info("entering IndustryCodesServiceTest | testRetrieveDescriptionForIndsCodeTypeCode");

		Long industryCodeTypeCode = 1016L;
		String industryCode = "0139";
		String descriptionResult = industryCodeService
				.retrieveDescriptionForIndsCodeTypeCode(industryCodeTypeCode,
						industryCode);
		Assert.assertNotNull(descriptionResult);
	}

	/**
	 * This method will test if industry code id is retrieved by passing
	 * industry code type code
	 */
	@Test
	public void testRetrieveIndustryCodeIdByCodeTypeCode() {
		LOGGER.info("entering IndustryCodesServiceTest | testRetrieveIndustryCodeIdByCodeTypeCode");

		Long industryCodeTypeCode = 700L;
		String industryCode = "5418";
		Long descriptionResult = industryCodeService
				.retrieveIndustryCodeIdByCodeTypeCode(industryCodeTypeCode,
						industryCode);
		Assert.assertEquals(50032270L, descriptionResult.longValue());

	}

	/**
	 * The method will retrieve Industry code Group Levels for the selected
	 * industry code type.
	 */
	@Test
	public void testRetrieveGroupLevelCodes() {
		LOGGER.info("entering IndustryCodesServiceTest | testRetrieveIndustryCodeIdByCodeTypeCode");

		Long industryCodeTypeCode = 3599L;
		List<CodeValueVO> groupLevelList = industryCodeService
				.retrieveGroupLevelCodes(industryCodeTypeCode,39L);
		Assert.assertEquals(5, groupLevelList.size());
	}

	/**
	 *
	 * The method will count the records in the hierarchy search of industry
	 * codes on the search db. The search will be done on the flat db based on
	 * the search criteria the user had provided.
	 */
	@Test
	public void testCountSearchIndustryCodes() {
		LOGGER.info("entering IndustryCodesServiceTest | testCountSearchIndustryCodes");

		IndustryCodesSearchCriteriaVO industryCodesSearchCriteria = new IndustryCodesSearchCriteriaVO();
		industryCodesSearchCriteria.setSortOrder("asc");
		industryCodesSearchCriteria.setSortBy("1");
		industryCodesSearchCriteria.setMaxResults(10);
		industryCodesSearchCriteria.setRowIndex(1);
		industryCodesSearchCriteria.setIndustryCodeTypeCode("3844");

		Long countResults = industryCodeService
				.countSearchIndustryCodes(industryCodesSearchCriteria);
		Assert.assertNotNull(countResults);
	}

	/**
	 * This test method will search the Staging SoR for the IndustryCode based
	 * on the IndustryCodeId and will return the IndustryCode entity.
	 */
	@Test
	public void testRetrieveIndustryCodeByIndustryCodeId() {
		LOGGER.info("entering IndustryCodesServiceTest | testRetrieveIndustryCodeByIndustryCodeId");

		Long industryCodeId = 50030469L;
		IndustryCode industryCodeResult = industryCodeService
				.retrieveIndustryCodeByIndustryCodeId(industryCodeId);
		Assert.assertEquals("1112", industryCodeResult.getIndustryCode());
	}

	/**
	 * The method will test if the existing IndustryCode data is being persisted
	 * in the Transactional DB
	 */
	@Test
	public void testUpdateIndustryCode() {
		IndustryCode industryCodeResult = industryCodeService
				.retrieveIndustryCodeByIndustryCodeId(3529L);
		Long workflowTrackingId = industryCodeService
				.updateIndustryCode(industryCodeResult);
		Assert.assertNotNull(workflowTrackingId);
	}

	/**
	 * The method will test if the existing IndustryCode data is being persisted
	 * in the Transactional DB for a null valued industry code id
	 */
	@Test
	public void testUpdateIndustryCodeForNull() {
		IndustryCode industryCodeResult = industryCodeService
				.retrieveIndustryCodeByIndustryCodeId(3529L);
		industryCodeResult.setIndustryCodeId(-1L);
		Long workflowTrackingId = industryCodeService
				.updateIndustryCode(industryCodeResult);
		Assert.assertNotNull(workflowTrackingId);
	}

	/**
	 * This method will test if the Industry Code languages are being retrieved
	 * based on the industry code type code and the group level codes entered
	 */
	@Test
	public void testRetrieveIndustryCodeLanguages() {

		Long industryCodeTypeCode = 700L;
		List<Long> groupLevelCodes = new ArrayList<Long>();
		List<CodeValueVO> codeLanguagesResult = industryCodeService
				.retrieveIndustryCodeLanguages(industryCodeTypeCode,
						groupLevelCodes);
		Assert.assertEquals(3, codeLanguagesResult.size());
	}

	/**
	 *
	 * The method to test the lock on industry code record for edit
	 */
	@Test
	public void testLockIndustryCode() {
		Long industryCodeId = 51000010L;
		String lockResult = industryCodeService
				.lockIndustryCode(industryCodeId);
		Assert.assertEquals("false", lockResult);
	}
}
