/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.service.impl;

import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dnb.dsc.refdata.core.entity.XmlSchemaElement;
import com.dnb.dsc.refdata.core.vo.XmlSchemaSearchVO;
import com.dnb.dsc.refdata.service.XmlSchemaLabelService;

/**
 * TODO
 * 
 * @author Cognizant
 * @version last updated : Apr 20, 2012
 * @see
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-service-test.xml" })
public class XmlSchemaLabelServiceTest {

    /**
     * The instance variable for Logging
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(XmlSchemaLabelServiceTest.class);

    @Autowired
    private XmlSchemaLabelService xmlSchemaLabelService;

    /**
     * The test method will search for the xml labels matching the elementname/description.
     * The user will pass the input criteria to the service layer and dao will return 
     * the xml element details
     * 
     */
    @Test
    public void testSearchXmLSchemaLabels() {
        LOGGER.info("entering XmlSchemaLabelServiceTest | testSearchXmLSchemaLabels");
        XmlSchemaSearchVO xmlSchemaSearchVO = new XmlSchemaSearchVO();
        xmlSchemaSearchVO.setElementName("Actual");
        xmlSchemaSearchVO.setElementDescription("Actual");
        xmlSchemaSearchVO.setSortBy("xmlSchemaElementId");
        xmlSchemaSearchVO.setSortOrder("asc");
        xmlSchemaSearchVO.setStartIndex(0);
        xmlSchemaSearchVO.setMaxResults(10);

        List<XmlSchemaElement> xmlElement = xmlSchemaLabelService.searchXmLSchemaLabels(xmlSchemaSearchVO);
        Assert.assertEquals(10, xmlElement.size());
    }
    
    /**
     * The test method will search for the xml elements by xml element id.The user will pass the 
     * element id to the service layer and dao will return the corresponding xml element details
     *
     */
    @Test
    public void testRetrieveXmlSchemaByXmlElementId(){
        XmlSchemaElement xmlSchemaElement=xmlSchemaLabelService.retrieveXmlSchemaByXmlElementId("Element_Common_1588");
        Assert.assertEquals("Element_Common_1588", xmlSchemaElement.getXmlSchemaElementId());
    }
    
    /**
     * The test method will search for the xml labels matching the elementname/description.
     * The user will pass the input criteria to the service layer and dao will return 
     * the xml element details
     * 
     */
    @Test
    public void testCountSearchXmLSchemaLabels() {
        LOGGER.info("entering XmlSchemaLabelServiceTest | testSearchXmLSchemaLabels");
        XmlSchemaSearchVO xmlSchemaSearchVO = new XmlSchemaSearchVO();
        xmlSchemaSearchVO.setElementName("Actual");
        xmlSchemaSearchVO.setElementDescription("Actual");
        xmlSchemaSearchVO.setSortBy("xmlSchemaElementId");
        xmlSchemaSearchVO.setSortOrder("asc");
        xmlSchemaSearchVO.setStartIndex(0);
        xmlSchemaSearchVO.setMaxResults(10);

        Long xmlElement = xmlSchemaLabelService.countSearchXmLSchemaLabels(xmlSchemaSearchVO);
        Assert.assertEquals(91, xmlElement.longValue());
    }

}
