package com.dnb.dsc.refdata.service.impl;

import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dnb.dsc.refdata.core.entity.CodeTable;
import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.SCoTSSearchCriteriaVO;
import com.dnb.dsc.refdata.service.SCoTsService;

/**
 * This is the test class for services interface for the Currency operations
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-service-test.xml" })
public class SCoTSServiceTest {

	@Autowired
	private SCoTsService scotsService;
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SCoTSServiceTest.class);

	/**
	 * The test method to retrieve Code Values for a list of code table ids

   @Test
	public void testRetrieveCodeValues() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeValues");
		List<Long> codeTableIds = new ArrayList<Long>();
		codeTableIds.add(3L);
		codeTableIds.add(4L);
		Map<Long, List<CodeValue>> resultMap = scotsService.retrieveCodeValues(
				codeTableIds, 39L);
		Assert.assertEquals(2,resultMap.size());
	}*/

   /**
	 * The test method to search code table based on any searc criteria
	 */
	@Test
	public void testSearchCodeTables() {
		LOGGER.debug("entering SCoTSServiceTest || testSearchCodeTables");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setTableDescription("language");

		List<CodeTable> searchCodeTables=scotsService.searchCodeTables(searchCriteriaVO);

		Assert.assertEquals(1, searchCodeTables.size());
	}

	/**
	 * The test method to count the number of search results
	 */
	@Test
	public void testCountSearchCodeTables() {
		LOGGER.debug("entering SCoTSServiceTest || testCountSearchCodeTables");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setTableDescription("language");

		Long countSearchCodeTables=scotsService.countSearchCodeTables(searchCriteriaVO);

		Assert.assertEquals(2, countSearchCodeTables.longValue());
	}


	/**
	 * The test method to retrieve list of all code tables
	 */
	@Test
	public void testRetrieveCodeTableList() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeTableList");
		List<CodeValueVO> retrieveCodeTableList=scotsService.retrieveCodeTableList();
		Assert.assertEquals(633, retrieveCodeTableList.size());
	}


	/**
	 * The test method to retrieve Code languages
	 */
	@Test
	public void testRetrieveCodeLanguages() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeLanguages");
		List<CodeValueVO> retrieveCodeLanguages=scotsService.retrieveCodeLanguages();
		Assert.assertEquals(7, retrieveCodeLanguages.size());
	}

	/**
	 * The test method to retrieve system applicability for a code table
	 */
	@Test
	public void testRetrieveSystemApplicability() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveSystemApplicability");
		List<SystemApplicability> retrieveSystemApplicability=scotsService.retrieveSystemApplicability(3L,1);
		Assert.assertEquals(1, retrieveSystemApplicability.size());
	}


	/**
	 * The test method to retrieve all system applicabilities
	 */
	@Test
	public void testRetrieveAllSystemApplicability() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveAllSystemApplicability");
		List<CodeValueVO> retrieveAllSystemApplicability=scotsService.retrieveAllSystemApplicability("System");
		Assert.assertEquals(59, retrieveAllSystemApplicability.size());
	}


	/**
	 * The test method to retrieve country applicability
	 */
	@Test
	public void testRetrieveCountryApplicability() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCountryApplicability");
		List<CountryApplicability> retrieveCountryApplicability =scotsService.retrieveCountryApplicability(3L,1);
		Assert.assertEquals(2, retrieveCountryApplicability.size());
	}


	/**
	 * The test method to retrieve code table by id
	 */
	@Test
	public void testRetrieveCodeTableById() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeTableById");
		CodeTable retrieveCodeTableById=scotsService.retrieveCodeTableById(3L);
		Assert.assertEquals(3, retrieveCodeTableById.getCodeTableId().longValue());
	}

	/**
	 * The test method to retrieve code table by id
	 */
	@Test
	public void testReviewCodeTableChanges() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeTableById");
		Long domainId = scotsService.retrieveFirstCodeTableId();
		CodeTable retrieveCodeTableById=scotsService.reviewCodeTableChanges(domainId);
		Assert.assertEquals(domainId, retrieveCodeTableById.getCodeTableId());
	}

	/**
	 * The test method to retrieve code table by id
	 */
	@Test
	public void testReviewCodeValueChanges() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeTableById");
		scotsService.reviewCodeValueChanges(11L);
	}

	/**
	 * The test method to retrieve code values by table id
	 */
	@Test
	public void testRetrieveCodeValuesByTableId(){
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeValuesByTableId");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setTableDescription("3");
		List<CodeValue> retrieveCodeValuesByTableId=scotsService.retrieveCodeValuesByTableId(searchCriteriaVO);
		Assert.assertEquals(10, retrieveCodeValuesByTableId.size());

	}


	/**
	 * The test method to count results of retrieving code value by table id
	 */
	@Test
	public void testCountCodeValuesByTableId() {
		LOGGER.debug("entering SCoTSServiceTest || testCountCodeValuesByTableId");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setTableDescription("3");

		Long countCodeValuesByTableId=scotsService.countCodeValuesByTableId(searchCriteriaVO);
		Assert.assertEquals(559, countCodeValuesByTableId.longValue());
	}


	/**
	 * The test method to search code values
	 */
	@Test
	public void testSearchCodeValues() {
		LOGGER.debug("entering SCoTSServiceTest || testSearchCodeValues");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setCodeValueDescription("English");
		List<CodeValue> searchCodeValues=scotsService.searchCodeValues(searchCriteriaVO);
		Assert.assertEquals(10, searchCodeValues.size());
	}


	/**
	 * The test method to count results of search code values
	 */
	@Test
	public void testCountOfSearchCodeValues() {
		LOGGER.debug("entering SCoTSServiceTest || testCountOfSearchCodeValues");
		SCoTSSearchCriteriaVO searchCriteriaVO = new SCoTSSearchCriteriaVO();
		searchCriteriaVO.setSortOrder("asc");
		searchCriteriaVO.setSortBy("1");
		searchCriteriaVO.setMaxResults(10);
		searchCriteriaVO.setRowIndex(1);
		searchCriteriaVO.setCodeValueDescription("English");
		Long searchCodeValues=scotsService.countOfSearchCodeValues(searchCriteriaVO);
		Assert.assertEquals(21, searchCodeValues.longValue());

	}


	/**
	 * The test method to retrieve code value by code value id
	 */
	@Test
	public void testRetrieveCodeValueByCodeValueId() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeValueByCodeValueId");
		Long codeValueId = 39L;
		CodeValue codeValue = scotsService.retrieveCodeValueByCodeValueId(codeValueId);
		Assert.assertEquals(39,codeValue.getCodeValueId().longValue());
	}


	/**
	 * The test method to retrieve code value associations with a parent and child code table
	 */
	@Test
	public void testRetrieveCodeValueAssociations(){
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCodeValueAssociations");
		List<CodeValueAssociation> retrieveCodeValueAssociations=scotsService.retrieveCodeValueAssociations(2L,9L, true);
		Assert.assertEquals(0,retrieveCodeValueAssociations.size());
	}



	/**
	 * The test method to retrieve all alternate scheme codes
	 */
	@Test
	public void testRetrieveAllAlternateSchemeCodes () {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveAllAlternateSchemeCodes");
		List<CodeValueVO> retrieveAllAlternateSchemeCodes=scotsService.retrieveAllAlternateSchemeCodes();
		Assert.assertEquals(8,retrieveAllAlternateSchemeCodes.size());
	}


	/**
	 * The test method to retrieve country by code table
	 */
	@Test
	public void testRetrieveCountryByCodeTable() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveCountryByCodeTable");
		CountryApplicability retrieveCountryByCodeTable=scotsService.retrieveCountryByCodeTable("Japan");
		Assert.assertEquals(122,retrieveCountryByCodeTable.getCtryAppyId().longValue());
	}


	/**
	 * The test method to check for lock on a code value
	 */
	@Test
	public void testLockCodeValue() {
		LOGGER.debug("entering SCoTSServiceTest || testLockCodeValue");
		String count = scotsService.lockCodeValue(39l);
		Assert.assertEquals("false", count);
	}

	/**
	 * The test method to check for lock on a code table
	 */
	@Test
	public void testLockCodeTable() {
		LOGGER.debug("entering SCoTSServiceTest || testLockCodeTable");
		String count = scotsService.lockCodeTable(3l);
		Assert.assertEquals("false", count);
	}

	/**
	 * The test method to check update code table functionality
	 */
	@Test
	public void testUpdateCodeTable() {
		LOGGER.debug("entering SCoTSServiceTest || testUpdateCodeTable");
		CodeTable codeTable=new CodeTable();
		codeTable.setBusinessDescription("Test");
		codeTable.setCodeTableId(99999L);
		codeTable.setCodeTableName("Test");
		codeTable.setCreatedDate(new Date());
		codeTable.setCreatedUser("refui");
		codeTable.setModifiedDate(new Date());
		codeTable.setModifiedUser("refui");
		codeTable.setEffectiveDate(new Date());
		codeTable.setOnBehalfOfName("refUi");
		codeTable.setReasonText("Not Avalilable");
		Long codeTableReceiver = scotsService.updateCodeTable(codeTable);
		Assert.assertNotNull(codeTableReceiver);
	}


	/**
	 * The test method to retrieve alternate scheme codes
	 */
	@Test
	public void testRetrieveAlternateSchemeCodes() {
		LOGGER.debug("entering SCoTSServiceTest || testRetrieveAlternateSchemeCodes");
		List<CodeValueAlternateScheme> retrieveAlternateSchemeCodes =scotsService.retrieveAlternateSchemeCodes(23404L);
		Assert.assertEquals(196, retrieveAlternateSchemeCodes.size());

	}
	
	/**
	 * This method tests whether approved changes are being entered into the
	 * staging DB
	 */
	@Test
	@Rollback(value = true)
	public void testSaveApprovedChanges() {
		LOGGER.info("entering SCoTSServiceTest | testSaveApprovedChanges");
		Long domainId = scotsService.retrieveFirstCodeTableId();
		Long codeTableIdResult = scotsService
				.saveApprovedCodeTable(domainId);
		Assert.assertEquals(domainId.longValue(), codeTableIdResult.longValue());
	}
	
	/**
	 * This method tests whether approved changes are being removed from the
	 * txn DB
	 */
	@Test
	@Rollback(value = true)
	public void testRemoveApprovedCodeTable() {
		LOGGER.info("entering SCoTSServiceTest | testRemoveApprovedCodeTable");
		Long domainId = 35L;
		scotsService
				.removeApprovedCodeTable(domainId);
		
	}
}
