package com.dnb.dsc.refdata.service.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.CurrencyExchange;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.CurrencySearchCriteriaVO;
import com.dnb.dsc.refdata.service.CurrencyService;

/**
 * This is the test class for services interface for the Currency operations
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-service-test.xml" })
public class CurrencyServiceTest {

	@Autowired
	private CurrencyService currencyService;

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CurrencyServiceTest.class);

	/**
	 *
	 * The method will perform a hierarchy search of Currency Exchange on the
	 * search db.
	 *
	 * The search will be done on the flat db based on the search criteria the
	 * user had provided.
	 */
	@Test
	public void testSearchCurrencyExchange() {

		LOGGER.info("entering CurrencyServiceTest | testSearchCurrencyExchange");

		CurrencySearchCriteriaVO currencySearchCriteria = new CurrencySearchCriteriaVO();
		currencySearchCriteria.setSortOrder("asc");
		currencySearchCriteria.setSortBy("1");
		currencySearchCriteria.setMaxResults(10);
		currencySearchCriteria.setRowIndex(1);
		currencySearchCriteria.setFromCurrencyCode("1");
		currencySearchCriteria.setToCurrencyCode("28");
		currencySearchCriteria.setFromDate(getDateForString("2004-12-15"));
		currencySearchCriteria.setFromDate(getDateForString("2012-12-15"));
		currencySearchCriteria.setDataProviderCode("581");

		List<CurrencyExchange> currencyExchangeResult = currencyService
				.searchCurrencyExchange(currencySearchCriteria);
		Assert.assertEquals(10, currencyExchangeResult.size());
	}

	/**
	 * The method to retrieve all data providers for the currency exchange data.
	 * The data will be fetched from the currency exchange tables.
	 */
	@Test
	public void testRetrieveCurcyExchDataProviders() {

		LOGGER.info("entering CurrencyServiceTest | testRetrieveCurcyExchDataProviders");

		Long languageCode = 39L;
		List<CodeValueVO> retrieveDataProviderList = currencyService
				.retrieveCurcyExchDataProviders(languageCode);
		Assert.assertNotNull(retrieveDataProviderList);
	}

	/**
	 * The method will count the records in the hierarchy search of currency
	 * units on the search db. The search will be done on the flat db based on
	 * the search criteria the user had provided.
	 */
	@Test
	public void testCountSearchCurrencyExchange() {

		LOGGER.info("entering CurrencyServiceTest | testCountSearchCurrencyExchange");

		CurrencySearchCriteriaVO currencySearchCriteria = new CurrencySearchCriteriaVO();
		currencySearchCriteria.setSortOrder("asc");
		currencySearchCriteria.setSortBy("1");
		currencySearchCriteria.setMaxResults(10);
		currencySearchCriteria.setRowIndex(1);
		currencySearchCriteria.setFromCurrencyCode("1");
		currencySearchCriteria.setToCurrencyCode("28");
		currencySearchCriteria.setFromDate(getDateForString("12/15/2004"));
		currencySearchCriteria.setFromDate(getDateForString("12/15/2012"));
		currencySearchCriteria.setDataProviderCode("581");

		Long countCurrencyExchange = currencyService
				.countSearchCurrencyExchange(currencySearchCriteria);

		Assert.assertEquals(169L, countCurrencyExchange.longValue());
	}

	/**
	 * The method to test if currency exchange rate data is persisted in the
	 * Transaction DB.
	 */
	@Test
	public void testUpdateExchangeRate() {
		LOGGER.info("entering CurrencyServiceTest | testUpdateExchangeRate");

		CurrencyExchange currencyExchange = new CurrencyExchange(100176L,
				4550L, 28L, new Date(), 11552L, 0.8765D,
				581L, "DNB", new Date(), "DNB",
				new Date());
		Long workflowTrackingId = currencyService
				.updateExchangeRate(currencyExchange);
		Assert.assertNotNull(workflowTrackingId.longValue());
	}

	/**
	 * This method will test for a lock if a user tries to update an exchange
	 * rate which is already present in the Transaction DB
	 */
	@Test
	public void testLockCurrencyExchange() {
		LOGGER.info("entering CurrencyServiceTest | testLockCurrencyExchange");

		Long currencyExchangeId = 123951L;
		String lockResult = currencyService
				.lockCurrencyExchange(currencyExchangeId);
		Assert.assertEquals("false", lockResult);
	}

	/**
	 * This method tests the functionality to review and approve or reject a
	 * proposed update. The review is done by a business owner.
	 */
	@Test
	public void testReviewCurrencyExchangeChanges() {
		LOGGER.info("entering CurrencyServiceTest | testReviewCurrencyExchangeChanges");

		Long trackingId = 124320L;
		CurrencyExchange reviewCurrencyExchangeChangesResult = currencyService
				.reviewCurrencyExchangeChanges(trackingId);
		Assert.assertEquals(124320L, reviewCurrencyExchangeChangesResult
				.getCurrencyExchangeId().longValue());
	}

	/**
	 * Retrieves the CurrencyExchange based on the Work-flow Tracking Id.
	 * Invoked from the Work-flow Component and the search will be performed on
	 * the Transactional DB.
	 */
	@Test
	public void testRetrieveCurrencyExchangeByTrackingId() {
		LOGGER.info("entering CurrencyServiceTest | testRetrieveCurrencyExchangeByTrackingId");

		Long trackingId = 124320L;
		CurrencyExchange retrieveCurrencyExchangeByTrackingIdResult = currencyService
				.retrieveCurrencyExchangeByTrackingId(trackingId);
		Assert.assertEquals(124320L, retrieveCurrencyExchangeByTrackingIdResult
				.getCurrencyExchangeId().longValue());
	}

	/**
	 * The method will search the Staging SoR for the CurrencyExchange based on
	 * the currencyExchangeId and will return the CurrencyExchange entity
	 */
	@Test
	public void testRetrieveCurrencyExchangeByCurrencyExchangeId() {
		LOGGER.info("entering CurrencyServiceTest | testRetrieveCurrencyExchangeByCurrencyExchangeId");

		Long currencyExchangeId = 100188L;
		CurrencyExchange retrieveCurrencyExchangeByCurrencyExchangeIdResult = currencyService
				.retrieveCurrencyExchangeByCurrencyExchangeId(currencyExchangeId);
		Assert.assertEquals(4479L,
				retrieveCurrencyExchangeByCurrencyExchangeIdResult
						.getFromCurrencyCode().longValue());
	}

	/**
	 * The method to save the Currency Exchange changes to the Staging SoR. The
	 * method will remove the entries from the transaction DB as well.
	 */
	@Test
	@Rollback(value = true)
	public void testSaveApprovedCurrencyExchanges() {
		LOGGER.info("entering CurrencyServiceTest | testSaveApprovedCurrencyExchanges");

		Long trackingId = 124438L;

		Long currencyExchangeIdResult = currencyService
				.saveApprovedCurrencyExchanges(trackingId);
		Assert.assertEquals(124438L, currencyExchangeIdResult.longValue());

	}

	/**
	 * This test tries to remove an existing entry from the Transaction DB.
	 * currencyExchangeId is used to determine which entry is to be removed.
	 */
	@Test
	@Rollback(value = true)
	public void testRemoveApprovedCurrencyExchange() {
		LOGGER.info("entering CurrencyServiceTest | testSaveApprovedCurrencyExchanges");

		Long currencyExchangeId = 7L;
		currencyService.removeApprovedCurrencyExchange(currencyExchangeId);
	}

	/**
	 * method to convert a String object into a Date type object
	 *
	 * @param inputStr
	 * @return
	 */
	private Date getDateForString(String inputStr) {
		if (inputStr == null) {
			return null;
		}
		DateFormat formatter = new SimpleDateFormat(
				RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT);
		try {
			return (Date) formatter.parse(inputStr);
		} catch (ParseException e) {
			return null;
		}
	}
}
