/*
 * Cognizant PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Cognizant Technology Solutions. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.GeoDefaultConfiguration;
import com.dnb.dsc.refdata.core.entity.GeoHierarchy;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.entity.GeographySearch;
import com.dnb.dsc.refdata.core.entity.UserGroupMapping;
import com.dnb.dsc.refdata.core.vo.CodeValueVO;
import com.dnb.dsc.refdata.core.vo.GeoSearchCriteriaVO;
import com.dnb.dsc.refdata.service.GeographyService;

/**
 * This is the test class for services interface for the Geography operations
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:refdata-applicationContext-service-test.xml" })
public class GeographyServiceTest {

	@Autowired
	private GeographyService geographyService;

	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GeographyServiceTest.class);

	/**
	 * The test method will search for the geo units by name. The user will type
	 * in the filter condition in the name field and the dao layer will retrieve
	 * the names satisfying the filter
	 */
	@Test
	public void testSearchGeoUnitByName() {

		LOGGER.info("entering GeographyServiceTest | testSearchGeoUnitByName");
		String nameFilter = "Canada";
		Long langaugeCode = RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH;
		List<GeoUnitName> geoUnitNames = geographyService.searchGeoUnitByName(
				nameFilter, 0, 10, "", "", langaugeCode);
		Assert.assertEquals(10, geoUnitNames.size());
	}

	/**
	 * The method will search for the geo units by code. The user will type in
	 * the filter condition in the code field and the dao layer will retrieve
	 * the codes satisfying the filter
	 */
	@Test
	public void testSearchGeoUnitByCode() {

		LOGGER.info("entering GeographyServiceTest | testSearchGeoUnitByCode");
		String codeFilter = "CA";
		Long langaugeCode = RefDataPropertiesConstants.CODE_LANGUAGE_ENGLISH;
		List<GeoUnitCode> geoUnitCodes = geographyService.searchGeoUnitByCode(
				codeFilter, 0, 10, "", "", langaugeCode);
		Assert.assertEquals(4, geoUnitCodes.size());
	}

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 */
	@Test
	public void testRetrieveGeoUnitByGeoUnitId() {

		LOGGER.info("entering GeographyServiceTest | testRetrieveGeoUnitByGeoUnitId");
		Long geoUnitId = 141545L;
		GeoUnit geoUnit = geographyService
				.retrieveGeoUnitByGeoUnitId(geoUnitId);

		Assert.assertEquals((Long) 141545L, geoUnit.getGeoUnitId());
		Assert.assertEquals((Long) 130L, geoUnit.getGeoUnitTypeCode());

	}

	/**
	 * The method will test the delete operation on the geoUnit. The geoUnit to
	 * be deleted is inserted in the Transactional DB.
	 */
	@Test
	@Rollback(value = true)
	public void testDeleteGeoUnitById() {
		LOGGER.info("entering GeographyServiceTest | testDeleteGeoUnitById");
		Long workflowTrackingId = geographyService.deleteGeoUnitById(999192465L);
		Assert.assertNotNull(workflowTrackingId);


	}

	/**
	 * The method will validate the Geo Unit for any locks (If already been
	 * opened by any other user for edit).
	 */
	@Test
	public void testLockGeoUnit() {
		LOGGER.info("entering GeographyServiceTest | testLockGeoUnit");
		Long geoUnitId = 999190558L;
		String lockResult = geographyService.lockGeoUnit(geoUnitId);
		Assert.assertEquals("false", lockResult);
	}

	/**
	 * The method will retrieve the Geo Unit based on the Workflow Tracking Id.
	 */
	@Test
	public void testRetreiveGeoUnitByTrackingId() {
		LOGGER.info("entering GeographyServiceTest | testRetreiveGeoUnitByTrackingId");
		Long domainId = 999192465L;
		GeoUnit geoUnit = geographyService
				.retreiveGeoUnitByDomainId(domainId);
		Assert.assertEquals(999192465L, geoUnit.getGeoUnitId().longValue());
	}

	/**
	 * The method will retrieve the Geo Unit based on the Workflow Tracking Id.
	 */
	@Test
	public void testRetreiveGeoUnitByTrackingIdForIf() {
		LOGGER.info("entering GeographyServiceTest | testRetreiveGeoUnitByTrackingIdForIf");
		Long domainId = 999192465L;
		GeoUnit geoUnit = geographyService
				.retreiveGeoUnitByDomainId(domainId);
		geoUnit.setGeoUnitTypeCode(130L);
		Assert.assertEquals(999192465L, geoUnit.getGeoUnitId().longValue());
	}

	/**
	 * The method will retrieve all Country details from the Search DB based on
	 * the name type code and the language code.
	 */
	@Test
	public void testRetrieveAllCountries() {
		LOGGER.info("entering GeographyServiceTest | testRetrieveAllCountries");
		Long nameType = 19284L;
		Long languageCode = 39L;

		List<CodeValueVO> allCountriesResult = geographyService
				.retrieveAllCountries(nameType, languageCode);
		Assert.assertEquals(239, allCountriesResult.size());
	}

	/**
	 * The method will retrieve all Continent details from the Search DB based
	 * on the name type code and language code.
	 */
	@Test
	public void testRetrieveAllContinents() {
		LOGGER.info("entering GeographyServiceTest | testRetrieveAllContinents");
		Long nameType = 32L;
		Long languageCode = 39L;

		List<CodeValueVO> allContinentsResult = geographyService
				.retrieveAllContinents(nameType, languageCode);
		Assert.assertEquals(2, allContinentsResult.size());
	}

	/**
	 *
	 * The method will test if the Geo Units corresponding to the parentGeoUnit,
	 * geoUnitType, nameType and languageCode are being retrieved
	 */
	@Test
	public void testRetrieveChildGeoUnitsByType() {
		LOGGER.info("entering GeographyServiceTest | testRetrieveChildGeoUnitsByType");
		List<CodeValueVO> childGeoUnitsResult = geographyService
				.retrieveChildGeoUnitsByType(39L, 126L, 984L, 32L);
		Assert.assertEquals(11885, childGeoUnitsResult.size());
	}

	/**
	 * This method tests whether approved changes are being entered into the
	 * staging DB
	 */
	@Test
	@Rollback(value = true)
	public void testSaveApprovedChanges() {
		LOGGER.info("entering GeographyServiceTest | testSaveApprovedChanges");
		Long domainId = 999192465L;
		Long geoUnitIdResult = geographyService
				.saveApprovedGeoChanges(domainId, 101L);
		Assert.assertEquals(999192465L, geoUnitIdResult.longValue());
	}

	/**
	 * The method will test if geo unit data is being removed from the
	 * Transaction DB.
	 */
	@Test
	@Rollback(value = true)
	public void testRemoveApprovedGeoUnit() {
		LOGGER.info("entering GeographyServiceTest | testRemoveApprovedGeoUnit");
		Long geoUnitId = 9993714048L;
		Long changeTypeId= (long)101;
		geographyService.removeApprovedGeoUnit(geoUnitId,changeTypeId);
	}

	/**
	 * The method will persist the existing Geo Unit data in the Transactional
	 * DB.
	 */
	@Test
	@Rollback(value = true)
	public void testUpdateGeoUnit() {
		LOGGER.info("entering GeographyServiceTest | testUpdateGeoUnit");
		GeoUnit geoUnit = geographyService
				.retrieveGeoUnitByGeoUnitId(100009948L);
		Long workflowTrackingIdResult = geographyService.updateGeoUnit(geoUnit);
		Assert.assertNotNull(workflowTrackingIdResult);
	}

	/**
	 *
	 * The method will perform a hierarchy search of geo units on the search db.
	 */
	@Test
	public void testSearchGeographies() {
		LOGGER.info("entering GeographyServiceTest | testSearchGeographies");
		GeoSearchCriteriaVO geoSearchCriteria = new GeoSearchCriteriaVO();
		geoSearchCriteria.setSortOrder("asc");
		geoSearchCriteria.setSortBy("countryName");
		geoSearchCriteria.setMaxResults(10);
		geoSearchCriteria.setRowIndex(1);
		geoSearchCriteria.setCountryGeoCode("892");
		geoSearchCriteria.setStateGeoCode("999189145");
		geoSearchCriteria.setCountyName("WATERLOO");
		geoSearchCriteria.setPostTownName("KITCHENER");
		List<GeographySearch> searchResults = geographyService
				.searchGeographies(geoSearchCriteria);
		Assert.assertEquals(0, searchResults.size());
	}

	/**
	 * The method will count the records in the hierarchy search of geo units on
	 * the search db
	 */
	@Test
	public void testCountSearchGeographies() {
		LOGGER.info("entering GeographyServiceTest | testCountSearchGeographies");
		GeoSearchCriteriaVO geoSearchCriteria = new GeoSearchCriteriaVO();
		geoSearchCriteria.setSortOrder("asc");
		geoSearchCriteria.setSortBy("countryName");
		geoSearchCriteria.setMaxResults(10);
		geoSearchCriteria.setRowIndex(1);
		geoSearchCriteria.setCountryGeoCode("892");
		geoSearchCriteria.setStateGeoCode("999189145");
		geoSearchCriteria.setCountyName("WATERLOO");
		geoSearchCriteria.setPostTownName("KITCHENER");
		Long searchResults = geographyService
				.countSearchGeographies(geoSearchCriteria);
		Assert.assertEquals(0, searchResults.longValue());
	}

	/**
	 * This method tests if the count of search results using geo unit name is
	 * being obtained
	 */
	@Test
	public void testCountSearchGeoUnitByName() {
		LOGGER.info("entering GeographyServiceTest | testCountSearchGeoUnitByName");
		String searchString = "Canada";
		Long countResult = geographyService
				.countSearchGeoUnitByName(searchString);
		Assert.assertEquals(104L, countResult.longValue());
	}

	/**
	 * This method tests if the count of search results using geo unit code is
	 * being obtained
	 */
	@Test
	public void testCountSearchGeoUnitByCode() {
		LOGGER.info("entering GeographyServiceTest | testCountSearchGeoUnitByCode");
		String searchString = "892";
		Long countResult = geographyService
				.countSearchGeoUnitByCode(searchString);
		Assert.assertEquals(176L, countResult.longValue());
	}

	/**
	 * This method tests if a GeoUnit entity is beind retrieved for review by
	 * the user
	 */
	@Test
	@Rollback(value = true)
	public void testReviewGeoUnitChanges() {
		LOGGER.info("entering GeographyServiceTest | testReviewGeoUnitChanges");
		Long trackingId = 999192465L;
		GeoUnit reviewGeoUnit = geographyService
				.reviewGeoUnitChanges(trackingId);
		Assert.assertEquals(999192465L, reviewGeoUnit.getGeoUnitId()
				.longValue());
	}

	/**
	 * The method will retrieve all Country Groups from the Search DB based on
	 * the name type code and the user preferred language code.
	 */
	@Test
	public void testRetrieveAllCountryGroups() {
		LOGGER.info("entering GeographyServiceTest | testRetrieveAllCountryGroups");
		Long nameType = 32L;
		Long languageCode = 39L;
		List<CodeValueVO> countryGroups = geographyService
				.retrieveAllCountryGroups(nameType, languageCode);
		Assert.assertEquals(23, countryGroups.size());
	}

	/**
	 * Retrieves all the country groups or the country groups under the given
	 * country group
	 */
	@Test
	public void testSearchCountryGroups() {
		LOGGER.info("entering GeographyServiceTest | testSearchCountryGroups");
		List<GeoUnitName> searchCountryGroupsResult = geographyService
				.searchCountryGroups(39L, 19349L, 32L, 141542L);
		Assert.assertEquals(3, searchCountryGroupsResult.size());
	}

	/**
	 * The method will test if new Geo Unit data is being persisted in the
	 * Transactional DB.
	 */
	@Test
	@Rollback(value = true)
	public void testInsertGeoUnit() {
		LOGGER.info("entering GeographyServiceTest | testInsertGeoUnit");
		GeoUnit geoUnit = new GeoUnit();
		geoUnit.setGeoUnitTypeCode(324L);
		geoUnit.setEffectiveDate(new Date());
		geoUnit.setCreatedUser("DNB");
		geoUnit.setCreatedDate(new Date());
		geoUnit.setModifiedUser("DNB");
		geoUnit.setModifiedDate(new Date());
		Long workflowTracking = geographyService.insertGeoUnit(geoUnit);
		Assert.assertNotNull(workflowTracking);
	}

	/**
	 *
	 * The method will retrieve all geography hierarchies
	 */
	@Test
	public void testRetrieveAllGeoHierarchies() {
		LOGGER.info("entering GeographyServiceTest | testRetrieveAllGeoHierarchies");
		List<GeoHierarchy> heirarchyResults = geographyService
				.retrieveAllGeoHierarchies();
		Assert.assertEquals(280, heirarchyResults.size());
	}

	/**
	 *
	 * The method will retrieve all geography default configurations
	 *
	 */
	@Test
	public void testRetrieveAllGeoConfigurations() {
		LOGGER.info("entering GeographyServiceTest | testRetrieveAllGeoConfigurations");
		List<GeoDefaultConfiguration> configuratoinResults = geographyService
				.retrieveAllGeoConfigurations();
		Assert.assertEquals(241, configuratoinResults.size());

	}

	/**
	 * This method tests if a given geo unit id has a child geo unit
	 */
	@Test
	public void testCheckForChildGeoUnit() {
		LOGGER.info("entering GeographyServiceTest | testCheckForChildGeoUnit");
		Boolean checkForChild = geographyService.checkForChildGeoUnit(892L);
		Assert.assertEquals(true, checkForChild.booleanValue());
	}

	/**
	 * The method will search the Staging SoR for the Geo Unit based on the Geo
	 * Unit Id and will return the GeoUnit entity.
	 */
	@Test
	public void testRetrieveTxnGeoUnitById() {

		LOGGER.info("entering GeographyServiceTest | testRetrieveGeoUnitByGeoUnitId");
		Long geoUnitId = 1007401L;
		GeoUnit geoUnit = geographyService
				.retrieveTxnGeoUnitById(geoUnitId);
		Assert.assertEquals(geoUnitId,geoUnit.getGeoUnitId());
	}


	/**
	 *
	 * The method will retrieve all user group mappings available within refdata.
	 *
	 * @return userGroupMappings
	 */
	@Test
	public void testRetrieveAllUserGroupMappings()
	{
		List<UserGroupMapping> retrieveAllUserGroupMappings= geographyService.retrieveAllUserGroupMappings();
		Assert.assertEquals(29,retrieveAllUserGroupMappings.size());
	}

	/**
	 *
	 * The method will retrieve all Hierarchy by the geoUnitId passed.
	 *
	 * @param geoUnitId,geoUnitTypeCode
	 */
	@Test
	public void testGetHierarchyByGeoUnitId(){
		Map<Long, String> getHierarchyByGeoUnitId=geographyService.getHierarchyByGeoUnitId(9996618751L, 324L);

		Assert.assertEquals(0,getHierarchyByGeoUnitId.size());
	}


	/**
	 *
	 * The method will retrieve official name  by the geoUnitId and type code passed.
	 *
	 * @param geoUnitId,geoUnitTypeCode
	 */
	@Test
	public void testGetOfficialNameByGeoUnitIdAndTypeCode() {
		String getOfficialNameByGeoUnitIdAndTypeCode=geographyService.getOfficialNameByGeoUnitIdAndTypeCode(9994051903L, 9994187206L, 126L);
		Assert.assertEquals("s Ust-Rakhmanovka",getOfficialNameByGeoUnitIdAndTypeCode);
	}

	/**
	 *
	 * The method will retrieve official name  by the geoUnitId and type code passed.
	 *
	 * @param geoUnitId,geoUnitTypeCode
	 */
	@Test
	public void testRetrieveGeoUnitsByIdList() {

		List<Long> geoUnitIds= new ArrayList<Long>();
		geoUnitIds.add(9994051903L);
		geoUnitIds.add(139326L);

		Map<Long, List<GeoUnit>> retrieveGeoUnitsByIdList=geographyService.retrieveGeoUnitsByIdList(geoUnitIds);
		Assert.assertEquals(2,retrieveGeoUnitsByIdList.size());
	}
}
