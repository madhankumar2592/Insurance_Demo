/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * This class used as an entity class for the IndustrialCodeMap. The class will have a
 * direct mapping toe DB table INDS_CODE_MAP.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "INDS_CODE_MAP")
@NamedQueries({ 
	@NamedQuery(name = "IndustryCodeMap.removeIndustryCodeMapByIndustryCodeId", query = "DELETE FROM IndustryCodeMap i where i.industryCodeMapPK.fromIndustryCodeId = :industryCodeId"),
	@NamedQuery(name = "IndustryCodeMap.removeIndustryCodeToMapByIndustryCodeId", query = "DELETE FROM IndustryCodeMap i where i.industryCodeMapPK.toIndustryCodeId = :industryCodeId"),
	@NamedQuery(name = "IndustryCodeMap.removeByFromAndToIndsCodeId", query = "DELETE FROM IndustryCodeMap i where i.industryCodeMapPK.fromIndustryCodeId = :fromIndustryCodeId and i.industryCodeMapPK.toIndustryCodeId = :toIndustryCodeId")
})
public class IndustryCodeMap extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private IndustryCodeMapPK industryCodeMapPK;
		
	@Column(name = "PRFD_MAP_INDC")
	private Integer preferredMapIndicator;

	@Transient
	private IndustryCode toIndustryCode;

	@Transient
	private String changeIndicator;

	/**
	 * Empty Constructor.
	 */
	public IndustryCodeMap() {
		super();
	}

	/**
	 * 
	 * @param fromIndustryCodeId
	 * @param toIndustryCode
	 * @param preferredMapIndicator
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 */
	public IndustryCodeMap(Long fromIndustryCodeId, Long toIndustryCodeId,
			Integer preferredMapIndicator, String createdUser,
			Date createdDate, String modifiedUser, Date modifiedDate) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.industryCodeMapPK.setFromIndustryCodeId(fromIndustryCodeId);
		this.industryCodeMapPK.setToIndustryCodeId(toIndustryCodeId);
		this.preferredMapIndicator = preferredMapIndicator;
	}

	/**
	 * @return the industryCodeMapPK
	 */
	public IndustryCodeMapPK getIndustryCodeMapPK() {
		return industryCodeMapPK;
	}

	/**
	 * @param industryCodeMapPK the industryCodeMapPK to set
	 */
	public void setIndustryCodeMapPK(IndustryCodeMapPK industryCodeMapPK) {
		this.industryCodeMapPK = industryCodeMapPK;
	}

	/**
	 * @return the preferredMapIndicator
	 */
	public Integer getPreferredMapIndicator() {
		return preferredMapIndicator;
	}

	/**
	 * @param preferredMapIndicator the preferredMapIndicator to set
	 */
	public void setPreferredMapIndicator(Integer preferredMapIndicator) {
		this.preferredMapIndicator = preferredMapIndicator;
	}

	/**
	 * @return the toIndustryCode
	 */
	public IndustryCode getToIndustryCode() {
		return toIndustryCode;
	}

	/**
	 * @param toIndustryCode the toIndustryCode to set
	 */
	public void setToIndustryCode(IndustryCode toIndustryCode) {
		this.toIndustryCode = toIndustryCode;
	}

	/**
	 * @return the changeIndicator
	 */
	public String getChangeIndicator() {
		return changeIndicator;
	}

	/**
	 * @param changeIndicator the changeIndicator to set
	 */
	public void setChangeIndicator(String changeIndicator) {
		this.changeIndicator = changeIndicator;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "IndustryCodeMap [industryCodeMapPK=" + industryCodeMapPK
				+ ", preferredMapIndicator=" + preferredMapIndicator
				+ ", toIndustryCode=" + toIndustryCode + ", changeIndicator="
				+ changeIndicator + "]";
	}
	
}
