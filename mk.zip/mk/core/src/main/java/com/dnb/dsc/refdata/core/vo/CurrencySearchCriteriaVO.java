/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as a value object class.
 * 
 * @author Cognizant
 * @version last updated : Mar 01, 2012
 * @see
 * 
 */
@Component
public class CurrencySearchCriteriaVO extends PaginationVO {
	
	private static final long serialVersionUID = 2L;
	
	private String fromCurrencyCode;
	private String toCurrencyCode;
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date fromDate;
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date toDate;
	private String dataProviderCode;
	
	/**
	 * Empty Constructor.
	 */
	public CurrencySearchCriteriaVO() {
		super();
	}

	/**
	 * 
	 * @param fromCurrencyCode
	 * @param toCurrencyCode
	 * @param fromDate
	 * @param toDate
	 * @param dataProviderCode
	 */
	public CurrencySearchCriteriaVO(String fromCurrencyCode,
			String toCurrencyCode, Date fromDate, Date toDate,
			String dataProviderCode) {
		super();
		this.fromCurrencyCode = fromCurrencyCode;
		this.toCurrencyCode = toCurrencyCode;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.dataProviderCode = dataProviderCode;
	}
	
	/**
	 * 
	 * @return fromCurrencyCode
	 */
	public String getFromCurrencyCode() {
		return fromCurrencyCode;
	}

	/**
	 * 
	 * @param fromCurrencyCode
	 */
	public void setFromCurrencyCode(String fromCurrencyCode) {
		this.fromCurrencyCode = fromCurrencyCode;
	}

	/**
	 * 
	 * @return toCurrencyCode
	 */
	public String getToCurrencyCode() {
		return toCurrencyCode;
	}

	/**
	 * 
	 * @param toCurrencyCode
	 */
	public void setToCurrencyCode(String toCurrencyCode) {
		this.toCurrencyCode = toCurrencyCode;
	}

	/**
	 * 
	 * @return fromDate
	 */
	public Date getFromDate() {
		return fromDate;
	}

	/**
	 * 
	 * @param fromDate
	 */
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * 
	 * @return toDate
	 */
	public Date getToDate() {
		return toDate;
	}

	/**
	 * 
	 * @param toDate
	 */
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	/**
	 * 
	 * @return dataProviderCode
	 */
	public String getDataProviderCode() {
		return dataProviderCode;
	}

	/**
	 * 
	 * @param dataProviderCode
	 */
	public void setDataProviderCode(String dataProviderCode) {
		this.dataProviderCode = dataProviderCode;
	}

	@Override
	public String toString() {
		return "CurrencySearchCriteriaVO [fromCurrencyCode=" + fromCurrencyCode
				+ ", toCurrencyCode=" + toCurrencyCode + ", fromDate="
				+ fromDate + ", toDate=" + toDate + ", dataProviderCode="
				+ dataProviderCode + "]";
	}
}
