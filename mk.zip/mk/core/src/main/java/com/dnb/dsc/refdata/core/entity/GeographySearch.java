/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class used as an entity class for the Geography search DB. The class  
 * will have a direct mapping toe DB table geography table.
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@Entity
@Table(name = "UI_GEO_SRCH")
public class GeographySearch implements Serializable {

	private static final long serialVersionUID = 2L;
	
	@Id
	@Column(name = "UI_GEO_SRCH_ID")
	private Long geoSearchId;

	@Column(name = "CTRY_NME")
	private String countryName;

	@Column(name = "CTRY_GEO_UNIT_ID")
	private Long countryGeoCode;

	@Column(name = "TERR_NME")
	private String stateName;

	@Column(name = "TERR_GEO_UNIT_ID")
	private Long stateGeoCode;

	@Column(name = "CNTY_NME")
	private String countyName;

	@Column(name = "CNTY_GEO_UNIT_ID")
	private Long countyGeoCode;

	@Column(name = "POST_TOWN_NME")
	private String postTownName;

	@Column(name = "POST_TOWN_GEO_UNIT_ID")
	private Long postTownGeoCode;

	@Column(name = "POST_CODE")
	private String postCode;

	@Column(name = "POST_CODE_GEO_UNIT_ID")
	private Long postCodeGeoCode;
	
	/**
	 * Constructor
	 */
	public GeographySearch() {
		super();
	}
	
	/**
	 * @param countryName
	 * @param countryGeoCode
	 * @param stateName
	 * @param stateGeoCode
	 * @param countyName
	 * @param countyGeoCode
	 * @param postTownName
	 * @param postTownGeoCode
	 * @param postCode
	 * @param postCodeGeoCode
	 */
	public GeographySearch(String countryName, Long countryGeoCode,
			String stateName, Long stateGeoCode, String countyName,
			Long countyGeoCode, String postTownName, Long postTownGeoCode,
			String postCode, Long postCodeGeoCode) {
		this.countryName = countryName;
		this.countryGeoCode = countryGeoCode;
		this.stateName = stateName;
		this.stateGeoCode = stateGeoCode;
		this.countyName = countyName;
		this.countyGeoCode = countyGeoCode;
		this.postTownName = postTownName;
		this.postTownGeoCode = postTownGeoCode;
		this.postCode = postCode;
		this.postCodeGeoCode = postCodeGeoCode;
	}

	/**
	 * @return the geoSearchId
	 */
	public Long getGeoSearchId() {
		return geoSearchId;
	}

	/**
	 * @param geoSearchId the geoSearchId to set
	 */
	public void setGeoSearchId(Long geoSearchId) {
		this.geoSearchId = geoSearchId;
	}

	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}

	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	/**
	 * @return the countryGeoCode
	 */
	public Long getCountryGeoCode() {
		return countryGeoCode;
	}

	/**
	 * @param countryGeoCode the countryGeoCode to set
	 */
	public void setCountryGeoCode(Long countryGeoCode) {
		this.countryGeoCode = countryGeoCode;
	}

	/**
	 * @return the stateName
	 */
	public String getStateName() {
		return stateName;
	}

	/**
	 * @param stateName the stateName to set
	 */
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	/**
	 * @return the stateGeoCode
	 */
	public Long getStateGeoCode() {
		return stateGeoCode;
	}

	/**
	 * @param stateGeoCode the stateGeoCode to set
	 */
	public void setStateGeoCode(Long stateGeoCode) {
		this.stateGeoCode = stateGeoCode;
	}

	/**
	 * @return the countyName
	 */
	public String getCountyName() {
		return countyName;
	}

	/**
	 * @param countyName the countyName to set
	 */
	public void setCountyName(String countyName) {
		this.countyName = countyName;
	}

	/**
	 * @return the countyGeoCode
	 */
	public Long getCountyGeoCode() {
		return countyGeoCode;
	}

	/**
	 * @param countyGeoCode the countyGeoCode to set
	 */
	public void setCountyGeoCode(Long countyGeoCode) {
		this.countyGeoCode = countyGeoCode;
	}

	/**
	 * @return the postTownName
	 */
	public String getPostTownName() {
		return postTownName;
	}

	/**
	 * @param postTownName the postTownName to set
	 */
	public void setPostTownName(String postTownName) {
		this.postTownName = postTownName;
	}

	/**
	 * @return the postTownGeoCode
	 */
	public Long getPostTownGeoCode() {
		return postTownGeoCode;
	}

	/**
	 * @param postTownGeoCode the postTownGeoCode to set
	 */
	public void setPostTownGeoCode(Long postTownGeoCode) {
		this.postTownGeoCode = postTownGeoCode;
	}

	/**
	 * @return the postCode
	 */
	public String getPostCode() {
		return postCode;
	}

	/**
	 * @param postCode the postCode to set
	 */
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	/**
	 * @return the postCodeGeoCode
	 */
	public Long getPostCodeGeoCode() {
		return postCodeGeoCode;
	}

	/**
	 * @param postCodeGeoCode the postCodeGeoCode to set
	 */
	public void setPostCodeGeoCode(Long postCodeGeoCode) {
		this.postCodeGeoCode = postCodeGeoCode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GeographySearch [countryName=" + countryName
				+ ", countryGeoCode=" + countryGeoCode + ", stateName="
				+ stateName + ", stateGeoCode=" + stateGeoCode
				+ ", countyName=" + countyName + ", countyGeoCode="
				+ countyGeoCode + ", postTownName=" + postTownName
				+ ", postTownGeoCode=" + postTownGeoCode + ", postCode="
				+ postCode + ", postCodeGeoCode=" + postCodeGeoCode + "]";
	}

}
