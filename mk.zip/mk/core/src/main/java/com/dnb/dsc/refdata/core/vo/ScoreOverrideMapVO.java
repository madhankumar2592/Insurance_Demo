package com.dnb.dsc.refdata.core.vo;

import java.util.Date;

public class ScoreOverrideMapVO {
	private Long scoreTypeCode;
	private Long marketCode;
	private Integer scoreVersion;
	private String createdUser;
	private Date createdDate;
	private String modifiedUser;
	private Date modifiedDate;
	
	
	/**
	 * @return the createdUser
	 */
	public String getCreatedUser() {
		return createdUser;
	}
	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the modifiedUser
	 */
	public String getModifiedUser() {
		return modifiedUser;
	}
	/**
	 * @param modifiedUser the modifiedUser to set
	 */
	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}
	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}
	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	/**
	 * @return the scoreTypeCode
	 */
	public Long getScoreTypeCode() {
		return scoreTypeCode;
	}
	/**
	 * @param scoreTypeCode the scoreTypeCode to set
	 */
	public void setScoreTypeCode(Long scoreTypeCode) {
		this.scoreTypeCode = scoreTypeCode;
	}
	/**
	 * @return the marketCode
	 */
	public Long getMarketCode() {
		return marketCode;
	}
	/**
	 * @param marketCode the marketCode to set
	 */
	public void setMarketCode(Long marketCode) {
		this.marketCode = marketCode;
	}
	/**
	 * @return the scoreVersion
	 */
	public Integer getScoreVersion() {
		return scoreVersion;
	}
	/**
	 * @param scoreVersion the scoreVersion to set
	 */
	public void setScoreVersion(Integer scoreVersion) {
		this.scoreVersion = scoreVersion;
	}
}


