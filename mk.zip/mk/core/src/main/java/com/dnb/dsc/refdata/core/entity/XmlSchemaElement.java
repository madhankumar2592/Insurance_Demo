/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * This class used as an entity class for the XML Schema Element Table. The class will have a direct mapping toe DB
 * table xml_scma_ele
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
@Entity
@Table(name = "XML_SCMA_ELE")
@NamedQueries({
        @NamedQuery(name = "XmlSchema.retrieveXmlSchemaByXmlElementId", query = "select xse from XmlSchemaElement xse where xse.xmlSchemaElementId=:elementId"),
        @NamedQuery(name = "XmlSchema.countXmlSchema", query = "SELECT COUNT(xse.xmlSchemaElementId) FROM XmlSchemaElement xse WHERE xse.xmlSchemaElementId = :xmlSchemaElementId"),
        @NamedQuery(name = "XmlSchema.removeXmlSchemaElementById", query ="DELETE FROM XmlSchemaElement xse where xse.xmlSchemaElementId = :xmlSchemaElementId")
        })
public class XmlSchemaElement extends Audit implements Serializable {
    private static final long serialVersionUID = 2L;

    @Id
    @Column(name = "XML_SCMA_ELE_ID")
    private String xmlSchemaElementId;

    @Column(name = "XML_SCMA_REC_TYP_CD")
    private String xmlSchemaRecordTypeCd;

    @Column(name = "DATA_ELE_NME")
    private String dataElementName;

    @Column(name = "DATA_ELE_DESC")
    private String dataElementDescription;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "xmlSchemaElementId")
    private List<XmlSchemaElementLabelDetails> xmlSchemaElementLabelDetails;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "xmlSchemaElementId")
    private List<XmlSchemaElementXPath> xmlSchemaElementXPath;

    /**
     * The default constructor
     */
    public XmlSchemaElement() {
        super();
    }

    /**
     * @param xmlSchemaElementId
     * @param xmlSchemaRecordTypeCd
     * @param dataElementName
     * @param dataElementDescription
     * @param rowCreationId
     * @param rowCreationTimeStamp
     * @param rowModificationId
     * @param rowModificationTimeStamp
     * @param xmlSchemaElementLabelDetails
     * @param xmlSchemaElementXPath
     */
    public XmlSchemaElement(String xmlSchemaElementId, String xmlSchemaRecordTypeCd, String dataElementName,
            String dataElementDescription, String rowCreationId, Date rowCreationTimeStamp, String rowModificationId,
            Date rowModificationTimeStamp, List<XmlSchemaElementLabelDetails> xmlSchemaElementLabelDetails,
            List<XmlSchemaElementXPath> xmlSchemaElementXPath) {
    	super(rowCreationId, rowCreationTimeStamp, rowModificationId,rowModificationTimeStamp);
        this.xmlSchemaElementId = xmlSchemaElementId;
        this.xmlSchemaRecordTypeCd = xmlSchemaRecordTypeCd;
        this.dataElementName = dataElementName;
        this.dataElementDescription = dataElementDescription;
        this.xmlSchemaElementLabelDetails = xmlSchemaElementLabelDetails;
        this.xmlSchemaElementXPath = xmlSchemaElementXPath;
    }

    /**
     * @param xmlSchemaElementId
     * @param dataElementName
     * @param dataElementDescription
     */
    public XmlSchemaElement(String xmlSchemaElementId, String dataElementName, String dataElementDescription) {
        super();
        this.xmlSchemaElementId = xmlSchemaElementId;
        this.dataElementName = dataElementName;
        this.dataElementDescription = dataElementDescription;
    }

    /**
     * @return the xmlSchemaElementId
     */
    public String getXmlSchemaElementId() {
        return xmlSchemaElementId;
    }

    /**
     * @param xmlSchemaElementId
     *            the xmlSchemaElementId to set
     */
    public void setXmlSchemaElementId(String xmlSchemaElementId) {
        this.xmlSchemaElementId = xmlSchemaElementId;
    }

    /**
     * @return the xmlSchemaRecordTypeCd
     */
    public String getXmlSchemaRecordTypeCd() {
        return xmlSchemaRecordTypeCd;
    }

    /**
     * @param xmlSchemaRecordTypeCd
     *            the xmlSchemaRecordTypeCd to set
     */
    public void setXmlSchemaRecordTypeCd(String xmlSchemaRecordTypeCd) {
        this.xmlSchemaRecordTypeCd = xmlSchemaRecordTypeCd;
    }

    /**
     * @return the dataElementName
     */
    public String getDataElementName() {
        return dataElementName;
    }

    /**
     * @param dataElementName
     *            the dataElementName to set
     */
    public void setDataElementName(String dataElementName) {
        this.dataElementName = dataElementName;
    }

    /**
     * @return the dataElementDescription
     */
    public String getDataElementDescription() {
        return dataElementDescription;
    }

    /**
     * @param dataElementDescription
     *            the dataElementDescription to set
     */
    public void setDataElementDescription(String dataElementDescription) {
        this.dataElementDescription = dataElementDescription;
    }

    /**
     * @return the xmlSchemaElementLabelDetails
     */
    public List<XmlSchemaElementLabelDetails> getXmlSchemaElementLabelDetails() {
        return xmlSchemaElementLabelDetails;
    }

    /**
     * @param xmlSchemaElementLabelDetails
     *            the xmlSchemaElementLabelDetails to set
     */
    public void setXmlSchemaElementLabelDetails(List<XmlSchemaElementLabelDetails> xmlSchemaElementLabelDetails) {
        this.xmlSchemaElementLabelDetails = xmlSchemaElementLabelDetails;
    }

    /**
     * @return the xmlSchemaElementXPath
     */
    public List<XmlSchemaElementXPath> getXmlSchemaElementXPath() {
        return xmlSchemaElementXPath;
    }

    /**
     * @param xmlSchemaElementXPath
     *            the xmlSchemaElementXPath to set
     */
    public void setXmlSchemaElementXPath(List<XmlSchemaElementXPath> xmlSchemaElementXPath) {
        this.xmlSchemaElementXPath = xmlSchemaElementXPath;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "XmlSchemaElement [xmlSchemaElementId=" + xmlSchemaElementId
				+ ", xmlSchemaRecordTypeCd=" + xmlSchemaRecordTypeCd
				+ ", dataElementName=" + dataElementName
				+ ", dataElementDescription=" + dataElementDescription
				+ ", xmlSchemaElementLabelDetails="
				+ xmlSchemaElementLabelDetails + ", xmlSchemaElementXPath="
				+ xmlSchemaElementXPath + "]";
	}
}