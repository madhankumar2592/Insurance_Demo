/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "SCR")
@NamedQueries({
		@NamedQuery(name = "Score.retrieveCountForScoreTypeCode", query = "SELECT count(s.scoreTypeId) FROM ScoreType s WHERE s.scoreTypeCode= :scoreTypeCode"),
		@NamedQuery(name = "Score.retrievescoreVersion", query = "SELECT distinct new Score(s.scoreVersion, s.scoreMarketCode,s.modifiedDate,s.createdUser,s.createdDate,s.modifiedUser) FROM Score s where s.scoreTypeId in(select st.scoreTypeId FROM ScoreType st WHERE st.scoreTypeCode=:scoreType) and s.scoreMarketCode=:marketType order by s.modifiedDate desc")
		
		})
public class Score extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * @return the scoreId
	 */
	public Long getScoreId() {
		return scoreId;
	}

	/**
	 * @param scoreId the scoreId to set
	 */
	public void setScoreId(Long scoreId) {
		this.scoreId = scoreId;
	}

	/**
	 * @return the scoreTypeId
	 */
	public Long getScoreTypeId() {
		return scoreTypeId;
	}

	/**
	 * @param scoreTypeId the scoreTypeId to set
	 */
	public void setScoreTypeId(Long scoreTypeId) {
		this.scoreTypeId = scoreTypeId;
	}

	/**
	 * @return the scoreMarketCode
	 */
	public Long getScoreMarketCode() {
		return scoreMarketCode;
	}

	/**
	 * @param scoreMarketCode the scoreMarketCode to set
	 */
	public void setScoreMarketCode(Long scoreMarketCode) {
		this.scoreMarketCode = scoreMarketCode;
	}

	/**
	 * @return the inactiveIndicator
	 */
	public Long getInactiveIndicator() {
		return inactiveIndicator;
	}

	/**
	 * @param inactiveIndicator the inactiveIndicator to set
	 */
	public void setInactiveIndicator(Long inactiveIndicator) {
		this.inactiveIndicator = inactiveIndicator;
	}

	/**
	 * @return the scoreVersion
	 */
	/*public Integer getScoreVersion() {
		return scoreVersion;
	}

	*//**
	 * @param scoreVersion the scoreVersion to set
	 *//*
	public void setScoreVersion(Integer scoreVersion) {
		this.scoreVersion = scoreVersion;
	}*/

	@Id
	@Column(name = "SCR_ID")
	private Long scoreId;
		
	@Column(name = "SCR_TYP_ID")
	private Long scoreTypeId;
	
	@Column(name = "SCR_MKT_CD")
	private Long scoreMarketCode;
	
	@Column(name = "INAC_INDC")
	private Long inactiveIndicator;
	
	/*@Column(name = "SCR_VER")
	private Integer scoreVersion;*/
	
	@Column(name = "SCR_VER" ,precision=6, scale=2)
	private Double scoreVersion;
	
		

	public Double getScoreVersion() {
		return scoreVersion;
	}

	public void setScoreVersion(Double scoreVersion) {
		this.scoreVersion = scoreVersion;
	}

	/**
	 * Empty Constructor.
	 */
	/*public Score(Long scoreMarketCode) {
		super();
		this.scoreMarketCode = scoreMarketCode;
	}*/
	public Score(Double scoreVersion) {
		super();
		this.scoreVersion = scoreVersion;
	}
	/*public Score(Long scoreVersion) {
		super();
		this.scoreVersion = scoreVersion;
	}*/
	public Score(Double scoreVersion, Long scoreMarketCode) {
		super();
		this.scoreMarketCode = scoreMarketCode;
		this.scoreVersion = scoreVersion;
	}
	public Score(Double scoreVersion, Long scoreMarketCode,Date modifiedDate,String createdUser, Date createdDate,
			String modifiedUser) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.scoreMarketCode = scoreMarketCode;
		this.scoreVersion = scoreVersion;
	}
	
	public Score() {
		super();
	}
	/**
	 * 
	 * @param scoreId
	 * @param scoreVersion
	 * @param scoreTypeId
	 * @param scoreMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public Score(Long scoreId, Double scoreVersion, Long scoreTypeId, Long scoreMarketCode,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate, Long inactiveIndicator
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.scoreId = scoreId;
		this.scoreVersion = scoreVersion;
		this.scoreTypeId = scoreTypeId;
		this.scoreMarketCode = scoreMarketCode;
		this.inactiveIndicator = inactiveIndicator;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "scoreId [scoreId=" + scoreId
				+ ", scoreMarketCode=" + scoreMarketCode 
				+"scoreVersion=" + scoreVersion+ 
				"scoreTypeId=" + scoreTypeId + 
				", inactiveIndicator=" + inactiveIndicator + 
				 "]";
	}
	
	
}
