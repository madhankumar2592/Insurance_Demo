/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

/**
 * This class used as an value object class.
 * 
 * @author Cognizant
 * @version last updated : June 6 2012
 * @see
 * 
 */
public class ScotsBulkDowloadVO {
	private String fileType;
	private Long uiBlkDwnldId;
	private Long[] languageList; 
	private Long[] codeTableList ;
	private String scotsDownLoadFileName;
	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}
	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	/**
	 * @return the uiBlkDwnldId
	 */
	public Long getUiBlkDwnldId() {
		return uiBlkDwnldId;
	}
	/**
	 * @param uiBlkDwnldId the uiBlkDwnldId to set
	 */
	public void setUiBlkDwnldId(Long uiBlkDwnldId) {
		this.uiBlkDwnldId = uiBlkDwnldId;
	}
	/**
	 * @return the scotsDownLoadFileName
	 */
	public String getScotsDownLoadFileName() {
		return scotsDownLoadFileName;
	}
	/**
	 * @param scotsDownLoadFileName the scotsDownLoadFileName to set
	 */
	public void setScotsDownLoadFileName(String scotsDownLoadFileName) {
		this.scotsDownLoadFileName = scotsDownLoadFileName;
	}
	/**
	 * @return the languageList
	 */
	public Long[] getLanguageList() {
		return languageList;
	}
	/**
	 * @param languageList the languageList to set
	 */
	public void setLanguageList(Long[] languageList) {
		this.languageList = languageList;
	}
	/**
	 * @return the codeTableList
	 */
	public Long[] getCodeTableList() {
		return codeTableList;
	}
	/**
	 * @param codeTableList the codeTableList to set
	 */
	public void setCodeTableList(Long[] codeTableList) {
		this.codeTableList = codeTableList;
	}
	
	

	
}
