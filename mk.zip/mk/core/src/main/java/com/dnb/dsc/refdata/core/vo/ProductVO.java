package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.ArrayList;

public class ProductVO implements Serializable{
	private static final long serialVersionUID = 8384721628931167943L;

	private Long marketCode;
	private Long productCode;
	private Long resourceCode;
	
	private ArrayList<Long> marketCodeList;
	private ArrayList<Long> productList;
	private ArrayList<Long> resourceList;
	
	public Long getMarketCode() {
		return marketCode;
	}
	public void setMarketCode(Long marketCode) {
		this.marketCode = marketCode;
	}
	public Long getProductCode() {
		return productCode;
	}
	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}
	public Long getResourceCode() {
		return resourceCode;
	}
	public void setResourceCode(Long resourceCode) {
		this.resourceCode = resourceCode;
	}
	public ArrayList<Long> getMarketCodeList() {
		return marketCodeList;
	}
	public void setMarketCodeList(ArrayList<Long> marketCodeList) {
		this.marketCodeList = marketCodeList;
	}
	public ArrayList<Long> getProductList() {
		return productList;
	}
	public void setProductList(ArrayList<Long> productList) {
		this.productList = productList;
	}
	public ArrayList<Long> getResourceList() {
		return resourceList;
	}
	public void setResourceList(ArrayList<Long> resourceList) {
		this.resourceList = resourceList;
	}
}
