package com.dnb.dsc.refdata.core.vo;

import org.springframework.stereotype.Component;

/**
 * This class used as a value object class.
 * 
 * @author Cognizant
 * @version last updated : August 21, 2014
 * @see
 * 
 */


@Component
public class ScoreSearchCriteriaVO extends PaginationVO{
	
private static final long serialVersionUID = 2L;
	
	private String country;
	private String capability;
	
	
	
	/**
	 * Empty Constructor.
	 */	
	public ScoreSearchCriteriaVO(){
		super();
	}



	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}



	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}



	/**
	 * @return the capability
	 */
	public String getCapability() {
		return capability;
	}



	/**
	 * @param capability the capability to set
	 */
	public void setCapability(String capability) {
		this.capability = capability;
	}	
	
	@Override
	public String toString() {
		return "ScoreSearchCriteriaVO [country=" + country
				+ ", capability=" + capability +  "]";
	}

	

}
