/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *	Entity for finl_stmt_ln_itm_assn table
 *
 * @author Cognizant
 * @version last updated : June 14, 2012
 * @see
 *
 */
@Entity
@Table(name = "finl_stmt_ln_itm_assn")
public class FinancialStatementLineItemAssociation extends Audit{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "FINL_STMT_LN_ITM_ASSN_ID")
	private Long financialStatementLineItemAssociationId;

	@Column(name = "PRNT_FINL_STMT_TMPLT_LN_ITM_ID")
	private Long parentFinancialStatementLineItemAssociationId;
	
	@Column(name = "CHLD_FINL_STMT_TMPLT_LN_ITM_ID")
	private Long childFinancialStatementLineItemAssociationId;
	
	public FinancialStatementLineItemAssociation(){

	}

	/**
	 * @return the financialStatementLineItemAssociationId
	 */
	public Long getFinancialStatementLineItemAssociationId() {
		return financialStatementLineItemAssociationId;
	}

	/**
	 * @param financialStatementLineItemAssociationId the financialStatementLineItemAssociationId to set
	 */
	public void setFinancialStatementLineItemAssociationId(
			Long financialStatementLineItemAssociationId) {
		this.financialStatementLineItemAssociationId = financialStatementLineItemAssociationId;
	}

	/**
	 * @return the parentFinancialStatementLineItemAssociationId
	 */
	public Long getParentFinancialStatementLineItemAssociationId() {
		return parentFinancialStatementLineItemAssociationId;
	}

	/**
	 * @param parentFinancialStatementLineItemAssociationId the parentFinancialStatementLineItemAssociationId to set
	 */
	public void setParentFinancialStatementLineItemAssociationId(
			Long parentFinancialStatementLineItemAssociationId) {
		this.parentFinancialStatementLineItemAssociationId = parentFinancialStatementLineItemAssociationId;
	}

	/**
	 * @return the childFinancialStatementLineItemAssociationId
	 */
	public Long getChildFinancialStatementLineItemAssociationId() {
		return childFinancialStatementLineItemAssociationId;
	}

	/**
	 * @param childFinancialStatementLineItemAssociationId the childFinancialStatementLineItemAssociationId to set
	 */
	public void setChildFinancialStatementLineItemAssociationId(
			Long childFinancialStatementLineItemAssociationId) {
		this.childFinancialStatementLineItemAssociationId = childFinancialStatementLineItemAssociationId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FinancialStatementLineItemAssociation [financialStatementLineItemAssociationId="
				+ financialStatementLineItemAssociationId
				+ ", parentFinancialStatementLineItemAssociationId="
				+ parentFinancialStatementLineItemAssociationId
				+ ", childFinancialStatementLineItemAssociationId="
				+ childFinancialStatementLineItemAssociationId + "]";
	}

}
