package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.ScoreGranularity;

public class ProductScoreMappingVO
	 implements Serializable {

			private static final long serialVersionUID = 8993265291802855778L;
			/**
			 * The code attribute
			 */
			private Long productCode;
			/**
			 *  productVersion.
			 */
			private Long productVersion;
			/**
			 *  productFamilyCode.
			 */
			private Long productFamilyCode;
			/**
			 *  productGroupCode.
			 */
			private Long productGroupCode;
			/**
			 *  productMetadataCode.
			 */
			private Long productMetadataCode;
			/**
			 *  productMetadataValue.
			 */
			private String productMetadataValue;
			/**
			 *  productResources.
			 */
			private List<ProductResources> productResources;
			/**
			 *  salesChannelCode.
			 */
			private Long salesChannelCode;
			/**
			 *  salesVersion.
			 */
			private Long salesVersion;
			/**
			 *  salesMetadataCode.
			 */
			private Long salesMetadataCode;
			/**
			 *  salesMetadataValue.
			 */
			private String salesMetadataValue;
			/**
			 *  countryList.
			 */
			private List<Long> countryList;
			/**
			 *  country.
			 */
			private Long country;
			/**
			 *  marketGroupCode.
			 */
			private Long marketGroupCode;
			/**
			 *  productResource.
			 */
			private ProductResources productResource;	
			
			/**
			 *  resourceCodesString.
			 */
			private String resourceCodesString;
			
			private Long prodId;
			private Long prodAvailId;
			private Long saleChnlid;
			private Long prodMktId;
			private Long rescMapId;
			private Long rescId;
			private Long prodGrpId;
			private Long prodDtlId;
			private Long mktGrpId;
			private Long rescGrpId;
			private Long rescDtlID;
			private Long slsChnlDtlID;	
			
			private String resourceString;
			private String granularityString;		
			
			private String isSearch;	
			
			public String getResourceString() {
				return resourceString;
			}
			public void setResourceString(String resourceString) {
				this.resourceString = resourceString;
			}
			public String getGranularityString() {
				return granularityString;
			}
			public void setGranularityString(String granularityString) {
				this.granularityString = granularityString;
			}
			public Long getProdId() {
				return prodId;
			}
			public void setProdId(Long prodId) {
				this.prodId = prodId;
			}
			public Long getProdAvailId() {
				return prodAvailId;
			}
			public void setProdAvailId(Long prodAvailId) {
				this.prodAvailId = prodAvailId;
			}
			public Long getSaleChnlid() {
				return saleChnlid;
			}
			public void setSaleChnlid(Long saleChnlid) {
				this.saleChnlid = saleChnlid;
			}
			public Long getProdMktId() {
				return prodMktId;
			}
			public void setProdMktId(Long prodMktId) {
				this.prodMktId = prodMktId;
			}
			public Long getRescMapId() {
				return rescMapId;
			}
			public void setRescMapId(Long rescMapId) {
				this.rescMapId = rescMapId;
			}
			public Long getRescId() {
				return rescId;
			}
			public void setRescId(Long rescId) {
				this.rescId = rescId;
			}
			public Long getProdGrpId() {
				return prodGrpId;
			}
			public void setProdGrpId(Long prodGrpId) {
				this.prodGrpId = prodGrpId;
			}
			public Long getProdDtlId() {
				return prodDtlId;
			}
			public void setProdDtlId(Long prodDtlId) {
				this.prodDtlId = prodDtlId;
			}
			public Long getMktGrpId() {
				return mktGrpId;
			}
			public void setMktGrpId(Long mktGrpId) {
				this.mktGrpId = mktGrpId;
			}
			public Long getRescGrpId() {
				return rescGrpId;
			}
			public void setRescGrpId(Long rescGrpId) {
				this.rescGrpId = rescGrpId;
			}
			public Long getRescDtlID() {
				return rescDtlID;
			}
			public void setRescDtlID(Long rescDtlID) {
				this.rescDtlID = rescDtlID;
			}
			public Long getSlsChnlDtlID() {
				return slsChnlDtlID;
			}
			public void setSlsChnlDtlID(Long slsChnlDtlID) {
				this.slsChnlDtlID = slsChnlDtlID;
			}
			public Long getCountry() {
				return country;
			}
			public void setCountry(Long country) {
				this.country = country;
			}
			public ProductResources getProductResource() {
				return productResource;
			}
			public void setProductResource(ProductResources productResource) {
				this.productResource = productResource;
			}
			/**
			 * @return the productCode
			 */
			public Long getProductCode() {
				return productCode;
			}
			/**
			 * @param productCode the productCode to set
			 */
			public void setProductCode(Long productCode) {
				this.productCode = productCode;
			}
			/**
			 * @return the productVersion
			 */
			public Long getProductVersion() {
				return productVersion;
			}
			/**
			 * @param productVersion the productVersion to set
			 */
			public void setProductVersion(Long productVersion) {
				this.productVersion = productVersion;
			}
			/**
			 * @return the productFamilyCode
			 */
			public Long getProductFamilyCode() {
				return productFamilyCode;
			}
			/**
			 * @param list the productFamilyCode to set
			 */
			public void setProductFamilyCode(Long list) {
				this.productFamilyCode = list;
			}
			/**
			 * @return the productGroupCode
			 */
			public Long getProductGroupCode() {
				return productGroupCode;
			}
			/**
			 * @param productGroupCode the productGroupCode to set
			 */
			public void setProductGroupCode(Long productGroupCode) {
				this.productGroupCode = productGroupCode;
			}
			/**
			 * @return the productMetadataCode
			 */
			public Long getProductMetadataCode() {
				return productMetadataCode;
			}
			/**
			 * @param productMetadataCode the productMetadataCode to set
			 */
			public void setProductMetadataCode(Long productMetadataCode) {
				this.productMetadataCode = productMetadataCode;
			}
			/**
			 * @return the productMetadataValue
			 */
			public String getProductMetadataValue() {
				return productMetadataValue;
			}
			/**
			 * @param productMetadataValue the productMetadataValue to set
			 */
			public void setProductMetadataValue(String productMetadataValue) {
				this.productMetadataValue = productMetadataValue;
			}
			/**
			 * @return the productResources
			 */
			public List<ProductResources> getProductResources() {
				return productResources;
			}
			/**
			 * @param productResources the productResources to set
			 */
			public void setProductResources(List<ProductResources> productResources) {
				this.productResources = productResources;
			}
			/**
			 * @return the salesChannelCode
			 */
			public Long getSalesChannelCode() {
				return salesChannelCode;
			}
			/**
			 * @param salesChannelCode the salesChannelCode to set
			 */
			public void setSalesChannelCode(Long salesChannelCode) {
				this.salesChannelCode = salesChannelCode;
			}
			/**
			 * @return the salesVersion
			 */
			public Long getSalesVersion() {
				return salesVersion;
			}
			/**
			 * @param salesVersion the salesVersion to set
			 */
			public void setSalesVersion(Long salesVersion) {
				this.salesVersion = salesVersion;
			}
			/**
			 * @return the salesMetadataCode
			 */
			public Long getSalesMetadataCode() {
				return salesMetadataCode;
			}
			/**
			 * @param salesMetadataCode the salesMetadataCode to set
			 */
			public void setSalesMetadataCode(Long salesMetadataCode) {
				this.salesMetadataCode = salesMetadataCode;
			}
			/**
			 * @return the salesMetadataValue
			 */
			public String getSalesMetadataValue() {
				return salesMetadataValue;
			}
			/**
			 * @param salesMetadataValue the salesMetadataValue to set
			 */
			public void setSalesMetadataValue(String salesMetadataValue) {
				this.salesMetadataValue = salesMetadataValue;
			}
			/**
			 * @return the countryList
			 */
			public List<Long> getCountryList() {
				return countryList;
			}
			/**
			 * @param countryList the countryList to set
			 */
			public void setCountryList(List<Long> countryList) {
				this.countryList = countryList;
			}
			/**
			 * @return the marketGroupCode
			 */
			public Long getMarketGroupCode() {
				return marketGroupCode;
			}
			/**
			 * @param marketGroupCode the marketGroupCode to set
			 */
			public void setMarketGroupCode(Long marketGroupCode) {
				this.marketGroupCode = marketGroupCode;
			}			
			private Long scoreTypeCode;

			private Long scoreMarketCode;

			private Double scoreVersion;
			
			private List<ScoreMappingListVO> scoreMappingList;
			
			private String loggedInUser;
			
			private List<Double> scoreVersionList;
			private List<ScoreGranularity> scoreGranularity;
			private List<CodeValue> scoreMarketCodes;
			private List<CodeValue> scoreTyp;
			private List<CodeValue> scoreGraCodes;
			private List<CodeValue> scoreAttributeCodes;			
			
			private List<Long> scoreGranularty;
			
			public List<Long> getScoreGranularty() {
				return scoreGranularty;
			}

			public void setScoreGranularty(List<Long> scoreGranularty) {
				this.scoreGranularty = scoreGranularty;
			}

			public List<Double> getScoreVersionList() {
				return scoreVersionList;
			}

			public void setScoreVersionList(List<Double> scoreVersionList) {
				this.scoreVersionList = scoreVersionList;
			}

			public String getLoggedInUser() {
				return loggedInUser;
			}

			public void setLoggedInUser(String loggedInUser) {
				this.loggedInUser = loggedInUser;
			}

			public List<CodeValue> getScoreMarketCodes() {
				return scoreMarketCodes;
			}

			public void setScoreMarketCodes(List<CodeValue> scoreMarketCodes) {
				this.scoreMarketCodes = scoreMarketCodes;
			}

			public List<CodeValue> getScoreTyp() {
				return scoreTyp;
			}

			public void setScoreTyp(List<CodeValue> scoreTyp) {
				this.scoreTyp = scoreTyp;
			}

			public List<CodeValue> getScoreGraCodes() {
				return scoreGraCodes;
			}

			public void setScoreGraCodes(List<CodeValue> scoreGraCodes) {
				this.scoreGraCodes = scoreGraCodes;
			}

			public List<CodeValue> getScoreAttributeCodes() {
				return scoreAttributeCodes;
			}

			public void setScoreAttributeCodes(List<CodeValue> scoreAttributeCodes) {
				this.scoreAttributeCodes = scoreAttributeCodes;
			}

			public Long getScoreTypeCode() {
				return scoreTypeCode;
			}

			public void setScoreTypeCode(Long scoreTypeCode) {
				this.scoreTypeCode = scoreTypeCode;
			}

			public Long getScoreMarketCode() {
				return scoreMarketCode;
			}

			public void setScoreMarketCode(Long scoreMarketCode) {
				this.scoreMarketCode = scoreMarketCode;
			}

			public Double getScoreVersion() {
				return scoreVersion;
			}

			public void setScoreVersion(Double scoreVersion) {
				this.scoreVersion = scoreVersion;
			}

			public List<ScoreGranularity> getScoreGranularity() {
				return scoreGranularity;
			}

			public void setScoreGranularity(List<ScoreGranularity> scoreGranularity) {
				this.scoreGranularity = scoreGranularity;
			}

			public static long getSerialversionuid() {
				return serialVersionUID;
			}
			/**
			 * @param scoreMappingList the scoreMappingList to set
			 */
			public void setScoreMappingList(List<ScoreMappingListVO> scoreMappingList) {
				this.scoreMappingList = scoreMappingList;
			}
			/**
			 * @return the scoreMappingList
			 */
			public List<ScoreMappingListVO> getScoreMappingList() {
				return scoreMappingList;
			}
			/**
			 * @param resourceCodesString the resourceCodesString to set
			 */
			public void setResourceCodesString(String resourceCodesString) {
				this.resourceCodesString = resourceCodesString;
			}
			/**
			 * @return the resourceCodesString
			 */
			public String getResourceCodesString() {
				return resourceCodesString;
			}		
			/**
			 * @param isSearch the isSearch to set
			 */
			public void setIsSearch(String isSearch) {
				this.isSearch = isSearch;
			}
			/**
			 * @return the isSearch
			 */
			public String getIsSearch() {
				return isSearch;
			}


}
