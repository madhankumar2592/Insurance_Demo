package com.dnb.dsc.refdata.core.vo;

import com.dnb.dsc.refdata.core.entity.DnbUnusAdr;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsyCtryAppy;
import com.dnb.dsc.refdata.core.entity.DnbUnusIndNme;
import com.dnb.dsc.refdata.core.entity.DnbUnusTlcmAdr;

public class DNBUnusableGlsyBulkUploadMasterVO {
	private DnbUnusGlsy dnbUnusGlsy;
	private DnbUnusIndNme dnbUnusIndNme;
	private DnbUnusAdr dnbUnusAdr;
	private DnbUnusGlsyCtryAppy dnbUnusGlsyCtryAppy;
	private DnbUnusTlcmAdr dnbUnusTlcmAdr;
	private Integer errorCD;
	/**
	 * @return the errorCD
	 */
	public Integer getErrorCD() {
		return errorCD;
	}
	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(Integer errorCD) {
		this.errorCD = errorCD;
	}
	/**
	 * @return the dnbUnusGlsy
	 */
	public DnbUnusGlsy getDnbUnusGlsy() {
		return dnbUnusGlsy;
	}
	/**
	 * @param dnbUnusGlsy the dnbUnusGlsy to set
	 */
	public void setDnbUnusGlsy(DnbUnusGlsy dnbUnusGlsy) {
		this.dnbUnusGlsy = dnbUnusGlsy;
	}
	/**
	 * @return the dnbUnusIndNme
	 */
	public DnbUnusIndNme getDnbUnusIndNme() {
		return dnbUnusIndNme;
	}
	/**
	 * @param dnbUnusIndNme the dnbUnusIndNme to set
	 */
	public void setDnbUnusIndNme(DnbUnusIndNme dnbUnusIndNme) {
		this.dnbUnusIndNme = dnbUnusIndNme;
	}
	/**
	 * @return the dnbUnusAdr
	 */
	public DnbUnusAdr getDnbUnusAdr() {
		return dnbUnusAdr;
	}
	/**
	 * @param dnbUnusAdr the dnbUnusAdr to set
	 */
	public void setDnbUnusAdr(DnbUnusAdr dnbUnusAdr) {
		this.dnbUnusAdr = dnbUnusAdr;
	}
	/**
	 * @return the dnbUnusGlsyCtryAppy
	 */
	public DnbUnusGlsyCtryAppy getDnbUnusGlsyCtryAppy() {
		return dnbUnusGlsyCtryAppy;
	}
	/**
	 * @param dnbUnusGlsyCtryAppy the dnbUnusGlsyCtryAppy to set
	 */
	public void setDnbUnusGlsyCtryAppy(DnbUnusGlsyCtryAppy dnbUnusGlsyCtryAppy) {
		this.dnbUnusGlsyCtryAppy = dnbUnusGlsyCtryAppy;
	}
	/**
	 * @return the dnbUnusTlcmAdr
	 */
	public DnbUnusTlcmAdr getDnbUnusTlcmAdr() {
		return dnbUnusTlcmAdr;
	}
	/**
	 * @param dnbUnusTlcmAdr the dnbUnusTlcmAdr to set
	 */
	public void setDnbUnusTlcmAdr(DnbUnusTlcmAdr dnbUnusTlcmAdr) {
		this.dnbUnusTlcmAdr = dnbUnusTlcmAdr;
	}
	
	

}
