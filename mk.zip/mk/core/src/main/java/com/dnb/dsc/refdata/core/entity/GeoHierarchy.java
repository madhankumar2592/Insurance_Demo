/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * This class used as an entity class for the GeoHierarchy. The class will have
 * a direct mapping toe DB table GEO_HIERARCHY.
 * 
 * @author Cognizant
 * @version last updated : Mar 05, 2012
 * @see
 * 
 */
@Entity
@Table(name = "UI_GEO_HIER")
@NamedQueries({
	@NamedQuery(name = "GeoHierarchy.getHierarchyByGeoUnitId", query = "SELECT new GeoHierarchy(g.parentGeoUnitTypeCode, g.childGeoUnitTypeCode, g.isRootIndicator, g.childGeoUnitTypeDescription) FROM GeoHierarchy g where g.geoUnitId = :geoUnitId"), 
	@NamedQuery(name = "GeoHierarchy.retrieveGeoUnitTypeByGeoUnitId",query = "SELECT distinct new GeoHierarchy(g.childGeoUnitTypeCode,g.childGeoUnitTypeDescription) FROM GeoHierarchy g WHERE g.geoUnitId = :geoUnitId"),
	@NamedQuery(name = "GeoHierarchy.retrieveGeoUnitHierarchyByGeoUnitId",query = "SELECT distinct new GeoHierarchy(g.parentGeoUnitTypeCode,g.childGeoUnitTypeCode) FROM GeoHierarchy g WHERE g.geoUnitId = :geoUnitId")
	})	
public class GeoHierarchy implements Serializable {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "UI_GEO_HIER_ID")
	private Long geoHierarchyId;	

	@Column(name = "CTRY_GEO_UNIT_ID")
	private Long geoUnitId;

	@Column(name = "PRNT_GEO_UNIT_TYP_CD")
	private Long parentGeoUnitTypeCode;
	
	@Column(name = "CHLD_GEO_UNIT_TYP_CD")
	private Long childGeoUnitTypeCode;
	
	@Column(name = "CHLD_GEO_UNIT_TYP_DESC")
	private String childGeoUnitTypeDescription;
	
	@Column(name = "ROOT_INDC")
	private Boolean isRootIndicator;
	
	@Column(name = "DEFU_HIER_INDC")
	private Boolean isDefaultHierarchy;
	
	@Transient
	private String prntGeoUnitTypeDescription;
	

	/**
	 * Constructor
	 */
	public GeoHierarchy() {
		super();
	}
	
	public GeoHierarchy(Long parentGeoUnitTypeCode, 
						Long childGeoUnitTypeCode,
						Boolean isRootIndicator,
						String childGeoUnitTypeDescription){
		this.parentGeoUnitTypeCode = parentGeoUnitTypeCode;
		this.childGeoUnitTypeCode = childGeoUnitTypeCode;
		this.isRootIndicator = isRootIndicator;
		this.childGeoUnitTypeDescription = childGeoUnitTypeDescription;	
	}
	
	public GeoHierarchy(Long childGeoUnitTypeCode,
			String childGeoUnitTypeDescription){
		this.childGeoUnitTypeCode = childGeoUnitTypeCode;
		this.childGeoUnitTypeDescription = childGeoUnitTypeDescription;	
	}
	
	public GeoHierarchy(Long parentGeoUnitTypeCode,
			Long childGeoUnitTypeCode){
		this.parentGeoUnitTypeCode = parentGeoUnitTypeCode;
		this.childGeoUnitTypeCode = childGeoUnitTypeCode;
	}
	
	/**
	 * @return the geoHierarchyId
	 */
	public Long getGeoHierarchyId() {
		return geoHierarchyId;
	}


	/**
	 * @param geoHierarchyId the geoHierarchyId to set
	 */
	public void setGeoHierarchyId(Long geoHierarchyId) {
		this.geoHierarchyId = geoHierarchyId;
	}


	/**
	 * @return the geoUnitId
	 */
	public Long getGeoUnitId() {
		return geoUnitId;
	}

	/**
	 * @param geoUnitId the geoUnitId to set
	 */
	public void setGeoUnitId(Long geoUnitId) {
		this.geoUnitId = geoUnitId;
	}

	/**
	 * @return the parentGeoUnitTypeCode
	 */
	public Long getParentGeoUnitTypeCode() {
		return parentGeoUnitTypeCode;
	}

	/**
	 * @param parentGeoUnitTypeCode the parentGeoUnitTypeCode to set
	 */
	public void setParentGeoUnitTypeCode(Long parentGeoUnitTypeCode) {
		this.parentGeoUnitTypeCode = parentGeoUnitTypeCode;
	}

	/**
	 * @return the childGeoUnitTypeCode
	 */
	public Long getChildGeoUnitTypeCode() {
		return childGeoUnitTypeCode;
	}

	/**
	 * @param childGeoUnitTypeCode the childGeoUnitTypeCode to set
	 */
	public void setChildGeoUnitTypeCode(Long childGeoUnitTypeCode) {
		this.childGeoUnitTypeCode = childGeoUnitTypeCode;
	}

	/**
	 * @return the isRootIndicator
	 */
	public Boolean getIsRootIndicator() {
		return isRootIndicator;
	}

	/**
	 * @param isRootIndicator the isRootIndicator to set
	 */
	public void setIsRootIndicator(Boolean isRootIndicator) {
		this.isRootIndicator = isRootIndicator;
	}
	
	/**
	 * @return the childGeoUnitTypeDescription
	 */
	public String getChildGeoUnitTypeDescription() {
		return childGeoUnitTypeDescription;
	}

	/**
	 * @param childGeoUnitTypeDescription the childGeoUnitTypeDescription to set
	 */
	public void setChildGeoUnitTypeDescription(String childGeoUnitTypeDescription) {
		this.childGeoUnitTypeDescription = childGeoUnitTypeDescription;
	}

	/**
	 * @return the isDefaultHierarchy
	 */
	public Boolean getIsDefaultHierarchy() {
		return isDefaultHierarchy;
	}

	/**
	 * @param isDefaultHierarchy the isDefaultHierarchy to set
	 */
	public void setIsDefaultHierarchy(Boolean isDefaultHierarchy) {
		this.isDefaultHierarchy = isDefaultHierarchy;
	}
	

	

	/**
	 * @return the prntGeoUnitTypeDescription
	 */
	public String getPrntGeoUnitTypeDescription() {
		return prntGeoUnitTypeDescription;
	}

	/**
	 * @param prntGeoUnitTypeDescription the prntGeoUnitTypeDescription to set
	 */
	public void setPrntGeoUnitTypeDescription(String prntGeoUnitTypeDescription) {
		this.prntGeoUnitTypeDescription = prntGeoUnitTypeDescription;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GeoHierarchy [geoHierarchyId=" + geoHierarchyId
				+ ", geoUnitId=" + geoUnitId + ", parentGeoUnitTypeCode="
				+ parentGeoUnitTypeCode + ", childGeoUnitTypeCode="
				+ childGeoUnitTypeCode + ", childGeoUnitTypeDescription="
				+ childGeoUnitTypeDescription + ", isRootIndicator="
				+ isRootIndicator + "]";
	}
}
