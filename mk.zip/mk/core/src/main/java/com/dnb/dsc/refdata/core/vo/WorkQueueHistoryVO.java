/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

/**
 * This class used as an value object class.
 * 
 * @author Cognizant
 * @version last updated : Dec 09, 2011
 * @see
 * 
 */
public class WorkQueueHistoryVO {
	String submittedBy;
	String submittedOn;
	String reviewedBy;
	String reviewedOn;
	String status;
	String reason;

	/**
	 * 
	 * @param submittedBy
	 * @param submittedOn
	 * @param reviewedBy
	 * @param reviewedOn
	 * @param status
	 * @param reason
	 */
	public WorkQueueHistoryVO(String submittedBy, String submittedOn,
			String reviewedBy, String reviewedOn, String status, String reason) {
		super();

		this.submittedBy = submittedBy != null ? submittedBy : " - ";
		this.submittedOn = submittedOn != null ? submittedOn : " - ";
		this.reviewedBy = reviewedBy != null ? reviewedBy : " - ";
		this.reviewedOn = reviewedOn != null ? reviewedOn : " - ";
		this.status = status != null ? status : " - ";
		this.reason = reason != null ? reason : " - ";
	}

	/**
	 * @return the submittedBy
	 */
	public String getSubmittedBy() {
		return submittedBy;
	}

	/**
	 * @param submittedBy the submittedBy to set
	 */
	public void setSubmittedBy(String submittedBy) {
		this.submittedBy = submittedBy;
	}

	/**
	 * @return the submittedOn
	 */
	public String getSubmittedOn() {
		return submittedOn;
	}

	/**
	 * @param submittedOn the submittedOn to set
	 */
	public void setSubmittedOn(String submittedOn) {
		this.submittedOn = submittedOn;
	}

	/**
	 * @return the reviewedBy
	 */
	public String getReviewedBy() {
		return reviewedBy;
	}

	/**
	 * @param reviewedBy the reviewedBy to set
	 */
	public void setReviewedBy(String reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	/**
	 * @return the reviewedOn
	 */
	public String getReviewedOn() {
		return reviewedOn;
	}

	/**
	 * @param reviewedOn the reviewedOn to set
	 */
	public void setReviewedOn(String reviewedOn) {
		this.reviewedOn = reviewedOn;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}
}
