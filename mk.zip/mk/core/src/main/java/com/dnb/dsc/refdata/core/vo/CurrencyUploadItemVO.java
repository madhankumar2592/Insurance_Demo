/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import org.springframework.web.multipart.MultipartFile;
/**
 * This class used as an value object class.
 * 
 * @author Cognizant
 * @version last updated : May 09, 2012
 * @see
 * 
 */
public class CurrencyUploadItemVO {

	private MultipartFile file;

	/**
	 * 
	 * @param file
	 */
	public void setFile(MultipartFile file) {
		this.file = file;
	}

	/**
	 * 
	 * @return file
	 */
	public MultipartFile getFile() {
		return file;
	}

}
