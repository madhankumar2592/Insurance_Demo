package com.dnb.dsc.refdata.core.vo;

import com.dnb.dsc.refdata.core.entity.IndustryCodeInferment;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.InfermentTextCountryApplicability;
import com.dnb.dsc.refdata.core.entity.LegalFormInferment;

public class InfermentBulkUploadMasterVO {
	private InfermentText infermentText;
	private InfermentTextCountryApplicability inferTxtCtyAppy;
	private IndustryCodeInferment indsCodeInferment;
	private LegalFormInferment lglFormInferment;
	/**
	 * @return the infermentText
	 */
	public InfermentText getInfermentText() {
		return infermentText;
	}
	/**
	 * @param infermentText the infermentText to set
	 */
	public void setInfermentText(InfermentText infermentText) {
		this.infermentText = infermentText;
	}
	/**
	 * @return the inferTxtCtyAppy
	 */
	public InfermentTextCountryApplicability getInferTxtCtyAppy() {
		return inferTxtCtyAppy;
	}
	/**
	 * @param inferTxtCtyAppy the inferTxtCtyAppy to set
	 */
	public void setInferTxtCtyAppy(InfermentTextCountryApplicability inferTxtCtyAppy) {
		this.inferTxtCtyAppy = inferTxtCtyAppy;
	}
	/**
	 * @return the indsCodeInferment
	 */
	public IndustryCodeInferment getIndsCodeInferment() {
		return indsCodeInferment;
	}
	/**
	 * @param indsCodeInferment the indsCodeInferment to set
	 */
	public void setIndsCodeInferment(IndustryCodeInferment indsCodeInferment) {
		this.indsCodeInferment = indsCodeInferment;
	}
	/**
	 * @return the lglFormInferment
	 */
	public LegalFormInferment getLglFormInferment() {
		return lglFormInferment;
	}
	/**
	 * @param lglFormInferment the lglFormInferment to set
	 */
	public void setLglFormInferment(LegalFormInferment lglFormInferment) {
		this.lglFormInferment = lglFormInferment;
	}
	
	
}
