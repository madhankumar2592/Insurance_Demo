package com.dnb.dsc.refdata.core.vo;

public class ReferenceDataExceptionVO extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	private String errorCode;
	private String errorMessage;
	private Object errorObject;

	public ReferenceDataExceptionVO(String errorMessage) {
        super(errorMessage);
        this.errorMessage = errorMessage;
    }
	
	public ReferenceDataExceptionVO(String errorCode, String errorMessage) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }
	
	public ReferenceDataExceptionVO(String errorCode, String errorMessage,
				Object errorObject) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.errorObject = errorObject;
    }

	public ReferenceDataExceptionVO(String errorCode, Object errorObject) {
    super(errorCode);
    this.errorCode = errorCode;
    this.errorObject = errorObject;
}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the errorObject
	 */
	public Object getErrorObject() {
		return errorObject;
	}

	/**
	 * @param errorObject the errorObject to set
	 */
	public void setErrorObject(Object errorObject) {
		this.errorObject = errorObject;
	}
}
