/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "SCR_TYP")
@NamedQueries({
		@NamedQuery(name = "ScoreType.retrieveCountForScoreTypeCode", query = "SELECT count(s.scoreTypeId) FROM ScoreType s where s.scoreTypeCode= :scoreTypeCode"),
		@NamedQuery(name = "ScoreType.retrieveScoreTypeCode", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT distinct d.scoreTypeCode FROM ScoreType d) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
		@NamedQuery(name = "ScoreType.retrieveMarketTypeCode", query = "SELECT new GeoUnitName(n.geoUnitNameId, n.geoUnitId, n.languageCode, n.nameTypeCode, n.geoName, n.dataProviderCode) FROM GeoUnitName n where n.geoUnitId in (SELECT s.scoreMarketCode FROM Score s where s.scoreTypeId in (SELECT d.scoreTypeId FROM ScoreType d where d.scoreTypeCode=:scoreType))and n.languageCode = 39 and n.writingScriptCode = 19349 and n.nameTypeCode = 32 order by n.geoName"),
		@NamedQuery(name = "ScoreType.findScoreTypeCodeValues", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT distinct(d.scoreTypeCode) FROM ScoreType d) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
		@NamedQuery(name = "ScoreType.retreiveMarketCode", query = "select new GeoUnitName(g.geoUnitId,g.geoName) from GeoUnitName g where g.geoUnitId in (select s.scoreMarketCode from Score s where s.scoreTypeId in (select st.scoreTypeId from ScoreType st where st.scoreTypeCode = :scoreTypeCode)) and g.languageCode = 39 and g.nameTypeCode = 32 order by g.geoName"),
		@NamedQuery(name = "ScoreType.retreiveVersion", query = "select new Score(s.scoreVersion) from Score s where s.scoreTypeId in (select st.scoreTypeId from ScoreType st where st.scoreTypeCode = :scoreTypeCode) and s.scoreMarketCode = :scoreMktCode order by s.modifiedDate desc"),
		@NamedQuery(name = "ScoreType.retreiveGranularityCodeValues", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (select scoreGraCode from ScoreGranularity where scoreGraId in (select scoreGraId from ScoreTypeAssc where scoreTypeId in (select scoreTypeId from ScoreType where scoreTypeCode = :scoreTypeCode))) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
		@NamedQuery(name = "ScoreType.findGruTypeCodeValues", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT distinct(d.scoreGraCode) FROM ScoreGranularity d) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
		@NamedQuery(name = "ScoreType.retreiveGranularityValues", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where  t.codeValueId in (SELECT distinct(s.scoreGraCode) FROM ScoreGranularity s where s.scoreGraId in (select distinct(a.scoreGraId) from ScoreTypeAssc a where  a.scoreTypAsscId in (select distinct(d.scoreTypeAssociationId) from  ScoreDetail d where d.scoreId in (select i.scoreId from Score i where i.scoreMarketCode =  :scrMktCode and i.scoreVersion = :scrVers and i.scoreTypeId in (select f.scoreTypeId from ScoreType f where f.scoreTypeCode =  :scoreTypeCode))))) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription")
		//@NamedQuery(name = "ScoreType.retrieveScoreTypeCode", query = "SELECT new ScoreType(s.scoreTypeCode) FROM ScoreType s")
				})
public class ScoreType extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "SCR_TYP_ID")
	private Long scoreTypeId;
	
	@Column(name = "SCR_TYP_CD")
	private Long scoreTypeCode;
	
	@Column(name = "INAC_INDC")
	private Long inactiveIndicator;
	
	@OneToMany(mappedBy = "scoreTypeId", cascade = CascadeType.ALL)
	private List<ScoreTypeAssociation> ScoreTypeAssociations;
		
	/**
	 * @return the scoreTypeId
	 */
	public Long getScoreTypeId() {
		return scoreTypeId;
	}

	/**
	 * @param scoreTypeId the scoreTypeId to set
	 */
	public void setScoreTypeId(Long scoreTypeId) {
		this.scoreTypeId = scoreTypeId;
	}

	/**
	 * @return the scoreTypeCode
	 */
	public Long getScoreTypeCode() {
		return scoreTypeCode;
	}

	/**
	 * @param scoreTypeCode the scoreTypeCode to set
	 */
	public void setScoreTypeCode(Long scoreTypeCode) {
		this.scoreTypeCode = scoreTypeCode;
	}

	/**
	 * @return the scoreTypeAssociations
	 */
	public List<ScoreTypeAssociation> getScoreTypeAssociations() {
		return ScoreTypeAssociations;
	}

	/**
	 * @param scoreTypeAssociations the scoreTypeAssociations to set
	 */
	public void setScoreTypeAssociations(
			List<ScoreTypeAssociation> scoreTypeAssociations) {
		ScoreTypeAssociations = scoreTypeAssociations;
	}

	/**
	 * @return the inactiveIndicator
	 */
	public Long getInactiveIndicator() {
		return inactiveIndicator;
	}

	/**
	 * @param inactiveIndicator the inactiveIndicator to set
	 */
	public void setInactiveIndicator(Long inactiveIndicator) {
		this.inactiveIndicator = inactiveIndicator;
	}
	
	/**
	 * Empty Constructor.
	 */
	public ScoreType() {
		super();
	}
	public ScoreType(Long scoreTypeId) {
		super();
		this.scoreTypeId = scoreTypeId;
	}
	public ScoreType(Long scoreTypeCode,Long inactiveIndicator) {
		super();
		this.scoreTypeCode = scoreTypeCode;
		this.inactiveIndicator = inactiveIndicator;
	}
	/*public ScoreType(Long scoreTypeCode) {
		super();
		this.scoreTypeCode = scoreTypeCode;
	}*/
	/**
	 * 
	 * @param scoreTypeId
	 * @param scoreTypeCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public ScoreType(Long scoreTypeId, Long scoreTypeCode,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate, Long inactiveIndicator
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.scoreTypeId = scoreTypeId;
		this.scoreTypeCode = scoreTypeCode;
		this.inactiveIndicator = inactiveIndicator;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ScoreTypeId [scoreTypeId=" + scoreTypeId
				+ ", scoreTypeCode=" + scoreTypeCode + 
				 "]";
	}
	
	
}
