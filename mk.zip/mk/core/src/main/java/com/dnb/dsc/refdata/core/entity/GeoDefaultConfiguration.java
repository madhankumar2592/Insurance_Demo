/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class used as an entity class for the GeoDefaultConfiguration. The class
 * will have a direct mapping toe DB table GEO_DFLT_CONFIG.
 * 
 * @author Cognizant
 * @version last updated : Mar 07, 2012
 * @see
 * 
 */
@Entity
@Table(name = "UI_CTRY_DEFU_LANG")
public class GeoDefaultConfiguration implements Serializable {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "CTRY_GEO_UNIT_ID")
	private Long geoUnitId;

	@Column(name = "DEFU_LANG_CD")
	private Long defaultLanguageCode;

	/**
	 * Constructor
	 */
	public GeoDefaultConfiguration() {
		super();
	}

	/**
	 * @return the geoUnitId
	 */
	public Long getGeoUnitId() {
		return geoUnitId;
	}

	/**
	 * @param geoUnitId the geoUnitId to set
	 */
	public void setGeoUnitId(Long geoUnitId) {
		this.geoUnitId = geoUnitId;
	}

	/**
	 * @return the defaultLanguageCode
	 */
	public Long getDefaultLanguageCode() {
		return defaultLanguageCode;
	}

	/**
	 * @param defaultLanguageCode the defaultLanguageCode to set
	 */
	public void setDefaultLanguageCode(Long defaultLanguageCode) {
		this.defaultLanguageCode = defaultLanguageCode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GeoDefaultConfiguration [geoUnitId=" + geoUnitId
				+ ", defaultLanguageCode=" + defaultLanguageCode + "]";
	}
}
