package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "HLP_HINT")
@NamedQueries({
		@NamedQuery(name = "HelpfulHint.retrieveHintsDesc", query = "SELECT new HelpfulHint(hh.helpfulHintTypeIdentifier,hh.helpfulHintText) FROM HelpfulHint hh order by hh.helpfulHintTypeIdentifier,hh.helpfulHintIdentifier ")		
		})
public class HelpfulHint extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "HLP_HINT_ID")
	private Long helpfulHintIdentifier;
	
	@Column(name = "HLP_HINT_DOMN_CD")
	private Long helpfulHintDomainCode;
	
	@Column(name = "HLP_HINT_TYP_ID")
	private Long helpfulHintTypeIdentifier;
	
	@Column(name = "HLP_HINT_LANG_CD")
	private Long helpfulHintLanguageCode;
	
	@Column(name = "HLP_HINT_ORDR_ID")
	private Long helpfulHintOrderIdentifier;
	
	@Column(name = "HLP_HINT_TXT")
	private String helpfulHintText;
	
	
	public HelpfulHint(){
		super();
	}
	
	public HelpfulHint(Long helpfulHintTypeIdentifier,String helpfulHintText){
		this.helpfulHintTypeIdentifier = helpfulHintTypeIdentifier;
		this.helpfulHintText = helpfulHintText;		
	}
	
	/**
	 * @return the helpfulHintIdentifier
	 */
	public Long getHelpfulHintIdentifier() {
		return helpfulHintIdentifier;
	}

	/**
	 * @param helpfulHintIdentifier the helpfulHintIdentifier to set
	 */
	public void setHelpfulHintIdentifier(Long helpfulHintIdentifier) {
		this.helpfulHintIdentifier = helpfulHintIdentifier;
	}

	/**
	 * @return the helpfulHintDomainCode
	 */
	public Long getHelpfulHintDomainCode() {
		return helpfulHintDomainCode;
	}

	/**
	 * @param helpfulHintDomainCode the helpfulHintDomainCode to set
	 */
	public void setHelpfulHintDomainCode(Long helpfulHintDomainCode) {
		this.helpfulHintDomainCode = helpfulHintDomainCode;
	}

	
	/**
	 * @return the helpfulHintLanguageCode
	 */
	public Long getHelpfulHintLanguageCode() {
		return helpfulHintLanguageCode;
	}

	/**
	 * @param helpfulHintLanguageCode the helpfulHintLanguageCode to set
	 */
	public void setHelpfulHintLanguageCode(Long helpfulHintLanguageCode) {
		this.helpfulHintLanguageCode = helpfulHintLanguageCode;
	}

	/**
	 * @return the helpfulHintOrderIdentifier
	 */
	public Long getHelpfulHintOrderIdentifier() {
		return helpfulHintOrderIdentifier;
	}

	/**
	 * @param helpfulHintOrderIdentifier the helpfulHintOrderIdentifier to set
	 */
	public void setHelpfulHintOrderIdentifier(Long helpfulHintOrderIdentifier) {
		this.helpfulHintOrderIdentifier = helpfulHintOrderIdentifier;
	}

	/**
	 * @return the helpfulHintText
	 */
	public String getHelpfulHintText() {
		return helpfulHintText;
	}

	/**
	 * @param helpfulHintText the helpfulHintText to set
	 */
	public void setHelpfulHintText(String helpfulHintText) {
		this.helpfulHintText = helpfulHintText;
	}

	/**
	 * @param helpfulHintTypeIdentifier the helpfulHintTypeIdentifier to set
	 */
	public void setHelpfulHintTypeIdentifier(Long helpfulHintTypeIdentifier) {
		this.helpfulHintTypeIdentifier = helpfulHintTypeIdentifier;
	}

	/**
	 * @return the helpfulHintTypeIdentifier
	 */
	public Long getHelpfulHintTypeIdentifier() {
		return helpfulHintTypeIdentifier;
	}

	
	
	

}
