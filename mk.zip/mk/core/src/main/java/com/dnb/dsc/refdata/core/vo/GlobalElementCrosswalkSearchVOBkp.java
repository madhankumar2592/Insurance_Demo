package com.dnb.dsc.refdata.core.vo;

public class GlobalElementCrosswalkSearchVOBkp extends PaginationVO{
	
	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	private Long globalElementId;
	private Long globalElementCrosswalkId;
	private Long globalElementMetadataCode;
	private String globalElementMetadataValue;
	private Long globalElementPlatformCode;
	private Long globalElementType;
	private String viewType;
	private String globalElementCodeDescription;
	
	public GlobalElementCrosswalkSearchVOBkp(){
		super();
	}
	GlobalElementCrosswalkSearchVOBkp(Long globalElementId,Long globalElementCrosswalkId,Long globalElementMetadataCode,String globalElementMetadataValue,
			Long globalElementPlatformCode,Long globalElementType,String globalElementCodeDescription){
		this.globalElementId=globalElementId;
		this.globalElementCrosswalkId=globalElementCrosswalkId;
		this.globalElementMetadataCode=globalElementMetadataCode;
		this.globalElementMetadataValue=globalElementMetadataValue;
		this.globalElementPlatformCode=globalElementPlatformCode;
		this.globalElementType=globalElementType;
		this.globalElementCodeDescription=globalElementCodeDescription;
	}
	/**
	 * @return the globalElementId
	 */
	public Long getGlobalElementId() {
		return globalElementId;
	}
	/**
	 * @param globalElementId the globalElementId to set
	 */
	public void setGlobalElementId(Long globalElementId) {
		this.globalElementId = globalElementId;
	}
	/**
	 * @return the globalElementCrosswalkId
	 */
	public Long getGlobalElementCrosswalkId() {
		return globalElementCrosswalkId;
	}
	/**
	 * @param globalElementCrosswalkId the globalElementCrosswalkId to set
	 */
	public void setGlobalElementCrosswalkId(Long globalElementCrosswalkId) {
		this.globalElementCrosswalkId = globalElementCrosswalkId;
	}
	/**
	 * @return the globalElementMetadataCode
	 */
	public Long getGlobalElementMetadataCode() {
		return globalElementMetadataCode;
	}
	/**
	 * @param globalElementMetadataCode the globalElementMetadataCode to set
	 */
	public void setGlobalElementMetadataCode(Long globalElementMetadataCode) {
		this.globalElementMetadataCode = globalElementMetadataCode;
	}
	/**
	 * @return the globalElementMetadataValue
	 */
	public String getGlobalElementMetadataValue() {
		return globalElementMetadataValue;
	}
	/**
	 * @param globalElementMetadataValue the globalElementMetadataValue to set
	 */
	public void setGlobalElementMetadataValue(String globalElementMetadataValue) {
		this.globalElementMetadataValue = globalElementMetadataValue;
	}
	/**
	 * @return the globalElementPlatformCode
	 */
	public Long getGlobalElementPlatformCode() {
		return globalElementPlatformCode;
	}
	/**
	 * @param globalElementPlatformCode the globalElementPlatformCode to set
	 */
	public void setGlobalElementPlatformCode(Long globalElementPlatformCode) {
		this.globalElementPlatformCode = globalElementPlatformCode;
	}
	/**
	 * @return the globalElementType
	 */
	public Long getGlobalElementType() {
		return globalElementType;
	}
	/**
	 * @param globalElementType the globalElementType to set
	 */
	public void setGlobalElementType(Long globalElementType) {
		this.globalElementType = globalElementType;
	}
	/**
	 * @return the viewType
	 */
	public String getViewType() {
		return viewType;
	}
	/**
	 * @param viewType the viewType to set
	 */
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	/**
	 * @return the globalElementCodeDescription
	 */
	public String getGlobalElementCodeDescription() {
		return globalElementCodeDescription;
	}
	/**
	 * @param globalElementCodeDescription the globalElementCodeDescription to set
	 */
	public void setGlobalElementCodeDescription(String globalElementCodeDescription) {
		this.globalElementCodeDescription = globalElementCodeDescription;
	}
	
	
}
