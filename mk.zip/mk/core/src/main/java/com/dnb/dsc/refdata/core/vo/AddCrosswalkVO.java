package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.Audit;
import com.dnb.dsc.refdata.core.entity.GloblalElementCrossWalk;

public class AddCrosswalkVO extends Audit implements Serializable{
	
	private static final long serialVersionUID = 8993265291802855778L;
	
	private Long platformCode;
	private Long globalElementCrosswalkId;
	private Long globalElementId;
	private Long globalElementPlatformCode;
	private Long globalElementTypeCode;
	private Long metadataCode;
	private String metadataValue;
	private List<AddCrosswalkVO> addCrosswalkVO;
	private List<String> metacodeValueList;
	private String codeValueDescription;
	private String isEdit;
	private List<GloblalElementCrossWalk> globlalElementCrossWalk;
	private String globalElementCrosswalkGrpNme;
	private String globalElementCrosswalkComment;
	
	public AddCrosswalkVO(){
		super();
	}
	
	public AddCrosswalkVO(Long metadataCode,String metadataValue,String globalElementCrosswalkGrpNme){
		this.metadataCode = metadataCode;
		this.metadataValue = metadataValue;
		//this.globalElementCrosswalkGrpNme=globalElementCrosswalkGrpNme;
	}
	public AddCrosswalkVO(Long globalElementCrosswalkId,Long globalElementId,Long metadataCode,String metadataValue,String globalElementCrosswalkGrpNme){
		this.globalElementCrosswalkId=globalElementCrosswalkId;
		this.globalElementId=globalElementId;
		this.metadataCode = metadataCode;
		this.metadataValue = metadataValue;
		this.globalElementCrosswalkGrpNme=globalElementCrosswalkGrpNme;
	}
	/**
	 * @return the globalElementCrosswalkId
	 */
	public Long getGlobalElementCrosswalkId() {
		return globalElementCrosswalkId;
	}

	/**
	 * @param globalElementCrosswalkId the globalElementCrosswalkId to set
	 */
	public void setGlobalElementCrosswalkId(Long globalElementCrosswalkId) {
		this.globalElementCrosswalkId = globalElementCrosswalkId;
	}

	/**
	 * @return the globalElementCrosswalkGrpNme
	 */
	public String getGlobalElementCrosswalkGrpNme() {
		return globalElementCrosswalkGrpNme;
	}

	/**
	 * @param globalElementCrosswalkGrpNme the globalElementCrosswalkGrpNme to set
	 */
	public void setGlobalElementCrosswalkGrpNme(String globalElementCrosswalkGrpNme) {
		this.globalElementCrosswalkGrpNme = globalElementCrosswalkGrpNme;
	}

	/**
	 * @return the metadataCode
	 */
	public Long getMetadataCode() {
		return metadataCode;
	}
	/**
	 * @param metadataCode the metadataCode to set
	 */
	public void setMetadataCode(Long metadataCode) {
		this.metadataCode = metadataCode;
	}
	/**
	 * @return the metadataValue
	 */
	public String getMetadataValue() {
		return metadataValue;
	}
	/**
	 * @param metadataValue the metadataValue to set
	 */
	public void setMetadataValue(String metadataValue) {
		this.metadataValue = metadataValue;
	}
	/**
	 * @param platformCode the platformCode to set
	 */
	public void setPlatformCode(Long platformCode) {
		this.platformCode = platformCode;
	}
	/**
	 * @return the platformCode
	 */
	public Long getPlatformCode() {
		return platformCode;
	}

	/**
	 * @param addCrosswalkVO the addCrosswalkVO to set
	 */
	public void setAddCrosswalkVO(List<AddCrosswalkVO> addCrosswalkVO) {
		this.addCrosswalkVO = addCrosswalkVO;
	}

	/**
	 * @return the addCrosswalkVO
	 */
	public List<AddCrosswalkVO> getAddCrosswalkVO() {
		return addCrosswalkVO;
	}

	/**
	 * @param metacodeValueList the metacodeValueList to set
	 */
	public void setMetacodeValueList(List<String> metacodeValueList) {
		this.metacodeValueList = metacodeValueList;
	}

	/**
	 * @return the metacodeValueList
	 */
	public List<String> getMetacodeValueList() {
		return metacodeValueList;
	}

	
	/**
	 * @param globalElementPlatformCode the globalElementPlatformCode to set
	 */
	public void setGlobalElementPlatformCode(Long globalElementPlatformCode) {
		this.globalElementPlatformCode = globalElementPlatformCode;
	}

	/**
	 * @return the globalElementPlatformCode
	 */
	public Long getGlobalElementPlatformCode() {
		return globalElementPlatformCode;
	}

	/**
	 * @param globalElementTypeCode the globalElementTypeCode to set
	 */
	public void setGlobalElementTypeCode(Long globalElementTypeCode) {
		this.globalElementTypeCode = globalElementTypeCode;
	}

	/**
	 * @return the globalElementTypeCode
	 */
	public Long getGlobalElementTypeCode() {
		return globalElementTypeCode;
	}

	/**
	 * @param globalElementId the globalElementId to set
	 */
	public void setGlobalElementId(Long globalElementId) {
		this.globalElementId = globalElementId;
	}

	/**
	 * @return the globalElementId
	 */
	public Long getGlobalElementId() {
		return globalElementId;
	}

	/**
	 * @param codeValueDescription the codeValueDescription to set
	 */
	public void setCodeValueDescription(String codeValueDescription) {
		this.codeValueDescription = codeValueDescription;
	}

	/**
	 * @return the codeValueDescription
	 */
	public String getCodeValueDescription() {
		return codeValueDescription;
	}

	/**
	 * @param isEdit the isEdit to set
	 */
	public void setIsEdit(String isEdit) {
		this.isEdit = isEdit;
	}

	/**
	 * @return the isEdit
	 */
	public String getIsEdit() {
		return isEdit;
	}

	/**
	 * @param globlalElementCrossWalk the globlalElementCrossWalk to set
	 */
	public void setGloblalElementCrossWalk(List<GloblalElementCrossWalk> globlalElementCrossWalk) {
		this.globlalElementCrossWalk = globlalElementCrossWalk;
	}

	/**
	 * @return the globlalElementCrossWalk
	 */
	public List<GloblalElementCrossWalk> getGloblalElementCrossWalk() {
		return globlalElementCrossWalk;
	}

	/**
	 * @return the globalCrosswalkGroupName
	 */
	public String getGlobalCrosswalkGroupName() {
		return globalElementCrosswalkGrpNme;
	}

	/**
	 * @param globalCrosswalkGroupName the globalCrosswalkGroupName to set
	 */
	public void setGlobalCrosswalkGroupName(String globalElementCrosswalkGrpNme) {
		this.globalElementCrosswalkGrpNme = globalElementCrosswalkGrpNme;
	}

	/**
	 * @return the globalElementCrosswalkComment
	 */
	public String getGlobalElementCrosswalkComment() {
		return globalElementCrosswalkComment;
	}

	/**
	 * @param globalElementCrosswalkComment the globalElementCrosswalkComment to set
	 */
	public void setGlobalElementCrosswalkComment(
			String globalElementCrosswalkComment) {
		this.globalElementCrosswalkComment = globalElementCrosswalkComment;
	}

	
	
}
