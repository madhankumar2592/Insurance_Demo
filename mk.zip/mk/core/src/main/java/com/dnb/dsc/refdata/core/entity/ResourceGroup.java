/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "RESC_GRP")
@NamedQueries({
	@NamedQuery(name = "ResourceGroup.removeRescGrpById", query = "DELETE FROM ResourceGroup c where c.rescId  in ( :rescId)")

		})
public class ResourceGroup extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "RESC_GRP_ID")
	private Long rescGrpId;
		
	@Column(name = "RESC_ID")
	private Long rescId;
	
	@Column(name = "RESC_GRP_CD")
	private Long rescGrpCd;
	
	public Long getRescGrpId() {
		return rescGrpId;
	}

	public void setRescGrpId(Long rescGrpId) {
		this.rescGrpId = rescGrpId;
	}

	public Long getRescId() {
		return rescId;
	}

	public void setRescId(Long rescId) {
		this.rescId = rescId;
	}

	/**
	 * @param rescCd the rescCd to set
	 */
	public void setRescGrpCd(Long rescGrpCd) {
		this.rescGrpCd = rescGrpCd;
	}

	/**
	 * @return the rescCd
	 */
	public Long getRescGrpCd() {
		return rescGrpCd;
	}

	/**
	 * Empty Constructor.
	 */
	public ResourceGroup() {
		super();
	}
	
	public ResourceGroup(Long rescGrpId) {
		super();
		this.rescGrpId = rescGrpId;
	}
	/*public ResourceGroup(Long ResourceGroupVersion) {
		super();
		this.ResourceGroupVersion = ResourceGroupVersion;
	}*/
	public ResourceGroup(Long rescGrpId, Long rescId, Long rescCd) {
		super();
		this.rescGrpId = rescGrpId;
		this.rescId = rescId;
		this.rescGrpCd = rescCd;
	}
	
	
	/**
	 * 
	 * @param ResourceGroupId
	 * @param ResourceGroupVersion
	 * @param ResourceGroupTypeId
	 * @param ResourceGroupMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public ResourceGroup(Long rescGrpId, Long rescId,Long rescCd,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.rescGrpId = rescGrpId;
		this.rescId = rescId;
		this.rescGrpCd = rescCd;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ResourceGroup [rescGrpId=" + rescGrpId
				+ ", rescId=" + rescId+ ", rescCd=" + rescGrpCd + 
				  "]";
	}
	
	
}
