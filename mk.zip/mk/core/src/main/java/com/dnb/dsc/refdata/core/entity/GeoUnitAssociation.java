/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the GeoUnitAssociation. 
 * The class will have a direct mapping toe DB table geo_unit_assn.
 * 
 * @author Cognizant
 * @version last updated : Jan 11, 2012
 * @see
 * 
 */
@Entity
@Table(name = "GEO_UNIT_ASSN")
@NamedQueries({
		@NamedQuery(name = "GeoUnitAssociation.validateGeoUnitAssociations", query = "SELECT COUNT(geoUnitAsscn.childGeoUnitId) FROM GeoUnitAssociation geoUnitAsscn WHERE geoUnitAsscn.parentGeoUnitId = :geoUnitId"),
		@NamedQuery(name = "GeoUnitAssociation.removeParentGeoUnitsByGeoUnitId", query = "DELETE GeoUnitAssociation g where g.childGeoUnitId = :geoUnitId"),
		@NamedQuery(name = "GeoUnitAssociation.retrieveChildGeoAssociation", query = "SELECT new GeoUnitAssociation(a.geoUnitAssociationId, a.parentGeoUnitId, a.childGeoUnitId, a.effectiveDate, a.expirationDate, a.expiredByDate, g.geoUnitTypeCode, a.createdDate, a.modifiedDate, a.modifiedUser, a.createdUser ) FROM GeoUnitAssociation a, GeoUnit g where a.childGeoUnitId = g.geoUnitId and a.parentGeoUnitId = :geoUnitId") })
public class GeoUnitAssociation extends Audit implements Serializable{

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "GEO_UNIT_ASSN_ID")
	private Long geoUnitAssociationId;

	@Column(name = "PRNT_GEO_UNIT_ID")
	private Long parentGeoUnitId;

	@Column(name = "CHLD_GEO_UNIT_ID")
	private Long childGeoUnitId;

	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;

	@Column(name = "EXPD_BY_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expiredByDate;
	
	@Transient
	private GeoUnit parentGeoUnit;

	@Transient
	private Long childGeoUnitTypeCode;

	@Transient
	private String errorCD;
	
	@Transient
	private String changeIndicator;

	/**
	 * Constructor
	 */
	public GeoUnitAssociation() {
		super();
	}

	/**
	 * @param parentGeoUnitId
	 * @param childGeoUnitId
	 * @param effectiveDate
	 * @param expirationDate
	 * @param expiredByDate
	 * @param createdDate
	 * @param modifiedDate
	 * @param modifiedUser
	 * @param createdUser
	 * @param geoUnit
	 */
	public GeoUnitAssociation(Long parentGeoUnitId, Long childGeoUnitId,
			Date effectiveDate, Date expirationDate, Date expiredByDate,
			Date createdDate, Date modifiedDate, String modifiedUser,
			String createdUser, GeoUnit parentGeoUnit) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.parentGeoUnitId = parentGeoUnitId;
		this.childGeoUnitId = childGeoUnitId;
		this.effectiveDate = effectiveDate;
		this.expiredByDate = expiredByDate;
		this.expirationDate = expirationDate;		
		this.parentGeoUnit = parentGeoUnit;
	}

	/**
	 * @param geoUnitAssociationId
	 * @param parentGeoUnitId
	 * @param childGeoUnitId
	 * @param effectiveDate
	 * @param expiredByDate
	 * @param childGeoUnitTypeCode
	 */
	public GeoUnitAssociation(Long geoUnitAssociationId, Long parentGeoUnitId,
			Long childGeoUnitId, Date effectiveDate, Date expiredByDate, Date expirationDate,
			Long childGeoUnitTypeCode) {
		this.geoUnitAssociationId = geoUnitAssociationId;
		this.parentGeoUnitId = parentGeoUnitId;
		this.childGeoUnitId = childGeoUnitId;
		this.effectiveDate = effectiveDate;
		this.expiredByDate = expiredByDate;
		this.expirationDate = expirationDate;
		this.childGeoUnitTypeCode = childGeoUnitTypeCode;
	}
	
	/**
	 * 
	 * @param geoUnitAssociationId
	 * @param parentGeoUnitId
	 * @param childGeoUnitId
	 * @param effectiveDate
	 * @param expirationDate
	 * @param expiredByDate
	 * @param childGeoUnitTypeCode
	 * @param createdDate
	 * @param modifiedDate
	 * @param modifiedUser
	 * @param createdUser
	 */
	public GeoUnitAssociation(Long geoUnitAssociationId, Long parentGeoUnitId,
			Long childGeoUnitId, Date effectiveDate, 
			Date expiredByDate, Date expirationDate,Long childGeoUnitTypeCode, Date createdDate,
			Date modifiedDate, String modifiedUser, String createdUser) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.geoUnitAssociationId = geoUnitAssociationId;
		this.parentGeoUnitId = parentGeoUnitId;
		this.childGeoUnitId = childGeoUnitId;
		this.childGeoUnitTypeCode = childGeoUnitTypeCode;
		this.effectiveDate = effectiveDate;
		this.expiredByDate = expiredByDate;
		this.expirationDate = expirationDate;
		
	}

	/**
	 * @return the geoUnitAssociationId
	 */
	public Long getGeoUnitAssociationId() {
		return geoUnitAssociationId;
	}

	/**
	 * @param geoUnitAssociationId
	 *            the geoUnitAssociationId to set
	 */
	public void setGeoUnitAssociationId(Long geoUnitAssociationId) {
		this.geoUnitAssociationId = geoUnitAssociationId;
	}

	/**
	 * @return the parentGeoUnitId
	 */
	public Long getParentGeoUnitId() {
		return parentGeoUnitId;
	}

	/**
	 * @param parentGeoUnitId
	 *            the parentGeoUnitId to set
	 */
	public void setParentGeoUnitId(Long parentGeoUnitId) {
		this.parentGeoUnitId = parentGeoUnitId;
	}

	/**
	 * @return the childGeoUnitId
	 */
	public Long getChildGeoUnitId() {
		return childGeoUnitId;
	}

	/**
	 * @return the changeIndicator
	 */
	public String getChangeIndicator() {
		return changeIndicator;
	}

	/**
	 * @param changeIndicator the changeIndicator to set
	 */
	public void setChangeIndicator(String changeIndicator) {
		this.changeIndicator = changeIndicator;
	}

	/**
	 * @param childGeoUnitId
	 *            the childGeoUnitId to set
	 */
	public void setChildGeoUnitId(Long childGeoUnitId) {
		this.childGeoUnitId = childGeoUnitId;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate
	 *            the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate
	 *            the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
		System.out.println("inside Association Setter"+expirationDate);
	}

	/**
	 * @return the expiredByDate
	 */
	public Date getExpiredByDate() {
		return expiredByDate;
	}

	/**
	 * @param expiredByDate
	 *            the expiredByDate to set
	 */
	public void setExpiredByDate(Date expiredByDate) {
		this.expiredByDate = expiredByDate;
	}

	/**
	 * @return the parentGeoUnit
	 */
	public GeoUnit getParentGeoUnit() {
		return parentGeoUnit;
	}

	/**
	 * @param parentGeoUnit
	 *            the parentGeoUnit to set
	 */
	public void setParentGeoUnit(GeoUnit parentGeoUnit) {
		this.parentGeoUnit = parentGeoUnit;
	}

	/**
	 * @return the childGeoUnitTypeCode
	 */
	public Long getChildGeoUnitTypeCode() {
		return childGeoUnitTypeCode;
	}

	/**
	 * @param childGeoUnitTypeCode the childGeoUnitTypeCode to set
	 */
	public void setChildGeoUnitTypeCode(Long childGeoUnitTypeCode) {
		this.childGeoUnitTypeCode = childGeoUnitTypeCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GeoUnitAssociation [geoUnitAssociationId="
				+ geoUnitAssociationId + ", parentGeoUnitId=" + parentGeoUnitId
				+ ", childGeoUnitId=" + childGeoUnitId + ", effectiveDate="
				+ effectiveDate + ", expirationDate=" + expirationDate
				+ ", expiredByDate=" + expiredByDate + ", parentGeoUnit="
				+ parentGeoUnit + ", childGeoUnitTypeCode="
				+ childGeoUnitTypeCode + ", changeIndicator=" + changeIndicator
				+ "]";

	}
	
	/**
	 * @return the errorCD
	 */
	public String getErrorCD() {
		return errorCD;
	}

	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(String errorCD) {
		this.errorCD = errorCD;
	}
}
