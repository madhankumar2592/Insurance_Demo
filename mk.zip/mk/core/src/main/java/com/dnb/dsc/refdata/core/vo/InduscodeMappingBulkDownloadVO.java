/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

/**
* This class used as a vo  class for the industry code mapping bulk download. 
* 
* @author Cognizant
* @version last updated : Jul 20, 2017
* @see
* 
*/

public class InduscodeMappingBulkDownloadVO {
	private Long toIndustryCodeTypeCode;
	private Long fromIndustryCodeTypeCode;
	private String toIndustryCodeTypeCodeDesc;
	private String fromIndustryCodeTypeCodeDesc;
	private Long fromIndustryCodeId;
	private Long toIndustryCodeId;
	private String fromIndustryCode;
	private String toIndustryCode;
	private String fromIndustryCodeDesc;
	private String toIndustryCodeDesc;
	private Long fromIndustryCodelangCode;
	private Long toIndustryCodelangCode;
	private String fromIndustryCodelangCodeDesc;
	private String toIndustryCodelangCodeDesc;
	private Long fromIndustryCodeDescLenCode;
	private String fromIndustryCodeDescLenCodeDesc;
	private Long toIndustryCodeDescLenCode;
	private String toIndustryCodeDescLenCodeDesc;
	private Long prfrdMappingIndicator;
	private Long crosswalkCount;
	
	
	public InduscodeMappingBulkDownloadVO(){
		
	}
	
	/**
	 * 
	 * @param fromIndustryCodeTypeCodeDesc
	 * @param toIndustryCodeTypeCodeDesc
	 * @param crosswalkCount
	 */
	public InduscodeMappingBulkDownloadVO(Long fromIndustryCodeTypeCode,String fromIndustryCodeTypeCodeDesc,
			Long toIndustryCodeTypeCode,String toIndustryCodeTypeCodeDesc,Long crosswalkCount){
		this.fromIndustryCodeTypeCode = fromIndustryCodeTypeCode;
		this.fromIndustryCodeTypeCodeDesc = fromIndustryCodeTypeCodeDesc;
		this.toIndustryCodeTypeCode = toIndustryCodeTypeCode;
		this.toIndustryCodeTypeCodeDesc = toIndustryCodeTypeCodeDesc;
		this.crosswalkCount = crosswalkCount;
	}
	
	/**
	 * @return the toIndustryCodeTypeCode
	 */
	public Long getToIndustryCodeTypeCode() {
		return toIndustryCodeTypeCode;
	}
	/**
	 * @param toIndustryCodeTypeCode the toIndustryCodeTypeCode to set
	 */
	public void setToIndustryCodeTypeCode(Long toIndustryCodeTypeCode) {
		this.toIndustryCodeTypeCode = toIndustryCodeTypeCode;
	}
	/**
	 * @return the fromIndustryCodeTypeCode
	 */
	public Long getFromIndustryCodeTypeCode() {
		return fromIndustryCodeTypeCode;
	}
	/**
	 * @param fromIndustryCodeTypeCode the fromIndustryCodeTypeCode to set
	 */
	public void setFromIndustryCodeTypeCode(Long fromIndustryCodeTypeCode) {
		this.fromIndustryCodeTypeCode = fromIndustryCodeTypeCode;
	}
	/**
	 * @return the toIndustryCodeTypeCodeDesc
	 */
	public String getToIndustryCodeTypeCodeDesc() {
		return toIndustryCodeTypeCodeDesc;
	}
	/**
	 * @param toIndustryCodeTypeCodeDesc the toIndustryCodeTypeCodeDesc to set
	 */
	public void setToIndustryCodeTypeCodeDesc(String toIndustryCodeTypeCodeDesc) {
		this.toIndustryCodeTypeCodeDesc = toIndustryCodeTypeCodeDesc;
	}
	/**
	 * @return the fromIndustryCodeTypeCodeDesc
	 */
	public String getFromIndustryCodeTypeCodeDesc() {
		return fromIndustryCodeTypeCodeDesc;
	}
	/**
	 * @param fromIndustryCodeTypeCodeDesc the fromIndustryCodeTypeCodeDesc to set
	 */
	public void setFromIndustryCodeTypeCodeDesc(String fromIndustryCodeTypeCodeDesc) {
		this.fromIndustryCodeTypeCodeDesc = fromIndustryCodeTypeCodeDesc;
	}
	/**
	 * @return the fromIndustryCodeId
	 */
	public Long getFromIndustryCodeId() {
		return fromIndustryCodeId;
	}
	/**
	 * @param fromIndustryCodeId the fromIndustryCodeId to set
	 */
	public void setFromIndustryCodeId(Long fromIndustryCodeId) {
		this.fromIndustryCodeId = fromIndustryCodeId;
	}
	/**
	 * @return the toIndustryCodeId
	 */
	public Long getToIndustryCodeId() {
		return toIndustryCodeId;
	}
	/**
	 * @param toIndustryCodeId the toIndustryCodeId to set
	 */
	public void setToIndustryCodeId(Long toIndustryCodeId) {
		this.toIndustryCodeId = toIndustryCodeId;
	}
	/**
	 * @return the fromIndustryCode
	 */
	public String getFromIndustryCode() {
		return fromIndustryCode;
	}
	/**
	 * @param fromIndustryCode the fromIndustryCode to set
	 */
	public void setFromIndustryCode(String fromIndustryCode) {
		this.fromIndustryCode = fromIndustryCode;
	}
	/**
	 * @return the toIndustryCode
	 */
	public String getToIndustryCode() {
		return toIndustryCode;
	}
	/**
	 * @param toIndustryCode the toIndustryCode to set
	 */
	public void setToIndustryCode(String toIndustryCode) {
		this.toIndustryCode = toIndustryCode;
	}
	/**
	 * @return the fromIndustryCodeDesc
	 */
	public String getFromIndustryCodeDesc() {
		return fromIndustryCodeDesc;
	}
	/**
	 * @param fromIndustryCodeDesc the fromIndustryCodeDesc to set
	 */
	public void setFromIndustryCodeDesc(String fromIndustryCodeDesc) {
		this.fromIndustryCodeDesc = fromIndustryCodeDesc;
	}
	/**
	 * @return the toIndustryCodeDesc
	 */
	public String getToIndustryCodeDesc() {
		return toIndustryCodeDesc;
	}
	/**
	 * @param toIndustryCodeDesc the toIndustryCodeDesc to set
	 */
	public void setToIndustryCodeDesc(String toIndustryCodeDesc) {
		this.toIndustryCodeDesc = toIndustryCodeDesc;
	}
	/**
	 * @return the fromIndustryCodelangCode
	 */
	public Long getFromIndustryCodelangCode() {
		return fromIndustryCodelangCode;
	}
	/**
	 * @param fromIndustryCodelangCode the fromIndustryCodelangCode to set
	 */
	public void setFromIndustryCodelangCode(Long fromIndustryCodelangCode) {
		this.fromIndustryCodelangCode = fromIndustryCodelangCode;
	}
	/**
	 * @return the toIndustryCodelangCode
	 */
	public Long getToIndustryCodelangCode() {
		return toIndustryCodelangCode;
	}
	/**
	 * @param toIndustryCodelangCode the toIndustryCodelangCode to set
	 */
	public void setToIndustryCodelangCode(Long toIndustryCodelangCode) {
		this.toIndustryCodelangCode = toIndustryCodelangCode;
	}
	/**
	 * @return the fromIndustryCodelangCodeDesc
	 */
	public String getFromIndustryCodelangCodeDesc() {
		return fromIndustryCodelangCodeDesc;
	}
	/**
	 * @param fromIndustryCodelangCodeDesc the fromIndustryCodelangCodeDesc to set
	 */
	public void setFromIndustryCodelangCodeDesc(String fromIndustryCodelangCodeDesc) {
		this.fromIndustryCodelangCodeDesc = fromIndustryCodelangCodeDesc;
	}
	/**
	 * @return the toIndustryCodelangCodeDesc
	 */
	public String getToIndustryCodelangCodeDesc() {
		return toIndustryCodelangCodeDesc;
	}
	/**
	 * @param toIndustryCodelangCodeDesc the toIndustryCodelangCodeDesc to set
	 */
	public void setToIndustryCodelangCodeDesc(String toIndustryCodelangCodeDesc) {
		this.toIndustryCodelangCodeDesc = toIndustryCodelangCodeDesc;
	}
	/**
	 * @return the fromIndustryCodeDescLenCode
	 */
	public Long getFromIndustryCodeDescLenCode() {
		return fromIndustryCodeDescLenCode;
	}
	/**
	 * @param fromIndustryCodeDescLenCode the fromIndustryCodeDescLenCode to set
	 */
	public void setFromIndustryCodeDescLenCode(Long fromIndustryCodeDescLenCode) {
		this.fromIndustryCodeDescLenCode = fromIndustryCodeDescLenCode;
	}
	/**
	 * @return the fromIndustryCodeDescLenCodeDesc
	 */
	public String getFromIndustryCodeDescLenCodeDesc() {
		return fromIndustryCodeDescLenCodeDesc;
	}
	/**
	 * @param fromIndustryCodeDescLenCodeDesc the fromIndustryCodeDescLenCodeDesc to set
	 */
	public void setFromIndustryCodeDescLenCodeDesc(
			String fromIndustryCodeDescLenCodeDesc) {
		this.fromIndustryCodeDescLenCodeDesc = fromIndustryCodeDescLenCodeDesc;
	}
	/**
	 * @return the toIndustryCodeDescLenCode
	 */
	public Long getToIndustryCodeDescLenCode() {
		return toIndustryCodeDescLenCode;
	}
	/**
	 * @param toIndustryCodeDescLenCode the toIndustryCodeDescLenCode to set
	 */
	public void setToIndustryCodeDescLenCode(Long toIndustryCodeDescLenCode) {
		this.toIndustryCodeDescLenCode = toIndustryCodeDescLenCode;
	}
	/**
	 * @return the toIndustryCodeDescLenCodeDesc
	 */
	public String getToIndustryCodeDescLenCodeDesc() {
		return toIndustryCodeDescLenCodeDesc;
	}
	/**
	 * @param toIndustryCodeDescLenCodeDesc the toIndustryCodeDescLenCodeDesc to set
	 */
	public void setToIndustryCodeDescLenCodeDesc(
			String toIndustryCodeDescLenCodeDesc) {
		this.toIndustryCodeDescLenCodeDesc = toIndustryCodeDescLenCodeDesc;
	}
	/**
	 * @return the prfrdMappingIndicator
	 */
	public Long getPrfrdMappingIndicator() {
		return prfrdMappingIndicator;
	}
	/**
	 * @param prfrdMappingIndicator the prfrdMappingIndicator to set
	 */
	public void setPrfrdMappingIndicator(Long prfrdMappingIndicator) {
		this.prfrdMappingIndicator = prfrdMappingIndicator;
	}
	/**
	 * @return the crosswalkCount
	 */
	public Long getCrosswalkCount() {
		return crosswalkCount;
	}
	/**
	 * @param crosswalkCount the crosswalkCount to set
	 */
	public void setCrosswalkCount(Long crosswalkCount) {
		this.crosswalkCount = crosswalkCount;
	}
	
	
}
