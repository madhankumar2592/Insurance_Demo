package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.Audit;
import com.dnb.dsc.refdata.core.entity.GlobalElementHistory;

public class AddGlobalElementVO extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Long globalElementId;	
	private Long globalElementBaseSubTypeId;	
	private Long globalElementTypeCode;	
	private Long globalElementTopicCategoryCode;	
	private String globalElementName;
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;
	private List<GlobalElementDetailVO> globalElementDetailVO;
	private String globalElementComment;
	private List<GlobalElementHistory> globalElementHistory;
	private String shortDescription;
	private String longDescription;
	private Long globalElementMetadataLangCode;
	private String globalElementDetailComment;
	
	/**
	 * @return the globalElementId
	 */
	public Long getGlobalElementId() {
		return globalElementId;
	}
	/**
	 * @param globalElementId the globalElementId to set
	 */
	public void setGlobalElementId(Long globalElementId) {
		this.globalElementId = globalElementId;
	}
	/**
	 * @return the globalElementBaseSubTypeId
	 */
	public Long getGlobalElementBaseSubTypeId() {
		return globalElementBaseSubTypeId;
	}
	/**
	 * @param globalElementBaseSubTypeId the globalElementBaseSubTypeId to set
	 */
	public void setGlobalElementBaseSubTypeId(Long globalElementBaseSubTypeId) {
		this.globalElementBaseSubTypeId = globalElementBaseSubTypeId;
	}
	/**
	 * @return the globalElementTypeCode
	 */
	public Long getGlobalElementTypeCode() {
		return globalElementTypeCode;
	}
	/**
	 * @param globalElementTypeCode the globalElementTypeCode to set
	 */
	public void setGlobalElementTypeCode(Long globalElementTypeCode) {
		this.globalElementTypeCode = globalElementTypeCode;
	}
	/**
	 * @return the globalElementTopicCategoryCode
	 */
	public Long getGlobalElementTopicCategoryCode() {
		return globalElementTopicCategoryCode;
	}
	/**
	 * @param globalElementTopicCategoryCode the globalElementTopicCategoryCode to set
	 */
	public void setGlobalElementTopicCategoryCode(
			Long globalElementTopicCategoryCode) {
		this.globalElementTopicCategoryCode = globalElementTopicCategoryCode;
	}
	/**
	 * @return the globalElementName
	 */
	public String getGlobalElementName() {
		return globalElementName;
	}
	/**
	 * @param globalElementName the globalElementName to set
	 */
	public void setGlobalElementName(String globalElementName) {
		this.globalElementName = globalElementName;
	}
	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}
	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	/**
	 * @return the globalElementDetailVO
	 */
	public List<GlobalElementDetailVO> getGlobalElementDetailVO() {
		return globalElementDetailVO;
	}
	/**
	 * @param globalElementDetailVO the globalElementDetailVO to set
	 */
	public void setGlobalElementDetailVO(
			List<GlobalElementDetailVO> globalElementDetailVO) {
		this.globalElementDetailVO = globalElementDetailVO;
	}
	/**
	 * @param globalElementComment the globalElementComment to set
	 */
	public void setGlobalElementComment(String globalElementComment) {
		this.globalElementComment = globalElementComment;
	}
	/**
	 * @return the globalElementComment
	 */
	public String getGlobalElementComment() {
		return globalElementComment;
	}
	/**
	 * @param globalElementHistory the globalElementHistory to set
	 */
	public void setGlobalElementHistory(List<GlobalElementHistory> globalElementHistory) {
		this.globalElementHistory = globalElementHistory;
	}
	/**
	 * @return the globalElementHistory
	 */
	public List<GlobalElementHistory> getGlobalElementHistory() {
		return globalElementHistory;
	}
	/**
	 * @param shortDescription the shortDescription to set
	 */
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	/**
	 * @return the shortDescription
	 */
	public String getShortDescription() {
		return shortDescription;
	}
	/**
	 * @param longDescription the longDescription to set
	 */
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}
	/**
	 * @return the longDescription
	 */
	public String getLongDescription() {
		return longDescription;
	}
	/**
	 * @param globalElementMetadataLangCode the globalElementMetadataLangCode to set
	 */
	public void setGlobalElementMetadataLangCode(
			Long globalElementMetadataLangCode) {
		this.globalElementMetadataLangCode = globalElementMetadataLangCode;
	}
	/**
	 * @return the globalElementMetadataLangCode
	 */
	public Long getGlobalElementMetadataLangCode() {
		return globalElementMetadataLangCode;
	}
	/**
	 * @param globalElementDetailComment the globalElementDetailComment to set
	 */
	public void setGlobalElementDetailComment(String globalElementDetailComment) {
		this.globalElementDetailComment = globalElementDetailComment;
	}
	/**
	 * @return the globalElementDetailComment
	 */
	public String getGlobalElementDetailComment() {
		return globalElementDetailComment;
	}
	
	

}
