/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.util.List;

import org.springframework.stereotype.Component;

/**
 * <p>
 * This class is a logger VO
 * </p>
 * 
 * @author  Cognizant Technology Solutions
 * @version last updated : August 1, 2012
 * @see TransactionLoggerVO 
 * 
 */
@Component
public class TransactionLoggerVO {
	
	private static final long serialVersionUID = 2L;
	
	private Long TransactionId;
	
	private String startTime;
	
	private String endTime;
	
	private String userId;
	
	private String userRoles;
	
	private String domain;
	
	private String transactionType;
	
	private Long transactionStatus;
	
	private Long domainId;
	
	private String strDomainId;
	
	private Long trackingId;

	private String strTrackingId;

	private Object domainObject;

	private List<Object> variableArguments;

	/**
	 * @return the transactionId
	 */
	public Long getTransactionId() {
		return TransactionId;
	}

	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(Long transactionId) {
		TransactionId = transactionId;
	}

	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the userRoles
	 */
	public String getUserRoles() {
		return userRoles;
	}

	/**
	 * @param userRoles the userRoles to set
	 */
	public void setUserRoles(String userRoles) {
		this.userRoles = userRoles;
	}

	/**
	 * @return the domain
	 */
	public String getDomain() {
		return domain;
	}

	/**
	 * @param domain the domain to set
	 */
	public void setDomain(String domain) {
		this.domain = domain;
	}

	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the transactionStatus
	 */
	public Long getTransactionStatus() {
		return transactionStatus;
	}

	/**
	 * @param transactionStatus the transactionStatus to set
	 */
	public void setTransactionStatus(Long transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	/**
	 * @return the domainId
	 */
	public Long getDomainId() {
		return domainId;
	}

	/**
	 * @param domainId the domainId to set
	 */
	public void setDomainId(Long domainId) {
		this.domainId = domainId;
	}

	/**
	 * @return the strDomainId
	 */
	public String getStrDomainId() {
		return strDomainId;
	}

	/**
	 * @param strDomainId the strDomainId to set
	 */
	public void setStrDomainId(String strDomainId) {
		this.strDomainId = strDomainId;
	}

	/**
	 * @return the trackingId
	 */
	public Long getTrackingId() {
		return trackingId;
	}

	/**
	 * @param trackingId the trackingId to set
	 */
	public void setTrackingId(Long trackingId) {
		this.trackingId = trackingId;
	}

	/**
	 * @return the strTrackingId
	 */
	public String getStrTrackingId() {
		return strTrackingId;
	}

	/**
	 * @param strTrackingId the strTrackingId to set
	 */
	public void setStrTrackingId(String strTrackingId) {
		this.strTrackingId = strTrackingId;
	}

	/**
	 * @return the domainObject
	 */
	public Object getDomainObject() {
		return domainObject;
	}

	/**
	 * @param domainObject the domainObject to set
	 */
	public void setDomainObject(Object domainObject) {
		this.domainObject = domainObject;
	}

	/**
	 * @return the variableArguments
	 */
	public List<Object> getVariableArguments() {
		return variableArguments;
	}

	/**
	 * @param variableArguments the variableArguments to set
	 */
	public void setVariableArguments(List<Object> variableArguments) {
		this.variableArguments = variableArguments;
	}

	@Override
	public String toString() {
		return "TransactionLoggerVO [TransactionId=" + TransactionId
				+ ", startTime=" + startTime + ", endTime=" + endTime
				+ ", userId=" + userId + ", userRoles=" + userRoles
				+ ", domain=" + domain + ", transactionType=" + transactionType
				+ ", transactionStatus=" + transactionStatus + ", domainId="
				+ domainId + ", strDomainId=" + strDomainId + ", trackingId="
				+ trackingId + ", strTrackingId=" + strTrackingId + "]";
	}

}
