/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class used as an entity class for the UserGroupMapping. The class  
 * will have a direct mapping toe DB table usr_grp_map.
 *
 * @author Cognizant
 * @version last updated : Apr 12, 2012
 * @see
 *
 */
@Entity
@Table(name = "UI_ACS_GRP")
public class UserGroupMapping implements Serializable {

	private static final long serialVersionUID = 8993265291802855779L;
	/**
	 * The user group identifier attribute
	 */
	@Id
	@Column(name = "UI_ACS_GRP_ID")
	private Long groupIdentifier;
	/**
	 * The user group code attribute
	 */
	@Column(name = "GRP_NME")
	private String groupName;
	/**
	 * The domain name attribute
	 */
	@Column(name = "DMN_NME")
	private String domainName;
	/**
	 * The user country geoUnit identifier attribute
	 */
	@Column(name = "DMN_ID")
	private Long domainIdentifier;
	/**
	 * The is approver indicator attribute
	 */
	@Column(name = "IS_APR_IND")
	private Boolean isApprover;
	/**
	 * The approver group identifier attribute
	 */
	@Column(name = "APR_GRP_ID")
	private Long approverGroupId;

	/**
	 * The default constructor
	 */
	public UserGroupMapping() {
	}

	/**
	 * @return the groupIdentifier
	 */
	public Long getGroupIdentifier() {
		return groupIdentifier;
	}

	/**
	 * @param groupIdentifier the groupIdentifier to set
	 */
	public void setGroupIdentifier(Long groupIdentifier) {
		this.groupIdentifier = groupIdentifier;
	}

	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * @return the domainName
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * @param domainName the domainName to set
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @return the domainIdentifier
	 */
	public Long getDomainIdentifier() {
		return domainIdentifier;
	}

	/**
	 * @param domainIdentifier the domainIdentifier to set
	 */
	public void setDomainIdentifier(Long domainIdentifier) {
		this.domainIdentifier = domainIdentifier;
	}

	/**
	 * @return the isApprover
	 */
	public Boolean getIsApprover() {
		return isApprover;
	}

	/**
	 * @param isApprover the isApprover to set
	 */
	public void setIsApprover(Boolean isApprover) {
		this.isApprover = isApprover;
	}

	/**
	 * @return the approverGroupId
	 */
	public Long getApproverGroupId() {
		return approverGroupId;
	}

	/**
	 * @param approverGroupId the approverGroupId to set
	 */
	public void setApproverGroupId(Long approverGroupId) {
		this.approverGroupId = approverGroupId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserGroupMapping [groupIdentifier=" + groupIdentifier
				+ ", groupName=" + groupName + ", domainName=" + domainName
				+ ", domainIdentifier=" + domainIdentifier + ", isApprover="
				+ isApprover + ", approverGroupId=" + approverGroupId + "]";
	}
}
