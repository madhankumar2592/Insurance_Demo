/*
 * Name: IndustryCodeInferment.java
 * Created: May 29, 2012
 * 
 * Confidential and Proprietary.
 * Copyright (C) 2012 D&B. All Rights Reserved.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the IndustrialCodeInferment. The class will have a direct mapping to DB table
 * inds_code_infr.
 * <p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 * 
 */
@Entity
@Table(name = "INDS_CODE_INFR")
@NamedQueries({
        @NamedQuery(name = "IndustryCodeInferment.retrieveIndustryCodeTypeAndDesc", query = "select distinct new IndustryCodeInferment(i.industryCodeTypeCode,t.codeValueShortDescription,t.codeValueDescription) from CodeValueText t,CodeValue c,IndustryCode i,IndustryCodeInferment infr where c.codeValueId=i.industryCodeTypeCode and i.industryCodeId = infr.industryCodeId and t.codeValueId=c.codeValueId and t.languageCode=:langCode and  t.writingScriptCode=:writingScriptCode and c.codeTableId =:codeTableId order by t.codeValueShortDescription"),
        @NamedQuery(name = "IndustryCodeInferment.retrieveLanguageCode", query = "select distinct new IndustryCodeInferment(infr.languageCode,cdValTxt.codeValueShortDescription) from IndustryCodeInferment indsinfr,InfermentText infr,CodeValue cdVal,CodeValueText cdValTxt where infr.infermentTextId = indsinfr.infermentTextId and cdVal.codeValueId=infr.languageCode and cdVal.codeValueId=cdValTxt.codeValueId order by cdValTxt.codeValueShortDescription"),
        @NamedQuery(name = "IndustryCodeInferment.retrieveIndustryCodeDescription", query = "select distinct new IndustryCodeInferment(ic.industryCode,icd.industryDescription) from IndustryCodeInferment ici,IndustryCode ic,IndustryCodeDescription icd where ici.industryCodeId=ic.industryCodeId and ic.industryCodeId=icd.industryCodeId and icd.languageCode=:languageCode"),
        @NamedQuery(name = "IndustryCodeInferment.retrieveIndustryCodeInfermentView", query = "select distinct new IndustryCodeInferment(it.infermentText,it.infermentTextId,ic.industryCodeTypeCode,it.languageCode,(select cvt.codeValueDescription from CodeValueText cvt where cvt.codeValueId=it.languageCode and cvt.languageCode = :langCode),ic.industryCode,(select icd.industryDescription from IndustryCodeDescription icd where icd.industryCodeId=ic.industryCodeId and icd.languageCode=:indsCodeDescriptionLanguage),(select cvt.codeValueDescription from CodeValueText cvt where cvt.codeValueId=ic.industryCodeTypeCode and cvt.languageCode=:indsTypeCodeLanguage),it.expirationDate,it.modifiedDate,it.modifiedUser) from InfermentText it,IndustryCodeInferment ici,IndustryCode ic where it.infermentTextId=ici.infermentTextId and ici.industryCodeId=ic.industryCodeId and it.infermentTextId=:infermentText"),
        @NamedQuery(name = "IndustryCodeInferment.removeApprovedIndustryCodeInferment", query = "DELETE from IndustryCodeInferment WHERE infermentTextId = :infermentTextId")})
public class IndustryCodeInferment extends Audit implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "INDS_CD_INFR_ID")
    private Long industryCodeInfermentId;

    @Column(name = "INDS_CODE_ID")
    private Long industryCodeId;

    @Column(name = "INFR_TXT_ID")
    private Long infermentTextId;

    @Transient
    private Long industryCodeTypeCode;

    @Transient
    private String codeValueShortDescription;

    @Transient
    private String codeValueDescription;

    @Transient
    private String industryCode;

    @Transient
    private Long languageCode;

    @Transient
    private String icountryGeoUnitId;

    @Transient
    private String countryName;

    @Transient
    private String language;

    @Transient
    private String industryCodeTypeCodeDesc;

    @Transient
    private String industryDescription;

    @Transient
    private String infermentText;

    @Transient
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
    private Date expirationDate;
    @Transient
    private int errorCD;
    @Transient
	private String infrmntTxtBulkId;
       /**
     * Empty Constructor.
     */
    public IndustryCodeInferment() {
        super();
    }

    /**
     * @param industryCodeInfermentId
     * @param industryCodeId
     * @param infermentTextId
     */
    public IndustryCodeInferment(Long industryCodeInfermentId, Long industryCodeId, Long infermentTextId) {
        super();
        this.industryCodeInfermentId = industryCodeInfermentId;
        this.industryCodeId = industryCodeId;
        this.infermentTextId = infermentTextId;
    }

    public IndustryCodeInferment(String infermentText, Long infermentTextId) {
        this.infermentText = infermentText;
        this.infermentTextId = infermentTextId;
    }

    /**
     * @param industryCodeInfermentId
     * @param industryCodeId
     * @param infermentTextId
     */
    public IndustryCodeInferment(Long industryCodeTypeCode, String codeValueShortDescription,
            String codeValueDescription) {
        super();
        this.industryCodeTypeCode = industryCodeTypeCode;
        this.codeValueShortDescription = codeValueShortDescription;
        this.codeValueDescription = codeValueDescription;
    }

    public IndustryCodeInferment(String countryName, String language, String industryCodeTypeCodeDesc,
            String industryDescription, String industryCode, String infermentText, Long infermentTextId) {

        this.countryName = countryName;
        this.language = language;
        this.industryCodeTypeCodeDesc = industryCodeTypeCodeDesc;
        this.industryDescription = industryDescription;
        this.industryCode = industryCode;
        this.infermentText = infermentText;
        this.infermentTextId = infermentTextId;
    }

    /**
     * @param codeValueShortDescription
     * @param languageCode
     */
    public IndustryCodeInferment(Long languageCode, String codeValueShortDescription) {
        super();
        this.codeValueShortDescription = codeValueShortDescription;
        this.languageCode = languageCode;
    }

    /**
     * @param industryCode
     * @param industryDescription
     */
    public IndustryCodeInferment(String industryCode, String industryDescription) {
        super();
        this.industryCode = industryCode;
        this.industryDescription = industryDescription;
    }

    /**
     * @param industryCode
     * @param industryDescription
     */
    public IndustryCodeInferment(String infermentText, Long infermentTextId, Long industryCodeTypeCode,
            Long languageCode, String language, String industryCode, String industryDescription,
            String industryCodeTypeCodeDesc, Date expirationDate, Date modifiedDate, String modifiedUser) {
        super(modifiedDate, modifiedUser);
        this.infermentText = infermentText;
        this.infermentTextId = infermentTextId;
        this.industryCodeTypeCode = industryCodeTypeCode;
        this.languageCode = languageCode;
        this.language = language;
        this.industryCode = industryCode;
        this.industryDescription = industryDescription;
        this.industryCodeTypeCodeDesc = industryCodeTypeCodeDesc;
        this.expirationDate = expirationDate;

    }

    /**
     * @return the industryCodeInfermentId
     */
    public Long getIndustryCodeInfermentId() {
        return industryCodeInfermentId;
    }

    /**
     * @param industryCodeInfermentId
     *            the industryCodeInfermentId to set
     */
    public void setIndustryCodeInfermentId(Long industryCodeInfermentId) {
        this.industryCodeInfermentId = industryCodeInfermentId;
    }

    /**
     * @return the industryCodeId
     */
    public Long getIndustryCodeId() {
        return industryCodeId;
    }

    /**
     * @param industryCodeId
     *            the industryCodeId to set
     */
    public void setIndustryCodeId(Long industryCodeId) {
        this.industryCodeId = industryCodeId;
    }

    /**
     * @return the infermentTextId
     */
    public Long getInfermentTextId() {
        return infermentTextId;
    }

    /**
     * @param infermentTextId
     *            the infermentTextId to set
     */
    public void setInfermentTextId(Long infermentTextId) {
        this.infermentTextId = infermentTextId;
    }

    /**
     * @return the industryCodeTypeCode
     */
    public Long getIndustryCodeTypeCode() {
        return industryCodeTypeCode;
    }

    /**
     * @param industryCodeTypeCode
     *            the industryCodeTypeCode to set
     */
    public void setIndustryCodeTypeCode(Long industryCodeTypeCode) {
        this.industryCodeTypeCode = industryCodeTypeCode;
    }

    /**
     * @return the codeValueShortDescription
     */
    public String getCodeValueShortDescription() {
        return codeValueShortDescription;
    }

    /**
     * @param codeValueShortDescription
     *            the codeValueShortDescription to set
     */
    public void setCodeValueShortDescription(String codeValueShortDescription) {
        this.codeValueShortDescription = codeValueShortDescription;
    }

    /**
     * @return the codeValueDescription
     */
    public String getCodeValueDescription() {
        return codeValueDescription;
    }

    /**
     * @param codeValueDescription
     *            the codeValueDescription to set
     */
    public void setCodeValueDescription(String codeValueDescription) {
        this.codeValueDescription = codeValueDescription;
    }

    /**
     * @return the industryCode
     */
    public String getIndustryCode() {
        return industryCode;
    }

    /**
     * @param industryCode
     *            the industryCode to set
     */
    public void setIndustryCode(String industryCode) {
        this.industryCode = industryCode;
    }

    /**
     * @return the languageCode
     */
    public Long getLanguageCode() {
        return languageCode;
    }

    /**
     * @param languageCode
     *            the languageCode to set
     */
    public void setLanguageCode(Long languageCode) {
        this.languageCode = languageCode;
    }

    /**
     * @return the icountryGeoUnitId
     */
    public String getIcountryGeoUnitId() {
        return icountryGeoUnitId;
    }

    /**
     * @param icountryGeoUnitId
     *            the icountryGeoUnitId to set
     */
    public void setIcountryGeoUnitId(String icountryGeoUnitId) {
        this.icountryGeoUnitId = icountryGeoUnitId;
    }

    /**
     * @return the countryName
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * @param countryName
     *            the countryName to set
     */
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    /**
     * @return the language
     */
    public String getLanguage() {
        return language;
    }

    /**
     * @param language
     *            the language to set
     */
    public void setLanguage(String language) {
        this.language = language;
    }

    /**
     * @return the industryCodeTypeCodeDesc
     */
    public String getIndustryCodeTypeCodeDesc() {
        return industryCodeTypeCodeDesc;
    }

    /**
     * @param industryCodeTypeCodeDesc
     *            the industryCodeTypeCodeDesc to set
     */
    public void setIndustryCodeTypeCodeDesc(String industryCodeTypeCodeDesc) {
        this.industryCodeTypeCodeDesc = industryCodeTypeCodeDesc;
    }

    /**
     * @return the infermentText
     */
    public String getInfermentText() {
        return infermentText;
    }

    /**
     * @param infermentText
     *            the infermentText to set
     */
    public void setInfermentText(String infermentText) {
        this.infermentText = infermentText;
    }

    /**
     * @return the industryDescription
     */
    public String getIndustryDescription() {
        return industryDescription;
    }

    /**
     * @param industryDescription
     *            the industryDescription to set
     */
    public void setIndustryDescription(String industryDescription) {
        this.industryDescription = industryDescription;
    }

    /**
     * @return the expirationDate
     */
    public Date getExpirationDate() {
        return expirationDate;
    }

    /**
     * @param expirationDate
     *            the expirationDate to set
     */
    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    /**
	 * @return the errorCD
	 */
	public int getErrorCD() {
		return errorCD;
	}

	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(int errorCD) {
		this.errorCD = errorCD;
	}

	/**
	 * @return the infrmntTxtBulkId
	 */
	public String getInfrmntTxtBulkId() {
		return infrmntTxtBulkId;
	}

	/**
	 * @param infrmntTxtBulkId the infrmntTxtBulkId to set
	 */
	public void setInfrmntTxtBulkId(String infrmntTxtBulkId) {
		this.infrmntTxtBulkId = infrmntTxtBulkId;
	}

	/*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "IndustryCodeInferment [industryCodeInfermentId=" + industryCodeInfermentId + ", industryCodeId="
                + industryCodeId + ", infermentTextId=" + infermentTextId + ", industryCodeTypeCode="
                + industryCodeTypeCode + ", codeValueShortDescription=" + codeValueShortDescription
                + ", codeValueDescription=" + codeValueDescription + ", industryCode=" + industryCode
                + ", languageCode=" + languageCode + ", icountryGeoUnitId=" + icountryGeoUnitId + ", countryName="
                + countryName + ", language=" + language + ", industryCodeTypeCodeDesc=" + industryCodeTypeCodeDesc
                + ", industryDescription=" + industryDescription + ", infermentText=" + infermentText
                + ", expirationDate=" + expirationDate + "]";
    }

}
