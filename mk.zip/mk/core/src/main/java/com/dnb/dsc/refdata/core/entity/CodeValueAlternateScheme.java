/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the Code Value Text. The class  
 * will have a direct mapping toe DB table cd_val_alt_schm .
 * 
 * @author Cognizant
 * @version last updated : Mar 29, 2012
 * @see
 * 
 */
@Entity
@Table(name = "CD_VAL_ALT_SCHM")
@NamedQueries({
	@NamedQuery(name = "CodeValueAlternateScheme.retrieveAllSchemeCodes", query = "SELECT distinct new CodeValueAlternateScheme(a.alternateSchemeTypeCode, t.codeValueDescription) FROM CodeValueAlternateScheme a, CodeValueText t where a.alternateSchemeTypeCode = t.codeValueId and t.languageCode = :engLangCode order by a.alternateSchemeTypeCode "),
		/**
	 * Query changed to implement the fix for 208410455(the issue of displaying expired Code Value Description in Manage SCoTS Alternate Code Scheme)   
	 * 
	 */
		@NamedQuery(name = "CodeValueAlternateScheme.retrieveAlternateSchemeCodes", query = "SELECT distinct new CodeValueAlternateScheme(a.codeValueAlternateSchemeId, a.codeValueId, a.alternateSchemeTypeCode, a.alternateSchemeCodeValue, a.effectiveDate, a.expirationDate, a.createdUser, a.createdDate, a.modifiedUser, a.modifiedDate, a.alternateSchemeCodeValueDescription, cv.codeTableId, cvt.codeValueDescription, ct.codeTableName) from CodeValueAlternateScheme a, CodeValue cv, CodeValueText cvt, CodeTable ct where a.codeValueId = cv.codeValueId and cv.codeValueId = cvt.codeValueId and cv.codeTableId = ct.codeTableId and a.alternateSchemeTypeCode = :altSchTypeCode and cvt.languageCode = 39 and cvt.expirationDate is null order by a.codeValueId "),
		@NamedQuery(name = "CodeValueAlternateScheme.countCodeValueAlternateScheme", query = "FROM CodeValueAlternateScheme a where a.alternateSchemeTypeCode = :alternateSchemeTypeCode"),
		@NamedQuery(name = "CodeValueAlternateScheme.retrieveSchemeCodesByType", query = "SELECT cas FROM CodeValueAlternateScheme cas where cas.alternateSchemeTypeCode = :alternateSchemeTypeCode"),
		@NamedQuery(name = "CodeValueAlternateScheme.removeAlternateSchemeByType", query ="DELETE FROM CodeValueAlternateScheme c where c.alternateSchemeTypeCode = :alternateSchemeTypeCode")})
public class CodeValueAlternateScheme extends Audit implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "CD_VAL_ALT_SCHM_ID")
	private Long codeValueAlternateSchemeId;
	
	@Column(name = "CD_VAL_ID")
	private Long codeValueId;
	
	@Column(name = "ALT_SCHM_TYP_CD")
	private Long alternateSchemeTypeCode;
	
	@Column(name = "ALT_SCHM_CODE_VAL")
	private String alternateSchemeCodeValue;
	
	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;
	
	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;
		
	@Column(name = "ALT_SCHM_CODE_VAL_DESC")
	private String alternateSchemeCodeValueDescription;
	
	@Transient
	private String alternateSchemeTypeDescription;
	
	@Transient
	private Long codeTableId;
	
	@Transient
	private String codeValueDescription;
	
	@Transient
	private String codeTableName;
	
	@Transient
	private String errorCode;
	@Transient
	private String cdValIdBulk;

	/**
	 * Empty Constructor.
	 */
	public CodeValueAlternateScheme() {
		super();
	}
	
	public CodeValueAlternateScheme(String modifiedUser){
		super(modifiedUser);
	}

	/**
	 * @param alternateSchemeTypeCode
	 * @param alternateSchemeTypeDescription
	 */
	public CodeValueAlternateScheme(Long alternateSchemeTypeCode,
			String alternateSchemeTypeDescription) {
		this.alternateSchemeTypeCode = alternateSchemeTypeCode;
		this.alternateSchemeTypeDescription = alternateSchemeTypeDescription;
	}

	/**
	 * @param codeValueAlternateSchemeId
	 * @param codeValueId
	 * @param alternateSchemeTypeCode
	 * @param alternateSchemeCodeValue
	 * @param effectiveDate
	 * @param expirationDate
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param alternateSchemeCodeValueDescription
	 * @param codeTableId
	 * @param codeValueDescription
	 * @param codeTableName
	 */
	public CodeValueAlternateScheme(Long codeValueAlternateSchemeId,
			Long codeValueId, Long alternateSchemeTypeCode,
			String alternateSchemeCodeValue, Date effectiveDate,
			Date expirationDate, String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate,
			String alternateSchemeCodeValueDescription, Integer codeTableId,
			String codeValueDescription, String codeTableName) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.codeValueAlternateSchemeId = codeValueAlternateSchemeId;
		this.codeValueId = codeValueId;
		this.alternateSchemeTypeCode = alternateSchemeTypeCode;
		this.alternateSchemeCodeValue = alternateSchemeCodeValue;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
		this.alternateSchemeCodeValueDescription = alternateSchemeCodeValueDescription;
		this.codeTableId = Long.valueOf(codeTableId);
		this.codeValueDescription = codeValueDescription;
		this.codeTableName = codeTableName;
	}

	/**
	 * @return the codeValueAlternateSchemeId
	 */
	public Long getCodeValueAlternateSchemeId() {
		return codeValueAlternateSchemeId;
	}

	/**
	 * @param codeValueAlternateSchemeId the codeValueAlternateSchemeId to set
	 */
	public void setCodeValueAlternateSchemeId(Long codeValueAlternateSchemeId) {
		this.codeValueAlternateSchemeId = codeValueAlternateSchemeId;
	}

	/**
	 * @return the codeValueId
	 */
	public Long getCodeValueId() {
		return codeValueId;
	}

	/**
	 * @param codeValueId the codeValueId to set
	 */
	public void setCodeValueId(Long codeValueId) {
		this.codeValueId = codeValueId;
	}

	/**
	 * @return the alternateSchemeTypeCode
	 */
	public Long getAlternateSchemeTypeCode() {
		return alternateSchemeTypeCode;
	}

	/**
	 * @param alternateSchemeTypeCode the alternateSchemeTypeCode to set
	 */
	public void setAlternateSchemeTypeCode(Long alternateSchemeTypeCode) {
		this.alternateSchemeTypeCode = alternateSchemeTypeCode;
	}

	/**
	 * @return the alternateSchemeCodeValue
	 */
	public String getAlternateSchemeCodeValue() {
		return alternateSchemeCodeValue;
	}

	/**
	 * @param alternateSchemeCodeValue the alternateSchemeCodeValue to set
	 */
	public void setAlternateSchemeCodeValue(String alternateSchemeCodeValue) {
		this.alternateSchemeCodeValue = alternateSchemeCodeValue;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the alternateSchemeCodeValueDescription
	 */
	public String getAlternateSchemeCodeValueDescription() {
		return alternateSchemeCodeValueDescription;
	}

	/**
	 * @param alternateSchemeCodeValueDescription the alternateSchemeCodeValueDescription to set
	 */
	public void setAlternateSchemeCodeValueDescription(
			String alternateSchemeCodeValueDescription) {
		this.alternateSchemeCodeValueDescription = alternateSchemeCodeValueDescription;
	}

	/**
	 * @return the alternateSchemeTypeDescription
	 */
	public String getAlternateSchemeTypeDescription() {
		return alternateSchemeTypeDescription;
	}

	/**
	 * @param alternateSchemeTypeDescription the alternateSchemeTypeDescription to set
	 */
	public void setAlternateSchemeTypeDescription(
			String alternateSchemeTypeDescription) {
		this.alternateSchemeTypeDescription = alternateSchemeTypeDescription;
	}

	/**
	 * @return the codeTableId
	 */
	public Long getCodeTableId() {
		return codeTableId;
	}

	/**
	 * @param codeTableId the codeTableId to set
	 */
	public void setCodeTableId(Long codeTableId) {
		this.codeTableId = codeTableId;
	}

	/**
	 * @return the codeValueDescription
	 */
	public String getCodeValueDescription() {
		return codeValueDescription;
	}

	/**
	 * @param codeValueDescription the codeValueDescription to set
	 */
	public void setCodeValueDescription(String codeValueDescription) {
		this.codeValueDescription = codeValueDescription;
	}

	/**
	 * @return the codeTableName
	 */
	public String getCodeTableName() {
		return codeTableName;
	}

	/**
	 * @param codeTableName the codeTableName to set
	 */
	public void setCodeTableName(String codeTableName) {
		this.codeTableName = codeTableName;
	}


	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}
	
	
	/**
	 * @return the cdValIdBulk
	 */
	public String getCdValIdBulk() {
		return cdValIdBulk;
	}

	/**
	 * @param cdValIdBulk the cdValIdBulk to set
	 */
	public void setCdValIdBulk(String cdValIdBulk) {
		this.cdValIdBulk = cdValIdBulk;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CodeValueAlternateScheme [codeValueAlternateSchemeId="
				+ codeValueAlternateSchemeId + ", codeValueId=" + codeValueId
				+ ", alternateSchemeTypeCode=" + alternateSchemeTypeCode
				+ ", alternateSchemeCodeValue=" + alternateSchemeCodeValue
				+ ", effectiveDate=" + effectiveDate + ", expirationDate="
				+ expirationDate + ", alternateSchemeCodeValueDescription="
				+ alternateSchemeCodeValueDescription
				+ ", alternateSchemeTypeDescription="
				+ alternateSchemeTypeDescription + ", codeTableId="
				+ codeTableId + ", codeValueDescription="
				+ codeValueDescription + ", codeTableName=" + codeTableName
				+ "]";
	}
}
