package com.dnb.dsc.refdata.core.vo;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.CountryApplicability;
import com.dnb.dsc.refdata.core.entity.SystemApplicability;

public class ScotsBulkUploadMasterVO {
	
	private CodeValue codeValue;
	private CodeValueText codeValueText;
	private CodeValueAlternateScheme codeValAltSchm;
	private SystemApplicability systemAppy;
	private CountryApplicability countryAppy;
	/**
	 * @return the codeValue
	 */
	public CodeValue getCodeValue() {
		return codeValue;
	}
	/**
	 * @param codeValue the codeValue to set
	 */
	public void setCodeValue(CodeValue codeValue) {
		this.codeValue = codeValue;
	}
	/**
	 * @return the codeValueText
	 */
	public CodeValueText getCodeValueText() {
		return codeValueText;
	}
	/**
	 * @param codeValueText the codeValueText to set
	 */
	public void setCodeValueText(CodeValueText codeValueText) {
		this.codeValueText = codeValueText;
	}
	/**
	 * @return the codeValAltSchm
	 */
	public CodeValueAlternateScheme getCodeValAltSchm() {
		return codeValAltSchm;
	}
	/**
	 * @param codeValAltSchm the codeValAltSchm to set
	 */
	public void setCodeValAltSchm(CodeValueAlternateScheme codeValAltSchm) {
		this.codeValAltSchm = codeValAltSchm;
	}
	/**
	 * @return the systemAppy
	 */
	public SystemApplicability getSystemAppy() {
		return systemAppy;
	}
	/**
	 * @param systemAppy the systemAppy to set
	 */
	public void setSystemAppy(SystemApplicability systemAppy) {
		this.systemAppy = systemAppy;
	}
	/**
	 * @return the countryAppy
	 */
	public CountryApplicability getCountryAppy() {
		return countryAppy;
	}
	/**
	 * @param countryAppy the countryAppy to set
	 */
	public void setCountryAppy(CountryApplicability countryAppy) {
		this.countryAppy = countryAppy;
	}
	
	

}
