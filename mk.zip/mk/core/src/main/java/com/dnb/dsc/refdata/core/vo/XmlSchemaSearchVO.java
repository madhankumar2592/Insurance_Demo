/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.core.vo;

import org.springframework.stereotype.Component;

/**
 * This class used as an value object class.
 * 
 * @author Cognizant
 * @version last updated : Apr 13, 2012
 * @see
 * 
 */
@Component
public class XmlSchemaSearchVO {

    private static final long serialVersionUID = 2L;
    private String elementId;
    private String elementName;
    private String elementDescription;
    private String sortOrder;
    private String sortBy;
    private int maxResults;
    private int rowIndex;
    private String searchParam;  
    private int startIndex;
    

    public String getElementId() {
        return elementId;
    }

    public void setElementId(String elementId) {
        this.elementId = elementId;
    }

    public String getElementName() {
        return elementName;
    }

    public void setElementName(String elementName) {
        this.elementName = elementName;
    }

    public String getElementDescription() {
        return elementDescription;
    }

    public void setElementDescription(String elementDescription) {
        this.elementDescription = elementDescription;
    }

    /**
     * @return the sortOrder
     */
    public String getSortOrder() {
        return sortOrder;
    }

    /**
     * @param sortOrder the sortOrder to set
     */
    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    /**
     * @return the sortBy
     */
    public String getSortBy() {
        return sortBy;
    }

    /**
     * @param sortBy the sortBy to set
     */
    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    

    /**
     * @return the maxResults
     */
    public int getMaxResults() {
        return maxResults;
    }

    /**
     * @param maxResults the maxResults to set
     */
    public void setMaxResults(int maxResults) {
        this.maxResults = maxResults;
    }

    /**
     * @return the rowIndex
     */
    public int getRowIndex() {
        return rowIndex;
    }

    /**
     * @param rowIndex the rowIndex to set
     */
    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    /**
     * @return the searchParam
     */
    public String getSearchParam() {
        return searchParam;
    }

    /**
     * @param searchParam the searchParam to set
     */
    public void setSearchParam(String searchParam) {
        this.searchParam = searchParam;
    }

    /**
     * @return the startIndex
     */
    public int getStartIndex() {
        return startIndex;
    }

    /**
     * @param startIndex the startIndex to set
     */
    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "XmlSchemaSearchVO [elementId=" + elementId + ", elementName="
				+ elementName + ", elementDescription=" + elementDescription
				+ ", searchParam=" + searchParam + "]";
	}
}
