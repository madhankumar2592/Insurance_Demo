/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * This class used as an entity class for the IndustrialCodeDescription. The class will have a
 * direct mapping toe DB table inds_code_desc.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "INDS_CODE_DESC")
@NamedQueries({ 
	@NamedQuery(name = "IndustryCodeDescription.removeIndustryCodeDescriptionByIndustryCodeId", query = "DELETE FROM IndustryCodeDescription i where i.industryCodeId = :industryCodeId"),
	@NamedQuery(name = "IndustryCodeDescription.removeByIndustryCodeDescriptionId", query = "DELETE FROM IndustryCodeDescription i where i.industryCodeDescriptionId = :industryCodeDescriptionId ")
})
public class IndustryCodeDescription extends Audit {

	/**
	 * Serial Version ID.
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "INDS_CODE_DESC_ID")
	private Long industryCodeDescriptionId;
	
	@Column(name = "INDS_CODE_ID")
	private Long industryCodeId;
	
	@Column(name = "LANG_CD")
	private Long languageCode;
	
	@Column(name = "WRIT_SCRP_CD")
	private Long writingScriptCode;
	
	@Column(name = "DESC_LEN_CD")
	private Long descriptionLengthCode;
	
	@Column(name = "INDS_DESC")
	private String industryDescription;

	@Transient
	private String changeIndicator;
	
	@Transient
	private String batchIdentity;
	
	/**
	 * @return the batchIdentity
	 */
	public String getBatchIdentity() {
		return batchIdentity;
	}

	/**
	 * @param batchIdentity the batchIdentity to set
	 */
	public void setBatchIdentity(String batchIdentity) {
		this.batchIdentity = batchIdentity;
	}

	
	/**
	 * Empty Constructor.
	 */
	public IndustryCodeDescription() {
		super();
	}

	/**
	 * 
	 * @param industryCodeDescriptionId
	 * @param industryCodeId
	 * @param languageCode
	 * @param writingScriptCode
	 * @param descriptionLengthCode
	 * @param industryDescription
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 */
	public IndustryCodeDescription(Long industryCodeDescriptionId,
			Long industryCodeId, Long languageCode, Long writingScriptCode,
			Long descriptionLengthCode, String industryDescription,
			String createdUser, Date createdDate, String modifiedUser,
			Date modifiedDate) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.industryCodeDescriptionId = industryCodeDescriptionId;
		this.industryCodeId = industryCodeId;
		this.languageCode = languageCode;
		this.writingScriptCode = writingScriptCode;
		this.descriptionLengthCode = descriptionLengthCode;
		this.industryDescription = industryDescription;
	}

	/**
	 * @return the industryCodeDescriptionId
	 */
	public Long getIndustryCodeDescriptionId() {
		return industryCodeDescriptionId;
	}

	/**
	 * @param industryCodeDescriptionId the industryCodeDescriptionId to set
	 */
	public void setIndustryCodeDescriptionId(Long industryCodeDescriptionId) {
		this.industryCodeDescriptionId = industryCodeDescriptionId;
	}

	/**
	 * @return the industryCodeId
	 */
	public Long getIndustryCodeId() {
		return industryCodeId;
	}

	/**
	 * @param industryCodeId the industryCodeId to set
	 */
	public void setIndustryCodeId(Long industryCodeId) {
		this.industryCodeId = industryCodeId;
	}

	/**
	 * @return the languageCode
	 */
	public Long getLanguageCode() {
		return languageCode;
	}

	/**
	 * @param languageCode the languageCode to set
	 */
	public void setLanguageCode(Long languageCode) {
		this.languageCode = languageCode;
	}

	/**
	 * @return the writingScriptCode
	 */
	public Long getWritingScriptCode() {
		return writingScriptCode;
	}

	/**
	 * @param writingScriptCode the writingScriptCode to set
	 */
	public void setWritingScriptCode(Long writingScriptCode) {
		this.writingScriptCode = writingScriptCode;
	}

	/**
	 * @return the descriptionLengthCode
	 */
	public Long getDescriptionLengthCode() {
		return descriptionLengthCode;
	}

	/**
	 * @param descriptionLengthCode the descriptionLengthCode to set
	 */
	public void setDescriptionLengthCode(Long descriptionLengthCode) {
		this.descriptionLengthCode = descriptionLengthCode;
	}

	/**
	 * @return the industryDescription
	 */
	public String getIndustryDescription() {
		return industryDescription;
	}

	/**
	 * @param industryDescription the industryDescription to set
	 */
	public void setIndustryDescription(String industryDescription) {
		this.industryDescription = industryDescription;
	}
	
	/**
	 * @return the changeIndicator
	 */
	public String getChangeIndicator() {
		return changeIndicator;
	}

	/**
	 * @param changeIndicator the changeIndicator to set
	 */
	public void setChangeIndicator(String changeIndicator) {
		this.changeIndicator = changeIndicator;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "IndustryCodeDescription [industryCodeDescriptionId="
				+ industryCodeDescriptionId + ", industryCodeId="
				+ industryCodeId + ", languageCode=" + languageCode
				+ ", writingScriptCode=" + writingScriptCode
				+ ", descriptionLengthCode=" + descriptionLengthCode
				+ ", industryDescription=" + industryDescription
				+ "]";
	}
}
