/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.codehaus.jackson.annotate.JsonBackReference;
import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the GeoUnitCode. The class will have a
 * direct mapping toe DB table geo_unit_code.
 * 
 * @author Cognizant
 * @version last updated : Jan 11, 2011
 * @see
 * 
 */
@Entity
@Table(name = "GEO_UNIT_CODE")
@NamedQueries({
		@NamedQuery(name = "GeoUnitCode.retrieveGeoUnitsByCode", query = "SELECT new GeoUnitCode(c.geoUnitCodeId, "
			+ "cvt.codeValueShortDescription , "
			+ "c.geoUnitId, c.geoCode, n.geoName, cvt1.codeValueShortDescription) "
			+ "FROM GeoUnitCode c, GeoUnitName n, CodeValueText cvt,CodeValueText cvt1,GeoUnit unit where c.geoUnitId = n.geoUnitId "
			+ "and upper(c.geoCode) like concat(upper(:geoCode),'%') "
			+ "and n.nameTypeCode = :nameTypeCode and n.writingScriptCode = :writingScriptCode "
			+ "and n.languageCode = :enLangCode "
			+ "and cvt.languageCode = :enLangCode "
			+ "and cvt.codeValueId = c.geoCodeTypeCode " 
			+ "and c.geoUnitId = unit.geoUnitId " 
			+ "and cvt1.codeValueId = unit.geoUnitTypeCode " 
			+ "and cvt1.languageCode = :enLangCode "
			+ "and c.expirationDate is null and c.expiredByDate is null "
            + "and n.expirationDate is null and n.expiredByDate is null "
			+ "and cvt.expirationDate is null and cvt1.expirationDate is null "
			+ "and unit.expirationDate is null and unit.expiredByDate is null "),
		@NamedQuery(name = "GeoUnitCode.removeGeoUnitByGeoUnitId", query = "DELETE GeoUnitCode g where g.geoUnitId = :geoUnitId") })
public class GeoUnitCode extends Audit implements Serializable  {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "GEO_UNIT_CODE_ID")
	private Long geoUnitCodeId;

	@Column(name = "GEO_CODE_TYP_CD")
	private Long geoCodeTypeCode;

	@Column(name = "GEO_UNIT_ID", insertable = false, updatable = false)
	private Long geoUnitId;

	@Column(name = "GEO_CODE")
	private String geoCode;

	@Column(name = "DATA_PRVD_CD")
	private Long dataProviderCode;

	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;

	@Column(name = "EXPD_BY_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expiredByDate;

	@Transient
	private String officialGeoName;

	@Transient
	private String geoCodeTypeDescription;

	@Transient
	private String changeIndicator;
	
	@Transient
	private String geoUnitType;


	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "GEO_UNIT_ID")
	@JsonBackReference
	private GeoUnit parentGeoUnit;
	@Transient
	private String geoUnitBulkId;
	
	@Transient
	private String errorCD;

	@Transient
	private String dataProviderDescription;
	
	/**
	 * Constructor
	 */
	public GeoUnitCode() {
		super();
	}

	/**
	 * @param geoUnitCodeId
	 * @param geoCodeTypeCode
	 * @param geoUnitId
	 * @param geoCode
	 * @param dataProviderCode
	 * @param effectiveDate
	 * @param expirationDate
	 * @param expiredByDate
	 * @param createdDate
	 * @param modifiedDate
	 * @param modifiedUser
	 * @param createdUser
	 *  @param geoUnitType
	 */
	public GeoUnitCode(Long geoUnitCodeId, Long geoCodeTypeCode,
			Long geoUnitId, String geoCode, Long dataProviderCode,
			Date effectiveDate, Date expiredByDate, Date expirationDate,
			Date createdDate, Date modifiedDate, String modifiedUser,
			String createdUser) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.geoUnitCodeId = geoUnitCodeId;
		this.geoCodeTypeCode = geoCodeTypeCode;
		this.geoUnitId = geoUnitId;
		this.geoCode = geoCode;
		this.dataProviderCode = dataProviderCode;
		this.effectiveDate = effectiveDate;
		this.expiredByDate = expiredByDate;
		this.expirationDate = expirationDate;
		
	}

	/**
	 * The constructor for the retrieve functionality
	 * 
	 * @param geoUnitCodeId
	 * @param geoCodeTypeDescription
	 * @param geoUnitId
	 * @param geoCode
	 * @param officialGeoName
	 * @param geoUnitType
	 */
	public GeoUnitCode(Long geoUnitCodeId, String geoCodeTypeDescription,
			Long geoUnitId, String geoCode, String officialGeoName,String geoUnitType) {
		this.geoUnitCodeId = geoUnitCodeId;
		this.geoCodeTypeDescription = geoCodeTypeDescription;
		this.geoUnitId = geoUnitId;
		this.geoCode = geoCode;
		this.officialGeoName = officialGeoName;
		this.geoUnitType = geoUnitType;
	}

	public GeoUnitCode(Long geoUnitCodeId, String geoCodeTypeDescription,
			Long geoUnitId, String geoCode, String officialGeoName) {
		this.geoUnitCodeId = geoUnitCodeId;
		this.geoCodeTypeDescription = geoCodeTypeDescription;
		this.geoUnitId = geoUnitId;
		this.geoCode = geoCode;
		this.officialGeoName = officialGeoName;
			}
	/**
	 * @return the geoUnitCodeId
	 */
	public Long getGeoUnitCodeId() {
		return geoUnitCodeId;
	}

	/**
	 * @param geoUnitCodeId
	 *            the geoUnitCodeId to set
	 */
	public void setGeoUnitCodeId(Long geoUnitCodeId) {
		this.geoUnitCodeId = geoUnitCodeId;
	}

	/**
	 * @return the geoCodeTypeCode
	 */
	public Long getGeoCodeTypeCode() {
		return geoCodeTypeCode;
	}

	/**
	 * @param geoCodeTypeCode
	 *            the geoCodeTypeCode to set
	 */
	public void setGeoCodeTypeCode(Long geoCodeTypeCode) {
		this.geoCodeTypeCode = geoCodeTypeCode;
	}

	/**
	 * @return the geoUnitId
	 */
	public Long getGeoUnitId() {
		return geoUnitId;
	}

	/**
	 * @param geoUnitId
	 *            the geoUnitId to set
	 */
	public void setGeoUnitId(Long geoUnitId) {
		this.geoUnitId = geoUnitId;
	}

	/**
	 * @return the geoCode
	 */
	public String getGeoCode() {
		return geoCode;
	}

	/**
	 * @param geoCode
	 *            the geoCode to set
	 */
	public void setGeoCode(String geoCode) {
		this.geoCode = geoCode;
	}

	/**
	 * @return the dataProviderCode
	 */
	public Long getDataProviderCode() {
		return dataProviderCode;
	}

	/**
	 * @param dataProviderCode
	 *            the dataProviderCode to set
	 */
	public void setDataProviderCode(Long dataProviderCode) {
		this.dataProviderCode = dataProviderCode;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate
	 *            the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate
	 *            the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	
	}

	/**
	 * @return the expiredByDate
	 */
	public Date getExpiredByDate() {
		return expiredByDate;
	}

	/**
	 * @param expiredByDate
	 *            the expiredByDate to set
	 */
	public void setExpiredByDate(Date expiredByDate) {
		this.expiredByDate = expiredByDate;
	}

	/**
	 * @return the officialGeoName
	 */
	public String getOfficialGeoName() {
		return officialGeoName;
	}

	/**
	 * @param officialGeoName
	 *            the officialGeoName to set
	 */
	public void setOfficialGeoName(String officialGeoName) {
		this.officialGeoName = officialGeoName;
	}

	/**
	 * @return the geoCodeTypeDescription
	 */
	public String getGeoCodeTypeDescription() {
		return geoCodeTypeDescription;
	}

	/**
	 * @param geoCodeTypeDescription
	 *            the geoCodeTypeDescription to set
	 */
	public void setGeoCodeTypeDescription(String geoCodeTypeDescription) {
		this.geoCodeTypeDescription = geoCodeTypeDescription;
	}

	/**
	 * @return the changeIndicator
	 */
	public String getChangeIndicator() {
		return changeIndicator;
	}

	/**
	 * @param changeIndicator
	 *            the changeIndicator to set
	 */
	public void setChangeIndicator(String changeIndicator) {
		this.changeIndicator = changeIndicator;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GeoUnitCode [geoUnitCodeId=" + geoUnitCodeId
				+ ", geoCodeTypeCode=" + geoCodeTypeCode + ", geoUnitId="
				+ geoUnitId + ", geoCode=" + geoCode + "expiredByDate="
				+ expiredByDate +",expirationDate="+expirationDate+ ", dataProviderCode=" + dataProviderCode				
				+ "]";
	}

	/**
	 * @return the parentGeoUnit
	 */
	public GeoUnit getParentGeoUnit() {
		return parentGeoUnit;
	}

	/**
	 * @param parentGeoUnit
	 *            the parentGeoUnit to set
	 */
	public void setParentGeoUnit(GeoUnit parentGeoUnit) {
		this.parentGeoUnit = parentGeoUnit;
	}	
	/**
	 * @return the geoUnitBulkId
	 */
	public String getGeoUnitBulkId() {
		return geoUnitBulkId;
	}

	/**
	 * @param geoUnitBulkId the geoUnitBulkId to set
	 */
	public void setGeoUnitBulkId(String geoUnitBulkId) {
		this.geoUnitBulkId = geoUnitBulkId;
	}

	/**
	 * @return the errorCD
	 */
	public String getErrorCD() {
		return errorCD;
	}

	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(String errorCD) {
		this.errorCD = errorCD;
	}

	/**
	 * @return the dataProviderDescription
	 */
	public String getDataProviderDescription() {
		return dataProviderDescription;
	}

	/**
	 * @param dataProviderDescription the dataProviderDescription to set
	 */
	public void setDataProviderDescription(String dataProviderDescription) {
		this.dataProviderDescription = dataProviderDescription;
	}

	public void setGeoUnitType(String geoUnitType) {
		this.geoUnitType = geoUnitType;
	}

	public String getGeoUnitType() {
		return geoUnitType;
	}	
}
