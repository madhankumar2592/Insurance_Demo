/**
 * 
 */
package com.dnb.dsc.refdata.core.vo;

import java.util.Date;

/**
 * @author cognizant
 *
 */
public class GeoCurrencySearchVO extends PaginationVO{

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	private Long geoCurrencyId;
	private Long geoUnitId;
	private Long currencyCode;
	private Date effectiveDate;
	private Date endDate;
	private String currencyCodeDescription;
	private String countryName;
	private String viewType;
	
	public GeoCurrencySearchVO(){
	    
	}
	
	
	/**
	 * @return the geoCurrencyId
	 */
	public Long getGeoCurrencyId() {
		return geoCurrencyId;
	}
	/**
	 * @param geoCurrencyId the geoCurrencyId to set
	 */
	public void setGeoCurrencyId(Long geoCurrencyId) {
		this.geoCurrencyId = geoCurrencyId;
	}
	/**
	 * @return the geoUnitId
	 */
	public Long getGeoUnitId() {
		return geoUnitId;
	}
	/**
	 * @param geoUnitId the geoUnitId to set
	 */
	public void setGeoUnitId(Long geoUnitId) {
		this.geoUnitId = geoUnitId;
	}
	/**
	 * @return the currencyCode
	 */
	public Long getCurrencyCode() {
		return currencyCode;
	}
	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(Long currencyCode) {
		this.currencyCode = currencyCode;
	}
	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return the currencyCodeDescription
	 */
	public String getCurrencyCodeDescription() {
		return currencyCodeDescription;
	}
	/**
	 * @param currencyCodeDescription the currencyCodeDescription to set
	 */
	public void setCurrencyCodeDescription(String currencyCodeDescription) {
		this.currencyCodeDescription = currencyCodeDescription;
	}
	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}
	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	/**
	 * @return the viewType
	 */
	public String getViewType() {
		return viewType;
	}
	/**
	 * @param viewType the viewType to set
	 */
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	
}
