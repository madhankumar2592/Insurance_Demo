/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * This class used as an entity class for the Code Table. The class
 * will have a direct mapping toe DB table cd_tbl.
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
@Entity
@Table(name = "SCR_GRU")
@NamedQueries({
		@NamedQuery(name = "ScoreGranularity.retrieveScoreTableList", query = "SELECT new CodeTable(c.codeTableId, c.codeTableName) FROM CodeTable c order by c.codeTableId"),
		@NamedQuery(name = "ScoreGranularity.countTable", query = "SELECT count(c.codeTableId) FROM CodeTable c WHERE c.codeTableId = :codeTableId")})
public class ScoreGranularity extends Audit implements Serializable {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "SCR_GRU_ID")
	private Long scoreGraId;

	@Column(name = "SCR_GRU_CD")
	private Long scoreGraCode;
	
	/*@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "scoreGraId")
	private List<ScoreTypeAssc> scoreTypeAssc;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "scoreGraId")
	private List<ScoreGranularityAssc> scoreGranularityAssc;*/
	
	@Column(name = "INAC_INDC")
	private Long scoreInvalidIndicator;
	
	@Transient
	private String changeIndicator;

	public String getChangeIndicator() {
		return changeIndicator;
	}

	public void setChangeIndicator(String changeIndicator) {
		this.changeIndicator = changeIndicator;
	}
	public Long getScoreInvalidIndicator() {
		return scoreInvalidIndicator;
	}

	public void setScoreInvalidIndicator(Long scoreInvalidIndicator) {
		this.scoreInvalidIndicator = scoreInvalidIndicator;
	}
	
	/*public List<ScoreGranularityAssc> getScoreGranularityAssc() {
		return scoreGranularityAssc;
	}

	public void setScoreGranularityAssc(
			List<ScoreGranularityAssc> scoreGranularityAssc) {
		this.scoreGranularityAssc = scoreGranularityAssc;
	}

	public List<ScoreTypeAssc> getScoreGranularity() {
		return scoreTypeAssc;
	}

	public void setScoreGranularity(List<ScoreTypeAssc> scoreTypeAssc) {
		this.scoreTypeAssc = scoreTypeAssc;
	}*/

	/**
	 * The default constructor
	 */
	public ScoreGranularity() {
		super();
	}

	public Long getScoreGraId() {
		return scoreGraId;
	}

	public void setScoreGraId(Long scoreGraId) {
		this.scoreGraId = scoreGraId;
	}

	public Long getScoreGraCode() {
		return scoreGraCode;
	}

	public void setScoreGraCode(Long scoreGraCode) {
		this.scoreGraCode = scoreGraCode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ScoreGranularity [scoreGraId=" + scoreGraId + ", scoreGraCode="
				+ scoreGraCode +"]";
	}


}
