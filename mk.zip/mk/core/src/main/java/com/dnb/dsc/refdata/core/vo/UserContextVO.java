/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

/**
 * This class used as an value object class for the UserContextVO. The class
 * will store the user attributes retrieved as part of the OAM component.
 *
 * @author Cognizant
 * @version last updated : Apr 12, 2012
 * @see
 *
 */
public class UserContextVO implements Serializable {

	private static final long serialVersionUID = 8993265291802855778L;
	/**
	 * The user email identifier attribute
	 */
	private String userIdentifier;
	/**
	 * The user first name attribute
	 */
	private String userFirstName;
	/**
	 * The user last name attribute
	 */
	private String userLastName;
	/**
	 * The user country geoUnit identifier attribute
	 */
	private Long userCountryGeoUnitId;
	/**
	 * The user country code attribute
	 */
	private String userCountryCode;
	/**
	 * The user country code attribute
	 */
	private List<UserRoleVO> userRoles;

	/**
	 * The default constructor
	 */
	public UserContextVO() {
	}

	/**
	 * @return the userIdentifier
	 */
	public String getUserIdentifier() {
		return userIdentifier;
	}

	/**
	 * @param userIdentifier the userIdentifier to set
	 */
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	/**
	 * @return the userFirstName
	 */
	public String getUserFirstName() {
		return userFirstName;
	}

	/**
	 * @param userFirstName the userFirstName to set
	 */
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	/**
	 * @return the userLastName
	 */
	public String getUserLastName() {
		return userLastName;
	}

	/**
	 * @param userLastName the userLastName to set
	 */
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	/**
	 * @return the userCountryGeoUnitId
	 */
	public Long getUserCountryGeoUnitId() {
		return userCountryGeoUnitId;
	}

	/**
	 * @param userCountryGeoUnitId the userCountryGeoUnitId to set
	 */
	public void setUserCountryGeoUnitId(Long userCountryGeoUnitId) {
		this.userCountryGeoUnitId = userCountryGeoUnitId;
	}

	/**
	 * @return the userCountryCode
	 */
	public String getUserCountryCode() {
		return userCountryCode;
	}

	/**
	 * @param userCountryCode the userCountryCode to set
	 */
	public void setUserCountryCode(String userCountryCode) {
		this.userCountryCode = userCountryCode;
	}

	/**
	 * @return the userRoles
	 */
	public List<UserRoleVO> getUserRoles() {
		return userRoles;
	}

	/**
	 * @param userRoles the userRoles to set
	 */
	public void setUserRoles(List<UserRoleVO> userRoles) {
		this.userRoles = userRoles;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserContextVO [userIdentifier=" + userIdentifier
				+ ", userFirstName=" + userFirstName + ", userLastName="
				+ userLastName + ", userCountryGeoUnitId="
				+ userCountryGeoUnitId + ", userCountryCode=" + userCountryCode
				+ ", userRoles=" + userRoles + "]";
	}	
}
