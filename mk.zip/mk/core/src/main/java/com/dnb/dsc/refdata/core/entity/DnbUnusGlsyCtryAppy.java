package com.dnb.dsc.refdata.core.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

@Entity
@Table(name = "dnb_unus_glsy_ctry_appy")
@NamedQueries({
	@NamedQuery(name = "DnbUnusGlsyCtryAppy.removeDnbUnusGlsyCtryAppyById", query = "DELETE DnbUnusGlsyCtryAppy d where d.dnbUnusGlsyId = :dnbUnusGlsyId") })

public class DnbUnusGlsyCtryAppy extends Audit{

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "DNB_UNUS_GLSY_CTRY_APPY_ID")
	private Long dnbUnusGlsyCtryAppyId;

	@Column(name = "DNB_UNUS_GLSY_ID")
	private Long dnbUnusGlsyId;

	@Column(name = "CTRY_GEO_UNIT_ID")
	private Long ctryGeoUnitId;

	@Column(name = "expn_dt")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expnDt;

	@Column(name = "effv_dt")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effvDt;
	
	@Transient
	private String dnbUnsGlyBulkId;
	
	@Transient
	private Integer errorCD;
	

	/**
	 * @return the errorCD
	 */
	public Integer getErrorCD() {
		return errorCD;
	}
	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(Integer errorCD) {
		this.errorCD = errorCD;
	}
	public DnbUnusGlsyCtryAppy(){
		
	}
	/**
	 * @return the dnbUnusGlsyCtryAppyId
	 */
	public Long getDnbUnusGlsyCtryAppyId() {
		return dnbUnusGlsyCtryAppyId;
	}

	/**
	 * @param dnbUnusGlsyCtryAppyId the dnbUnusGlsyCtryAppyId to set
	 */
	public void setDnbUnusGlsyCtryAppyId(Long dnbUnusGlsyCtryAppyId) {
		this.dnbUnusGlsyCtryAppyId = dnbUnusGlsyCtryAppyId;
	}

	/**
	 * @return the dnbUnusGlsyId
	 */
	public Long getDnbUnusGlsyId() {
		return dnbUnusGlsyId;
	}

	/**
	 * @param dnbUnusGlsyId the dnbUnusGlsyId to set
	 */
	public void setDnbUnusGlsyId(Long dnbUnusGlsyId) {
		this.dnbUnusGlsyId = dnbUnusGlsyId;
	}

	/**
	 * @return the ctryGeoUnitId
	 */
	public Long getCtryGeoUnitId() {
		return ctryGeoUnitId;
	}

	/**
	 * @param ctryGeoUnitId the ctryGeoUnitId to set
	 */
	public void setCtryGeoUnitId(Long ctryGeoUnitId) {
		this.ctryGeoUnitId = ctryGeoUnitId;
	}

	/**
	 * @return the expnDt
	 */
	public Date getExpnDt() {
		return expnDt;
	}

	/**
	 * @param expnDt the expnDt to set
	 */
	public void setExpnDt(Date expnDt) {
		this.expnDt = expnDt;
	}

	/**
	 * @return the effvDt
	 */
	public Date getEffvDt() {
		return effvDt;
	}

	/**
	 * @param effvDt the effvDt to set
	 */
	public void setEffvDt(Date effvDt) {
		this.effvDt = effvDt;
	}
	
	
	/**
	 * @return the dnbUnsGlyBulkId
	 */
	public String getDnbUnsGlyBulkId() {
		return dnbUnsGlyBulkId;
	}
	/**
	 * @param dnbUnsGlyBulkId the dnbUnsGlyBulkId to set
	 */
	public void setDnbUnsGlyBulkId(String dnbUnsGlyBulkId) {
		this.dnbUnsGlyBulkId = dnbUnsGlyBulkId;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DnbUnusGlsyCtryAppy [dnbUnusGlsyCtryAppyId="
				+ dnbUnusGlsyCtryAppyId + ", dnbUnusGlsyId=" + dnbUnusGlsyId
				+ ", ctryGeoUnitId=" + ctryGeoUnitId + ", expnDt=" + expnDt
				+ ", effvDt=" + effvDt + "]";
	}

}
