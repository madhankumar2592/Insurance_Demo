/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * This class used as an entity class for the IndustrialCodeMap. The class will have a
 * direct mapping toe DB table INDS_CODE_MAP.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Embeddable
public class IndustryCodeMapPK implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name = "FROM_INDS_CODE_ID")
	private Long fromIndustryCodeId;
	
	@Column(name = "TO_INDS_CODE_ID")
	private Long toIndustryCodeId;
	
	/**
	 * Empty Constructor.
	 */
	public IndustryCodeMapPK() {
		super();
	}

	/**
	 * @return the fromIndustryCodeId
	 */
	public Long getFromIndustryCodeId() {
		return fromIndustryCodeId;
	}

	/**
	 * @param fromIndustryCodeId the fromIndustryCodeId to set
	 */
	public void setFromIndustryCodeId(Long fromIndustryCodeId) {
		this.fromIndustryCodeId = fromIndustryCodeId;
	}

	/**
	 * @return the toIndustryCode
	 */
	public Long getToIndustryCodeId() {
		return toIndustryCodeId;
	}

	/**
	 * @param toIndustryCode the toIndustryCode to set
	 */
	public void setToIndustryCodeId(Long toIndustryCodeId) {
		this.toIndustryCodeId = toIndustryCodeId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "IndustryCodeMapPK [fromIndustryCodeId=" + fromIndustryCodeId
				+ ", toIndustryCodeId=" + toIndustryCodeId + "]";
	}
}
