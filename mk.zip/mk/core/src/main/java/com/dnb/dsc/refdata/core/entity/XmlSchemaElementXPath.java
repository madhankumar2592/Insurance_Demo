/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * TODO
 * 
 * @author Cognizant
 * @version last updated : Apr 19, 2012
 * @see
 * 
 */
@Entity
@Table(name = "XML_SCMA_ELE_XPTH")
@NamedQueries({
        @NamedQuery(name = "XmlSchemaElementXPath.removeByXmlSchemaElementId", query ="DELETE FROM XmlSchemaElementXPath xse where xse.xmlSchemaElementId = :xmlSchemaElementId")
        })
public class XmlSchemaElementXPath extends Audit implements Serializable {

    private static final long serialVersionUID = 2L;

    @Id
    @Column(name = "XML_SCMA_ELE_XPTH_ID")
    private Long xmlSchemaElementXPathId;

    @Column(name = "XML_SCMA_ELE_ID")
    private String xmlSchemaElementId;

    @Column(name = "XML_SCMA_REC_TYP_CD")
    private Long xmlSchemaRecordTypeCd;

    @Column(name = "ELE_XPTH_TXT")
    private String elementXPathText;

    /**
     * 
     */
    public XmlSchemaElementXPath() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param xmlSchemaElementXPathId
     * @param xmlSchemaElementId
     * @param xmlSchemaRecordTypeCd
     * @param elementXPathText
     * @param rowCreationId
     * @param rowCreationTimeStamp
     * @param rowModificationId
     * @param rowModificationTimeStamp
     */
    public XmlSchemaElementXPath(Long xmlSchemaElementXPathId, String xmlSchemaElementId, Long xmlSchemaRecordTypeCd,
            String elementXPathText, String rowCreationId, Date rowCreationTimeStamp, String rowModificationId,
            Date rowModificationTimeStamp) {
        super(rowCreationId, rowCreationTimeStamp, rowModificationId, rowModificationTimeStamp);
        this.xmlSchemaElementXPathId = xmlSchemaElementXPathId;
        this.xmlSchemaElementId = xmlSchemaElementId;
        this.xmlSchemaRecordTypeCd = xmlSchemaRecordTypeCd;
        this.elementXPathText = elementXPathText;
    }

    /**
     * @return the xmlSchemaElementXPathId
     */
    public Long getXmlSchemaElementXPathId() {
        return xmlSchemaElementXPathId;
    }

    /**
     * @param xmlSchemaElementXPathId
     *            the xmlSchemaElementXPathId to set
     */
    public void setXmlSchemaElementXPathId(Long xmlSchemaElementXPathId) {
        this.xmlSchemaElementXPathId = xmlSchemaElementXPathId;
    }

    /**
     * @return the xmlSchemaElementId
     */
    public String getXmlSchemaElementId() {
        return xmlSchemaElementId;
    }

    /**
     * @param xmlSchemaElementId
     *            the xmlSchemaElementId to set
     */
    public void setXmlSchemaElementId(String xmlSchemaElementId) {
        this.xmlSchemaElementId = xmlSchemaElementId;
    }

    /**
     * @return the xmlSchemaRecordTypeCd
     */
    public Long getXmlSchemaRecordTypeCd() {
        return xmlSchemaRecordTypeCd;
    }

    /**
     * @param xmlSchemaRecordTypeCd
     *            the xmlSchemaRecordTypeCd to set
     */
    public void setXmlSchemaRecordTypeCd(Long xmlSchemaRecordTypeCd) {
        this.xmlSchemaRecordTypeCd = xmlSchemaRecordTypeCd;
    }

    /**
     * @return the elementXPathText
     */
    public String getElementXPathText() {
        return elementXPathText;
    }

    /**
     * @param elementXPathText
     *            the elementXPathText to set
     */
    public void setElementXPathText(String elementXPathText) {
        this.elementXPathText = elementXPathText;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "XmlSchemaElementXPath [xmlSchemaElementXPathId="
				+ xmlSchemaElementXPathId + ", xmlSchemaElementId="
				+ xmlSchemaElementId + ", xmlSchemaRecordTypeCd="
				+ xmlSchemaRecordTypeCd + ", elementXPathText="
				+ elementXPathText + "]";
	}
}
