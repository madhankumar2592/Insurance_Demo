/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "RESC_DTL")
@NamedQueries({
	@NamedQuery(name = "ResourceDetails.removeRescDtlById", query = "DELETE FROM ResourceDetails c where c.rescDtlId not in ( :rescDtlId) and rescId = :rescId"),
	@NamedQuery(name = "ResourceDetails.removerescDtlById", query = "DELETE FROM ResourceDetails c where c.rescId not in ( :rescIdNot) and c.rescId in ( :rescId)")
	
})
public class ResourceDetails extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "RESC_DTL_ID")
	private Long rescDtlId;
		
	@Column(name = "RESC_ID")
	private Long rescId;
	
	@Column(name = "RESC_DTL_MTDT_CD")
	private Long rescDtlMetaDataCode;
	
	@Column(name = "RESC_MTDT_VAL")
	private String rescDtlMetaDataVal;	
	
	public Long getRescDtlId() {
		return rescDtlId;
	}

	public void setRescDtlId(Long rescDtlId) {
		this.rescDtlId = rescDtlId;
	}

	public Long getRescId() {
		return rescId;
	}

	public void setRescId(Long rescId) {
		this.rescId = rescId;
	}

	public Long getRescDtlMetaDataCode() {
		return rescDtlMetaDataCode;
	}

	public void setRescDtlMetaDataCode(Long rescDtlMetaDataCode) {
		this.rescDtlMetaDataCode = rescDtlMetaDataCode;
	}

	public String getRescDtlMetaDataVal() {
		return rescDtlMetaDataVal;
	}

	public void setRescDtlMetaDataVal(String rescDtlMetaDataVal) {
		this.rescDtlMetaDataVal = rescDtlMetaDataVal;
	}

	/**
	 * Empty Constructor.
	 */
	public ResourceDetails() {
		super();
	}
	
	public ResourceDetails(Long rescDtlId) {
		super();
		this.rescDtlId = rescDtlId;
	}
	/*public ResourceDetails(Long ResourceDetailsVersion) {
		super();
		this.ResourceDetailsVersion = ResourceDetailsVersion;
	}*/
	public ResourceDetails(Long rescDtlId, Long rescId) {
		super();
		this.rescDtlId = rescDtlId;
		this.rescId = rescId;
	}
	
	
	/**
	 * 
	 * @param ResourceDetailsId
	 * @param ResourceDetailsVersion
	 * @param ResourceDetailsTypeId
	 * @param ResourceDetailsMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public ResourceDetails(Long rescDtlId, Long rescId, Long rescDtlMetaDataCode, String rescDtlMetaDataVal,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.rescDtlId = rescDtlId;
		this.rescId = rescId;
		this.rescDtlMetaDataCode = rescDtlMetaDataCode;
		this.rescDtlMetaDataVal = rescDtlMetaDataVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ResourceDetails [rescDtlId=" + rescDtlId
				+ ", rescId=" + rescId 
				+"rescDtlMetaDataCode=" + rescDtlMetaDataCode+ 
				", rescDtlMetaDataVal=" + rescDtlMetaDataVal + 
				 "]";
	}
	
	
}
