/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
/**
 * This class used as an entity class for the Code Value. The class
 * will have a direct mapping toe DB table cd_val.
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
@Entity
@Table(name = "CTRY_APPY")
@NamedQueries({
		@NamedQuery(name = "CountryApplicability.retrieveCountriesForCodeValue", query = "SELECT distinct new CountryApplicability(ca.ctryAppyId, ca.countryGeoUnitId,ca.applicabilityIndicator, ca.codeTableId,ca.codeValueId,ca.effectiveDate,ca.expirationDate, ca.createdUser,ca.createdDate, ca.modifiedDate,ca.modifiedUser, gn.geoName) FROM CountryApplicability ca, GeoUnitName gn WHERE  ca.applicabilityIndicator = 0 AND gn.geoUnitId = ca.countryGeoUnitId and gn.languageCode = 39 and gn.nameTypeCode = 32 AND ca.codeValueId= :codeValueId order by gn.geoName"),
		@NamedQuery(name = "CountryApplicability.retrieveCountries", query = "SELECT distinct new CountryApplicability(ca.countryGeoUnitId, gn.geoName) FROM CountryApplicability ca, GeoUnitName gn WHERE gn.geoUnitId = ca.countryGeoUnitId and gn.languageCode = 39 and gn.nameTypeCode = 32 AND ca.codeTableId= :codeTableId and ca.expirationDate is null order by gn.geoName"),
		@NamedQuery(name = "CountryApplicability.retrieveCountriesForCodeTable", query = "SELECT distinct new CountryApplicability(ca.ctryAppyId, ca.countryGeoUnitId,ca.applicabilityIndicator, ca.codeTableId,ca.codeValueId,ca.effectiveDate,ca.expirationDate, ca.createdUser,ca.createdDate, ca.modifiedDate,ca.modifiedUser, gn.geoName) FROM CountryApplicability ca, GeoUnitName gn WHERE gn.geoUnitId = ca.countryGeoUnitId and gn.languageCode = 39 and gn.nameTypeCode = 32 AND ca.codeTableId= :codeTableId AND ca.applicabilityIndicator = 1 ORDER BY gn.geoName"),
		@NamedQuery(name = "CountryApplicability.retrieveCountriesForReview", query = "SELECT ca FROM CountryApplicability ca WHERE  ca.applicabilityIndicator = 1 AND ca.codeTableId= :codeTableId"),
		@NamedQuery(name = "CountryApplicability.retrieveCountriesForCodeValueReview", query = "SELECT ca FROM CountryApplicability ca WHERE  ca.applicabilityIndicator = 0 AND ca.codeValueId= :codeValueId"),
		@NamedQuery(name = "CountryApplicability.retrieveAllCountries", query = "SELECT distinct new CountryApplicability(ca.countryGeoUnitId, gn.geoName) FROM CountryApplicability ca, GeoUnitName gn WHERE gn.geoUnitId = ca.countryGeoUnitId and gn.languageCode = 39 and gn.nameTypeCode = 32 order by gn.geoName"),
		@NamedQuery(name = "CountryApplicability.searchCountryByCodeTable", query = "SELECT ca FROM CountryApplicability ca,GeoUnitName g WHERE  ca.countryGeoUnitId=g.geoUnitId AND g.geoName like :codeValueDescription and rownum=1"),
		@NamedQuery(name = "CountryApplicability.retrieveCountryForCode", query = "SELECT distinct new CountryApplicability(ca.ctryAppyId, ca.countryGeoUnitId, ca.applicabilityIndicator, ca.codeTableId, ca.codeValueId, cvt.codeValueDescription, ct.codeTableName) FROM CountryApplicability ca, CodeValueText cvt, CodeTable ct WHERE cvt.codeValueId = ca.codeValueId and ct.codeTableId = ca.codeTableId and ca.countryGeoUnitId = :countryGeoUnitId order by ca.codeTableId"),
		@NamedQuery(name = "CountryApplicability.retrieveCountryForCodeWithoutDescription", query = "SELECT distinct new CountryApplicability(ca.ctryAppyId, ca.countryGeoUnitId, ca.applicabilityIndicator, ca.codeTableId, ca.codeValueId) FROM CountryApplicability ca WHERE ca.countryGeoUnitId = :countryGeoUnitId order by ca.codeTableId"),
		@NamedQuery(name = "CountryApplicability.retrieveTxnMarketApplicabilities", query = "SELECT distinct ca FROM CountryApplicability ca WHERE ca.countryGeoUnitId = :countryGeoUnitId "),
		@NamedQuery(name = "CountryApplicability.removeCountryApplicabilities", query = "DELETE CountryApplicability ca WHERE ca.countryGeoUnitId = :countryGeoUnitId "),
		@NamedQuery(name = "CountryApplicability.removeCountryByCodeTableById", query = "DELETE CountryApplicability ca WHERE ca.codeTableId = :codeTableId and applicabilityIndicator = 1 "),
                @NamedQuery(name = "CountryApplicability.removeCountryAppyByCodeValueId", query = "DELETE CountryApplicability ca WHERE ca.codeValueId = :codeValueId and applicabilityIndicator = 0 "),
		@NamedQuery(name = "CountryApplicability.retrieveCodeValueCountryForCode", query = "SELECT distinct new CountryApplicability(ca.ctryAppyId, ca.countryGeoUnitId, ca.applicabilityIndicator, ca.codeTableId, ca.codeValueId, cvt.codeValueDescription, ct.codeTableName) FROM CountryApplicability ca, CodeValueText cvt, CodeTable ct WHERE ca.applicabilityIndicator = 0 and cvt.codeValueId = ca.codeValueId and ct.codeTableId = ca.codeTableId and cvt.languageCode = 39 and ca.countryGeoUnitId = :countryGeoUnitId order by ca.codeTableId"),
		@NamedQuery(name = "CountryApplicability.retrieveCodeTableCountryForCode", query = "SELECT distinct new CountryApplicability(ca.ctryAppyId, ca.countryGeoUnitId, ca.applicabilityIndicator, ca.codeTableId, ca.codeValueId, null, ct.codeTableName) FROM CountryApplicability ca, CodeTable ct WHERE ca.applicabilityIndicator = 1 and ct.codeTableId = ca.codeTableId and ca.countryGeoUnitId = :countryGeoUnitId order by ca.codeTableId"),
		@NamedQuery(name = "CountryApplicability.lockCountryApplicabilityForEdit", query = "SELECT distinct new CountryApplicability(ca.modifiedUser) FROM CountryApplicability ca WHERE ca.countryGeoUnitId = :countryGeoUnitId")
})
public class CountryApplicability extends Audit implements Serializable {

	private static final long serialVersionUID = 23L;

	@Id
	@Column(name = "CTRY_APPY_ID")
	private Long ctryAppyId;

	@Column(name = "CTRY_GEO_UNIT_ID")
	private Long countryGeoUnitId;

	@Column(name = "CD_TBL_APPY_INDC")
	private Integer applicabilityIndicator;

	@Column(name = "CD_TBL_ID")
	private Long codeTableId;

	@Column(name = "CD_VAL_ID")
	private Long codeValueId;

	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.DATE)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.DATE)
	private Date expirationDate;

	@Transient
	private String geoName;

	@Transient
	private String codeValueDescription;

	@Transient
	private String codeTableName;
	
	@Transient
	private String errorCode;
	
	@Transient
	private String cdValIdBulk;

	@Transient
	private String ctryChangeIndicator;

	
	public CountryApplicability(){
		super();
	}

	public CountryApplicability(Long ctryAppyId, Long countryGeoUnitId,
			Integer applicabilityIndicator, Long codeTableId, Long codeValueId,
			String codeValueDescription, String codeTableName) {
		super();
		this.ctryAppyId = ctryAppyId;
		this.countryGeoUnitId = countryGeoUnitId;
		this.applicabilityIndicator = applicabilityIndicator;
		this.codeTableId = codeTableId;
		this.codeValueId = codeValueId;
		this.codeValueDescription=codeValueDescription;
		this.codeTableName = codeTableName;
	}

	public CountryApplicability(Long ctryAppyId, Long countryGeoUnitId,
			Integer applicabilityIndicator, Long codeTableId, Long codeValueId) {
		super();
		this.ctryAppyId = ctryAppyId;
		this.countryGeoUnitId = countryGeoUnitId;
		this.applicabilityIndicator = applicabilityIndicator;
		this.codeTableId = codeTableId;
		this.codeValueId = codeValueId;
	}

	/**
	 *
	 * @param ctryAppyId
	 * @param countryGeoUnitId
	 * @param applicabilityIndicator
	 * @param codeTableId
	 * @param codeValueId
	 * @param effectiveDate
	 * @param expirationDate
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedDate
	 * @param modifiedUser
	 * @param geoName
	 */
	public CountryApplicability(Long ctryAppyId, Long countryGeoUnitId,
			Integer applicabilityIndicator, Long codeTableId, Long codeValueId,
			Date effectiveDate, Date expirationDate, String createdUser,
			Date createdDate, Date modifiedDate, String modifiedUser,
			String geoName) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.ctryAppyId = ctryAppyId;
		this.countryGeoUnitId = countryGeoUnitId;
		this.applicabilityIndicator = applicabilityIndicator;
		this.codeTableId = codeTableId;
		this.codeValueId = codeValueId;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
		this.geoName = geoName;
	}

	public CountryApplicability(Long countryGeoUnitId, String geoName) {
		super();
		this.countryGeoUnitId = countryGeoUnitId;
		this.geoName = geoName;
	}

	public CountryApplicability(String modifiedUser) {
		super();
		this.setModifiedUser(modifiedUser);
	}
	/**
	 * @return the ctryAppyId
	 */
	public Long getCtryAppyId() {
		return ctryAppyId;
	}

	/**
	 * @param ctryAppyId the ctryAppyId to set
	 */
	public void setCtryAppyId(Long ctryAppyId) {
		this.ctryAppyId = ctryAppyId;
	}

	/**
	 * @return the ctryGeoUnitId
	 */
	public Long getCountryGeoUnitId() {
		return countryGeoUnitId;
	}

	/**
	 * @param ctryGeoUnitId the ctryGeoUnitId to set
	 */
	public void setCountryGeoUnitId(Long ctryGeoUnitId) {
		this.countryGeoUnitId = ctryGeoUnitId;
	}

	/**
	 * @return the applicabilityIndicator
	 */
	public Integer getApplicabilityIndicator() {
		return applicabilityIndicator;
	}

	/**
	 * @param applicabilityIndicator the applicabilityIndicator to set
	 */
	public void setApplicabilityIndicator(Integer applicabilityIndicator) {
		this.applicabilityIndicator = applicabilityIndicator;
	}

	/**
	 * @return the codeTableId
	 */
	public Long getCodeTableId() {
		return codeTableId;
	}

	/**
	 * @param codeTableId the codeTableId to set
	 */
	public void setCodeTableId(Long codeTableId) {
		this.codeTableId = codeTableId;
	}

	/**
	 * @return the codeValueId
	 */
	public Long getCodeValueId() {
		return codeValueId;
	}

	/**
	 * @param codeValueId the codeValueId to set
	 */
	public void setCodeValueId(Long codeValueId) {
		this.codeValueId = codeValueId;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the geoName
	 */
	public String getGeoName() {
		return geoName;
	}

	/**
	 * @param geoName the geoName to set
	 */
	public void setGeoName(String geoName) {
		this.geoName = geoName;
	}

	/**
	 * @return the codeValueDescription
	 */
	public String getCodeValueDescription() {
		return codeValueDescription;
	}

	/**
	 * @param codeValueDescription the codeValueDescription to set
	 */
	public void setCodeValueDescription(String codeValueDescription) {
		this.codeValueDescription = codeValueDescription;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CountryApplicability [ctryAppyId=" + ctryAppyId
				+ ", countryGeoUnitId=" + countryGeoUnitId
				+ ", applicabilityIndicator=" + applicabilityIndicator
				+ ", codeTableId=" + codeTableId + ", codeValueId="
				+ codeValueId + ", effectiveDate=" + effectiveDate
				+ ", expirationDate=" + expirationDate + ", geoName=" + geoName
				+ ", codeValueDescription=" + codeValueDescription + "]";
	}

	/**
	 * @return the codeTableName
	 */
	public String getCodeTableName() {
		return codeTableName;
	}

	/**
	 * @param codeTableName the codeTableName to set
	 */
	public void setCodeTableName(String codeTableName) {
		this.codeTableName = codeTableName;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @return the cdValIdBulk
	 */
	public String getCdValIdBulk() {
		return cdValIdBulk;
	}

	/**
	 * @param cdValIdBulk the cdValIdBulk to set
	 */
	public void setCdValIdBulk(String cdValIdBulk) {
		this.cdValIdBulk = cdValIdBulk;
	}
	
	/**
	 * @return the ctryChangeIndicator
	 */
	public String getCtryChangeIndicator() {
		return ctryChangeIndicator;
	}

	/**
	 * @param ctryChangeIndicator the ctryChangeIndicator to set
	 */
	public void setCtryChangeIndicator(String ctryChangeIndicator) {
		this.ctryChangeIndicator = ctryChangeIndicator;
	}



}
