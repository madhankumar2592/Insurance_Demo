/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.util.Date;

import org.springframework.stereotype.Component;

/**
 * This class used as an value object class.
 * 
 * @author Cognizant
 * @version last updated : Dec 09, 2011
 * @see
 * 
 */
@Component
public class GeoSearchCriteriaVO extends PaginationVO {

	private static final long serialVersionUID = 2L;

	private String continentGeoCode;

	private String continentName;

	private String countryName;

	private String countryGeoCode;

	private String stateName;

	private String stateGeoCode;

	private String countyName;

	private String countyGeoCode;

	private String postTownName;

	private String postTownGeoCode;

	private String postCode;

	private String postCodeGeoCode;

	private String language;
	
	private String activeIndicator;
	
	private String recordStatus;
	
	private Date lastUpdatedDate;

	/**
	 * Constructor
	 */
	public GeoSearchCriteriaVO() {
		super();
	}

	/**
	 * Constructor with arguments
	 * 
	 * @param continentGeoCode
	 * @param continentName
	 * @param countryGeoCode
	 * @param countryName
	 * @param stateGeoCode
	 * @param stateName
	 * @param countyGeoCode
	 * @param countyName
	 * @param postTownGeoCode
	 * @param postTownName
	 * @param postCodeGeoCode
	 * @param postCode
	 * @param language
	 */
	public GeoSearchCriteriaVO(final String continentGeoCode, final String continentName,
			final String countryGeoCode, final String countryName,
			final String stateGeoCode, final String stateName,
			final String countyGeoCode, final String countyName,
			final String postTownGeoCode, final String postTownName,
			final String postCodeGeoCode, final String postCode,
			final String language) {
		this.continentGeoCode = continentGeoCode;
		this.continentName = continentName;
		this.countryGeoCode = countryGeoCode;
		this.countryName = countryName;
		this.stateGeoCode = stateGeoCode;
		this.stateName = stateName;
		this.countyGeoCode = countyGeoCode;
		this.countyName = countyName;
		this.postTownGeoCode = postTownGeoCode;
		this.postTownName = postTownName;
		this.postCodeGeoCode = postCodeGeoCode;
		this.postCode = postCode;
		this.language = language;
	}

	/**
	 * @return the continentGeoCode
	 */
	public String getContinentGeoCode() {
		return continentGeoCode;
	}

	/**
	 * @param continentGeoCode
	 *            the continentGeoCode to set
	 */
	public void setContinentGeoCode(String continentGeoCode) {
		this.continentGeoCode = continentGeoCode;
	}

	/**
	 * @return the continentName
	 */
	public String getContinentName() {
		return continentName;
	}

	/**
	 * @param continentName
	 *            the continentName to set
	 */
	public void setContinentName(String continentName) {
		this.continentName = continentName;
	}

	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}

	/**
	 * @param countryName
	 *            the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	/**
	 * @return the countryGeoCode
	 */
	public String getCountryGeoCode() {
		return countryGeoCode;
	}

	/**
	 * @param countryGeoCode
	 *            the countryGeoCode to set
	 */
	public void setCountryGeoCode(String countryGeoCode) {
		this.countryGeoCode = countryGeoCode;
	}

	/**
	 * @return the stateName
	 */
	public String getStateName() {
		return stateName;
	}

	/**
	 * @param stateName
	 *            the stateName to set
	 */
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	/**
	 * @return the stateGeoCode
	 */
	public String getStateGeoCode() {
		return stateGeoCode;
	}

	/**
	 * @param stateGeoCode
	 *            the stateGeoCode to set
	 */
	public void setStateGeoCode(String stateGeoCode) {
		this.stateGeoCode = stateGeoCode;
	}

	/**
	 * @return the countyName
	 */
	public String getCountyName() {
		return countyName;
	}

	/**
	 * @param countyName
	 *            the countyName to set
	 */
	public void setCountyName(String countyName) {
		this.countyName = countyName;
	}

	/**
	 * @return the countyGeoCode
	 */
	public String getCountyGeoCode() {
		return countyGeoCode;
	}

	/**
	 * @param countyGeoCode
	 *            the countyGeoCode to set
	 */
	public void setCountyGeoCode(String countyGeoCode) {
		this.countyGeoCode = countyGeoCode;
	}

	/**
	 * @return the postTownName
	 */
	public String getPostTownName() {
		return postTownName;
	}

	/**
	 * @param postTownName
	 *            the postTownName to set
	 */
	public void setPostTownName(String postTownName) {
		this.postTownName = postTownName;
	}

	/**
	 * @return the postTownGeoCode
	 */
	public String getPostTownGeoCode() {
		return postTownGeoCode;
	}

	/**
	 * @param postTownGeoCode
	 *            the postTownGeoCode to set
	 */
	public void setPostTownGeoCode(String postTownGeoCode) {
		this.postTownGeoCode = postTownGeoCode;
	}

	/**
	 * @return the postCode
	 */
	public String getPostCode() {
		return postCode;
	}

	/**
	 * @param postCode
	 *            the postCode to set
	 */
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	/**
	 * @return the postCodeGeoCode
	 */
	public String getPostCodeGeoCode() {
		return postCodeGeoCode;
	}

	/**
	 * @param postCodeGeoCode
	 *            the postCodeGeoCode to set
	 */
	public void setPostCodeGeoCode(String postCodeGeoCode) {
		this.postCodeGeoCode = postCodeGeoCode;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language
	 *            the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the activeIndicator
	 */
	public String getActiveIndicator() {
		return activeIndicator;
	}

	/**
	 * @param activeIndicator the activeIndicator to set
	 */
	public void setActiveIndicator(String activeIndicator) {
		this.activeIndicator = activeIndicator;
	}

	/**
	 * @return the recordStatus
	 */
	public String getRecordStatus() {
		return recordStatus;
	}

	/**
	 * @param recordStatus the recordStatus to set
	 */
	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	/**
	 * @return the lastUpdatedDate
	 */
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	/**
	 * @param lastUpdatedDate the lastUpdatedDate to set
	 */
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GeoSearchCriteriaVO [continentGeoCode=" + continentGeoCode
				+ ", continentName=" + continentName + ", countryName="
				+ countryName + ", countryGeoCode=" + countryGeoCode
				+ ", stateName=" + stateName + ", stateGeoCode=" + stateGeoCode
				+ ", countyName=" + countyName + ", countyGeoCode="
				+ countyGeoCode + ", postTownName=" + postTownName
				+ ", postTownGeoCode=" + postTownGeoCode + ", postCode="
				+ postCode + ", postCodeGeoCode=" + postCodeGeoCode
				+ ", language=" + language + ", activeIndicator="
				+ activeIndicator + ", recordStatus=" + recordStatus
				+ ", lastUpdatedDate=" + lastUpdatedDate + ", maxResults="
				+ maxResults + ", pageCount=" + pageCount + ", rowIndex="
				+ rowIndex + ", sortOrder=" + sortOrder + ", sortBy=" + sortBy
				+ "]";
	}
}
