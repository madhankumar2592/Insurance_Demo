package com.dnb.dsc.refdata.core.vo;

public class IndusCodeDescBulkUploadVO {

}
