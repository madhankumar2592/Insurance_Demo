package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.ScoreGranularity;

public class ScoreDtlVO
	 implements Serializable {

			private static final long serialVersionUID = 8993265291802855778L;
			/**
			 * The code attribute
			 */
			private Long scoreTypeCode;

			private Long scoreMarketCode;

			private Double scoreVersion;
			
			private String loggedInUser;
			
			private List<Double> scoreVersionList;
			private List<ScoreGranularity> scoreGranularity;
			private List<CodeValue> scoreMarketCodes;
			private List<CodeValue> scoreTyp;
			private List<CodeValue> scoreGraCodes;
			private List<CodeValue> scoreAttributeCodes;			
			
			private List<Long> scoreGranularty;
			
			public List<Long> getScoreGranularty() {
				return scoreGranularty;
			}

			public void setScoreGranularty(List<Long> scoreGranularty) {
				this.scoreGranularty = scoreGranularty;
			}

			public List<Double> getScoreVersionList() {
				return scoreVersionList;
			}

			public void setScoreVersionList(List<Double> scoreVersionList) {
				this.scoreVersionList = scoreVersionList;
			}

			public String getLoggedInUser() {
				return loggedInUser;
			}

			public void setLoggedInUser(String loggedInUser) {
				this.loggedInUser = loggedInUser;
			}

			public List<CodeValue> getScoreMarketCodes() {
				return scoreMarketCodes;
			}

			public void setScoreMarketCodes(List<CodeValue> scoreMarketCodes) {
				this.scoreMarketCodes = scoreMarketCodes;
			}

			public List<CodeValue> getScoreTyp() {
				return scoreTyp;
			}

			public void setScoreTyp(List<CodeValue> scoreTyp) {
				this.scoreTyp = scoreTyp;
			}

			public List<CodeValue> getScoreGraCodes() {
				return scoreGraCodes;
			}

			public void setScoreGraCodes(List<CodeValue> scoreGraCodes) {
				this.scoreGraCodes = scoreGraCodes;
			}

			public List<CodeValue> getScoreAttributeCodes() {
				return scoreAttributeCodes;
			}

			public void setScoreAttributeCodes(List<CodeValue> scoreAttributeCodes) {
				this.scoreAttributeCodes = scoreAttributeCodes;
			}

			public Long getScoreTypeCode() {
				return scoreTypeCode;
			}

			public void setScoreTypeCode(Long scoreTypeCode) {
				this.scoreTypeCode = scoreTypeCode;
			}

			public Long getScoreMarketCode() {
				return scoreMarketCode;
			}

			public void setScoreMarketCode(Long scoreMarketCode) {
				this.scoreMarketCode = scoreMarketCode;
			}

			public Double getScoreVersion() {
				return scoreVersion;
			}

			public void setScoreVersion(Double scoreVersion) {
				this.scoreVersion = scoreVersion;
			}

			public List<ScoreGranularity> getScoreGranularity() {
				return scoreGranularity;
			}

			public void setScoreGranularity(List<ScoreGranularity> scoreGranularity) {
				this.scoreGranularity = scoreGranularity;
			}

			public static long getSerialversionuid() {
				return serialVersionUID;
			}
			
			
}
