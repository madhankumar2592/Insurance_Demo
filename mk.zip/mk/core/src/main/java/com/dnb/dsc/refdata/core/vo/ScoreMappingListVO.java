package com.dnb.dsc.refdata.core.vo;

import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValue;
import com.dnb.dsc.refdata.core.entity.ScoreGranularity;

public class ScoreMappingListVO {
	/**
	 * scoreTypeCode.
	 */
	private Long scoreTypeCode;
	/**
	 * scoreMarketCode.
	 */
	private Long scoreMarketCode;
	/**
	 * scoreVersion.
	 */
	private Double scoreVersion;
	/**
	 * scoreVersionList.
	 */
	private List<Double> scoreVersionList;
	/**
	 * scoreGranularity.
	 */
	private List<ScoreGranularity> scoreGranularity;
	/**
	 * scoreMarketCodes.
	 */
	private List<CodeValueVO> scoreMarketCodes;
	/**
	 * scoreTyp.
	 */
	private List<CodeValue> scoreTyp;
	/**
	 * scoreGraCodes.
	 */
	private List<CodeValue> scoreGraCodes;
	/**
	 * scoreAttributeCodes.
	 */
	private List<CodeValue> scoreAttributeCodes;			
	/**
	 * scoreGranularty.
	 */
	private List<Long> scoreGranularty;
	
	private String granularityCodesString;
	
	private String granularityString;	
	
	public String getGranularityString() {
		return granularityString;
	}

	public void setGranularityString(String granularityString) {
		this.granularityString = granularityString;
	}

	public List<Long> getScoreGranularty() {
		return scoreGranularty;
	}

	public void setScoreGranularty(List<Long> scoreGranularty) {
		this.scoreGranularty = scoreGranularty;
	}

	public List<Double> getScoreVersionList() {
		return scoreVersionList;
	}

	public void setScoreVersionList(List<Double> scoreVersionList) {
		this.scoreVersionList = scoreVersionList;
	}

	public List<CodeValueVO> getScoreMarketCodes() {
		return scoreMarketCodes;
	}

	public void setScoreMarketCodes(List<CodeValueVO> list) {
		this.scoreMarketCodes = list;
	}

	public List<CodeValue> getScoreTyp() {
		return scoreTyp;
	}

	public void setScoreTyp(List<CodeValue> scoreTyp) {
		this.scoreTyp = scoreTyp;
	}

	public List<CodeValue> getScoreGraCodes() {
		return scoreGraCodes;
	}

	public void setScoreGraCodes(List<CodeValue> scoreGraCodes) {
		this.scoreGraCodes = scoreGraCodes;
	}

	public List<CodeValue> getScoreAttributeCodes() {
		return scoreAttributeCodes;
	}

	public void setScoreAttributeCodes(List<CodeValue> scoreAttributeCodes) {
		this.scoreAttributeCodes = scoreAttributeCodes;
	}

	public Long getScoreTypeCode() {
		return scoreTypeCode;
	}

	public void setScoreTypeCode(Long scoreTypeCode) {
		this.scoreTypeCode = scoreTypeCode;
	}

	public Long getScoreMarketCode() {
		return scoreMarketCode;
	}

	public void setScoreMarketCode(Long scoreMarketCode) {
		this.scoreMarketCode = scoreMarketCode;
	}

	public Double getScoreVersion() {
		return scoreVersion;
	}

	public void setScoreVersion(Double scoreVersion) {
		this.scoreVersion = scoreVersion;
	}

	public List<ScoreGranularity> getScoreGranularity() {
		return scoreGranularity;
	}

	public void setScoreGranularity(List<ScoreGranularity> scoreGranularity) {
		this.scoreGranularity = scoreGranularity;
	}

	/**
	 * @param granularityCodesString the granularityCodesString to set
	 */
	public void setGranularityCodesString(String granularityCodesString) {
		this.granularityCodesString = granularityCodesString;
	}

	/**
	 * @return the granularityCodesString
	 */
	public String getGranularityCodesString() {
		return granularityCodesString;
	}

}
