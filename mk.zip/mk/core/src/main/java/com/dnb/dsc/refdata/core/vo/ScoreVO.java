package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.ScoreType;

public class ScoreVO implements Serializable {

	private static final long serialVersionUID = 8993265291802855778L;
	/**
	 * The code attribute
	 */
	private Long scoreId;

	private Long scoreTypeId;
	
	private Long scoreMarketCode;

	private Double scoreVersion;
	
	private List<ScoreType> scoreTypes;
	
	private List<Long> scoreTypesCodes;
	
	private String indicator;
	
	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	public List<Long> getScoreTypesCodes() {
		return scoreTypesCodes;
	}

	public void setScoreTypesCodes(List<Long> scoreTypesCodes) {
		this.scoreTypesCodes = scoreTypesCodes;
	}

	public Long getScoreId() {
		return scoreId;
	}

	public void setScoreId(Long scoreId) {
		this.scoreId = scoreId;
	}

	public Long getScoreTypeId() {
		return scoreTypeId;
	}

	public void setScoreTypeId(Long scoreTypeId) {
		this.scoreTypeId = scoreTypeId;
	}

	public Long getScoreMarketCode() {
		return scoreMarketCode;
	}

	public void setScoreMarketCode(Long scoreMarketCode) {
		this.scoreMarketCode = scoreMarketCode;
	}

	public Double getScoreVersion() {
		return scoreVersion;
	}

	public void setScoreVersion(Double scoreVersion) {
		this.scoreVersion = scoreVersion;
	}

	public List<ScoreType> getScoreTypes() {
		return scoreTypes;
	}

	public void setScoreTypes(List<ScoreType> scoreTypes) {
		this.scoreTypes = scoreTypes;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ScoreVO [scoreId=" + scoreId + "scoreTypeId" + scoreTypeId
				+ ", scoreMarketCode=" + scoreMarketCode + "]";
	}

}
