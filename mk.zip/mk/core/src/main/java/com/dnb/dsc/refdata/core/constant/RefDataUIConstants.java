/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.constant;

/**
 * This class contains general constants used across application. The class will
 * contain constants declared in the web/ presentation layers.
 *
 * @author Cognizant
 * @version last updated : Jan 20, 2012
 * @see
 *
 */
public class RefDataUIConstants {

	/**
	 * The constant geo type for the geo name code search page.
	 */
	public static final String GEO_NAME_CODE_SEARCH_GEOTYPE = "geoType";

	/**
	 * The constant geo search string for the geo name code search page.
	 */
	public static final String GEO_NAME_CODE_SEARCH_STRING = "geoSearchString";

	/**
	 * The constant for the geo name radio button in the geo name code search
	 * page.
	 */
	public static final String GEO_NAME_CODE_SEARCH_RADIO_NAME = "geoNameRadio";

	/**
	 * The constant for the geo code radio button in the geo name code search
	 * page.
	 */
	public static final String GEO_NAME_CODE_SEARCH_RADIO_CODE = "geoCodeRadio";

	/**
	 * The constant for the geo unit id request parameter send from geo name
	 * code search page.
	 */
	public static final String GEO_UNIT_ID_REQ_PARAM = "geoUnitId";

	/**
	 * The constant for the infermentTextId request parameter send from inferment search
	 */
	public static final String INFERMENT_TEXT_ID_REQ_PARAM = "infermentTextId";

	/**
	 * The constant for the geo unit id request parameter send from geo unit id
	 * search page.
	 */
	public static final String GEO_UNIT_SEARCH_ID_REQ_PARAM = "id";

	/**
	 * The constant for language code request parameter send from geo name code
	 * search page.
	 */
	public static final String GEO_NAME_CODE_SEARCH_LANGCD = "langCode";
	/**
	 * The constant for language code session variable.
	 */
	public static final String GEO_NAME_CODE_SEARCH_LANGCD_SESSION = "languageCodeValues";

	/**
	 * The constant for country list session variable.
	 */
	public static final String GEO_SEARCH_COUNTRYLIST_SESSION = "countryList";

	/**
	 * The constant for country list session variable.
	 */
	public static final String GEO_SEARCH_COUNTRY_GROUP_LIST_SESSION = "countryGroupList";

	/**
	 * The constant for country code search variable.
	 */
	public static final String COUNTRY_GROUPS_SEARCH_COUNTRY_CODE = "countryCode";

	/**
	 * The constant for Currency Code list session variable.
	 */
	public static final String CURRENCY_SEARCH_CURRENCY_CODE_SESSION = "currencyCodeValues";

	/**
	 * The constant for Currency Code list session variable.
	 */
	public static final String INDUSTRY_CODES_SEARCH_INDUSTRY_CODE_TYPES_SESSION = "industryCodeTypes";
	
	/**
	 * The constant for Currency Code list session variable.
	 */
	public static final String INDUSTRY_CODES_DESC_LENGTH_CODE_SESSION = "industryCodeDescLengthCode";

	/**
     * The constant for Currency Code list session variable.
     */
    public static final String INDUSTRY_CODES_SEARCH_INDUSTRY_CODE_INFERMENT_TYPES_SESSION = "industryCodeInfermentTypes";

	/**
	 * The constant for Data Provider Code list session variable.
	 */
	public static final String CURRENCY_SEARCH_DATA_PROVIDER_CODE_SESSION = "dataProviderCodeValues";

	/**
	 * The constant for Date Precision Code list session variable.
	 */
	public static final String CURRENCY_VIEW_DATE_PRECISION_CODE_SESSION = "datePrecisionCodeValues";

	/**
	 * The constant for the Currency Exchange id request parameter send from
	 * Currency Exchange search page.
	 */
	public static final String CURRENCY_EXCHANGE_ID_REQ_PARAM = "currencyExchangeId";

	/**
     * The constant for the Currency Exchange id request parameter send from
     * Currency Exchange search page.
     */
    public static final String CTRL_WORDS_INFERMENT_TEXT_REQ_PARAM = "infermentText";

	/**
	 * The constant for the Continent Hierarchy text
	 */
	public static final String HIERARCHY_CONTINENT_TEXT = "Continent";

	/**
	 * The constant for the Country Hierarchy text
	 */
	public static final String HIERARCHY_COUNTRY_TEXT = "Country";

	/**
	 * The constant for the County Hierarchy text
	 */
	public static final String HIERARCHY_COUNTY_TEXT = "County";

	/**
	 * The constant for the Territory Hierarchy text
	 */
	public static final String HIERARCHY_TERRITORY_TEXT = "Territory";

	/**
	 * The constant for the PostTown Hierarchy text
	 */
	public static final String HIERARCHY_POSTTOWN_TEXT = "PostTown";

	/**
	 * The constant for the PostCode Hierarchy text
	 */
	public static final String HIERARCHY_POSTCODE_TEXT = "PostCode";

	/**
	 * The constant for the Country US Code
	 */
	public static final Long CODE_GEO_UNIT_ID_UNITED_STATES = 1073L;

	/**
	 * The constant for the toggle indicator code
	 */
	public static final String TOGGLE_INDICATOR_CODE = "CODE";

	/**
	 * The constant for the toggle indicator value
	 */
	public static final String TOGGLE_INDICATOR_VALUE = "VALUE";

	/**
	 * The constant for code table list session variable.
	 */
	public static final String SCOTS_LIST_CODE_TABLE_SESSION = "codeTableList";
	/**
	 * The constant for code languages session variable.
	 */
	public static final String SCOTS_LIST_CODE_LANGUAGE_SESSION = "codeLanguages";
	/**
	 * The constant for code languages session variable.
	 */
	public static final String LEGAL_FORM_LANGUAGE_SESSION = "legalFormLanguages";
    public static final String CTRL_WORD_LIST_CODE_LANGUAGE_SESSION = "infermentCodeLanguages";
	/**
	 * The constant for the OAM Header - HTTP_OBLIX_UID
	 */
	public static final String ONELOGIN_HEADER_HTTP_OBLIX_UID = "CAMS-HTTP-DNB-LOGINID";
	/**
	 * The constant for the OAM Header - DNB_FIRST_NAME
	 */
	public static final String ONELOGIN_HEADER_DNB_FIRST_NAME = "CAMS-HTTP-DNB-GIVENNAME";
	/**
	 * The constant for the OAM Header - DNB_LAST_NAME
	 */
	public static final String ONELOGIN_HEADER_DNB_LAST_NAME = "CAMS-HTTP-DNB-LASTNAME";
	/**
	 * The constant for the OAM Header - DNB_COUNTRY
	 */
	public static final String ONELOGIN_HEADER_DNB_COUNTRY = "CAMS-HTTP-DNB-COUNTRY";
	/**
	 * The constant for the OAM Header - DNB_USER_ROLE
	 */
	public static final String ONELOGIN_HEADER_DNB_USER_ROLE = "CAMS-HTTP-DNB-USERROLE";
	/**
	 * The constant for the OAM Header - app separator
	 */
	public static final String ONELOGIN_HEADER_APPLICATION_SEPARATOR = ":";
	/**
	 * The constant for the REFDATA_USER_CONTEXT
	 */
	public static final String REFDATA_USER_CONTEXT = "REFDATA_USER_CONTEXT";
	/**
	 * The constant for the OAM_HEADER_APP_REF_DATA
	 */
	public static final String OAM_HEADER_APP_REF_DATA = "31";
  /**
     * The constant for the Geo Currency id request parameter send from
     * Geo Currency search page.
     */
    public static final String GEO_CURRENCY_ID_REQ_PARAM = "geoCurrencyId";

	/**
	 * The constant for workFlow - PROCESS_NME_ID 400
	 */
	public static final Long WRKFLW_PROCESS_NME_ID_TRAN_PROC = 400L;
	
	/**
	 * The constant for workFlow - PROCESS_NME_ID 401
	 */
	public static final Long WRKFLW_CRCY_BULK_UPLOAD_PROCESS_NME_ID_TRAN_PROC = 401L;
	/**
	 * The constant for workFlow - CREATE_PROCESS_INSTANCE 500
	 */
	public static final Long WRKFLW_REQ_TYPE_ID_CREATE_PROCESS_INSTANCE = 500L;
	/**
	 * The constant for workFlow - GET_TASK_LIST 502
	 */
	public static final Long WRKFLW_REQ_TYPE_ID_GET_TASK_LIST = 502L;
	/**
	 * The constant for workFlow - PERFORM_TASK 503
	 */
	public static final Long WRKFLW_REQ_TYPE_ID_PERFORM_TASK = 503L;
	/**
	 * The constant for workFlow -  504
	 */
	public static final Long WRKFLW_REQ_TYPE_ID_504 = 504L;
	/**
	 * The constant for workFlow -  505
	 */
	public static final Long WRKFLW_REQ_TYPE_ID_505 = 505L;
	/**
	 * The constant for workFlow - COMPLETE 800
	 */
	public static final Long WRKFLW_TASK_STAT_TYP_ID_COMPLETE = 800L;
	/**
	 * The constant for workFlow -  803
	 */
	public static final Long WRKFLW_TASK_STAT_TYP_ID_803 = 803L;
	
	public static final Long WRKFLW_TASK_STAT_TYP_ID_801 = 801L;
	
	/**
	 * The constant for workFlow - SUBMITTER 300
	 */
	public static final Long WRKFLW_USER_ROLE_ID_SUBMITTER = 300L;
	/**
	 * The constant for workFlow - APPROVER 301
	 */
	public static final Long WRKFLW_USER_ROLE_ID_APPROVER = 301L;
	/**
	 * The constant for workFlow -  903
	 */
	public static final Long WRKFLW_TSK_ASG_TYP_ID_901 = 901L;
	/**
	 * The constant for workFlow -  904
	 */
	public static final Long WRKFLW_TSK_ASG_TYP_ID_902 = 902L;
	/**
	 * The constant for group code separator
	 */
	public static final String REFDATA_GROUP_CODE_SEPARATOR = "~";

	/**
	 * The constant for the DNB System Code
	 */
	public static final Long DNB_SYSTEM_CODE_FOR_ALL_SYSTEMS= 2000L;

	/**
	 * The constant for the Code Table Id
	 */
	public static final Long CODE_TABLE_ID_FOR_ALL_SYSTEMS= 270L;

	/**
	 * The constant for page navigation source - Geo Unit Id Search 
	 */
	public static final String PAGE_NAVIGATE_SRC_GEO_UNIT_ID_SEARCH = "GeoUnitIdSearch";
	
	/**
	 * The constant for refdata application deploy environment - LOCAL
	 */
	public static final String REFDATA_APP_DEPLOY_ENV_LOCAL = "LOCAL";
}
