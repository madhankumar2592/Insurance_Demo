/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.constant;

/**
 * This class contains constant variables for properties key added in RefData
 * environment properties file.
 *
 * @author	Cognizant
 * @version	last updated : Jan 20, 2012
 * @see
 */
public class RefDataPropertiesConstants {

	/**
	 * The constants SCoTS writing script code Latin
	 */
	public static final Long CODE_WRITING_SCRIPT_LATIN = 19349L;

	/**
	 * The constants SCoTS geographic name type code Official
	 */
	public static final Long CODE_GEOGRAPHIC_NAME_TYPE_OFFICIAL = 32L;

	/**
	 * The constants SCoTS language code English
	 */
	public static final Long CODE_LANGUAGE_ENGLISH = 39L;

	/**
	 * The constants SCoTS description length code
	 */
	public static final Long DESCRIPTION_LENGTH_240 = 9120L;

	/**
	 * The constants SCoTS GeoUnit Type code COUNTRY
	 */
	public static final Long CODE_GEO_UNIT_TYPE_COUNTRY = 128L;

	/**
	 * The constants SCoTS GeoUnit Type code COUNTRY
	 */
	public static final Long CODE_GEO_UNIT_TYPE_CONTINENT = 129L;

	/**
	 * The constants SCoTS GeoUnit Type code COUNTRY GROUP
	 */
	public static final Long CODE_GEO_UNIT_TYPE_COUNTRY_GROUP = 130L;

	/**
	 * The constants SCoTS GeoUnit Type code TERRITORY
	 */
	public static final Long CODE_GEO_UNIT_TYPE_TERRITORY = 5392L;

	/**
	 * The constants SCoTS GeoUnit Type code COUNTY
	 */
	public static final Long CODE_GEO_UNIT_TYPE_COUNTY = 5153L;

	/**
	 * The constants SCoTS GeoUnit Type code POST TOWN
	 */
	public static final Long CODE_GEO_UNIT_TYPE_POST_TOWN = 126L;

	/**
	 * The constants SCoTS GeoUnit Type code POST CODE
	 */
	public static final Long CODE_GEO_UNIT_TYPE_POST_CODE = 324L;

	/**
	 * The constants SCoTS Table id for Language
	 */
	public static final Integer CODE_TABLE_ID_LANGUAGE = 3;

	/**
	 * The constants SCoTS Table id for Information Sources
	 */
	public static final Integer CODE_TABLE_ID_INFO_SOURCES = 29;

	/**
	 * The constants SCoTS Table id for Information Sources
	 */
	public static final Integer CODE_TABLE_ID_GEO_NAME_TYPE = 2;

	/**
	 * The constants SCoTS Table id for Information Sources
	 */
	public static final String CODE_TABLE_ID_GEO_NAME_TYPE_STRING = "2";

	/**
	 * The constants SCoTS Table id for Geographic Unit Type
	 */
	public static final Integer CODE_TABLE_ID_GEO_UNIT_TYPE = 13;

	/**
	 * The constants SCoTS Table id for Geographic Code Type
	 */
	public static final Integer CODE_TABLE_ID_GEO_CODE_TYPE = 514;

	/**
	 * The constants SCoTS Table id for Currency
	 */
	public static final Integer CODE_TABLE_ID_CURRENCY = 1;

	/**
	 * The constants SCoTS Table id for Industry Code Type Code
	 */
	public static final Integer CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE = 30;

	/**
	 * The constants SCoTS Table id for Industry Code Type Code
	 */
	public static final String CODE_TABLE_ID_INDUSTRY_CODE_TYPE_CODE_STRING = "30";

	/**
	 * The constants SCoTS Table id for Date Precision
	 */
	public static final Integer CODE_TABLE_ID_DATA_PRECISION = 14;

	/**
	 * The constants SCoTS Table id for Writing Script Code
	 */
	public static final Integer CODE_TABLE_ID_WRTITING_SCRIPT_CODE = 466;

	/**
	 * The constants SCoTS Table id for Gender Code
	 */
	public static final Integer CODE_TABLE_ID_GENDER_CODE = 18;

	/**
	 * The constants SCoTS Table id for Coding Scheme
	 */
	public static final Integer CODE_TABLE_ID_CODING_SCHEME = 266;

	/**
	 * The constants SCoTS Table id for Coding Scheme
	 */
	public static final String CODE_TABLE_ID_CODING_SCHEME_STRING = "266";
	
	/**
	 * The constants SCoTS Table id for Numeric Sign Code
	 */
	public static final Integer CODE_TABLE_ID_NUMERIC_SIGN_CODE = 634;

	/**
	 * The constants for the domain Geography
	 */
	public static final String DOMAIN_CODE_GEOGRAPHY = "Geography";

	/**
	 * The constants for the domain Industry
	 */
	public static final String DOMAIN_CODE_INDUSTRY_CODE = "Industry Codes";

	/**
	 * The constants for the domain Currency Exchange
	 */
	public static final String DOMAIN_CODE_CURRENCY_EXCHANGE = "Currency Exchange";

	/**
	 * The constants for the domain SCOTS
	 */
	public static final String DOMAIN_CODE_SCOTS = "SCoTS";

	/**
	 * The constants for the domain Financial Templates
	 */
	public static final String DOMAIN_CODE_FINANCIAL_TEMPLATES = "Financial Templates";
	/**
	 * The constants for the domain Control Words
	 */
	public static final String DOMAIN_CODE_CONTROL_WORDS = "Control Words";

	/**
	 * The constants for the domain XML Schema Labels
	 */
	public static final String DOMAIN_CODE_XML_SCHEMA_LABELS = "XML Schema Labels";
	
	public static final String DOMAIN_CODE_GSRL_METADATA = "GSRL Metadata";

	/**
	 * The constants for the reference data transaction - Insert
	 */
	public static final String TRANSACTION_TYPE_INSERT = "INSERT";

	/**
	 * The constants for the reference data transaction - Update
	 */
	public static final String TRANSACTION_TYPE_UPDATE = "UPDATE";

	/**
	 * The constants for the reference data transaction - Delete
	 */
	public static final String TRANSACTION_TYPE_DELETE = "DELETE";

	/**
	 * The constants for the database -Staging SoR
	 */
	public static final String DATABASE_STAGING_SOR = "STG";

	/**
	 * The constants for the database -Transaction DB
	 */
	public static final String DATABASE_TRANSACTION_DB = "TXN";

	/**
	 * The constants for the WorkQueue - Review Record NO CHANGE
	 */
	public static final String WQ_REVIEW_RECORD_NO_CHANGE = "NOCHANGE";
	
	/**
	 * The constants for the WorkQueue - Review Record EXPIRED
	 */
	public static final String WQ_REVIEW_RECORD_EXPIRED = "EXPIRED";

	/**
	 * The constants for the WorkQueue - Review Record NEW
	 */
	public static final String WQ_REVIEW_RECORD_NEW = "NEW";

	/**
	 * The constants for the WorkQueue - Review Record OLD
	 */
	public static final String WQ_REVIEW_RECORD_OLD = "OLD";

	/**
	 * The constants for the WorkQueue - Review Record CORRECTED
	 */
	public static final String WQ_REVIEW_RECORD_CORRECTED = "CORRECTED";

	/**
	 * The constants for the WorkQueue - Review Record CORRECTED
	 */
	public static final String WQ_REVIEW_RECORD_DUPLICATE = "DUPLICATE";

	/**
	 * The constants for the WorkQueue - Review Record DELETED
	 */
	public static final String WQ_REVIEW_RECORD_DELETED = "DELETED";

	/**
	 * The constants for the default date time format
	 */
	public static final String DEFAULT_DATE_TIME_FORMAT = "yyyy-MM-dd";
	/**
	 * The constants for the Download date time format
	 */
	public static final String UI_DWNL_DATE_TIME_FORMAT = "yyyy-MM-dd HH:MI:SS";

	/**
	 * The constants for the default user for work-flow
	 */
	public static final String DEFAULT_REFDATA_USER = "refui";

	/**
	 * The constants SCoTS Table id for Industry Code Group Level
	 */
	public static final Integer CODE_TABLE_ID_INDUSTRY_CODE_GROUP_LEVEL = 265;

	/**
	 * The constants SCoTS Table id for Industry Code Group Level
	 */
	public static final Integer CODE_TABLE_ID_INDUSTRY_CODE_DESC_LENGTH_CODE = 194;

	/**
	 * The constant for DNBUnusGlsyTypeCode for Phone Area Code
	 */
	public static final Long DNB_UBUS_GLSY_TYPE_CODE_PHONE_AREA_CODE = 24801L;

	/**
	 * The constants for the reference data service deploy URL
	 */
	public static final String REFDATA_SERVICE_DEPLOY_URL = "refdata.service.deploy.url";

	/**
	 * The constants for the reference data batch deploy URL
	 */
	public static final String REFDATA_BATCH_DEPLOY_URL = "refdata.batch.deploy.url";

	/**
	 * The constants for the reference data service deploy URL
	 */
	public static final String REFDATA_WORKFLOW_SERVICE_URL = "refdata.workflow.service.url";

	/**
	 * The constants for the industry code length code - 240 char length code
	 */
	public static final Long CODE_INDSCODE_DESC_LEN_CD_240_CHAR_DESC = 9120L;

	public static final String SUBMITTER_EMAIL_ADDRESS = "marannanm@dnb.com";

	public static final String APPROVER_EMAIL_ADDRESS = "marannanm@dnb.com";

	/**
	 * The constants for the rest of world geography approver
	 */
	public static final String REFDATA_ROW_GEO_APPROVER = "refdata.approver.geo.row";

	/**
	 * The constants for the approver pre appender
	 */
	public static final String REFDATA_APPROVER_PRE_APPENDER = "refdata.approver.";

	/**
	 * The constants for the submitter pre appender
	 */
	public static final String REFDATA_SUBMITTER_PRE_APPENDER = "refdata.submitter.";

	/**
	 * The constants for the rest of world geography submitter
	 */
	public static final String REFDATA_ROW_GEO_SUBMITTER = "refdata.submitter.geo.row";

	/**
	 * The constants for the request change type
	 */
	public static final String REFDATA_REQUEST_CHANGE_TYPE_CD = "refdata.request.changetype.";

	/**
	 * The constants SCoTS currency code - US Dollar
	 */
	public static final Long CODE_CURRENCY_USDOLLAR = 28L;

	/**
	 * The constants GEO United States
	 */
	public static final Long CODE_GEOGRAPHY_UNITED_STATES = 1073L;

	/**
	 * The constants for the submitter pre appender currency
	 */
	public static final String REFDATA_APPROVER_CURRENCY = "refdata.approver.crcy";

	public static final Long INDUSTRY_CODE_APPROVER_GROUP_ID = 214L;

	public static final Long INDUSTRY_CODE_SUBMITTER_GROUP_ID = 213L;
	
	public static final Long FINANCE_TEMPLATE_APPROVER_GROUP_ID = 218L;

	public static final Long FINANCE_TEMPLATE_SUBMITTER_GROUP_ID = 217L;
	
	public static final Long CONTROLWORDS_APPROVER_GROUP_ID = 226L;

	public static final Long CONTROLWORDS_SUBMITTER_GROUP_ID = 225L;
	
	
	/**
	 * The constant for the industry code bulk download  location
	 */
	public static final String REFDATA_INDUSTRY_BLK_DOWNLOAD_LOCATION = "refdata.bulk.download.location.industrycode";
	
	/**
	 * The constant for the industry code bulk upload validation  location
	 */
	public static final String REFDATA_INDUSTRY_BLK_UPLOAD_VAL_LOCATION = "/dnbusr2/RefData/bulkupload/industry_codes/validation_service/input/";
	
	/**
	 * The constant for the geography bulk download  location
	 */
	public static final String REFDATA_GEOGRAPHY_BLK_DOWNLOAD_LOCATION = "refdata.bulk.download.location.geography";
	
	/**
	 * The constant for the geography bulk upload validation  location
	 */
	public static final String REFDATA_GEOGRAPHY_BLK_UPLOAD_VAL_LOCATION = "/dnbusr2/RefData/bulkupload/geography/validation_service/input/";

	/**
	 * The constant for the Scots bulk download  location
	 */
	public static final String REFDATA_SCOTS_BLK_DOWNLOAD_LOCATION = "refdata.bulk.download.location.scots";
	
	/**
	 * The constant for the Scots bulk upload Validation  location
	 */
	public static final String REFDATA_SCOTS_BLK_UPLOAD_VAL_LOCATION = "/dnbusr2/RefData/bulkupload/scots/validation_service/input/";
	/**
	 * The constant for the Scots bulk download  location
	 */
	public static final String REFDATA_CTRLWRDS_BLK_DOWNLOAD_LOCATION = "refdata.bulk.download.location.ctrlwrds";
	/**
	 * The constant for the currency bulk upload location
	 */
	public static final String REFDATA_CRCY_BLK_UPLOAD_LOCATION = "refdata.bulk.upload.location.crcy";

	/**
	 * The constant for Upload Location
	 */
	public static final String REFDATA_INDUSTRY_BLK_UPLOAD_LOCATION ="refdata.bulk.upload.location.inds";
	/**
	 * The constant for Upload Location
	 */
	public static final String REFDATA_GEOGRAPHY_BLK_UPLOAD_LOCATION ="refdata.bulk.upload.location.geo";
	/**
	 * The constant for Upload Location
	 */
	public static final String REFDATA_SCOTS_BLK_UPLOAD_LOCATION = "refdata.bulk.upload.location.scots";
	/**
	 * The constant for Upload Location
	 */
	public static final String REFDATA_CTRLWRDS_BLK_UPLOAD_LOCATION = "refdata.bulk.upload.location.ctrlwrds";
	/**
	 * The constant for under score
	 */
	public static final String UNDERSOCRE ="_";

	/**
	 * The constant for the industry code bulk downlaod  file format
	 */
	public static final String REFDATA_INDUSTRY_BLK_DOWNLOAD_FILE_FORMAT = ".xlsx";
	/**
	 * The constant for status In Progress
	 */
	public static final String REFDATA_INDUSTRY_BLK_DOWNLOAD_FILE_STATUS  = "In Progress";
	
	/**
	 * The constant for the Scots bulk download  location
	 */
	public static final String REFDATA_BLK_TEMPLATE_DOWNLOAD_LOCATION = "refdata.bulk.template.download.location";


	public static final Long SCOTS_CODE_APPROVER_GROUP_ID = 212L;

	public static final Long SCOTS_CODE_SUBMITTER_GROUP_ID = 211L;

	public static final Long XML_SCHEMA_ELEMENT_SUBMITTER_GROUP_ID = 227L;

	public static final Long XML_SCHEMA_ELEMENT_APPROVER_GROUP_ID = 228L;

	/**
	 * The constant for the market applicability mode
	 */
	public static final String REFDATA_SCOTS_MODE_MARKET_APPLICABILITY  = "Market";
	/**
	 * The constant for the system applicability mode
	 */
	public static final String REFDATA_SCOTS_MODE_SYSTEM_APPLICABILITY  = "System";

	/**
	 * The constants for the D&B Data Stores - GSRL 8.0
	 */
	public static final Long CODE_DATA_STORES_GSRL = 23926L;
	/**
	 * The constants for the Inferment Type - Legal
	 */
	public static final Long CODE_INFERMENT_TYPE_LEGAL = 24760L;

	public static final Long CODE_INFERMENT_TYPE_INDUSTRYCODE = 24761L;

	public static final Long CONTROL_WORDS_APPROVER_GROUP_ID = 226L;

	public static final Long CONTROL_WORDS_SUBMITTER_GROUP_ID = 225L;
	/**
	 * The constant for the financial statement template 
	 */
	public static final Long CODE_TABLE_FINANCIAL_STATEMENT_TEMPLATES = 78L;
	
	/**
	 * The constant for the Financial Statement Type
	 */
	public static final Long CODE_TABLE_FINANCIAL_STATEMENT_TYPE = 632L;
	
	/**
	 * The constant for the Financial Statement Schedule
	 */
	public static final Long CODE_TABLE_FINANCIAL_STATEMENT_SCHEDULE = 60L;

	public static final Long CODE_TABLE_FINANCIAL_STATEMENT_LINE_ITEM = 33L;
	
	public static final Long FINANCIAL_STMT_TEMPLATE_OWNER_CODE = 3891L;
	
	/**
	 * The constant for the user email address max characters
	 *  
	 */
	public static final int USER_EMAIL_ADDRESS_MAX_LENGTH = 32;
	
	/* 
	 * Error codes
	 * 
	 */
	public static final String ERROR_CODE_SQL = "1000";
	public static final String ERROR_CODE_PERSISTENCE = "2000";
	public static final String ERROR_CODE_DATA_ACCESS = "3000";
	public static final String ERROR_CODE_NOT_FOUND = "4000";
	public static final String ERROR_CODE_MERGE = "5000";
	public static final String ERROR_CODE_WORKFLOW = "6000";
	public static final String ERROR_CODE_SYSTEM = "7000";
	public static final String ERROR_CODE_OAM_ERROR = "8000";
	public static final String ERROR_CODE_BULK_NOT_FOUND = "9000";
	
	/**
	 * The constant for refdata application deploy environment
	 */
	public static final String REFDATA_APP_DEPLOY_ENVIRONMENT = "refdata.app.deploy.env";
	
	/**
	 * The constant for Geo WorldBase Code
	 */
	public static final Long CODE_GEOGRAPHIC_CODE_TYPE_WBCODE = 23414L;
	
	/**
	 * The constant for the User Guide and FAQ  location
	 */
	public static final String REFDATA_USERGUIDE_LOCATION = "refdata.userguide.location";
	
	/**
	 * The constant for the WD to ISO Codes
	 */
	public static final String REFDATA_WDTOISOCODES_LOCATION = "refdata.wdToISOCode.location";
	
	
	/**
	 * The constant for the User Guide and FAQ  location
	 */
	public static final String REFDATA_SCOTS_LOCATION = "refdata.scots.location";
	
	
	/**
	 * The constant for the mail host
	 */
	public static final String REFDATA_MAIL_HOST = "refdata.mail.host";
	
	/**
	 * The constant for the Automation Mailbot
	 */
	public static final String REFDATA_MAIL_BOT = "refdata.mail.bot";
	
	
	/**
	 * The constant for the  Sender mail
	 */
	public static final String REFDATA_MAIL_FROM = "refdata.mail.from";
	
	
	/**
	 * The constant for the  SMTP Host
	 */
	public static final String REFDATA_MAIL_SMTP_HOST = "mail.smtp.host";
	
	/**
	 * The constant for the  SMTP PORT
	 */
	public static final String REFDATA_MAIL_SMTP_PORT = "mail.smtp.port";
	
	
	/**
	 * The constant for the  SMTP PORT Number
	 */
	public static final String REFDATA_MAIL_SMTP_PORT_NO = "25";
	
	/**
	 * The constant for the  SMTP Socket
	 */
	public static final String REFDATA_MAIL_SMTP_SOCKET = "mail.smtp.socketFactory.port";
	
	/**
	 * The constant for the  withdraw alert
	 */
	public static final String REFDATA_WITHDRAW_ALERT = "Request Will be removed within next 30 minutes";
	
	/**
	 * The constant for the  withdraw alert
	 */
	public static final String REFDATA_MAIL_SUBJECT = "ERD Request Removal";
}
