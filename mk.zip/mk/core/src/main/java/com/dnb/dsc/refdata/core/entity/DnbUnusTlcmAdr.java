package com.dnb.dsc.refdata.core.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "dnb_unus_tlcm_adr")
@NamedQueries({
	@NamedQuery(name = "DnbUnusTlcmAdr.removeDnbUnusTlcmAdrById", query = "DELETE DnbUnusTlcmAdr t where t.dnbUnusGlsyId = :dnbUnusGlsyId")
})	
public class DnbUnusTlcmAdr extends Audit {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "dnb_unus_tlcm_adr_id")
	private Long dnbUnusTlcmAdrId;
	
	@Column(name = "dnb_unus_glsy_id")
	private Long dnbUnusGlsyId;

	@Column(name = "comm_meth_cd")
	private Long commMethCd;

	@Column(name = "area_code_nbr")
	private String areaCodeNbr;

	@Column(name = "tlcm_exch_code")
	private String tlcmExchCode;

	@Column(name = "phon_extn_nbr")
	private String phonExtnNbr;

	@Column(name = "res_indc")
	private Boolean resIndc;
	
	@Column(name = "mbl_indc")
	private Boolean mblIndc;

	@Column(name = "telx_ansb_txt")
	private String telxAnsbTxt;
	
	@Transient
	private String dnbUnsGlyBulkId;
	
	@Transient
	private Integer errorCD;

	/**
	 * @return the dnbUnusTlcmAdrId
	 */
	public Long getDnbUnusTlcmAdrId() {
		return dnbUnusTlcmAdrId;
	}

	/**
	 * @param dnbUnusTlcmAdrId the dnbUnusTlcmAdrId to set
	 */
	public void setDnbUnusTlcmAdrId(Long dnbUnusTlcmAdrId) {
		this.dnbUnusTlcmAdrId = dnbUnusTlcmAdrId;
	}

	/**
	 * @return the dnbUnusGlsyId
	 */
	public Long getDnbUnusGlsyId() {
		return dnbUnusGlsyId;
	}

	/**
	 * @param dnbUnusGlsyId the dnbUnusGlsyId to set
	 */
	public void setDnbUnusGlsyId(Long dnbUnusGlsyId) {
		this.dnbUnusGlsyId = dnbUnusGlsyId;
	}

	/**
	 * @return the commMethCd
	 */
	public Long getCommMethCd() {
		return commMethCd;
	}

	/**
	 * @param commMethCd the commMethCd to set
	 */
	public void setCommMethCd(Long commMethCd) {
		this.commMethCd = commMethCd;
	}

	/**
	 * @return the areaCodeNbr
	 */
	public String getAreaCodeNbr() {
		return areaCodeNbr;
	}

	/**
	 * @param areaCodeNbr the areaCodeNbr to set
	 */
	public void setAreaCodeNbr(String areaCodeNbr) {
		this.areaCodeNbr = areaCodeNbr;
	}

	/**
	 * @return the tlcmExchCode
	 */
	public String getTlcmExchCode() {
		return tlcmExchCode;
	}

	/**
	 * @param tlcmExchCode the tlcmExchCode to set
	 */
	public void setTlcmExchCode(String tlcmExchCode) {
		this.tlcmExchCode = tlcmExchCode;
	}

	/**
	 * @return the phonExtnNbr
	 */
	public String getPhonExtnNbr() {
		return phonExtnNbr;
	}

	/**
	 * @param phonExtnNbr the phonExtnNbr to set
	 */
	public void setPhonExtnNbr(String phonExtnNbr) {
		this.phonExtnNbr = phonExtnNbr;
	}

	/**
	 * @return the resIndc
	 */
	public Boolean getResIndc() {
		return resIndc;
	}

	/**
	 * @param resIndc the resIndc to set
	 */
	public void setResIndc(Boolean resIndc) {
		this.resIndc = resIndc;
	}

	/**
	 * @return the mblIndc
	 */
	public Boolean getMblIndc() {
		return mblIndc;
	}

	/**
	 * @param mblIndc the mblIndc to set
	 */
	public void setMblIndc(Boolean mblIndc) {
		this.mblIndc = mblIndc;
	}

	/**
	 * @return the telxAnsbTxt
	 */
	public String getTelxAnsbTxt() {
		return telxAnsbTxt;
	}

	/**
	 * @param telxAnsbTxt the telxAnsbTxt to set
	 */
	public void setTelxAnsbTxt(String telxAnsbTxt) {
		this.telxAnsbTxt = telxAnsbTxt;
	}


	/**
	 * @return the dnbUnsGlyBulkId
	 */
	public String getDnbUnsGlyBulkId() {
		return dnbUnsGlyBulkId;
	}


	/**
	 * @param dnbUnsGlyBulkId the dnbUnsGlyBulkId to set
	 */
	public void setDnbUnsGlyBulkId(String dnbUnsGlyBulkId) {
		this.dnbUnsGlyBulkId = dnbUnsGlyBulkId;
	}


	/**
	 * @return the errorCD
	 */
	public Integer getErrorCD() {
		return errorCD;
	}


	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(Integer errorCD) {
		this.errorCD = errorCD;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DnbUnusTlcmAdr [dnbUnusTlcmAdrId=" + dnbUnusTlcmAdrId
				+ ", dnbUnusGlsyId=" + dnbUnusGlsyId + ", commMethCd="
				+ commMethCd + ", areaCodeNbr=" + areaCodeNbr
				+ ", tlcmExchCode=" + tlcmExchCode + ", phonExtnNbr="
				+ phonExtnNbr + ", resIndc=" + resIndc + ", mblIndc=" + mblIndc
				+ ", telxAnsbTxt=" + telxAnsbTxt + "]";
	}


}
