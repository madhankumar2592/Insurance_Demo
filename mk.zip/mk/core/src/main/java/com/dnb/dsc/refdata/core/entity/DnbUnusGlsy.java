package com.dnb.dsc.refdata.core.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

@Entity
@Table(name = "dnb_unus_glsy")
@NamedQueries({
	@NamedQuery(name = "DnbUnusGlsy.retrieveDnbUnusGlsyById", query = "SELECT d FROM DnbUnusGlsy d where d.dnbUnusGlsyId = :dnbUnusGlsyId"),
	@NamedQuery(name = "DnbUnusGlsy.retrieveDistinctDnbUnusGlsyTypCd", query = "SELECT distinct new DnbUnusGlsy(d.dnbUnusGlsyTypCd) FROM DnbUnusGlsy d"),
	@NamedQuery(name = "DnbUnusGlsy.removeDnbUnusGlsyById", query = "DELETE DnbUnusGlsy d where d.dnbUnusGlsyId = :dnbUnusGlsyId"),
	@NamedQuery(name = "DnbUnusGlsy.removeDnbUnusGlsyByIdAndText", query = "DELETE DnbUnusGlsy d where d.dnbUnusGlsyId = :dnbUnusGlsyId and d.dnbUnusTxt = :dnbUnusTxt")
	
})		
public class DnbUnusGlsy extends Audit{

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "dnb_unus_glsy_id")
	private Long dnbUnusGlsyId;

	@Column(name = "dnb_unus_glsy_typ_cd")
	private Long dnbUnusGlsyTypCd;

	@Column(name = "dnb_unus_txt")
	private String dnbUnusTxt;

	@Column(name = "alwd_wth_oth_wd_indc")
	private Boolean alwdWthOthWdIndc;

	@Column(name = "exct_mtch_indc")
	private Boolean exctMtchIndc;

	@Column(name = "expn_dt")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expnDt;

	@Column(name = "effv_dt")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effvDt;

	@Column(name = "stop_prcs_rec_indc")
	private Boolean stopPrcsRecIndc;
	
	@OneToOne(optional = true, cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name="dnb_unus_glsy_id")
	private DnbUnusIndNme dnbUnusIndNme;

	@OneToOne(optional = true, cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name="dnb_unus_glsy_id")
	private DnbUnusAdr dnbUnusAdr;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "dnbUnusGlsyId")
	private List<DnbUnusGlsyCtryAppy> countryApplicability;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "dnbUnusGlsyId")
	private List<DnbUnusTlcmAdr> telecomAddress;
	
	@OneToOne(optional = true, cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name="dnb_unus_glsy_id")
	private PhoneAreaCode phoneAreaCode;
	
	@Transient
	private String officialGeoName;
	
	@Transient
	private String status;

        @Transient
	private String dnbUnsGlyBulkId;
	
	@Transient
	private List<String> countryApplicabilityCheckboxValues;
	
	@Transient
	private String areaCodeNumber;
	
	@Transient
	private String areaCodeServiceDescription;
	
	@Transient
	private Long territoryGeoUnitId;
	
	@Transient
	private Long countryGeoUnitId;
		
	@Transient
	private String countryGeoUnitOfficialName;
	
	@Transient
	private String territoryGeoUnitOfficialName;
	
	@Transient
	private String ln1Adr;

	@Transient
	private String ln2Adr;
	
	@Transient
	private String strNme;
	
	@Transient
	private String primTownNme;
	
	@Transient
	private String cntyNme;

	@Transient
	private String terrNme;
	
	@Transient
	private String postCode;
	
	@Transient
	private String areaCodeNbr;
	
	@Transient
	private String tlcmExchCode;
	
	@Transient
	private String phonExtnNbr;
	
	@Transient
	private String nmeSfxTxt;

	@Transient
	private String frnm;

	@Transient
	private String srnme;

	@Transient
	private String midlNme;
	
	public DnbUnusGlsy(){
		
	}
	
	public DnbUnusGlsy(Long dnbUnusGlsyId, Long dnbUnusGlsyTypCd, 
			String dnbUnusTxt, Boolean alwdWthOthWdIndc, Boolean exctMtchIndc, 
			Date expnDt, Date effvDt, Boolean stopPrcsRecIndc, String geoName) {
		this.dnbUnusGlsyId = dnbUnusGlsyId;
		this.dnbUnusGlsyTypCd = dnbUnusGlsyTypCd;
		this.dnbUnusTxt = dnbUnusTxt;
		this.alwdWthOthWdIndc = alwdWthOthWdIndc;
		this.exctMtchIndc = exctMtchIndc;
		this.expnDt = expnDt;
		this.effvDt = effvDt;
		this.stopPrcsRecIndc = stopPrcsRecIndc;
		this.officialGeoName = geoName;
	}
	
	public DnbUnusGlsy(Long dnbUnusGlsyId, Long dnbUnusGlsyTypCd, 
			String dnbUnusTxt, Boolean alwdWthOthWdIndc, Boolean exctMtchIndc, 
			Date expnDt, Date effvDt, Boolean stopPrcsRecIndc, String geoName,
			String frnm, String midlNme, String srnme, String nmeSfxTxt) {
		this.dnbUnusGlsyId = dnbUnusGlsyId;
		this.dnbUnusGlsyTypCd = dnbUnusGlsyTypCd;
		this.dnbUnusTxt = dnbUnusTxt;
		this.alwdWthOthWdIndc = alwdWthOthWdIndc;
		this.exctMtchIndc = exctMtchIndc;
		this.expnDt = expnDt;
		this.effvDt = effvDt;
		this.stopPrcsRecIndc = stopPrcsRecIndc;
		this.officialGeoName = geoName;
		this.frnm = frnm;
		this.midlNme = midlNme;
		this.srnme = srnme;
		this.nmeSfxTxt = nmeSfxTxt;
	}
	
	public DnbUnusGlsy(Long dnbUnusGlsyId, Long dnbUnusGlsyTypCd, 
			String dnbUnusTxt, Boolean alwdWthOthWdIndc, Boolean exctMtchIndc, 
			Date expnDt, Date effvDt, Boolean stopPrcsRecIndc, String geoName,
			String ln1Adr, String ln2Adr, String strNme, String primTownNme,
			String cntyNme, String terrNme, String postCode ) {
		this.dnbUnusGlsyId = dnbUnusGlsyId;
		this.dnbUnusGlsyTypCd = dnbUnusGlsyTypCd;
		this.dnbUnusTxt = dnbUnusTxt;
		this.alwdWthOthWdIndc = alwdWthOthWdIndc;
		this.exctMtchIndc = exctMtchIndc;
		this.expnDt = expnDt;
		this.effvDt = effvDt;
		this.stopPrcsRecIndc = stopPrcsRecIndc;
		this.officialGeoName = geoName;
		this.ln1Adr = ln1Adr;
		this.ln2Adr = ln2Adr;
		this.strNme = strNme;
		this.primTownNme = primTownNme;
		this.cntyNme = cntyNme;
		this.terrNme = terrNme;
		this.postCode = postCode;
	}
	
	public DnbUnusGlsy(Long dnbUnusGlsyId, Long dnbUnusGlsyTypCd, 
			String dnbUnusTxt, Boolean alwdWthOthWdIndc, Boolean exctMtchIndc, 
			Date expnDt, Date effvDt, Boolean stopPrcsRecIndc, String geoName,
			String areaCodeNbr, String tlcmExchCode, String phonExtnNbr) {
		this.dnbUnusGlsyId = dnbUnusGlsyId;
		this.dnbUnusGlsyTypCd = dnbUnusGlsyTypCd;
		this.dnbUnusTxt = dnbUnusTxt;
		this.alwdWthOthWdIndc = alwdWthOthWdIndc;
		this.exctMtchIndc = exctMtchIndc;
		this.expnDt = expnDt;
		this.effvDt = effvDt;
		this.stopPrcsRecIndc = stopPrcsRecIndc;
		this.officialGeoName = geoName;
		this.areaCodeNbr = areaCodeNbr;
		this.tlcmExchCode = tlcmExchCode;
		this.phonExtnNbr = phonExtnNbr;
	}
	
	public DnbUnusGlsy(Long dnbUnusGlsyId, Long dnbUnusGlsyTypCd, 
			String dnbUnusTxt, Boolean alwdWthOthWdIndc, Boolean exctMtchIndc, 
			Date expnDt, Date effvDt, Boolean stopPrcsRecIndc, String geoName,
			String areaCodeNumber, String areaCodeServiceDescription ,
			Long countryGeoUnitId, Long territoryGeoUnitId) {
		this.dnbUnusGlsyId = dnbUnusGlsyId;
		this.dnbUnusGlsyTypCd = dnbUnusGlsyTypCd;
		this.dnbUnusTxt = dnbUnusTxt;
		this.alwdWthOthWdIndc = alwdWthOthWdIndc;
		this.exctMtchIndc = exctMtchIndc;
		this.expnDt = expnDt;
		this.effvDt = effvDt;
		this.stopPrcsRecIndc = stopPrcsRecIndc;
		this.officialGeoName = geoName;
		if(this.phoneAreaCode == null){
			this.phoneAreaCode = new PhoneAreaCode();
		}
		this.phoneAreaCode.setAreaCodeNumber(areaCodeNumber);
		this.phoneAreaCode.setAreaCodeServiceDescription(areaCodeServiceDescription);
		this.phoneAreaCode.setCountryGeoUnitId(countryGeoUnitId);
		this.phoneAreaCode.setTerritoryGeoUnitId(territoryGeoUnitId);
	}
	
		
	/**
	 * @param dnbUnusGlsyId
	 * @param dnbUnusGlsyTypCd
	 * @param dnbUnusTxt
	 * @param alwdWthOthWdIndc
	 * @param exctMtchIndc
	 * @param expnDt
	 * @param effvDt
	 * @param stopPrcsRecIndc
	 * @param officialGeoName
	 * @param status
	 * @param areaCodeNumber
	 * @param areaCodeServiceDescription
	 * @param territoryGeoUnitId
	 * @param countryGeoUnitId
	 * @param countryGeoUnitOfficialName
	 * @param territoryGeoUnitOfficialName
	 */
	public DnbUnusGlsy(Long dnbUnusGlsyId, Long dnbUnusGlsyTypCd, 
			String dnbUnusTxt, Boolean alwdWthOthWdIndc, Boolean exctMtchIndc,
			Date expnDt, Date effvDt, Boolean stopPrcsRecIndc,String officialGeoName,  
			String areaCodeNumber, String areaCodeServiceDescription ,
			Long countryGeoUnitId, String countryGeoUnitOfficialName,
			Long territoryGeoUnitId, String territoryGeoUnitOfficialName) {
		super();
		this.dnbUnusGlsyId = dnbUnusGlsyId;
		this.dnbUnusGlsyTypCd = dnbUnusGlsyTypCd;
		this.dnbUnusTxt = dnbUnusTxt;
		this.alwdWthOthWdIndc = alwdWthOthWdIndc;
		this.exctMtchIndc = exctMtchIndc;
		this.expnDt = expnDt;
		this.effvDt = effvDt;
		this.stopPrcsRecIndc = stopPrcsRecIndc;
		this.officialGeoName = officialGeoName;
		this.areaCodeNumber = areaCodeNumber;
		this.areaCodeServiceDescription = areaCodeServiceDescription;
		this.territoryGeoUnitId = territoryGeoUnitId;
		this.countryGeoUnitId = countryGeoUnitId;
		this.countryGeoUnitOfficialName = countryGeoUnitOfficialName;
		this.territoryGeoUnitOfficialName = territoryGeoUnitOfficialName;
	}
	
	public DnbUnusGlsy(Long dnbUnusGlsyTypCd){
		this.dnbUnusGlsyTypCd = dnbUnusGlsyTypCd;
	}


	/**
	 * @return the dnbUnusGlsyId
	 */
	public Long getDnbUnusGlsyId() {
		return dnbUnusGlsyId;
	}

	/**
	 * @param dnbUnusGlsyId the dnbUnusGlsyId to set
	 */
	public void setDnbUnusGlsyId(Long dnbUnusGlsyId) {
		this.dnbUnusGlsyId = dnbUnusGlsyId;
	}

	/**
	 * @return the dnbUnusGlsyTypCd
	 */
	public Long getDnbUnusGlsyTypCd() {
		return dnbUnusGlsyTypCd;
	}

	/**
	 * @param dnbUnusGlsyTypCd the dnbUnusGlsyTypCd to set
	 */
	public void setDnbUnusGlsyTypCd(Long dnbUnusGlsyTypCd) {
		this.dnbUnusGlsyTypCd = dnbUnusGlsyTypCd;
	}

	/**
	 * @return the dnbUnusTxt
	 */
	public String getDnbUnusTxt() {
		return dnbUnusTxt;
	}

	/**
	 * @param dnbUnusTxt the dnbUnusTxt to set
	 */
	public void setDnbUnusTxt(String dnbUnusTxt) {
		this.dnbUnusTxt = dnbUnusTxt;
	}

	/**
	 * @return the alwdWthOthWdIndc
	 */
	public Boolean getAlwdWthOthWdIndc() {
		return alwdWthOthWdIndc;
	}

	/**
	 * @param alwdWthOthWdIndc the alwdWthOthWdIndc to set
	 */
	public void setAlwdWthOthWdIndc(Boolean alwdWthOthWdIndc) {
		this.alwdWthOthWdIndc = alwdWthOthWdIndc;
	}

	/**
	 * @return the exctMtchIndc
	 */
	public Boolean getExctMtchIndc() {
		return exctMtchIndc;
	}

	/**
	 * @param exctMtchIndc the exctMtchIndc to set
	 */
	public void setExctMtchIndc(Boolean exctMtchIndc) {
		this.exctMtchIndc = exctMtchIndc;
	}

	/**
	 * @return the expnDt
	 */
	public Date getExpnDt() {
		return expnDt;
	}

	/**
	 * @param expnDt the expnDt to set
	 */
	public void setExpnDt(Date expnDt) {
		this.expnDt = expnDt;
	}

	/**
	 * @return the effvDt
	 */
	public Date getEffvDt() {
		return effvDt;
	}

	/**
	 * @param effvDt the effvDt to set
	 */
	public void setEffvDt(Date effvDt) {
		this.effvDt = effvDt;
	}

	/**
	 * @return the stopPrcsRecIndc
	 */
	public Boolean getStopPrcsRecIndc() {
		return stopPrcsRecIndc;
	}

	/**
	 * @param stopPrcsRecIndc the stopPrcsRecIndc to set
	 */
	public void setStopPrcsRecIndc(Boolean stopPrcsRecIndc) {
		this.stopPrcsRecIndc = stopPrcsRecIndc;
	}
	
	/**
	 * @return the dnbUnusIndNme
	 */
	public DnbUnusIndNme getDnbUnusIndNme() {
		return dnbUnusIndNme;
	}

	/**
	 * @param dnbUnusIndNme the dnbUnusIndNme to set
	 */
	public void setDnbUnusIndNme(DnbUnusIndNme dnbUnusIndNme) {
		this.dnbUnusIndNme = dnbUnusIndNme;
	}

	/**
	 * @return the dnbUnusAdr
	 */
	public DnbUnusAdr getDnbUnusAdr() {
		return dnbUnusAdr;
	}

	/**
	 * @param dnbUnusAdr the dnbUnusAdr to set
	 */
	public void setDnbUnusAdr(DnbUnusAdr dnbUnusAdr) {
		this.dnbUnusAdr = dnbUnusAdr;
	}

	/**
	 * @return the officialGeoName
	 */
	public String getOfficialGeoName() {
		return officialGeoName;
	}

	/**
	 * @param officialGeoName the officialGeoName to set
	 */
	public void setOfficialGeoName(String officialGeoName) {
		this.officialGeoName = officialGeoName;
	}

	/**
	 * @return the countryApplicability
	 */
	public List<DnbUnusGlsyCtryAppy> getCountryApplicability() {
		return countryApplicability;
	}

	/**
	 * @param countryApplicability the countryApplicability to set
	 */
	public void setCountryApplicability(
			List<DnbUnusGlsyCtryAppy> countryApplicability) {
		this.countryApplicability = countryApplicability;
	}

	/**
	 * @return the countryApplicabilityCheckboxValues
	 */
	public List<String> getCountryApplicabilityCheckboxValues() {
		return countryApplicabilityCheckboxValues;
	}

	/**
	 * @param countryApplicabilityCheckboxValues the countryApplicabilityCheckboxValues to set
	 */
	public void setCountryApplicabilityCheckboxValues(
			List<String> countryApplicabilityCheckboxValues) {
		this.countryApplicabilityCheckboxValues = countryApplicabilityCheckboxValues;
	}

	/**
	 * @return the telecomAddress
	 */
	public List<DnbUnusTlcmAdr> getTelecomAddress() {
		return telecomAddress;
	}

	/**
	 * @param telecomAddress the telecomAddress to set
	 */
	public void setTelecomAddress(List<DnbUnusTlcmAdr> telecomAddress) {
		this.telecomAddress = telecomAddress;
	}

	/**
	 * @return the phoneAreaCode
	 */
	public PhoneAreaCode getPhoneAreaCode() {
		return phoneAreaCode;
	}

	/**
	 * @param phoneAreaCode the phoneAreaCode to set
	 */
	public void setPhoneAreaCode(PhoneAreaCode phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the areaCodeNumber
	 */
	public String getAreaCodeNumber() {
		return areaCodeNumber;
	}

	/**
	 * @param areaCodeNumber the areaCodeNumber to set
	 */
	public void setAreaCodeNumber(String areaCodeNumber) {
		this.areaCodeNumber = areaCodeNumber;
	}

	/**
	 * @return the dnbUnsGlyBulkId
	 */
	public String getDnbUnsGlyBulkId() {
		return dnbUnsGlyBulkId;
	}

	/**
	 * @param dnbUnsGlyBulkId the dnbUnsGlyBulkId to set
	 */
	public void setDnbUnsGlyBulkId(String dnbUnsGlyBulkId) {
		this.dnbUnsGlyBulkId = dnbUnsGlyBulkId;
	}

	/**
	 * @return the areaCodeServiceDescription
	 */
	public String getAreaCodeServiceDescription() {
		return areaCodeServiceDescription;
	}

	/**
	 * @param areaCodeServiceDescription the areaCodeServiceDescription to set
	 */
	public void setAreaCodeServiceDescription(String areaCodeServiceDescription) {
		this.areaCodeServiceDescription = areaCodeServiceDescription;
	}

	/**
	 * @return the territoryGeoUnitId
	 */
	public Long getTerritoryGeoUnitId() {
		return territoryGeoUnitId;
	}

	/**
	 * @param territoryGeoUnitId the territoryGeoUnitId to set
	 */
	public void setTerritoryGeoUnitId(Long territoryGeoUnitId) {
		this.territoryGeoUnitId = territoryGeoUnitId;
	}

	/**
	 * @return the countryGeoUnitId
	 */
	public Long getCountryGeoUnitId() {
		return countryGeoUnitId;
	}

	/**
	 * @param countryGeoUnitId the countryGeoUnitId to set
	 */
	public void setCountryGeoUnitId(Long countryGeoUnitId) {
		this.countryGeoUnitId = countryGeoUnitId;
	}

	/**
	 * @return the countryGeoUnitOfficialName
	 */
	public String getCountryGeoUnitOfficialName() {
		return countryGeoUnitOfficialName;
	}

	/**
	 * @param countryGeoUnitOfficialName the countryGeoUnitOfficialName to set
	 */
	public void setCountryGeoUnitOfficialName(String countryGeoUnitOfficialName) {
		this.countryGeoUnitOfficialName = countryGeoUnitOfficialName;
	}

	/**
	 * @return the territoryGeoUnitOfficialName
	 */
	public String getTerritoryGeoUnitOfficialName() {
		return territoryGeoUnitOfficialName;
	}

	/**
	 * @param territoryGeoUnitOfficialName the territoryGeoUnitOfficialName to set
	 */
	public void setTerritoryGeoUnitOfficialName(String territoryGeoUnitOfficialName) {
		this.territoryGeoUnitOfficialName = territoryGeoUnitOfficialName;
	}
	
	/**
	 * @return the ln1Adr
	 */
	public String getLn1Adr() {
		return ln1Adr;
	}

	/**
	 * @param ln1Adr the ln1Adr to set
	 */
	public void setLn1Adr(String ln1Adr) {
		this.ln1Adr = ln1Adr;
	}

	/**
	 * @return the ln2Adr
	 */
	public String getLn2Adr() {
		return ln2Adr;
	}

	/**
	 * @param ln2Adr the ln2Adr to set
	 */
	public void setLn2Adr(String ln2Adr) {
		this.ln2Adr = ln2Adr;
	}

	/**
	 * @return the strNme
	 */
	public String getStrNme() {
		return strNme;
	}

	/**
	 * @param strNme the strNme to set
	 */
	public void setStrNme(String strNme) {
		this.strNme = strNme;
	}

	/**
	 * @return the primTownNme
	 */
	public String getPrimTownNme() {
		return primTownNme;
	}

	/**
	 * @param primTownNme the primTownNme to set
	 */
	public void setPrimTownNme(String primTownNme) {
		this.primTownNme = primTownNme;
	}

	/**
	 * @return the cntyNme
	 */
	public String getCntyNme() {
		return cntyNme;
	}

	/**
	 * @param cntyNme the cntyNme to set
	 */
	public void setCntyNme(String cntyNme) {
		this.cntyNme = cntyNme;
	}

	/**
	 * @return the terrNme
	 */
	public String getTerrNme() {
		return terrNme;
	}

	/**
	 * @param terrNme the terrNme to set
	 */
	public void setTerrNme(String terrNme) {
		this.terrNme = terrNme;
	}

	/**
	 * @return the postCode
	 */
	public String getPostCode() {
		return postCode;
	}

	/**
	 * @param postCode the postCode to set
	 */
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	/**
	 * @return the areaCodeNbr
	 */
	public String getAreaCodeNbr() {
		return areaCodeNbr;
	}

	/**
	 * @param areaCodeNbr the areaCodeNbr to set
	 */
	public void setAreaCodeNbr(String areaCodeNbr) {
		this.areaCodeNbr = areaCodeNbr;
	}

	/**
	 * @return the tlcmExchCode
	 */
	public String getTlcmExchCode() {
		return tlcmExchCode;
	}

	/**
	 * @param tlcmExchCode the tlcmExchCode to set
	 */
	public void setTlcmExchCode(String tlcmExchCode) {
		this.tlcmExchCode = tlcmExchCode;
	}

	/**
	 * @return the phonExtnNbr
	 */
	public String getPhonExtnNbr() {
		return phonExtnNbr;
	}

	/**
	 * @param phonExtnNbr the phonExtnNbr to set
	 */
	public void setPhonExtnNbr(String phonExtnNbr) {
		this.phonExtnNbr = phonExtnNbr;
	}

	/**
	 * @return the nmeSfxTxt
	 */
	public String getNmeSfxTxt() {
		return nmeSfxTxt;
	}

	/**
	 * @param nmeSfxTxt the nmeSfxTxt to set
	 */
	public void setNmeSfxTxt(String nmeSfxTxt) {
		this.nmeSfxTxt = nmeSfxTxt;
	}

	/**
	 * @return the frnm
	 */
	public String getFrnm() {
		return frnm;
	}

	/**
	 * @param frnm the frnm to set
	 */
	public void setFrnm(String frnm) {
		this.frnm = frnm;
	}

	/**
	 * @return the srnme
	 */
	public String getSrnme() {
		return srnme;
	}

	/**
	 * @param srnme the srnme to set
	 */
	public void setSrnme(String srnme) {
		this.srnme = srnme;
	}

	/**
	 * @return the midlNme
	 */
	public String getMidlNme() {
		return midlNme;
	}

	/**
	 * @param midlNme the midlNme to set
	 */
	public void setMidlNme(String midlNme) {
		this.midlNme = midlNme;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DnbUnusGlsy [dnbUnusGlsyId=" + dnbUnusGlsyId
				+ ", dnbUnusGlsyTypCd=" + dnbUnusGlsyTypCd + ", dnbUnusTxt="
				+ dnbUnusTxt + ", alwdWthOthWdIndc=" + alwdWthOthWdIndc
				+ ", exctMtchIndc=" + exctMtchIndc + ", expnDt=" + expnDt
				+ ", effvDt=" + effvDt + ", stopPrcsRecIndc=" + stopPrcsRecIndc
				+ ", dnbUnusIndNme=" + dnbUnusIndNme + ", dnbUnusAdr="
				+ dnbUnusAdr + ", countryApplicability=" + countryApplicability
				+ ", telecomAddress=" + telecomAddress + ", phoneAreaCode="
				+ phoneAreaCode + ", officialGeoName=" + officialGeoName
				+ ", countryApplicabilityCheckboxValues="
				+ countryApplicabilityCheckboxValues + "]";
	}
}
