/**
 * 
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the Geo Currency. The class will
 * have a direct mapping toe DB table geo_crcy.
 * 
 * @author Cognizant
 *
 * 
 */
@Entity
@Table(name = "GEO_CRCY")
@NamedQueries({
	@NamedQuery(name = "GeoCurrency.retrieveGeoCurrencyByGeoCurrencyId", query = "SELECT geoCrcy FROM GeoCurrency geoCrcy where geoCrcy.geoCurrencyId = :geoCurrencyId")})
public class GeoCurrency extends Audit implements Serializable  {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "GEO_CRCY_ID")
	private Long geoCurrencyId;

	@Column(name = "GEO_UNIT_ID")
	private Long geoUnitId;

	@Column(name = "CRCY_CD")
	private Long currencyCode;



	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "END_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private  Date endDate;

	@Transient
	private String currencyCodeDescription;

	@Transient
	private String countryName;


	public GeoCurrency(){

	}

	public GeoCurrency(Long geoCurrencyId,Long geoUnitId,String countryName,Long currencyCode,
			String currencyCodeDescription,Date effectiveDate,Date endDate){
		this.geoCurrencyId = geoCurrencyId;
		this.geoUnitId = geoUnitId;
		this.countryName = countryName;
		this.currencyCode = currencyCode;
		this.currencyCodeDescription = currencyCodeDescription;
		this.effectiveDate = effectiveDate;
		this.endDate = endDate;
	}

	public GeoCurrency(Long geoCurrencyId,Long geoUnitId,Long currencyCode,
			Date effectiveDate,Date endDate){
		this.geoCurrencyId = geoCurrencyId;
		this.geoUnitId = geoUnitId;		
		this.currencyCode = currencyCode;		
		this.effectiveDate = effectiveDate;
		this.endDate = endDate;
	}

	/**
	 * @return the geoCurrencyId
	 */
	public Long getGeoCurrencyId() {
		return geoCurrencyId;
	}

	/**
	 * @param geoCurrencyId the geoCurrencyId to set
	 */
	public void setGeoCurrencyId(Long geoCurrencyId) {
		this.geoCurrencyId = geoCurrencyId;
	}

	/**
	 * @return the geoUnitId
	 */
	public Long getGeoUnitId() {
		return geoUnitId;
	}

	/**
	 * @param geoUnitId the geoUnitId to set
	 */
	public void setGeoUnitId(Long geoUnitId) {
		this.geoUnitId = geoUnitId;
	}

	/**
	 * @return the currencyCode
	 */
	public Long getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(Long currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {// NOPMD
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the endDate
	 */
	public Date getEndDate() {// NOPMD
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the currencyCodeDescription
	 */
	public String getCurrencyCodeDescription() {
		return currencyCodeDescription;
	}

	/**
	 * @param currencyCodeDescription the currencyCodeDescription to set
	 */
	public void setCurrencyCodeDescription(String currencyCodeDescription) {
		this.currencyCodeDescription = currencyCodeDescription;
	}

	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}

	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	@Override
	public String toString() {
		return "GeoCurrency [geoCurrencyId=" + geoCurrencyId + ", geoUnitId=" + geoUnitId + ", currencyCode="
				+ currencyCode + ", effectiveDate=" + effectiveDate + ", endDate=" + endDate
				+ ", currencyCodeDescription=" + currencyCodeDescription + ", countryName=" + countryName + "]";
	}
}
