package com.dnb.dsc.refdata.core.vo;

public class GranularityMapDetails {
	private Long prnt_scr_id;
	private Long scr_map_id;
	private String scr_attr_val;
	public Long getPrnt_scr_id() {
		return prnt_scr_id;
	}
	public void setPrnt_scr_id(Long prnt_scr_id) {
		this.prnt_scr_id = prnt_scr_id;
	}
	public Long getScr_map_id() {
		return scr_map_id;
	}
	public void setScr_map_id(Long scr_map_id) {
		this.scr_map_id = scr_map_id;
	}
	public String getScr_attr_val() {
		return scr_attr_val;
	}
	public void setScr_attr_val(String scr_attr_val) {
		this.scr_attr_val = scr_attr_val;
	}

	
}
