/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.InfermentText;
/**
 * This class used as a value object class.
 * 
 * @author Cognizant
 * @version last updated : May 30, 2012
 * @see
 *
 */
@Component
public class ControlWordsSearchVO extends PaginationVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<DnbUnusGlsy> controlWords;
	
	private Long countControlWords;
	
	private Long controlWordsTypeCode;
	
	private String searchText;
	
	private Long countryGeoUnitId;
	
	private Boolean isActive;
	
	private Boolean isInactive;
	
	private static Map<Long, List<String>> columnHeaderMap;
	
	private List<List<CodeValueVO>> searchResults;
	
	/* Area Code Numbers Criteria fields $start$ */
	private Long territoryGeoUnitId;
	
	/* Area Code Numbers Criteria fields $ends$ */
	
	static{
		columnHeaderMap = new HashMap<Long, List<String>>();
		columnHeaderMap.put(24799L, Arrays.asList("Country", "Industry Code Inferment Noise Word",
				"Stop Processing Indicator",
				"Active/Inactive"));
		columnHeaderMap.put(24801L, Arrays.asList("Country", 
				"Area Code Number", "Area Code Service Description", "County", 
				"Territory", "Stop Processing Indicator", "Active/Inactive"));
		columnHeaderMap.put(24802L, Arrays.asList("Country", "Address","Line1 Address",
				"Line2 Address", "Street Name", "City", "County Name",
				"Territory Name", "Postal Code", "Active/Inactive"));
		columnHeaderMap.put(24803L, Arrays.asList("Country", "Organization Name",
				"Exact Match Indicator", "Stop Processing Indicator", "Active/Inactive"));
		columnHeaderMap.put(24804L, Arrays.asList("Country", "Offensive Word",
				"Allowed With Other Words Indicator", "Stop Processing Indicator",
				"Active/Inactive"));
		columnHeaderMap.put(24806L, Arrays.asList("Country", "Telephone Number",
				"Area Code Number", "Telephone Exchange Code", "Telephone Extension Number", 
				"Active/Inactive"));
		columnHeaderMap.put(24808L, Arrays.asList("Country", "Full Name", "Fore Name",
				"Middle Name", "Sur Name", "Name Suffix Text", "Stop Processing Indicator",
				"Active/Inactive"));
		
	}
	private String infermentText;
	private String geoName;
	private Long legalFormCode;
	private Long legalFormClassCode;
	private Long languageCode;
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;
	
	private List<InfermentText> searchLegalFormSearchResults;
	private String industryCodeType;
	private String industryCodeTypeDescription;
	private String industryCode;
	private String insdustryCodeDescription;
	

	/**
	 * 
	 * @param infermentText
	 * @param countryGeoUnitId
	 * @param legalFormCode
	 * @param legalFormClassCode
	 * @param languageCode
	 */
	public ControlWordsSearchVO(String infermentText,
			Long countryGeoUnitId, Long legalFormCode,
			Long legalFormClassCode, Long languageCode) {
		super();
		this.infermentText = infermentText;
		this.countryGeoUnitId = countryGeoUnitId;
		this.legalFormCode = legalFormCode;
		this.legalFormClassCode = legalFormClassCode;
		this.languageCode = languageCode;
	}

	/**
	 * @return the infermentText
	 */
	public String getInfermentText() {
		return infermentText;
	}

	/**
	 * @param infermentText the infermentText to set
	 */
	public void setInfermentText(String infermentText) {
		this.infermentText = infermentText;
	}

	/**
	 * @return the legalFormCode
	 */
	public Long getLegalFormCode() {
		return legalFormCode;
	}

	/**
	 * @param legalFormCode the legalFormCode to set
	 */
	public void setLegalFormCode(Long legalFormCode) {
		this.legalFormCode = legalFormCode;
	}

	/**
	 * @return the geoName
	 */
	public String getGeoName() {
		return geoName;
	}

	/**
	 * @param geoName the geoName to set
	 */
	public void setGeoName(String geoName) {
		this.geoName = geoName;
	}

	/**
	 * @return the searchLegalFormSearchResults
	 */
	public List<InfermentText> getSearchLegalFormSearchResults() {
		return searchLegalFormSearchResults;
	}

	/**
	 * @param searchLegalFormSearchResults the searchLegalFormSearchResults to set
	 */
	public void setSearchLegalFormSearchResults(
			List<InfermentText> searchLegalFormSearchResults) {
		this.searchLegalFormSearchResults = searchLegalFormSearchResults;
	}

	/**
	 * @return the legalFormClassCode
	 */
	public Long getLegalFormClassCode() {
		return legalFormClassCode;
	}

	/**
	 * @param legalFormClassCode the legalFormClassCode to set
	 */
	public void setLegalFormClassCode(Long legalFormClassCode) {
		this.legalFormClassCode = legalFormClassCode;
	}

	/**
	 * @return the languageCode
	 */
	public Long getLanguageCode() {
		return languageCode;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @param languageCode the languageCode to set
	 */
	public void setLanguageCode(Long languageCode) {
		this.languageCode = languageCode;
	}

	/**
	 * 
	 */
	public ControlWordsSearchVO(){
		
	}
	
	/**
	 * @return the controlWordsTypeCode
	 */
	public Long getControlWordsTypeCode() {
		return controlWordsTypeCode;
	}
	/**
	 * @param controlWordsTypeCode the controlWordsTypeCode to set
	 */
	public void setControlWordsTypeCode(Long controlWordsTypeCode) {
		this.controlWordsTypeCode = controlWordsTypeCode;
	}
	/**
	 * @return the searchText
	 */
	public String getSearchText() {
		return searchText;
	}
	/**
	 * @param searchText the searchText to set
	 */
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}
	/**
	 * @return the countryGeoUnitId
	 */
	public Long getCountryGeoUnitId() {
		return countryGeoUnitId;
	}
	/**
	 * @param countryGeoUnitId the countryGeoUnitId to set
	 */
	public void setCountryGeoUnitId(Long countryGeoUnitId) {
		this.countryGeoUnitId = countryGeoUnitId;
	}
	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}
	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	/**
	 * @return the isInactive
	 */
	public Boolean getIsInactive() {
		return isInactive;
	}
	/**
	 * @param isInactive the isInactive to set
	 */
	public void setIsInactive(Boolean isInactive) {
		this.isInactive = isInactive;
	}
	/**
	 * @return the columnHeaderMap
	 */
	public Map<Long, List<String>> getColumnHeaderMap() {
		return columnHeaderMap;
	}

	/**
	 * @return the searchResults
	 */
	public List<List<CodeValueVO>> getSearchResults() {
		return searchResults;
	}

	/**
	 * @param searchResults the searchResults to set
	 */
	public void setSearchResults(List<List<CodeValueVO>> searchResults) {
		this.searchResults = searchResults;
	}

	/**
	 * @return the territoryGeoUnitId
	 */
	public Long getTerritoryGeoUnitId() {
		return territoryGeoUnitId;
	}

	/**
	 * @param territoryGeoUnitId the territoryGeoUnitId to set
	 */
	public void setTerritoryGeoUnitId(Long territoryGeoUnitId) {
		this.territoryGeoUnitId = territoryGeoUnitId;
	}
    /**
     * @return the industryCodeType
     */
    public String getIndustryCodeType() {
        return industryCodeType;
    }

    /**
     * @param industryCodeType the industryCodeType to set
     */
    public void setIndustryCodeType(String industryCodeType) {
        this.industryCodeType = industryCodeType;
    }

    /**
     * @return the insdustryCodeDescription
     */
    public String getInsdustryCodeDescription() {
        return insdustryCodeDescription;
    }

    /**
     * @param insdustryCodeDescription the insdustryCodeDescription to set
     */
    public void setInsdustryCodeDescription(String insdustryCodeDescription) {
        this.insdustryCodeDescription = insdustryCodeDescription;
    }
    
    

    /**
     * @return the industryCodeTypeDescription
     */
    public String getIndustryCodeTypeDescription() {
        return industryCodeTypeDescription;
    }

    /**
     * @param industryCodeTypeDescription the industryCodeTypeDescription to set
     */
    public void setIndustryCodeTypeDescription(String industryCodeTypeDescription) {
        this.industryCodeTypeDescription = industryCodeTypeDescription;
    }

    /**
     * @return the industryCode
     */
    public String getIndustryCode() {
        return industryCode;
    }

    /**
     * @param industryCode the industryCode to set
     */
    public void setIndustryCode(String industryCode) {
        this.industryCode = industryCode;
    }


	/**
	 * @return the controlWords
	 */
	public List<DnbUnusGlsy> getControlWords() {
		return controlWords;
	}

	/**
	 * @param controlWords the controlWords to set
	 */
	public void setControlWords(List<DnbUnusGlsy> controlWords) {
		this.controlWords = controlWords;
	}

	/**
	 * @return the countControlWords
	 */
	public Long getCountControlWords() {
		return countControlWords;
	}

	/**
	 * @param countControlWords the countControlWords to set
	 */
	public void setCountControlWords(Long countControlWords) {
		this.countControlWords = countControlWords;
	}

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
		return "ControlWordsSearchVO [controlWord=" + controlWords
				+ ", controlWordsTypeCode=" + controlWordsTypeCode
				+ ", searchText=" + searchText + ", countryGeoUnitId="
				+ countryGeoUnitId + ", isActive=" + isActive + ", isInactive="
				+ isInactive + ", searchResults=" + searchResults
				+ ", territoryGeoUnitId=" + territoryGeoUnitId
				+ ", infermentText=" + infermentText + ", geoName=" + geoName
				+ ", legalFormCode=" + legalFormCode + ", legalFormClassCode="
				+ legalFormClassCode + ", languageCode=" + languageCode
				+ ", expirationDate=" + expirationDate
				+ ", searchLegalFormSearchResults="
				+ searchLegalFormSearchResults + ", industryCodeType="
				+ industryCodeType + ", industryCodeTypeDescription="
				+ industryCodeTypeDescription + ", industryCode="
				+ industryCode + ", insdustryCodeDescription="
                + insdustryCodeDescription + "]";
    }

}
