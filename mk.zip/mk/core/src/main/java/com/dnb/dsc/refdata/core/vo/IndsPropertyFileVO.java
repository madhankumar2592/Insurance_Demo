package com.dnb.dsc.refdata.core.vo;

public class IndsPropertyFileVO {
	
	private String validateWithIdQuery;
	private String validateWithoutIdQuery;
	private String validatePrfdMapQuery;
	private String insertQuery;
	private String selectQuery;
	private String outputFilePath;
	private String errorFilePath;
	private String loadOutputFilePath;
	private String loadErrorFilePath;
	private String cdValQuery;
	private String validateIdQuery;
	private String validateDescIdQuery;
	private String indsCodeIdSeqQuery;
	private String indsCodeInsertQuery;
	private String indsCodeDescInsertQuery;
	private String indsMapDeleteQuery;
	private String indsUniqueQuery;
	private String indsDescUpdateQuery;

	public IndsPropertyFileVO(String validateWithIdQuery, String validateWithoutIdQuery,
			String validatePrfdMapQuery,String insertQuery,String selectQuery,String outputFilePath, String errorFilePath,
			String loadOutputFilePath,String loadErrorFilePath, String cdValQuery,
			String validateIdQuery,String validateDescIdQuery,String indsCodeIdSeqQuery,
			String indsCodeInsertQuery,String indsCodeDescInsertQuery,String indsMapDeleteQuery,
			String indsUniqueQuery,String indsDescUpdateQuery){

		this.validateWithIdQuery = validateWithIdQuery;
		this.validateWithoutIdQuery = validateWithoutIdQuery;
		this.validatePrfdMapQuery = validatePrfdMapQuery;
		this.insertQuery = insertQuery;
		this.selectQuery = selectQuery;
		this.outputFilePath = outputFilePath;
		this.errorFilePath = errorFilePath;
		this.loadOutputFilePath = loadOutputFilePath;
		this.loadErrorFilePath = loadErrorFilePath;
		this.cdValQuery = cdValQuery;
		this.validateIdQuery = validateIdQuery;
		this.validateDescIdQuery = validateDescIdQuery;
		this.indsCodeIdSeqQuery = indsCodeIdSeqQuery;
		this.indsCodeInsertQuery = indsCodeInsertQuery;
		this.indsCodeDescInsertQuery = indsCodeDescInsertQuery;
		this.indsMapDeleteQuery = indsMapDeleteQuery;
		this.indsUniqueQuery = indsUniqueQuery;
		this.indsDescUpdateQuery = indsDescUpdateQuery;
	}

	/**
	 * @return the selectQuery
	 */
	public String getSelectQuery() {
		return selectQuery;
	}

	/**
	 * @param selectQuery the selectQuery to set
	 */
	public void setSelectQuery(String selectQuery) {
		this.selectQuery = selectQuery;
	}

	/**
	 * @return the validateWithIdQuery
	 */
	public String getValidateWithIdQuery() {
		return validateWithIdQuery;
	}

	/**
	 * @param validateWithIdQuery the validateWithIdQuery to set
	 */
	public void setValidateWithIdQuery(String validateWithIdQuery) {
		this.validateWithIdQuery = validateWithIdQuery;
	}

	/**
	 * @return the validateWithoutIdQuery
	 */
	public String getValidateWithoutIdQuery() {
		return validateWithoutIdQuery;
	}

	/**
	 * @param validateWithoutIdQuery the validateWithoutIdQuery to set
	 */
	public void setValidateWithoutIdQuery(String validateWithoutIdQuery) {
		this.validateWithoutIdQuery = validateWithoutIdQuery;
	}

	/**
	 * @return the validatePrfdMapQuery
	 */
	public String getValidatePrfdMapQuery() {
		return validatePrfdMapQuery;
	}

	/**
	 * @param validatePrfdMapQuery the validatePrfdMapQuery to set
	 */
	public void setValidatePrfdMapQuery(String validatePrfdMapQuery) {
		this.validatePrfdMapQuery = validatePrfdMapQuery;
	}

	/**
	 * @return the insertQuery
	 */
	public String getInsertQuery() {
		return insertQuery;
	}

	/**
	 * @param insertQuery the insertQuery to set
	 */
	public void setInsertQuery(String insertQuery) {
		this.insertQuery = insertQuery;
	}



	/**
	 * @return the outputFilePath
	 */
	public String getOutputFilePath() {
		return outputFilePath;
	}

	/**
	 * @param outputFilePath the outputFilePath to set
	 */
	public void setOutputFilePath(String outputFilePath) {
		this.outputFilePath = outputFilePath;
	}

	/**
	 * @return the errorFilePath
	 */
	public String getErrorFilePath() {
		return errorFilePath;
	}

	/**
	 * @param errorFilePath the errorFilePath to set
	 */
	public void setErrorFilePath(String errorFilePath) {
		this.errorFilePath = errorFilePath;
	}

	/**
	 * @return the loadOutputFilePath
	 */
	public String getLoadOutputFilePath() {
		return loadOutputFilePath;
	}

	/**
	 * @param loadOutputFilePath the loadOutputFilePath to set
	 */
	public void setLoadOutputFilePath(String loadOutputFilePath) {
		this.loadOutputFilePath = loadOutputFilePath;
	}

	/**
	 * @return the loadErrorFilePath
	 */
	public String getLoadErrorFilePath() {
		return loadErrorFilePath;
	}

	/**
	 * @param loadErrorFilePath the loadErrorFilePath to set
	 */
	public void setLoadErrorFilePath(String loadErrorFilePath) {
		this.loadErrorFilePath = loadErrorFilePath;
	}

	/**
	 * @return the cdValQuery
	 */
	public String getCdValQuery() {
		return cdValQuery;
	}

	/**
	 * @param cdValQuery the cdValQuery to set
	 */
	public void setCdValQuery(String cdValQuery) {
		this.cdValQuery = cdValQuery;
	}

	/**
	 * @return the validateIdQuery
	 */
	public String getValidateIdQuery() {
		return validateIdQuery;
	}

	/**
	 * @param validateIdQuery the validateIdQuery to set
	 */
	public void setValidateIdQuery(String validateIdQuery) {
		this.validateIdQuery = validateIdQuery;
	}

	/**
	 * @return the validateDescIdQuery
	 */
	public String getValidateDescIdQuery() {
		return validateDescIdQuery;
	}

	/**
	 * @param validateDescIdQuery the validateDescIdQuery to set
	 */
	public void setValidateDescIdQuery(String validateDescIdQuery) {
		this.validateDescIdQuery = validateDescIdQuery;
	}

	/**
	 * @return the indsCodeIdSeqQuery
	 */
	public String getIndsCodeIdSeqQuery() {
		return indsCodeIdSeqQuery;
	}

	/**
	 * @param indsCodeIdSeqQuery the indsCodeIdSeqQuery to set
	 */
	public void setIndsCodeIdSeqQuery(String indsCodeIdSeqQuery) {
		this.indsCodeIdSeqQuery = indsCodeIdSeqQuery;
	}

	/**
	 * @return the indsCodeInsertQuery
	 */
	public String getIndsCodeInsertQuery() {
		return indsCodeInsertQuery;
	}

	/**
	 * @param indsCodeInsertQuery the indsCodeInsertQuery to set
	 */
	public void setIndsCodeInsertQuery(String indsCodeInsertQuery) {
		this.indsCodeInsertQuery = indsCodeInsertQuery;
	}

	/**
	 * @return the indsCodeDescInsertQuery
	 */
	public String getIndsCodeDescInsertQuery() {
		return indsCodeDescInsertQuery;
	}

	/**
	 * @param indsCodeDescInsertQuery the indsCodeDescInsertQuery to set
	 */
	public void setIndsCodeDescInsertQuery(String indsCodeDescInsertQuery) {
		this.indsCodeDescInsertQuery = indsCodeDescInsertQuery;
	}

	/**
	 * @return the indsMapDeleteQuery
	 */
	public String getIndsMapDeleteQuery() {
		return indsMapDeleteQuery;
	}

	/**
	 * @param indsMapDeleteQuery the indsMapDeleteQuery to set
	 */
	public void setIndsMapDeleteQuery(String indsMapDeleteQuery) {
		this.indsMapDeleteQuery = indsMapDeleteQuery;
	}

	/**
	 * @return the indsUniqueQuery
	 */
	public String getIndsUniqueQuery() {
		return indsUniqueQuery;
	}

	/**
	 * @param indsUniqueQuery the indsUniqueQuery to set
	 */
	public void setIndsUniqueQuery(String indsUniqueQuery) {
		this.indsUniqueQuery = indsUniqueQuery;
	}

	/**
	 * @return the indsDescUpdateQuery
	 */
	public String getIndsDescUpdateQuery() {
		return indsDescUpdateQuery;
	}

	/**
	 * @param indsDescUpdateQuery the indsDescUpdateQuery to set
	 */
	public void setIndsDescUpdateQuery(String indsDescUpdateQuery) {
		this.indsDescUpdateQuery = indsDescUpdateQuery;
	}


	


}
