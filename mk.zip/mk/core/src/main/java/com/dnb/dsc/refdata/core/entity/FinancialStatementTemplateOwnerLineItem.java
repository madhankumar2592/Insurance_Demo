/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *	Entity for finl_stmt_tmplt_owr_ln_itm table
 *
 * @author Cognizant
 * @version last updated : June 14, 2012
 * @see
 *
 */
@Entity
@Table(name = "finl_stmt_tmplt_owr_ln_itm")
@NamedQueries({
	@NamedQuery(name = "FinancialStatementTemplateOwnerLineItem.removeFinancialStatementTemplateOwnerLineItemById", query = "DELETE FinancialStatementTemplateOwnerLineItem o where o.financialStatementTemplateLineItemId = :financialStatementTemplateLineItemId")
})
public class FinancialStatementTemplateOwnerLineItem extends Audit{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "FINL_STMT_TMPLT_LN_ITM_ID")
	private Long financialStatementTemplateLineItemId;

	@Column(name = "TMPLT_OWR_LN_ITM_CODE")
	private String templateOwnerLineItemCode;
	
	public FinancialStatementTemplateOwnerLineItem(){

	}

	/**
	 * @return the financialStatementTemplateLineItemId
	 */
	public Long getFinancialStatementTemplateLineItemId() {
		return financialStatementTemplateLineItemId;
	}

	/**
	 * @param financialStatementTemplateLineItemId the financialStatementTemplateLineItemId to set
	 */
	public void setFinancialStatementTemplateLineItemId(
			Long financialStatementTemplateLineItemId) {
		this.financialStatementTemplateLineItemId = financialStatementTemplateLineItemId;
	}

	/**
	 * @return the templateOwnerLineItemCode
	 */
	public String getTemplateOwnerLineItemCode() {
		return templateOwnerLineItemCode;
	}

	/**
	 * @param templateOwnerLineItemCode the templateOwnerLineItemCode to set
	 */
	public void setTemplateOwnerLineItemCode(String templateOwnerLineItemCode) {
		this.templateOwnerLineItemCode = templateOwnerLineItemCode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FinancialStatementTemplateOwnerLineItem [financialStatementTemplateLineItemId="
				+ financialStatementTemplateLineItemId
				+ ", templateOwnerLineItemCode="
				+ templateOwnerLineItemCode
				+ "]";
	}

}
