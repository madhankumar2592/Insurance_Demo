/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "MKT_GRP")
@NamedQueries({
		})
public class MarketGroup extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "MKT_GRP_ID")
	private Long mktGrpId;
		
	@Column(name = "PROD_MKT_ID")
	private Long productMktId;
	
	@Column(name = "MKT_GRP_CD")
	private Long mktGrpCd;
	
	
	
	/**
	 * @param mktGrpId the mktGrpId to set
	 */
	public void setMktGrpId(Long mktGrpId) {
		this.mktGrpId = mktGrpId;
	}

	/**
	 * @return the mktGrpId
	 */
	public Long getMktGrpId() {
		return mktGrpId;
	}

	public Long getProductMktId() {
		return productMktId;
	}

	public void setProductMktId(Long productMktId) {
		this.productMktId = productMktId;
	}

	public Long getMktGrpCd() {
		return mktGrpCd;
	}

	public void setMktGrpCd(Long mktGrpCd) {
		this.mktGrpCd = mktGrpCd;
	}

	/**
	 * Empty Constructor.
	 */
	public MarketGroup() {
		super();
	}
	
	public MarketGroup(Long productMktId) {
		super();
		this.productMktId = productMktId;
	}
	/*public MarketGroup(Long MarketGroupVersion) {
		super();
		this.MarketGroupVersion = MarketGroupVersion;
	}*/
	public MarketGroup(Long mktGrpId, Long mktGrpCd) {
		super();
		this.mktGrpId = mktGrpId;
		this.mktGrpCd= mktGrpCd;
	}
	
	
	/**
	 * 
	 * @param MarketGroupId
	 * @param MarketGroupVersion
	 * @param MarketGroupTypeId
	 * @param MarketGroupMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public MarketGroup(Long productMktId, Long mktGrpCd, Long mktGrpId,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.productMktId = productMktId;
		this.mktGrpCd = mktGrpCd;
		this.mktGrpId = mktGrpId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MarketGroup [mktGrpId=" + mktGrpId
				+ ", productMktId=" + productMktId 
				+ ",mktGrpCd=" + mktGrpCd + 
				  "]";
	}
	
	
}
