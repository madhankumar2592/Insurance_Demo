/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "PROD_GRP")
@NamedQueries({
		
		})
public class ProductGroup extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PROD_GRP_ID")
	private Long productGrpId;
		
	@Column(name = "PROD_GRP_CD")
	private Long productGrpCode;
	
	@Column(name = "PROD_ID")
	private Long productId;
	
	public Long getProductGrpId() {
		return productGrpId;
	}

	public void setProductGrpId(Long productGrpId) {
		this.productGrpId = productGrpId;
	}

	public Long getProductGrpCode() {
		return productGrpCode;
	}

	public void setProductGrpCode(Long productGrpCode) {
		this.productGrpCode = productGrpCode;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	/**
	 * Empty Constructor.
	 */
	public ProductGroup() {
		super();
	}
	
	public ProductGroup(Long productGrpId) {
		super();
		this.productGrpId = productGrpId;
	}
	/*public ProductGroup(Long ProductGroupVersion) {
		super();
		this.ProductGroupVersion = ProductGroupVersion;
	}*/
	public ProductGroup(Long productGrpId, Long productGrpCode) {
		super();
		this.productGrpId = productGrpId;
		this.productGrpCode = productGrpCode;
	}
	
	
	/**
	 * 
	 * @param ProductGroupId
	 * @param ProductGroupVersion
	 * @param ProductGroupTypeId
	 * @param ProductGroupMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public ProductGroup(Long productGrpId, Long productGrpCode, Long productId,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.productGrpId = productGrpId;
		this.productGrpCode = productGrpCode;
		this.productId = productId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ProductGroup [productGrpId=" + productGrpId
				+ ", productGrpCode=" + productGrpCode 
				+ ",productId=" + productId + 
				  "]";
	}
	
	
}
