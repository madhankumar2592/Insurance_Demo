/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "SCR_MAP")
@NamedQueries({
		@NamedQuery(name = "ScoreMap.retrieveCountForScoreTypeCode", query = "SELECT count(s.scoreTypeId) FROM ScoreType s WHERE s.scoreTypeCode= :scoreTypeCode")		
		})
public class ScoreMap extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	

	@Id
	@Column(name = "SCR_MAP_ID")
	private Long scoreMapId;
		
	@Column(name = "PRNT_SCR_ID")
	private Long prntScrsId;
	
	@Column(name = "SCR_GRU_ASSN_ID")
	private Long scrGruAssnId;
	
	@Column(name = "SCR_ID")
	private Long scrId;
	
	@Column(name = "SCR_ATTR_VAL")
	private String scrAttrVal;
	
	@Column(name = "INAC_INDC")
	private Long inactInd;
	
	public Long getScoreMapId() {
		return scoreMapId;
	}
	public void setScoreMapId(Long scoreMapId) {
		this.scoreMapId = scoreMapId;
	}
	public Long getPrntScrsId() {
		return prntScrsId;
	}
	public void setPrntScrsId(Long prntScrsId) {
		this.prntScrsId = prntScrsId;
	}
	public Long getScrGruAssnId() {
		return scrGruAssnId;
	}
	public void setScrGruAssnId(Long scrGruAssnId) {
		this.scrGruAssnId = scrGruAssnId;
	}
	public Long getScrId() {
		return scrId;
	}
	public void setScrId(Long scrId) {
		this.scrId = scrId;
	}
	public String getScrAttrVal() {
		return scrAttrVal;
	}
	public void setScrAttrVal(String scrAttrVal) {
		this.scrAttrVal = scrAttrVal;
	}
	public Long getInactInd() {
		return inactInd;
	}
	public void setInactInd(Long inactInd) {
		this.inactInd = inactInd;
	}
	/**
	 * Empty Constructor.
	 */
	public ScoreMap(Long prntScrsId) {
		super();
		this.prntScrsId = prntScrsId;
	}
	/*public ScoreMap(Long scoreVersion) {
		super();
		this.scoreVersion = scoreVersion;
	}*/
	public ScoreMap(Long prntScrsId, Long scrGruAssnId) {
		super();
		this.prntScrsId = prntScrsId;
		this.scrGruAssnId = scrGruAssnId;
	}
	
	public ScoreMap() {
		super();
	}
	/**
	 * 
	 * @param scoreId
	 * @param scoreVersion
	 * @param scoreTypeId
	 * @param scoreMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public ScoreMap(Long scoreMapId, Long prntScrsId, Long scrGruAssnId, Long scrId,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate, Long inactiveIndicator,String scrAttrVal
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.scoreMapId = scoreMapId;
		this.prntScrsId = prntScrsId;
		this.scrGruAssnId = scrGruAssnId;
		this.scrId = scrId;
		this.inactInd = inactiveIndicator;
		this.scrAttrVal = scrAttrVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "scoreId [scoreMapId=" + scoreMapId
				+ ", prntScrsId=" + prntScrsId 
				+",scrGruAssnId=" + scrGruAssnId+ 
				",scrId=" + scrId + 
				",scrAttrVal=" + scrAttrVal +
				",inactInd=" + inactInd +
				 "]";
	}
	
	
}
