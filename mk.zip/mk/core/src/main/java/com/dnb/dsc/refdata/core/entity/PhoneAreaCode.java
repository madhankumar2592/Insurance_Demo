/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "PHON_AREA_CODE")
@NamedQueries({
	@NamedQuery(name = "PhoneAreaCode.retrievePhoneAreaCodeById", query = "SELECT new PhoneAreaCode(p.phoneAreaCodeId, p.areaCodeNumber, p.areaCodeServiceDescription, p.territoryGeoUnitId, p.countryGeoUnitId ,p.dnbUnusGlsyId , p.createdUser ,p.createdDate ,p.modifiedUser ,p.modifiedDate ,d.effvDt) FROM PhoneAreaCode p, DnbUnusGlsy d where p.phoneAreaCodeId = :phoneAreaCodeId and p.dnbUnusGlsyId = d.dnbUnusGlsyId"),
	@NamedQuery(name = "PhoneAreaCode.removePhoneAreaCodeById", query = "DELETE PhoneAreaCode p where p.dnbUnusGlsyId = :dnbUnusGlsyId"),
	@NamedQuery(name = "PhoneAreaCode.removePhoneAreaCodeByPrimaryKey", query = "DELETE PhoneAreaCode p where p.phoneAreaCodeId = :phoneAreaCodeId"),
	@NamedQuery(name = "PhoneAreaCode.retrieveAreaCode", query = "select distinct areaCodeNumber from PhoneAreaCode"),
	@NamedQuery(name = "PhoneAreaCode.retrieveAreaCodeServiceDesc", query = "select distinct areaCodeServiceDescription from PhoneAreaCode"),
	@NamedQuery(name = "PhoneAreaCode.countPhoneAreaCode", query = "SELECT count(p.phoneAreaCodeId) FROM PhoneAreaCode p WHERE p.phoneAreaCodeId = :phoneAreaCodeId")
})	
public class PhoneAreaCode extends Audit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8971803068235373475L;
	
	@Id
	@Column(name = "PHON_AREA_CODE_ID")
	private Long phoneAreaCodeId;
	
	@Column(name = "AREA_CODE_NBR")
	private String areaCodeNumber;
	
	@Column(name = "AREA_CODE_SVC_DESC")
	private String areaCodeServiceDescription;
	
	@Column(name = "TERR_GEO_UNIT_ID")
	private Long territoryGeoUnitId;
	
	@Column(name = "CTRY_GEO_UNIT_ID")
	private Long countryGeoUnitId;
	
	@Column(name = "DNB_UNUS_GLSY_ID")
	private Long dnbUnusGlsyId;
	
	@Transient
	private String countryGeoUnitOfficialName;
	
	@Transient
	private String territoryGeoUnitOfficialName;
	
	@Transient
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effvDt;
	
	
	
	
	@Transient
	private int errorCD;
		
	/**
	 * Empty Constructor.
	 */
	public PhoneAreaCode() {
		super();
	}

	/**
	 * @param phoneAreaCodeId
	 * @param areaCodeNumber
	 * @param areaCodeServiceDescription
	 * @param territoryGeoUnitId
	 * @param countryGeoUnitId
	 * @param dnbUnusGlsyId
	 * @param countryGeoUnitOfficialName
	 * @param territoryGeoUnitOfficialName
	 * @param effvDt
	 */
	public PhoneAreaCode(Long phoneAreaCodeId, String areaCodeNumber,
			String areaCodeServiceDescription, Long territoryGeoUnitId,
			Long countryGeoUnitId, Long dnbUnusGlsyId,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate,
			Date effvDt
			) {
		super(createdUser,createdDate,modifiedUser,modifiedDate);
		this.phoneAreaCodeId = phoneAreaCodeId;
		this.areaCodeNumber = areaCodeNumber;
		this.areaCodeServiceDescription = areaCodeServiceDescription;
		this.territoryGeoUnitId = territoryGeoUnitId;
		this.countryGeoUnitId = countryGeoUnitId;
		this.dnbUnusGlsyId = dnbUnusGlsyId;
		this.effvDt = effvDt;
	}

	/**
	 * @param countryGeoUnitId
	 * @param countryGeoUnitOfficialName
	 */
	public PhoneAreaCode(Long countryGeoUnitId,
			String countryGeoUnitOfficialName) {
		this.countryGeoUnitId = countryGeoUnitId;
		this.countryGeoUnitOfficialName = countryGeoUnitOfficialName;
	}

	
	/**
	 * @param phoneAreaCodeId
	 * @param areaCodeNumber
	 * @param areaCodeServiceDescription
	 * @param territoryGeoUnitId
	 * @param countryGeoUnitId
	 * @param countryGeoUnitOfficialName
	 * @param territoryGeoUnitOfficialName
	 */
	public PhoneAreaCode(Long phoneAreaCodeId, String areaCodeNumber,
			String areaCodeServiceDescription, Long territoryGeoUnitId,
			Long countryGeoUnitId, String territoryGeoUnitOfficialName,
			String countryGeoUnitOfficialName) {
		this.phoneAreaCodeId = phoneAreaCodeId;
		this.areaCodeNumber = areaCodeNumber;
		this.areaCodeServiceDescription = areaCodeServiceDescription;
		this.territoryGeoUnitId = territoryGeoUnitId;
		this.countryGeoUnitId = countryGeoUnitId;
		this.countryGeoUnitOfficialName = countryGeoUnitOfficialName;
		this.territoryGeoUnitOfficialName = territoryGeoUnitOfficialName;
	}

	/**
	 * @return the phoneAreaCodeId
	 */
	public Long getPhoneAreaCodeId() {
		return phoneAreaCodeId;
	}

	/**
	 * @param phoneAreaCodeId the phoneAreaCodeId to set
	 */
	public void setPhoneAreaCodeId(Long phoneAreaCodeId) {
		this.phoneAreaCodeId = phoneAreaCodeId;
	}

	/**
	 * @return the areaCodeNumber
	 */
	public String getAreaCodeNumber() {
		return areaCodeNumber;
	}

	/**
	 * @param areaCodeNumber the areaCodeNumber to set
	 */
	public void setAreaCodeNumber(String areaCodeNumber) {
		this.areaCodeNumber = areaCodeNumber;
	}

	/**
	 * @return the areaCodeServiceDescription
	 */
	public String getAreaCodeServiceDescription() {
		return areaCodeServiceDescription;
	}

	/**
	 * @param areaCodeServiceDescription the areaCodeServiceDescription to set
	 */
	public void setAreaCodeServiceDescription(String areaCodeServiceDescription) {
		this.areaCodeServiceDescription = areaCodeServiceDescription;
	}

	/**
	 * @return the territoryGeoUnitId
	 */
	public Long getTerritoryGeoUnitId() {
		return territoryGeoUnitId;
	}

	/**
	 * @param territoryGeoUnitId the territoryGeoUnitId to set
	 */
	public void setTerritoryGeoUnitId(Long territoryGeoUnitId) {
		this.territoryGeoUnitId = territoryGeoUnitId;
	}

	/**
	 * @return the countryGeoUnitId
	 */
	public Long getCountryGeoUnitId() {
		return countryGeoUnitId;
	}

	/**
	 * @param countryGeoUnitId the countryGeoUnitId to set
	 */
	public void setCountryGeoUnitId(Long countryGeoUnitId) {
		this.countryGeoUnitId = countryGeoUnitId;
	}

	/**
	 * @return the dnbUnusGlsyId
	 */
	public Long getDnbUnusGlsyId() {
		return dnbUnusGlsyId;
	}

	/**
	 * @param dnbUnusGlsyId the dnbUnusGlsyId to set
	 */
	public void setDnbUnusGlsyId(Long dnbUnusGlsyId) {
		this.dnbUnusGlsyId = dnbUnusGlsyId;
	}

	/**
	 * @return the countryGeoUnitOfficialName
	 */
	public String getCountryGeoUnitOfficialName() {
		return countryGeoUnitOfficialName;
	}

	/**
	 * @param countryGeoUnitOfficialName the countryGeoUnitOfficialName to set
	 */
	public void setCountryGeoUnitOfficialName(String countryGeoUnitOfficialName) {
		this.countryGeoUnitOfficialName = countryGeoUnitOfficialName;
	}

	/**
	 * @return the territoryGeoUnitOfficialName
	 */
	public String getTerritoryGeoUnitOfficialName() {
		return territoryGeoUnitOfficialName;
	}

	/**
	 * @param territoryGeoUnitOfficialName the territoryGeoUnitOfficialName to set
	 */
	public void setTerritoryGeoUnitOfficialName(String territoryGeoUnitOfficialName) {
		this.territoryGeoUnitOfficialName = territoryGeoUnitOfficialName;
	}

	/**
	 * @return the effvDt
	 */
	public Date getEffvDt() {
		return effvDt;
	}

	/**
	 * @param effvDt the effvDt to set
	 */
	public void setEffvDt(Date effvDt) {
		this.effvDt = effvDt;
	}

	/**
	 * @return the errorCD
	 */
	public int getErrorCD() {
		return errorCD;
	}

	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(int errorCD) {
		this.errorCD = errorCD;
	}
}
