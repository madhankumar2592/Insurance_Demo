/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "SLS_CHNL")
@NamedQueries({
		})
public class SalesChannel extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "SLS_CHNL_ID")
	private Long salesChnlId;
		
	@Column(name = "SLS_CHNL_VERS")
	private Long salesChnlVers;
	
	@Column(name = "SLS_CHNL_CD")
	private Long salesChnlCode;	
	
	@Column(name = "INAC_INDC")
	private Long inactiveIndicator;	
	
	public Long getSalesChnlId() {
		return salesChnlId;
	}

	public void setSalesChnlId(Long salesChnlId) {
		this.salesChnlId = salesChnlId;
	}

	public Long getSalesChnlVers() {
		return salesChnlVers;
	}

	public void setSalesChnlVers(Long salesChnlVers) {
		this.salesChnlVers = salesChnlVers;
	}

	public Long getSalesChnlCode() {
		return salesChnlCode;
	}

	public void setSalesChnlCode(Long salesChnlCode) {
		this.salesChnlCode = salesChnlCode;
	}

	/**
	 * @param inactiveIndicator the inactiveIndicator to set
	 */
	public void setInactiveIndicator(Long inactiveIndicator) {
		this.inactiveIndicator = inactiveIndicator;
	}

	/**
	 * @return the inactiveIndicator
	 */
	public Long getInactiveIndicator() {
		return inactiveIndicator;
	}

	/**
	 * Empty Constructor.
	 */
	public SalesChannel() {
		super();
	}
	
	public SalesChannel(Long salesChnlId) {
		super();
		this.salesChnlId = salesChnlId;
	}
	/*public SalesChannel(Long SalesChannelVersion) {
		super();
		this.SalesChannelVersion = SalesChannelVersion;
	}*/
	public SalesChannel(Long salesChnlId, Long salesChnlVers) {
		super();
		this.salesChnlId = salesChnlId;
		this.salesChnlVers = salesChnlVers;
	}
	
	
	/**
	 * 
	 * @param SalesChannelId
	 * @param SalesChannelVersion
	 * @param SalesChannelTypeId
	 * @param SalesChannelMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public SalesChannel(Long salesChnlId, Long salesChnlVers, Long salesChnlCode,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.salesChnlId = salesChnlId;
		this.salesChnlVers = salesChnlVers;
		this.salesChnlCode = salesChnlCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SalesChannel [salesChnlId=" + salesChnlId
				+ ", salesChnlVers=" + salesChnlVers 
				+ ",salesChnlCode=" + salesChnlCode + 
				  "]";
	}
	
	
}
