/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;

/**
 * This class used as an value object class for the UserRoleVO. The class
 * will store the user attributes retrieved as part of the OAM component.
 *
 * @author Cognizant
 * @version last updated : Apr 12, 2012
 * @see
 *
 */
public class UserRoleVO implements Serializable {

	private static final long serialVersionUID = 8993265291802855778L;
	/**
	 * The user role code attribute
	 */
	private String roleCode;
	/**
	 * The user role Description attribute
	 */
	private String roleDescription;
	/**
	 * The user role name attribute
	 */
	private String userGroup;

	/**
	 * The default constructor
	 */
	public UserRoleVO() {
	}

	/**
	 * @return the roleCode
	 */
	public String getRoleCode() {
		return roleCode;
	}

	/**
	 * @param roleCode the roleCode to set
	 */
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	/**
	 * @return the roleDescription
	 */
	public String getRoleDescription() {
		return roleDescription;
	}

	/**
	 * @param roleDescription the roleDescription to set
	 */
	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	/**
	 * @return the userGroup
	 */
	public String getUserGroup() {
		return userGroup;
	}

	/**
	 * @param userGroup the userGroup to set
	 */
	public void setUserGroup(String userGroup) {
		this.userGroup = userGroup;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserRoleVO [roleCode=" + roleCode + ", roleDescription="
				+ roleDescription + ", userGroup=" + userGroup + "]";
	}
}
