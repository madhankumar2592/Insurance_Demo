package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

public class EditScoreSearchVO  implements Serializable {

	private static final long serialVersionUID = 8993265291802855778L;
	
	private String scrGranularityLable;
	private Long scr_gru_id;
	private Long scr_attr_id;
	private Long scr_gru_assn_id;
	private String scr_attr_val;
	private Long scr_id;
	private Long scr_typ_id;
	private Long scr_mkt_cd;
	private Double scr_ver;
	private Long prnt_scr_id;
	private Long scr_map_id;
	
	private String prnt_scr_id_val;
	private String scr_map_id_val;

	
	public String getPrnt_scr_id_val() {
		return prnt_scr_id_val;
	}
	public void setPrnt_scr_id_val(String prnt_scr_id_val) {
		this.prnt_scr_id_val = prnt_scr_id_val;
	}
	public String getScr_map_id_val() {
		return scr_map_id_val;
	}
	public void setScr_map_id_val(String scr_map_id_val) {
		this.scr_map_id_val = scr_map_id_val;
	}

	private List<GranularityMapDetails> GranularityMapDetailList;
	
	public List<GranularityMapDetails> getGranularityMapDetailList() {
		return GranularityMapDetailList;
	}
	public void setGranularityMapDetailList(
			List<GranularityMapDetails> granularityMapDetailList) {
		GranularityMapDetailList = granularityMapDetailList;
	}
	public Long getPrnt_scr_id() {
		return prnt_scr_id;
	}
	public void setPrnt_scr_id(Long prnt_scr_id) {
		this.prnt_scr_id = prnt_scr_id;
	}
	public Long getScr_map_id() {
		return scr_map_id;
	}
	public void setScr_map_id(Long scr_map_id) {
		this.scr_map_id = scr_map_id;
	}
	public String getScrGranularityLable() {
		return scrGranularityLable;
	}
	public void setScrGranularityLable(String scrGranularityLable) {
		this.scrGranularityLable = scrGranularityLable;
	}
	public Long getScr_gru_id() {
		return scr_gru_id;
	}
	public void setScr_gru_id(Long scr_gru_id) {
		this.scr_gru_id = scr_gru_id;
	}
	public Long getScr_attr_id() {
		return scr_attr_id;
	}
	public void setScr_attr_id(Long scr_attr_id) {
		this.scr_attr_id = scr_attr_id;
	}
	public Long getScr_gru_assn_id() {
		return scr_gru_assn_id;
	}
	public void setScr_gru_assn_id(Long scr_gru_assn_id) {
		this.scr_gru_assn_id = scr_gru_assn_id;
	}
	public String getScr_attr_val() {
		return scr_attr_val;
	}
	public void setScr_attr_val(String scr_attr_val) {
		this.scr_attr_val = scr_attr_val;
	}
	public Long getScr_id() {
		return scr_id;
	}
	public void setScr_id(Long scr_id) {
		this.scr_id = scr_id;
	}
	public Long getScr_typ_id() {
		return scr_typ_id;
	}
	public void setScr_typ_id(Long scr_typ_id) {
		this.scr_typ_id = scr_typ_id;
	}
	public Long getScr_mkt_cd() {
		return scr_mkt_cd;
	}
	public void setScr_mkt_cd(Long scr_mkt_cd) {
		this.scr_mkt_cd = scr_mkt_cd;
	}
	public Double getScr_ver() {
		return scr_ver;
	}
	public void setScr_ver(Double scr_ver) {
		this.scr_ver = scr_ver;
	}
	
	@Override
	public String toString() {
		return "EditScoreSearchVO [scr_gru_id=" + scr_gru_id + "scr_attr_id" + scr_attr_id
				+ ", scr_gru_assn_id=" + scr_gru_assn_id + "]";
	}
}
