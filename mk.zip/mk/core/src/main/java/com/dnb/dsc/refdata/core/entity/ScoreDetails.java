/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the Code Table. The class
 * will have a direct mapping toe DB table cd_tbl.
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
@Entity
@Table(name = "SCR_DTL")
@NamedQueries({
		@NamedQuery(name = "ScoreDetails.retrieveScoreTableList", query = "SELECT new CodeTable(c.codeTableId, c.codeTableName) FROM CodeTable c order by c.codeTableId"),
		@NamedQuery(name = "ScoreDetails.countTable", query = "SELECT count(c.codeTableId) FROM CodeTable c WHERE c.codeTableId = :codeTableId"),
		@NamedQuery(name = "ScoreDetails.retrieveScoreDetailsId", query = "SELECT distinct(s.scoreDetId) FROM ScoreDetails s where s.scoreId = :scoreId"),
		@NamedQuery(name = "ScoreDetails.retrieveScrDtlId", query = "SELECT distinct(s.scoreDetId) FROM ScoreDetails s where s.scoreId = :scoreId and s.scoreTypAssnId" +
				" in (SELECT t.scoreTypeAssociationId FROM ScoreTypeAssociation t where t.granularityTypeId in (SELECT a.granularityTypeId FROM " +
				" ScoreGranularityAssociation a where a.granularityTypeAssociationId in (:granAssnId)))"),
		@NamedQuery(name = "ScoreDetails.retrieveScrDtlsId", query = "SELECT distinct(s.scoreDetId) FROM ScoreDetails s where s.scoreId = :scoreId"),
		@NamedQuery(name = "ScoreDetails.removeScoreDetailsById", query = "DELETE FROM ScoreDetails c where c.scoreDetId  in ( :scrDtlId)")

		
})
public class ScoreDetails extends Audit implements Serializable {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "SCR_DTL_ID")
	private Long scoreDetId;

	@Column(name = "SCR_ID")
	private Long scoreId;
	
	@Column(name = "SCR_TYP_ASSN_ID")
	private Long scoreTypAssnId;
	
	
	
	
	/*@ManyToOne(targetEntity = Score.class,fetch = FetchType.EAGER)
	@JoinColumn(name = "SCR_ID")
	private Score Score;
	
	@ManyToOne(targetEntity = ScoreTypeAssc.class,fetch = FetchType.LAZY)
	@JoinColumn(name = "SCR_TYP_ASSC_ID")
	private ScoreTypeAssc scoreTypeAssc;*/
	
	/*@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "scoreTypeId")
	private List<Score> scores;*/
	
	/*@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "scoreTypAsscId")
	private List<ScoreTypeAssc> scoreTypeAssc;*/
	
	

	/*public Score getScore() {
		return Score;
	}

	public void setScore(Score score) {
		Score = score;
	}

	public ScoreTypeAssc getScoreTypeAssc() {
		return scoreTypeAssc;
	}

	public void setScoreTypeAssc(ScoreTypeAssc scoreTypeAssc) {
		this.scoreTypeAssc = scoreTypeAssc;
	}*/

	public Long getScoreTypAssnId() {
		return scoreTypAssnId;
	}

	public void setScoreTypAssnId(Long scoreTypAssnId) {
		this.scoreTypAssnId = scoreTypAssnId;
	}

	/**
	 * The default constructor
	 */
	public ScoreDetails() {
		super();
	}

	public Long getScoreDetId() {
		return scoreDetId;
	}

	public void setScoreDetId(Long scoreDetId) {
		this.scoreDetId = scoreDetId;
	}

	public Long getScoreId() {
		return scoreId;
	}

	public void setScoreId(Long scoreId) {
		this.scoreId = scoreId;
	}
	/*public List<Score> getScores() {
		return scores;
	}

	public void setScores(List<Score> scores) {
		this.scores = scores;
	}*/

	/*public List<ScoreTypeAssc> getScoreTypeAssc() {
		return scoreTypeAssc;
	}

	public void setScoreTypeAssc(List<ScoreTypeAssc> scoreTypeAssc) {
		this.scoreTypeAssc = scoreTypeAssc;
	}*/

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ScoreDetails [scoreDetId=" + scoreDetId + ", scoreId="
				+ scoreId +", scoreTypeAsscId="
					+ scoreTypAssnId +"]";
	}


}
