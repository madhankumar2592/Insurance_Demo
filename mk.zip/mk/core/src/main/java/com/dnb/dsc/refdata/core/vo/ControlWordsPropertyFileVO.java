package com.dnb.dsc.refdata.core.vo;


/**
 * The Class ControlWordsPropertyFileVO.
 */
public class ControlWordsPropertyFileVO {

	/** The validate dnb glsry type cd query. */
	private String validateDNBGlsryTypeCdQuery;
	
	/** The validate dnb gly id query. */
	private String validateDnbGlyIdQuery;
	
	/** The validate geo unit id query. */
	private String validateGeoUnitIdQuery;
	
	/** The validate com methd cd query. */
	private String validateComMethdCdQuery;
	
	/** The validate typecodes query. */
	private String validateTypecodesQuery;
	
	/** The validate infr txt id query. */
	private String validateInfrTxtIdQuery;
	
	/** The validate inf txt ctr apy id query. */
	private String validateInfTxtCtrApyIdQuery;
	
	/** The validate indus cd query. */
	private String validateIndusCdQuery;
	
	/** The validate inds cd inf tx id query. */
	private String validateIndsCdInfTxIdQuery;
	
	/** The validate lgl fm cls cd query. */
	private String validateLglFmClsCdQuery;
	
	/** The phon area code insert query. */
	private String phonAreaCodeInsertQuery;
	
	/** The infer txt seq query. */
	private String inferTxtSeqQuery;
	
	/** The phon area code seq query. */
	private String phonAreaCodeSeqQuery;
	
	/** The dnb unusable glsy seq query. */
	private String dnbUnusableGlsySeqQuery;
	
	/** The dnb unusable glsy insert query. */
	private String dnbUnusableGlsyInsertQuery;
	
	/** The dnb unusable glsy cnty appy insert query. */
	private String dnbUnusableGlsyCntyAppyInsertQuery;
	
	/** The dnb unusable glsy ind nme insert query. */
	private String dnbUnusableGlsyIndNmeInsertQuery;
	
	/** The dnb unusable glsy addr insert query. */
	private String dnbUnusableGlsyAddrInsertQuery;
	
	/** The dnb unusable glsy telecom insert query. */
	private String dnbUnusableGlsyTelecomInsertQuery;
	
	/** The infer txt insert query. */
	private String inferTxtInsertQuery;
	
	/** The inft txt cntry appy insert query. */
	private String inftTxtCntryAppyInsertQuery;
	
	/** The inds cd infer insert query. */
	private String indsCdInferInsertQuery;
	
	/** The lgl form insert query. */
	private String lglFormInsertQuery;
	
	/** The validate addr geo unit query. */
	private String validateAddrGeoUnitQuery;
	
	/** The dnb unusable glsy delete query. */
	private String dnbUnusableGlsyDeleteQuery;
	
	/** The dnb unusable glsy cnty appy delete query. */
	private String dnbUnusableGlsyCntyAppyDeleteQuery;
	
	/** The dnb unusable glsy cnty appy delete id query. */
	private String dnbUnusableGlsyCntyAppyDeleteIdQuery;
	
	/** The cntrl wrds output file path. */
	private String cntrlWrdsOutputFilePath;
	
	/** The cntrl wrds error file path. */
	private String cntrlWrdsErrorFilePath;
	
	/** The cntrl wrds load output file path. */
	private String cntrlWrdsLoadOutputFilePath;
	
	/** The cntrl wrds load error file path. */
	private String cntrlWrdsLoadErrorFilePath;
	
	private String infrTxtUpdateQuery;
	private String indsCdInfrDeleteQuery;
	private String infrTxtCntyAppyDeleteQuery;
	private String infrTxtDeleteQuery;
	private String lglInfrDeleteQuery;
	private String infrTxtCntyAppyDeleteSoftQuery;
	private String infrTxtDeleteSoftQuery;
	private String indsCdInfrUpdateQuery;
	private String infrTxtCntyAppyIdDeleteQuery;
	private String infrTxtCntyAppyIdDeleteSoftQuery;
	

	/**
	 * Instantiates a new control words property file vo.
	 *
	 * @param validateDNBGlsryTypeCdQuery the validate dnb glsry type cd query
	 * @param validateDnbGlyIdQuery the validate dnb gly id query
	 * @param validateGeoUnitIdQuery the validate geo unit id query
	 * @param validateComMethdCdQuery the validate com methd cd query
	 * @param validateTypecodesQuery the validate typecodes query
	 * @param validateInfrTxtIdQuery the validate infr txt id query
	 * @param validateInfTxtCtrApyIdQuery the validate inf txt ctr apy id query
	 * @param validateIndusCdQuery the validate indus cd query
	 * @param validateIndsCdInfTxIdQuery the validate inds cd inf tx id query
	 * @param validateLglFmClsCdQuery the validate lgl fm cls cd query
	 * @param phonAreaCodeInsertQuery the phon area code insert query
	 * @param inferTxtSeqQuery the infer txt seq query
	 * @param phonAreaCodeSeqQuery the phon area code seq query
	 * @param dnbUnusableGlsySeqQuery the dnb unusable glsy seq query
	 * @param dnbUnusableGlsyInsertQuery the dnb unusable glsy insert query
	 * @param dnbUnusableGlsyCntyAppyInsertQuery the dnb unusable glsy cnty appy insert query
	 * @param dnbUnusableGlsyIndNmeInsertQuery the dnb unusable glsy ind nme insert query
	 * @param dnbUnusableGlsyAddrInsertQuery the dnb unusable glsy addr insert query
	 * @param dnbUnusableGlsyTelecomInsertQuery the dnb unusable glsy telecom insert query
	 * @param inferTxtInsertQuery the infer txt insert query
	 * @param inftTxtCntryAppyInsertQuery the inft txt cntry appy insert query
	 * @param indsCdInferInsertQuery the inds cd infer insert query
	 * @param lglFormInsertQuery the lgl form insert query
	 * @param dnbUnusableGlsyDeleteQuery the dnb unusable glsy delete query
	 * @param dnbUnusableGlsyCntyAppyDeleteQuery the dnb unusable glsy cnty appy delete query
	 * @param dnbUnusableGlsyCntyAppyDeleteIdQuery the dnb unusable glsy cnty appy delete id query
	 * @param cntrlWrdsOutputFilePath the cntrl wrds output file path
	 * @param cntrlWrdsErrorFilePath the cntrl wrds error file path
	 * @param cntrlWrdsLoadOutputFilePath the cntrl wrds load output file path
	 * @param cntrlWrdsLoadErrorFilePath the cntrl wrds load error file path
	 * @param validateAddrGeoUnitQuery the validate addr geo unit query
	 */
	public ControlWordsPropertyFileVO(String validateDNBGlsryTypeCdQuery,
			String validateDnbGlyIdQuery, String validateGeoUnitIdQuery,
			String validateComMethdCdQuery, String validateTypecodesQuery,
			String validateInfrTxtIdQuery, String validateInfTxtCtrApyIdQuery,
			String validateIndusCdQuery,
			String validateIndsCdInfTxIdQuery,String validateLglFmClsCdQuery,
			String phonAreaCodeInsertQuery,
			String inferTxtSeqQuery,String phonAreaCodeSeqQuery,
			String dnbUnusableGlsySeqQuery,
			String dnbUnusableGlsyInsertQuery,
			String dnbUnusableGlsyIndNmeInsertQuery,
			String dnbUnusableGlsyCntyAppyInsertQuery,			
			String dnbUnusableGlsyAddrInsertQuery,
			String dnbUnusableGlsyTelecomInsertQuery,
			String inferTxtInsertQuery,
			String inftTxtCntryAppyInsertQuery,String indsCdInferInsertQuery,String lglFormInsertQuery,
			String dnbUnusableGlsyDeleteQuery,
			String dnbUnusableGlsyCntyAppyDeleteQuery,
			String dnbUnusableGlsyCntyAppyDeleteIdQuery,
			String infrTxtUpdateQuery,
			String indsCdInfrDeleteQuery,
			String infrTxtCntyAppyDeleteQuery,
			String infrTxtDeleteQuery,
			String lglInfrDeleteQuery,
			String infrTxtCntyAppyDeleteSoftQuery,
			String infrTxtDeleteSoftQuery,
			String indsCdInfrUpdateQuery,
			String infrTxtCntyAppyIdDeleteQuery,
			String infrTxtCntyAppyIdDeleteSoftQuery,
			String cntrlWrdsOutputFilePath, String cntrlWrdsErrorFilePath,
			String cntrlWrdsLoadOutputFilePath,String cntrlWrdsLoadErrorFilePath,String validateAddrGeoUnitQuery) {

		this.validateDNBGlsryTypeCdQuery = validateDNBGlsryTypeCdQuery;
		this.validateDnbGlyIdQuery = validateDnbGlyIdQuery;
		this.validateGeoUnitIdQuery = validateGeoUnitIdQuery;
		this.validateComMethdCdQuery = validateComMethdCdQuery;
		this.validateTypecodesQuery = validateTypecodesQuery;
		this.validateInfrTxtIdQuery = validateInfrTxtIdQuery;
		this.validateInfTxtCtrApyIdQuery =validateInfTxtCtrApyIdQuery;
		this.validateIndusCdQuery = validateIndusCdQuery;
		this.validateIndsCdInfTxIdQuery = validateIndsCdInfTxIdQuery;
		this.validateLglFmClsCdQuery = validateLglFmClsCdQuery;
		this.phonAreaCodeInsertQuery = phonAreaCodeInsertQuery;
		this.inferTxtSeqQuery = inferTxtSeqQuery;
		this.phonAreaCodeSeqQuery = phonAreaCodeSeqQuery;
		this.dnbUnusableGlsySeqQuery = dnbUnusableGlsySeqQuery;
		this.dnbUnusableGlsyInsertQuery = dnbUnusableGlsyInsertQuery;
		this.dnbUnusableGlsyIndNmeInsertQuery = dnbUnusableGlsyIndNmeInsertQuery;
		this.dnbUnusableGlsyCntyAppyInsertQuery = dnbUnusableGlsyCntyAppyInsertQuery;		
		this.dnbUnusableGlsyAddrInsertQuery = dnbUnusableGlsyAddrInsertQuery;
		this.dnbUnusableGlsyTelecomInsertQuery = dnbUnusableGlsyTelecomInsertQuery;
		this.inferTxtInsertQuery = inferTxtInsertQuery;
		this.inftTxtCntryAppyInsertQuery = inftTxtCntryAppyInsertQuery;
		this.indsCdInferInsertQuery = indsCdInferInsertQuery;
		this.lglFormInsertQuery = lglFormInsertQuery;
		this.dnbUnusableGlsyDeleteQuery=dnbUnusableGlsyDeleteQuery;
		this.dnbUnusableGlsyCntyAppyDeleteQuery=dnbUnusableGlsyCntyAppyDeleteQuery;
		this.dnbUnusableGlsyCntyAppyDeleteIdQuery=dnbUnusableGlsyCntyAppyDeleteIdQuery;
		this.infrTxtUpdateQuery=infrTxtUpdateQuery;
		this.indsCdInfrDeleteQuery=indsCdInfrDeleteQuery;
		this.infrTxtCntyAppyDeleteQuery=infrTxtCntyAppyDeleteQuery;
		this.infrTxtDeleteQuery=infrTxtDeleteQuery;
		this.lglInfrDeleteQuery=lglInfrDeleteQuery;
		this.infrTxtCntyAppyDeleteSoftQuery=infrTxtCntyAppyDeleteSoftQuery;
		this.infrTxtDeleteSoftQuery=infrTxtDeleteSoftQuery;
		this.indsCdInfrUpdateQuery=indsCdInfrUpdateQuery;
		this.infrTxtCntyAppyIdDeleteQuery=infrTxtCntyAppyIdDeleteQuery;
		this.infrTxtCntyAppyIdDeleteSoftQuery=infrTxtCntyAppyIdDeleteSoftQuery;
		this.cntrlWrdsOutputFilePath = cntrlWrdsOutputFilePath;
		this.cntrlWrdsErrorFilePath = cntrlWrdsErrorFilePath;
		this.cntrlWrdsLoadOutputFilePath = cntrlWrdsLoadOutputFilePath;
		this.cntrlWrdsLoadErrorFilePath = cntrlWrdsLoadErrorFilePath;
		this.validateAddrGeoUnitQuery = validateAddrGeoUnitQuery;
	}

	/**
	 * Gets the validate dnb glsry type cd query.
	 *
	 * @return the validateDNBGlsryTypeCdQuery
	 */
	public String getValidateDNBGlsryTypeCdQuery() {
		return validateDNBGlsryTypeCdQuery;
	}

	/**
	 * Sets the validate dnb glsry type cd query.
	 *
	 * @param validateDNBGlsryTypeCdQuery the validateDNBGlsryTypeCdQuery to set
	 */
	public void setValidateDNBGlsryTypeCdQuery(
			String validateDNBGlsryTypeCdQuery) {
		this.validateDNBGlsryTypeCdQuery = validateDNBGlsryTypeCdQuery;
	}

	/**
	 * Gets the validate dnb gly id query.
	 *
	 * @return the validateDnbGlyIdQuery
	 */
	public String getValidateDnbGlyIdQuery() {
		return validateDnbGlyIdQuery;
	}

	/**
	 * Gets the validate inds cd inf tx id query.
	 *
	 * @return the validateIndsCdInfTxIdQuery
	 */
	public String getValidateIndsCdInfTxIdQuery() {
		return validateIndsCdInfTxIdQuery;
	}

	/**
	 * Sets the validate inds cd inf tx id query.
	 *
	 * @param validateIndsCdInfTxIdQuery the validateIndsCdInfTxIdQuery to set
	 */
	public void setValidateIndsCdInfTxIdQuery(String validateIndsCdInfTxIdQuery) {
		this.validateIndsCdInfTxIdQuery = validateIndsCdInfTxIdQuery;
	}

	/**
	 * Sets the validate dnb gly id query.
	 *
	 * @param validateDnbGlyIdQuery the validateDnbGlyIdQuery to set
	 */
	public void setValidateDnbGlyIdQuery(String validateDnbGlyIdQuery) {
		this.validateDnbGlyIdQuery = validateDnbGlyIdQuery;
	}

	/**
	 * Gets the validate infr txt id query.
	 *
	 * @return the validateInfrTxtIdQuery
	 */
	public String getValidateInfrTxtIdQuery() {
		return validateInfrTxtIdQuery;
	}

	/**
	 * Sets the validate infr txt id query.
	 *
	 * @param validateInfrTxtIdQuery the validateInfrTxtIdQuery to set
	 */
	public void setValidateInfrTxtIdQuery(String validateInfrTxtIdQuery) {
		this.validateInfrTxtIdQuery = validateInfrTxtIdQuery;
	}

	/**
	 * Gets the validate indus cd query.
	 *
	 * @return the validateIndusCdQuery
	 */
	public String getValidateIndusCdQuery() {
		return validateIndusCdQuery;
	}

	/**
	 * Sets the validate indus cd query.
	 *
	 * @param validateIndusCdQuery the validateIndusCdQuery to set
	 */
	public void setValidateIndusCdQuery(String validateIndusCdQuery) {
		this.validateIndusCdQuery = validateIndusCdQuery;
	}

	/**
	 * Gets the cntrl wrds output file path.
	 *
	 * @return the cntrlWrdsOutputFilePath
	 */
	public String getCntrlWrdsOutputFilePath() {
		return cntrlWrdsOutputFilePath;
	}

	/**
	 * Sets the cntrl wrds output file path.
	 *
	 * @param cntrlWrdsOutputFilePath the cntrlWrdsOutputFilePath to set
	 */
	public void setCntrlWrdsOutputFilePath(String cntrlWrdsOutputFilePath) {
		this.cntrlWrdsOutputFilePath = cntrlWrdsOutputFilePath;
	}

	/**
	 * Gets the validate inf txt ctr apy id query.
	 *
	 * @return the validateInfTxtCtrApyIdQuery
	 */
	public String getValidateInfTxtCtrApyIdQuery() {
		return validateInfTxtCtrApyIdQuery;
	}

	/**
	 * Sets the validate inf txt ctr apy id query.
	 *
	 * @param validateInfTxtCtrApyIdQuery the validateInfTxtCtrApyIdQuery to set
	 */
	public void setValidateInfTxtCtrApyIdQuery(String validateInfTxtCtrApyIdQuery) {
		this.validateInfTxtCtrApyIdQuery = validateInfTxtCtrApyIdQuery;
	}

	/**
	 * Gets the validate geo unit id query.
	 *
	 * @return the validateGeoUnitIdQuery
	 */
	public String getValidateGeoUnitIdQuery() {
		return validateGeoUnitIdQuery;
	}

	/**
	 * Sets the validate geo unit id query.
	 *
	 * @param validateGeoUnitIdQuery the validateGeoUnitIdQuery to set
	 */
	public void setValidateGeoUnitIdQuery(String validateGeoUnitIdQuery) {
		this.validateGeoUnitIdQuery = validateGeoUnitIdQuery;
	}

	/**
	 * Gets the cntrl wrds error file path.
	 *
	 * @return the cntrlWrdsErrorFilePath
	 */
	public String getCntrlWrdsErrorFilePath() {
		return cntrlWrdsErrorFilePath;
	}

	/**
	 * Sets the cntrl wrds error file path.
	 *
	 * @param cntrlWrdsErrorFilePath the cntrlWrdsErrorFilePath to set
	 */
	public void setCntrlWrdsErrorFilePath(String cntrlWrdsErrorFilePath) {
		this.cntrlWrdsErrorFilePath = cntrlWrdsErrorFilePath;
	}

	/**
	 * Gets the validate com methd cd query.
	 *
	 * @return the validateComMethdCdQuery
	 */
	public String getValidateComMethdCdQuery() {
		return validateComMethdCdQuery;
	}

	/**
	 * Gets the validate typecodes query.
	 *
	 * @return the validateTypecodesQuery
	 */
	public String getValidateTypecodesQuery() {
		return validateTypecodesQuery;
	}

	/**
	 * Sets the validate typecodes query.
	 *
	 * @param validateTypecodesQuery the validateTypecodesQuery to set
	 */
	public void setValidateTypecodesQuery(String validateTypecodesQuery) {
		this.validateTypecodesQuery = validateTypecodesQuery;
	}

	/**
	 * Sets the validate com methd cd query.
	 *
	 * @param validateComMethdCdQuery the validateComMethdCdQuery to set
	 */
	public void setValidateComMethdCdQuery(String validateComMethdCdQuery) {
		this.validateComMethdCdQuery = validateComMethdCdQuery;
	}

	/**
	 * Gets the phon area code insert query.
	 *
	 * @return the phonAreaCodeInsertQuery
	 */
	public String getPhonAreaCodeInsertQuery() {
		return phonAreaCodeInsertQuery;
	}

	/**
	 * Sets the phon area code insert query.
	 *
	 * @param phonAreaCodeInsertQuery the phonAreaCodeInsertQuery to set
	 */
	public void setPhonAreaCodeInsertQuery(String phonAreaCodeInsertQuery) {
		this.phonAreaCodeInsertQuery = phonAreaCodeInsertQuery;
	}

	/**
	 * Gets the cntrl wrds load output file path.
	 *
	 * @return the cntrlWrdsLoadOutputFilePath
	 */
	public String getCntrlWrdsLoadOutputFilePath() {
		return cntrlWrdsLoadOutputFilePath;
	}

	/**
	 * Sets the cntrl wrds load output file path.
	 *
	 * @param cntrlWrdsLoadOutputFilePath the cntrlWrdsLoadOutputFilePath to set
	 */
	public void setCntrlWrdsLoadOutputFilePath(String cntrlWrdsLoadOutputFilePath) {
		this.cntrlWrdsLoadOutputFilePath = cntrlWrdsLoadOutputFilePath;
	}

	/**
	 * Gets the cntrl wrds load error file path.
	 *
	 * @return the cntrlWrdsLoadErrorFilePath
	 */
	public String getCntrlWrdsLoadErrorFilePath() {
		return cntrlWrdsLoadErrorFilePath;
	}

	/**
	 * Sets the cntrl wrds load error file path.
	 *
	 * @param cntrlWrdsLoadErrorFilePath the cntrlWrdsLoadErrorFilePath to set
	 */
	public void setCntrlWrdsLoadErrorFilePath(String cntrlWrdsLoadErrorFilePath) {
		this.cntrlWrdsLoadErrorFilePath = cntrlWrdsLoadErrorFilePath;
	}

	/**
	 * Gets the infer txt seq query.
	 *
	 * @return the inferTxtSeqQuery
	 */
	public String getInferTxtSeqQuery() {
		return inferTxtSeqQuery;
	}

	/**
	 * Sets the infer txt seq query.
	 *
	 * @param inferTxtSeqQuery the inferTxtSeqQuery to set
	 */
	public void setInferTxtSeqQuery(String inferTxtSeqQuery) {
		this.inferTxtSeqQuery = inferTxtSeqQuery;
	}

	/**
	 * Gets the infer txt insert query.
	 *
	 * @return the inferTxtInsertQuery
	 */
	public String getInferTxtInsertQuery() {
		return inferTxtInsertQuery;
	}

	/**
	 * Sets the infer txt insert query.
	 *
	 * @param inferTxtInsertQuery the inferTxtInsertQuery to set
	 */
	public void setInferTxtInsertQuery(String inferTxtInsertQuery) {
		this.inferTxtInsertQuery = inferTxtInsertQuery;
	}

	/**
	 * Gets the inft txt cntry appy insert query.
	 *
	 * @return the inftTxtCntryAppyInsertQuery
	 */
	public String getInftTxtCntryAppyInsertQuery() {
		return inftTxtCntryAppyInsertQuery;
	}

	/**
	 * Sets the inft txt cntry appy insert query.
	 *
	 * @param inftTxtCntryAppyInsertQuery the inftTxtCntryAppyInsertQuery to set
	 */
	public void setInftTxtCntryAppyInsertQuery(String inftTxtCntryAppyInsertQuery) {
		this.inftTxtCntryAppyInsertQuery = inftTxtCntryAppyInsertQuery;
	}

	/**
	 * Gets the inds cd infer insert query.
	 *
	 * @return the indsCdInferInsertQuery
	 */
	public String getIndsCdInferInsertQuery() {
		return indsCdInferInsertQuery;
	}

	/**
	 * Sets the inds cd infer insert query.
	 *
	 * @param indsCdInferInsertQuery the indsCdInferInsertQuery to set
	 */
	public void setIndsCdInferInsertQuery(String indsCdInferInsertQuery) {
		this.indsCdInferInsertQuery = indsCdInferInsertQuery;
	}

	/**
	 * Gets the lgl form insert query.
	 *
	 * @return the lglFormInsertQuery
	 */
	public String getLglFormInsertQuery() {
		return lglFormInsertQuery;
	}

	/**
	 * Sets the lgl form insert query.
	 *
	 * @param lglFormInsertQuery the lglFormInsertQuery to set
	 */
	public void setLglFormInsertQuery(String lglFormInsertQuery) {
		this.lglFormInsertQuery = lglFormInsertQuery;
	}

	/**
	 * Gets the phon area code seq query.
	 *
	 * @return the phonAreaCodeSeqQuery
	 */
	public String getPhonAreaCodeSeqQuery() {
		return phonAreaCodeSeqQuery;
	}

	/**
	 * Sets the phon area code seq query.
	 *
	 * @param phonAreaCodeSeqQuery the phonAreaCodeSeqQuery to set
	 */
	public void setPhonAreaCodeSeqQuery(String phonAreaCodeSeqQuery) {
		this.phonAreaCodeSeqQuery = phonAreaCodeSeqQuery;
	}

	/**
	 * Gets the dnb unusable glsy seq query.
	 *
	 * @return the dnbUnusableGlsySeqQuery
	 */
	public String getDnbUnusableGlsySeqQuery() {
		return dnbUnusableGlsySeqQuery;
	}

	/**
	 * Sets the dnb unusable glsy seq query.
	 *
	 * @param dnbUnusableGlsySeqQuery the dnbUnusableGlsySeqQuery to set
	 */
	public void setDnbUnusableGlsySeqQuery(String dnbUnusableGlsySeqQuery) {
		this.dnbUnusableGlsySeqQuery = dnbUnusableGlsySeqQuery;
	}

	/**
	 * Gets the dnb unusable glsy insert query.
	 *
	 * @return the dnbUnusableGlsyInsertQuery
	 */
	public String getDnbUnusableGlsyInsertQuery() {
		return dnbUnusableGlsyInsertQuery;
	}

	/**
	 * Sets the dnb unusable glsy insert query.
	 *
	 * @param dnbUnusableGlsyInsertQuery the dnbUnusableGlsyInsertQuery to set
	 */
	public void setDnbUnusableGlsyInsertQuery(String dnbUnusableGlsyInsertQuery) {
		this.dnbUnusableGlsyInsertQuery = dnbUnusableGlsyInsertQuery;
	}

	/**
	 * Gets the dnb unusable glsy cnty appy insert query.
	 *
	 * @return the dnbUnusableGlsyCntyAppyInsertQuery
	 */
	public String getDnbUnusableGlsyCntyAppyInsertQuery() {
		return dnbUnusableGlsyCntyAppyInsertQuery;
	}

	/**
	 * Sets the dnb unusable glsy cnty appy insert query.
	 *
	 * @param dnbUnusableGlsyCntyAppyInsertQuery the dnbUnusableGlsyCntyAppyInsertQuery to set
	 */
	public void setDnbUnusableGlsyCntyAppyInsertQuery(
			String dnbUnusableGlsyCntyAppyInsertQuery) {
		this.dnbUnusableGlsyCntyAppyInsertQuery = dnbUnusableGlsyCntyAppyInsertQuery;
	}

	/**
	 * Gets the dnb unusable glsy ind nme insert query.
	 *
	 * @return the dnbUnusableGlsyIndNmeInsertQuery
	 */
	public String getDnbUnusableGlsyIndNmeInsertQuery() {
		return dnbUnusableGlsyIndNmeInsertQuery;
	}

	/**
	 * Sets the dnb unusable glsy ind nme insert query.
	 *
	 * @param dnbUnusableGlsyIndNmeInsertQuery the dnbUnusableGlsyIndNmeInsertQuery to set
	 */
	public void setDnbUnusableGlsyIndNmeInsertQuery(
			String dnbUnusableGlsyIndNmeInsertQuery) {
		this.dnbUnusableGlsyIndNmeInsertQuery = dnbUnusableGlsyIndNmeInsertQuery;
	}

	/**
	 * Gets the dnb unusable glsy addr insert query.
	 *
	 * @return the dnbUnusableGlsyAddrInsertQuery
	 */
	public String getDnbUnusableGlsyAddrInsertQuery() {
		return dnbUnusableGlsyAddrInsertQuery;
	}

	/**
	 * Sets the dnb unusable glsy addr insert query.
	 *
	 * @param dnbUnusableGlsyAddrInsertQuery the dnbUnusableGlsyAddrInsertQuery to set
	 */
	public void setDnbUnusableGlsyAddrInsertQuery(
			String dnbUnusableGlsyAddrInsertQuery) {
		this.dnbUnusableGlsyAddrInsertQuery = dnbUnusableGlsyAddrInsertQuery;
	}

	/**
	 * Gets the dnb unusable glsy telecom insert query.
	 *
	 * @return the dnbUnusableGlsyTelecomInsertQuery
	 */
	public String getDnbUnusableGlsyTelecomInsertQuery() {
		return dnbUnusableGlsyTelecomInsertQuery;
	}

	/**
	 * Sets the dnb unusable glsy telecom insert query.
	 *
	 * @param dnbUnusableGlsyTelecomInsertQuery the dnbUnusableGlsyTelecomInsertQuery to set
	 */
	public void setDnbUnusableGlsyTelecomInsertQuery(
			String dnbUnusableGlsyTelecomInsertQuery) {
		this.dnbUnusableGlsyTelecomInsertQuery = dnbUnusableGlsyTelecomInsertQuery;
	}
	
	/**
	 * Gets the validate lgl fm cls cd query.
	 *
	 * @return the validateLglFmClsCdQuery
	 */
	public String getValidateLglFmClsCdQuery() {
		return validateLglFmClsCdQuery;
	}

	/**
	 * Sets the validate lgl fm cls cd query.
	 *
	 * @param validateLglFmClsCdQuery the validateLglFmClsCdQuery to set
	 */
	public void setValidateLglFmClsCdQuery(String validateLglFmClsCdQuery) {
		this.validateLglFmClsCdQuery = validateLglFmClsCdQuery;
	}
	
	/**
	 * Sets the validate addr geo unit query.
	 *
	 * @param validateAddrGeoUnitQuery the new validate addr geo unit query
	 */
	public void setValidateAddrGeoUnitQuery(String validateAddrGeoUnitQuery) {
		this.validateAddrGeoUnitQuery = validateAddrGeoUnitQuery;
	}

	/**
	 * Gets the validate addr geo unit query.
	 *
	 * @return the validate addr geo unit query
	 */
	public String getValidateAddrGeoUnitQuery() {
		return validateAddrGeoUnitQuery;
	}

	/**
	 * Gets the dnb unusable glsy delete query.
	 *
	 * @return the dnbUnusableGlsyDeleteQuery
	 */
	public String getDnbUnusableGlsyDeleteQuery() {
		return dnbUnusableGlsyDeleteQuery;
	}

	/**
	 * Sets the dnb unusable glsy delete query.
	 *
	 * @param dnbUnusableGlsyDeleteQuery the dnbUnusableGlsyDeleteQuery to set
	 */
	public void setDnbUnusableGlsyDeleteQuery(String dnbUnusableGlsyDeleteQuery) {
		this.dnbUnusableGlsyDeleteQuery = dnbUnusableGlsyDeleteQuery;
	}

	/**
	 * Gets the dnb unusable glsy cnty appy delete query.
	 *
	 * @return the dnbUnusableGlsyCntyAppyDeleteQuery
	 */
	public String getDnbUnusableGlsyCntyAppyDeleteQuery() {
		return dnbUnusableGlsyCntyAppyDeleteQuery;
	}

	/**
	 * Sets the dnb unusable glsy cnty appy delete query.
	 *
	 * @param dnbUnusableGlsyCntyAppyDeleteQuery the dnbUnusableGlsyCntyAppyDeleteQuery to set
	 */
	public void setDnbUnusableGlsyCntyAppyDeleteQuery(
			String dnbUnusableGlsyCntyAppyDeleteQuery) {
		this.dnbUnusableGlsyCntyAppyDeleteQuery = dnbUnusableGlsyCntyAppyDeleteQuery;
	}

	/**
	 * Gets the dnb unusable glsy cnty appy delete id query.
	 *
	 * @return the dnbUnusableGlsyCntyAppyDeleteIdQuery
	 */
	public String getDnbUnusableGlsyCntyAppyDeleteIdQuery() {
		return dnbUnusableGlsyCntyAppyDeleteIdQuery;
	}

	/**
	 * Sets the dnb unusable glsy cnty appy delete id query.
	 *
	 * @param dnbUnusableGlsyCntyAppyDeleteIdQuery the dnbUnusableGlsyCntyAppyDeleteIdQuery to set
	 */
	public void setDnbUnusableGlsyCntyAppyDeleteIdQuery(
			String dnbUnusableGlsyCntyAppyDeleteIdQuery) {
		this.dnbUnusableGlsyCntyAppyDeleteIdQuery = dnbUnusableGlsyCntyAppyDeleteIdQuery;
	}

	/**
	 * @return the infrTxtUpdateQuery
	 */
	public String getInfrTxtUpdateQuery() {
		return infrTxtUpdateQuery;
	}

	/**
	 * @param infrTxtUpdateQuery the infrTxtUpdateQuery to set
	 */
	public void setInfrTxtUpdateQuery(String infrTxtUpdateQuery) {
		this.infrTxtUpdateQuery = infrTxtUpdateQuery;
	}

	/**
	 * @return the indsCdInfrDeleteQuery
	 */
	public String getIndsCdInfrDeleteQuery() {
		return indsCdInfrDeleteQuery;
	}

	/**
	 * @param indsCdInfrDeleteQuery the indsCdInfrDeleteQuery to set
	 */
	public void setIndsCdInfrDeleteQuery(String indsCdInfrDeleteQuery) {
		this.indsCdInfrDeleteQuery = indsCdInfrDeleteQuery;
	}

	/**
	 * @return the infrTxtCntyAppyDeleteQuery
	 */
	public String getInfrTxtCntyAppyDeleteQuery() {
		return infrTxtCntyAppyDeleteQuery;
	}

	/**
	 * @param infrTxtCntyAppyDeleteQuery the infrTxtCntyAppyDeleteQuery to set
	 */
	public void setInfrTxtCntyAppyDeleteQuery(String infrTxtCntyAppyDeleteQuery) {
		this.infrTxtCntyAppyDeleteQuery = infrTxtCntyAppyDeleteQuery;
	}

	/**
	 * @return the infrTxtDeleteQuery
	 */
	public String getInfrTxtDeleteQuery() {
		return infrTxtDeleteQuery;
	}

	/**
	 * @param infrTxtDeleteQuery the infrTxtDeleteQuery to set
	 */
	public void setInfrTxtDeleteQuery(String infrTxtDeleteQuery) {
		this.infrTxtDeleteQuery = infrTxtDeleteQuery;
	}

	/**
	 * @return the lglInfrDeleteQuery
	 */
	public String getLglInfrDeleteQuery() {
		return lglInfrDeleteQuery;
	}

	/**
	 * @param lglInfrDeleteQuery the lglInfrDeleteQuery to set
	 */
	public void setLglInfrDeleteQuery(String lglInfrDeleteQuery) {
		this.lglInfrDeleteQuery = lglInfrDeleteQuery;
	}

	/**
	 * @return the infrTxtCntyAppyDeleteSoftQuery
	 */
	public String getInfrTxtCntyAppyDeleteSoftQuery() {
		return infrTxtCntyAppyDeleteSoftQuery;
	}

	/**
	 * @param infrTxtCntyAppyDeleteSoftQuery the infrTxtCntyAppyDeleteSoftQuery to set
	 */
	public void setInfrTxtCntyAppyDeleteSoftQuery(
			String infrTxtCntyAppyDeleteSoftQuery) {
		this.infrTxtCntyAppyDeleteSoftQuery = infrTxtCntyAppyDeleteSoftQuery;
	}

	/**
	 * @return the infrTxtDeleteSoftQuery
	 */
	public String getInfrTxtDeleteSoftQuery() {
		return infrTxtDeleteSoftQuery;
	}

	/**
	 * @param infrTxtDeleteSoftQuery the infrTxtDeleteSoftQuery to set
	 */
	public void setInfrTxtDeleteSoftQuery(String infrTxtDeleteSoftQuery) {
		this.infrTxtDeleteSoftQuery = infrTxtDeleteSoftQuery;
	}

	/**
	 * @return the indsCdInfrUpdateQuery
	 */
	public String getIndsCdInfrUpdateQuery() {
		return indsCdInfrUpdateQuery;
	}

	/**
	 * @param indsCdInfrUpdateQuery the indsCdInfrUpdateQuery to set
	 */
	public void setIndsCdInfrUpdateQuery(String indsCdInfrUpdateQuery) {
		this.indsCdInfrUpdateQuery = indsCdInfrUpdateQuery;
	}

	/**
	 * @return the infrTxtCntyAppyIdDeleteQuery
	 */
	public String getInfrTxtCntyAppyIdDeleteQuery() {
		return infrTxtCntyAppyIdDeleteQuery;
	}

	/**
	 * @param infrTxtCntyAppyIdDeleteQuery the infrTxtCntyAppyIdDeleteQuery to set
	 */
	public void setInfrTxtCntyAppyIdDeleteQuery(String infrTxtCntyAppyIdDeleteQuery) {
		this.infrTxtCntyAppyIdDeleteQuery = infrTxtCntyAppyIdDeleteQuery;
	}

	/**
	 * @return the infrTxtCntyAppyIdDeleteSoftQuery
	 */
	public String getInfrTxtCntyAppyIdDeleteSoftQuery() {
		return infrTxtCntyAppyIdDeleteSoftQuery;
	}

	/**
	 * @param infrTxtCntyAppyIdDeleteSoftQuery the infrTxtCntyAppyIdDeleteSoftQuery to set
	 */
	public void setInfrTxtCntyAppyIdDeleteSoftQuery(
			String infrTxtCntyAppyIdDeleteSoftQuery) {
		this.infrTxtCntyAppyIdDeleteSoftQuery = infrTxtCntyAppyIdDeleteSoftQuery;
	}
	
	
	
	
}
