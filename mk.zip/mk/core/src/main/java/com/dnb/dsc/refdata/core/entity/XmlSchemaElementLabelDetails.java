/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2011, Dun & Bradstreet. All rights reserved.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * This class used as an entity class for the XML Schema Element Label Details
 * Table. The class will have a direct mapping toe DB table xml_scma_ele_lbl_dtl
 * 
 * @author Cognizant
 * @version last updated : Apr 19, 2012
 * @see
 * 
 */
@Entity
@Table(name = "XML_SCMA_ELE_LBL_DTL")
@NamedQueries({
        @NamedQuery(name = "XmlSchemaElementLabelDetails.removeByXmlSchemaElementId", query ="DELETE FROM XmlSchemaElementLabelDetails xse where xse.xmlSchemaElementId = :xmlSchemaElementId"),
        @NamedQuery(name = "XmlSchemaElementLabelDetails.removeByXmlSchemaElementLabelDetailsId", query ="DELETE FROM XmlSchemaElementLabelDetails xse where xse.xmlSchemaElementLabelDetailsId = :xmlSchemaElementLabelDetailsId")
        })
public class XmlSchemaElementLabelDetails extends Audit implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -5397582780463082087L;

	@Id
    @Column(name = "XML_SCMA_ELE_LBL_DTL_ID")
    private Long xmlSchemaElementLabelDetailsId;

    @Column(name = "XML_SCMA_ELE_ID")
    private String xmlSchemaElementId;

    @Column(name = "XML_SCMA_REC_TYP_CD")
    private Long xmlSchemaRecordTypeCd;

    @Column(name = "LANG_CD")
    private Long languageCd;

    @Column(name = "WRIT_SCRP_CD")
    private Long writeScrpCd;

    @Column(name = "DATA_ELE_LBL_NME")
    private String dataElementLabelName;

    @Column(name = "DATA_ELE_LBL_DESC")
    private String dataElementLabelDescription;

    @Transient
    private String changeIndicator;
    /**
     * 
     */
    public XmlSchemaElementLabelDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param xmlSchemaElementLabelDetailsId
     * @param xmlSchemaElementId
     * @param xmlSchemaRecordTypeCd
     * @param languageCd
     * @param writeScrpCd
     * @param dataElementLabelName
     * @param dataElementLabelDescription
     * @param rowCreationId
     * @param rowCreationTimeStamp
     * @param rowModificationId
     * @param rowModificationTimeStamp
     */
    public XmlSchemaElementLabelDetails(Long xmlSchemaElementLabelDetailsId, String xmlSchemaElementId,
            Long xmlSchemaRecordTypeCd, Long languageCd, Long writeScrpCd, String dataElementLabelName,
            String dataElementLabelDescription, String rowCreationId, Date rowCreationTimeStamp,
            String rowModificationId, Date rowModificationTimeStamp) {
		super(rowCreationId, rowCreationTimeStamp, rowModificationId, rowModificationTimeStamp);
        this.xmlSchemaElementLabelDetailsId = xmlSchemaElementLabelDetailsId;
        this.xmlSchemaElementId = xmlSchemaElementId;
        this.xmlSchemaRecordTypeCd = xmlSchemaRecordTypeCd;
        this.languageCd = languageCd;
        this.writeScrpCd = writeScrpCd;
        this.dataElementLabelName = dataElementLabelName;
        this.dataElementLabelDescription = dataElementLabelDescription;
    }

    /**
     * @return the xmlSchemaElementLabelDetailsId
     */
    public Long getXmlSchemaElementLabelDetailsId() {
        return xmlSchemaElementLabelDetailsId;
    }

    /**
     * @param xmlSchemaElementLabelDetailsId
     *            the xmlSchemaElementLabelDetailsId to set
     */
    public void setXmlSchemaElementLabelDetailsId(Long xmlSchemaElementLabelDetailsId) {
        this.xmlSchemaElementLabelDetailsId = xmlSchemaElementLabelDetailsId;
    }

    /**
     * @return the xmlSchemaElementId
     */
    public String getXmlSchemaElementId() {
        return xmlSchemaElementId;
    }

    /**
     * @param xmlSchemaElementId
     *            the xmlSchemaElementId to set
     */
    public void setXmlSchemaElementId(String xmlSchemaElementId) {
        this.xmlSchemaElementId = xmlSchemaElementId;
    }

    /**
     * @return the xmlSchemaRecordTypeCd
     */
    public Long getXmlSchemaRecordTypeCd() {
        return xmlSchemaRecordTypeCd;
    }

    /**
     * @param xmlSchemaRecordTypeCd
     *            the xmlSchemaRecordTypeCd to set
     */
    public void setXmlSchemaRecordTypeCd(Long xmlSchemaRecordTypeCd) {
        this.xmlSchemaRecordTypeCd = xmlSchemaRecordTypeCd;
    }

    /**
     * @return the languageCd
     */
    public Long getLanguageCd() {
        return languageCd;
    }

    /**
	 * @return the changeIndicator
	 */
	public String getChangeIndicator() {
		return changeIndicator;
	}

	/**
	 * @param changeIndicator the changeIndicator to set
	 */
	public void setChangeIndicator(String changeIndicator) {
		this.changeIndicator = changeIndicator;
	}

	/**
     * @param languageCd
     *            the languageCd to set
     */
    public void setLanguageCd(Long languageCd) {
        this.languageCd = languageCd;
    }

    /**
     * @return the writeScrpCd
     */
    public Long getWriteScrpCd() {
        return writeScrpCd;
    }

    /**
     * @param writeScrpCd
     *            the writeScrpCd to set
     */
    public void setWriteScrpCd(Long writeScrpCd) {
        this.writeScrpCd = writeScrpCd;
    }

    /**
     * @return the dataElementLabelName
     */
    public String getDataElementLabelName() {
        return dataElementLabelName;
    }

    /**
     * @param dataElementLabelName
     *            the dataElementLabelName to set
     */
    public void setDataElementLabelName(String dataElementLabelName) {
        this.dataElementLabelName = dataElementLabelName;
    }

    /**
     * @return the dataElementLabelDescription
     */
    public String getDataElementLabelDescription() {
        return dataElementLabelDescription;
    }

    /**
     * @param dataElementLabelDescription
     *            the dataElementLabelDescription to set
     */
    public void setDataElementLabelDescription(String dataElementLabelDescription) {
        this.dataElementLabelDescription = dataElementLabelDescription;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "XmlSchemaElementLabelDetails [xmlSchemaElementLabelDetailsId="
				+ xmlSchemaElementLabelDetailsId + ", xmlSchemaElementId="
				+ xmlSchemaElementId + ", xmlSchemaRecordTypeCd="
				+ xmlSchemaRecordTypeCd + ", languageCd=" + languageCd
				+ ", writeScrpCd=" + writeScrpCd + ", dataElementLabelName="
				+ dataElementLabelName + ", dataElementLabelDescription="
				+ dataElementLabelDescription + ", changeIndicator="
				+ changeIndicator + "]";
	}
}
