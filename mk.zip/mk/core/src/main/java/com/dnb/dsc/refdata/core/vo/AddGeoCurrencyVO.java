/**
 * 
 */
package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
import com.dnb.dsc.refdata.core.entity.Audit;

/**
 * @author 302801
 *
 */
public class AddGeoCurrencyVO extends Audit implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long geoCrcyId;
	private Long geoCrcyCountry;
	private Long currencyCode;	
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;
	
	
	public AddGeoCurrencyVO(){
		
	}
	
	/**
	 * @return the geoCrcyCountry
	 */
	public Long getGeoCrcyCountry() {
		return geoCrcyCountry;
	}
	/**
	 * @param geoCrcyCountry the geoCrcyCountry to set
	 */
	public void setGeoCrcyCountry(Long geoCrcyCountry) {
		this.geoCrcyCountry = geoCrcyCountry;
	}
	/**
	 * @return the currencyCode
	 */
	public Long getCurrencyCode() {
		return currencyCode;
	}
	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(Long currencyCode) {
		this.currencyCode = currencyCode;
	}
	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	/**
	 * @return the geoCrcyId
	 */
	public Long getGeoCrcyId() {
		return geoCrcyId;
	}
	/**
	 * @param geoCrcyId the geoCrcyId to set
	 */
	public void setGeoCrcyId(Long geoCrcyId) {
		this.geoCrcyId = geoCrcyId;
	}
	
	@Override
	public String toString() {
		return "AddGeoCurrencyVO [geoCrcyId=" + geoCrcyId + ", geoCrcyCountry="
				+ geoCrcyCountry + ", currencyCode=" + currencyCode
				+ ", effectiveDate=" + effectiveDate + "]";
	}

}
