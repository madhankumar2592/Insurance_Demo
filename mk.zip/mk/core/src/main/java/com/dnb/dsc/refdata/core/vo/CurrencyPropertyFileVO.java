package com.dnb.dsc.refdata.core.vo;

public class CurrencyPropertyFileVO {

	private String cdvalQuery;
	private String insertQuery;
	private String updateQuery;
	private String selectQuery;
	private String selectUniqueQuery;
	private String outputFilePath;
	private String errorFilePath;
	private String loadOutputFilePath;
	private String loadErrorFilePath;

	public CurrencyPropertyFileVO(String cdvalQuery, String insertQuery,
			String updateQuery,String selectQuery,String selectUniqueQuery, String outputFilePath, String errorFilePath,String loadOutputFilePath, String loadErrorFilePath) {

		this.cdvalQuery = cdvalQuery;
		this.insertQuery = insertQuery;
		this.updateQuery = updateQuery;
		this.selectQuery = selectQuery;
		this.selectUniqueQuery = selectUniqueQuery;
		this.outputFilePath = outputFilePath;
		this.errorFilePath = errorFilePath;
		this.loadOutputFilePath = loadOutputFilePath;
		this.loadErrorFilePath = loadErrorFilePath;
	}

	public String getCdvalQuery() {
		return cdvalQuery;
	}

	public void setCdvalQuery(String cdvalQuery) {
		this.cdvalQuery = cdvalQuery;
	}

	public String getInsertQuery() {
		return insertQuery;
	}

	public void setInsertQuery(String insertQuery) {
		this.insertQuery = insertQuery;
	}

	public String getUpdateQuery() {
		return updateQuery;
	}

	public void setUpdateQuery(String updateQuery) {
		this.updateQuery = updateQuery;
	}
	
	/**
	 * @return the selectQuery
	 */
	public String getSelectQuery() {
		return selectQuery;
	}

	/**
	 * @param selectQuery the selectQuery to set
	 */
	public void setSelectQuery(String selectQuery) {
		this.selectQuery = selectQuery;
	}
	

	/**
	 * @return the selectUniqueQuery
	 */
	public String getSelectUniqueQuery() {
		return selectUniqueQuery;
	}

	/**
	 * @param selectUniqueQuery the selectUniqueQuery to set
	 */
	public void setSelectUniqueQuery(String selectUniqueQuery) {
		this.selectUniqueQuery = selectUniqueQuery;
	}

	public String getOutputFilePath() {
		return outputFilePath;
	}

	public void setOutputFilePath(String outputFilePath) {
		this.outputFilePath = outputFilePath;
	}

	public String getErrorFilePath() {
		return errorFilePath;
	}

	public void setErrorFilePath(String errorFilePath) {
		this.errorFilePath = errorFilePath;
	}

	/**
	 * @return the loadOutputFilePath
	 */
	public String getLoadOutputFilePath() {
		return loadOutputFilePath;
	}

	/**
	 * @param loadOutputFilePath the loadOutputFilePath to set
	 */
	public void setLoadOutputFilePath(String loadOutputFilePath) {
		this.loadOutputFilePath = loadOutputFilePath;
	}

	/**
	 * @return the loadErrorFilePath
	 */
	public String getLoadErrorFilePath() {
		return loadErrorFilePath;
	}

	/**
	 * @param loadErrorFilePath the loadErrorFilePath to set
	 */
	public void setLoadErrorFilePath(String loadErrorFilePath) {
		this.loadErrorFilePath = loadErrorFilePath;
	}

	

}
