
/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "SCR_GRU")
@NamedQueries({
		@NamedQuery(name = "GranularityType.retrieveCrossWalksForIndsCodeTypeCode", query = "SELECT distinct new IndustryCode(i2.industryCodeTypeCode, (SELECT cvt.codeValueDescription from CodeValueText cvt where cvt.languageCode = :enLangCode and cvt.codeValueId = i2.industryCodeTypeCode)) FROM IndustryCodeMap m, IndustryCode i1, IndustryCode i2 where m.industryCodeMapPK.fromIndustryCodeId = i1.industryCodeId and m.industryCodeMapPK.toIndustryCodeId = i2.industryCodeId and i1.industryCodeTypeCode = :indsCodeTypeCode"),
		@NamedQuery(name = "GranularityType.retrieveIndustryCodeByIndustryCodeId", query = "SELECT g FROM IndustryCode g where g.industryCodeId = :industryCodeId")
		})
public class GranularityType extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "SCR_GRU_ID")
	private Long granularityTypeId;
	
	@Column(name = "SCR_GRU_CD")
	private Long granularityTypeCode;
	
	@Column(name = "INAC_INDC")
	private Long inactiveIndicator;
	
	@OneToMany(mappedBy = "granularityTypeId", cascade = CascadeType.ALL)
	private List<ScoreGranularityAssociation> ScoreGranularityAssociation;
	
	/**
	 * @return the scoreGranularityAssociation
	 */
	public List<ScoreGranularityAssociation> getScoreGranularityAssociation() {
		return ScoreGranularityAssociation;
	}


	/**
	 * @param scoreGranularityAssociation the scoreGranularityAssociation to set
	 */
	public void setScoreGranularityAssociation(
			List<ScoreGranularityAssociation> scoreGranularityAssociation) {
		ScoreGranularityAssociation = scoreGranularityAssociation;
	}


	/**
	 * @return the inactiveIndicator
	 */
	public Long getInactiveIndicator() {
		return inactiveIndicator;
	}


	/**
	 * @param inactiveIndicator the inactiveIndicator to set
	 */
	public void setInactiveIndicator(Long inactiveIndicator) {
		this.inactiveIndicator = inactiveIndicator;
	}

		/**
	 * Empty Constructor.
	 */
	public GranularityType() {
		super();
	}

	
	/**
	 * @return the granularityTypeId
	 */
	public Long getGranularityTypeId() {
		return granularityTypeId;
	}


	/**
	 * @param granularityTypeId the granularityTypeId to set
	 */
	public void setGranularityTypeId(Long granularityTypeId) {
		this.granularityTypeId = granularityTypeId;
	}


	/**
	 * @return the granularityTypeCode
	 */
	public Long getGranularityTypeCode() {
		return granularityTypeCode;
	}


	/**
	 * @param granularityTypeCode the granularityTypeCode to set
	 */
	public void setGranularityTypeCode(Long granularityTypeCode) {
		this.granularityTypeCode = granularityTypeCode;
	}




	

	/**
	 * 
	 * @param granularityTypeId
	 * @param granularityTypeCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 */
	public GranularityType(Long granularityTypeId, Long granularityTypeCode,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.granularityTypeId = granularityTypeId;
		this.granularityTypeCode = granularityTypeCode;
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "granularityTypeId [granularityTypeId=" +granularityTypeId
				+ ", granularityTypeCode=" + granularityTypeCode + 
				 "]";
	}
	
	
}
