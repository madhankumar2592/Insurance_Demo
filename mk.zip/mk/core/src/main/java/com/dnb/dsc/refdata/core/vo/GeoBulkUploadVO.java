package com.dnb.dsc.refdata.core.vo;

import org.springframework.web.multipart.MultipartFile;

public class GeoBulkUploadVO {

	
	private String fileType;
	private MultipartFile file;
	private String countryName;
	
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}	
}
