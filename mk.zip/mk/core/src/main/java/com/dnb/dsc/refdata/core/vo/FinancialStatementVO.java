/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.FinancialStatementTemplate;

public class FinancialStatementVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long financialStatementTemplateId;
	private Long financialStatementTypeCode;
	private String financialStatementTypeDescription;
	private List<CodeValueText> financialTemplateList;
	private Map<Long, FinancialStatementTemplate> financialStatementTemplateList;
	private String finlTemplateModelAttribute;
	private String modifiedUser;
	private Date modifiedDate;
	private Date effectiveDate;
	private Boolean isLocked;
	
	public FinancialStatementVO(){

	}
	
	public FinancialStatementVO(Long financialStatementTypeCode, 
			String financialStatementTypeDescription){
		this.financialStatementTypeCode = financialStatementTypeCode;
		this.financialStatementTypeDescription = financialStatementTypeDescription;
	}

	/**
	 * @return the financialStatementTemplateId
	 */
	public Long getFinancialStatementTemplateId() {
		return financialStatementTemplateId;
	}

	/**
	 * @param financialStatementTemplateId the financialStatementTemplateId to set
	 */
	public void setFinancialStatementTemplateId(Long financialStatementTemplateId) {
		this.financialStatementTemplateId = financialStatementTemplateId;
	}

	/**
	 * @return the financialStatementTypeCode
	 */
	public Long getFinancialStatementTypeCode() {
		return financialStatementTypeCode;
	}

	/**
	 * @param financialStatementTypeCode the financialStatementTypeCode to set
	 */
	public void setFinancialStatementTypeCode(Long financialStatementTypeCode) {
		this.financialStatementTypeCode = financialStatementTypeCode;
	}

	/**
	 * @return the financialStatementTypeDescription
	 */
	public String getFinancialStatementTypeDescription() {
		return financialStatementTypeDescription;
	}

	/**
	 * @param financialStatementTypeDescription the financialStatementTypeDescription to set
	 */
	public void setFinancialStatementTypeDescription(
			String financialStatementTypeDescription) {
		this.financialStatementTypeDescription = financialStatementTypeDescription;
	}

	/**
	 * @return financialStatementTemplateList
	 */
	public Map<Long, FinancialStatementTemplate> getFinancialStatementTemplateList() {
		return financialStatementTemplateList;
	}

	/**
	 * @param financialStatementTemplateList
	 */
	public void setFinancialStatementTemplateList(
			Map<Long, FinancialStatementTemplate> financialStatementTemplateList) {
		this.financialStatementTemplateList = financialStatementTemplateList;
	}

	/**
	 * @return the financialTemplateList
	 */
	public List<CodeValueText> getFinancialTemplateList() {
		return financialTemplateList;
	}

	/**
	 * @param financialTemplateList the financialTemplateList to set
	 */
	public void setFinancialTemplateList(List<CodeValueText> financialTemplateList) {
		this.financialTemplateList = financialTemplateList;
	}
	
	/**
	 * @return the finlTemplateModelAttribute
	 */
	public String getFinlTemplateModelAttribute() {
		return finlTemplateModelAttribute;
	}

	/**
	 * @param finlTemplateModelAttribute the finlTemplateModelAttribute to set
	 */
	public void setFinlTemplateModelAttribute(String finlTemplateModelAttribute) {
		this.finlTemplateModelAttribute = finlTemplateModelAttribute;
	}

	/**
	 * @return the modifiedUser
	 */
	public String getModifiedUser() {
		return modifiedUser;
	}

	/**
	 * @param modifiedUser the modifiedUser to set
	 */
	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the isLocked
	 */
	public Boolean getIsLocked() {
		return isLocked;
	}

	/**
	 * @param isLocked the isLocked to set
	 */
	public void setIsLocked(Boolean isLocked) {
		this.isLocked = isLocked;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FinancialStatementVO [financialStatementTemplateId="
				+ financialStatementTemplateId
				+ ", financialStatementTypeCode=" + financialStatementTypeCode
				+ ", financialStatementTypeDescription="
				+ financialStatementTypeDescription
				+ ", financialTemplateList=" + financialTemplateList
				+ ", financialStatementTemplateList="
				+ financialStatementTemplateList
				+ ", finlTemplateModelAttribute=" + finlTemplateModelAttribute
				+ ", modifiedUser=" + modifiedUser + ", modifiedDate="
				+ modifiedDate + ", effectiveDate=" + effectiveDate
				+ ", isLocked=" + isLocked + "]";
	}
}
