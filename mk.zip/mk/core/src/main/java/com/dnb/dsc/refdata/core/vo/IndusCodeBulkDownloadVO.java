/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

/**
 * This class used as an value object class.
 * 
 * @author Cognizant
 * @version last updated : May 22, 2012
 * @see
 * 
 */
public class IndusCodeBulkDownloadVO {
	
	private Long uiBlkDwnldId;
	private Long industryCodeTypeCode;
	private String[] languageCodeList;
	private String[] descLengthCodeList;
	private String indusCodeDownLoadFileName;	
	private Long fromLanguageCode;
	private Long fromDescLengthCode;
	private Long toLanguageCode;
	private Long toDescLengthCode;
	private Long fromIndusCodeTypeCode;
	private Long toIndusCodeTypeCode;
	private String fileType;
	/**
	 * @return the uiBlkDwnldId
	 */
	public Long getUiBlkDwnldId() {
		return uiBlkDwnldId;
	}
	/**
	 * @param uiBlkDwnldId the uiBlkDwnldId to set
	 */
	public void setUiBlkDwnldId(Long uiBlkDwnldId) {
		this.uiBlkDwnldId = uiBlkDwnldId;
	}
	/**
	 * @return the industryCodeTypeCode
	 */
	public Long getIndustryCodeTypeCode() {
		return industryCodeTypeCode;
	}
	/**
	 * @param industryCodeTypeCode the industryCodeTypeCode to set
	 */
	public void setIndustryCodeTypeCode(Long industryCodeTypeCode) {
		this.industryCodeTypeCode = industryCodeTypeCode;
	}
	/**
	 * @return the languageCodeList
	 */
	public String[] getLanguageCodeList() {
		return languageCodeList;
	}
	/**
	 * @param languageCodeList the languageCodeList to set
	 */
	public void setLanguageCodeList(String[] languageCodeList) {
		this.languageCodeList = languageCodeList;
	}
	/**
	 * @return the descLengthCodeList
	 */
	public String[] getDescLengthCodeList() {
		return descLengthCodeList;
	}
	/**
	 * @param descLengthCodeList the descLengthCodeList to set
	 */
	public void setDescLengthCodeList(String[] descLengthCodeList) {
		this.descLengthCodeList = descLengthCodeList;
	}
	/**
	 * @return the indusCodeDownLoadFileName
	 */
	public String getIndusCodeDownLoadFileName() {
		return indusCodeDownLoadFileName;
	}
	/**
	 * @param indusCodeDownLoadFileName the indusCodeDownLoadFileName to set
	 */
	public void setIndusCodeDownLoadFileName(String indusCodeDownLoadFileName) {
		this.indusCodeDownLoadFileName = indusCodeDownLoadFileName;
	}
	/**
	 * @return the fromLanguageCode
	 */
	public Long getFromLanguageCode() {
		return fromLanguageCode;
	}
	/**
	 * @param fromLanguageCode the fromLanguageCode to set
	 */
	public void setFromLanguageCode(Long fromLanguageCode) {
		this.fromLanguageCode = fromLanguageCode;
	}
	/**
	 * @return the fromDescLengthCode
	 */
	public Long getFromDescLengthCode() {
		return fromDescLengthCode;
	}
	/**
	 * @param fromDescLengthCode the fromDescLengthCode to set
	 */
	public void setFromDescLengthCode(Long fromDescLengthCode) {
		this.fromDescLengthCode = fromDescLengthCode;
	}
	/**
	 * @return the toLanguageCode
	 */
	public Long getToLanguageCode() {
		return toLanguageCode;
	}
	/**
	 * @param toLanguageCode the toLanguageCode to set
	 */
	public void setToLanguageCode(Long toLanguageCode) {
		this.toLanguageCode = toLanguageCode;
	}
	/**
	 * @return the toDescLengthCode
	 */
	public Long getToDescLengthCode() {
		return toDescLengthCode;
	}
	/**
	 * @param toDescLengthCode the toDescLengthCode to set
	 */
	public void setToDescLengthCode(Long toDescLengthCode) {
		this.toDescLengthCode = toDescLengthCode;
	}
	/**
	 * @return the fromIndusCodeTypeCode
	 */
	public Long getFromIndusCodeTypeCode() {
		return fromIndusCodeTypeCode;
	}
	/**
	 * @param fromIndusCodeTypeCode the fromIndusCodeTypeCode to set
	 */
	public void setFromIndusCodeTypeCode(Long fromIndusCodeTypeCode) {
		this.fromIndusCodeTypeCode = fromIndusCodeTypeCode;
	}
	/**
	 * @return the toIndusCodeTypeCode
	 */
	public Long getToIndusCodeTypeCode() {
		return toIndusCodeTypeCode;
	}
	/**
	 * @param toIndusCodeTypeCode the toIndusCodeTypeCode to set
	 */
	public void setToIndusCodeTypeCode(Long toIndusCodeTypeCode) {
		this.toIndusCodeTypeCode = toIndusCodeTypeCode;
	}
	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}
}
