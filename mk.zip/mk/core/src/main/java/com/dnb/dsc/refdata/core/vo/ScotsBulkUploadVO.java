package com.dnb.dsc.refdata.core.vo;

import org.springframework.web.multipart.MultipartFile;

public class ScotsBulkUploadVO {
	
	private MultipartFile file;
	

	
	public ScotsBulkUploadVO(){
		
	}
	
	/**
	 * @param file the file to set
	 */
	public void setFile(MultipartFile file) {
		this.file = file;
	}

	/**
	 * @return the file
	 */
	public MultipartFile getFile() {
		return file;
	}
	

}
