/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *	Entity for finl_stmt_sche table
 *
 * @author Cognizant
 * @version last updated : June 14, 2012
 * @see
 *
 */
@Entity
@Table(name = "finl_stmt_sche")
@NamedQueries({
	@NamedQuery(name = "FinancialStatementSchedule.removeFinancialStatementScheduleById", query = "DELETE FinancialStatementSchedule s where s.financialStatementTemplateId = :financialStatementTemplateId")
})
public class FinancialStatementSchedule extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "FINL_STMT_SCHE_ID")
	private Long financialStatementScheduleId;

	@Column(name = "FINL_STMT_TMPLT_ID")
	private Long financialStatementTemplateId;
	
	@Column(name = "FINL_STMT_SCHE_CD")
	private Long financialStatementScheduleCode;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "financialStatementScheduleId")
	private List<FinancialStatementTemplateLineItem> financialStatementTemplateLineItemList;
	
	@Transient
	private String scheduleCodeDescription;
	
	@Transient
	private Long statementTypeCode;
	
	@Transient
	private String statementTypeDescription;
	
	public FinancialStatementSchedule(){

	}
	
	/**
	 * @return the financialStatementTemplateId
	 */
	public Long getFinancialStatementTemplateId() {
		return financialStatementTemplateId;
	}

	/**
	 * @param financialStatementTemplateId the financialStatementTemplateId to set
	 */
	public void setFinancialStatementTemplateId(Long financialStatementTemplateId) {
		this.financialStatementTemplateId = financialStatementTemplateId;
	}

	/**
	 * @return the financialStatementScheduleId
	 */
	public Long getFinancialStatementScheduleId() {
		return financialStatementScheduleId;
	}

	/**
	 * @param financialStatementScheduleId the financialStatementScheduleId to set
	 */
	public void setFinancialStatementScheduleId(Long financialStatementScheduleId) {
		this.financialStatementScheduleId = financialStatementScheduleId;
	}

	/**
	 * @return the financialStatementScheduleCode
	 */
	public Long getFinancialStatementScheduleCode() {
		return financialStatementScheduleCode;
	}

	/**
	 * @param financialStatementScheduleCode the financialStatementScheduleCode to set
	 */
	public void setFinancialStatementScheduleCode(
			Long financialStatementScheduleCode) {
		this.financialStatementScheduleCode = financialStatementScheduleCode;
	}

	/**
	 * @return the financialStatementTemplateLineItemList
	 */
	public List<FinancialStatementTemplateLineItem> getFinancialStatementTemplateLineItemList() {
		return financialStatementTemplateLineItemList;
	}

	/**
	 * @param financialStatementTemplateLineItemList the financialStatementTemplateLineItemList to set
	 */
	public void setFinancialStatementTemplateLineItemList(
			List<FinancialStatementTemplateLineItem> financialStatementTemplateLineItemList) {
		this.financialStatementTemplateLineItemList = financialStatementTemplateLineItemList;
	}

	/**
	 * @return the scheduleCodeDescription
	 */
	public String getScheduleCodeDescription() {
		return scheduleCodeDescription;
	}

	/**
	 * @param scheduleCodeDescription the scheduleCodeDescription to set
	 */
	public void setScheduleCodeDescription(String scheduleCodeDescription) {
		this.scheduleCodeDescription = scheduleCodeDescription;
	}

	/**
	 * @return the statementTypeCode
	 */
	public Long getStatementTypeCode() {
		return statementTypeCode;
	}

	/**
	 * @param statementTypeCode the statementTypeCode to set
	 */
	public void setStatementTypeCode(Long statementTypeCode) {
		this.statementTypeCode = statementTypeCode;
	}

	/**
	 * @return the statementTypeDescription
	 */
	public String getStatementTypeDescription() {
		return statementTypeDescription;
	}

	/**
	 * @param statementTypeDescription the statementTypeDescription to set
	 */
	public void setStatementTypeDescription(String statementTypeDescription) {
		this.statementTypeDescription = statementTypeDescription;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FinancialStatementSchedule [financialStatementScheduleId="
				+ financialStatementScheduleId
				+ ", financialStatementTemplateId="
				+ financialStatementTemplateId
				+ ", financialStatementScheduleCode="
				+ financialStatementScheduleCode
				+ ", financialStatementTemplateLineItemList="
				+ financialStatementTemplateLineItemList
				+ ", scheduleCodeDescription=" + scheduleCodeDescription + "]";
	}

}
