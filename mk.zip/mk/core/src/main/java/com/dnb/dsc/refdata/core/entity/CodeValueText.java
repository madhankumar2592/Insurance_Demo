/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the Code Value Text. The class  
 * will have a direct mapping toe DB table cd_tbl_txt.
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2012
 * @see
 * 
 */
@Entity
@Table(name = "CD_VAL_TXT")
@NamedQueries({
	@NamedQuery(name = "CodeValueText.retrieveCodeValueTextByCodeValueId", query = "SELECT cvt from CodeValueText cvt where cvt.codeValueId = :codeValueId and cvt.languageCode = :languageCode and cvt.writingScriptCode = :writingScriptCode and cvt.expirationDate is null"),
    @NamedQuery(name = "CodeValueText.retrieveLanguages", query = "SELECT new CodeValueText(t.codeValueId, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT DISTINCT new CodeValueText(t1.languageCode) FROM CodeValueText t1) AND t.languageCode = 39 and t.expirationDate is null "),
	@NamedQuery(name = "CodeValueText.retrieveAllControlWords", query = "SELECT DISTINCT new CodeValueText(t1.codeValueId, t1.codeValueDescription) FROM CodeValueText t1, DnbUnusGlsy t2 WHERE t1.codeValueId = t2.dnbUnusGlsyTypCd AND t1.languageCode = :languageCode and t1.expirationDate is null"),
	@NamedQuery(name = "CodeValueText.retrieveFinancialTemplates", query = "select DISTINCT new CodeValueText(cvt.codeValueId,cvt.codeValueDescription) from CodeValueText cvt, CodeValue cv,SystemApplicability sa where cv.codeTableId = :codeTableId and sa.codeValueId = cv.codeValueId and sa.dnbSystemCode = 24291 and cvt.codeValueId = cv.codeValueId and sa.applicabilityIndicator = 0 and cvt.languageCode = :languageCode and cvt.expirationDate is null and sa.expirationDate is null ORDER BY cvt.codeValueId "),
	@NamedQuery(name = "CodeValueText.retrieveSchedulesForStatementType", query = "select DISTINCT new CodeValueText(cvt.codeValueId,cvt.codeValueDescription) from CodeValueText cvt, CodeValue cv,SystemApplicability sa where cv.codeTableId = :codeTableId and cv.codeValueId in (select childCodeValueId from CodeValueAssociation where parentCodeValueId = :statementType) and sa.codeValueId = cv.codeValueId and sa.dnbSystemCode = 24291 and cvt.codeValueId = cv.codeValueId and sa.applicabilityIndicator = 0 and cvt.languageCode = :languageCode and cvt.expirationDate is null and sa.expirationDate is null ORDER BY cvt.codeValueId "),
	@NamedQuery(name = "CodeValueText.retrieveLineItemsForScheduleType", query = "select DISTINCT new CodeValueText(cvt.codeValueId,cvt.codeValueDescription) from CodeValueText cvt, CodeValue cv,SystemApplicability sa where cv.codeTableId = :codeTableId and cv.codeValueId in (select childCodeValueId from CodeValueAssociation where parentCodeValueId = :scheduleType) and sa.codeValueId = cv.codeValueId and sa.dnbSystemCode = 24291 and cvt.codeValueId = cv.codeValueId and sa.applicabilityIndicator = 0 and cvt.languageCode = :languageCode and cvt.expirationDate is null and sa.expirationDate is null ORDER BY cvt.codeValueId "),
	@NamedQuery(name = "CodeValueText.retrieveDescForId", query = "select DISTINCT new CodeValueText(cvt.codeValueId,cvt.codeValueDescription) from CodeValueText cvt where cvt.codeValueId in (:codeValueIdList) and cvt.languageCode = :languageCode and cvt.writingScriptCode = :writingScriptCode and cvt.expirationDate is null"),
	@NamedQuery(name = "CodeValueText.retrieveStatementForSchedules", query = "select DISTINCT new CodeValueText(cvt.codeValueId,cvt.codeValueDescription, cva.childCodeValueId) from CodeValueText cvt, CodeValue cv,SystemApplicability sa, CodeValueAssociation cva where cv.codeTableId = :codeTableId and cv.codeValueId = cva.parentCodeValueId and cva.childCodeValueId in (:scheduleCodeList) and sa.codeValueId = cv.codeValueId and sa.dnbSystemCode = 24291 and cvt.codeValueId = cv.codeValueId and sa.applicabilityIndicator = 0 and cvt.languageCode = :languageCode  ORDER BY cvt.codeValueId "),
	@NamedQuery(name = "CodeValueText.removeTextByCodeValueId", query = "DELETE CodeValueText cvt WHERE cvt.codeValueId = :codeValueId ")
})
public class CodeValueText extends Audit {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "CD_VAL_TXT_ID")
	private Long codeValueTextId;
	
	@Column(name = "CD_VAL_ID")
	private Long codeValueId;

	@Column(name = "LANG_CD")
	private Long languageCode;

	@Column(name = "WRIT_SCRP_CD")
	private Long writingScriptCode;
	
	@Column(name = "CD_VAL_SHRT_DESC")
	private String codeValueShortDescription;
	
	@Column(name = "CD_VAL_DESC")
	private String codeValueDescription;
	
	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;

	@Column(name = "PROD_LITR_DESC")
	private String productLiteralDescription;
	
	@Column(name = "PROD_LITR_SHRT_DESC")
	private String productLiteralShortDescription;
	
	@Column(name = "PROD_LITR_MASC_DESC")
	private String literalMasculineDescription;
	
	@Column(name = "PROD_LITR_MASC_SHRT_DESC")
	private String literalMasculineShortDescription;
	
	@Column(name = "PROD_LITR_FEM_DESC")
	private String literalFeminineDescription;
	
	@Column(name = "PROD_LITR_FEM_SHRT_DESC")
	private String literalFeminineShortDescription;

	@Transient
	private Long childCodeValueId;
	
	@Transient
	private Long codeTableId;
	
	@Transient
	private String codeTableName;
	
	@Transient
	private String languageCodeDescription;
	
	@Transient
	private String writingScriptCodeDescription;
	
	@Transient
	private String errorCode;
	
	@Transient
	private String cdValIdBulk;
	
	@Transient
	private String changeIndicator;


	/**
	 * Constructor
	 */
	public CodeValueText() {
		super();
	}
	
	/**
	 * @param codeValueId
	 * @param languageCode
	 * @param writingScripCode
	 * @param codeValueShortDescription
	 * @param codeValueDescription
	 * @param prefferedProductDescription
	 * @param createdDate
	 * @param modifiedDate
	 * @param modifiedUser
	 */
	public CodeValueText(Long codeValueId, Long languageCode,
			Long writingScriptCode, String codeValueShortDescription,
			String codeValueDescription, String prefferedProductDescription,
			String createdUser, Date createdDate, Date modifiedDate, String modifiedUser) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.codeValueId = codeValueId;
		this.languageCode = languageCode;
		this.writingScriptCode = writingScriptCode;
		this.codeValueShortDescription = codeValueShortDescription;
		this.codeValueDescription = codeValueDescription;

	}
	
	/**
	 * @param codeValueId
	 * @param codeValueDescription 
	 */
	public CodeValueText(Long codeValueId, String codeValueDescription) {
		this.codeValueId = codeValueId;
		this.codeValueDescription = codeValueDescription;
	}

	public CodeValueText(Long codeValueId, String codeValueDescription, Long childCodeValueId) {
		this.codeValueId = codeValueId;
		this.codeValueDescription = codeValueDescription;
		this.childCodeValueId = childCodeValueId;
	}
	//CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription)
	public CodeValueText(Long codeValueId, String codeValueShortDescription, String  codeValueDescription){
		super();
		this.codeValueId = codeValueId;
		this.codeValueShortDescription = codeValueShortDescription;
		this.codeValueDescription = codeValueDescription;

	}

	/**
	 * @param languageCode
	 */
	public CodeValueText(Long languageCode) {
		this.languageCode = languageCode;
	}

	/**
	 * @return the codeValueId
	 */
	public Long getCodeValueId() {
		return codeValueId;
	}

	/**
	 * @param codeValueId the codeValueId to set
	 */
	public void setCodeValueId(Long codeValueId) {
		this.codeValueId = codeValueId;
	}

	/**
	 * @return the languageCode
	 */
	public Long getLanguageCode() {
		return languageCode;
	}

	/**
	 * @param languageCode the languageCode to set
	 */
	public void setLanguageCode(Long languageCode) {
		this.languageCode = languageCode;
	}

	/**
	 * @return the writingScriptCode
	 */
	public Long getWritingScriptCode() {
		return writingScriptCode;
	}

	/**
	 * @param writingScriptCode the writingScriptCode to set
	 */
	public void setWritingScriptCode(Long writingScriptCode) {
		this.writingScriptCode = writingScriptCode;
	}

	/**
	 * @return the codeValueShortDescription
	 */
	public String getCodeValueShortDescription() {
		return codeValueShortDescription;
	}

	/**
	 * @param codeValueShortDescription the codeValueShortDescription to set
	 */
	public void setCodeValueShortDescription(String codeValueShortDescription) {
		this.codeValueShortDescription = codeValueShortDescription;
	}

	/**
	 * @return the codeValueDescription
	 */
	public String getCodeValueDescription() {
		return codeValueDescription;
	}

	/**
	 * @param codeValueDescription the codeValueDescription to set
	 */
	public void setCodeValueDescription(String codeValueDescription) {
		this.codeValueDescription = codeValueDescription;
	}

	/**
	 * @return the codeValueTextId
	 */
	public Long getCodeValueTextId() {
		return codeValueTextId;
	}

	/**
	 * @param codeValueTextId the codeValueTextId to set
	 */
	public void setCodeValueTextId(Long codeValueTextId) {
		this.codeValueTextId = codeValueTextId;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the productLiteralDescription
	 */
	public String getProductLiteralDescription() {
		return productLiteralDescription;
	}

	/**
	 * @param productLiteralDescription the productLiteralDescription to set
	 */
	public void setProductLiteralDescription(String productLiteralDescription) {
		this.productLiteralDescription = productLiteralDescription;
	}

	/**
	 * @return the productLiteralShortDescription
	 */
	public String getProductLiteralShortDescription() {
		return productLiteralShortDescription;
	}

	/**
	 * @param productLiteralShortDescription the productLiteralShortDescription to set
	 */
	public void setProductLiteralShortDescription(
			String productLiteralShortDescription) {
		this.productLiteralShortDescription = productLiteralShortDescription;
	}
	
	/**
	 * @return the literalMasculineDescription
	 */
	public String getLiteralMasculineDescription() {
		return literalMasculineDescription;
	}

	/**
	 * @param literalMasculineDescription the literalMasculineDescription to set
	 */
	public void setLiteralMasculineDescription(String literalMasculineDescription) {
		this.literalMasculineDescription = literalMasculineDescription;
	}

	/**
	 * @return the literalMasculineShortDescription
	 */
	public String getLiteralMasculineShortDescription() {
		return literalMasculineShortDescription;
	}

	/**
	 * @param literalMasculineShortDescription the literalMasculineShortDescription to set
	 */
	public void setLiteralMasculineShortDescription(
			String literalMasculineShortDescription) {
		this.literalMasculineShortDescription = literalMasculineShortDescription;
	}

	/**
	 * @return the literalFeminineDescription
	 */
	public String getLiteralFeminineDescription() {
		return literalFeminineDescription;
	}

	/**
	 * @param literalFeminineDescription the literalFeminineDescription to set
	 */
	public void setLiteralFeminineDescription(String literalFeminineDescription) {
		this.literalFeminineDescription = literalFeminineDescription;
	}

	/**
	 * @return the literalFeminineShortDescription
	 */
	public String getLiteralFeminineShortDescription() {
		return literalFeminineShortDescription;
	}

	/**
	 * @param literalFeminineShortDescription the literalFeminineShortDescription to set
	 */
	public void setLiteralFeminineShortDescription(
			String literalFeminineShortDescription) {
		this.literalFeminineShortDescription = literalFeminineShortDescription;
	}

	/**
	 * @return the childCodeValueId
	 */
	public Long getChildCodeValueId() {
		return childCodeValueId;
	}

	/**
	 * @param childCodeValueId the childCodeValueId to set
	 */
	public void setChildCodeValueId(Long childCodeValueId) {
		this.childCodeValueId = childCodeValueId;
	}
	
		/**
	 * @param codeTableId the codeTableId to set
	 */
	public void setCodeTableId(Long codeTableId) {
		this.codeTableId = codeTableId;
	}

	/**
	 * @return the codeTableId
	 */
	public Long getCodeTableId() {
		return codeTableId;
	}

	/**
	 * @param codeTableName the codeTableName to set
	 */
	public void setCodeTableName(String codeTableName) {
		this.codeTableName = codeTableName;
	}

	/**
	 * @return the codeTableName
	 */
	public String getCodeTableName() {
		return codeTableName;
	}

	/**
	 * @param languageCodeDescription the languageCodeDescription to set
	 */
	public void setLanguageCodeDescription(String languageCodeDescription) {
		this.languageCodeDescription = languageCodeDescription;
	}

	/**
	 * @return the languageCodeDescription
	 */
	public String getLanguageCodeDescription() {
		return languageCodeDescription;
	}

	/**
	 * @param writingScriptCodeDescription the writingScriptCodeDescription to set
	 */
	public void setWritingScriptCodeDescription(
			String writingScriptCodeDescription) {
		this.writingScriptCodeDescription = writingScriptCodeDescription;
	}

	/**
	 * @return the writingScriptCodeDescription
	 */
	public String getWritingScriptCodeDescription() {
		return writingScriptCodeDescription;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @return the cdValIdBulk
	 */
	public String getCdValIdBulk() {
		return cdValIdBulk;
	}

	/**
	 * @param cdValIdBulk the cdValIdBulk to set
	 */
	public void setCdValIdBulk(String cdValIdBulk) {
		this.cdValIdBulk = cdValIdBulk;
	}

	/**
	 * @return the changeIndicator
	 */
	public String getChangeIndicator() {
		return changeIndicator;
	}

	/**
	 * @param changeIndicator the changeIndicator to set
	 */
	public void setChangeIndicator(String changeIndicator) {
		this.changeIndicator = changeIndicator;
	}

	
	@Override
	public String toString() {
		return "CodeValueText [codeValueTextId=" + codeValueTextId
				+ ", codeValueId=" + codeValueId + ", languageCode="
				+ languageCode + ", writingScriptCode=" + writingScriptCode
				+ ", codeValueShortDescription=" + codeValueShortDescription
				+ ", codeValueDescription=" + codeValueDescription
				+ ", effectiveDate=" + effectiveDate + ", expirationDate="
				+ expirationDate + ", productLiteralDescription="
				+ productLiteralDescription
				+ ", productLiteralShortDescription="
				+ productLiteralShortDescription
				+ ", literalMasculineDescription="
				+ literalMasculineDescription
				+ ", literalMasculineShortDescription="
				+ literalMasculineShortDescription
				+ ", literalFeminineDescription=" + literalFeminineDescription
				+ ", literalFeminineShortDescription="
				+ literalFeminineShortDescription + ", childCodeValueId="
				+ childCodeValueId + "]";
	}
}
