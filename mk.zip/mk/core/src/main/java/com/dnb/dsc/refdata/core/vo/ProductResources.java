package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.Audit;

public class ProductResources extends Audit implements Serializable {
	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -9103188765091982027L;
	
	
	private Long rescId;
	
	
	public Long getRescId() {
		return rescId;
	}

	public void setRescId(Long rescId) {
		this.rescId = rescId;
	}

	/**
	 * resourceCode.
	 */
	private Long resourceCode;
	/**
	 * resourceType.
	 */
	private String resourceType;
	/**
	 * billingSysCode.
	 */
	private String billingSysCode;
	/**
	 * billingSysType.
	 */
	private Long billingSysType;
	/**
	 * resourceMetadataCode.
	 *//*
	private Long resourceMetadataCode;
	*//**
	 * resourceMetadataValue.
	 *//*
	private String resourceMetadataValue;
	*/
	/**
	 * resourceMetadata
	 */
	private List<ResourceMetadataVO> resourceMetadata;
	
	
	
	/*private List<ResourceMetaDtaVO> resourceMetaDta;
	
	
	public List<ResourceMetaDtaVO> getResourceMetaDta() {
		return resourceMetaDta;
	}

	public void setResourceMetaDta(List<ResourceMetaDtaVO> resourceMetaDta) {
		this.resourceMetaDta = resourceMetaDta;
	}*/

	public List<ResourceMetadataVO> getResourceMetadata() {
		return resourceMetadata;
	}

	public void setResourceMetadata(List<ResourceMetadataVO> resourceMetadata) {
		this.resourceMetadata = resourceMetadata;
	}

	/**
	 * resourceGroupCode.
	 */
	private Long resourceGroupCode;
	/**
	 * resourceVersion.
	 */
	private Long resourceVersion;

	
	/**
	 * @return the resourceCode
	 */
	public Long getResourceCode() {
		return resourceCode;
	}

	/**
	 * @param resourceCode
	 *            the resourceCode to set
	 */
	public void setResourceCode(Long resourceCode) {
		this.resourceCode = resourceCode;
	}

	/**
	 * @return the resourceType
	 */
	public String getResourceType() {
		return resourceType;
	}

	/**
	 * @param resourceType
	 *            the resourceType to set
	 */
	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	/**
	 * @return the billingSysCode
	 */
	public String getBillingSysCode() {
		return billingSysCode;
	}

	/**
	 * @param billingSysCode
	 *            the billingSysCode to set
	 */
	public void setBillingSysCode(String billingSysCode) {
		this.billingSysCode = billingSysCode;
	}

	/**
	 * @return the billingSysType
	 */
	public Long getBillingSysType() {
		return billingSysType;
	}

	/**
	 * @param billingSysType
	 *            the billingSysType to set
	 */
	public void setBillingSysType(Long billingSysType) {
		this.billingSysType = billingSysType;
	}

	
	
/*	*//**
	 * @return the resourceMetadataCode
	 *//*
	public Long getResourceMetadataCode() {
		return resourceMetadataCode;
	}

	*//**
	 * @param resourceMetadataCode
	 *            the resourceMetadataCode to set
	 *//*
	public void setResourceMetadataCode(Long resourceMetadataCode) {
		this.resourceMetadataCode = resourceMetadataCode;
	}

	*//**
	 * @return the resourceMetadataValue
	 *//*
	public String getResourceMetadataValue() {
		return resourceMetadataValue;
	}

	*//**
	 * @param resourceMetadataValue
	 *            the resourceMetadataValue to set
	 *//*
	public void setResourceMetadataValue(String resourceMetadataValue) {
		this.resourceMetadataValue = resourceMetadataValue;
	}*/
	/**
	 * @return resourceMetadata
	 */

	/**
	 * @return the resourceGroupCode
	 */
	public Long getResourceGroupCode() {
		return resourceGroupCode;
	}

	/**
	 * @param resourceGroupCode
	 *            the resourceGroupCode to set
	 */
	public void setResourceGroupCode(Long resourceGroupCode) {
		this.resourceGroupCode = resourceGroupCode;
	}

	/**
	 * @return the resourceVersion
	 */
	public Long getResourceVersion() {
		return resourceVersion;
	}

	/**
	 * @param resourceVersion
	 *            the resourceVersion to set
	 */
	public void setResourceVersion(Long resourceVersion) {
		this.resourceVersion = resourceVersion;
	}

}
