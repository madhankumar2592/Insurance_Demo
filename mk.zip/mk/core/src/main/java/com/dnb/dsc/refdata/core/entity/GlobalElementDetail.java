package com.dnb.dsc.refdata.core.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "GLBL_ELE_DTL_RLS_2")
public class GlobalElementDetail extends Audit{
	
	private static final long serialVersionUID = 2L;
	
	@Id
	@Column(name = "GLBL_ELE_DTL_ID")
	private Long globalElementDetailId;

	@Column(name = "GLBL_ELE_ID")
	private Long globalElementId;

	@Column(name = "GLBL_ELE_MTDT_CD")
	private Long globalElementMetadataCode;

	@Column(name = "GLBL_ELE_MTDT_VAL")
	private String globalElementMetadataValue;
	
	@Column(name = "GLBL_ELE_MTDT_DATA_TYP_CD")
	private Long globalElementMetadataTypeCode;
	
	@Column(name = "GLBL_ELE_MTDT_LANG_CD")
	private Long globalElementMetadataLangCode;

	@Column(name = "GLBL_ELE_DTL_CMNT")
	private String globalElementDetailComment;
	
	
	/**
	 * The default constructor
	 */
	public GlobalElementDetail() {
		super();
	}
	
	
	public GlobalElementDetail(Long globalElementDetailId,Long globalElementId,Long globalElementMetadataCode,
			String globalElementMetadataValue,Long globalElementMetadataTypeCode,Long globalElementMetadataLangCode,String globalElementDetailComment){
		
		this.globalElementDetailId = globalElementDetailId;
		this.globalElementId = globalElementId;
		this.globalElementMetadataCode = globalElementMetadataCode;
		this.globalElementMetadataValue = globalElementMetadataValue;
		this.globalElementMetadataTypeCode = globalElementMetadataTypeCode;
		this.globalElementMetadataLangCode = globalElementMetadataLangCode;
		this.globalElementDetailComment = globalElementDetailComment;
	}
	
	/**
	 * @return the globalElementDetailId
	 */
	public Long getGlobalElementDetailId() {
		return globalElementDetailId;
	}

	/**
	 * @param globalElementDetailId the globalElementDetailId to set
	 */
	public void setGlobalElementDetailId(Long globalElementDetailId) {
		this.globalElementDetailId = globalElementDetailId;
	}

	

	/**
	 * @return the globalElementMetadataCode
	 */
	public Long getGlobalElementMetadataCode() {
		return globalElementMetadataCode;
	}

	/**
	 * @param globalElementMetadataCode the globalElementMetadataCode to set
	 */
	public void setGlobalElementMetadataCode(Long globalElementMetadataCode) {
		this.globalElementMetadataCode = globalElementMetadataCode;
	}

	/**
	 * @return the globalElementMetadataValue
	 */
	public String getGlobalElementMetadataValue() {
		return globalElementMetadataValue;
	}

	/**
	 * @param globalElementMetadataValue the globalElementMetadataValue to set
	 */
	public void setGlobalElementMetadataValue(String globalElementMetadataValue) {
		this.globalElementMetadataValue = globalElementMetadataValue;
	}

	/**
	 * @return the globalElementMetadataTypeCode
	 */
	public Long getGlobalElementMetadataTypeCode() {
		return globalElementMetadataTypeCode;
	}

	/**
	 * @param globalElementMetadataTypeCode the globalElementMetadataTypeCode to set
	 */
	public void setGlobalElementMetadataTypeCode(Long globalElementMetadataTypeCode) {
		this.globalElementMetadataTypeCode = globalElementMetadataTypeCode;
	}

	/**
	 * @return the globalElementMetadataLangCode
	 */
	public Long getGlobalElementMetadataLangCode() {
		return globalElementMetadataLangCode;
	}

	/**
	 * @param globalElementMetadataLangCode the globalElementMetadataLangCode to set
	 */
	public void setGlobalElementMetadataLangCode(Long globalElementMetadataLangCode) {
		this.globalElementMetadataLangCode = globalElementMetadataLangCode;
	}

	/**
	 * @param globalElementId the globalElementId to set
	 */
	public void setGlobalElementId(Long globalElementId) {
		this.globalElementId = globalElementId;
	}

	/**
	 * @return the globalElementId
	 */
	public Long getGlobalElementId() {
		return globalElementId;
	}

	/**
	 * @param globalElementDetailComment the globalElementDetailComment to set
	 */
	public void setGlobalElementDetailComment(String globalElementDetailComment) {
		this.globalElementDetailComment = globalElementDetailComment;
	}

	/**
	 * @return the globalElementDetailComment
	 */
	public String getGlobalElementDetailComment() {
		return globalElementDetailComment;
	}

	

	

}
