/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "PROD_DTL")
@NamedQueries({
	@NamedQuery(name = "ProductDetails.removeproductDtlById", query = "DELETE FROM ProductDetails c where c.productDtlId not in ( :productDtlId) and productID = :productID")

		})
public class ProductDetails extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PROD_DTL_ID")
	private Long productDtlId;
		
	@Column(name = "PROD_ID")
	private Long productID;
	
	@Column(name = "PROD_DTL_MTDT_CD")
	private Long productDtlMetDatCode;
	
	@Column(name = "PROD_DTL_MTDT_VAL")
	private String productDtlMetDatVal;
	
	
	public Long getProductDtlId() {
		return productDtlId;
	}

	public void setProductDtlId(Long productDtlId) {
		this.productDtlId = productDtlId;
	}

	public Long getProductID() {
		return productID;
	}

	public void setProductID(Long productID) {
		this.productID = productID;
	}

	public Long getProductDtlMetDatCode() {
		return productDtlMetDatCode;
	}

	public void setProductDtlMetDatCode(Long productDtlMetDatCode) {
		this.productDtlMetDatCode = productDtlMetDatCode;
	}

	public String getProductDtlMetDatVal() {
		return productDtlMetDatVal;
	}

	public void setProductDtlMetDatVal(String productDtlMetDatVal) {
		this.productDtlMetDatVal = productDtlMetDatVal;
	}

	/**
	 * Empty Constructor.
	 */
	public ProductDetails() {
		super();
	}
	
	public ProductDetails(Long productDtlId) {
		super();
		this.productDtlId = productDtlId;
	}
	/*public ProductDetails(Long ProductDetailsVersion) {
		super();
		this.ProductDetailsVersion = ProductDetailsVersion;
	}*/
	public ProductDetails(Long productDtlId, Long productID) {
		super();
		this.productDtlId = productDtlId;
		this.productID = productID;
	}
	
	
	/**
	 * 
	 * @param ProductDetailsId
	 * @param ProductDetailsVersion
	 * @param ProductDetailsTypeId
	 * @param ProductDetailsMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public ProductDetails(Long productDtlId, Long productID, Long productDtlMetDatCode, String productDtlMetDatVal,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.productDtlId = productDtlId;
		this.productID = productID;
		this.productDtlMetDatCode = productDtlMetDatCode;
		this.productDtlMetDatVal = productDtlMetDatVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ProductDetails [productDtlId=" + productDtlId
				+ ", productID=" + productID 
				+ ",productDtlMetDatCode=" + productDtlMetDatCode + 
				  ", productDtlMetDatVal=" + productDtlMetDatVal + 
				  "]";
	}
	
	
}
