package com.dnb.dsc.refdata.core.vo;

import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;

public class GeoBulkUploadMasterVO {
	private GeoUnit geoUnit;
	private GeoUnitName geoUnitNme;
	private GeoUnitCode geoUnitCode;
	/**
	 * @return the geoUnit
	 */
	public GeoUnit getGeoUnit() {
		return geoUnit;
	}
	/**
	 * @param geoUnit the geoUnit to set
	 */
	public void setGeoUnit(GeoUnit geoUnit) {
		this.geoUnit = geoUnit;
	}
	/**
	 * @return the geoUnitNme
	 */
	public GeoUnitName getGeoUnitNme() {
		return geoUnitNme;
	}
	/**
	 * @param geoUnitNme the geoUnitNme to set
	 */
	public void setGeoUnitNme(GeoUnitName geoUnitNme) {
		this.geoUnitNme = geoUnitNme;
	}
	/**
	 * @return the geoUnitCode
	 */
	public GeoUnitCode getGeoUnitCode() {
		return geoUnitCode;
	}
	/**
	 * @param geoUnitCode the geoUnitCode to set
	 */
	public void setGeoUnitCode(GeoUnitCode geoUnitCode) {
		this.geoUnitCode = geoUnitCode;
	}
	
	

}
