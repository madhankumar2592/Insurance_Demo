/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeDescription;
/**
 * This class used as an value object class.
 * 
 * @author Cognizant
 * @version last updated : Dec 09, 2011
 * @see
 * 
 */
public class IndusCodeDownLoadBatchVO {
	private IndustryCode indusCode;
	private IndustryCodeDescription indusCodeDesc;
	private CodeValueText cdValTxtLang;
	private CodeValueText cdValTxtWritngScrpt;
	private CodeValueText cdValTxtDescLeng;
	
	
	/**
	 * @return the cdValTxtLang
	 */
	public CodeValueText getCdValTxtLang() {
		return cdValTxtLang;
	}
	/**
	 * @param cdValTxtLang the cdValTxtLang to set
	 */
	public void setCdValTxtLang(CodeValueText cdValTxtLang) {
		this.cdValTxtLang = cdValTxtLang;
	}
	/**
	 * @return the cdValTxtWritngScrpt
	 */
	public CodeValueText getCdValTxtWritngScrpt() {
		return cdValTxtWritngScrpt;
	}
	/**
	 * @param cdValTxtWritngScrpt the cdValTxtWritngScrpt to set
	 */
	public void setCdValTxtWritngScrpt(CodeValueText cdValTxtWritngScrpt) {
		this.cdValTxtWritngScrpt = cdValTxtWritngScrpt;
	}
	/**
	 * @return the cdValTxtDescLeng
	 */
	public CodeValueText getCdValTxtDescLeng() {
		return cdValTxtDescLeng;
	}
	/**
	 * @param cdValTxtDescLeng the cdValTxtDescLeng to set
	 */
	public void setCdValTxtDescLeng(CodeValueText cdValTxtDescLeng) {
		this.cdValTxtDescLeng = cdValTxtDescLeng;
	}
	/**
	 * @return the indusCode
	 */
	public IndustryCode getIndusCode() {
		return indusCode;
	}
	/**
	 * @param indusCode the indusCode to set
	 */
	public void setIndusCode(IndustryCode indusCode) {
		this.indusCode = indusCode;
	}
	/**
	 * @return the indusCodeDesc
	 */
	public IndustryCodeDescription getIndusCodeDesc() {
		return indusCodeDesc;
	}
	/**
	 * @param indusCodeDesc the indusCodeDesc to set
	 */
	public void setIndusCodeDesc(IndustryCodeDescription indusCodeDesc) {
		this.indusCodeDesc = indusCodeDesc;
	}
	/**
	 * @return the cdValTxt
	 */
	
	

}
