package com.dnb.dsc.refdata.core.vo;

import java.util.List;

public class ProductScoreReportVO extends PaginationVO{
	
	private static final long serialVersionUID = 476805299168172044L;
	private String exportIndc;	
	private String mkt_cd;
	private String product_cd;
	private String resc_cd;	
	private String mkt_cd_scr;
	private String sr_typ_cd;	
	private String sr_gru_cd;
	private List<Long> productList;
	private List<Long> marketCodeList;
	private List<Long> resourceList;	
	private List<Long> marketCodeScrList;
	private List<Long> scrTypCdList;
	private List<Long> scrGruCdList;
	
	private Long prodAvailId;
	private Long saleChnlid;
	private Long prodMktId;
	private Long mktCd;
	private Long prodId;
	private Long prodFamCd;
	private Long prodCd;
	private Long prodInacIndc;
	private Long prodVers;
	private Long rescMapId;
	private Long rescId;
	private Long bilgSysCd;
	private Long rescVers;
	private Long rescCd;
	private Long rescTypCd;
	private Long bilgSysTypCd;
	private Long countryCode;
	private String countryDesc;
	private Long productCod;
	private String prodCodeShrtDesc;
	private String prodCodeDesc;
	private Long rescCode;
	private String rescCodeShrtDesc;
	private String rescCodeDesc;
	
	private Long prodGrpId;
	private Long prodGrpCd;
	private Long prodDtlId;
	private Long prodDtlMtdtCd;
	private String prodDtlMtdCdVal;
	private Long mktGrpId;
	private Long mktGrpCd;
	private Long rescGrpId;
	private Long rescGrpCd;
	private Long rescDtlID;
	private Long rescDtlMtdtCd;
	private String rescMtdtVal;
	private Long slsChnlDtlID;
	private Long slsChnlDtlMtdtCd;
	private String slsChnlDtlMtdtVal;
	private String prodGrpCdShrtDesc;
	private String prodGrpCdDesc;
	private String prodDtlMtdtCdShrtDesc;
	private String prodDtlMtdtCdDesc;
	private String mktGrpCdShrtDesc;
	private String mktGrpCdDesc;
	private String rescGrpCdShrtDesc;
	private String rescGrpCdDesc;
	private String rescDtlMtdtCdShrtDesc;
	private String rescDtlMtdtCdDesc;
	private String slsChnlDtlMtdtCdShrtDesc;
	private String slsChnlDtlMtdtCdDesc;
	
	private Long scr_mkt_cd_id;
	private String country_name;
	
	private Long scr_typ_cd_id;
	private String scr_typ_cd_shrt_d;
	private String scr_typ_cd_val_d;

	private Long scr_gru_cd_id;
	private String scr_gru_cd_shrt_d;
	private String scr_gru_cd_val_d;
	
	private Long scr_id;
	private Long scr_typ_assn_id;
	private Long scr_gru_id;
	private Long scr_typ_id;
	private Double scr_vers;
	private Long scoreTypeCode;
	private Long marketCodeScr;
	private Long scoreGranularity;
	private Long scr_dtl_id;
	private Long scrProdScrMapId;
	private Long prodProdScrMapId;

	public Long getProdProdScrMapId() {
		return prodProdScrMapId;
	}
	public void setProdProdScrMapId(Long prodProdScrMapId) {
		this.prodProdScrMapId = prodProdScrMapId;
	}
	public Long getScr_dtl_id() {
		return scr_dtl_id;
	}
	public void setScr_dtl_id(Long scr_dtl_id) {
		this.scr_dtl_id = scr_dtl_id;
	}
	public Long getScrProdScrMapId() {
		return scrProdScrMapId;
	}
	public void setScrProdScrMapId(Long scrProdScrMapId) {
		this.scrProdScrMapId = scrProdScrMapId;
	}
	public Long getScoreTypeCode() {
		return scoreTypeCode;
	}
	public void setScoreTypeCode(Long scoreTypeCode) {
		this.scoreTypeCode = scoreTypeCode;
	}
	public Long getMarketCodeScr() {
		return marketCodeScr;
	}
	public void setMarketCodeScr(Long marketCodeScr) {
		this.marketCodeScr = marketCodeScr;
	}
	public Long getScoreGranularity() {
		return scoreGranularity;
	}
	public void setScoreGranularity(Long scoreGranularity) {
		this.scoreGranularity = scoreGranularity;
	}
	public Long getScr_mkt_cd_id() {
		return scr_mkt_cd_id;
	}
	public void setScr_mkt_cd_id(Long scr_mkt_cd_id) {
		this.scr_mkt_cd_id = scr_mkt_cd_id;
	}
	public String getCountry_name() {
		return country_name;
	}
	public void setCountry_name(String country_name) {
		this.country_name = country_name;
	}
	public Long getScr_typ_cd_id() {
		return scr_typ_cd_id;
	}
	public void setScr_typ_cd_id(Long scr_typ_cd_id) {
		this.scr_typ_cd_id = scr_typ_cd_id;
	}
	public String getScr_typ_cd_shrt_d() {
		return scr_typ_cd_shrt_d;
	}
	public void setScr_typ_cd_shrt_d(String scr_typ_cd_shrt_d) {
		this.scr_typ_cd_shrt_d = scr_typ_cd_shrt_d;
	}
	public String getScr_typ_cd_val_d() {
		return scr_typ_cd_val_d;
	}
	public void setScr_typ_cd_val_d(String scr_typ_cd_val_d) {
		this.scr_typ_cd_val_d = scr_typ_cd_val_d;
	}
	public Long getScr_gru_cd_id() {
		return scr_gru_cd_id;
	}
	public void setScr_gru_cd_id(Long scr_gru_cd_id) {
		this.scr_gru_cd_id = scr_gru_cd_id;
	}
	public String getScr_gru_cd_shrt_d() {
		return scr_gru_cd_shrt_d;
	}
	public void setScr_gru_cd_shrt_d(String scr_gru_cd_shrt_d) {
		this.scr_gru_cd_shrt_d = scr_gru_cd_shrt_d;
	}
	public String getScr_gru_cd_val_d() {
		return scr_gru_cd_val_d;
	}
	public void setScr_gru_cd_val_d(String scr_gru_cd_val_d) {
		this.scr_gru_cd_val_d = scr_gru_cd_val_d;
	}
	public Long getScr_id() {
		return scr_id;
	}
	public void setScr_id(Long scr_id) {
		this.scr_id = scr_id;
	}
	public Long getScr_typ_assn_id() {
		return scr_typ_assn_id;
	}
	public void setScr_typ_assn_id(Long scr_typ_assn_id) {
		this.scr_typ_assn_id = scr_typ_assn_id;
	}
	public Long getScr_gru_id() {
		return scr_gru_id;
	}
	public void setScr_gru_id(Long scr_gru_id) {
		this.scr_gru_id = scr_gru_id;
	}
	public Long getScr_typ_id() {
		return scr_typ_id;
	}
	public void setScr_typ_id(Long scr_typ_id) {
		this.scr_typ_id = scr_typ_id;
	}
	public Double getScr_vers() {
		return scr_vers;
	}
	public void setScr_vers(Double scr_vers) {
		this.scr_vers = scr_vers;
	}
	public Long getProdAvailId() {
		return prodAvailId;
	}
	public void setProdAvailId(Long prodAvailId) {
		this.prodAvailId = prodAvailId;
	}
	public Long getSaleChnlid() {
		return saleChnlid;
	}
	public void setSaleChnlid(Long saleChnlid) {
		this.saleChnlid = saleChnlid;
	}
	public Long getProdMktId() {
		return prodMktId;
	}
	public void setProdMktId(Long prodMktId) {
		this.prodMktId = prodMktId;
	}
	public Long getMktCd() {
		return mktCd;
	}
	public void setMktCd(Long mktCd) {
		this.mktCd = mktCd;
	}
	public Long getProdId() {
		return prodId;
	}
	public void setProdId(Long prodId) {
		this.prodId = prodId;
	}
	public Long getProdFamCd() {
		return prodFamCd;
	}
	public void setProdFamCd(Long prodFamCd) {
		this.prodFamCd = prodFamCd;
	}
	public Long getProdCd() {
		return prodCd;
	}
	public void setProdCd(Long prodCd) {
		this.prodCd = prodCd;
	}
	public Long getProdInacIndc() {
		return prodInacIndc;
	}
	public void setProdInacIndc(Long prodInacIndc) {
		this.prodInacIndc = prodInacIndc;
	}
	public Long getProdVers() {
		return prodVers;
	}
	public void setProdVers(Long prodVers) {
		this.prodVers = prodVers;
	}
	public Long getRescMapId() {
		return rescMapId;
	}
	public void setRescMapId(Long rescMapId) {
		this.rescMapId = rescMapId;
	}
	public Long getRescId() {
		return rescId;
	}
	public void setRescId(Long rescId) {
		this.rescId = rescId;
	}
	public Long getBilgSysCd() {
		return bilgSysCd;
	}
	public void setBilgSysCd(Long bilgSysCd) {
		this.bilgSysCd = bilgSysCd;
	}
	public Long getRescVers() {
		return rescVers;
	}
	public void setRescVers(Long rescVers) {
		this.rescVers = rescVers;
	}
	public Long getRescCd() {
		return rescCd;
	}
	public void setRescCd(Long rescCd) {
		this.rescCd = rescCd;
	}
	public Long getRescTypCd() {
		return rescTypCd;
	}
	public void setRescTypCd(Long rescTypCd) {
		this.rescTypCd = rescTypCd;
	}
	public Long getBilgSysTypCd() {
		return bilgSysTypCd;
	}
	public void setBilgSysTypCd(Long bilgSysTypCd) {
		this.bilgSysTypCd = bilgSysTypCd;
	}
	public Long getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(Long countryCode) {
		this.countryCode = countryCode;
	}
	public String getCountryDesc() {
		return countryDesc;
	}
	public void setCountryDesc(String countryDesc) {
		this.countryDesc = countryDesc;
	}
	public Long getProductCod() {
		return productCod;
	}
	public void setProductCod(Long productCod) {
		this.productCod = productCod;
	}
	public String getProdCodeShrtDesc() {
		return prodCodeShrtDesc;
	}
	public void setProdCodeShrtDesc(String prodCodeShrtDesc) {
		this.prodCodeShrtDesc = prodCodeShrtDesc;
	}
	public String getProdCodeDesc() {
		return prodCodeDesc;
	}
	public void setProdCodeDesc(String prodCodeDesc) {
		this.prodCodeDesc = prodCodeDesc;
	}
	public Long getRescCode() {
		return rescCode;
	}
	public void setRescCode(Long rescCode) {
		this.rescCode = rescCode;
	}
	public String getRescCodeShrtDesc() {
		return rescCodeShrtDesc;
	}
	public void setRescCodeShrtDesc(String rescCodeShrtDesc) {
		this.rescCodeShrtDesc = rescCodeShrtDesc;
	}
	public String getRescCodeDesc() {
		return rescCodeDesc;
	}
	public void setRescCodeDesc(String rescCodeDesc) {
		this.rescCodeDesc = rescCodeDesc;
	}
	public Long getProdGrpId() {
		return prodGrpId;
	}
	public void setProdGrpId(Long prodGrpId) {
		this.prodGrpId = prodGrpId;
	}
	public Long getProdGrpCd() {
		return prodGrpCd;
	}
	public void setProdGrpCd(Long prodGrpCd) {
		this.prodGrpCd = prodGrpCd;
	}
	public Long getProdDtlId() {
		return prodDtlId;
	}
	public void setProdDtlId(Long prodDtlId) {
		this.prodDtlId = prodDtlId;
	}
	public Long getProdDtlMtdtCd() {
		return prodDtlMtdtCd;
	}
	public void setProdDtlMtdtCd(Long prodDtlMtdtCd) {
		this.prodDtlMtdtCd = prodDtlMtdtCd;
	}
	public String getProdDtlMtdCdVal() {
		return prodDtlMtdCdVal;
	}
	public void setProdDtlMtdCdVal(String prodDtlMtdCdVal) {
		this.prodDtlMtdCdVal = prodDtlMtdCdVal;
	}
	public Long getMktGrpId() {
		return mktGrpId;
	}
	public void setMktGrpId(Long mktGrpId) {
		this.mktGrpId = mktGrpId;
	}
	public Long getMktGrpCd() {
		return mktGrpCd;
	}
	public void setMktGrpCd(Long mktGrpCd) {
		this.mktGrpCd = mktGrpCd;
	}
	public Long getRescGrpId() {
		return rescGrpId;
	}
	public void setRescGrpId(Long rescGrpId) {
		this.rescGrpId = rescGrpId;
	}
	public Long getRescGrpCd() {
		return rescGrpCd;
	}
	public void setRescGrpCd(Long rescGrpCd) {
		this.rescGrpCd = rescGrpCd;
	}
	public Long getRescDtlID() {
		return rescDtlID;
	}
	public void setRescDtlID(Long rescDtlID) {
		this.rescDtlID = rescDtlID;
	}
	public Long getRescDtlMtdtCd() {
		return rescDtlMtdtCd;
	}
	public void setRescDtlMtdtCd(Long rescDtlMtdtCd) {
		this.rescDtlMtdtCd = rescDtlMtdtCd;
	}
	public String getRescMtdtVal() {
		return rescMtdtVal;
	}
	public void setRescMtdtVal(String rescMtdtVal) {
		this.rescMtdtVal = rescMtdtVal;
	}
	public Long getSlsChnlDtlID() {
		return slsChnlDtlID;
	}
	public void setSlsChnlDtlID(Long slsChnlDtlID) {
		this.slsChnlDtlID = slsChnlDtlID;
	}
	public Long getSlsChnlDtlMtdtCd() {
		return slsChnlDtlMtdtCd;
	}
	public void setSlsChnlDtlMtdtCd(Long slsChnlDtlMtdtCd) {
		this.slsChnlDtlMtdtCd = slsChnlDtlMtdtCd;
	}
	public String getSlsChnlDtlMtdtVal() {
		return slsChnlDtlMtdtVal;
	}
	public void setSlsChnlDtlMtdtVal(String slsChnlDtlMtdtVal) {
		this.slsChnlDtlMtdtVal = slsChnlDtlMtdtVal;
	}
	public String getProdGrpCdShrtDesc() {
		return prodGrpCdShrtDesc;
	}
	public void setProdGrpCdShrtDesc(String prodGrpCdShrtDesc) {
		this.prodGrpCdShrtDesc = prodGrpCdShrtDesc;
	}
	public String getProdGrpCdDesc() {
		return prodGrpCdDesc;
	}
	public void setProdGrpCdDesc(String prodGrpCdDesc) {
		this.prodGrpCdDesc = prodGrpCdDesc;
	}
	public String getProdDtlMtdtCdShrtDesc() {
		return prodDtlMtdtCdShrtDesc;
	}
	public void setProdDtlMtdtCdShrtDesc(String prodDtlMtdtCdShrtDesc) {
		this.prodDtlMtdtCdShrtDesc = prodDtlMtdtCdShrtDesc;
	}
	public String getProdDtlMtdtCdDesc() {
		return prodDtlMtdtCdDesc;
	}
	public void setProdDtlMtdtCdDesc(String prodDtlMtdtCdDesc) {
		this.prodDtlMtdtCdDesc = prodDtlMtdtCdDesc;
	}
	public String getMktGrpCdShrtDesc() {
		return mktGrpCdShrtDesc;
	}
	public void setMktGrpCdShrtDesc(String mktGrpCdShrtDesc) {
		this.mktGrpCdShrtDesc = mktGrpCdShrtDesc;
	}
	public String getMktGrpCdDesc() {
		return mktGrpCdDesc;
	}
	public void setMktGrpCdDesc(String mktGrpCdDesc) {
		this.mktGrpCdDesc = mktGrpCdDesc;
	}
	public String getRescGrpCdShrtDesc() {
		return rescGrpCdShrtDesc;
	}
	public void setRescGrpCdShrtDesc(String rescGrpCdShrtDesc) {
		this.rescGrpCdShrtDesc = rescGrpCdShrtDesc;
	}
	public String getRescGrpCdDesc() {
		return rescGrpCdDesc;
	}
	public void setRescGrpCdDesc(String rescGrpCdDesc) {
		this.rescGrpCdDesc = rescGrpCdDesc;
	}
	public String getRescDtlMtdtCdShrtDesc() {
		return rescDtlMtdtCdShrtDesc;
	}
	public void setRescDtlMtdtCdShrtDesc(String rescDtlMtdtCdShrtDesc) {
		this.rescDtlMtdtCdShrtDesc = rescDtlMtdtCdShrtDesc;
	}
	public String getRescDtlMtdtCdDesc() {
		return rescDtlMtdtCdDesc;
	}
	public void setRescDtlMtdtCdDesc(String rescDtlMtdtCdDesc) {
		this.rescDtlMtdtCdDesc = rescDtlMtdtCdDesc;
	}
	public String getSlsChnlDtlMtdtCdShrtDesc() {
		return slsChnlDtlMtdtCdShrtDesc;
	}
	public void setSlsChnlDtlMtdtCdShrtDesc(String slsChnlDtlMtdtCdShrtDesc) {
		this.slsChnlDtlMtdtCdShrtDesc = slsChnlDtlMtdtCdShrtDesc;
	}
	public String getSlsChnlDtlMtdtCdDesc() {
		return slsChnlDtlMtdtCdDesc;
	}
	public void setSlsChnlDtlMtdtCdDesc(String slsChnlDtlMtdtCdDesc) {
		this.slsChnlDtlMtdtCdDesc = slsChnlDtlMtdtCdDesc;
	}
	public String getExportIndc() {
		return exportIndc;
	}
	public void setExportIndc(String exportIndc) {
		this.exportIndc = exportIndc;
	}
	public String getMkt_cd() {
		return mkt_cd;
	}
	public void setMkt_cd(String mkt_cd) {
		this.mkt_cd = mkt_cd;
	}
	public String getProduct_cd() {
		return product_cd;
	}
	public void setProduct_cd(String product_cd) {
		this.product_cd = product_cd;
	}
	public String getResc_cd() {
		return resc_cd;
	}
	public void setResc_cd(String resc_cd) {
		this.resc_cd = resc_cd;
	}
	public List<Long> getProductList() {
		return productList;
	}
	public void setProductList(List<Long> productList) {
		this.productList = productList;
	}
	public List<Long> getMarketCodeList() {
		return marketCodeList;
	}
	public void setMarketCodeList(List<Long> marketCodeList) {
		this.marketCodeList = marketCodeList;
	}
	public List<Long> getResourceList() {
		return resourceList;
	}
	public void setResourceList(List<Long> resourceList) {
		this.resourceList = resourceList;
	}
	public List<Long> getMarketCodeScrList() {
		return marketCodeScrList;
	}
	public void setMarketCodeScrList(List<Long> marketCodeScrList) {
		this.marketCodeScrList = marketCodeScrList;
	}
	public List<Long> getScrTypCdList() {
		return scrTypCdList;
	}
	public void setScrTypCdList(List<Long> scrTypCdList) {
		this.scrTypCdList = scrTypCdList;
	}
	public List<Long> getScrGruCdList() {
		return scrGruCdList;
	}
	public void setScrGruCdList(List<Long> scrGruCdList) {
		this.scrGruCdList = scrGruCdList;
	}
	public String getMkt_cd_scr() {
		return mkt_cd_scr;
	}
	public void setMkt_cd_scr(String mkt_cd_scr) {
		this.mkt_cd_scr = mkt_cd_scr;
	}
	public String getSr_typ_cd() {
		return sr_typ_cd;
	}
	public void setSr_typ_cd(String sr_typ_cd) {
		this.sr_typ_cd = sr_typ_cd;
	}
	public String getSr_gru_cd() {
		return sr_gru_cd;
	}
	public void setSr_gru_cd(String sr_gru_cd) {
		this.sr_gru_cd = sr_gru_cd;
	}
	
}
