package com.dnb.dsc.refdata.core.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * @author 302801
 *
 */
@Entity
@Table(name = "GLBL_ELE_RLS_2")
@NamedQueries({
		@NamedQuery(name = "GlobalElement.retrieveUnmappedCount", query = "select to_char(createdDate, 'MONTH'),count(*) from GlobalElement where createdDate BETWEEN ADD_MONTHS(trunc(SYSDATE,'MONTH'), -6) AND LAST_DAY(TRUNC(SYSDATE, 'MONTH')) and globalElementId not in (select globalElementId from GloblalElementCrossWalk) GROUP BY to_char(createdDate, 'MONTH') ORDER BY to_char(createdDate, 'MONTH')")		
		})
public class GlobalElement extends Audit{	
	
	private static final long serialVersionUID = 2L;
	
	@Id
	@Column(name = "GLBL_ELE_ID")
	private Long globalElementId;
	
	@Column(name = "GLBL_ELE_BASE_SUB_TYP_ID")
	private Long globalElementBaseSubTypeId;

	@Column(name = "GLBL_ELE_TYP_CD")
	private Long globalElementTypeCode;

	@Column(name = "GLBL_ELE_TOPC_CATG_CD")
	private Long globalElementTopicCategoryCode;
	
	@Column(name = "GLBL_ELE_NME")
	private String globalElementName;	

	@Column(name = "GLBL_ELE_EFFV_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "GLBL_ELE_EXPN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;
	
	@Column(name = "GLBL_ELE_CMNT")
	private String globalElementComment;
	
	@OneToMany(mappedBy = "globalElementId", cascade = CascadeType.ALL)
	private List<GlobalElementDetail> globalElementDetail;
	
	@Transient
	private String topicCategoryDescription;
	
	@Transient
	private String globalElementMetadataCodeDescription;
	
	@Transient
	private String globalElementMetadataValue;
	
	@Transient
	private Long globalElementMetadataCode;
	
	@Transient
	private String globalElementDetailComment;
	
	@Transient
	private Long unMappedCount;
	
	@Transient
	private Long unMappedElementCount;
	
	@Transient
	private String month;
	
	
	
	public GlobalElement(Long globalElementId,Long globalElementTopicCategoryCode,
			String topicCategoryDescription,String globalElementName,Long globalElementMetadataCode,
			String globalElementMetadataCodeDescription,String globalElementMetadataValue,Date effectiveDate,Date expirationDate,String globalElementComment,String globalElementDetailComment){
		this.globalElementId = globalElementId;
		this.globalElementTopicCategoryCode = globalElementTopicCategoryCode;
		this.topicCategoryDescription = topicCategoryDescription;		
		this.globalElementName = globalElementName;	
		this.globalElementMetadataCode = globalElementMetadataCode;
		this.globalElementMetadataCodeDescription = globalElementMetadataCodeDescription;
		this.globalElementMetadataValue = globalElementMetadataValue;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
		this.globalElementComment = globalElementComment;
		this.globalElementDetailComment = globalElementDetailComment;
	}
	
	public GlobalElement(String globalElementName){
		this.globalElementName = globalElementName;
	}
	
	public GlobalElement(String month,Long unMappedElementCount){
		this.month = month;
		this.unMappedElementCount = unMappedElementCount;
	}
	
	
	public GlobalElement(Long globalElementId,Long globalElementTypeCode,Long globalElementTopicCategoryCode
			,String globalElementName,Date effectiveDate,Date expirationDate,String globalElementComment){
		
		this.globalElementId = globalElementId;
		this.globalElementTypeCode = globalElementTypeCode;
		this.globalElementTopicCategoryCode = globalElementTopicCategoryCode;
		this.globalElementName = globalElementName;	
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
		this.globalElementComment = globalElementComment;
		
	}

	/**
	 * @return the globalElementMetadataValue
	 */
	public String getGlobalElementMetadataValue() {
		return globalElementMetadataValue;
	}



	/**
	 * @param globalElementMetadataValue the globalElementMetadataValue to set
	 */
	public void setGlobalElementMetadataValue(String globalElementMetadataValue) {
		this.globalElementMetadataValue = globalElementMetadataValue;
	}




	
	/**
	 * The default constructor
	 */
	public GlobalElement() {
		super();
	}

	

	/**
	 * @return the globalElementId
	 */
	public Long getGlobalElementId() {
		return globalElementId;
	}



	/**
	 * @param globalElementId the globalElementId to set
	 */
	public void setGlobalElementId(Long globalElementId) {
		this.globalElementId = globalElementId;
	}



	/**
	 * @return the globalElementTypeCode
	 */
	public Long getGlobalElementTypeCode() {
		return globalElementTypeCode;
	}



	/**
	 * @param globalElementTypeCode the globalElementTypeCode to set
	 */
	public void setGlobalElementTypeCode(Long globalElementTypeCode) {
		this.globalElementTypeCode = globalElementTypeCode;
	}



	/**
	 * @return the globalElementTopicCategoryCode
	 */
	public Long getGlobalElementTopicCategoryCode() {
		return globalElementTopicCategoryCode;
	}



	/**
	 * @param globalElementTopicCategoryCode the globalElementTopicCategoryCode to set
	 */
	public void setGlobalElementTopicCategoryCode(
			Long globalElementTopicCategoryCode) {
		this.globalElementTopicCategoryCode = globalElementTopicCategoryCode;
	}



	/**
	 * @return the globalElementName
	 */
	public String getGlobalElementName() {
		return globalElementName;
	}



	/**
	 * @param globalElementName the globalElementName to set
	 */
	public void setGlobalElementName(String globalElementName) {
		this.globalElementName = globalElementName;
	}



	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the globalElementDetail
	 */
	public List<GlobalElementDetail> getGlobalElementDetail() {
		return globalElementDetail;
	}

	/**
	 * @param globalElementDetail the globalElementDetail to set
	 */
	public void setGlobalElementDetail(List<GlobalElementDetail> globalElementDetail) {
		this.globalElementDetail = globalElementDetail;
	}



	/**
	 * @param topicCategoryDescription the topicCategoryDescription to set
	 */
	public void setTopicCategoryDescription(String topicCategoryDescription) {
		this.topicCategoryDescription = topicCategoryDescription;
	}



	/**
	 * @return the topicCategoryDescription
	 */
	public String getTopicCategoryDescription() {
		return topicCategoryDescription;
	}


	/**
	 * @param globalElementMetadataCode the globalElementMetadataCode to set
	 */
	public void setGlobalElementMetadataCode(Long globalElementMetadataCode) {
		this.globalElementMetadataCode = globalElementMetadataCode;
	}


	/**
	 * @return the globalElementMetadataCode
	 */
	public Long getGlobalElementMetadataCode() {
		return globalElementMetadataCode;
	}




	/**
	 * @param globalElementMetadataCodeDescription the globalElementMetadataCodeDescription to set
	 */
	public void setGlobalElementMetadataCodeDescription(
			String globalElementMetadataCodeDescription) {
		this.globalElementMetadataCodeDescription = globalElementMetadataCodeDescription;
	}




	/**
	 * @return the globalElementMetadataCodeDescription
	 */
	public String getGlobalElementMetadataCodeDescription() {
		return globalElementMetadataCodeDescription;
	}




	/**
	 * @param globalElementBaseSubTypeId the globalElementBaseSubTypeId to set
	 */
	public void setGlobalElementBaseSubTypeId(Long globalElementBaseSubTypeId) {
		this.globalElementBaseSubTypeId = globalElementBaseSubTypeId;
	}




	/**
	 * @return the globalElementBaseSubTypeId
	 */
	public Long getGlobalElementBaseSubTypeId() {
		return globalElementBaseSubTypeId;
	}




	/**
	 * @param globalElementComment the globalElementComment to set
	 */
	public void setGlobalElementComment(String globalElementComment) {
		this.globalElementComment = globalElementComment;
	}




	/**
	 * @return the globalElementComment
	 */
	public String getGlobalElementComment() {
		return globalElementComment;
	}

	public void setGlobalElementDetailComment(String globalElementDetailComment) {
		this.globalElementDetailComment = globalElementDetailComment;
	}

	public String getGlobalElementDetailComment() {
		return globalElementDetailComment;
	}

	/**
	 * @param unMappedCount the unMappedCount to set
	 */
	public void setUnMappedCount(Long unMappedCount) {
		this.unMappedCount = unMappedCount;
	}

	/**
	 * @return the unMappedCount
	 */
	public Long getUnMappedCount() {
		return unMappedCount;
	}

	/**
	 * @param unMappedElementCount the unMappedElementCount to set
	 */
	public void setUnMappedElementCount(Long unMappedElementCount) {
		this.unMappedElementCount = unMappedElementCount;
	}

	/**
	 * @return the unMappedElementCount
	 */
	public Long getUnMappedElementCount() {
		return unMappedElementCount;
	}

	/**
	 * @param month the month to set
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * @return the month
	 */
	public String getMonth() {
		return month;
	}
	
	
	
	
}
