/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "PROD_AVLB")
@NamedQueries({
		
		})
public class ProductAvailability extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PROD_AVLB_ID")
	private Long productAvlbId;
		
	@Column(name = "PROD_ID")
	private Long productId;
	
	@Column(name = "SLS_CHNL_ID")
	private Long salesChnlId;
		
	public Long getProductAvlbId() {
		return productAvlbId;
	}

	public void setProductAvlbId(Long productAvlbId) {
		this.productAvlbId = productAvlbId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getSalesChnlId() {
		return salesChnlId;
	}

	public void setSalesChnlId(Long salesChnlId) {
		this.salesChnlId = salesChnlId;
	}

	/**
	 * Empty Constructor.
	 */
	public ProductAvailability() {
		super();
	}
	
	public ProductAvailability(Long productAvlbId) {
		super();
		this.productAvlbId = productAvlbId;
	}
	/*public ProductAvailability(Long ProductAvailabilityVersion) {
		super();
		this.ProductAvailabilityVersion = ProductAvailabilityVersion;
	}*/
	public ProductAvailability(Long productAvlbId, Long productId) {
		super();
		this.productAvlbId = productAvlbId;
		this.productId = productId;
	}
	
	
	/**
	 * 
	 * @param ProductAvailabilityId
	 * @param ProductAvailabilityVersion
	 * @param ProductAvailabilityTypeId
	 * @param ProductAvailabilityMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public ProductAvailability(Long productAvlbId, Long productId, Long salesChnlId,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.productAvlbId = productAvlbId;
		this.productId = productId;
		this.salesChnlId = salesChnlId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ProductAvailability [productAvlbId=" + productAvlbId
				+ ", productId=" + productId 
				+ ",salesChnlId=" + salesChnlId + 
				  "]";
	}
	
	
}
