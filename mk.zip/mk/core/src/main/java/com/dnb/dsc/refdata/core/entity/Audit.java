/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
/**
 * This class used as an entity class for the AuditAble attributes. The class
 * will be extended by all the other classes for the Audit fields mapping
 *
 * @author Cognizant
 * @version last updated : May 04, 2012
 * @see
 *
 */
@MappedSuperclass
public abstract class Audit implements Serializable {

	private static final long serialVersionUID = 5457603753917439972L;

	@Column(name = "ROW_CRE_ID")
	private String createdUser;
	
	@Column(name = "ROW_CRE_TMST")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date createdDate;
		
	@Column(name = "ROW_MOD_ID")
	private String modifiedUser;
	
	@Column(name = "ROW_MOD_TMST")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date modifiedDate;

	public Audit() {
		
	}
	
	/**
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 */
	public Audit(String createdUser, Date createdDate, String modifiedUser,
			Date modifiedDate) {
		this.createdUser = createdUser;
		this.createdDate = createdDate;
		this.modifiedUser = modifiedUser;
		this.modifiedDate = modifiedDate;
	}

    public Audit(Date modifiedDate, String modifiedUser) {
        this.modifiedDate = modifiedDate;
        this.modifiedUser = modifiedUser;
    }
    
    public Audit(String modifiedUser){
    	this.modifiedUser = modifiedUser;
    }

	/**
	 * @return the createdUser
	 */
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the modifiedUser
	 */
	public String getModifiedUser() {
		return modifiedUser;
	}

	/**
	 * @param modifiedUser the modifiedUser to set
	 */
	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
