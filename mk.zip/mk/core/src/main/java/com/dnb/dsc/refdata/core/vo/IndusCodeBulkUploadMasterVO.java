package com.dnb.dsc.refdata.core.vo;

import com.dnb.dsc.refdata.core.entity.IndustryCode;

public class IndusCodeBulkUploadMasterVO {
	private IndustryCode indsCode;
	private IndustryCode indsCodeDesc;
	/**
	 * @return the indsCode
	 */
	public IndustryCode getIndsCode() {
		return indsCode;
	}
	/**
	 * @param indsCode the indsCode to set
	 */
	public void setIndsCode(IndustryCode indsCode) {
		this.indsCode = indsCode;
	}
	/**
	 * @return the indsCodeDesc
	 */
	public IndustryCode getIndsCodeDesc() {
		return indsCodeDesc;
	}
	/**
	 * @param indsCodeDesc the indsCodeDesc to set
	 */
	public void setIndsCodeDesc(IndustryCode indsCodeDesc) {
		this.indsCodeDesc = indsCodeDesc;
	}
	
	

}
