/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.CodeValueText;

public class FinancialStatementTemplateVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<FinancialStatementVO> allFSVOList;
	private List<CodeValueText> financialTemplateList;
	
	public FinancialStatementTemplateVO(){

	}

	/**
	 * @return the financialTemplateList
	 */
	public List<CodeValueText> getFinancialTemplateList() {
		return financialTemplateList;
	}

	/**
	 * @param financialTemplateList the financialTemplateList to set
	 */
	public void setFinancialTemplateList(List<CodeValueText> financialTemplateList) {
		this.financialTemplateList = financialTemplateList;
	}

	/**
	 * @return the allFSVOList
	 */
	public List<FinancialStatementVO> getAllFSVOList() {
		return allFSVOList;
	}

	/**
	 * @param allFSVOList the allFSVOList to set
	 */
	public void setAllFSVOList(List<FinancialStatementVO> allFSVOList) {
		this.allFSVOList = allFSVOList;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FinancialStatementTemplateVO [allFSVOList=" + allFSVOList
				+ ", financialTemplateList=" + financialTemplateList + "]";
	}
	
}
