/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.interceptor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.dnb.dsc.refdata.core.vo.TransactionLoggerVO;

/**
 * <p>
 * This class is an logger which will logs the transactions
 * </p>
 * 
 * @author Cognizant Technology Solutions
 * @version last updated : August 1, 2012
 * @see TransactionLogger
 * 
 */
@Component
public class TransactionLogger {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(TransactionLogger.class);

	/**
	 * This method will log all the transactions in RefData
	 * 
	 * @param transactionLoggerVO
	 */
	public void transactionLog(TransactionLoggerVO transactionLoggerVO) {
		LOGGER.debug("transactionId=" + transactionLoggerVO.getTransactionId()
				+ ", startTime=" + transactionLoggerVO.getStartTime()
				+ ", endTime=" + transactionLoggerVO.getEndTime() 
				+ ", userId=" + transactionLoggerVO.getUserId() 
				+ ", userRole="	+ transactionLoggerVO.getUserRoles() 
				+ ", domainName=" + transactionLoggerVO.getDomain() 
				+ ", transactionType=" + transactionLoggerVO.getTransactionType()
				+ ", transactionStatus=" + transactionLoggerVO.getTransactionStatus() 
				+ (transactionLoggerVO.getVariableArguments() != null ? ", arguments="
						+ transactionLoggerVO.getVariableArguments() : "")
				+ ", domainObject="	+ transactionLoggerVO.getDomainObject()
				+ (transactionLoggerVO.getTrackingId() > 0 ? ", workflowTrackingId="
						+ transactionLoggerVO.getTrackingId() : ""));
	}

	/**
	 * 
	 * This method will populate the audit variable in to the
	 * TransactionLoggerVO
	 *
	 * @param startTime
	 * @param endTime
	 * @param userIdentifier
	 * @param userRoles
	 * @param domainName
	 * @param transactionType
	 * @param transactionStatus
	 * @param domainId
	 * @param trackingId
	 * @param varArgs
	 * @return transactionLoggerVO
	 */
	public TransactionLoggerVO populateTransactionLoggerVO(String startTime,
			String endTime, String userIdentifier, List<String> userRoles,
			String domainName, String transactionType, Long transactionStatus,
			Object domainId, Long trackingId, Object ... varArgs) {

		TransactionLoggerVO transactionLoggerVO = new TransactionLoggerVO();
		transactionLoggerVO.setTransactionId(System.currentTimeMillis());
		transactionLoggerVO.setStartTime(startTime);
		transactionLoggerVO.setEndTime(endTime);
		transactionLoggerVO.setUserId(userIdentifier);
		transactionLoggerVO.setUserRoles(userRoles != null ? userRoles.toString().replace(',', '~') : "");
		transactionLoggerVO.setDomain(domainName);
		transactionLoggerVO.setTransactionType(transactionType);
		transactionLoggerVO.setTransactionStatus(transactionStatus);
		transactionLoggerVO.setDomainObject(domainId);
		transactionLoggerVO.setTrackingId(trackingId);
		
		if(varArgs != null && varArgs.length > 0) {
			List<Object> vList = new ArrayList<Object>();
			for(Object arg : varArgs) {
				vList.add(arg);
			}
			transactionLoggerVO.setVariableArguments(vList);
		}
		return transactionLoggerVO;
	}
	/**
	 * 
	 * The method to log the audit transaction
	 *
	 * @param startTime
	 * @param userIdentifier
	 * @param userRoles
	 * @param domainName
	 * @param transactionType
	 * @param transactionStatus
	 * @param domainId
	 * @param trackingId
	 * @param varArgs
	 */
	public void log(Date startTime, String userIdentifier, List<String> userRoles,
			String domainName, String transactionType, Long transactionStatus, Object domainId,
			Long trackingId, Object ... varArgs) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date endTime = new Date();
		String strStartTime = formatter.format(startTime);
		String strEndTime = formatter.format(endTime);
		
		TransactionLoggerVO transactionLoggerVO = populateTransactionLoggerVO(
				strStartTime, strEndTime, userIdentifier, userRoles, domainName,
				transactionType, transactionStatus, domainId, trackingId, varArgs);
		transactionLog(transactionLoggerVO);
	}
}
