package com.dnb.dsc.refdata.core.vo;

import org.springframework.web.multipart.MultipartFile;

public class ControlWordsUploadVO {
	private String fileType;
	private MultipartFile file;

	/**
	 * @param file the file to set
	 */
	public void setFile(MultipartFile file) {
		this.file = file;
	}

	/**
	 * @return the file
	 */
	public MultipartFile getFile() {
		return file;
	}

	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}

}
