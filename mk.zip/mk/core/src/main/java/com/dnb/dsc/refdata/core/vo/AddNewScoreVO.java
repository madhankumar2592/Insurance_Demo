package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.Audit;

public class AddNewScoreVO extends Audit implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8993265291802855778L;
	
	
	private Long scoreTypeCode;
	private Long marketCode;
	private Double scoreVersion;
	private Long scoreGranuAssnId;
	private String scoreMappingLabel;
	private Long scoreId;
	private List<Long> scrGranuAssnIdList;
	private List<String> scrGranuValueList;
	private List<AddNewScoreVO> addNewScoreVOs;
	private List<Long> marketCodeList; 
    
    public List<Long> getMarketCodeList() { 
            return marketCodeList; 
    } 
    public void setMarketCodeList(List<Long> marketCodeList) { 
            this.marketCodeList = marketCodeList; 
    }
	
	/**
	 * @return the addNewScoreVOs
	 */
	public List<AddNewScoreVO> getAddNewScoreVOs() {
		return addNewScoreVOs;
	}
	/**
	 * @param addNewScoreVOs the addNewScoreVOs to set
	 */
	public void setAddNewScoreVOs(List<AddNewScoreVO> addNewScoreVOs) {
		this.addNewScoreVOs = addNewScoreVOs;
	}
	/**
	 * @return the scrGranuValueList
	 */
	public List<String> getScrGranuValueList() {
		return scrGranuValueList;
	}
	/**
	 * @param scrGranuValueList the scrGranuValueList to set
	 */
	public void setScrGranuValueList(List<String> scrGranuValueList) {
		this.scrGranuValueList = scrGranuValueList;
	}
	/**
	 * @return the scrGranuAssnIdList
	 */
	public List<Long> getScrGranuAssnIdList() {
		return scrGranuAssnIdList;
	}
	/**
	 * @param scrGranuAssnIdList the scrGranuAssnIdList to set
	 */
	public void setScrGranuAssnIdList(List<Long> scrGranuAssnIdList) {
		this.scrGranuAssnIdList = scrGranuAssnIdList;
	}
	/**
	 * @return the scoreMappingLabel
	 */
	public String getScoreMappingLabel() {
		return scoreMappingLabel;
	}
	/**
	 * @param scoreMappingLabel the scoreMappingLabel to set
	 */
	public void setScoreMappingLabel(String scoreMappingLabel) {
		this.scoreMappingLabel = scoreMappingLabel;
	}
	/**
	 * @return the scoreId
	 */
	public Long getScoreId() {
		return scoreId;
	}
	/**
	 * @param scoreId the scoreId to set
	 */
	public void setScoreId(Long scoreId) {
		this.scoreId = scoreId;
	}
	/**
	 * @return the scoreTypeCode
	 */
	public Long getScoreTypeCode() {
		return scoreTypeCode;
	}
	/**
	 * @return the scoreGranuAssnId
	 */
	public Long getScoreGranuAssnId() {
		return scoreGranuAssnId;
	}
	/**
	 * @param scoreGranuAssnId the scoreGranuAssnId to set
	 */
	public void setScoreGranuAssnId(Long scoreGranuAssnId) {
		this.scoreGranuAssnId = scoreGranuAssnId;
	}
	
	/**
	 * @param scoreTypeCode the scoreTypeCode to set
	 */
	public void setScoreTypeCode(Long scoreTypeCode) {
		this.scoreTypeCode = scoreTypeCode;
	}
	/**
	 * @return the marketList
	 */
	public Long getMarketCode() {
		return marketCode;
	}
	/**
	 * @param marketList the marketList to set
	 */
	public void setMarketCode(Long marketCode) {
		this.marketCode = marketCode;
	}
	/**
	 * @return the scoreVersion
	 */
	public Double getScoreVersion() {
		return scoreVersion;
	}
	/**
	 * @param scoreVersion the scoreVersion to set
	 */
	public void setScoreVersion(Double scoreVersion) {
		this.scoreVersion = scoreVersion;
	}
	
	
}