package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.Audit;

public class AddNewProductsVO extends Audit implements Serializable  {
	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = 6764323275786399244L;
	/**
	 *  productCode.
	 */
	private Long productCode;
	/**
	 *  productVersion.
	 */
	private Long productVersion;
	/**
	 *  productFamilyCode.
	 */
	private Long productFamilyCode;
	/**
	 *  productGroupCode.
	 */
	private Long productGroupCode;
	/**
	 *  productMetadataCode.
	 */
	private List<ProductMetaData> productMetaData;
	
	private Long productMetadataCode;
	/**
	 *  productMetadataValue.
	 */
	private String productMetadataValue;
	/**
	 *  productResources.
	 */
	private List<ProductResources> productResources;
	
	
	/*private List<ResourceMetadataVO> resourceMetadata;

	public List<ResourceMetadataVO> getResourceMetadata() {
		return resourceMetadata;
	}
	public void setResourceMetadata(List<ResourceMetadataVO> resourceMetadata) {
		this.resourceMetadata = resourceMetadata;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}*/
	/**
	 *  salesChannelCode.
	 */
	private Long salesChannelCode;
	/**
	 *  salesVersion.
	 */
	private Long salesVersion;

	/*	*//**
	 *  salesMetadataCode.
	 *//*
	private Long salesMetadataCode;
	*//**
	 *  salesMetadataValue.
	 *//*
	private String salesMetadataValue;*/
	
	
	/**
	 * salesMetadata
	 */
	private List<SalesMetadataVO> salesMetadata;
	
	/**
	 *  countryList.
	 */
	private List<Long> countryList;
	/**
	 *  country.
	 */
	private Long country;
	/**
	 *  marketGroupCode.
	 */
	private Long marketGroupCode;
	/**
	 *  productResource.
	 */
	private ProductResources productResource;	
	
	private Long prodId;
	private Long prodAvailId;
	private Long saleChnlid;
	private Long prodMktId;
	private Long rescMapId;
	private Long rescId;
	private Long prodGrpId;
	private Long prodDtlId;
	private Long mktGrpId;
	private Long rescGrpId;
	private Long rescDtlID;
	private Long slsChnlDtlID;	
	
	private List<Long> prodMktIdList;
	
	public Long getProdId() {
		return prodId;
	}
	public void setProdId(Long prodId) {
		this.prodId = prodId;
	}
	public Long getProdAvailId() {
		return prodAvailId;
	}
	public void setProdAvailId(Long prodAvailId) {
		this.prodAvailId = prodAvailId;
	}
	public Long getSaleChnlid() {
		return saleChnlid;
	}
	public void setSaleChnlid(Long saleChnlid) {
		this.saleChnlid = saleChnlid;
	}
	public Long getProdMktId() {
		return prodMktId;
	}
	public void setProdMktId(Long prodMktId) {
		this.prodMktId = prodMktId;
	}
	public Long getRescMapId() {
		return rescMapId;
	}
	public void setRescMapId(Long rescMapId) {
		this.rescMapId = rescMapId;
	}
	public Long getRescId() {
		return rescId;
	}
	public void setRescId(Long rescId) {
		this.rescId = rescId;
	}
	public Long getProdGrpId() {
		return prodGrpId;
	}
	public void setProdGrpId(Long prodGrpId) {
		this.prodGrpId = prodGrpId;
	}
	public Long getProdDtlId() {
		return prodDtlId;
	}
	public void setProdDtlId(Long prodDtlId) {
		this.prodDtlId = prodDtlId;
	}
	public Long getMktGrpId() {
		return mktGrpId;
	}
	public void setMktGrpId(Long mktGrpId) {
		this.mktGrpId = mktGrpId;
	}
	public Long getRescGrpId() {
		return rescGrpId;
	}
	public void setRescGrpId(Long rescGrpId) {
		this.rescGrpId = rescGrpId;
	}
	public Long getRescDtlID() {
		return rescDtlID;
	}
	public void setRescDtlID(Long rescDtlID) {
		this.rescDtlID = rescDtlID;
	}
	public Long getSlsChnlDtlID() {
		return slsChnlDtlID;
	}
	public void setSlsChnlDtlID(Long slsChnlDtlID) {
		this.slsChnlDtlID = slsChnlDtlID;
	}
	public Long getCountry() {
		return country;
	}
	public void setCountry(Long country) {
		this.country = country;
	}
	public ProductResources getProductResource() {
		return productResource;
	}
	public void setProductResource(ProductResources productResource) {
		this.productResource = productResource;
	}
	/**
	 * @return the productCode
	 */
	public Long getProductCode() {
		return productCode;
	}
	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}
	/**
	 * @return the productVersion
	 */
	public Long getProductVersion() {
		return productVersion;
	}
	/**
	 * @param productVersion the productVersion to set
	 */
	public void setProductVersion(Long productVersion) {
		this.productVersion = productVersion;
	}
	/**
	 * @return the productFamilyCode
	 */
	public Long getProductFamilyCode() {
		return productFamilyCode;
	}
	/**
	 * @param productFamilyCode the productFamilyCode to set
	 */
	public void setProductFamilyCode(Long productFamilyCode) {
		this.productFamilyCode = productFamilyCode;
	}
	/**
	 * @return the productGroupCode
	 */
	public Long getProductGroupCode() {
		return productGroupCode;
	}
	/**
	 * @param productGroupCode the productGroupCode to set
	 */
	public void setProductGroupCode(Long productGroupCode) {
		this.productGroupCode = productGroupCode;
	}
	/**
	 * @return the productMetadataCode
	 */
	public Long getProductMetadataCode() {
		return productMetadataCode;
	}
	/**
	 * @param productMetadataCode the productMetadataCode to set
	 */
	public void setProductMetadataCode(Long productMetadataCode) {
		this.productMetadataCode = productMetadataCode;
	}
	/**
	 * @return the productMetadataValue
	 */
	public String getProductMetadataValue() {
		return productMetadataValue;
	}
	/**
	 * @param productMetadataValue the productMetadataValue to set
	 */
	public void setProductMetadataValue(String productMetadataValue) {
		this.productMetadataValue = productMetadataValue;
	}
/**
	 * @return productMetaData
	 */
	public List<ProductMetaData> getProductMetaData() {
		return productMetaData;
	}
	/**
	 * 
	 * @param productMetaData the productMetaData to set
	 */
	public void setProductMetaData(List<ProductMetaData> productMetaData) {
		this.productMetaData = productMetaData;
	}
	/**
	 * @return the productResources
	 */
	public List<ProductResources> getProductResources() {
		return productResources;
	}
	/**
	 * @param productResources the productResources to set
	 */
	public void setProductResources(List<ProductResources> productResources) {
		this.productResources = productResources;
	}
	/**
	 * @return the salesChannelCode
	 */
	public Long getSalesChannelCode() {
		return salesChannelCode;
	}
	/**
	 * @param salesChannelCode the salesChannelCode to set
	 */
	public void setSalesChannelCode(Long salesChannelCode) {
		this.salesChannelCode = salesChannelCode;
	}
	/**
	 * @return the salesVersion
	 */
	public Long getSalesVersion() {
		return salesVersion;
	}
	/**
	 * @param salesVersion the salesVersion to set
	 */
	public void setSalesVersion(Long salesVersion) {
		this.salesVersion = salesVersion;
	}
/*	*//**
	 * @return the salesMetadataCode
	 *//*
	public Long getSalesMetadataCode() {
		return salesMetadataCode;
	}
	*//**
	 * @param salesMetadataCode the salesMetadataCode to set
	 *//*
	public void setSalesMetadataCode(Long salesMetadataCode) {
		this.salesMetadataCode = salesMetadataCode;
	}
	*//**
	 * @return the salesMetadataValue
	 *//*
	public String getSalesMetadataValue() {
		return salesMetadataValue;
	}
	*//**
	 * @param salesMetadataValue the salesMetadataValue to set
	 *//*
	public void setSalesMetadataValue(String salesMetadataValue) {
		this.salesMetadataValue = salesMetadataValue;
	}*/
	
	/**
	 *@return the  salesMetadata
	 */
	public List<SalesMetadataVO> getSalesMetadata() {
		return salesMetadata;
	}
	/**
	 * 	
	 * @param salesMetadata the salesMetadata to set
	 */
	public void setSalesMetadata(List<SalesMetadataVO> salesMetadata) {
		this.salesMetadata = salesMetadata;
	}
	/**
	 * @return the countryList
	 */
	public List<Long> getCountryList() {
		return countryList;
	}
	/**
	 * @param countryList the countryList to set
	 */
	public void setCountryList(List<Long> countryList) {
		this.countryList = countryList;
	}
	/**
	 * @return the marketGroupCode
	 */
	public Long getMarketGroupCode() {
		return marketGroupCode;
	}
	/**
	 * @param marketGroupCode the marketGroupCode to set
	 */
	public void setMarketGroupCode(Long marketGroupCode) {
		this.marketGroupCode = marketGroupCode;
	}
	/**
	 * @param prodMktIdList the prodMktIdList to set
	 */
	public void setProdMktIdList(List<Long> prodMktIdList) {
		this.prodMktIdList = prodMktIdList;
	}
	/**
	 * @return the prodMktIdList
	 */
	public List<Long> getProdMktIdList() {
		return prodMktIdList;
	}
	

	
}
