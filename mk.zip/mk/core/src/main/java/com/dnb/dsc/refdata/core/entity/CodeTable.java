/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the Code Table. The class
 * will have a direct mapping toe DB table cd_tbl.
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
@Entity
@Table(name = "CD_TBL")
@NamedQueries({
		@NamedQuery(name = "CodeTable.retrieveCodeTableList", query = "SELECT new CodeTable(c.codeTableId, c.codeTableName) FROM CodeTable c order by c.codeTableId"),
		@NamedQuery(name = "CodeTable.countCodeTable", query = "SELECT count(c.codeTableId) FROM CodeTable c WHERE c.codeTableId = :codeTableId"),
		@NamedQuery(name = "CodeTable.removeCodeTableById", query = "DELETE FROM CodeTable c where c.codeTableId = :codeTableId")})
public class CodeTable extends Audit implements Serializable {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "CD_TBL_ID")
	private Long codeTableId;

	@Column(name = "CD_TBL_NME")
	private String codeTableName;

	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;

	@Column(name = "BUS_DESC")
	private String businessDescription;

	@Column(name = "REAS_TXT")
	private String reasonText;

	@Column(name = "REQ_ON_BHLF_OF_NME")
	private String onBehalfOfName;

	@Transient
	private List<CodeValue> codeValues;

	@Transient
	private List<SystemApplicability> systemApplicability;

	@Transient
	private List<CountryApplicability> countryApplicability;

	@Transient
	private List<String> systemList;

	@Transient
	private List<String> countryList;

	/**
	 * The default constructor
	 */
	public CodeTable() {
		super();
	}

	/**
	 * @param codeTableId
	 * @param codeTableName
	 * @param effectiveDate
	 * @param expirationDate
	 * @param businessDescription
	 * @param reasonText
	 * @param onBehalfOfName
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedDate
	 * @param modifiedUser
	 * @param codeValues
	 * @param systemApplicability
	 * @param countryApplicability
	 */
	public CodeTable(Long codeTableId, String codeTableName,
			Date effectiveDate, Date expirationDate,
			String businessDescription, String reasonText,
			String onBehalfOfName, String createdUser, Date createdDate,
			Date modifiedDate, String modifiedUser, List<CodeValue> codeValues,
			List<SystemApplicability> systemApplicability,
			List<CountryApplicability> countryApplicability) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.codeTableId = codeTableId;
		this.codeTableName = codeTableName;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
		this.businessDescription = businessDescription;
		this.reasonText = reasonText;
		this.onBehalfOfName = onBehalfOfName;
		this.codeValues = codeValues;
		this.systemApplicability = systemApplicability;
		this.countryApplicability = countryApplicability;
	}

	/**
	 * @param codeTableId
	 * @param codeTableName
	 */
	public CodeTable(Long codeTableId, String codeTableName) {
		this.codeTableId = codeTableId;
		this.codeTableName = codeTableName;
	}
	/**
	 * @return the codeTableId
	 */
	public Long getCodeTableId() {
		return codeTableId;
	}

	/**
	 * @param codeTableId the codeTableId to set
	 */
	public void setCodeTableId(Long codeTableId) {
		this.codeTableId = codeTableId;
	}

	/**
	 * @return the codeTableName
	 */
	public String getCodeTableName() {
		return codeTableName;
	}

	/**
	 * @param codeTableName the codeTableName to set
	 */
	public void setCodeTableName(String codeTableName) {
		this.codeTableName = codeTableName;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	/**
	 * @return the businessDescription
	 */
	public String getBusinessDescription() {
		return businessDescription;
	}

	/**
	 * @param businessDescription the businessDescription to set
	 */
	public void setBusinessDescription(String businessDescription) {
		this.businessDescription = businessDescription;
	}

	/**
	 * @return the reasonText
	 */
	public String getReasonText() {
		return reasonText;
	}

	/**
	 * @param reasonText the reasonText to set
	 */
	public void setReasonText(String reasonText) {
		this.reasonText = reasonText;
	}

	/**
	 * @return the onBehalfOfName
	 */
	public String getOnBehalfOfName() {
		return onBehalfOfName;
	}

	/**
	 * @param onBehalfOfName the onBehalfOfName to set
	 */
	public void setOnBehalfOfName(String onBehalfOfName) {
		this.onBehalfOfName = onBehalfOfName;
	}

	/**
	 * @return the codeValues
	 */
	public List<CodeValue> getCodeValues() {
		return codeValues;
	}

	/**
	 * @param codeValues the codeValues to set
	 */
	public void setCodeValues(List<CodeValue> codeValues) {
		this.codeValues = codeValues;
	}




	/**
	 * @return the systemApplicability
	 */
	public List<SystemApplicability> getSystemApplicability() {
		return systemApplicability;
	}

	/**
	 * @param systemApplicability the systemApplicability to set
	 */
	public void setSystemApplicability(List<SystemApplicability> systemApplicability) {
		this.systemApplicability = systemApplicability;
	}

	/**
	 * @return the countryApplicability
	 */
	public List<CountryApplicability> getCountryApplicability() {
		return countryApplicability;
	}

	/**
	 * @param countryApplicability the countryApplicability to set
	 */
	public void setCountryApplicability(List<CountryApplicability> countryApplicability) {
		this.countryApplicability = countryApplicability;
	}



	/**
	 * @return the systemList
	 */
	public List<String> getSystemList() {
		return systemList;
	}

	/**
	 * @param systemList the systemList to set
	 */
	public void setSystemList(List<String> systemList) {
		this.systemList = systemList;
	}

	/**
	 * @return the countryList
	 */
	public List<String> getCountryList() {
		return countryList;
	}

	/**
	 * @param countryList the countryList to set
	 */
	public void setCountryList(List<String> countryList) {
		this.countryList = countryList;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CodeTable [codeTableId=" + codeTableId + ", codeTableName="
				+ codeTableName + ", effectiveDate=" + effectiveDate
				+ ", expirationDate=" + expirationDate
				+ ", businessDescription=" + businessDescription
				+ ", reasonText=" + reasonText + ", onBehalfOfName="
				+ onBehalfOfName + ", codeValues=" + codeValues
				+ ", systemApplicability=" + systemApplicability
				+ ", countryApplicability=" + countryApplicability
				+ ", systemList=" + systemList + ", countryList=" + countryList
				+ "]";
	}


}
