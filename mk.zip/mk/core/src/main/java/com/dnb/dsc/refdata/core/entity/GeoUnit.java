/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.codehaus.jackson.annotate.JsonManagedReference;
import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the GeoUnit. The class will have a
 * direct mapping toe DB table geo_unit.
 *
 * @author Cognizant
 * @version last updated : Jan 11, 2011
 * @see
 *
 */
@Entity
@Table(name = "GEO_UNIT")
@NamedQueries({
		@NamedQuery(name = "GeoUnit.retrieveGeoUnitByGeoUnitId", query = "SELECT g FROM GeoUnit g where g.geoUnitId = :geoUnitId"),
		@NamedQuery(name = "GeoUnit.deleteGeoUnit", query = "UPDATE GeoUnit g SET g.expiredByDate = (sysdate) WHERE g.geoUnitId = :geoUnitId"),
		@NamedQuery(name = "GeoUnit.retrieveGeoUnitForDelete", query = "SELECT new GeoUnit(g.geoUnitId, g.geoUnitTypeCode, g.dnbComment, g.effectiveDate, g.expirationDate, g.expiredByDate, g.createdDate, g.modifiedDate, g.modifiedUser,g.createdUser) FROM GeoUnit g WHERE g.geoUnitId = :geoUnitId"),
		@NamedQuery(name = "GeoUnit.countGeoUnit", query = "SELECT count(g.geoUnitId) FROM GeoUnit g WHERE g.geoUnitId = :geoUnitId"),
		@NamedQuery(name = "GeoUnit.retrieveGeoUnitByTrackingId", query = "SELECT g from GeoUnit g where g.geoUnitId  = :trackingId"),
		@NamedQuery(name = "GeoUnit.updateGeoUnit", query = "UPDATE GeoUnit g set g.dnbComment = :dnbComment, g.expirationDate = :expirationDate, g.expiredByDate = :expiredByDate, g.modifiedUser = :modifiedUser, g.modifiedDate = :modifiedDate where g.geoUnitId = :geoUnitId"),
		@NamedQuery(name = "GeoUnit.removeGeoUnitByGeoUnitId", query = "DELETE GeoUnit g where g.geoUnitId = :geoUnitId"),
		@NamedQuery(name = "GeoUnit.getOfficialNameByGeoUnitIdAndTypeCode", query = "SELECT new GeoUnit(n.geoName) FROM GeoUnit g, GeoUnitAssociation a, GeoUnitName n WHERE g.geoUnitId = n.geoUnitId and g.geoUnitId = a.childGeoUnitId and a.parentGeoUnitId = :parentGeoUnitId and g.geoUnitTypeCode = :geoUnitTypeCode and n.languageCode = 39 and n.nameTypeCode = 32 and n.geoUnitId = :geoUnitId"),
		@NamedQuery(name = "GeoUnit.getCodeAndNameById", query = "SELECT new GeoUnit(g.geoUnitId, g.geoUnitTypeCode, n.geoName, n.languageCode) FROM GeoUnit g, GeoUnitName n WHERE g.geoUnitId in (:geoUnitIdList) and g.geoUnitId = n.geoUnitId and n.nameTypeCode = :nameTypeCode and n.expirationDate is null and n.expiredByDate is null")
	})
public class GeoUnit extends Audit implements Serializable {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "GEO_UNIT_ID")
	private Long geoUnitId;

	@Column(name = "GEO_UNIT_TYP_CD")
	private Long geoUnitTypeCode;

	@Column(name = "DNB_CMNT")
	private String dnbComment;

	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)   //Added for Enhancement
	private Date expirationDate;

	@Column(name = "EXPD_BY_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expiredByDate;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "parentGeoUnit")
	@JsonManagedReference
	private List<GeoUnitName> geoUnitNames;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "parentGeoUnit")
	@JsonManagedReference
	private List<GeoUnitCode> geoUnitCodes;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "childGeoUnitId")
	private List<GeoUnitAssociation> parentGeoUnitAssociations;

	@Transient
	private List<GeoUnitAssociation> childGeoUnitAssociations;

	@Transient
	private String officialGeoName;

	@Transient
	private Long officialLanguageCode;
	/**
	 * Constructor
	 */
	@Transient
	private String geoUnitBulkId;
	
	@Transient
	private String errorCD;
	
	
	/**
	 * @return the geoUnitBulkId
	 */
	public String getGeoUnitBulkId() {
		return geoUnitBulkId;
	}

	/**
	 * @param geoUnitBulkId the geoUnitBulkId to set
	 */
	public void setGeoUnitBulkId(String geoUnitBulkId) {
		this.geoUnitBulkId = geoUnitBulkId;
	}
	public GeoUnit() {
		super();
	}

	public GeoUnit(String officialGeoName){
		this.officialGeoName = officialGeoName;
	}

	public GeoUnit(Long geoUnitId, Long geoUnitTypeCode, String officialGeoName, Long officialLanguageCode){
		this.geoUnitId = geoUnitId;
		this.geoUnitTypeCode = geoUnitTypeCode;
		this.officialGeoName = officialGeoName;
		this.officialLanguageCode = officialLanguageCode;
	}

	/**
	 * @param geoUnitId
	 * @param geoUnitTypeCode
	 * @param dnbComment
	 * @param effectiveDate
	 * @param expirationDate
	 * @param expiredByDate
	 * @param createdDate
	 * @param modifiedDate
	 * @param modifiedUser
	 * @param createdUser
	 * @param geoUnitNames
	 * @param geoUnitCodes
	 * @param parentGeoUnitAssociations
	 */
	public GeoUnit(Long geoUnitId, Long geoUnitTypeCode, String dnbComment,
			Date effectiveDate, Date expirationDate, Date expiredByDate,
			Date createdDate, Date modifiedDate, String modifiedUser,
			String createdUser, List<GeoUnitName> geoUnitNames,
			List<GeoUnitCode> geoUnitCodes,
			List<GeoUnitAssociation> parentGeoUnitAssociations) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.geoUnitId = geoUnitId;
		this.geoUnitTypeCode = geoUnitTypeCode;
		this.dnbComment = dnbComment;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
		this.expiredByDate = expiredByDate;
		this.geoUnitNames = geoUnitNames;
		this.geoUnitCodes = geoUnitCodes;
		this.parentGeoUnitAssociations = parentGeoUnitAssociations;
	}

	/**
	 * @param geoUnitId
	 * @param geoUnitTypeCode
	 * @param dnbComment
	 * @param effectiveDate
	 * @param expirationDate
	 * @param expiredByDate
	 * @param createdDate
	 * @param modifiedDate
	 * @param modifiedUser
	 * @param createdUser
	 */
	public GeoUnit(Long geoUnitId, Long geoUnitTypeCode, String dnbComment,
			Date effectiveDate, Date expirationDate, Date expiredByDate,
			Date createdDate, Date modifiedDate, String modifiedUser,String createdUser) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.geoUnitId = geoUnitId;
		this.geoUnitTypeCode = geoUnitTypeCode;
		this.dnbComment = dnbComment;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
		this.expiredByDate = expiredByDate;
	}

	/**
	 * @return the geoUnitId
	 */
	public Long getGeoUnitId() {
		return geoUnitId;
	}

	/**
	 * @param geoUnitId
	 *            the geoUnitId to set
	 */
	public void setGeoUnitId(Long geoUnitId) {
		this.geoUnitId = geoUnitId;
	}

	/**
	 * @return the geoUnitTypeCode
	 */
	public Long getGeoUnitTypeCode() {
		return geoUnitTypeCode;
	}

	/**
	 * @param geoUnitTypeCode
	 *            the geoUnitTypeCode to set
	 */
	public void setGeoUnitTypeCode(Long geoUnitTypeCode) {
		this.geoUnitTypeCode = geoUnitTypeCode;
	}

	/**
	 * @return the dnbComment
	 */
	public String getDnbComment() {
		return dnbComment;
	}

	/**
	 * @param dnbComment
	 *            the dnbComment to set
	 */
	public void setDnbComment(String dnbComment) {
		this.dnbComment = dnbComment;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate
	 *            the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate
	 *            the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the expiredByDate
	 */
	public Date getExpiredByDate() {
		return expiredByDate;
	}

	/**
	 * @param expiredByDate
	 *            the expiredByDate to set
	 */
	public void setExpiredByDate(Date expiredByDate) {
		this.expiredByDate = expiredByDate;
	}

	/**
	 * @return the geoUnitNames
	 */
	public List<GeoUnitName> getGeoUnitNames() {
		return geoUnitNames;
	}

	/**
	 * @param geoUnitNames
	 *            the geoUnitNames to set
	 */
	public void setGeoUnitNames(List<GeoUnitName> geoUnitNames) {
		if (geoUnitNames != null) {
			for (int i = 0; i < geoUnitNames.size(); i++) {
				geoUnitNames.get(i).setParentGeoUnit(this);
			}
		}
		this.geoUnitNames = geoUnitNames;
	}

	/**
	 * @return the geoUnitCodes
	 */
	public List<GeoUnitCode> getGeoUnitCodes() {
		return geoUnitCodes;
	}

	/**
	 * @param geoUnitCodes
	 *            the geoUnitCodes to set
	 */
	public void setGeoUnitCodes(List<GeoUnitCode> geoUnitCodes) {
		if (geoUnitCodes != null) {
			for (int i = 0; i < geoUnitCodes.size(); i++) {
				geoUnitCodes.get(i).setParentGeoUnit(this);
			}
		}
		this.geoUnitCodes = geoUnitCodes;
	}

	/**
	 * @return the parentGeoUnitAssociations
	 */
	public List<GeoUnitAssociation> getParentGeoUnitAssociations() {
		return parentGeoUnitAssociations;
	}

	/**
	 * @param parentGeoUnitAssociations
	 *            the parentGeoUnitAssociations to set
	 */
	public void setParentGeoUnitAssociations(
			List<GeoUnitAssociation> parentGeoUnitAssociations) {
		this.parentGeoUnitAssociations = parentGeoUnitAssociations;
	}

	/**
	 * @return the officialGeoName
	 */
	public String getOfficialGeoName() {
		return officialGeoName;
	}

	/**
	 * @param officialGeoName
	 *            the officialGeoName to set
	 */
	public void setOfficialGeoName(String officialGeoName) {
		this.officialGeoName = officialGeoName;
	}

	/**
	 * @return the childGeoUnitAssociations
	 */
	public List<GeoUnitAssociation> getChildGeoUnitAssociations() {
		return childGeoUnitAssociations;
	}

	/**
	 * @param childGeoUnitAssociations
	 *            the childGeoUnitAssociations to set
	 */
	public void setChildGeoUnitAssociations(
			List<GeoUnitAssociation> childGeoUnitAssociations) {
		this.childGeoUnitAssociations = childGeoUnitAssociations;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GeoUnit [geoUnitId=" + geoUnitId + ", geoUnitTypeCode="
				+ geoUnitTypeCode + ", dnbComment=" + dnbComment
				+ ", effectiveDate=" + effectiveDate + ", expirationDate="
				+ expirationDate + ", expiredByDate=" + expiredByDate
				+ ", createdDate=" + ", geoUnitNames="
				+ geoUnitNames + ", geoUnitCodes=" + geoUnitCodes
				+ ", parentGeoUnitAssociations=" + parentGeoUnitAssociations
				+ ", childGeoUnitAssociations=" + childGeoUnitAssociations
				+ ", officialGeoName=" + officialGeoName + "]";
	}

	/**
	 * @return the officialLanguageCode
	 */
	public Long getOfficialLanguageCode() {
		return officialLanguageCode;
	}

	/**
	 * @param officialLanguageCode the officialLanguageCode to set
	 */
	public void setOfficialLanguageCode(Long officialLanguageCode) {
		this.officialLanguageCode = officialLanguageCode;
	}
	/**
	 * @return the errorCD
	 */
	public String getErrorCD() {
		return errorCD;
	}

	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(String errorCD) {
		this.errorCD = errorCD;
	}
}