/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the Legal Form Inferment. The class
 * will have a direct mapping toe DB table LGL_FORM_INFR.
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
@Entity
@NamedQueries({
		@NamedQuery(name = "InfermentTextCountryApplicability.retrieveLegalFormCountries", query = "SELECT DISTINCT new InfermentTextCountryApplicability(itc.icountryGeoUnitId, n.geoName) FROM InfermentTextCountryApplicability itc, GeoUnitName n, InfermentText it where it.infermentTextId= itc.infermentTextId and n.geoUnitId = itc.icountryGeoUnitId and n.languageCode = :languageCode and n.nameTypeCode = :nameTypeCode order by n.geoName"),
		@NamedQuery(name = "InfermentTextCountryApplicability.removeApprovedInfermentTextCountryApplicability", query = "DELETE from InfermentTextCountryApplicability WHERE infermentTextId= :infermentTextId") })
@Table(name = "INFR_TXT_CTRY_APPY")
public class InfermentTextCountryApplicability extends Audit implements
		Serializable {

	private static final long serialVersionUID = 6L;

	@Id
	@Column(name = "INFR_TXT_CTRY_APPY_ID")
	private Long infermentTextCountryApplicabilityId;

	@Column(name = "INFR_TXT_ID")
	private Long infermentTextId;

	@Column(name = "CTRY_GEO_UNIT_ID")
	private Long icountryGeoUnitId;

	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;

	@Transient
	private String geoName;
    
	@Transient
	private String infrmntTxtBulkId;
	
	@Transient
	private int errorCD;

	public InfermentTextCountryApplicability() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InfermentTextCountryApplicability(String createdUser,
			Date createdDate, String modifiedUser, Date modifiedDate) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		// TODO Auto-generated constructor stub
	}

	/**
	 *
	 * @param icountryGeoUnitId
	 * @param geoName
	 */
	public InfermentTextCountryApplicability(Long icountryGeoUnitId,
			String geoName) {
		super();
		this.icountryGeoUnitId = icountryGeoUnitId;
		this.geoName = geoName;
	}

	public Long getInfermentTextCountryApplicabilityId() {
		return infermentTextCountryApplicabilityId;
	}

	/**
	 * @return the geoName
	 */
	public String getGeoName() {
		return geoName;
	}

	/**
	 * @param geoName
	 *            the geoName to set
	 */
	public void setGeoName(String geoName) {
		this.geoName = geoName;
	}

	public void setInfermentTextCountryApplicabilityId(
			Long infermentTextCountryApplicabilityId) {
		this.infermentTextCountryApplicabilityId = infermentTextCountryApplicabilityId;
	}

	public Long getInfermentTextId() {
		return infermentTextId;
	}

	public void setInfermentTextId(Long infermentTextId) {
		this.infermentTextId = infermentTextId;
	}

	public Long getIcountryGeoUnitId() {
		return icountryGeoUnitId;
	}

	public void setIcountryGeoUnitId(Long icountryGeoUnitId) {
		this.icountryGeoUnitId = icountryGeoUnitId;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the infrmntTxtBulkId
	 */
	public String getInfrmntTxtBulkId() {
		return infrmntTxtBulkId;
	}

	/**
	 * @param infrmntTxtBulkId the infrmntTxtBulkId to set
	 */
	public void setInfrmntTxtBulkId(String infrmntTxtBulkId) {
		this.infrmntTxtBulkId = infrmntTxtBulkId;
	}

	/**
	 * @return the errorCD
	 */
	public int getErrorCD() {
		return errorCD;
	}

	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(int errorCD) {
		this.errorCD = errorCD;
	}

	@Override
	public String toString() {
		return "InfermentTextCountryApplicability [infermentTextCountryApplicabilityId="
				+ infermentTextCountryApplicabilityId
				+ ", infermentTextId="
				+ infermentTextId
				+ ", icountryGeoUnitId="
				+ icountryGeoUnitId
				+ ", effectiveDate="
				+ effectiveDate
				+ ", expirationDate="
				+ expirationDate + "]";
	}

}