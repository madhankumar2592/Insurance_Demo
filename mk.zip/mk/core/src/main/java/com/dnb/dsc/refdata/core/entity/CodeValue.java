/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;


/**
 * This class used as an entity class for the Code Value. The class
 * will have a direct mapping toe DB table cd_val.
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
@Entity
@Table(name = "CD_VAL")
@NamedQueries({
	@NamedQuery(name = "CodeValue.retrieveCodeValueByCodeValueId", query = "SELECT cv FROM CodeValue cv  where cv.codeValueId = :codeValueId and cv.expirationDate is null "),
	@NamedQuery(name = "CodeValue.retrieveCodeValues", query = "SELECT new CodeValue(c.codeTableId, c.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValue c, CodeValueText t where c.codeValueId = t.codeValueId and c.codeTableId in (:codeTableIds) and t.languageCode = :langCode and t.writingScriptCode = :writingScriptCode and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "CodeValue.retrieveCodeValuesScr", query = "SELECT new CodeValue(c.codeTableId, c.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValue c, CodeValueText t,SystemApplicability s where s.codeValueId=c.codeValueId and t.expirationDate is null and s.expirationDate is null and s.dnbSystemCode = 29096 and c.codeValueId = t.codeValueId and c.codeTableId in (:codeTableIds) and t.languageCode = :langCode and t.writingScriptCode = :writingScriptCode order by t.codeValueShortDescription"),
	@NamedQuery(name = "CodeValue.removeCodeValueById", query ="DELETE FROM CodeValue c where c.codeValueId = :codeValueId"),
	@NamedQuery(name = "CodeValue.countCodeValue", query = "SELECT COUNT(cv.codeValueId) FROM CodeValue cv where cv.codeValueId = :codeValueId and cv.expirationDate is null "),
	@NamedQuery(name = "CodeValue.retrieveCodeValuesById", query = "SELECT new CodeValue(c.codeValueId, t.codeValueDescription, c.businessDescription, ct.codeTableId, ct.businessDescription, ct.codeTableName) FROM CodeValue c, CodeValueText t, CodeTable ct where c.codeValueId = t.codeValueId and c.codeTableId = ct.codeTableId and c.codeValueId in (:codeValueIds) and t.languageCode = :langCode and t.writingScriptCode = :writingScriptCode and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "CodeValue.retrieveGroupLevelCodes", query = "SELECT new CodeValue(c.codeTableId, c.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValue c, CodeValueText t, SystemApplicability s where c.codeValueId = t.codeValueId and c.codeValueId = s.codeValueId and c.codeTableId = :codeTableId and t.languageCode = :langCode and t.writingScriptCode = :writingScriptCode and s.dnbSystemCode = :dnbSystemCode and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "CodeValue.retrieveAllGeoUnitTypes",  query = "SELECT new CodeValue(c.codeTableId, c.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValue c, CodeValueText t where c.codeValueId = t.codeValueId and c.codeTableId = :codeTableId and t.languageCode = :languageCode and t.writingScriptCode = :writingScriptCode and t.expirationDate is null and c.codeValueId in (select codeValueId from SystemApplicability where dnbSystemCode=24291) order by t.codeValueDescription"),
	@NamedQuery(name = "CodeValue.findIndustryCodeValues", query = "SELECT distinct new CodeValue(c.codeTableId, c.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValue c, CodeValueText t, IndustryCode i where c.codeValueId = t.codeValueId and i.industryCodeTypeCode = t.codeValueId and c.codeTableId in (:codeTableId) and t.languageCode = :langCode and t.writingScriptCode = :writingScriptCode and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "CodeValue.retrieveApplicableGeoNameTypes", query = "SELECT new CodeValue(c.codeTableId, c.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValue c, CodeValueText t where c.codeValueId = t.codeValueId and c.codeTableId = :codeTableId and t.languageCode = :languageCode and t.writingScriptCode = :writingScriptCode and c.codeValueId in (select codeValueId from SystemApplicability where dnbSystemCode=24291) and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "CodeValue.retrieveGranularityForCapabilityTypeCode", query = "SELECT new CodeValue(c.codeTableId, c.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValue c, CodeValueText t where c.codeValueId = t.codeValueId and c.codeTableId in (477) and t.languageCode = 39 and t.expirationDate is null order by t.codeValueShortDescription"),
	@NamedQuery(name = "CodeValue.retrieveMktGrpCodes", query = "select new GeoUnitName(gu.geoUnitId,gun.geoName)FROM GeoUnit gu,GeoUnitName gun WHERE 1=1 and gu.geoUnitId=gun.geoUnitId and gun.languageCode=39 and gun.nameTypeCode=32 and gu.geoUnitTypeCode=130 and gu.expirationDate is null and gun.expirationDate is null "),
	@NamedQuery(name = "CodeValue.retrieveMetada", query = "Select distinct new CodeValue(sa.codeValueId,cvt.codeValueDescription) from SystemApplicability sa,CodeValueText cvt WHERE sa.dnbSystemCode = :crosswalkApplied AND sa.codeValueId=cvt.codeValueId and cvt.languageCode=39 AND sa.expirationDate IS NULL AND cvt.expirationDate IS NULL ")})
public class CodeValue extends Audit {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "CD_VAL_ID")
	private Long codeValueId;

	@Column(name = "CD_TBL_ID")
	private Integer codeTableId;

	@Column(name = "REAS_TXT")
	private String reasonText;

	@Column(name = "BUS_DESC")
	private String businessDescription;

	@Column(name = "REQ_ON_BHLF_OF_NME")
	private String onBehalfOfName;

	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "codeValueId")
	private List<CodeValueText> codeValueTexts;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "codeValueId")
	private List<CodeValueAlternateScheme> codeValueSchemes;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "childCodeValueId")
	private List<CodeValueAssociation> parentCodeValueAssociations;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "parentCodeValueId")
	private List<CodeValueAssociation> childCodeValueAssociations;

//	@JoinColumn(name = "CD_TBL_ID", referencedColumnName = "CD_TBL_ID", insertable = false, updatable = false)
//	@ManyToOne(cascade = CascadeType.ALL, optional = true)
//	private CodeTable codeTable;

	@Transient
	private String literalShortDescription;

	@Transient
	private String codeValueDescription;

	@Transient
	private String codeTableBusinessDescription;

	@Transient
	private String codeTableName;

	@Transient
	private List<SystemApplicability> systemApplicability;
	
	@Transient
	private List<CountryApplicability> countryApplicability;

	@Transient
	private List<String> systemList;

	@Transient
	private List<String> countryList;
	
	@Transient
	private String errorCode;
	
	@Transient
	private String cdValIdBulk;
	
	@Transient
	private Boolean isIntermediateSave;
	
	@Transient
	private String indicator;	
	
	@Transient
	private String stgBusinessDescription;
	
	@Transient
	private String stgReasonText;
	
	@Transient
	private String stgOnBehalfOfName;
	
	@Transient
	private List<SystemApplicability> stgSystemApplicability;
	
	@Transient
	private List<CountryApplicability> stgCountryApplicability;

	/**
	 * The default constructor
	 */
	public CodeValue() {
		super();
	}

	/**
	 *
	 * @param codeValueId
	 * @param codeValueDescription
	 * @param businessDescription
	 */
	public CodeValue(Long codeValueId, String codeValueDescription,
			String businessDescription) {
		super();
		this.codeValueId = codeValueId;
		this.codeValueDescription = codeValueDescription;
		this.businessDescription = businessDescription;
	}
	
	/**
	 *
	 * @param codeValueId
	 * @param codeValueDescription
	 * @param businessDescription
	 */
	public CodeValue(Long codeValueId, String codeValueDescription) {
		super();
		this.codeValueId = codeValueId;
		this.codeValueDescription = codeValueDescription;		
	}
	
	
	/**
	 * @param codeValueId
	 * @param codeTableId
	 * @param reasonText
	 * @param businessDescription
	 * @param onBehalfOfName
	 */
	public CodeValue(Long codeValueId, Integer codeTableId, String reasonText,
			String businessDescription, String onBehalfOfName) {
		this.codeValueId = codeValueId;
		this.codeTableId = codeTableId;
		this.reasonText = reasonText;
		this.businessDescription = businessDescription;
		this.onBehalfOfName = onBehalfOfName;
	}

	/**
	 * @param codeTableId
	 * @param codeValueId,
	 * @param literalShortDescription
	 * @param codeValueDescription
	 */
	public CodeValue(Integer codeTableId, Long codeValueId,
			String literalShortDescription, String codeValueDescription) {
		this.codeTableId = codeTableId;
		this.codeValueId = codeValueId;
		this.literalShortDescription = literalShortDescription;
		this.codeValueDescription = codeValueDescription;
	}

	/**
	 * @param codeValueId
	 * @param codeTableId
	 * @param businessDescription
	 * @param codeValueDescription
	 * @param codeTableBusinessDescription
	 * @param codeTableName
	 */
	public CodeValue(Long codeValueId, String codeValueDescription,
			String businessDescription, Long codeTableId,
			String codeTableBusinessDescription,
			String codeTableName) {
		this.codeValueId = codeValueId;
		this.codeTableId = codeTableId.intValue();
		this.businessDescription = businessDescription;
		this.codeValueDescription = codeValueDescription;
		this.codeTableBusinessDescription = codeTableBusinessDescription;
		this.codeTableName = codeTableName;
	}

	public List<SystemApplicability> getSystemApplicability() {
		return systemApplicability;
	}

	public void setSystemApplicability(List<SystemApplicability> systemApplicability) {
		this.systemApplicability = systemApplicability;
	}

	public List<CountryApplicability> getCountryApplicability() {
		return countryApplicability;
	}

	public void setCountryApplicability(
			List<CountryApplicability> countryApplicability) {
		this.countryApplicability = countryApplicability;
	}

	public List<String> getSystemList() {
		return systemList;
	}

	public void setSystemList(List<String> systemList) {
		this.systemList = systemList;
	}

	public List<String> getCountryList() {
		return countryList;
	}

	public void setCountryList(List<String> countryList) {
		this.countryList = countryList;
	}

	/**
	 * @return the reasonText
	 */
	public String getReasonText() {
		return reasonText;
	}

	/**
	 * @param reasonText the reasonText to set
	 */
	public void setReasonText(String reasonText) {
		this.reasonText = reasonText;
	}

	/**
	 * @return the businessDescription
	 */
	public String getBusinessDescription() {
		return businessDescription;
	}

	/**
	 * @param businessDescription the businessDescription to set
	 */
	public void setBusinessDescription(String businessDescription) {
		this.businessDescription = businessDescription;
	}

	/**
	 * @return the onBehalfOfName
	 */
	public String getOnBehalfOfName() {
		return onBehalfOfName;
	}

	/**
	 * @param onBehalfOfName the onBehalfOfName to set
	 */
	public void setOnBehalfOfName(String onBehalfOfName) {
		this.onBehalfOfName = onBehalfOfName;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the codeValueTexts
	 */
	public List<CodeValueText> getCodeValueTexts() {
		return codeValueTexts;
	}

	/**
	 * @param codeValueTexts the codeValueTexts to set
	 */
	public void setCodeValueTexts(List<CodeValueText> codeValueTexts) {
		this.codeValueTexts = codeValueTexts;
	}

	/**
	 * @return the literalShortDescription
	 */
	public String getLiteralShortDescription() {
		return literalShortDescription;
	}

	/**
	 * @param literalShortDescription the literalShortDescription to set
	 */
	public void setLiteralShortDescription(String literalShortDescription) {
		this.literalShortDescription = literalShortDescription;
	}

	/**
	 * @return the codeValueDescription
	 */
	public String getCodeValueDescription() {
		return codeValueDescription;
	}

	/**
	 * @param codeValueDescription the codeValueDescription to set
	 */
	public void setCodeValueDescription(String codeValueDescription) {
		this.codeValueDescription = codeValueDescription;
	}

	/**
	 * @return the codeTableBusinessDescription
	 */
	public String getCodeTableBusinessDescription() {
		return codeTableBusinessDescription;
	}

	/**
	 * @param codeTableBusinessDescription the codeTableBusinessDescription to set
	 */
	public void setCodeTableBusinessDescription(String codeTableBusinessDescription) {
		this.codeTableBusinessDescription = codeTableBusinessDescription;
	}

	/**
	 * @return the codeTableName
	 */
	public String getCodeTableName() {
		return codeTableName;
	}

	/**
	 * @param codeTableName the codeTableName to set
	 */
	public void setCodeTableName(String codeTableName) {
		this.codeTableName = codeTableName;
	}
//
//	/**
//	 * @return the codeTable
//	 */
//	public CodeTable getCodeTable() {
//		return codeTable;
//	}
//
//	/**
//	 * @param codeTable the codeTable to set
//	 */
//	public void setCodeTable(CodeTable codeTable) {
//		this.codeTable = codeTable;
//	}

	/**
	 * @return the codeValueSchemes
	 */
	public List<CodeValueAlternateScheme> getCodeValueSchemes() {
		return codeValueSchemes;
	}

	/**
	 * @param codeValueSchemes the codeValueSchemes to set
	 */
	public void setCodeValueSchemes(List<CodeValueAlternateScheme> codeValueSchemes) {
		this.codeValueSchemes = codeValueSchemes;
	}

	/**
	 * @return the parentCodeValueAssociations
	 */
	public List<CodeValueAssociation> getParentCodeValueAssociations() {
		return parentCodeValueAssociations;
	}

	/**
	 * @param parentCodeValueAssociations the parentCodeValueAssociations to set
	 */
	public void setParentCodeValueAssociations(
			List<CodeValueAssociation> parentCodeValueAssociations) {
		this.parentCodeValueAssociations = parentCodeValueAssociations;
	}

	/**
	 * @return the childCodeValueAssociations
	 */
	public List<CodeValueAssociation> getChildCodeValueAssociations() {
		return childCodeValueAssociations;
	}

	/**
	 * @param childCodeValueAssociations the childCodeValueAssociations to set
	 */
	public void setChildCodeValueAssociations(
			List<CodeValueAssociation> childCodeValueAssociations) {
		this.childCodeValueAssociations = childCodeValueAssociations;
	}


	/**
	 * @return the codeValueId
	 */
	public Long getCodeValueId() {
		return codeValueId;
	}
	/**
	 * @param codeValueId the codeValueId to set
	 */
	public void setCodeValueId(Long codeValueId) {
		this.codeValueId = codeValueId;
	}
	/**
	 * @return the codeTableId
	 */
	public Integer getCodeTableId() {
		return codeTableId;
	}
	/**
	 * @param codeTableId the codeTableId to set
	 */
	public void setCodeTableId(Integer codeTableId) {
		this.codeTableId = codeTableId;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}
	
	
	/**
	 * @return the cdValIdBulk
	 */
	public String getCdValIdBulk() {
		return cdValIdBulk;
	}

	/**
	 * @param cdValIdBulk the cdValIdBulk to set
	 */
	public void setCdValIdBulk(String cdValIdBulk) {
		this.cdValIdBulk = cdValIdBulk;
	}

	/**
	 * @return the isIntermediateSave
	 */
	public Boolean getIsIntermediateSave() {
		return isIntermediateSave;
	}

	/**
	 * @param isIntermediateSave the isIntermediateSave to set
	 */
	public void setIsIntermediateSave(Boolean isIntermediateSave) {
		this.isIntermediateSave = isIntermediateSave;
	}
	
	/**
	 * @return the indicator
	 */
	public String getIndicator() {
		return indicator;
	}

	/**
	 * @param indicator the indicator to set
	 */
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	/**
	 * @return the stgBusinessDescription
	 */
	public String getStgBusinessDescription() {
		return stgBusinessDescription;
	}

	/**
	 * @param stgBusinessDescription the stgBusinessDescription to set
	 */
	public void setStgBusinessDescription(String stgBusinessDescription) {
		this.stgBusinessDescription = stgBusinessDescription;
	}
	
	
	/**
	 * @return the stgReasonText
	 */
	public String getStgReasonText() {
		return stgReasonText;
	}

	/**
	 * @param stgReasonText the stgReasonText to set
	 */
	public void setStgReasonText(String stgReasonText) {
		this.stgReasonText = stgReasonText;
	}

	/**
	 * @return the stgOnBehalfOfName
	 */
	public String getStgOnBehalfOfName() {
		return stgOnBehalfOfName;
	}

	/**
	 * @param stgOnBehalfOfName the stgOnBehalfOfName to set
	 */
	public void setStgOnBehalfOfName(String stgOnBehalfOfName) {
		this.stgOnBehalfOfName = stgOnBehalfOfName;
	}

	@Override
	public String toString() {
		return "CodeValue [codeValueId=" + codeValueId + ", codeTableId="
				+ codeTableId + ", reasonText=" + reasonText
				+ ", businessDescription=" + businessDescription
				+ ", onBehalfOfName=" + onBehalfOfName 
				+ ", codeValueTexts=" + codeValueTexts + ", codeValueSchemes="
				+ codeValueSchemes + ", parentCodeValueAssociations="
				+ parentCodeValueAssociations + ", childCodeValueAssociations="
				+ childCodeValueAssociations //+ ", codeTable=" + codeTable
				+ ", literalShortDescription=" + literalShortDescription
				+ ", codeValueDescription=" + codeValueDescription
				+ ", codeTableBusinessDescription="
				+ codeTableBusinessDescription + ", codeTableName="
				+ codeTableName + ", systemApplicability="
				+ systemApplicability + ", countryApplicability="
				+ countryApplicability + ", systemList=" + systemList
				+ ", countryList=" + countryList + "]";
	}
}
