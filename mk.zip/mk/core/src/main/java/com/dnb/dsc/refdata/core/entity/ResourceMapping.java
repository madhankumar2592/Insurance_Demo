/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "RESC_MAP")
@NamedQueries({
	
	@NamedQuery(name = "ResourceMapping.retrieveResourceMappingId", query = "SELECT distinct(s.rescId) FROM ResourceMapping s where s.productId = :productId"),
	@NamedQuery(name = "ResourceMapping.retrieveAllResourceMappingId", query = "SELECT distinct new ResourceMapping(s.rescMapId,s.rescId) FROM ResourceMapping s where s.productId = :productId and s.rescId not in (:rescId)"),

	@NamedQuery(name = "ResourceMapping.removeRescMapById", query = "DELETE FROM ResourceMapping c where c.rescMapId  in ( :rescMapId)")

	
		})
public class ResourceMapping extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "RESC_MAP_ID")
	private Long rescMapId;
		
	@Column(name = "RESC_ID")
	private Long rescId;
	
	@Column(name = "PROD_ID")
	private Long productId;	
	
	public Long getRescMapId() {
		return rescMapId;
	}

	public void setRescMapId(Long rescMapId) {
		this.rescMapId = rescMapId;
	}

	public Long getRescId() {
		return rescId;
	}

	public void setRescId(Long rescId) {
		this.rescId = rescId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	/**
	 * Empty Constructor.
	 */
	public ResourceMapping() {
		super();
	}
	
	public ResourceMapping(Long rescMapId) {
		super();
		this.rescMapId = rescMapId;
	}
	/*public ResourceMapping(Long ResourceMappingVersion) {
		super();
		this.ResourceMappingVersion = ResourceMappingVersion;
	}*/
	public ResourceMapping(Long rescMapId, Long rescId) {
		super();
		this.rescMapId = rescMapId;
		this.rescId = rescId;
	}
	
	
	/**
	 * 
	 * @param ResourceMappingId
	 * @param ResourceMappingVersion
	 * @param ResourceMappingTypeId
	 * @param ResourceMappingMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public ResourceMapping(Long rescMapId, Long rescId, Long productId,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.rescMapId = rescMapId;
		this.rescId = rescId;
		this.productId = productId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ResourceMapping [rescMapId=" + rescMapId
				+ ", rescId=" + rescId 
				+ ",productId=" + productId + 
				  "]";
	}
	
	
}
