/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "PROD_RESC_TO_SCR_GRU")
@NamedQueries({	
	@NamedQuery(name = "ProdRescScrGru.removeProdRescScrGraById", query = "DELETE FROM ProdRescScrGru c where c.rescMapId  in ( :rescMapId)"),
	@NamedQuery(name = "ProdRescScrGru.retreiveProdRescScrGruId", query = "SELECT distinct(s.prodRescToScrGruId) FROM ProdRescScrGru s where s.scrDtlId in (:scrDtlId)"),
	@NamedQuery(name = "ProdRescScrGru.removeProdRescScrGruById", query = "DELETE FROM ProdRescScrGru c where c.prodRescToScrGruId  in ( :prodRescToScrGruId)"),
	@NamedQuery(name = "ProdRescScrGru.retreiveProdRescScrGruIdVal", query = "SELECT distinct(s.prodRescToScrGruId) FROM ProdRescScrGru s where s.scrDtlId not in (:scrDtlId) and s.rescMapId in (:rescMapId)"),
	@NamedQuery(name = "ProdRescScrGru.retreiveProdRescScrGranIdVal", query = "SELECT distinct(s.prodRescToScrGruId) FROM ProdRescScrGru s where s.rescMapId in (:rescMapId)"),
	@NamedQuery(name = "ProdRescScrGru.removeProdRescScrGruId", query = "DELETE FROM ProdRescScrGru c where c.prodRescToScrGruId  in ( :prodRescToScrGruId)")

})
public class ProdRescScrGru extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PROD_RESC_TO_SCR_GRU_ID")
	private Long prodRescToScrGruId;
		
	@Column(name = "RESC_MAP_ID")
	private Long rescMapId;
	
	@Column(name = "SCR_DTL_ID")
	private Long scrDtlId;
	
	public Long getProdRescToScrGruId() {
		return prodRescToScrGruId;
	}

	public void setProdRescToScrGruId(Long prodRescToScrGruId) {
		this.prodRescToScrGruId = prodRescToScrGruId;
	}

	public Long getRescMapId() {
		return rescMapId;
	}

	public void setRescMapId(Long rescMapId) {
		this.rescMapId = rescMapId;
	}

	public Long getScrDtlId() {
		return scrDtlId;
	}

	public void setScrDtlId(Long scrDtlId) {
		this.scrDtlId = scrDtlId;
	}

	/**
	 * Empty Constructor.
	 */
	public ProdRescScrGru() {
		super();
	}
	
	public ProdRescScrGru(Long prodRescToScrGruId) {
		super();
		this.prodRescToScrGruId = prodRescToScrGruId;
	}
	/*public Product(Long ProductVersion) {
		super();
		this.ProductVersion = ProductVersion;
	}*/
	public ProdRescScrGru(Long prodRescToScrGruId, Long rescMapId) {
		super();
		this.prodRescToScrGruId = prodRescToScrGruId;
		this.rescMapId = rescMapId;
	}
	
	
	/**
	 * 
	 * @param ProductId
	 * @param ProductVersion
	 * @param ProductTypeId
	 * @param ProductMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public ProdRescScrGru(Long prodRescToScrGruId, Long scrDtlId,Long rescMapId,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.prodRescToScrGruId = prodRescToScrGruId;
		this.rescMapId = rescMapId;
		this.scrDtlId = scrDtlId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ProdRescScrGru [prodRescToScrGruId=" + prodRescToScrGruId
				+ ", rescMapId=" + rescMapId 
				+"scrDtlId=" + scrDtlId+ 
				 "]";
	}
	
	
}
