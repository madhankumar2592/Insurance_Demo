package com.dnb.dsc.refdata.core.vo;

public class GlobalElementSearchVO extends PaginationVO{
	
	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	private Long globalElementId;
	private String globalElementTypeCode;
	private String globalElementTopicCategoryName;
	private String globalElementName;
	private String globalElementShortDescription;
	private String globalElementLongDescription;
	private String viewType;
	
	
	
	
	/**
	 * @param globalElementId
	 * @param globalElementTypeCode
	 * @param globalElementTopicCategoryName
	 * @param globalElementName
	 * @param globalElementShortDescription
	 * @param globalElementLongDescription
	 */
	public GlobalElementSearchVO(Long globalElementId,			
			String globalElementTopicCategoryName, String globalElementName,
			String globalElementShortDescription,
			String globalElementLongDescription) {		
		this.globalElementId = globalElementId;		
		this.globalElementTopicCategoryName = globalElementTopicCategoryName;
		this.globalElementName = globalElementName;
		this.globalElementShortDescription = globalElementShortDescription;
		this.globalElementLongDescription = globalElementLongDescription;
	}
	
	public GlobalElementSearchVO() {
		
	}
	/**
	 * @return the globalElementId
	 */
	public Long getGlobalElementId() {
		return globalElementId;
	}
	/**
	 * @param globalElementId the globalElementId to set
	 */
	public void setGlobalElementId(Long globalElementId) {
		this.globalElementId = globalElementId;
	}
	/**
	 * @return the globalElementTypeCode
	 */
	public String getGlobalElementTypeCode() {
		return globalElementTypeCode;
	}
	/**
	 * @param globalElementTypeCode the globalElementTypeCode to set
	 */
	public void setGlobalElementTypeCode(String globalElementTypeCode) {
		this.globalElementTypeCode = globalElementTypeCode;
	}
	/**
	 * @return the globalElementTopicCategoryName
	 */
	public String getGlobalElementTopicCategoryName() {
		return globalElementTopicCategoryName;
	}
	/**
	 * @param globalElementTopicCategoryName the globalElementTopicCategoryName to set
	 */
	public void setGlobalElementTopicCategoryName(
			String globalElementTopicCategoryName) {
		this.globalElementTopicCategoryName = globalElementTopicCategoryName;
	}
	/**
	 * @return the globalElementName
	 */
	public String getGlobalElementName() {
		return globalElementName;
	}
	/**
	 * @param globalElementName the globalElementName to set
	 */
	public void setGlobalElementName(String globalElementName) {
		this.globalElementName = globalElementName;
	}
	/**
	 * @return the globalElementShortDescription
	 */
	public String getGlobalElementShortDescription() {
		return globalElementShortDescription;
	}
	/**
	 * @param globalElementShortDescription the globalElementShortDescription to set
	 */
	public void setGlobalElementShortDescription(
			String globalElementShortDescription) {
		this.globalElementShortDescription = globalElementShortDescription;
	}
	/**
	 * @return the globalElementLongDescription
	 */
	public String getGlobalElementLongDescription() {
		return globalElementLongDescription;
	}
	/**
	 * @param globalElementLongDescription the globalElementLongDescription to set
	 */
	public void setGlobalElementLongDescription(String globalElementLongDescription) {
		this.globalElementLongDescription = globalElementLongDescription;
	}
	
	/**
	 * @param viewType the viewType to set
	 */
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	/**
	 * @return the viewType
	 */
	public String getViewType() {
		return viewType;
	}

	@Override
	public String toString() {
		return "GlobalElementSearchVO [globalElementId=" + globalElementId
				+ ", globalElementTopicCategoryName="
				+ globalElementTopicCategoryName + ", globalElementName=" + globalElementName
				+ ", globalElementShortDescription=" + globalElementShortDescription + ", globalElementLongDescription=" + globalElementLongDescription
				+ ", maxResults="
				+ maxResults + ", pageCount=" + pageCount + ", rowIndex="
				+ rowIndex + ", sortOrder=" + sortOrder + ", sortBy=" + sortBy
				+ "]";
	}	
	
}
