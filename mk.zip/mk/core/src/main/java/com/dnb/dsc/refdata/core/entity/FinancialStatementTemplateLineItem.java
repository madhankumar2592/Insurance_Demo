/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 *	Entity for finl_stmt_tmplt_ln_itm table
 *
 * @author Cognizant
 * @version last updated : June 14, 2012
 * @see
 *
 */
@Entity
@Table(name = "finl_stmt_tmplt_ln_itm")
@NamedQueries({
	@NamedQuery(name = "FinancialStatementTemplateLineItem.removeFinancialStatementTemplateLineItemById", query = "DELETE FinancialStatementTemplateLineItem l where l.financialStatementScheduleId = :financialStatementScheduleId")
})
public class FinancialStatementTemplateLineItem extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "FINL_STMT_TMPLT_LN_ITM_ID")
	private Long financialStatementTemplateLineItemId;

	@Column(name = "FINL_STMT_SCHE_ID")
	private Long financialStatementScheduleId;
	
	@Column(name = "FINL_STMT_LN_ITM_CD")
	private Long financialStatementLineItemCode;
	
	@Column(name = "EFFV_FROM_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveFromDate;

	@Column(name = "EFFV_TO_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveToDate;

	@Column(name = "LN_IM_SEQ_NBR")
	private Long lineItemSequenceNumber;
	
	@Column(name = "HDR_INDC")
	private boolean headerIndicator;
	
	@Column(name = "SZ_UNIT_EXMN_INDC")
	private Boolean sizeUnitExaminationIndicator;
	
	@Column(name = "LN_ITM_GRP_LVL")
	private Long lineItemGroupLevel;
	
	@Column(name = "LN_ITM_RL_ID")
	private String lineItemRelationId;
	
	@Column(name = "LN_ITM_NUM_SIGN_CD")
	private Long lineItemNumberSignCode;
	
	@OneToOne(optional = true, cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name="FINL_STMT_TMPLT_LN_ITM_ID")
	private FinancialStatementTemplateInternalLineItem financialStatementTemplateInternalLineItem;
	
	@OneToOne(optional = true, cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name="FINL_STMT_TMPLT_LN_ITM_ID")
	private FinancialStatementTemplateOwnerLineItem financialStatementTemplateOwnerLineItem;
	
	@Transient
	private String lineItemCodeDescription;
	
	@Transient
	private boolean header;
	
	public FinancialStatementTemplateLineItem(){

	}
	
	/**
	 * @return the effectiveFromDate
	 */
	public Date getEffectiveFromDate() {
		return effectiveFromDate;
	}

	/**
	 * @param effectiveFromDate the effectiveFromDate to set
	 */
	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	/**
	 * @return the effectiveToDate
	 */
	public Date getEffectiveToDate() {
		return effectiveToDate;
	}

	/**
	 * @param effectiveToDate the effectiveToDate to set
	 */
	public void setEffectiveToDate(Date effectiveToDate) {
		this.effectiveToDate = effectiveToDate;
	}

	/**
	 * @return the financialStatementTemplateLineItemId
	 */
	public Long getFinancialStatementTemplateLineItemId() {
		return financialStatementTemplateLineItemId;
	}

	/**
	 * @param financialStatementTemplateLineItemId the financialStatementTemplateLineItemId to set
	 */
	public void setFinancialStatementTemplateLineItemId(
			Long financialStatementTemplateLineItemId) {
		this.financialStatementTemplateLineItemId = financialStatementTemplateLineItemId;
	}

	/**
	 * @return the financialStatementScheduleId
	 */
	public Long getFinancialStatementScheduleId() {
		return financialStatementScheduleId;
	}

	/**
	 * @param financialStatementScheduleId the financialStatementScheduleId to set
	 */
	public void setFinancialStatementScheduleId(Long financialStatementScheduleId) {
		this.financialStatementScheduleId = financialStatementScheduleId;
	}

	/**
	 * @return the financialStatementLineItemCode
	 */
	public Long getFinancialStatementLineItemCode() {
		return financialStatementLineItemCode;
	}

	/**
	 * @param financialStatementLineItemCode the financialStatementLineItemCode to set
	 */
	public void setFinancialStatementLineItemCode(
			Long financialStatementLineItemCode) {
		this.financialStatementLineItemCode = financialStatementLineItemCode;
	}

	/**
	 * @return the lineItemSequenceNumber
	 */
	public Long getLineItemSequenceNumber() {
		return lineItemSequenceNumber;
	}

	/**
	 * @param lineItemSequenceNumber the lineItemSequenceNumber to set
	 */
	public void setLineItemSequenceNumber(Long lineItemSequenceNumber) {
		this.lineItemSequenceNumber = lineItemSequenceNumber;
	}

	/**
	 * @return the headerIndicator
	 */
	public boolean isHeaderIndicator() {
		return headerIndicator;
	}

	/**
	 * @param headerIndicator the headerIndicator to set
	 */
	public void setHeaderIndicator(boolean headerIndicator) {
		this.headerIndicator = headerIndicator;
	}

	/**
	 * @param sizeUnitExaminationIndicator the sizeUnitExaminationIndicator to set
	 */
	public void setSizeUnitExaminationIndicator(Boolean sizeUnitExaminationIndicator) {
		this.sizeUnitExaminationIndicator = sizeUnitExaminationIndicator;
	}

	/**
	 * @return the lineItemGroupLevel
	 */
	public Long getLineItemGroupLevel() {
		return lineItemGroupLevel;
	}

	/**
	 * @param lineItemGroupLevel the lineItemGroupLevel to set
	 */
	public void setLineItemGroupLevel(Long lineItemGroupLevel) {
		this.lineItemGroupLevel = lineItemGroupLevel;
	}

	/**
	 * @return the lineItemRelationId
	 */
	public String getLineItemRelationId() {
		return lineItemRelationId;
	}

	/**
	 * @param lineItemRelationId the lineItemRelationId to set
	 */
	public void setLineItemRelationId(String lineItemRelationId) {
		this.lineItemRelationId = lineItemRelationId;
	}

	/**
	 * @return the lineItemNumberSignCode
	 */
	public Long getLineItemNumberSignCode() {
		return lineItemNumberSignCode;
	}

	/**
	 * @param lineItemNumberSignCode the lineItemNumberSignCode to set
	 */
	public void setLineItemNumberSignCode(Long lineItemNumberSignCode) {
		this.lineItemNumberSignCode = lineItemNumberSignCode;
	}

	/**
	 * @return the financialStatementTemplateInternalLineItem
	 */
	public FinancialStatementTemplateInternalLineItem getFinancialStatementTemplateInternalLineItem() {
		return financialStatementTemplateInternalLineItem;
	}

	/**
	 * @param financialStatementTemplateInternalLineItem the financialStatementTemplateInternalLineItem to set
	 */
	public void setFinancialStatementTemplateInternalLineItem(
			FinancialStatementTemplateInternalLineItem financialStatementTemplateInternalLineItem) {
		this.financialStatementTemplateInternalLineItem = financialStatementTemplateInternalLineItem;
	}

	/**
	 * @return the financialStatementTemplateOwnerLineItem
	 */
	public FinancialStatementTemplateOwnerLineItem getFinancialStatementTemplateOwnerLineItem() {
		return financialStatementTemplateOwnerLineItem;
	}

	/**
	 * @param financialStatementTemplateOwnerLineItem the financialStatementTemplateOwnerLineItem to set
	 */
	public void setFinancialStatementTemplateOwnerLineItem(
			FinancialStatementTemplateOwnerLineItem financialStatementTemplateOwnerLineItem) {
		this.financialStatementTemplateOwnerLineItem = financialStatementTemplateOwnerLineItem;
	}

	public void setLineItemCodeDescription(String lineItemCodeDescription) {
		this.lineItemCodeDescription = lineItemCodeDescription;
	}

	public String getLineItemCodeDescription() {
		return lineItemCodeDescription;
	}

	public void setHeader(boolean header) {
		this.header = header;
	}

	public boolean isHeader() {
		return header;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FinancialStatementTemplateLineItem [financialStatementTemplateLineItemId="
				+ financialStatementTemplateLineItemId
				+ ", financialStatementScheduleId="
				+ financialStatementScheduleId
				+ ", financialStatementLineItemCode="
				+ financialStatementLineItemCode
				+ ", effectiveFromDate="
				+ effectiveFromDate
				+ ", effectiveToDate="
				+ effectiveToDate
				+ ", lineItemSequenceNumber="
				+ lineItemSequenceNumber
				+ ", headerIndicator="
				+ headerIndicator
				+ ", sizeUnitExaminationIndicator="
				+ sizeUnitExaminationIndicator
				+ ", lineItemGroupLevel="
				+ lineItemGroupLevel
				+ ", lineItemRelationId="
				+ lineItemRelationId
				+ ", lineItemNumberSignCode="
				+ lineItemNumberSignCode
				+ ", financialStatementTemplateInternalLineItem="
				+ financialStatementTemplateInternalLineItem
				+ ", financialStatementTemplateOwnerLineItem="
				+ financialStatementTemplateOwnerLineItem
				+ ", lineItemCodeDescription="
				+ lineItemCodeDescription
				+ ", header=" + header + "]";
	}

	/**
	 * @return the sizeUnitExaminationIndicator
	 */
	public Boolean getSizeUnitExaminationIndicator() {
		return sizeUnitExaminationIndicator;
	}

}
