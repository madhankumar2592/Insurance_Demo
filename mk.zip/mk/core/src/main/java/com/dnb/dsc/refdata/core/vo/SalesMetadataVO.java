package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;

import com.dnb.dsc.refdata.core.entity.Audit;

public class SalesMetadataVO extends Audit implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6051414025177733461L;
	
	
	private Long salesDtlId;
	/**
	 *  salesMetadataCode.
	 */
	private Long salesMetadataCode;
	/**
	 *  salesMetadataValue.
	 */
	private String salesMetadataValue;
	
	
	/**
	 * 
	 * @return salesMetadataCode
	 */
	public Long getSalesMetadataCode() {
		return salesMetadataCode;
	}
	
	/**
	 * 
	 * @param salesMetadataCode the salesMetadataCode to set
	 */
	public void setSalesMetadataCode(Long salesMetadataCode) {
		this.salesMetadataCode = salesMetadataCode;
	}
	/**
	 * 
	 * @return salesMetadataValue
	 */
	public String getSalesMetadataValue() {
		return salesMetadataValue;
	}
	/**
	 * 
	 * @param salesMetadataValue the salesMetadataValue to set
	 */
	public void setSalesMetadataValue(String salesMetadataValue) {
		this.salesMetadataValue = salesMetadataValue;
	}

	public Long getSalesDtlId() {
		return salesDtlId;
	}

	public void setSalesDtlId(Long salesDtlId) {
		this.salesDtlId = salesDtlId;
	}
	
	

}
