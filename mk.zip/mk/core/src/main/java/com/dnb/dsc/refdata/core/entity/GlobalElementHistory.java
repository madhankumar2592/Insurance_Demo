package com.dnb.dsc.refdata.core.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

@Entity
@Table(name = "GLBL_ELE_HIST")
public class GlobalElementHistory extends Audit {
	
	private static final long serialVersionUID = 2L;
		
	@Id
	@Column(name = "GLBL_ELE_HIST_ID")
	private Long globalElementHistoryId;

	@Column(name = "GLBL_ELE_ID")
	private Long globalElementId;
	
	@Column(name = "GLBL_ELE_TYP_CD")
	private Long globalElementTypeCode;

	@Column(name = "GLBL_ELE_TOPC_CATG_CD")
	private Long globalElementTopicCategoryCode;
	
	@Column(name = "GLBL_ELE_MTDT_CD")
	private Long globalElementMetadataCode;

	@Column(name = "GLBL_ELE_MTDT_VAL")
	private String globalElementMetadataValue;
	
	@Column(name = "GLBL_ELE_MTDT_DATA_TYP_CD")
	private Long globalElementMetadataTypeCode;
	
	@Column(name = "GLBL_ELE_MTDT_LANG_CD")
	private Long globalElementMetadataLangCode;
	
	@Column(name = "GLBL_ELE_NME")
	private String globalElementName;	

	@Column(name = "GLBL_ELE_EFFV_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "GLBL_ELE_EXPN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;
	
	@Column(name = "GLBL_ELE_CMNT")
	private String globalElementComment;
	
	@Column(name = "GLBL_ELE_DTL_CMNT")
	private String globalElementDetailComment;
	
	@Column(name = "GLBL_ELE_CW_CMNT")
	private String globalElementCWComment;
	
	@Column(name = "GLBL_ELE_HIST_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date globalElementHistoryDate;
	
	/**
	 * The default constructor
	 */
	public GlobalElementHistory() {
		super();
	}

	/**
	 * @param globalElementHistoryId the globalElementHistoryId to set
	 */
	public void setGlobalElementHistoryId(Long globalElementHistoryId) {
		this.globalElementHistoryId = globalElementHistoryId;
	}

	/**
	 * @return the globalElementHistoryId
	 */
	public Long getGlobalElementHistoryId() {
		return globalElementHistoryId;
	}

	/**
	 * @return the globalElementId
	 */
	public Long getGlobalElementId() {
		return globalElementId;
	}

	/**
	 * @param globalElementId the globalElementId to set
	 */
	public void setGlobalElementId(Long globalElementId) {
		this.globalElementId = globalElementId;
	}

	/**
	 * @return the globalElementTypeCode
	 */
	public Long getGlobalElementTypeCode() {
		return globalElementTypeCode;
	}

	/**
	 * @param globalElementTypeCode the globalElementTypeCode to set
	 */
	public void setGlobalElementTypeCode(Long globalElementTypeCode) {
		this.globalElementTypeCode = globalElementTypeCode;
	}

	/**
	 * @return the globalElementTopicCategoryCode
	 */
	public Long getGlobalElementTopicCategoryCode() {
		return globalElementTopicCategoryCode;
	}

	/**
	 * @param globalElementTopicCategoryCode the globalElementTopicCategoryCode to set
	 */
	public void setGlobalElementTopicCategoryCode(
			Long globalElementTopicCategoryCode) {
		this.globalElementTopicCategoryCode = globalElementTopicCategoryCode;
	}

	/**
	 * @return the globalElementMetadataCode
	 */
	public Long getGlobalElementMetadataCode() {
		return globalElementMetadataCode;
	}

	/**
	 * @param globalElementMetadataCode the globalElementMetadataCode to set
	 */
	public void setGlobalElementMetadataCode(Long globalElementMetadataCode) {
		this.globalElementMetadataCode = globalElementMetadataCode;
	}

	/**
	 * @return the globalElementMetadataValue
	 */
	public String getGlobalElementMetadataValue() {
		return globalElementMetadataValue;
	}

	/**
	 * @param globalElementMetadataValue the globalElementMetadataValue to set
	 */
	public void setGlobalElementMetadataValue(String globalElementMetadataValue) {
		this.globalElementMetadataValue = globalElementMetadataValue;
	}

	/**
	 * @return the globalElementMetadataTypeCode
	 */
	public Long getGlobalElementMetadataTypeCode() {
		return globalElementMetadataTypeCode;
	}

	/**
	 * @param globalElementMetadataTypeCode the globalElementMetadataTypeCode to set
	 */
	public void setGlobalElementMetadataTypeCode(Long globalElementMetadataTypeCode) {
		this.globalElementMetadataTypeCode = globalElementMetadataTypeCode;
	}

	/**
	 * @return the globalElementMetadataLangCode
	 */
	public Long getGlobalElementMetadataLangCode() {
		return globalElementMetadataLangCode;
	}

	/**
	 * @param globalElementMetadataLangCode the globalElementMetadataLangCode to set
	 */
	public void setGlobalElementMetadataLangCode(Long globalElementMetadataLangCode) {
		this.globalElementMetadataLangCode = globalElementMetadataLangCode;
	}

	/**
	 * @return the globalElementName
	 */
	public String getGlobalElementName() {
		return globalElementName;
	}

	/**
	 * @param globalElementName the globalElementName to set
	 */
	public void setGlobalElementName(String globalElementName) {
		this.globalElementName = globalElementName;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the globalElementComment
	 */
	public String getGlobalElementComment() {
		return globalElementComment;
	}

	/**
	 * @param globalElementComment the globalElementComment to set
	 */
	public void setGlobalElementComment(String globalElementComment) {
		this.globalElementComment = globalElementComment;
	}

	/**
	 * @return the globalElementDetailComment
	 */
	public String getGlobalElementDetailComment() {
		return globalElementDetailComment;
	}

	/**
	 * @param globalElementDetailComment the globalElementDetailComment to set
	 */
	public void setGlobalElementDetailComment(String globalElementDetailComment) {
		this.globalElementDetailComment = globalElementDetailComment;
	}

	/**
	 * @return the globalElementCWComment
	 */
	public String getGlobalElementCWComment() {
		return globalElementCWComment;
	}

	/**
	 * @param globalElementCWComment the globalElementCWComment to set
	 */
	public void setGlobalElementCWComment(String globalElementCWComment) {
		this.globalElementCWComment = globalElementCWComment;
	}

	/**
	 * @return the globalElementHistoryDate
	 */
	public Date getGlobalElementHistoryDate() {
		return globalElementHistoryDate;
	}

	/**
	 * @param globalElementHistoryDate the globalElementHistoryDate to set
	 */
	public void setGlobalElementHistoryDate(Date globalElementHistoryDate) {
		this.globalElementHistoryDate = globalElementHistoryDate;
	}
	

	


}
