/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.interceptor;

//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.annotation.Around;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Pointcut;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * <p>
 * This class is an intercepter which will automatically logs the entry , exit
 * and exception cases of all the classes under the configured packages in the
 * point cut pattern .
 * </p>
 * 
 * @author  Cognizant Technology Solutions
 * @version last updated : July 6, 2012
 * @see LoggingInterceptor 
 * 
 */
@Component
//@Aspect
public class LoggingInterceptor {

	/** The Constant LOG. */
	//private static final Logger LOGGER = LoggerFactory.getLogger(LoggingInterceptor.class);

	/**
	 * Pointcut method representing refdata package.
	 */
	/*@Pointcut("execution(public * com.dnb.dsc.refdata.web..*.*(..)) ||"
			+ " execution(public * com.dnb.dsc.refdata.service..*.*(..)) ||"
			+ " execution(public * com.dnb.dsc.refdata.dao..*.*(..)) ||"
			+ " execution(public * com.dnb.dsc.refdata.core..*.*(..))") */			
	public void refDataLoggerPointCut() {

	}

	/**
	 * Method to log the details of object.
	 *
	 * @param joinPoint the join point
	 * @return returnObject
	 * @throws Throwable the throwable
	 */
	/*@Around("refDataLoggerPointCut()")
	public Object newLog(ProceedingJoinPoint joinPoint) throws Throwable {

		Object returnObject = null;
		long t1 = System.currentTimeMillis();
		if (joinPoint.getArgs() == null) {
			LOGGER.debug("Entering class : "
					+ joinPoint.getTarget().getClass().getName()
					+ " | method : " + joinPoint.getSignature().getName());
		} else if (joinPoint.getArgs().length > 0) {
			LOGGER.debug("Entering class : "
					+ joinPoint.getTarget().getClass().getName()
					+ " | method : " + joinPoint.getSignature().getName()
					+ " | with arguments : " + joinPoint.getArgs()[0]);
		}
		returnObject = joinPoint.proceed();

		LOGGER.info("Exiting class : "
				+ joinPoint.getTarget().getClass().getName() + " | method : "
				+ joinPoint.getSignature().getName() + " | Time taken : "
				+ (System.currentTimeMillis() - t1) + " millisecond");
		return returnObject;
	}*/
}
