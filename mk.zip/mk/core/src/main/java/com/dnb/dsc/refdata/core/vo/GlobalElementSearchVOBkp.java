package com.dnb.dsc.refdata.core.vo;


public class GlobalElementSearchVOBkp extends PaginationVO{
	
	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	private Long globalElementId;
	private Long globalElementTypeCode;
	private Long globalElementTopicCategoryCode;
	private String globalElementName;
	private Long globalElementMetadataCode;
	private String globalElementMetadataValue;
	private String codeValueDescription;
	
	public GlobalElementSearchVOBkp(Long globalElementId,Long globalElementTopicCategoryCode,String codeValueDescription,
			String globalElementName,String globalElementMetadataValue){
		this.globalElementId = globalElementId;
		this.globalElementTopicCategoryCode = globalElementTopicCategoryCode;
		this.codeValueDescription = codeValueDescription;
		this.globalElementName = globalElementName;
		this.globalElementMetadataValue = globalElementMetadataValue;
	}
	
	public GlobalElementSearchVOBkp(){
		super();
	}
	
	/**
	 * @return the globalElementId
	 */
	public Long getGlobalElementId() {
		return globalElementId;
	}
	/**
	 * @param globalElementId the globalElementId to set
	 */
	public void setGlobalElementId(Long globalElementId) {
		this.globalElementId = globalElementId;
	}
	/**
	 * @return the globalElementTypeCode
	 */
	public Long getGlobalElementTypeCode() {
		return globalElementTypeCode;
	}
	/**
	 * @param globalElementTypeCode the globalElementTypeCode to set
	 */
	public void setGlobalElementTypeCode(Long globalElementTypeCode) {
		this.globalElementTypeCode = globalElementTypeCode;
	}
	/**
	 * @return the globalElementTopicCategoryCode
	 */
	public Long getGlobalElementTopicCategoryCode() {
		return globalElementTopicCategoryCode;
	}
	/**
	 * @param globalElementTopicCategoryCode the globalElementTopicCategoryCode to set
	 */
	public void setGlobalElementTopicCategoryCode(
			Long globalElementTopicCategoryCode) {
		this.globalElementTopicCategoryCode = globalElementTopicCategoryCode;
	}
	/**
	 * @return the globalElementName
	 */
	public String getGlobalElementName() {
		return globalElementName;
	}
	/**
	 * @param globalElementName the globalElementName to set
	 */
	public void setGlobalElementName(String globalElementName) {
		this.globalElementName = globalElementName;
	}
	/**
	 * @return the globalElementMetadataCode
	 */
	public Long getGlobalElementMetadataCode() {
		return globalElementMetadataCode;
	}
	/**
	 * @param globalElementMetadataCode the globalElementMetadataCode to set
	 */
	public void setGlobalElementMetadataCode(Long globalElementMetadataCode) {
		this.globalElementMetadataCode = globalElementMetadataCode;
	}
	/**
	 * @return the globalElementMetadataValue
	 */
	public String getGlobalElementMetadataValue() {
		return globalElementMetadataValue;
	}
	/**
	 * @param globalElementMetadataValue the globalElementMetadataValue to set
	 */
	public void setGlobalElementMetadataValue(String globalElementMetadataValue) {
		this.globalElementMetadataValue = globalElementMetadataValue;
	}
	/**
	 * @return the viewType
	 */
	public String getViewType() {
		return viewType;
	}
	/**
	 * @param viewType the viewType to set
	 */
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	/**
	 * @param codeValueDescription the codeValueDescription to set
	 */
	public void setCodeValueDescription(String codeValueDescription) {
		this.codeValueDescription = codeValueDescription;
	}

	/**
	 * @return the codeValueDescription
	 */
	public String getCodeValueDescription() {
		return codeValueDescription;
	}
	private String viewType;

}
