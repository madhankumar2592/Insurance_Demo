package com.dnb.dsc.refdata.core.vo;

import java.util.List;

public class ProductSearchVO extends PaginationVO{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8650955180401462612L;
	
	private Long marketCode;
	private Long productCode;
	private Long resourceCode;
	
	private String mkt_cd;
	private String product_cd;
	private String resc_cd;
	
	private List<Long> productList;

	private List<Long> marketCodeList;
	private List<Long> resourceList;
	
	private Long prodAvailId;
	private Long saleChnlid;
	private Long prodMktId;
	private Long mktCd;
	private Long prodId;
	private Long prodFamCd;
	private Long prodCd;
	private Long prodInacIndc;
	private Long prodVers;
	private Long rescMapId;
	private Long rescId;
	private Long bilgSysCd;
	private Long rescVers;
	private Long rescCd;
	private Long rescTypCd;
	private Long bilgSysTypCd;
	private Long countryCode;
	private String countryDesc;
	private Long productCod;
	private String prodCodeShrtDesc;
	private String prodCodeDesc;
	private Long rescCode;
	private String rescCodeShrtDesc;
	private String rescCodeDesc;
	
	private String exportIndc;
	
	private Long prodGrpId;
	private Long prodGrpCd;
	private Long prodDtlId;
	private Long prodDtlMtdtCd;
	private String prodDtlMtdCdVal;
	private Long mktGrpId;
	private Long mktGrpCd;
	private Long rescGrpId;
	private Long rescGrpCd;
	private Long rescDtlID;
	private Long rescDtlMtdtCd;
	private String rescMtdtVal;
	private Long slsChnlDtlID;
	private Long slsChnlDtlMtdtCd;
	private String slsChnlDtlMtdtVal;
	private String prodGrpCdShrtDesc;
	private String prodGrpCdDesc;
	private String prodDtlMtdtCdShrtDesc;
	private String prodDtlMtdtCdDesc;
	private String mktGrpCdShrtDesc;
	private String mktGrpCdDesc;
	private String rescGrpCdShrtDesc;
	private String rescGrpCdDesc;
	private String rescDtlMtdtCdShrtDesc;
	private String rescDtlMtdtCdDesc;
	private String slsChnlDtlMtdtCdShrtDesc;
	private String slsChnlDtlMtdtCdDesc;
	
	public Long getProdGrpId() {
		return prodGrpId;
	}
	public void setProdGrpId(Long prodGrpId) {
		this.prodGrpId = prodGrpId;
	}
	public Long getProdGrpCd() {
		return prodGrpCd;
	}
	public void setProdGrpCd(Long prodGrpCd) {
		this.prodGrpCd = prodGrpCd;
	}
	public Long getProdDtlId() {
		return prodDtlId;
	}
	public void setProdDtlId(Long prodDtlId) {
		this.prodDtlId = prodDtlId;
	}
	public Long getProdDtlMtdtCd() {
		return prodDtlMtdtCd;
	}
	public void setProdDtlMtdtCd(Long prodDtlMtdtCd) {
		this.prodDtlMtdtCd = prodDtlMtdtCd;
	}
	public String getProdDtlMtdCdVal() {
		return prodDtlMtdCdVal;
	}
	public void setProdDtlMtdCdVal(String prodDtlMtdCdVal) {
		this.prodDtlMtdCdVal = prodDtlMtdCdVal;
	}
	public Long getMktGrpId() {
		return mktGrpId;
	}
	public void setMktGrpId(Long mktGrpId) {
		this.mktGrpId = mktGrpId;
	}
	public Long getMktGrpCd() {
		return mktGrpCd;
	}
	public void setMktGrpCd(Long mktGrpCd) {
		this.mktGrpCd = mktGrpCd;
	}
	public Long getRescGrpId() {
		return rescGrpId;
	}
	public void setRescGrpId(Long rescGrpId) {
		this.rescGrpId = rescGrpId;
	}
	public Long getRescGrpCd() {
		return rescGrpCd;
	}
	public void setRescGrpCd(Long rescGrpCd) {
		this.rescGrpCd = rescGrpCd;
	}
	public Long getRescDtlID() {
		return rescDtlID;
	}
	public void setRescDtlID(Long rescDtlID) {
		this.rescDtlID = rescDtlID;
	}
	public Long getRescDtlMtdtCd() {
		return rescDtlMtdtCd;
	}
	public void setRescDtlMtdtCd(Long rescDtlMtdtCd) {
		this.rescDtlMtdtCd = rescDtlMtdtCd;
	}
	public String getRescMtdtVal() {
		return rescMtdtVal;
	}
	public void setRescMtdtVal(String rescMtdtVal) {
		this.rescMtdtVal = rescMtdtVal;
	}
	public Long getSlsChnlDtlID() {
		return slsChnlDtlID;
	}
	public void setSlsChnlDtlID(Long slsChnlDtlID) {
		this.slsChnlDtlID = slsChnlDtlID;
	}
	public Long getSlsChnlDtlMtdtCd() {
		return slsChnlDtlMtdtCd;
	}
	public void setSlsChnlDtlMtdtCd(Long slsChnlDtlMtdtCd) {
		this.slsChnlDtlMtdtCd = slsChnlDtlMtdtCd;
	}
	public String getSlsChnlDtlMtdtVal() {
		return slsChnlDtlMtdtVal;
	}
	public void setSlsChnlDtlMtdtVal(String slsChnlDtlMtdtVal) {
		this.slsChnlDtlMtdtVal = slsChnlDtlMtdtVal;
	}
	public String getProdGrpCdShrtDesc() {
		return prodGrpCdShrtDesc;
	}
	public void setProdGrpCdShrtDesc(String prodGrpCdShrtDesc) {
		this.prodGrpCdShrtDesc = prodGrpCdShrtDesc;
	}
	public String getProdGrpCdDesc() {
		return prodGrpCdDesc;
	}
	public void setProdGrpCdDesc(String prodGrpCdDesc) {
		this.prodGrpCdDesc = prodGrpCdDesc;
	}
	public String getProdDtlMtdtCdShrtDesc() {
		return prodDtlMtdtCdShrtDesc;
	}
	public void setProdDtlMtdtCdShrtDesc(String prodDtlMtdtCdShrtDesc) {
		this.prodDtlMtdtCdShrtDesc = prodDtlMtdtCdShrtDesc;
	}
	public String getProdDtlMtdtCdDesc() {
		return prodDtlMtdtCdDesc;
	}
	public void setProdDtlMtdtCdDesc(String prodDtlMtdtCdDesc) {
		this.prodDtlMtdtCdDesc = prodDtlMtdtCdDesc;
	}
	public String getMktGrpCdShrtDesc() {
		return mktGrpCdShrtDesc;
	}
	public void setMktGrpCdShrtDesc(String mktGrpCdShrtDesc) {
		this.mktGrpCdShrtDesc = mktGrpCdShrtDesc;
	}
	public String getMktGrpCdDesc() {
		return mktGrpCdDesc;
	}
	public void setMktGrpCdDesc(String mktGrpCdDesc) {
		this.mktGrpCdDesc = mktGrpCdDesc;
	}
	public String getRescGrpCdShrtDesc() {
		return rescGrpCdShrtDesc;
	}
	public void setRescGrpCdShrtDesc(String rescGrpCdShrtDesc) {
		this.rescGrpCdShrtDesc = rescGrpCdShrtDesc;
	}
	public String getRescGrpCdDesc() {
		return rescGrpCdDesc;
	}
	public void setRescGrpCdDesc(String rescGrpCdDesc) {
		this.rescGrpCdDesc = rescGrpCdDesc;
	}
	public String getRescDtlMtdtCdShrtDesc() {
		return rescDtlMtdtCdShrtDesc;
	}
	public void setRescDtlMtdtCdShrtDesc(String rescDtlMtdtCdShrtDesc) {
		this.rescDtlMtdtCdShrtDesc = rescDtlMtdtCdShrtDesc;
	}
	public String getRescDtlMtdtCdDesc() {
		return rescDtlMtdtCdDesc;
	}
	public void setRescDtlMtdtCdDesc(String rescDtlMtdtCdDesc) {
		this.rescDtlMtdtCdDesc = rescDtlMtdtCdDesc;
	}
	public String getSlsChnlDtlMtdtCdShrtDesc() {
		return slsChnlDtlMtdtCdShrtDesc;
	}
	public void setSlsChnlDtlMtdtCdShrtDesc(String slsChnlDtlMtdtCdShrtDesc) {
		this.slsChnlDtlMtdtCdShrtDesc = slsChnlDtlMtdtCdShrtDesc;
	}
	public String getSlsChnlDtlMtdtCdDesc() {
		return slsChnlDtlMtdtCdDesc;
	}
	public void setSlsChnlDtlMtdtCdDesc(String slsChnlDtlMtdtCdDesc) {
		this.slsChnlDtlMtdtCdDesc = slsChnlDtlMtdtCdDesc;
	}
	public String getExportIndc() {
		return exportIndc;
	}
	public void setExportIndc(String exportIndc) {
		this.exportIndc = exportIndc;
	}
	public Long getProdAvailId() {
		return prodAvailId;
	}
	public void setProdAvailId(Long prodAvailId) {
		this.prodAvailId = prodAvailId;
	}
	public Long getSaleChnlid() {
		return saleChnlid;
	}
	public void setSaleChnlid(Long saleChnlid) {
		this.saleChnlid = saleChnlid;
	}
	public Long getProdMktId() {
		return prodMktId;
	}
	public void setProdMktId(Long prodMktId) {
		this.prodMktId = prodMktId;
	}
	public Long getMktCd() {
		return mktCd;
	}
	public void setMktCd(Long mktCd) {
		this.mktCd = mktCd;
	}
	public Long getProdId() {
		return prodId;
	}
	public void setProdId(Long prodId) {
		this.prodId = prodId;
	}
	public Long getProdFamCd() {
		return prodFamCd;
	}
	public void setProdFamCd(Long prodFamCd) {
		this.prodFamCd = prodFamCd;
	}
	public Long getProdCd() {
		return prodCd;
	}
	public void setProdCd(Long prodCd) {
		this.prodCd = prodCd;
	}
	public Long getProdInacIndc() {
		return prodInacIndc;
	}
	public void setProdInacIndc(Long prodInacIndc) {
		this.prodInacIndc = prodInacIndc;
	}
	public Long getProdVers() {
		return prodVers;
	}
	public void setProdVers(Long prodVers) {
		this.prodVers = prodVers;
	}
	public Long getRescMapId() {
		return rescMapId;
	}
	public void setRescMapId(Long rescMapId) {
		this.rescMapId = rescMapId;
	}
	public Long getRescId() {
		return rescId;
	}
	public void setRescId(Long rescId) {
		this.rescId = rescId;
	}
	public Long getBilgSysCd() {
		return bilgSysCd;
	}
	public void setBilgSysCd(Long bilgSysCd) {
		this.bilgSysCd = bilgSysCd;
	}
	public Long getRescVers() {
		return rescVers;
	}
	public void setRescVers(Long rescVers) {
		this.rescVers = rescVers;
	}
	public Long getRescCd() {
		return rescCd;
	}
	public void setRescCd(Long rescCd) {
		this.rescCd = rescCd;
	}
	public Long getRescTypCd() {
		return rescTypCd;
	}
	public void setRescTypCd(Long rescTypCd) {
		this.rescTypCd = rescTypCd;
	}
	public Long getBilgSysTypCd() {
		return bilgSysTypCd;
	}
	public void setBilgSysTypCd(Long bilgSysTypCd) {
		this.bilgSysTypCd = bilgSysTypCd;
	}
	public Long getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(Long countryCode) {
		this.countryCode = countryCode;
	}
	public String getCountryDesc() {
		return countryDesc;
	}
	public void setCountryDesc(String countryDesc) {
		this.countryDesc = countryDesc;
	}
	public Long getProductCod() {
		return productCod;
	}
	public void setProductCod(Long productCod) {
		this.productCod = productCod;
	}
	public String getProdCodeShrtDesc() {
		return prodCodeShrtDesc;
	}
	public void setProdCodeShrtDesc(String prodCodeShrtDesc) {
		this.prodCodeShrtDesc = prodCodeShrtDesc;
	}
	public String getProdCodeDesc() {
		return prodCodeDesc;
	}
	public void setProdCodeDesc(String prodCodeDesc) {
		this.prodCodeDesc = prodCodeDesc;
	}
	public Long getRescCode() {
		return rescCode;
	}
	public void setRescCode(Long rescCode) {
		this.rescCode = rescCode;
	}
	public String getRescCodeShrtDesc() {
		return rescCodeShrtDesc;
	}
	public void setRescCodeShrtDesc(String rescCodeShrtDesc) {
		this.rescCodeShrtDesc = rescCodeShrtDesc;
	}
	public String getRescCodeDesc() {
		return rescCodeDesc;
	}
	public void setRescCodeDesc(String rescCodeDesc) {
		this.rescCodeDesc = rescCodeDesc;
	}
	public String getMkt_cd() {
		return mkt_cd;
	}
	public void setMkt_cd(String mkt_cd) {
		this.mkt_cd = mkt_cd;
	}
	public String getProduct_cd() {
		return product_cd;
	}
	public void setProduct_cd(String product_cd) {
		this.product_cd = product_cd;
	}
	public String getResc_cd() {
		return resc_cd;
	}
	public void setResc_cd(String resc_cd) {
		this.resc_cd = resc_cd;
	}
	public Long getMarketCode() {
		return marketCode;
	}
	public void setMarketCode(Long marketCode) {
		this.marketCode = marketCode;
	}
	public Long getProductCode() {
		return productCode;
	}
	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}
	public Long getResourceCode() {
		return resourceCode;
	}
	public void setResourceCode(Long resourceCode) {
		this.resourceCode = resourceCode;
	}
	public List<Long> getMarketCodeList() {
		return marketCodeList;
	}
	public void setMarketCodeList(List<Long> marketCodeList) {
		this.marketCodeList = marketCodeList;
	}
	public List<Long> getProductList() {
		return productList;
	}
	public void setProductList(List<Long> productList) {
		this.productList = productList;
	}
	public List<Long> getResourceList() {
		return resourceList;
	}
	public void setResourceList(List<Long> resourceList) {
		this.resourceList = resourceList;
	}
}
