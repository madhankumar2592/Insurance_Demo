/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

/**
 * This class used as an value object class for the ControlWordsBulkDownloadVO.
 * The class will store the code values for all the Control Words Bulk Download
 * elements.
 * 
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 * 
 */
public class ControlWordsBulkDownloadVO {
	
	private String[] countryList;
	private String[] languageList;
	private String fileType;
	private Long uiBlkDwnldId;
	private String ctrlWrdsDownLoadFileName;	
	
	
	
	/**
	 * @return the countryList
	 */
	public String[] getCountryList() {
		return countryList;
	}
	/**
	 * @param countryList the countryList to set
	 */
	public void setCountryList(String[] countryList) {
		this.countryList = countryList;
	}
	/**
	 * @return the languageList
	 */
	public String[] getLanguageList() {
		return languageList;
	}
	/**
	 * @param languageList the languageList to set
	 */
	public void setLanguageList(String[] languageList) {
		this.languageList = languageList;
	}
	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}
	/**
	 * @param uiBlkDwnldId the uiBlkDwnldId to set
	 */
	public void setUiBlkDwnldId(Long uiBlkDwnldId) {
		this.uiBlkDwnldId = uiBlkDwnldId;
	}
	/**
	 * @return the uiBlkDwnldId
	 */
	public Long getUiBlkDwnldId() {
		return uiBlkDwnldId;
	}
	/**
	 * @param ctrlWrdsDownLoadFileName the ctrlWrdsDownLoadFileName to set
	 */
	public void setCtrlWrdsDownLoadFileName(String ctrlWrdsDownLoadFileName) {
		this.ctrlWrdsDownLoadFileName = ctrlWrdsDownLoadFileName;
	}
	/**
	 * @return the ctrlWrdsDownLoadFileName
	 */
	public String getCtrlWrdsDownLoadFileName() {
		return ctrlWrdsDownLoadFileName;
	}
	
	

}
