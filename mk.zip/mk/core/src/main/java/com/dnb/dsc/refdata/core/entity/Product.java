/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "PROD")
@NamedQueries({
	@NamedQuery(name = "Product.retreiveProductTypeCodeValues", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT distinct(d.productCode) FROM Product d WHERE d.productCode is not null) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "Product.findProductVersionForProductCode", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT distinct p.productVersion FROM Product p WHERE p.productCode is not null and p.productCode=:productCode) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "Product.findProductCodeValues", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT distinct p.productCode FROM Product p WHERE p.productCode is not null) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "Product.findProductFamCodeValues", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT distinct p.productFamCode FROM Product p WHERE p.productCode is not null and p.productCode=:prodCode) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "Product.retreiveProdVersion", query = "select new Product(s.productVersion) from Product s where s.productVersion is not null and s.productCode =:prodCode order by s.modifiedDate desc"),
	@NamedQuery(name = "Product.retreiveProdFamVersion", query = "select new Product(s.productVersion) from Product s where s.productVersion is not null and s.productCode =:prodCode and s.productFamCode =:famCode order by s.modifiedDate desc")
		})
public class Product extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PROD_ID")
	private Long productId;
		
	@Column(name = "PROD_FAM_CD")
	private Long productFamCode;
	
	@Column(name = "PROD_CD")
	private Long productCode;
	
	@Column(name = "INAC_INDC")
	private Long inactiveIndicator;	
	
	@Column(name = "PROD_VERS")
	private Long productVersion;


	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getProductFamCode() {
		return productFamCode;
	}

	public void setProductFamCode(Long productFamCode) {
		this.productFamCode = productFamCode;
	}

	public Long getProductCode() {
		return productCode;
	}

	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}

	public Long getInactiveIndicator() {
		return inactiveIndicator;
	}

	public void setInactiveIndicator(Long inactiveIndicator) {
		this.inactiveIndicator = inactiveIndicator;
	}

	public Long getProductVersion() {
		return productVersion;
	}

	public void setProductVersion(Long productVersion) {
		this.productVersion = productVersion;
	}

	/**
	 * Empty Constructor.
	 */
	public Product() {
		super();
	}
	
	public Product(Long productVersion) {
		super();
		this.productVersion = productVersion;
	}
	/*public Product(Long ProductVersion) {
		super();
		this.ProductVersion = ProductVersion;
	}*/
	public Product(Long productId, Long productFamCode) {
		super();
		this.productId = productId;
		this.productFamCode = productFamCode;
	}
	
	
	/**
	 * 
	 * @param ProductId
	 * @param ProductVersion
	 * @param ProductTypeId
	 * @param ProductMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public Product(Long productId, Long productFamCode, Long productCode, Long inactiveIndicator,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate, Long productVersion
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.productId = productId;
		this.productFamCode = productFamCode;
		this.productCode = productCode;
		this.inactiveIndicator = inactiveIndicator;
		this.productVersion = productVersion;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Product [productId=" + productId
				+ ", productFamCode=" + productFamCode 
				+"productCode=" + productCode+ 
				"inactiveIndicator=" + inactiveIndicator + 
				", productVersion=" + productVersion + 
				 "]";
	}
	
	
}
