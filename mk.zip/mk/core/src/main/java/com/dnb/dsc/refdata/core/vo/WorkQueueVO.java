/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;

import org.springframework.stereotype.Component;

/**
 * This class used as an value object class.
 * 
 * @author Cognizant
 * @version last updated : Dec 09, 2011
 * @see
 * 
 */
@Component
public class WorkQueueVO implements Serializable {

	private static final long serialVersionUID = 2L;

	private String sourceQueue;
	private String domainId;
	private Long trackingId;	
	private Long taskId;
	private String taskStatus;
	private String approverId;
	private String submitterId;
	private String domainName;
	private Long changeType;
	private String notes;
	private String requestSubmittedDate;
	private String requestStatus;
	private String rejectedReason;
	private String rejectedDate;
	private String fileName;
	private int submitterRoleId;
	private int submitterGroupId;
	private String changeTypeDescription;
	private String requestServicedDate;
	/* Added for batch componenet*/
	private String namingUrl;
	private String queueName;
	private String connectionFactry;

	/**
	 * Constructor
	 */
	public WorkQueueVO() {
		super();
	}
	
	public WorkQueueVO(	
			Long trackingId,	
			String domainId,	
			Long taskId,
			String taskStatus,
			String approverId,
			String submitterId,
			String domainName,
			Long changeType,
			String notes,
			String requestSubmittedDate,
			String requestStatus,
			String rejectedReason,
			String rejectedDate,
			int submitterRoleId,
			int submitterGroupId,
			String changeTypeDescription){
		
		this.trackingId=trackingId;
		this.domainId=domainId;
		this.taskId = taskId;
		this.taskStatus = taskStatus;
		this.approverId = approverId;
		this.submitterId = submitterId;
		this.domainName = domainName;
		this.changeType = changeType;
		this.notes = notes;
		this.requestSubmittedDate = requestSubmittedDate;
		this.requestStatus = requestStatus;
		this.rejectedReason = rejectedReason;
		this.rejectedDate = rejectedDate;
		this.submitterRoleId = submitterRoleId;
		this.submitterGroupId = submitterGroupId;
		this.changeTypeDescription = changeTypeDescription;
	}
	
	public WorkQueueVO(String namingUrl, String queueName,
			String connectionFactry) {
		
		this.setNamingUrl(namingUrl);
		this.setQueueName(queueName);
		this.setConnectionFactry(connectionFactry);
	}


	/**
	 * @return the domainId
	 */
	public String getDomainId() {
		return domainId;
	}

	/**
	 * @param domainId the domainId to set
	 */
	public void setDomainId(String domainId) {
		this.domainId = domainId;
	}

	/**
	 * @return the taskId
	 */
	public Long getTaskId() {
		return taskId;
	}

	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	/**
	 * @return the taskStatus
	 */
	public String getTaskStatus() {
		return taskStatus;
	}

	/**
	 * @param taskStatus the taskStatus to set
	 */
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	/**
	 * @return the approverId
	 */
	public String getApproverId() {
		return approverId;
	}

	/**
	 * @param approverId the approverId to set
	 */
	public void setApproverId(String approverId) {
		this.approverId = approverId;
	}

	/**
	 * @return the submitterId
	 */
	public String getSubmitterId() {
		return submitterId;
	}

	/**
	 * @param submitterId the submitterId to set
	 */
	public void setSubmitterId(String submitterId) {
		this.submitterId = submitterId;
	}

	/**
	 * @return the domainName
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * @param domainName the domainName to set
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @return the requestType
	 */
	public Long getChangeType() {
		return changeType;
	}

	/**
	 * @param requestType the requestType to set
	 */
	public void setChangeType(Long changeType) {
		this.changeType = changeType;
	}

	/**
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}

	/**
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}

	/**
	 * @return the requestSubmitDate
	 */
	public String getRequestSubmittedDate() {
		return requestSubmittedDate;
	}

	/**
	 * @param requestSubmitDate the requestSubmitDate to set
	 */
	public void setRequestSubmittedDate(String requestSubmittedDate) {
		this.requestSubmittedDate = requestSubmittedDate;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the requestStatus
	 */
	public String getRequestStatus() {
		return requestStatus;
	}

	/**
	 * @param requestStatus the requestStatus to set
	 */
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	/**
	 * @return the rejectReason
	 */
	public String getRejectedReason() {
		return rejectedReason;
	}

	/**
	 * @param rejectReason the rejectReason to set
	 */
	public void setRejectedReason(String rejectedReason) {
		this.rejectedReason = rejectedReason;
	}

	/**
	 * @return the rejectedDate
	 */
	public String getRejectedDate() {
		return rejectedDate;
	}

	/**
	 * @param rejectedDate the rejectedDate to set
	 */
	public void setRejectedDate(String rejectedDate) {
		this.rejectedDate = rejectedDate;
	}
	
	/**
	 * @return the submitterRoleId
	 */
	public int getSubmitterRoleId() {
		return submitterRoleId;
	}

	/**
	 * @param submitterRoleId the submitterRoleId to set
	 */
	public void setSubmitterRoleId(int submitterRoleId) {
		this.submitterRoleId = submitterRoleId;
	}

	/**
	 * @return the submitterGroupId
	 */
	public int getSubmitterGroupId() {
		return submitterGroupId;
	}

	/**
	 * @param submitterGroupId the submitterGroupId to set
	 */
	public void setSubmitterGroupId(int submitterGroupId) {
		this.submitterGroupId = submitterGroupId;
	}
	
	/**
	 * @return the trackingId
	 */
	public Long getTrackingId() {
		return trackingId;
	}

	/**
	 * @param trackingId the trackingId to set
	 */
	public void setTrackingId(Long trackingId) {
		this.trackingId = trackingId;
	}

	/**
	 * @return the changeTypeDescription
	 */
	public String getChangeTypeDescription() {
		return changeTypeDescription;
	}

	/**
	 * @param changeTypeDescription the changeTypeDescription to set
	 */
	public void setChangeTypeDescription(String changeTypeDescription) {
		this.changeTypeDescription = changeTypeDescription;
	}

	/**
	 * @return the sourceQueue
	 */
	public String getSourceQueue() {
		return sourceQueue;
	}

	/**
	 * @param sourceQueue the sourceQueue to set
	 */
	public void setSourceQueue(String sourceQueue) {
		this.sourceQueue = sourceQueue;
	}
	/**
	 * @param namingUrl the namingUrl to set
	 */
	public void setNamingUrl(String namingUrl) {
		this.namingUrl = namingUrl;
	}

	/**
	 * @return the namingUrl
	 */
	public String getNamingUrl() {
		return namingUrl;
	}

	/**
	 * @param queueName the queueName to set
	 */
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	/**
	 * @return the queueName
	 */
	public String getQueueName() {
		return queueName;
	}

	/**
	 * @param connectionFactry the connectionFactry to set
	 */
	public void setConnectionFactry(String connectionFactry) {
		this.connectionFactry = connectionFactry;
	}

	/**
	 * @return the connectionFactry
	 */
	public String getConnectionFactry() {
		return connectionFactry;
	}

	/**
	 * @return the requestServicedDate
	 */
	public String getRequestServicedDate() {
		return requestServicedDate;
	}

	/**
	 * @param requestServicedDate the requestServicedDate to set
	 */
	public void setRequestServicedDate(String requestServicedDate) {
		this.requestServicedDate = requestServicedDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WorkQueueVO [sourceQueue=" + sourceQueue + ", domainId="
				+ domainId + ", trackingId=" + trackingId + ", taskId="
				+ taskId + ", taskStatus=" + taskStatus + ", approverId="
				+ approverId + ", submitterId=" + submitterId + ", domainName="
				+ domainName + ", changeType=" + changeType + ", notes="
				+ notes + ", requestSubmittedDate=" + requestSubmittedDate
				+ ", requestStatus=" + requestStatus + ", rejectedReason="
				+ rejectedReason + ", rejectedDate=" + rejectedDate
				+ ", fileName=" + fileName + ", submitterRoleId="
				+ submitterRoleId + ", submitterGroupId=" + submitterGroupId
				+ ", changeTypeDescription=" + changeTypeDescription
				+ ", requestServicedDate=" + requestServicedDate
				+ ", namingUrl=" + namingUrl + ", queueName=" + queueName
				+ ", connectionFactry=" + connectionFactry + "]";
	}	
}
