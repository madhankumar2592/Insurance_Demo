package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import javax.persistence.NamedQuery;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "GLBL_ELE_CROSS_WALK")
@NamedQueries({
		@NamedQuery(name = "GloblalElementCrossWalk.retrievePlatformList", query = "SELECT distinct cw.globalElementPlatformCode,cvt.codeValueDescription,count(distinct cw.globalElementId) FROM GloblalElementCrossWalk cw,CodeValueText cvt where cw.globalElementPlatformCode=cvt.codeValueId and cvt.expirationDate is null group by cw.globalElementPlatformCode,cvt.codeValueDescription "),
		@NamedQuery(name = "GloblalElementCrossWalk.deleteCrosswalk", query = "delete from GloblalElementCrossWalk where globalElementId=:globalElementId")		
		})
public class GloblalElementCrossWalk extends Audit implements Serializable {
	
	private static final long serialVersionUID = 2L;
	
	@Id
	@Column(name = "GLBL_ELE_CW_ID")
	private Long globalElementCrosswalkId;

	@Column(name = "GLBL_ELE_ID")
	private Long globalElementId;
	
	@Column(name = "GLBL_ELE_MTDT_CD")
	private Long globalElementMetadataCode;

	@Column(name = "GLBL_ELE_MTDT_VAL")
	private String globalElementMetadataValue;
	
	@Column(name = "GLBL_ELE_CW_CMNT")
	private String globalElementCrosswalkCommnet;
	
	@Column(name = "GLBL_ELE_PLFM_CD")
	private Long globalElementPlatformCode;
	
	@Column(name = "GLBL_ELE_CW_GRPG_NME")
	private String globalElementCrosswalkGrpNme;
	
	@Transient
	private Long elementsCount;
	
	@Transient
	private String globalElementMetadataCodeDescription;
	
	@Transient
	private Long globalElementTypeCode;
	
	@Transient
	private String globalElementPlatformCodeDescription;	
	
	@Transient
	private String globalElementTypeCodeDescription;
	
	@Transient
	private String changeIndicator;
	
	public GloblalElementCrossWalk(Long globalElementId,Long globalElementCrosswalkId, Long globalElementMetadataCode,
			String globalElementMetadataCodeDescription,String globalElementMetadataValue,Long globalElementPlatformCode,
			String globalElementPlatformCodeDescription, String globalElementCrosswalkGrpNme){
		this.globalElementId = globalElementId;
		this.globalElementCrosswalkId =globalElementCrosswalkId;
		this.globalElementMetadataCode = globalElementMetadataCode; //NV
		this.globalElementMetadataCodeDescription = globalElementMetadataCodeDescription;
		this.globalElementMetadataValue = globalElementMetadataValue;
		this.globalElementPlatformCode = globalElementPlatformCode; //NV
		this.globalElementPlatformCodeDescription = globalElementPlatformCodeDescription; //NV
		this.globalElementCrosswalkGrpNme = globalElementCrosswalkGrpNme; 
		
	}
	public GloblalElementCrossWalk(Long globalElementId,Long globalElementCrosswalkId, Long globalElementMetadataCode,
			String globalElementMetadataCodeDescription,String globalElementMetadataValue,Long globalElementPlatformCode,
			String globalElementPlatformCodeDescription,Long globalElementTypeCode,String globalElementTypeCodeDescription){
			this.globalElementId = globalElementId;
			this.globalElementCrosswalkId =globalElementCrosswalkId;
			this.globalElementMetadataCode = globalElementMetadataCode; //NV
			this.globalElementMetadataCodeDescription = globalElementMetadataCodeDescription;
			this.globalElementMetadataValue = globalElementMetadataValue;
			this.globalElementPlatformCode = globalElementPlatformCode; //NV
			this.globalElementPlatformCodeDescription = globalElementPlatformCodeDescription; //NV
			this.globalElementTypeCode = globalElementTypeCode;
			this.globalElementTypeCodeDescription = globalElementTypeCodeDescription; //NV
	}
	public GloblalElementCrossWalk(Long globalElementId){
			this.globalElementId = globalElementId;
	}
	/**
	 * @return the globalElementCrosswalkGrpNme
	 */
	public String getGlobalElementCrosswalkGrpNme() {
		return globalElementCrosswalkGrpNme;
	}

	/**
	 * @param globalElementCrosswalkGrpNme the globalElementCrosswalkGrpNme to set
	 */
	public void setGlobalElementCrosswalkGrpNme(String globalElementCrosswalkGrpNme) {
		this.globalElementCrosswalkGrpNme = globalElementCrosswalkGrpNme;
	}

	public GloblalElementCrossWalk(){
		 super();
	 }
	/**
	 * @return the globalElementCrosswalkId
	 */
	public Long getGlobalElementCrosswalkId() {
		return globalElementCrosswalkId;
	}

	/**
	 * @param globalElementCrosswalkId the globalElementCrosswalkId to set
	 */
	public void setGlobalElementCrosswalkId(Long globalElementCrosswalkId) {
		this.globalElementCrosswalkId = globalElementCrosswalkId;
	}

	/**
	 * @return the globalElementId
	 */
	public Long getGlobalElementId() {
		return globalElementId;
	}

	/**
	 * @param globalElementId the globalElementId to set
	 */
	public void setGlobalElementId(Long globalElementId) {
		this.globalElementId = globalElementId;
	}

	/**
	 * @return the globalElementMetadataCode
	 */
	public Long getGlobalElementMetadataCode() {
		return globalElementMetadataCode;
	}

	/**
	 * @param globalElementMetadataCode the globalElementMetadataCode to set
	 */
	public void setGlobalElementMetadataCode(Long globalElementMetadataCode) {
		this.globalElementMetadataCode = globalElementMetadataCode;
	}

	/**
	 * @return the globalElementMetadataValue
	 */
	public String getGlobalElementMetadataValue() {
		return globalElementMetadataValue;
	}

	/**
	 * @param globalElementMetadataValue the globalElementMetadataValue to set
	 */
	public void setGlobalElementMetadataValue(String globalElementMetadataValue) {
		this.globalElementMetadataValue = globalElementMetadataValue;
	}

	/**
	 * @return the globalElementCrosswalkCommnet
	 */
	public String getGlobalElementCrosswalkCommnet() {
		return globalElementCrosswalkCommnet;
	}

	/**
	 * @param globalElementCrosswalkCommnet the globalElementCrosswalkCommnet to set
	 */
	public void setGlobalElementCrosswalkCommnet(String globalElementCrosswalkCommnet) {
		this.globalElementCrosswalkCommnet = globalElementCrosswalkCommnet;
	}

	/**
	 * @return the globalElementPlatformCode
	 */
	public Long getGlobalElementPlatformCode() {
		return globalElementPlatformCode;
	}

	/**
	 * @param globalElementPlatformCode the globalElementPlatformCode to set
	 */
	public void setGlobalElementPlatformCode(Long globalElementPlatformCode) {
		this.globalElementPlatformCode = globalElementPlatformCode;
	}

	
	/**
	 * @param globalElementTypeCode the globalElementTypeCode to set
	 */
	public void setGlobalElementTypeCode(Long globalElementTypeCode) {
		this.globalElementTypeCode = globalElementTypeCode;
	}
	/**
	 * @return the globalElementTypeCode
	 */
	public Long getGlobalElementTypeCode() {
		return globalElementTypeCode;
	}
	

	/**
	 * @param globalElementPlatformCodeDescription the globalElementPlatformCodeDescription to set
	 */
	public void setGlobalElementPlatformCodeDescription(
			String globalElementPlatformCodeDescription) {
		this.globalElementPlatformCodeDescription = globalElementPlatformCodeDescription;
	}


	/**
	 * @return the globalElementPlatformCodeDescription
	 */
	public String getGlobalElementPlatformCodeDescription() {
		return globalElementPlatformCodeDescription;
	}


	/**
	 * @param globalElementTypeCodeDescription the globalElementTypeCodeDescription to set
	 */
	public void setGlobalElementTypeCodeDescription(
			String globalElementTypeCodeDescription) {
		this.globalElementTypeCodeDescription = globalElementTypeCodeDescription;
	}


	/**
	 * @return the globalElementTypeCodeDescription
	 */
	public String getGlobalElementTypeCodeDescription() {
		return globalElementTypeCodeDescription;
	}


	/**
	 * @param globalElementMetadataCodeDescription the globalElementMetadataCodeDescription to set
	 */
	public void setGlobalElementMetadataCodeDescription(
			String globalElementMetadataCodeDescription) {
		this.globalElementMetadataCodeDescription = globalElementMetadataCodeDescription;
	}


	/**
	 * @return the globalElementMetadataCodeDescription
	 */
	public String getGlobalElementMetadataCodeDescription() {
		return globalElementMetadataCodeDescription;
	}


	/**
	 * @param changeIndicator the changeIndicator to set
	 */
	public void setChangeIndicator(String changeIndicator) {
		this.changeIndicator = changeIndicator;
	}


	/**
	 * @return the changeIndicator
	 */
	public String getChangeIndicator() {
		return changeIndicator;
	}
	/**
	 * @param elementsCount the elementsCount to set
	 */
	public void setElementsCount(Long elementsCount) {
		this.elementsCount = elementsCount;
	}
	/**
	 * @return the elementsCount
	 */
	public Long getElementsCount() {
		return elementsCount;
	}
}
