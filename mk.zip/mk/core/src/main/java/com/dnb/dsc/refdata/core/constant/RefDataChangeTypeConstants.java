/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.constant;

/**
 * This class contains constants for the change type codes. The class will
 * contain constants which are used for the work-flow integration.
 * 
 * @author Cognizant
 * @version last updated : Apr 19, 2012
 * @see
 * 
 */
public class RefDataChangeTypeConstants {

	public static final String CHANGE_TYPE_ADD_GEO_UNIT = "101";

	public static final String CHANGE_TYPE_UPDATE_GEO_UNIT = "102";

	public static final String CHANGE_TYPE_DELETE_GEO_UNIT = "103";
	public static final String CHANGE_TYPE_BULK_UPLOAD_GEOGRAPHY = "104";

	public static final String CHANGE_TYPE_UPDATE_CURRENCY_EXCHANGE = "202";

	public static final String CHANGE_TYPE_BULK_UPLOAD_CURRENCY_EXCHANGE = "203";

	public static final String CHANGE_TYPE_ADD_INDUSTRY_CODE = "301";

	public static final String CHANGE_TYPE_UPDATE_INDUSTRY_CODE = "302";

	public static final String CHANGE_TYPE_DELETE_INDUSTRY_CODE = "303";
	
	public static final String CHANGE_TYPE_BULK_UPLOAD_INDUSTRY_CODE = "304";

	public static final String CHANGE_TYPE_ADD_CODE_TABLE = "401";

	public static final String CHANGE_TYPE_UPDATE_CODE_TABLE = "402";

	public static final String CHANGE_TYPE_DELETE_CODE_TABLE = "403";

	public static final String CHANGE_TYPE_ADD_CODE_VALUE = "411";

	public static final String CHANGE_TYPE_UPDATE_CODE_VALUE = "412";

	public static final String CHANGE_TYPE_DELETE_CODE_VALUE = "413";
	
	public static final String CHANGE_TYPE_BULK_UPLOAD_SCOTS = "414";

	public static final String CHANGE_TYPE_MANAGE_SYSTEM_APPLICABILITY = "421";

	public static final String CHANGE_TYPE_MANAGE_MARKET_APPLICABILITY = "431";

	public static final String CHANGE_TYPE_MANAGE_SCOTS_RELATIONSHIP = "441";

	public static final String CHANGE_TYPE_MANAGE_ALTERNATE_SCHEME_CODES = "451";

	public static final String CHANGE_TYPE_ADD_INDUSTRY_CODE_INFERMENT = "501";

	public static final String CHANGE_TYPE_UPDATE_INDUSTRY_CODE_INFERMENT = "502";

	public static final String CHANGE_TYPE_DELETE_INDUSTRY_CODE_INFERMENT = "503";	

	public static final String CHANGE_TYPE_ADD_LEGAL_FORM_INFERMENT = "511";

	public static final String CHANGE_TYPE_UPDATE_LEGAL_FORM_INFERMENT = "512";

	public static final String CHANGE_TYPE_DELETE_LEGAL_FORM_INFERMENT = "513";
	
	public static final String CHANGE_TYPE_BULK_UPLOAD_CTRLWRDS = "514";

	public static final String CHANGE_TYPE_ADD_UNUSABLE_OFFENSIVE_WORD = "521";

	public static final String CHANGE_TYPE_UPDATE_UNUSABLE_OFFENSIVE_WORD = "522";

	public static final String CHANGE_TYPE_DELETE_UNUSABLE_OFFENSIVE_WORD = "523";

	public static final String CHANGE_TYPE_ADD_UNUSABLE_INDIVIDUAL_NAME = "531";

	public static final String CHANGE_TYPE_UPDATE_UNUSABLE_INDIVIDUAL_NAME = "532";

	public static final String CHANGE_TYPE_DELETE_UNUSABLE_INDIVIDUAL_NAME = "533";

	public static final String CHANGE_TYPE_ADD_UNUSABLE_ORGANIZATION_NAME = "541";

	public static final String CHANGE_TYPE_UPDATE_UNUSABLE_ORGANIZATION_NAME = "542";

	public static final String CHANGE_TYPE_DELETE_UNUSABLE_ORGANIZATION_NAME = "543";

	public static final String CHANGE_TYPE_ADD_UNUSABLE_ADDRESS = "551";

	public static final String CHANGE_TYPE_UPDATE_UNUSABLE_ADDRESS = "552";

	public static final String CHANGE_TYPE_DELETE_UNUSABLE_ADDRESS = "553";

	public static final String CHANGE_TYPE_ADD_INDUSTRY_CODE_INFERRMENT_NOISE_WORD = "561";

	public static final String CHANGE_TYPE_UPDATE_INDUSTRY_CODE_INFERRMENT_NOISE_WORD = "562";

	public static final String CHANGE_TYPE_DELETE_INDUSTRY_CODE_INFERRMENT_NOISE_WORD = "563";

	public static final String CHANGE_TYPE_ADD_UNUSABLE_TELEPHONE_NUMBER = "571";

	public static final String CHANGE_TYPE_UPDATE_UNUSABLE_TELEPHONE_NUMBER = "572";

	public static final String CHANGE_TYPE_DELETE_UNUSABLE_TELEPHONE_NUMBER = "573";

	public static final String CHANGE_TYPE_ADD_UNUSABLE_PHONE_AREA_CODE_NUMBER = "581";

	public static final String CHANGE_TYPE_UPDATE_UNUSABLE_PHONE_AREA_CODE_NUMBER = "582";

	public static final String CHANGE_TYPE_DELETE_UNUSABLE_PHONE_AREA_CODE_NUMBER = "583";

	public static final String CHANGE_TYPE_ADD_PHONE_AREA_CODE_NUMBER = "591";

	public static final String CHANGE_TYPE_UPDATE_PHONE_AREA_CODE_NUMBER = "592";

	public static final String CHANGE_TYPE_DELETE_PHONE_AREA_CODE_NUMBER = "593";

	public static final String CHANGE_TYPE_UPDATE_XML_SCHEMA_LABEL = "602";

	public static final String CHANGE_TYPE_MANAGE_FINANCIAL_TEMPLATES = "701";

	

}
