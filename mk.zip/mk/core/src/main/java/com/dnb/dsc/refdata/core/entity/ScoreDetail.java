
/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCodeDescription. The class will have a
 * direct mapping toe DB table inds_code_desc.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "SCR_DTL")
@NamedQueries({ 
	@NamedQuery(name = "ScoreDetail.removeIndustryCodeDescriptionByIndustryCodeId", query = "DELETE FROM IndustryCodeDescription i where i.industryCodeId = :industryCodeId"),
	@NamedQuery(name = "ScoreDetail.removeByIndustryCodeDescriptionId", query = "DELETE FROM IndustryCodeDescription i where i.industryCodeDescriptionId = :industryCodeDescriptionId ")
	//@NamedQuery(name = "ScoreDetail.retrieveAttributeDetails", query = "SELECT scrgrnassn.granularityTypeAssociationId,case when scrgrnassn.attributeTypeId=1 then 'Minimum' when scrgrnassn.attributeTypeId=2 then 'Maximum' when scrgrnassn.attributeTypeId=3 then (SELECT DISTINCT cdval.codeValueDescription from CodeValueText cdval where scrgrnassn.granularityTypeId = cdval.codeValueId  and cdval.languageCode = 39 and cdval.writingScriptCode = 19349) End as granularityLabel FROM ScoreGranularityAssociation scrgrnassn where scrgrnassn.granularityTypeId in (select granularityTypeId from ScoreTypeAssociation where scoreTypeAssociationId in (select scoreTypeAssociationId from ScoreDetail where scoreId =:scoreId))")
	//@NamedQuery(name = "ScoreDetail.retrieveAttributeDetails", query = "SELECT scrgrnassn.granularityTypeAssociationId,case when scrgrnassn.attributeTypeId=1 then 'Minimum' when scrgrnassn.attributeTypeId=2 then 'Maximum' when scrgrnassn.attributeTypeId=3 then (SELECT DISTINCT cdval.codeValueDescription from CodeValueText cdval where scrgrnassn.granularityTypeId = cdval.codeValueId  and cdval.languageCode = 39 and cdval.writingScriptCode = 19349) End FROM ScoreGranularityAssociation scrgrnassn where scrgrnassn.granularityTypeId in (select granularityTypeId from ScoreTypeAssociation where scoreTypeAssociationId in (select scoreTypeAssociationId from ScoreDetail where scoreId =:scoreId))")
})
public class ScoreDetail extends Audit {
	
	/**
	 * Serial Version ID.
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "SCR_DTL_ID")
	private Long scoreDetailId;
	
	@Column(name = "SCR_ID")
	private Long scoreId;
	
	@Column(name = "SCR_TYP_ASSN_ID")
	private Long scoreTypeAssociationId;
	
	
	
	/**
	 * Empty Constructor.
	 */
	public ScoreDetail() {
		super();
	}

	/**
	 * 
	 * @param scoreDetailId
	 * @param scoreId
	 * @param scoreTypeAssociationId
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 */
	public ScoreDetail(Long scoreDetailId,
			Long scoreId, Long scoreTypeAssociationId, 
			String createdUser, Date createdDate, String modifiedUser,
			Date modifiedDate) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.scoreDetailId = scoreDetailId;
		this.scoreId = scoreId;
		this.scoreTypeAssociationId = scoreTypeAssociationId;
		
	}

	
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "scoreDetailId [scoreDetailId="
				+ scoreDetailId + ", scoreId="
				+ scoreId + ", scoreTypeAssociationId=" + scoreTypeAssociationId
				+ "]";
	}
}
