package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;

import com.dnb.dsc.refdata.core.entity.Audit;

public class ResourceMetadataVO extends Audit implements Serializable {
	
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8063816069657959470L;
	
	
	private Long rescDtlId;
	
	
	
	
	public Long getRescDtlId() {
		return rescDtlId;
	}

	public void setRescDtlId(Long rescDtlId) {
		this.rescDtlId = rescDtlId;
	}

	/**
	 * resourceMetadataCode.
	 */
	private Long resourceMetadataCode;
	/**
	 * resourceMetadataValue.
	 */
	private String resourceMetadataValue;
	
	
	/**
	 * 
	 * @return resourceMetadataCode
	 */
	public Long getResourceMetadataCode() {
		return resourceMetadataCode;
	}
	
	/**
	 * 
	 * @param resourceMetadataCode the resourceMetadataCode to set
	 */
	public void setResourceMetadataCode(Long resourceMetadataCode) {
		this.resourceMetadataCode = resourceMetadataCode;
	}
	
	/**
	 * 
	 * @return resourceMetadataValue
	 */
	
	public String getResourceMetadataValue() {
		return resourceMetadataValue;
	}
	
	/**
	 * 
	 * @param resourceMetadataValue the resourceMetadataValue to set
	 */
	
	public void setResourceMetadataValue(String resourceMetadataValue) {
		this.resourceMetadataValue = resourceMetadataValue;
	}
	

}
