/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
/**
 * This class used as an entity class for the Code Table. The class
 * will have a direct mapping toe DB table cd_tbl.
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
@Entity
@Table(name = "SCR_TYP_ASSN")
@NamedQueries({
		@NamedQuery(name = "ScoreTypeAssc.retrieveScoreTableList", query = "SELECT new CodeTable(c.codeTableId, c.codeTableName) FROM CodeTable c order by c.codeTableId"),
		@NamedQuery(name = "ScoreTypeAssc.countTable", query = "SELECT count(c.codeTableId) FROM CodeTable c WHERE c.codeTableId = :codeTableId")})
public class ScoreTypeAssc extends Audit implements Serializable {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "SCR_TYP_ASSN_ID")
	private Long scoreTypAsscId;

	@Column(name = "SCR_TYP_ID")
	private Long scoreTypeId;
	
	@Column(name = "SCR_GRU_ID")
	private Long scoreGraId;
	
	/*@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "scoreTypAsscId")
	private List<ScoreDetails> scoreDetails;*/
	
	/*@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "scoreTypeId")
	private List<ScoreType> scoreTypes;*/
	
	/*@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "scoreGraId")
	private List<ScoreGranularity> scoreGranularity;*/
	
	/*public List<ScoreDetails> getScoreDetails() {
		return scoreDetails;
	}

	public void setScoreDetails(List<ScoreDetails> scoreDetails) {
		this.scoreDetails = scoreDetails;
	}*/
	
	/*@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="SCR_TYP_ID",insertable = true, updatable = true)
	@JsonBackReference
	private ScoreType scoreType;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="SCR_GRA_ID",insertable = true, updatable = true)
	@JsonBackReference
	private ScoreGranularity scoreGranularity;*/
	
	
	
	/*public ScoreType getScoreType() {
		return scoreType;
	}

	public void setScoreType(ScoreType scoreType) {
		this.scoreType = scoreType;
	}

	public ScoreGranularity getScoreGranularity() {
		return scoreGranularity;
	}

	public void setScoreGranularity(ScoreGranularity scoreGranularity) {
		this.scoreGranularity = scoreGranularity;
	}*/

	/**
	 * The default constructor
	 */
	public ScoreTypeAssc() {
		super();
	}

	public Long getScoreTypAsscId() {
		return scoreTypAsscId;
	}

	public void setScoreTypAsscId(Long scoreTypAsscId) {
		this.scoreTypAsscId = scoreTypAsscId;
	}

	public Long getScoreTypeId() {
		return scoreTypeId;
	}

	public void setScoreTypeId(Long scoreTypeId) {
		this.scoreTypeId = scoreTypeId;
	}

	public Long getScoreGraId() {
		return scoreGraId;
	}

	public void setScoreGraId(Long scoreGraId) {
		this.scoreGraId = scoreGraId;
	}

	/*public List<ScoreType> getScoreTypes() {
		return scoreTypes;
	}

	public void setScoreTypes(List<ScoreType> scoreTypes) {
		this.scoreTypes = scoreTypes;
	}

	public List<ScoreGranularity> getScoreGranularity() {
		return scoreGranularity;
	}

	public void setScoreGranularity(List<ScoreGranularity> scoreGranularity) {
		this.scoreGranularity = scoreGranularity;
	}*/

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ScoreTypeAssc [scoreTypAsscId=" + scoreTypAsscId + ", scoreTypeId="
				+ scoreTypeId +", scoreGraId="
					+ scoreGraId +"]";
	}


}
