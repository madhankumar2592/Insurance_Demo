/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
/**
 * This class used as an entity class for the Legal Form Inferment. The class
 * will have a direct mapping toe DB table LGL_FORM_INFR.
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
@Entity
@Table(name = "LGL_FORM_INFR")
@NamedQueries({ @NamedQuery(name = "LegalFormInferment.retrieveLegalFormClassCodeList", query = "SELECT DISTINCT new LegalFormInferment(lfi.legalFormClassCode, cvt.codeValueDescription) FROM LegalFormInferment lfi, CodeValueText cvt WHERE cvt.codeValueId= lfi.legalFormClassCode AND cvt.languageCode= :languageCode ORDER BY lfi.legalFormClassCode"),
				@NamedQuery(name = "LegalFormInferment.retrieveLegalFormCodeList", query = "SELECT DISTINCT new LegalFormInferment(lfi.legalFormCode, cvt.codeValueDescription) FROM LegalFormInferment lfi, CodeValueText cvt WHERE cvt.codeValueId= lfi.legalFormCode AND cvt.languageCode= :languageCode ORDER BY lfi.legalFormCode"),
				@NamedQuery(name = "LegalFormInferment.removeApprovedLegalFormInferment", query = "DELETE from LegalFormInferment WHERE infermentTextId= :infermentTextId") })

public class LegalFormInferment extends Audit implements Serializable {

	private static final long serialVersionUID = 6L;


	@Id
	@Column(name = "LGL_FORM_INFR_ID")
	private Long legalFormInfermentId;

	@Column(name = "INFR_TXT_ID")
	private Long infermentTextId;

	@Column(name = "LGL_FORM_CLS_CD")
	private Long legalFormClassCode;

	@Column(name = "LGL_FORM_CD")
	private Long legalFormCode;

	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;

	@Transient
	private String codeValueDescription;

	@Transient
	private String legalFrominfrmntBulkId;
	
	
	@Transient
	private int errorCD;
	
	@Transient
	private String infrmntTxtBulkId;
		

	/**
	 *
	 */
	public LegalFormInferment() {
		super();
	}

	/**
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 */
	public LegalFormInferment(String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		// TODO Auto-generated constructor stub
	}

	/**
	 *
	 * @param legalFormInfermentId
	 * @param infermentTextId
	 * @param legalFormClassCode
	 * @param legalFormCode
	 * @param effectiveDate
	 * @param expirationDate
	 */
	public LegalFormInferment(Long legalFormInfermentId,
			Long infermentTextId, Long legalFormClassCode,
			Long legalFormCode, Date effectiveDate, Date expirationDate) {
		super();
		this.legalFormInfermentId = legalFormInfermentId;
		this.infermentTextId = infermentTextId;
		this.legalFormClassCode = legalFormClassCode;
		this.legalFormCode = legalFormCode;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
	}

	/**
	 *
	 * @param legalFormClassCode
	 * @param codeValueDescription
	 */
	public LegalFormInferment(Long legalFormClassCode,
			String codeValueDescription) {
		super();
		this.legalFormClassCode = legalFormClassCode;
		this.codeValueDescription = codeValueDescription;
	}

	public LegalFormInferment(Long legalFormCode,
			String codeValueDescription,Long legalFormInfermentId) {
		super();
		this.legalFormInfermentId = legalFormInfermentId;
		this.legalFormCode = legalFormCode;
		this.codeValueDescription = codeValueDescription;
	}

	public Long getLegalFormInfermentId() {
		return legalFormInfermentId;
	}


	public void setLegalFormInfermentId(Long legalFormInfermentId) {
		this.legalFormInfermentId = legalFormInfermentId;
	}


	public Long getInfermentTextId() {
		return infermentTextId;
	}


	public void setInfermentTextId(Long infermentTextId) {
		this.infermentTextId = infermentTextId;
	}


	public Long getLegalFormClassCode() {
		return legalFormClassCode;
	}


	public void setLegalFormClassCode(Long legalFormClassCode) {
		this.legalFormClassCode = legalFormClassCode;
	}


	public Long getLegalFormCode() {
		return legalFormCode;
	}


	public void setLegalFormCode(Long legalFormCode) {
		this.legalFormCode = legalFormCode;
	}


	public Date getEffectiveDate() {
		return effectiveDate;
	}


	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}


	public Date getExpirationDate() {
		return expirationDate;
	}


	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}


	public String getCodeValueDescription() {
		return codeValueDescription;
	}

	public void setCodeValueDescription(String codeValueDescription) {
		this.codeValueDescription = codeValueDescription;
	}

	/**
	 * @return the legalFrominfrmntBulkId
	 */
	public String getLegalFrominfrmntBulkId() {
		return legalFrominfrmntBulkId;
	}

	/**
	 * @param legalFrominfrmntBulkId the legalFrominfrmntBulkId to set
	 */
	public void setLegalFrominfrmntBulkId(String legalFrominfrmntBulkId) {
		this.legalFrominfrmntBulkId = legalFrominfrmntBulkId;
	}

	/**
	 * @return the errorCD
	 */
	public int getErrorCD() {
		return errorCD;
	}

	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(int errorCD) {
		this.errorCD = errorCD;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "LegalFormInferment [legalFormInfermentId="
				+ legalFormInfermentId + ", infermentTextId=" + infermentTextId
				+ ", legalFormClassCode=" + legalFormClassCode
				+ ", legalFormCode=" + legalFormCode + ", effectiveDate="
				+ effectiveDate + ", expirationDate=" + expirationDate
				+ ", codeValueDescription=" + codeValueDescription + "]";
	}

	/**
	 * @param infrmntTxtBulkId the infrmntTxtBulkId to set
	 */
	public void setInfrmntTxtBulkId(String infrmntTxtBulkId) {
		this.infrmntTxtBulkId = infrmntTxtBulkId;
	}

	/**
	 * @return the infrmntTxtBulkId
	 */
	public String getInfrmntTxtBulkId() {
		return infrmntTxtBulkId;
	}
}
