/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 *	Entity for finl_stmt_tmplt table
 *
 * @author Cognizant
 * @version last updated : June 14, 2012
 * @see
 *
 */
@Entity
@Table(name = "finl_stmt_tmplt")
@NamedQueries({
	@NamedQuery(name = "FinancialStatementTemplate.retrieveFinancialStatementTemplateByTypeCode", query = "SELECT f FROM FinancialStatementTemplate f where f.financialTemplateTypeCode = :financialTemplateTypeCode and f.effectiveToDate is null"),
	@NamedQuery(name = "FinancialStatementTemplate.retrieveFinancialStatementTemplateById", query = "SELECT f FROM FinancialStatementTemplate f where f.financialStatementTemplateId = :financialStatementTemplateId"),
	@NamedQuery(name = "FinancialStatementTemplate.removeFinancialStatementTemplateById", query = "DELETE FinancialStatementTemplate f where f.financialStatementTemplateId = :financialStatementTemplateId"),
	@NamedQuery(name = "FinancialStatementTemplate.retrieveFinanceTemplateCodeById", query = "SELECT financialTemplateTypeCode FROM  FinancialStatementTemplate f where f.financialStatementTemplateId = :financeTemplateId"),
	@NamedQuery(name = "FinancialStatementTemplate.lockFinancialTemplateForEdit", query = "SELECT distinct new FinancialStatementTemplate(fst.modifiedUser) FROM FinancialStatementTemplate fst WHERE fst.financialTemplateTypeCode = :financialTemplateTypeCode")
})
public class FinancialStatementTemplate extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "FINL_STMT_TMPLT_ID")
	private Long financialStatementTemplateId;

	@Column(name = "FINL_TMPLT_TYP_CD")
	private Long financialTemplateTypeCode;
	
	@Column(name = "TMPLT_OWR_CD")
	private Long templateOwnerCode;
	
	@Column(name = "EFFV_FROM_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveFromDate;

	@Column(name = "EFFV_TO_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveToDate;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "financialStatementTemplateId")
	private List<FinancialStatementSchedule> financialStatementScheduleList;

	@Transient
	private String typeCodeDescription;
	
	@Transient
	private Boolean isLocked;
	
	@Transient
	private String lockedUser;
	
	public FinancialStatementTemplate(){

	}
	public FinancialStatementTemplate(String modifiedUser){
		super();
		this.setModifiedUser(modifiedUser);
	}
	/**
	 * @return the financialStatementTemplateId
	 */
	public Long getFinancialStatementTemplateId() {
		return financialStatementTemplateId;
	}

	/**
	 * @param financialStatementTemplateId the financialStatementTemplateId to set
	 */
	public void setFinancialStatementTemplateId(Long financialStatementTemplateId) {
		this.financialStatementTemplateId = financialStatementTemplateId;
	}

	/**
	 * @return the financialTemplateTypeCode
	 */
	public Long getFinancialTemplateTypeCode() {
		return financialTemplateTypeCode;
	}

	/**
	 * @param financialTemplateTypeCode the financialTemplateTypeCode to set
	 */
	public void setFinancialTemplateTypeCode(Long financialTemplateTypeCode) {
		this.financialTemplateTypeCode = financialTemplateTypeCode;
	}

	/**
	 * @return the templateOwnerCode
	 */
	public Long getTemplateOwnerCode() {
		return templateOwnerCode;
	}

	/**
	 * @param templateOwnerCode the templateOwnerCode to set
	 */
	public void setTemplateOwnerCode(Long templateOwnerCode) {
		this.templateOwnerCode = templateOwnerCode;
	}

	/**
	 * @return the effectiveFromDate
	 */
	public Date getEffectiveFromDate() {
		return effectiveFromDate;
	}

	/**
	 * @param effectiveFromDate the effectiveFromDate to set
	 */
	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	/**
	 * @return the effectiveToDate
	 */
	public Date getEffectiveToDate() {
		return effectiveToDate;
	}

	/**
	 * @param effectiveToDate the effectiveToDate to set
	 */
	public void setEffectiveToDate(Date effectiveToDate) {
		this.effectiveToDate = effectiveToDate;
	}

	/**
	 * @return the financialStatementScheduleList
	 */
	public List<FinancialStatementSchedule> getFinancialStatementScheduleList() {
		return financialStatementScheduleList;
	}

	/**
	 * @param financialStatementScheduleList the financialStatementScheduleList to set
	 */
	public void setFinancialStatementScheduleList(
			List<FinancialStatementSchedule> financialStatementScheduleList) {
		this.financialStatementScheduleList = financialStatementScheduleList;
	}

	public void setTypeCodeDescription(String typeCodeDescription) {
		this.typeCodeDescription = typeCodeDescription;
	}

	public String getTypeCodeDescription() {
		return typeCodeDescription;
	}

	/**
	 * @return the isLocked
	 */
	public Boolean getIsLocked() {
		return isLocked;
	}
	/**
	 * @param isLocked the isLocked to set
	 */
	public void setIsLocked(Boolean isLocked) {
		this.isLocked = isLocked;
	}
	/**
	 * @return the lockedUser
	 */
	public String getLockedUser() {
		return lockedUser;
	}
	/**
	 * @param lockedUser the lockedUser to set
	 */
	public void setLockedUser(String lockedUser) {
		this.lockedUser = lockedUser;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FinancialStatementTemplate [financialStatementTemplateId="
				+ financialStatementTemplateId + ", financialTemplateTypeCode="
				+ financialTemplateTypeCode + ", templateOwnerCode="
				+ templateOwnerCode + ", effectiveFromDate="
				+ effectiveFromDate + ", effectiveToDate=" + effectiveToDate
				+ ", financialStatementScheduleList="
				+ financialStatementScheduleList + ", typeCodeDescription="
				+ typeCodeDescription + "]";
	}
}
