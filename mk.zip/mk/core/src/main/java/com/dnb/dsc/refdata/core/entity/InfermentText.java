/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;
/**
 * This class used as an entity class for the Legal Form Inferment. The class
 * will have a direct mapping toe DB table LGL_FORM_INFR.
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "InfermentText.retrieveLegalFormLanguages", query = "SELECT DISTINCT new InfermentText(it.languageCode, cvt.codeValueDescription) FROM InfermentText it, CodeValueText cvt WHERE cvt.codeValueId= it.languageCode AND it.infermentTypeCode=:infermentTypeCode AND cvt.languageCode= :languageCode ORDER BY it.languageCode"),
	@NamedQuery(name = "InfermentText.countInfermentText", query = "SELECT count(it.infermentTextId) FROM InfermentText it WHERE it.infermentTextId = :infermentTextId"),
	@NamedQuery(name = "InfermentText.retrieveInfermentTextByInfermentTextId", query = "SELECT it FROM InfermentText it where it.infermentTextId = :infermentTextId"),
	@NamedQuery(name = "InfermentText.removeApprovedInfermentText", query = "DELETE from InfermentText WHERE infermentTextId= :infermentTextId")
	})
@Table(name = "INFR_TXT")
public class InfermentText extends Audit implements Serializable {

	private static final long serialVersionUID = 6L;


	@Id
	@Column(name = "INFR_TXT_ID")
	private Long infermentTextId;

	@Column(name = "INFR_TYP_CD")
	private Long infermentTypeCode;

	@Column(name = "INFR_TXT")
	private String infermentText;

	@Column(name = "LANG_CD")
	private Long languageCode;

	@Column(name = "WRIT_SCRP_CD")
	private Long writingScriptCode;

	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "infermentTextId")
	private List<LegalFormInferment> legalFormInferments;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "infermentTextId")
	private List<InfermentTextCountryApplicability> countryApplicabilities;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "infermentTextId")
    private List<IndustryCodeInferment> industryCodeInferment;
		
	@Transient
	private String codeValueDescription;

	@Transient
	private String geoName;

	@Transient
	private Long icountryGeoUnitId;

	@Transient
	private String languageDescription;

	@Transient
	private Long legalFormCode;

	@Transient
	private String legalFormCodeValue;

	@Transient
	private Long legalFormClassCode;

	@Transient
	private String legalFormClassCodeValue;

	@Transient
	private String status;

	@Transient
	private List<String> countryList;
	
	@Transient
	private List<IndustryCode> industryCodeList;
	
	@Transient
    private List<IndustryCodeDescription> industryCodeDescriptionList;
	
	@Transient
	private String infrmntTxtBulkId;
	
	
	@Transient
	private int errorCD;
	
	/**
	 * @return the infrmntTxtBulkId
	 */
	public String getInfrmntTxtBulkId() {
		return infrmntTxtBulkId;
	}


	/**
	 * @param infrmntTxtBulkId the infrmntTxtBulkId to set
	 */
	public void setInfrmntTxtBulkId(String infrmntTxtBulkId) {
		this.infrmntTxtBulkId = infrmntTxtBulkId;
	}


	/**
	 * @return the errorCD
	 */
	public int getErrorCD() {
		return errorCD;
	}


	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(int errorCD) {
		this.errorCD = errorCD;
	}


	/**
	 *
	 */
	public InfermentText() {
		super();
	}


	/**
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 */
	public InfermentText(String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		// TODO Auto-generated constructor stub
	}


	/**
	 *
	 * @param languageCode
	 * @param codeValueDescription
	 */
	public InfermentText(Long languageCode, String codeValueDescription) {
		super();
		this.languageCode = languageCode;
		this.codeValueDescription = codeValueDescription;
	}

	/**
	 *
	 * @param infermentTextId
	 * @param infermentTypeCode
	 * @param infermentText
	 * @param languageCode
	 * @param writingScriptCode
	 * @param effectiveDate
	 * @param expirationDate
	 */
	public InfermentText(Long infermentTextId, Long infermentTypeCode,
			String infermentText, Long languageCode,
			Long writingScriptCode, Date effectiveDate, Date expirationDate) {
		super();
		this.infermentTextId = infermentTextId;
		this.infermentTypeCode = infermentTypeCode;
		this.infermentText = infermentText;
		this.languageCode = languageCode;
		this.writingScriptCode = writingScriptCode;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
	}

	/**
	 * @param infermentTextId
	 * @param infermentText
	 * @param languageCode
	 * @param expirationDate
	 * @param geoName
	 * @param icountryGeoUnitId
	 * @param languageDescription
	 * @param legalFormCode
	 * @param legalFormCodeValue
	 * @param legalFormClassCode
	 * @param legalFormClassCodeValue
	 */
	public InfermentText(Long icountryGeoUnitId,String geoName,
			Long languageCode,String languageDescription,
			Long legalFormCode, String legalFormCodeValue,
			Long legalFormClassCode, String legalFormClassCodeValue,
			Long infermentTextId, String infermentText,
			 Date expirationDate) {
		super();
		this.infermentTextId = infermentTextId;
		this.infermentText = infermentText;
		this.languageCode = languageCode;
		this.expirationDate = expirationDate;
		this.geoName = geoName;
		this.icountryGeoUnitId = icountryGeoUnitId;
		this.languageDescription = languageDescription;
		this.legalFormCode = legalFormCode;
		this.legalFormCodeValue = legalFormCodeValue;
		this.legalFormClassCode = legalFormClassCode;
		this.legalFormClassCodeValue = legalFormClassCodeValue;
	}


	/**
	 * @return the geoName
	 */
	public String getGeoName() {
		return geoName;
	}


	/**
	 * @param geoName the geoName to set
	 */
	public void setGeoName(String geoName) {
		this.geoName = geoName;
	}


	/**
	 * @return the legalFormCode
	 */
	public Long getLegalFormCode() {
		return legalFormCode;
	}


	/**
	 * @param legalFormCode the legalFormCode to set
	 */
	public void setLegalFormCode(Long legalFormCode) {
		this.legalFormCode = legalFormCode;
	}


	/**
	 * @return the legalFormClassCode
	 */
	public Long getLegalFormClassCode() {
		return legalFormClassCode;
	}


	/**
	 * @param legalFormClassCode the legalFormClassCode to set
	 */
	public void setLegalFormClassCode(Long legalFormClassCode) {
		this.legalFormClassCode = legalFormClassCode;
	}


	/**
	 * @return the infermentTextId
	 */
	public Long getInfermentTextId() {
		return infermentTextId;
	}


	/**
	 * @param infermentTextId the infermentTextId to set
	 */
	public void setInfermentTextId(Long infermentTextId) {
		this.infermentTextId = infermentTextId;
	}


	/**
	 * @return the infermentTypeCode
	 */
	public Long getInfermentTypeCode() {
		return infermentTypeCode;
	}


	/**
	 * @param infermentTypeCode the infermentTypeCode to set
	 */
	public void setInfermentTypeCode(Long infermentTypeCode) {
		this.infermentTypeCode = infermentTypeCode;
	}


	/**
	 * @return the infermentText
	 */
	public String getInfermentText() {
		return infermentText;
	}


	/**
	 * @param infermentText the infermentText to set
	 */
	public void setInfermentText(String infermentText) {
		this.infermentText = infermentText;
	}


	/**
	 * @return the languageCode
	 */
	public Long getLanguageCode() {
		return languageCode;
	}


	/**
	 * @param languageCode the languageCode to set
	 */
	public void setLanguageCode(Long languageCode) {
		this.languageCode = languageCode;
	}


	/**
	 * @return the writingScriptCode
	 */
	public Long getWritingScriptCode() {
		return writingScriptCode;
	}


	/**
	 * @param writingScriptCode the writingScriptCode to set
	 */
	public void setWritingScriptCode(Long writingScriptCode) {
		this.writingScriptCode = writingScriptCode;
	}


	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}


	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}


	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}


	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}


	/**
	 * @return the codeValueDescription
	 */
	public String getCodeValueDescription() {
		return codeValueDescription;
	}


	/**
	 * @param codeValueDescription the codeValueDescription to set
	 */
	public void setCodeValueDescription(String codeValueDescription) {
		this.codeValueDescription = codeValueDescription;
	}

	/**
	 * @return the icountryGeoUnitId
	 */
	public Long getIcountryGeoUnitId() {
		return icountryGeoUnitId;
	}


	/**
	 * @param icountryGeoUnitId the icountryGeoUnitId to set
	 */
	public void setIcountryGeoUnitId(Long icountryGeoUnitId) {
		this.icountryGeoUnitId = icountryGeoUnitId;
	}


	/**
	 * @return the languageDescription
	 */
	public String getLanguageDescription() {
		return languageDescription;
	}


	/**
	 * @param languageDescription the languageDescription to set
	 */
	public void setLanguageDescription(String languageDescription) {
		this.languageDescription = languageDescription;
	}


	/**
	 * @return the legalFormCodeValue
	 */
	public String getLegalFormCodeValue() {
		return legalFormCodeValue;
	}


	/**
	 * @param legalFormCodeValue the legalFormCodeValue to set
	 */
	public void setLegalFormCodeValue(String legalFormCodeValue) {
		this.legalFormCodeValue = legalFormCodeValue;
	}


	/**
	 * @return the legalFormClassCodeValue
	 */
	public String getLegalFormClassCodeValue() {
		return legalFormClassCodeValue;
	}


	/**
	 * @param legalFormClassCodeValue the legalFormClassCodeValue to set
	 */
	public void setLegalFormClassCodeValue(String legalFormClassCodeValue) {
		this.legalFormClassCodeValue = legalFormClassCodeValue;
	}


	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}


	/**
	 * @return the legalFormInferments
	 */
	public List<LegalFormInferment> getLegalFormInferments() {
		return legalFormInferments;
	}


	/**
	 * @param legalFormInferments the legalFormInferments to set
	 */
	public void setLegalFormInferments(List<LegalFormInferment> legalFormInferments) {
		this.legalFormInferments = legalFormInferments;
	}


	/**
	 * @return the countryApplicabilities
	 */
	public List<InfermentTextCountryApplicability> getCountryApplicabilities() {
		return countryApplicabilities;
	}


	/**
	 * @param countryApplicabilities the countryApplicabilities to set
	 */
	public void setCountryApplicabilities(
			List<InfermentTextCountryApplicability> countryApplicabilities) {
		this.countryApplicabilities = countryApplicabilities;
	}


	/**
	 * @return the countryList
	 */
	public List<String> getCountryList() {
		return countryList;
	}


	/**
	 * @param countryList the countryList to set
	 */
	public void setCountryList(List<String> countryList) {
		this.countryList = countryList;
	}


    /**
     * @return the industryCodeList
     */
    public List<IndustryCode> getIndustryCodeList() {
        return industryCodeList;
    }


    /**
     * @param industryCodeList the industryCodeList to set
     */
    public void setIndustryCodeList(List<IndustryCode> industryCodeList) {
        this.industryCodeList = industryCodeList;
    }


    /**
     * @return the industryCodeDescriptionList
     */
    public List<IndustryCodeDescription> getIndustryCodeDescriptionList() {
        return industryCodeDescriptionList;
    }


    /**
     * @param industryCodeDescriptionList the industryCodeDescriptionList to set
     */
    public void setIndustryCodeDescriptionList(List<IndustryCodeDescription> industryCodeDescriptionList) {
        this.industryCodeDescriptionList = industryCodeDescriptionList;
    }
    
    


    /**
     * @return the industryCodeInferment
     */
    public List<IndustryCodeInferment> getIndustryCodeInferment() {
        return industryCodeInferment;
    }


    /**
     * @param industryCodeInferment the industryCodeInferment to set
     */
    public void setIndustryCodeInferment(List<IndustryCodeInferment> industryCodeInferment) {
        this.industryCodeInferment = industryCodeInferment;
    }


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InfermentText [infermentTextId=" + infermentTextId
				+ ", infermentTypeCode=" + infermentTypeCode
				+ ", infermentText=" + infermentText + ", languageCode="
				+ languageCode + ", writingScriptCode=" + writingScriptCode
				+ ", effectiveDate=" + effectiveDate + ", expirationDate="
				+ expirationDate + ", legalFormInferments="
				+ legalFormInferments + ", countryApplicabilities="
				+ countryApplicabilities + ", industryCodeInferment="
				+ industryCodeInferment + ", codeValueDescription="
				+ codeValueDescription + ", geoName=" + geoName
				+ ", icountryGeoUnitId=" + icountryGeoUnitId
				+ ", languageDescription=" + languageDescription
				+ ", legalFormCode=" + legalFormCode + ", legalFormCodeValue="
				+ legalFormCodeValue + ", legalFormClassCode="
				+ legalFormClassCode + ", legalFormClassCodeValue="
				+ legalFormClassCodeValue + ", status=" + status
				+ ", countryList=" + countryList + ", industryCodeList="
				+ industryCodeList + ", industryCodeDescriptionList="
				+ industryCodeDescriptionList + "]";
	}
}