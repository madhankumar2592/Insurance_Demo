package com.dnb.dsc.refdata.core.vo;

import java.util.List;
import java.util.Map;

import com.dnb.dsc.refdata.core.entity.ScoreGranularityAssociation;

public class ScoreSearchVO extends PaginationVO{
	
	private static final long serialVersionUID = 8384721628931167943L;

	private Long scoreTypeCode;
	private Long marketCode;
	private Long scoreGranularity;
	private List<Long> marketCodeList;
	private List<Long> scrTypCdList;
	private List<Long> scrGruCdList;
	private Long indicator;
	
	private Long scr_mkt_cd_id;
	private String country_name;
	
	private Long scr_typ_cd_id;
	private String scr_typ_cd_shrt_d;
	private String scr_typ_cd_val_d;

	private Long scr_gru_cd_id;
	private String scr_gru_cd_shrt_d;
	private String scr_gru_cd_val_d;
	
	private Long scr_id;
	private Long scr_typ_assn_id;
	private Long scr_gru_id;
	private Long scr_typ_id;
	private Double scr_vers;
	private String mkt_cd;
	private String sr_typ_cd;
	
	private String sr_gru_cd;
	
	private String exportIndc;
	
	public Double getScr_vers() {
		return scr_vers;
	}
	public void setScr_vers(Double scr_vers) {
		this.scr_vers = scr_vers;
	}
	public String getExportIndc() {
		return exportIndc;
	}
	public void setExportIndc(String exportIndc) {
		this.exportIndc = exportIndc;
	}
	public List<Long> getScrGruCdList() {
		return scrGruCdList;
	}
	public void setScrGruCdList(List<Long> scrGruCdList) {
		this.scrGruCdList = scrGruCdList;
	}
	public String getSr_gru_cd() {
		return sr_gru_cd;
	}
	public void setSr_gru_cd(String sr_gru_cd) {
		this.sr_gru_cd = sr_gru_cd;
	}
	public String getSr_typ_cd() {
		return sr_typ_cd;
	}
	public void setSr_typ_cd(String sr_typ_cd) {
		this.sr_typ_cd = sr_typ_cd;
	}
	private List<EditScoreSearchVO> editScoreSearchList;
	private List<EditScoreSearchVO> editScoreSearchLit;

	private Double scrVersion;	
	private List<ScoreGranularityAssociation> scoreGranularityAssociation;
	private String loggedInUser;
	private Map<String, List<String>> mapValues;
	private List<String> distGranularityLable;
	
	public List<Long> getScrTypCdList() {
		return scrTypCdList;
	}
	public void setScrTypCdList(List<Long> scrTypCdList) {
		this.scrTypCdList = scrTypCdList;
	}
	public List<EditScoreSearchVO> getEditScoreSearchLit() {
		return editScoreSearchLit;
	}
	public void setEditScoreSearchLit(List<EditScoreSearchVO> editScoreSearchLit) {
		this.editScoreSearchLit = editScoreSearchLit;
	}
	public List<String> getDistGranularityLable() {
		return distGranularityLable;
	}
	public void setDistGranularityLable(List<String> distGranularityLable) {
		this.distGranularityLable = distGranularityLable;
	}
	public Map<String, List<String>> getMapValues() {
		return mapValues;
	}
	public void setMapValues(Map<String, List<String>> mapValues) {
		this.mapValues = mapValues;
	}
	public String getLoggedInUser() {
		return loggedInUser;
	}
	public void setLoggedInUser(String loggedInUser) {
		this.loggedInUser = loggedInUser;
	}
	public List<ScoreGranularityAssociation> getScoreGranularityAssociation() {
		return scoreGranularityAssociation;
	}
	public void setScoreGranularityAssociation(
			List<ScoreGranularityAssociation> scoreGranularityAssociation) {
		this.scoreGranularityAssociation = scoreGranularityAssociation;
	}
	public Double getScrVersion() {
		return scrVersion;
	}
	public void setScrVersion(Double scrVersion) {
		this.scrVersion = scrVersion;
	}
	public List<EditScoreSearchVO> getEditScoreSearchList() {
		return editScoreSearchList;
	}
	public void setEditScoreSearchList(List<EditScoreSearchVO> editScoreSearchList) {
		this.editScoreSearchList = editScoreSearchList;
	}
	public String getMkt_cd() {
		return mkt_cd;
	}
	public void setMkt_cd(String mkt_cd) {
		this.mkt_cd = mkt_cd;
	}
	public Long getScr_gru_id() {
		return scr_gru_id;
	}
	public void setScr_gru_id(Long scr_gru_id) {
		this.scr_gru_id = scr_gru_id;
	}
	public Long getScr_mkt_cd_id() {
		return scr_mkt_cd_id;
	}
	public void setScr_mkt_cd_id(Long scr_mkt_cd_id) {
		this.scr_mkt_cd_id = scr_mkt_cd_id;
	}
	public String getCountry_name() {
		return country_name;
	}
	public void setCountry_name(String country_name) {
		this.country_name = country_name;
	}
	public Long getScr_typ_cd_id() {
		return scr_typ_cd_id;
	}
	public void setScr_typ_cd_id(Long scr_typ_cd_id) {
		this.scr_typ_cd_id = scr_typ_cd_id;
	}
	public String getScr_typ_cd_shrt_d() {
		return scr_typ_cd_shrt_d;
	}
	public void setScr_typ_cd_shrt_d(String scr_typ_cd_shrt_d) {
		this.scr_typ_cd_shrt_d = scr_typ_cd_shrt_d;
	}
	public String getScr_typ_cd_val_d() {
		return scr_typ_cd_val_d;
	}
	public void setScr_typ_cd_val_d(String scr_typ_cd_val_d) {
		this.scr_typ_cd_val_d = scr_typ_cd_val_d;
	}
	public Long getScr_gru_cd_id() {
		return scr_gru_cd_id;
	}
	public void setScr_gru_cd_id(Long scr_gru_cd_id) {
		this.scr_gru_cd_id = scr_gru_cd_id;
	}
	public String getScr_gru_cd_shrt_d() {
		return scr_gru_cd_shrt_d;
	}
	public void setScr_gru_cd_shrt_d(String scr_gru_cd_shrt_d) {
		this.scr_gru_cd_shrt_d = scr_gru_cd_shrt_d;
	}
	public String getScr_gru_cd_val_d() {
		return scr_gru_cd_val_d;
	}
	public void setScr_gru_cd_val_d(String scr_gru_cd_val_d) {
		this.scr_gru_cd_val_d = scr_gru_cd_val_d;
	}
	public Long getScr_id() {
		return scr_id;
	}
	public void setScr_id(Long scr_id) {
		this.scr_id = scr_id;
	}
	public Long getScr_typ_assn_id() {
		return scr_typ_assn_id;
	}
	public void setScr_typ_assn_id(Long scr_typ_assn_id) {
		this.scr_typ_assn_id = scr_typ_assn_id;
	}	
	public Long getScr_typ_id() {
		return scr_typ_id;
	}
	public void setScr_typ_id(Long scr_typ_id) {
		this.scr_typ_id = scr_typ_id;
	}
	public Long getScoreTypeCode() {
		return scoreTypeCode;
	}
	public void setScoreTypeCode(Long scoreTypeCode) {
		this.scoreTypeCode = scoreTypeCode;
	}
	public Long getMarketCode() {
		return marketCode;
	}
	public void setMarketCode(Long marketCode) {
		this.marketCode = marketCode;
	}
	public Long getScoreGranularity() {
		return scoreGranularity;
	}
	public void setScoreGranularity(Long scoreGranularity) {
		this.scoreGranularity = scoreGranularity;
	}
	public List<Long> getMarketCodeList() {
		return marketCodeList;
	}
	public void setMarketCodeList(List<Long> marketCodeList) {
		this.marketCodeList = marketCodeList;
	}
	public Long getIndicator() {
		return indicator;
	}
	public void setIndicator(Long indicator) {
		this.indicator = indicator;
	}
}
