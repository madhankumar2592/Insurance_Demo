/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "PROD_MKT")
@NamedQueries({
		})
public class ProductMarket extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PROD_MKT_ID")
	private Long productMktId;
		
	@Column(name = "PROD_AVLB_ID")
	private Long productAvlbId;
	
	@Column(name = "MKT_CD")
	private Long mktCd;
	
	
	
	public Long getProductMktId() {
		return productMktId;
	}

	public void setProductMktId(Long productMktId) {
		this.productMktId = productMktId;
	}

	public Long getProductAvlbId() {
		return productAvlbId;
	}

	public void setProductAvlbId(Long productAvlbId) {
		this.productAvlbId = productAvlbId;
	}

	public Long getMktCd() {
		return mktCd;
	}

	public void setMktCd(Long mktCd) {
		this.mktCd = mktCd;
	}

	/**
	 * Empty Constructor.
	 */
	public ProductMarket() {
		super();
	}
	
	public ProductMarket(Long productMktId) {
		super();
		this.productMktId = productMktId;
	}
	/*public ProductMarket(Long ProductMarketVersion) {
		super();
		this.ProductMarketVersion = ProductMarketVersion;
	}*/
	public ProductMarket(Long productMktId, Long productAvlbId) {
		super();
		this.productMktId = productMktId;
		this.productAvlbId = productAvlbId;
	}
	
	
	/**
	 * 
	 * @param ProductMarketId
	 * @param ProductMarketVersion
	 * @param ProductMarketTypeId
	 * @param ProductMarketMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public ProductMarket(Long productMktId, Long productAvlbId, Long mktCd,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.productMktId = productMktId;
		this.productAvlbId = productAvlbId;
		this.mktCd = mktCd;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ProductMarket [productMktId=" + productMktId
				+ ", productAvlbId=" + productAvlbId 
				+ ",mktCd=" + mktCd + 
				  "]";
	}
	
	
}
