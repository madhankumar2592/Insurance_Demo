/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.codehaus.jackson.annotate.JsonBackReference;
import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the GeoUnitName. The class  
 * will have a direct mapping toe DB table geo_unit_nme.
 * 
 * @author Cognizant
 * @version last updated : Jan 11, 2011
 * @see
 * 
 */
@Entity
@Table(name = "GEO_UNIT_NME")
@NamedQueries({
		@NamedQuery(name = "GeoUnitName.retrieveGeoUnitsByName", query = "SELECT new GeoUnitName(n.geoUnitNameId, n.geoUnitId, (SELECT cvt.codeValueShortDescription from CodeValueText cvt where cvt.languageCode = :enLangCode and cvt.codeValueId = n.languageCode), (SELECT cvt.codeValueShortDescription from CodeValueText cvt where cvt.languageCode = :enLangCode and cvt.codeValueId = n.nameTypeCode), n.geoName, n.dataProviderCode) FROM GeoUnitName n where upper(n.geoName) like concat(upper(:geoName),'%')  and n.writingScriptCode = :writingScriptCode order by n.geoName"),
		@NamedQuery(name = "GeoUnitName.retrieveAllCountries", query = "SELECT new GeoUnitName(n.geoUnitNameId, n.geoUnitId, n.languageCode, n.nameTypeCode, n.geoName, n.dataProviderCode) FROM GeoUnitName n, GeoUnit g where n.geoUnitId = g.geoUnitId and g.geoUnitTypeCode = :geoUnitTypeCode and n.languageCode = :langCode and n.writingScriptCode = :writingScriptCode and n.nameTypeCode = :nameTypeCode order by n.geoName"),
		@NamedQuery(name = "GeoUnitName.retrieveAllCountryGroups", query = "SELECT distinct new GeoUnitName(n.geoUnitNameId, n.geoUnitId, n.languageCode, n.nameTypeCode, n.geoName, n.dataProviderCode) FROM GeoUnitName n, GeoUnit g, GeoUnitAssociation a where n.geoUnitId = g.geoUnitId and g.geoUnitId = a.parentGeoUnitId and n.geoUnitId = a.parentGeoUnitId and g.geoUnitTypeCode = :geoUnitTypeCode and n.languageCode = :langCode and n.writingScriptCode = :writingScriptCode and n.nameTypeCode = :nameTypeCode order by n.geoName"),
		@NamedQuery(name = "GeoUnitName.retrieveChildGeoUnitsByType", query = "SELECT new GeoUnitName(n.geoUnitNameId, n.geoUnitId, n.languageCode, n.nameTypeCode, n.geoName, n.dataProviderCode) FROM GeoUnitName n, GeoUnit g, GeoUnitAssociation a where n.geoUnitId = g.geoUnitId and g.geoUnitId = a.childGeoUnitId and g.geoUnitTypeCode = :geoUnitTypeCode and n.languageCode = :langCode and n.writingScriptCode = :writingScriptCode and n.nameTypeCode = :nameTypeCode and a.parentGeoUnitId = :parentGeoUnitId order by n.geoName"),
		@NamedQuery(name = "GeoUnitName.removeGeoUnitByGeoUnitId", query = "DELETE GeoUnitName g where g.geoUnitId = :geoUnitId"), 
		@NamedQuery(name = "GeoUnitName.retrieveGeoUnitsByCountryGroup", query = "SELECT new GeoUnitName(n.geoUnitId, n.geoName, a.parentGeoUnitId, (SELECT nm.geoName from GeoUnitName nm where nm.geoUnitId = a.parentGeoUnitId and nm.languageCode = :langCode and nm.writingScriptCode = :writingScriptCode and nm.nameTypeCode = :nameTypeCode) ) FROM GeoUnitName n, GeoUnitAssociation a where n.geoUnitId = a.childGeoUnitId and n.languageCode = :langCode and n.writingScriptCode = :writingScriptCode and n.nameTypeCode = :nameTypeCode and a.parentGeoUnitId = :geoUnitId order by n.geoName"),
		@NamedQuery(name = "GeoUnitName.retrieveAllGeoUnitsByCountryGroup", query = "SELECT new GeoUnitName(n.geoUnitId, n.geoName, a.parentGeoUnitId, (SELECT nm.geoName from GeoUnitName nm where nm.geoUnitId = a.parentGeoUnitId and nm.languageCode = :langCode and nm.writingScriptCode = :writingScriptCode and nm.nameTypeCode = :nameTypeCode) as parentGeoUnitOfficialName ) FROM GeoUnitName n, GeoUnitAssociation a, GeoUnit g where n.geoUnitId = a.childGeoUnitId and a.parentGeoUnitId = g.geoUnitId and n.languageCode = :langCode and n.writingScriptCode = :writingScriptCode and n.nameTypeCode = :nameTypeCode and g.geoUnitTypeCode = :geoUnitTypeCode order by n.geoName")
	})
public class GeoUnitName extends Audit implements Serializable{

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "GEO_UNIT_NME_ID")
	private Long geoUnitNameId;
	
	@Column(name = "GEO_UNIT_ID", insertable=false, updatable=false)
	private Long geoUnitId;

	@Column(name = "LANG_CD")
	private Long languageCode;
	
	@Column(name = "WRIT_SCRP_CD")
	private Long writingScriptCode;
	
	@Column(name = "GEO_NME_TYP_CD")
	private Long nameTypeCode;
	
	@Column(name = "GEO_NME")
	private String geoName;
	
	@Column(name = "DATA_PRVD_CD")
	private Long dataProviderCode;
	
	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)  //Added for Geo Enhancement
	private Date expirationDate;
	
	@Column(name = "EXPD_BY_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expiredByDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="GEO_UNIT_ID")
	@JsonBackReference
	private GeoUnit parentGeoUnit;	

	@Transient
	private String languageDescription;
	
	@Transient
	private String nameTypeDescription;
	
	@Transient
	private Long parentGeoUnitId;
	      
	@Transient
	private String parentGeoUnitOfficialName;

	@Transient
	private String changeIndicator;
	
	@Transient
	private String geoUnitBulkId;

	@Transient
	private String errorCD;
	
	@Transient
	private String dataProviderDescription;
	
	/**
	 * Constructor
	 */
	public GeoUnitName() {
		super();
	}
	
	/**
     * @param geoUnitId
     * @param geoName
     * @param parentGeoUnitId
     * @param parentGeoUnitOfficialName
     */
     public GeoUnitName(Long geoUnitId, String geoName, Long parentGeoUnitId,
                 String parentGeoUnitOfficialName) {
           this.geoUnitId = geoUnitId;
           this.geoName = geoName;
           this.parentGeoUnitId = parentGeoUnitId;
           this.parentGeoUnitOfficialName = parentGeoUnitOfficialName;
     }
     public GeoUnitName(Long geoUnitId, String geoName) {
         super();
         this.geoUnitId = geoUnitId;
         this.geoName = geoName;
   }
	/**
	 * @param geoUnitNameId
	 * @param geoUnitId
	 * @param languageCode
	 * @param writingScriptCode
	 * @param nameTypeCode
	 * @param geoName
	 * @param dataProviderCode
	 * @param effectiveDate
	 * @param expirationDate
	 * @param expiredByDate
	 * @param createdDate
	 * @param modifiedDate
	 * @param modifiedUser
	 * @param createdUser
	 */
	public GeoUnitName(Long geoUnitNameId, Long geoUnitId, Long languageCode,
			Long writingScriptCode, Long nameTypeCode, String geoName,
			Long dataProviderCode, Date effectiveDate, Date expiredByDate,Date expirationDate,
			 Date createdDate, Date modifiedDate,
			String modifiedUser, String createdUser) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.geoUnitNameId = geoUnitNameId;
		this.geoUnitId = geoUnitId;
		this.languageCode = languageCode;
		this.writingScriptCode = writingScriptCode;
		this.nameTypeCode = nameTypeCode;
		this.geoName = geoName;
		this.dataProviderCode = dataProviderCode;
		this.effectiveDate = effectiveDate;
		this.expiredByDate = expiredByDate;
		this.expirationDate = expirationDate;
		
	}

	/**
	 * The constructor for the retrieve functionality 
	 *  
	 * @param geoUnitNameId
	 * @param geoUnitId
	 * @param languageDescription
	 * @param nameTypeDescription
	 * @param geoName
	 * @param dataProviderCode
	 */
	public GeoUnitName(Long geoUnitNameId, Long geoUnitId,
			String languageDescription, String nameTypeDescription,
			String geoName, Long dataProviderCode) {
		this.geoUnitNameId = geoUnitNameId;
		this.geoUnitId = geoUnitId;
		this.languageDescription = languageDescription;
		this.nameTypeDescription = nameTypeDescription;
		this.geoName = geoName;
		this.dataProviderCode = dataProviderCode;
	}
	
	/**
	 * 
	 * @param geoUnitNameId
	 * @param geoUnitId
	 * @param languageCode
	 * @param nameTypeCode
	 * @param geoName
	 * @param dataProviderCode
	 */
	public GeoUnitName(Long geoUnitNameId, Long geoUnitId, Long languageCode,
			Long nameTypeCode, String geoName, Long dataProviderCode) {
		this.geoUnitNameId = geoUnitNameId;
		this.geoUnitId = geoUnitId;
		this.languageCode = languageCode;
		this.nameTypeCode = nameTypeCode;
		this.geoName = geoName;
		this.dataProviderCode = dataProviderCode;
	}	
	
	
	public GeoUnitName(String geoName){
		this.geoName = geoName;
	}
	
	/**
	 * @return the geoUnitNameId
	 */
	public Long getGeoUnitNameId() {
		return geoUnitNameId;
	}

	/**
	 * @param geoUnitNameId the geoUnitNameId to set
	 */
	public void setGeoUnitNameId(Long geoUnitNameId) {
		this.geoUnitNameId = geoUnitNameId;
	}

	/**
	 * @return the geoUnitId
	 */
	public Long getGeoUnitId() {
		return geoUnitId;
	}

	/**
	 * @param geoUnitId the geoUnitId to set
	 */
	public void setGeoUnitId(Long geoUnitId) {
		this.geoUnitId = geoUnitId;
	}

	/**
	 * @return the languageCode
	 */
	public Long getLanguageCode() {
		return languageCode;
	}

	/**
	 * @param languageCode the languageCode to set
	 */
	public void setLanguageCode(Long languageCode) {
		this.languageCode = languageCode;
	}

	/**
	 * @return the writingScriptCode
	 */
	public Long getWritingScriptCode() {
		return writingScriptCode;
	}

	/**
	 * @param writingScriptCode the writingScriptCode to set
	 */
	public void setWritingScriptCode(Long writingScriptCode) {
		this.writingScriptCode = writingScriptCode;
	}

	/**
	 * @return the nameTypeCode
	 */
	public Long getNameTypeCode() {
		return nameTypeCode;
	}

	/**
	 * @param nameTypeCode the nameTypeCode to set
	 */
	public void setNameTypeCode(Long nameTypeCode) {
		this.nameTypeCode = nameTypeCode;
	}

	/**
	 * @return the geoName
	 */
	public String getGeoName() {
		return geoName;
	}

	/**
	 * @param geoName the geoName to set
	 */
	public void setGeoName(String geoName) {
		this.geoName = geoName;
	}

	/**
	 * @return the dataProviderCode
	 */
	public Long getDataProviderCode() {
		return dataProviderCode;
	}

	/**
	 * @param dataProviderCode the dataProviderCode to set
	 */
	public void setDataProviderCode(Long dataProviderCode) {
		this.dataProviderCode = dataProviderCode;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
		
	}

	/**
	 * @return the expiredByDate
	 */
	public Date getExpiredByDate() {
		return expiredByDate;
	}

	/**
	 * @param expiredByDate the expiredByDate to set
	 */
	public void setExpiredByDate(Date expiredByDate) {
		this.expiredByDate = expiredByDate;
	}

	/**
	 * @return the languageDescription
	 */
	public String getLanguageDescription() {
		return languageDescription;
	}

	/**
	 * @param languageDescription the languageDescription to set
	 */
	public void setLanguageDescription(String languageDescription) {
		this.languageDescription = languageDescription;
	}

	/**
	 * @return the nameTypeDescription
	 */
	public String getNameTypeDescription() {
		return nameTypeDescription;
	}

	/**
	 * @param nameTypeDescription the nameTypeDescription to set
	 */
	public void setNameTypeDescription(String nameTypeDescription) {
		this.nameTypeDescription = nameTypeDescription;
	}
	
	/**
	 * @return the parentGeoUnitId
	 */
        public Long getParentGeoUnitId() {
		return parentGeoUnitId;
	}

	/**
	 * @param parentGeoUnitId the parentGeoUnitId to set
	 */
	public void setParentGeoUnitId(Long parentGeoUnitId) {
		this.parentGeoUnitId = parentGeoUnitId;
	}

	/**
	 * @return the parentGeoUnitOfficialName
	 */
	public String getParentGeoUnitOfficialName() {
		return parentGeoUnitOfficialName;
	}

	/**
	 * @param parentGeoUnitOfficialName the parentGeoUnitOfficialName to set
	 */
	public void setParentGeoUnitOfficialName(String parentGeoUnitOfficialName) {
		this.parentGeoUnitOfficialName = parentGeoUnitOfficialName;
	}

	/**
	 * @return the changeIndicator
	 */
	public String getChangeIndicator() {
		return changeIndicator;
	}

	/**
	 * @param changeIndicator the changeIndicator to set
	 */
	public void setChangeIndicator(String changeIndicator) {
		this.changeIndicator = changeIndicator;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GeoUnitName [geoUnitNameId=" + geoUnitNameId + ", geoUnitId="
				+ geoUnitId + ", languageCode=" + languageCode
				+ ", nameTypeCode=" + nameTypeCode + ", geoName=" + geoName
				+ ", expiredByDate=" + expiredByDate
				+ ", expirationDate=" + expirationDate
				+ ", dataProviderCode=" + dataProviderCode + "]";
	}
	/**
	 * @return the parentGeoUnit
	 */
	public GeoUnit getParentGeoUnit() {
		return parentGeoUnit;
	}

	/**
	 * @param parentGeoUnit the parentGeoUnit to set
	 */
	public void setParentGeoUnit(GeoUnit parentGeoUnit) {
		this.parentGeoUnit = parentGeoUnit;
	}
	/**
	 * @return the geoUnitBulkId
	 */
	public String getGeoUnitBulkId() {
		return geoUnitBulkId;
	}

	/**
	 * @param geoUnitBulkId the geoUnitBulkId to set
	 */
	public void setGeoUnitBulkId(String geoUnitBulkId) {
		this.geoUnitBulkId = geoUnitBulkId;
	}

	/**
	 * @return the errorCD
	 */
	public String getErrorCD() {
		return errorCD;
	}

	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(String errorCD) {
		this.errorCD = errorCD;
	}

	/**
	 * @return the dataProviderDescription
	 */
	public String getDataProviderDescription() {
		return dataProviderDescription;
	}

	/**
	 * @param dataProviderDescription the dataProviderDescription to set
	 */
	public void setDataProviderDescription(String dataProviderDescription) {
		this.dataProviderDescription = dataProviderDescription;
	}
}
