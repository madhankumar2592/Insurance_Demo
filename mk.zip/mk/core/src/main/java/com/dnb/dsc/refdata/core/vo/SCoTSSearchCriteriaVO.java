/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.util.List;

import org.springframework.stereotype.Component;

import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueAssociation;

/**
 * This class used as an value object class.
 * 
 * @author Cognizant
 * @version last updated : Mar 23, 2012
 * @see
 * 
 */
@Component
public class SCoTSSearchCriteriaVO extends PaginationVO {

	private static final long serialVersionUID = 2L;

	// fields for the Code Table Search $starts$
	private String tableDescription;
	
	private Long systemApplicabilityCode;
	
	private Long countryApplicabilityCode;
	// fields for the Code Table Search $ends$
	
	// fields for the List Code Table $starts$
	private Long codeTableId;
	
	private Long languageCode;
	// fields for the List Code Table $ends$
	
	// fields for the Search Code Value $starts$
	private Long codeValueId;
	
	private String codeValueDescription;
	
	private String codeValueBusinessDescription;
	// fields for the Search Code Value $ends$
	
	// fields for the manage SCoTs Relationship $starts$
	private Long parentCodeTableId;
	
	private Long childCodeTableId;
	
	private List<CodeValueAssociation> codeValueAssociations;
	// fields for the manage SCoTs Relationship $ends$
	
	// fields for the manage Alternate Scheme Code $starts$
	private Long alternateSchemeTypeCode;
	
	private List<CodeValueAlternateScheme> codeValueAlternateSchemes;	
	// fields for the manage Alternate Scheme Code $ends$
	
	/**
	 * Constructor
	 */
	public SCoTSSearchCriteriaVO() {
		super();
	}

	/**
	 * @return the tableDescription
	 */
	public String getTableDescription() {
		return tableDescription;
	}

	/**
	 * @param tableDescription the tableDescription to set
	 */
	public void setTableDescription(String tableDescription) {
		this.tableDescription = tableDescription;
	}

	/**
	 * @return the systemApplicabilityCode
	 */
	public Long getSystemApplicabilityCode() {
		return systemApplicabilityCode;
	}

	/**
	 * @param systemApplicabilityCode the systemApplicabilityCode to set
	 */
	public void setSystemApplicabilityCode(Long systemApplicabilityCode) {
		this.systemApplicabilityCode = systemApplicabilityCode;
	}

	/**
	 * @return the countryApplicabilityCode
	 */
	public Long getCountryApplicabilityCode() {
		return countryApplicabilityCode;
	}

	/**
	 * @param countryApplicabilityCode the countryApplicabilityCode to set
	 */
	public void setCountryApplicabilityCode(Long countryApplicabilityCode) {
		this.countryApplicabilityCode = countryApplicabilityCode;
	}

	/**
	 * @return the codeTableId
	 */
	public Long getCodeTableId() {
		return codeTableId;
	}

	/**
	 * @param codeTableId the codeTableId to set
	 */
	public void setCodeTableId(Long codeTableId) {
		this.codeTableId = codeTableId;
	}

	/**
	 * @return the languageCode
	 */
	public Long getLanguageCode() {
		return languageCode;
	}

	/**
	 * @param languageCode the languageCode to set
	 */
	public void setLanguageCode(Long languageCode) {
		this.languageCode = languageCode;
	}

	/**
	 * @return the codeValueId
	 */
	public Long getCodeValueId() {
		return codeValueId;
	}

	/**
	 * @param codeValueId the codeValueId to set
	 */
	public void setCodeValueId(Long codeValueId) {
		this.codeValueId = codeValueId;
	}

	/**
	 * @return the codeValueDescription
	 */
	public String getCodeValueDescription() {
		return codeValueDescription;
	}

	/**
	 * @param codeValueDescription the codeValueDescription to set
	 */
	public void setCodeValueDescription(String codeValueDescription) {
		this.codeValueDescription = codeValueDescription;
	}

	/**
	 * @return the codeValueBusinessDescription
	 */
	public String getCodeValueBusinessDescription() {
		return codeValueBusinessDescription;
	}

	/**
	 * @param codeValueBusinessDescription the codeValueBusinessDescription to set
	 */
	public void setCodeValueBusinessDescription(String codeValueBusinessDescription) {
		this.codeValueBusinessDescription = codeValueBusinessDescription;
	}

	/**
	 * @return the parentCodeTableId
	 */
	public Long getParentCodeTableId() {
		return parentCodeTableId;
	}

	/**
	 * @param parentCodeTableId the parentCodeTableId to set
	 */
	public void setParentCodeTableId(Long parentCodeTableId) {
		this.parentCodeTableId = parentCodeTableId;
	}

	/**
	 * @return the childCodeTableId
	 */
	public Long getChildCodeTableId() {
		return childCodeTableId;
	}

	/**
	 * @param childCodeTableId the childCodeTableId to set
	 */
	public void setChildCodeTableId(Long childCodeTableId) {
		this.childCodeTableId = childCodeTableId;
	}

	/**
	 * @return the codeValueAssociations
	 */
	public List<CodeValueAssociation> getCodeValueAssociations() {
		return codeValueAssociations;
	}

	/**
	 * @param codeValueAssociations the codeValueAssociations to set
	 */
	public void setCodeValueAssociations(
			List<CodeValueAssociation> codeValueAssociations) {
		this.codeValueAssociations = codeValueAssociations;
	}

	/**
	 * @return the alternateSchemeTypeCode
	 */
	public Long getAlternateSchemeTypeCode() {
		return alternateSchemeTypeCode;
	}

	/**
	 * @param alternateSchemeTypeCode the alternateSchemeTypeCode to set
	 */
	public void setAlternateSchemeTypeCode(Long alternateSchemeTypeCode) {
		this.alternateSchemeTypeCode = alternateSchemeTypeCode;
	}

	/**
	 * @return the codeValueAlternateSchemes
	 */
	public List<CodeValueAlternateScheme> getCodeValueAlternateSchemes() {
		return codeValueAlternateSchemes;
	}

	/**
	 * @param codeValueAlternateSchemes the codeValueAlternateSchemes to set
	 */
	public void setCodeValueAlternateSchemes(
			List<CodeValueAlternateScheme> codeValueAlternateSchemes) {
		this.codeValueAlternateSchemes = codeValueAlternateSchemes;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SCoTSSearchCriteriaVO [tableDescription=" + tableDescription
				+ ", systemApplicabilityCode=" + systemApplicabilityCode
				+ ", countryApplicabilityCode=" + countryApplicabilityCode
				+ ", codeTableId=" + codeTableId + ", languageCode="
				+ languageCode + ", codeValueId=" + codeValueId
				+ ", codeValueDescription=" + codeValueDescription
				+ ", codeValueBusinessDescription="
				+ codeValueBusinessDescription + ", parentCodeTableId="
				+ parentCodeTableId + ", childCodeTableId=" + childCodeTableId
				+ ", codeValueAssociations=" + codeValueAssociations
				+ ", alternateSchemeTypeCode=" + alternateSchemeTypeCode
				+ ", codeValueAlternateSchemes=" + codeValueAlternateSchemes
				+ "]";
	}
}
