/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.util.List;

import org.springframework.stereotype.Component;

/**
 * This class is used as a value object class for handling Industry Code Search process.
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Component
public class IndustryCodesSearchCriteriaVO extends PaginationVO {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	private String industryCodeTypeCode;
	private String industryCodeDescription;
	private String industryCodeCrosswalk;
	private String industryCode;
	private String description;

	private String industryCodeTypeCodeLiteralDescription;
	private String industryCodeCrosswalkLiteralDescription;
	private Long industryCodeLanguageCode;
	private Long industryCrossWalkLanguageCode;
	
	private List<Long> industryGroupLevelCodes;
	private String viewType;
	
	/**
	 * Empty Constructor.
	 */
	public IndustryCodesSearchCriteriaVO() {
		super();
	}

	/**
	 * Parameterized Constructor.
	 * 
	 * @param industryCodeTypeCode
	 * @param industryCodeDescription
	 * @param industryCodeCrosswalk
	 * @param industryCode
	 * @param description
	 */
	public IndustryCodesSearchCriteriaVO(String industryCodeTypeCode,
			String industryCodeDescription, String industryCodeCrosswalk,
			String industryCode, String description) {
		super();
		this.industryCodeTypeCode = industryCodeTypeCode;
		this.industryCodeDescription = industryCodeDescription;
		this.industryCodeCrosswalk = industryCodeCrosswalk;
		this.industryCode = industryCode;
		this.description = description;
	}
	

	/**
	 * @return the viewType
	 */
	public String getViewType() {
		return viewType;
	}

	/**
	 * @param viewType the viewType to set
	 */
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	/**
	 * @return the industryCodeTypeCode
	 */
	public String getIndustryCodeTypeCode() {
		return industryCodeTypeCode;
	}

	/**
	 * @param industryCodeTypeCode the industryCodeTypeCode to set
	 */
	public void setIndustryCodeTypeCode(String industryCodeTypeCode) {
		this.industryCodeTypeCode = industryCodeTypeCode;
	}

	/**
	 * @return the industryCodeDescription
	 */
	public String getIndustryCodeDescription() {
		return industryCodeDescription;
	}

	/**
	 * @param industryCodeDescription the industryCodeDescription to set
	 */
	public void setIndustryCodeDescription(String industryCodeDescription) {
		this.industryCodeDescription = industryCodeDescription;
	}

	/**
	 * @return the industryCodeCrosswalk
	 */
	public String getIndustryCodeCrosswalk() {
		return industryCodeCrosswalk;
	}

	/**
	 * @param industryCodeCrosswalk the industryCodeCrosswalk to set
	 */
	public void setIndustryCodeCrosswalk(String industryCodeCrosswalk) {
		this.industryCodeCrosswalk = industryCodeCrosswalk;
	}

	/**
	 * @return the industryCode
	 */
	public String getIndustryCode() {
		return industryCode;
	}

	/**
	 * @param industryCode the industryCode to set
	 */
	public void setIndustryCode(String industryCode) {
		this.industryCode = industryCode;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	
	/**
	 * @return the industryCodeTypeCodeLiteralDescription
	 */
	public String getIndustryCodeTypeCodeLiteralDescription() {
		return industryCodeTypeCodeLiteralDescription;
	}

	/**
	 * @param industryCodeTypeCodeLiteralDescription the industryCodeTypeCodeLiteralDescription to set
	 */
	public void setIndustryCodeTypeCodeLiteralDescription(
			String industryCodeTypeCodeLiteralDescription) {
		this.industryCodeTypeCodeLiteralDescription = industryCodeTypeCodeLiteralDescription;
	}

	/**
	 * @return the industryCodeCrosswalkLiteralDescription
	 */
	public String getIndustryCodeCrosswalkLiteralDescription() {
		return industryCodeCrosswalkLiteralDescription;
	}

	/**
	 * @param industryCodeCrosswalkLiteralDescription the industryCodeCrosswalkLiteralDescription to set
	 */
	public void setIndustryCodeCrosswalkLiteralDescription(
			String industryCodeCrosswalkLiteralDescription) {
		this.industryCodeCrosswalkLiteralDescription = industryCodeCrosswalkLiteralDescription;
	}	
	
	/**
	 * @return the industryCodeLanguageCode
	 */
	public Long getIndustryCodeLanguageCode() {
		return industryCodeLanguageCode;
	}

	/**
	 * @param industryCodeLanguageCode the industryCodeLanguageCode to set
	 */
	public void setIndustryCodeLanguageCode(Long industryCodeLanguageCode) {
		this.industryCodeLanguageCode = industryCodeLanguageCode;
	}

	/**
	 * @return the industryCrossWalkLanguageCode
	 */
	public Long getIndustryCrossWalkLanguageCode() {
		return industryCrossWalkLanguageCode;
	}

	/**
	 * @param industryCrossWalkLanguageCode the industryCrossWalkLanguageCode to set
	 */
	public void setIndustryCrossWalkLanguageCode(
			Long industryCrossWalkLanguageCode) {
		this.industryCrossWalkLanguageCode = industryCrossWalkLanguageCode;
	}

	/**
	 * @return the industryGroupLevelCodes
	 */
	public List<Long> getIndustryGroupLevelCodes() {
		return industryGroupLevelCodes;
	}

	/**
	 * @param industryGroupLevelCodes the industryGroupLevelCodes to set
	 */
	public void setIndustryGroupLevelCodes(List<Long> industryGroupLevelCodes) {
		this.industryGroupLevelCodes = industryGroupLevelCodes;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "IndustryCodesSearchCriteriaVO [industryCodeTypeCode="
				+ industryCodeTypeCode + ", industryCodeDescription="
				+ industryCodeDescription + ", industryCodeCrosswalk="
				+ industryCodeCrosswalk + ", industryCode=" + industryCode
				+ ", description=" + description
				+ ", industryCodeLanguageCode=" + industryCodeLanguageCode
				+ ", industryCrossWalkLanguageCode="
				+ industryCrossWalkLanguageCode + ", industryGroupLevelCodes="
				+ industryGroupLevelCodes + "]";
	}
}
