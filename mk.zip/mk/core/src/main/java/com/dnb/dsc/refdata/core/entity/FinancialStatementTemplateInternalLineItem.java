/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *	Entity for finl_stmt_tmplt_intrl_ln_itm table
 *
 * @author Cognizant
 * @version last updated : June 14, 2012
 * @see
 *
 */
@Entity
@Table(name = "finl_stmt_tmplt_intrl_ln_itm")
@NamedQueries({
	@NamedQuery(name = "FinancialStatementTemplateInternalLineItem.removeFinancialStatementTemplateInternalLineItemById", query = "DELETE FinancialStatementTemplateInternalLineItem i where i.financialStatementTemplateLineItemId = :financialStatementTemplateLineItemId")
})
public class FinancialStatementTemplateInternalLineItem extends Audit{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "FINL_STMT_TMPLT_LN_ITM_ID")
	private Long financialStatementTemplateLineItemId;

	@Column(name = "INTRL_LN_ITM_CODE")
	private String internalLineItemCode;
	
	public FinancialStatementTemplateInternalLineItem(){

	}

	/**
	 * @return the financialStatementTemplateInternalLineItemId
	 */
	public Long getFinancialStatementTemplateLineItemId() {
		return financialStatementTemplateLineItemId;
	}

	/**
	 * @param financialStatementTemplateInternalLineItemId the financialStatementTemplateInternalLineItemId to set
	 */
	public void setFinancialStatementTemplateLineItemId(
			Long financialStatementTemplateLineItemId) {
		this.financialStatementTemplateLineItemId = financialStatementTemplateLineItemId;
	}

	/**
	 * @return the internalLineItemCode
	 */
	public String getInternalLineItemCode() {
		return internalLineItemCode;
	}

	/**
	 * @param internalLineItemCode the internalLineItemCode to set
	 */
	public void setInternalLineItemCode(String internalLineItemCode) {
		this.internalLineItemCode = internalLineItemCode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FinancialStatementTemplateInternalLineItem [financialStatementTemplateLineItemId="
				+ financialStatementTemplateLineItemId
				+ ", internalLineItemCode=" + internalLineItemCode + "]";
	}
	
}
