/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import com.dnb.dsc.refdata.core.entity.CodeValueAlternateScheme;
import com.dnb.dsc.refdata.core.entity.CodeValueText;

/**
* This class used as an value object class for the BatchVO. The class
* will store the code values for all the Batch elements.
*
* @author Cognizant
* @version last updated : Jan 25, 2011
* @see
*
*/

public class ScotsBatchVO {
	private Long cdTableId;
	private String cdTableName;
	private CodeValueText cdValText;
	private String writingCdDesc;
	private String langCdDesc;
	private CodeValueAlternateScheme cdValAltcheme;
	/**
	 * @return the cdTableId
	 */
	public Long getCdTableId() {
		return cdTableId;
	}
	/**
	 * @param cdTableId the cdTableId to set
	 */
	public void setCdTableId(Long cdTableId) {
		this.cdTableId = cdTableId;
	}
	/**
	 * @return the cdTableName
	 */
	public String getCdTableName() {
		return cdTableName;
	}
	/**
	 * @param cdTableName the cdTableName to set
	 */
	public void setCdTableName(String cdTableName) {
		this.cdTableName = cdTableName;
	}
	/**
	 * @return the cdValText
	 */
	public CodeValueText getCdValText() {
		return cdValText;
	}
	/**
	 * @param cdValText the cdValText to set
	 */
	public void setCdValText(CodeValueText cdValText) {
		this.cdValText = cdValText;
	}
	/**
	 * @return the writingCdDesc
	 */
	public String getWritingCdDesc() {
		return writingCdDesc;
	}
	/**
	 * @param writingCdDesc the writingCdDesc to set
	 */
	public void setWritingCdDesc(String writingCdDesc) {
		this.writingCdDesc = writingCdDesc;
	}
	/**
	 * @return the langCdDesc
	 */
	public String getLangCdDesc() {
		return langCdDesc;
	}
	/**
	 * @param langCdDesc the langCdDesc to set
	 */
	public void setLangCdDesc(String langCdDesc) {
		this.langCdDesc = langCdDesc;
	}
	/**
	 * @return the cdValAltcheme
	 */
	public CodeValueAlternateScheme getCdValAltcheme() {
		return cdValAltcheme;
	}
	/**
	 * @param cdValAltcheme the cdValAltcheme to set
	 */
	public void setCdValAltcheme(CodeValueAlternateScheme cdValAltcheme) {
		this.cdValAltcheme = cdValAltcheme;
	}
	
	

}
