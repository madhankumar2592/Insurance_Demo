package com.dnb.dsc.refdata.core.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "dnb_unus_adr")
@NamedQueries({
	@NamedQuery(name = "DnbUnusAdr.removeDnbUnusAdrById", query = "DELETE DnbUnusAdr a where a.dnbUnusGlsyId = :dnbUnusGlsyId")
})	
public class DnbUnusAdr extends Audit {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "dnb_unus_glsy_id")
	private Long dnbUnusGlsyId;

	@Column(name = "post_bx_nbr")
	private String postBxNbr;

	@Column(name = "post_rte_nbr")
	private String postRteNbr;

	@Column(name = "bldg_nme")
	private String bldgNme;

	@Column(name = "strNbr")
	private String strNbr;

	@Column(name = "str_nbr_extn_txt")
	private String strNbrExtnTxt;

	@Column(name = "str_to_nbr")
	private String strToNbr;

	@Column(name = "str_to_nbr_extn_txt")
	private String strToNbrExtnTxt;

	@Column(name = "str_nme")
	private String strNme;

	@Column(name = "scdy_str_nme")
	private String scdyStrNme;

	@Column(name = "locn_txt")
	private String locnTxt;

	@Column(name = "esteNme")
	private String esteNme;

	@Column(name = "minr_town_subd_nme")
	private String minrTownSubdNme;

	@Column(name = "minr_town_nme")
	private String minrTownNme;

	@Column(name = "prim_town_nme")
	private String primTownNme;

	@Column(name = "post_code")
	private String postCode;

	@Column(name = "post_code_extn_code")
	private String postCodeExtnCode;

	@Column(name = "cnty_nme")
	private String cntyNme;

	@Column(name = "terr_nme")
	private String terrNme;

	@Column(name = "bldg_intrl_stru_unit_typ_txt")
	private String bldgIntrlStruUnitTypTxt;

	@Column(name = "post_rte_bx_nbr")
	private String postRteBxNbr;

	@Column(name = "fll_post_code")
	private String fllPostCode;

	@Column(name = "str_dsgn_txt")
	private String strDsgnTxt;

	@Column(name = "ctry_geo_unit_id")
	private long ctryGeoUnitId;

	@Column(name = "ln_1_adr")
	private String ln1Adr;

	@Column(name = "ln_2_adr")
	private String ln2Adr;

	/**
	 * @return the dnbUnusGlsyId
	 */
	public Long getDnbUnusGlsyId() {
		return dnbUnusGlsyId;
	}

	/**
	 * @param dnbUnusGlsyId the dnbUnusGlsyId to set
	 */
	public void setDnbUnusGlsyId(Long dnbUnusGlsyId) {
		this.dnbUnusGlsyId = dnbUnusGlsyId;
	}

	/**
	 * @return the postBxNbr
	 */
	public String getPostBxNbr() {
		return postBxNbr;
	}

	/**
	 * @param postBxNbr the postBxNbr to set
	 */
	public void setPostBxNbr(String postBxNbr) {
		this.postBxNbr = postBxNbr;
	}

	/**
	 * @return the postRteNbr
	 */
	public String getPostRteNbr() {
		return postRteNbr;
	}

	/**
	 * @param postRteNbr the postRteNbr to set
	 */
	public void setPostRteNbr(String postRteNbr) {
		this.postRteNbr = postRteNbr;
	}

	/**
	 * @return the bldgNme
	 */
	public String getBldgNme() {
		return bldgNme;
	}

	/**
	 * @param bldgNme the bldgNme to set
	 */
	public void setBldgNme(String bldgNme) {
		this.bldgNme = bldgNme;
	}

	/**
	 * @return the strNbr
	 */
	public String getStrNbr() {
		return strNbr;
	}

	/**
	 * @param strNbr the strNbr to set
	 */
	public void setStrNbr(String strNbr) {
		this.strNbr = strNbr;
	}

	/**
	 * @return the strNbrExtnTxt
	 */
	public String getStrNbrExtnTxt() {
		return strNbrExtnTxt;
	}

	/**
	 * @param strNbrExtnTxt the strNbrExtnTxt to set
	 */
	public void setStrNbrExtnTxt(String strNbrExtnTxt) {
		this.strNbrExtnTxt = strNbrExtnTxt;
	}

	/**
	 * @return the strToNbr
	 */
	public String getStrToNbr() {
		return strToNbr;
	}

	/**
	 * @param strToNbr the strToNbr to set
	 */
	public void setStrToNbr(String strToNbr) {
		this.strToNbr = strToNbr;
	}

	/**
	 * @return the strToNbrExtnTxt
	 */
	public String getStrToNbrExtnTxt() {
		return strToNbrExtnTxt;
	}

	/**
	 * @param strToNbrExtnTxt the strToNbrExtnTxt to set
	 */
	public void setStrToNbrExtnTxt(String strToNbrExtnTxt) {
		this.strToNbrExtnTxt = strToNbrExtnTxt;
	}

	/**
	 * @return the strNme
	 */
	public String getStrNme() {
		return strNme;
	}

	/**
	 * @param strNme the strNme to set
	 */
	public void setStrNme(String strNme) {
		this.strNme = strNme;
	}

	/**
	 * @return the scdyStrNme
	 */
	public String getScdyStrNme() {
		return scdyStrNme;
	}

	/**
	 * @param scdyStrNme the scdyStrNme to set
	 */
	public void setScdyStrNme(String scdyStrNme) {
		this.scdyStrNme = scdyStrNme;
	}

	/**
	 * @return the locnTxt
	 */
	public String getLocnTxt() {
		return locnTxt;
	}

	/**
	 * @param locnTxt the locnTxt to set
	 */
	public void setLocnTxt(String locnTxt) {
		this.locnTxt = locnTxt;
	}

	/**
	 * @return the esteNme
	 */
	public String getEsteNme() {
		return esteNme;
	}

	/**
	 * @param esteNme the esteNme to set
	 */
	public void setEsteNme(String esteNme) {
		this.esteNme = esteNme;
	}

	/**
	 * @return the minrTownSubdNme
	 */
	public String getMinrTownSubdNme() {
		return minrTownSubdNme;
	}

	/**
	 * @param minrTownSubdNme the minrTownSubdNme to set
	 */
	public void setMinrTownSubdNme(String minrTownSubdNme) {
		this.minrTownSubdNme = minrTownSubdNme;
	}

	/**
	 * @return the minrTownNme
	 */
	public String getMinrTownNme() {
		return minrTownNme;
	}

	/**
	 * @param minrTownNme the minrTownNme to set
	 */
	public void setMinrTownNme(String minrTownNme) {
		this.minrTownNme = minrTownNme;
	}

	/**
	 * @return the primTownNme
	 */
	public String getPrimTownNme() {
		return primTownNme;
	}

	/**
	 * @param primTownNme the primTownNme to set
	 */
	public void setPrimTownNme(String primTownNme) {
		this.primTownNme = primTownNme;
	}

	/**
	 * @return the postCode
	 */
	public String getPostCode() {
		return postCode;
	}

	/**
	 * @param postCode the postCode to set
	 */
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	/**
	 * @return the postCodeExtnCode
	 */
	public String getPostCodeExtnCode() {
		return postCodeExtnCode;
	}

	/**
	 * @param postCodeExtnCode the postCodeExtnCode to set
	 */
	public void setPostCodeExtnCode(String postCodeExtnCode) {
		this.postCodeExtnCode = postCodeExtnCode;
	}

	/**
	 * @return the cntyNme
	 */
	public String getCntyNme() {
		return cntyNme;
	}

	/**
	 * @param cntyNme the cntyNme to set
	 */
	public void setCntyNme(String cntyNme) {
		this.cntyNme = cntyNme;
	}

	/**
	 * @return the terrNme
	 */
	public String getTerrNme() {
		return terrNme;
	}

	/**
	 * @param terrNme the terrNme to set
	 */
	public void setTerrNme(String terrNme) {
		this.terrNme = terrNme;
	}

	/**
	 * @return the bldgIntrlStruUnitTypTxt
	 */
	public String getBldgIntrlStruUnitTypTxt() {
		return bldgIntrlStruUnitTypTxt;
	}

	/**
	 * @param bldgIntrlStruUnitTypTxt the bldgIntrlStruUnitTypTxt to set
	 */
	public void setBldgIntrlStruUnitTypTxt(String bldgIntrlStruUnitTypTxt) {
		this.bldgIntrlStruUnitTypTxt = bldgIntrlStruUnitTypTxt;
	}

	/**
	 * @return the postRteBxNbr
	 */
	public String getPostRteBxNbr() {
		return postRteBxNbr;
	}

	/**
	 * @param postRteBxNbr the postRteBxNbr to set
	 */
	public void setPostRteBxNbr(String postRteBxNbr) {
		this.postRteBxNbr = postRteBxNbr;
	}

	/**
	 * @return the fllPostCode
	 */
	public String getFllPostCode() {
		return fllPostCode;
	}

	/**
	 * @param fllPostCode the fllPostCode to set
	 */
	public void setFllPostCode(String fllPostCode) {
		this.fllPostCode = fllPostCode;
	}

	/**
	 * @return the strDsgnTxt
	 */
	public String getStrDsgnTxt() {
		return strDsgnTxt;
	}

	/**
	 * @param strDsgnTxt the strDsgnTxt to set
	 */
	public void setStrDsgnTxt(String strDsgnTxt) {
		this.strDsgnTxt = strDsgnTxt;
	}

	/**
	 * @return the ctryGeoUnitId
	 */
	public long getCtryGeoUnitId() {
		return ctryGeoUnitId;
	}

	/**
	 * @param ctryGeoUnitId the ctryGeoUnitId to set
	 */
	public void setCtryGeoUnitId(long ctryGeoUnitId) {
		this.ctryGeoUnitId = ctryGeoUnitId;
	}

	/**
	 * @return the ln1Adr
	 */
	public String getLn1Adr() {
		return ln1Adr;
	}

	/**
	 * @param ln1Adr the ln1Adr to set
	 */
	public void setLn1Adr(String ln1Adr) {
		this.ln1Adr = ln1Adr;
	}

	/**
	 * @return the ln2Adr
	 */
	public String getLn2Adr() {
		return ln2Adr;
	}

	/**
	 * @param ln2Adr the ln2Adr to set
	 */
	public void setLn2Adr(String ln2Adr) {
		this.ln2Adr = ln2Adr;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DnbUnusAdr [dnbUnusGlsyId=" + dnbUnusGlsyId + ", postBxNbr="
				+ postBxNbr + ", postRteNbr=" + postRteNbr + ", bldgNme="
				+ bldgNme + ", strNbr=" + strNbr + ", strNbrExtnTxt="
				+ strNbrExtnTxt + ", strToNbr=" + strToNbr
				+ ", strToNbrExtnTxt=" + strToNbrExtnTxt + ", strNme=" + strNme
				+ ", scdyStrNme=" + scdyStrNme + ", locnTxt=" + locnTxt
				+ ", esteNme=" + esteNme + ", minrTownSubdNme="
				+ minrTownSubdNme + ", minrTownNme=" + minrTownNme
				+ ", primTownNme=" + primTownNme + ", postCode=" + postCode
				+ ", postCodeExtnCode=" + postCodeExtnCode + ", cntyNme="
				+ cntyNme + ", terrNme=" + terrNme
				+ ", bldgIntrlStruUnitTypTxt=" + bldgIntrlStruUnitTypTxt
				+ ", postRteBxNbr=" + postRteBxNbr + ", fllPostCode="
				+ fllPostCode + ", strDsgnTxt=" + strDsgnTxt
				+ ", ctryGeoUnitId=" + ctryGeoUnitId + ", ln1Adr=" + ln1Adr
				+ ", ln2Adr=" + ln2Adr + "]";
	}

}
