package com.dnb.dsc.refdata.core.vo;

public class ScotsPropertyFileVO {
	
	private String outputFilePath;
	private String errorFilePath;
	private String cdTblIdCheckQuery;
	private String cdValIdCheckQuery;
	private String cdValTxtQuery;
	private String cdValTxtIdQuery;
	private String cdValAltSchmIdQuery;
	private String cdValAltSchmTypCdQuery;
	private String cdValSysAppyQuery;
	private String sysAppyIdQuery;
	private String ctryGeoUnitIdQuery;
	private String ctryAppyIdQuery;
	private String cdValueInsertQuery; 
	private String cdValTxtInsertQuery; 
	private String cdValAltSchmInsertQuery; 
	private String cntryAppyInsertQuery; 
	private String sysAppyInsertQuery; 
	private String codeValIdSeqQuery;
	
	private String codeValUpdateQuery;
	private String codeValDeleteQuery;
	private String cdValTxtDeleteQuery;
	private String cdValAltSchmDeleteQuery;
	private String sysAppyDeleteQuery;
	private String ctryAppyDeleteQuery;
	private String cdValTxtIdDeleteQuery;
	private String cdValAltSchmIdDeleteQuery;
	private String sysAppyIdDeleteQuery;
	private String ctryAppyIdDeleteQuery;
	private String loadOutputFilePath;
	private String loadErrorFilePath;
	private String lastSequenceNumberQuery;
	private String alterSequenceQuery;
	private String resetSequenceNumberQuery;
	private String maxCodeValueIdQuery;
	
	
	public ScotsPropertyFileVO(String outputFilePath,String errorFilePath,String cdTblIdCheckQuery,
			String cdValIdCheckQuery,String cdValTxtQuery,String cdValTxtIdQuery,
			String cdValAltSchmIdQuery,String cdValAltSchmTypCdQuery,
			String cdValSysAppyQuery,String sysAppyIdQuery,String ctryGeoUnitIdQuery,
			String ctryAppyIdQuery,String cdValueInsertQuery,String cdValTxtInsertQuery,
			String cdValAltSchmInsertQuery,String cntryAppyInsertQuery,String sysAppyInsertQuery,String codeValIdSeqQuery,
			String codeValUpdateQuery,String codeValDeleteQuery,String cdValTxtDeleteQuery,
			String cdValAltSchmDeleteQuery,String sysAppyDeleteQuery,String ctryAppyDeleteQuery,
			String cdValTxtIdDeleteQuery,String cdValAltSchmIdDeleteQuery,String sysAppyIdDeleteQuery,
			String ctryAppyIdDeleteQuery,
			String loadOutputFilePath ,String loadErrorFilePath,String lastSequenceNumberQuery,String alterSequenceQuery,
			String resetSequenceNumberQuery,String maxCodeValueIdQuery){
		this.outputFilePath = outputFilePath;
		this.errorFilePath = errorFilePath;
		this.cdTblIdCheckQuery = cdTblIdCheckQuery;
		this.cdValIdCheckQuery = cdValIdCheckQuery;
		this.cdValTxtQuery = cdValTxtQuery;
		this.cdValTxtIdQuery = cdValTxtIdQuery;
		this.cdValAltSchmIdQuery = cdValAltSchmIdQuery;
		this.cdValAltSchmTypCdQuery = cdValAltSchmTypCdQuery;
		this.cdValSysAppyQuery = cdValSysAppyQuery;
		this.sysAppyIdQuery = sysAppyIdQuery;
		this.ctryGeoUnitIdQuery = ctryGeoUnitIdQuery;
		this.ctryAppyIdQuery = ctryAppyIdQuery;
		this.cdValueInsertQuery = cdValueInsertQuery; 
		this.cdValTxtInsertQuery = cdValTxtInsertQuery; 
		this.cdValAltSchmInsertQuery = cdValAltSchmInsertQuery; 
		this.cntryAppyInsertQuery = cntryAppyInsertQuery; 
		this.sysAppyInsertQuery = sysAppyInsertQuery; 
		this.codeValIdSeqQuery = codeValIdSeqQuery;
		this.codeValUpdateQuery=codeValUpdateQuery;
		this.codeValDeleteQuery=codeValDeleteQuery;
		this.cdValTxtDeleteQuery=cdValTxtDeleteQuery;
		this.cdValAltSchmDeleteQuery=cdValAltSchmDeleteQuery;
		this.sysAppyDeleteQuery=sysAppyDeleteQuery;
		this.ctryAppyDeleteQuery=ctryAppyDeleteQuery;
		this.cdValTxtIdDeleteQuery=cdValTxtIdDeleteQuery;
		this.cdValAltSchmIdDeleteQuery=cdValAltSchmIdDeleteQuery;
		this.sysAppyIdDeleteQuery=sysAppyIdDeleteQuery;
		this.ctryAppyIdDeleteQuery=ctryAppyIdDeleteQuery;
		this.loadOutputFilePath = loadOutputFilePath;
		this.loadErrorFilePath = loadErrorFilePath;
		this.lastSequenceNumberQuery = lastSequenceNumberQuery;
		this.alterSequenceQuery = alterSequenceQuery;
		this.resetSequenceNumberQuery = resetSequenceNumberQuery;
		this.maxCodeValueIdQuery = maxCodeValueIdQuery;
	}
	
	
	
	
	
	
	/**
	 * @return the codeValUpdateQuery
	 */
	public String getCodeValUpdateQuery() {
		return codeValUpdateQuery;
	}


	/**
	 * @param codeValUpdateQuery the codeValUpdateQuery to set
	 */
	public void setCodeValUpdateQuery(String codeValUpdateQuery) {
		this.codeValUpdateQuery = codeValUpdateQuery;
	}


	/**
	 * @return the codeValDeleteQuery
	 */
	public String getCodeValDeleteQuery() {
		return codeValDeleteQuery;
	}


	/**
	 * @param codeValDeleteQuery the codeValDeleteQuery to set
	 */
	public void setCodeValDeleteQuery(String codeValDeleteQuery) {
		this.codeValDeleteQuery = codeValDeleteQuery;
	}


	/**
	 * @return the cdValTxtDeleteQuery
	 */
	public String getCdValTxtDeleteQuery() {
		return cdValTxtDeleteQuery;
	}


	/**
	 * @param cdValTxtDeleteQuery the cdValTxtDeleteQuery to set
	 */
	public void setCdValTxtDeleteQuery(String cdValTxtDeleteQuery) {
		this.cdValTxtDeleteQuery = cdValTxtDeleteQuery;
	}


	/**
	 * @return the cdValAltSchmDeleteQuery
	 */
	public String getCdValAltSchmDeleteQuery() {
		return cdValAltSchmDeleteQuery;
	}


	/**
	 * @param cdValAltSchmDeleteQuery the cdValAltSchmDeleteQuery to set
	 */
	public void setCdValAltSchmDeleteQuery(String cdValAltSchmDeleteQuery) {
		this.cdValAltSchmDeleteQuery = cdValAltSchmDeleteQuery;
	}


	/**
	 * @return the sysAppyDeleteQuery
	 */
	public String getSysAppyDeleteQuery() {
		return sysAppyDeleteQuery;
	}


	/**
	 * @param sysAppyDeleteQuery the sysAppyDeleteQuery to set
	 */
	public void setSysAppyDeleteQuery(String sysAppyDeleteQuery) {
		this.sysAppyDeleteQuery = sysAppyDeleteQuery;
	}


	/**
	 * @return the ctryAppyDeleteQuery
	 */
	public String getCtryAppyDeleteQuery() {
		return ctryAppyDeleteQuery;
	}


	/**
	 * @param ctryAppyDeleteQuery the ctryAppyDeleteQuery to set
	 */
	public void setCtryAppyDeleteQuery(String ctryAppyDeleteQuery) {
		this.ctryAppyDeleteQuery = ctryAppyDeleteQuery;
	}


	/**
	 * @return the cdValTxtIdDeleteQuery
	 */
	public String getCdValTxtIdDeleteQuery() {
		return cdValTxtIdDeleteQuery;
	}


	/**
	 * @param cdValTxtIdDeleteQuery the cdValTxtIdDeleteQuery to set
	 */
	public void setCdValTxtIdDeleteQuery(String cdValTxtIdDeleteQuery) {
		this.cdValTxtIdDeleteQuery = cdValTxtIdDeleteQuery;
	}


	/**
	 * @return the cdValAltSchmIdDeleteQuery
	 */
	public String getCdValAltSchmIdDeleteQuery() {
		return cdValAltSchmIdDeleteQuery;
	}


	/**
	 * @param cdValAltSchmIdDeleteQuery the cdValAltSchmIdDeleteQuery to set
	 */
	public void setCdValAltSchmIdDeleteQuery(String cdValAltSchmIdDeleteQuery) {
		this.cdValAltSchmIdDeleteQuery = cdValAltSchmIdDeleteQuery;
	}


	/**
	 * @return the sysAppyIdDeleteQuery
	 */
	public String getSysAppyIdDeleteQuery() {
		return sysAppyIdDeleteQuery;
	}


	/**
	 * @param sysAppyIdDeleteQuery the sysAppyIdDeleteQuery to set
	 */
	public void setSysAppyIdDeleteQuery(String sysAppyIdDeleteQuery) {
		this.sysAppyIdDeleteQuery = sysAppyIdDeleteQuery;
	}


	/**
	 * @return the ctryAppyIdDeleteQuery
	 */
	public String getCtryAppyIdDeleteQuery() {
		return ctryAppyIdDeleteQuery;
	}


	/**
	 * @param ctryAppyIdDeleteQuery the ctryAppyIdDeleteQuery to set
	 */
	public void setCtryAppyIdDeleteQuery(String ctryAppyIdDeleteQuery) {
		this.ctryAppyIdDeleteQuery = ctryAppyIdDeleteQuery;
	}


	/**
	 * @return the outputFilePath
	 */
	public String getOutputFilePath() {
		return outputFilePath;
	}


	/**
	 * @param outputFilePath the outputFilePath to set
	 */
	public void setOutputFilePath(String outputFilePath) {
		this.outputFilePath = outputFilePath;
	}


	/**
	 * @return the loadOutputFilePath
	 */
	public String getLoadOutputFilePath() {
		return loadOutputFilePath;
	}


	/**
	 * @param loadOutputFilePath the loadOutputFilePath to set
	 */
	public void setLoadOutputFilePath(String loadOutputFilePath) {
		this.loadOutputFilePath = loadOutputFilePath;
	}


	/**
	 * @return the loadErrorFilePath
	 */
	public String getLoadErrorFilePath() {
		return loadErrorFilePath;
	}


	/**
	 * @param loadErrorFilePath the loadErrorFilePath to set
	 */
	public void setLoadErrorFilePath(String loadErrorFilePath) {
		this.loadErrorFilePath = loadErrorFilePath;
	}


	/**
	 * @param cdTblIdCheckQuery the cdTblIdCheckQuery to set
	 */
	public void setCdTblIdCheckQuery(String cdTblIdCheckQuery) {
		this.cdTblIdCheckQuery = cdTblIdCheckQuery;
	}

	/**
	 * @return the cdTblIdCheckQuery
	 */
	public String getCdTblIdCheckQuery() {
		return cdTblIdCheckQuery;
	}

	/**
	 * @param cdValIdCheckQuery the cdValIdCheckQuery to set
	 */
	public void setCdValIdCheckQuery(String cdValIdCheckQuery) {
		this.cdValIdCheckQuery = cdValIdCheckQuery;
	}

	/**
	 * @return the cdValIdCheckQuery
	 */
	public String getCdValIdCheckQuery() {
		return cdValIdCheckQuery;
	}

	/**
	 * @param errorFilePath the errorFilePath to set
	 */
	public void setErrorFilePath(String errorFilePath) {
		this.errorFilePath = errorFilePath;
	}

	/**
	 * @return the errorFilePath
	 */
	public String getErrorFilePath() {
		return errorFilePath;
	}

	/**
	 * @param cdValTxtQuery the cdValTxtQuery to set
	 */
	public void setCdValTxtQuery(String cdValTxtQuery) {
		this.cdValTxtQuery = cdValTxtQuery;
	}

	/**
	 * @return the cdValTxtQuery
	 */
	public String getCdValTxtQuery() {
		return cdValTxtQuery;
	}

	/**
	 * @param cdValTxtIdQuery the cdValTxtIdQuery to set
	 */
	public void setCdValTxtIdQuery(String cdValTxtIdQuery) {
		this.cdValTxtIdQuery = cdValTxtIdQuery;
	}

	/**
	 * @return the cdValTxtIdQuery
	 */
	public String getCdValTxtIdQuery() {
		return cdValTxtIdQuery;
	}

	/**
	 * @param cdValAltSchmIdQuery the cdValAltSchmIdQuery to set
	 */
	public void setCdValAltSchmIdQuery(String cdValAltSchmIdQuery) {
		this.cdValAltSchmIdQuery = cdValAltSchmIdQuery;
	}

	/**
	 * @return the cdValAltSchmIdQuery
	 */
	public String getCdValAltSchmIdQuery() {
		return cdValAltSchmIdQuery;
	}

	/**
	 * @param cdValAltSchmTypCdQuery the cdValAltSchmTypCdQuery to set
	 */
	public void setCdValAltSchmTypCdQuery(String cdValAltSchmTypCdQuery) {
		this.cdValAltSchmTypCdQuery = cdValAltSchmTypCdQuery;
	}

	/**
	 * @return the cdValAltSchmTypCdQuery
	 */
	public String getCdValAltSchmTypCdQuery() {
		return cdValAltSchmTypCdQuery;
	}

	/**
	 * @param cdValSysAppyQuery the cdValSysAppyQuery to set
	 */
	public void setCdValSysAppyQuery(String cdValSysAppyQuery) {
		this.cdValSysAppyQuery = cdValSysAppyQuery;
	}

	/**
	 * @return the cdValSysAppyQuery
	 */
	public String getCdValSysAppyQuery() {
		return cdValSysAppyQuery;
	}

	/**
	 * @param sysAppyIdQuery the sysAppyIdQuery to set
	 */
	public void setSysAppyIdQuery(String sysAppyIdQuery) {
		this.sysAppyIdQuery = sysAppyIdQuery;
	}

	/**
	 * @return the sysAppyIdQuery
	 */
	public String getSysAppyIdQuery() {
		return sysAppyIdQuery;
	}

	/**
	 * @param ctryGeoUnitIdQuery the ctryGeoUnitIdQuery to set
	 */
	public void setCtryGeoUnitIdQuery(String ctryGeoUnitIdQuery) {
		this.ctryGeoUnitIdQuery = ctryGeoUnitIdQuery;
	}

	/**
	 * @return the ctryGeoUnitIdQuery
	 */
	public String getCtryGeoUnitIdQuery() {
		return ctryGeoUnitIdQuery;
	}

	/**
	 * @param ctryAppyIdQuery the ctryAppyIdQuery to set
	 */
	public void setCtryAppyIdQuery(String ctryAppyIdQuery) {
		this.ctryAppyIdQuery = ctryAppyIdQuery;
	}

	/**
	 * @return the ctryAppyIdQuery
	 */
	public String getCtryAppyIdQuery() {
		return ctryAppyIdQuery;
	}

	/**
	 * @return the cdValueInsertQuery
	 */
	public String getCdValueInsertQuery() {
		return cdValueInsertQuery;
	}

	/**
	 * @param cdValueInsertQuery the cdValueInsertQuery to set
	 */
	public void setCdValueInsertQuery(String cdValueInsertQuery) {
		this.cdValueInsertQuery = cdValueInsertQuery;
	}

	/**
	 * @return the cdValTxtInsertQuery
	 */
	public String getCdValTxtInsertQuery() {
		return cdValTxtInsertQuery;
	}

	/**
	 * @param cdValTxtInsertQuery the cdValTxtInsertQuery to set
	 */
	public void setCdValTxtInsertQuery(String cdValTxtInsertQuery) {
		this.cdValTxtInsertQuery = cdValTxtInsertQuery;
	}

	/**
	 * @return the cdValAltSchmInsertQuery
	 */
	public String getCdValAltSchmInsertQuery() {
		return cdValAltSchmInsertQuery;
	}

	/**
	 * @param cdValAltSchmInsertQuery the cdValAltSchmInsertQuery to set
	 */
	public void setCdValAltSchmInsertQuery(String cdValAltSchmInsertQuery) {
		this.cdValAltSchmInsertQuery = cdValAltSchmInsertQuery;
	}

	/**
	 * @return the cntryAppyInsertQuery
	 */
	public String getCntryAppyInsertQuery() {
		return cntryAppyInsertQuery;
	}

	/**
	 * @param cntryAppyInsertQuery the cntryAppyInsertQuery to set
	 */
	public void setCntryAppyInsertQuery(String cntryAppyInsertQuery) {
		this.cntryAppyInsertQuery = cntryAppyInsertQuery;
	}

	/**
	 * @return the sysAppyInsertQuery
	 */
	public String getSysAppyInsertQuery() {
		return sysAppyInsertQuery;
	}

	/**
	 * @param sysAppyInsertQuery the sysAppyInsertQuery to set
	 */
	public void setSysAppyInsertQuery(String sysAppyInsertQuery) {
		this.sysAppyInsertQuery = sysAppyInsertQuery;
	}

	/**
	 * @return the codeValIdSeqQuery
	 */
	public String getCodeValIdSeqQuery() {
		return codeValIdSeqQuery;
	}

	/**
	 * @param codeValIdSeqQuery the codeValIdSeqQuery to set
	 */
	public void setCodeValIdSeqQuery(String codeValIdSeqQuery) {
		this.codeValIdSeqQuery = codeValIdSeqQuery;
	}






	/**
	 * @param lastSequenceNumberQuery the lastSequenceNumberQuery to set
	 */
	public void setLastSequenceNumberQuery(String lastSequenceNumberQuery) {
		this.lastSequenceNumberQuery = lastSequenceNumberQuery;
	}






	/**
	 * @return the lastSequenceNumberQuery
	 */
	public String getLastSequenceNumberQuery() {
		return lastSequenceNumberQuery;
	}






	/**
	 * @param alterSequenceQuery the alterSequenceQuery to set
	 */
	public void setAlterSequenceQuery(String alterSequenceQuery) {
		this.alterSequenceQuery = alterSequenceQuery;
	}






	/**
	 * @return the alterSequenceQuery
	 */
	public String getAlterSequenceQuery() {
		return alterSequenceQuery;
	}






	/**
	 * @param resetSequenceNumberQuery the resetSequenceNumberQuery to set
	 */
	public void setResetSequenceNumberQuery(String resetSequenceNumberQuery) {
		this.resetSequenceNumberQuery = resetSequenceNumberQuery;
	}






	/**
	 * @return the resetSequenceNumberQuery
	 */
	public String getResetSequenceNumberQuery() {
		return resetSequenceNumberQuery;
	}






	/**
	 * @param maxCodeValueIdQuery the maxCodeValueIdQuery to set
	 */
	public void setMaxCodeValueIdQuery(String maxCodeValueIdQuery) {
		this.maxCodeValueIdQuery = maxCodeValueIdQuery;
	}






	/**
	 * @return the maxCodeValueIdQuery
	 */
	public String getMaxCodeValueIdQuery() {
		return maxCodeValueIdQuery;
	}

	
	
	

}
