
/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the ScoreMapping. The class will have a
 * direct mapping toe DB table inds_code_desc.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "SCR_MAP")
@NamedQueries({ 
	@NamedQuery(name = "ScoreMapping.removeIndustryCodeDescriptionByIndustryCodeId", query = "DELETE FROM IndustryCodeDescription i where i.industryCodeId = :industryCodeId"),
	@NamedQuery(name = "ScoreMapping.removeByIndustryCodeDescriptionId", query = "DELETE FROM IndustryCodeDescription i where i.industryCodeDescriptionId = :industryCodeDescriptionId "),
	@NamedQuery(name = "ScoreMapping.retreiveScoreMappingById", query = "SELECT distinct(c.scoreGruAssociationId) from ScoreMapping c where c.scoreMapId not in ( :scoreMapId) and c.scoreId = :scoreId"),
	@NamedQuery(name = "ScoreMapping.removeScoreMappingById", query = "DELETE FROM ScoreMapping c where c.scoreMapId not in ( :scoreMapId) and c.scoreId = :scoreId"),
	@NamedQuery(name = "ScoreMapping.removeScoreMappingId", query = "DELETE FROM ScoreMapping c where c.scoreId = :scoreId")

})
public class ScoreMapping extends Audit {
	
	/**
	 * Serial Version ID.
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "SCR_MAP_ID ")
	private Long scoreMapId;
	
	@Column(name = "SCR_ID")
	private Long scoreId;
	
	@Column(name = "PRNT_SCR_ID")
	private Long parentScoreId;
	
	@Column(name = "SCR_GRU_ASSN_ID")
	private Long scoreGruAssociationId;
	
	@Column(name = "SCR_ATTR_VAL")
	private String scoreAttributeValue;
		
	@Column(name = "INAC_INDC")
	private Long inactiveIndc;
	
	
	/**
	 * @return the inactiveIndc
	 */
	public Long getInactiveIndc() {
		return inactiveIndc;
	}

	/**
	 * @param inactiveIndc the inactiveIndc to set
	 */
	public void setInactiveIndc(Long inactiveIndc) {
		this.inactiveIndc = inactiveIndc;
	}

	/**
	 * @return the scoreMapId
	 */
	public Long getScoreMapId() {
		return scoreMapId;
	}

	/**
	 * @param scoreMapId the scoreMapId to set
	 */
	public void setScoreMapId(Long scoreMapId) {
		this.scoreMapId = scoreMapId;
	}

	/**
	 * @return the scoreId
	 */
	public Long getScoreId() {
		return scoreId;
	}

	/**
	 * @param scoreId the scoreId to set
	 */
	public void setScoreId(Long scoreId) {
		this.scoreId = scoreId;
	}

	/**
	 * @return the parentScoreId
	 */
	public Long getParentScoreId() {
		return parentScoreId;
	}

	/**
	 * @param parentScoreId the parentScoreId to set
	 */
	public void setParentScoreId(Long parentScoreId) {
		this.parentScoreId = parentScoreId;
	}

	/**
	 * @return the scoreGruAssociationId
	 */
	public Long getScoreGruAssociationId() {
		return scoreGruAssociationId;
	}

	/**
	 * @param scoreGruAssociationId the scoreGruAssociationId to set
	 */
	public void setScoreGruAssociationId(Long scoreGruAssociationId) {
		this.scoreGruAssociationId = scoreGruAssociationId;
	}

	/**
	 * @return the scoreAttributeValue
	 */
	public String getScoreAttributeValue() {
		return scoreAttributeValue;
	}

	/**
	 * @param scoreAttributeValue the scoreAttributeValue to set
	 */
	public void setScoreAttributeValue(String scoreAttributeValue) {
		this.scoreAttributeValue = scoreAttributeValue;
	}

	/**
	 * Empty Constructor.
	 */
	public ScoreMapping() {
		super();
	}

	/**
	 * 
	 * @param scoreMapId
	 * @param scoreId
	 * @param parentScoreId
	 * @param scoreGruAssociationId
	 * @param scoreAttributeValue
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 */
	public ScoreMapping(Long scoreMapId,
			Long scoreId, Long parentScoreId, Long scoreGruAssociationId, String scoreAttributeValue,Long inactiveIndc,
			String createdUser, Date createdDate, String modifiedUser,
			Date modifiedDate) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.scoreMapId = scoreMapId;
		this.scoreId = scoreId;
		this.inactiveIndc = inactiveIndc;
		this.parentScoreId = parentScoreId;
		this.scoreGruAssociationId = scoreGruAssociationId;
		this.scoreAttributeValue = scoreAttributeValue;
		
	}

	
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "scoreMapId [scoreMapId="
				+ scoreMapId + ", scoreId="
				+ scoreId + ", parentScoreId=" + parentScoreId
				+ ", scoreGruAssociationId=" + scoreGruAssociationId
				+ ", scoreAttributeValue=" + scoreAttributeValue
				+ "]";
	}
}