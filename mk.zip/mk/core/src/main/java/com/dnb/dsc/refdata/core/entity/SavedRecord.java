/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * This class used as an entity class for the SavedRecords. The class will have a
 * direct mapping to DB table ui_svd_rec.<p>
 * 
 * @author Cognizant
 * @version last updated : Jun 18, 2012
 * @see
 * 
 */
@Entity
@Table(name = "UI_SVD_REC")
@NamedQueries({
		@NamedQuery(name = "SavedRecord.countByDomainId", query = "FROM SavedRecord s WHERE s.domainId = :domainId "),
		@NamedQuery(name = "SavedRecord.removeByDomainId", query = "DELETE FROM SavedRecord s WHERE s.domainId = :domainId "),
		@NamedQuery(name = "SavedRecord.retrieveByDomainName", query = "SELECT new SavedRecord(s.savedRecordId, s.userId, s.domainId, s.domainName, s.changeTypeCode, s.userComment, s.createdDate) From SavedRecord s WHERE s.domainName like (:domainName)")
})
public class SavedRecord implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5089442744051881L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "svdRecordsIdGenerator")
	@SequenceGenerator(name = "svdRecordsIdGenerator", sequenceName = "soruiconfig.UI_SVD_REC_ID_SEQ", allocationSize = 1)
	@Column(name = "UI_SVD_REC_ID")
	private Long savedRecordId;
	
	@Column(name = "USR_ID")
	private String userId;
	
	@Column(name = "DOMN_ID")
	private Long domainId;
	
	@Column(name = "DOMN_NME")
	private String domainName;
	
	@Column(name = "CHG_TYP_CODE")
	private Long changeTypeCode;
	
	@Column(name = "USR_CMNT")
	private String userComment;
	
	@Column(name = "CRE_DT")
	private Date createdDate;
	
	@Transient
	private String changeType;
	
	@Transient
	private String dateAsString;
	
	/**
	 * Empty Constructor.
	 */
	public SavedRecord() {
		super();
	}
	
	
	public SavedRecord(String userId){
		this.userId = userId;
	}

	/**
	 * @param savedRecordId
	 * @param userId
	 * @param domainId
	 * @param domainName
	 * @param changeTypeCode
	 * @param userComment
	 * @param createdDate
	 */
	public SavedRecord(Long savedRecordId, String userId, Long domainId,
			String domainName, Long changeTypeCode, String userComment,
			Date createdDate) {
		super();
		this.savedRecordId = savedRecordId;
		this.userId = userId;
		this.domainId = domainId;
		this.domainName = domainName;
		this.changeTypeCode = changeTypeCode;
		this.userComment = userComment;
		this.createdDate = createdDate;
	}

	/**
	 * @return the savedRecordId
	 */
	public Long getSavedRecordId() {
		return savedRecordId;
	}

	/**
	 * @param savedRecordId the savedRecordId to set
	 */
	public void setSavedRecordId(Long savedRecordId) {
		this.savedRecordId = savedRecordId;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the domainId
	 */
	public Long getDomainId() {
		return domainId;
	}

	/**
	 * @param domainId the domainId to set
	 */
	public void setDomainId(Long domainId) {
		this.domainId = domainId;
	}

	/**
	 * @return the domainName
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * @param domainName the domainName to set
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @return the changeTypeCode
	 */
	public Long getChangeTypeCode() {
		return changeTypeCode;
	}

	/**
	 * @param changeTypeCode the changeTypeCode to set
	 */
	public void setChangeTypeCode(Long changeTypeCode) {
		this.changeTypeCode = changeTypeCode;
	}

	/**
	 * @return the userComment
	 */
	public String getUserComment() {
		return userComment;
	}

	/**
	 * @param userComment the userComment to set
	 */
	public void setUserComment(String userComment) {
		this.userComment = userComment;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	
	/**
	 * @return the changeType
	 */
	public String getChangeType() {
		return changeType;
	}

	/**
	 * @param changeType the changeType to set
	 */
	public void setChangeType(String changeType) {
		this.changeType = changeType;
	}

	/**
	 * @return the dateAsString
	 */
	public String getDateAsString() {
		return dateAsString;
	}

	/**
	 * @param dateAsString the dateAsString to set
	 */
	public void setDateAsString(String dateAsString) {
		this.dateAsString = dateAsString;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SavedRecord [savedRecordId=" + savedRecordId + ", userId="
				+ userId + ", domainId=" + domainId + ", domainName="
				+ domainName + ", changeTypeCode=" + changeTypeCode
				+ ", userComment=" + userComment + ", createdDate="
				+ createdDate + ", changeType=" + changeType + "]";
	}
}
