/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "SLS_CHNL_DTL")
@NamedQueries({
	@NamedQuery(name = "SalesChannelDetails.removesalesDtlById", query = "DELETE FROM SalesChannelDetails c where c.salesChnlDtlId not in ( :salesChnlDtlId) and salesChnlId = :salesChnlId")

		
		})
public class SalesChannelDetails extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "SLS_CHNL_DTL_ID")
	private Long salesChnlDtlId;
		
	@Column(name = "SLS_CHNL_ID")
	private Long salesChnlId;
	
	@Column(name = "SLS_CHNL_DTL_MTDT_CD")
	private Long salesChnlDtlMetaDataCode;
	
	@Column(name = "SLS_CHNL_DTL_MTDT_VAL")
	private String salesChnlDtlMetaDataVal;	
	
	public Long getSalesChnlDtlId() {
		return salesChnlDtlId;
	}

	public void setSalesChnlDtlId(Long salesChnlDtlId) {
		this.salesChnlDtlId = salesChnlDtlId;
	}

	public Long getSalesChnlId() {
		return salesChnlId;
	}

	public void setSalesChnlId(Long salesChnlId) {
		this.salesChnlId = salesChnlId;
	}

	public Long getSalesChnlDtlMetaDataCode() {
		return salesChnlDtlMetaDataCode;
	}

	public void setSalesChnlDtlMetaDataCode(Long salesChnlDtlMetaDataCode) {
		this.salesChnlDtlMetaDataCode = salesChnlDtlMetaDataCode;
	}

	public String getSalesChnlDtlMetaDataVal() {
		return salesChnlDtlMetaDataVal;
	}

	public void setSalesChnlDtlMetaDataVal(String salesChnlDtlMetaDataVal) {
		this.salesChnlDtlMetaDataVal = salesChnlDtlMetaDataVal;
	}

	/**
	 * Empty Constructor.
	 */
	public SalesChannelDetails() {
		super();
	}
	
	public SalesChannelDetails(Long salesChnlDtlId) {
		super();
		this.salesChnlDtlId = salesChnlDtlId;
	}
	/*public SalesChannelDetails(Long SalesChannelDetailsVersion) {
		super();
		this.SalesChannelDetailsVersion = SalesChannelDetailsVersion;
	}*/
	public SalesChannelDetails(Long salesChnlDtlId, Long salesChnlId) {
		super();
		this.salesChnlDtlId = salesChnlDtlId;
		this.salesChnlId = salesChnlId;
	}
	
	
	/**
	 * 
	 * @param SalesChannelDetailsId
	 * @param SalesChannelDetailsVersion
	 * @param SalesChannelDetailsTypeId
	 * @param SalesChannelDetailsMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public SalesChannelDetails(Long salesChnlDtlId, Long salesChnlId, Long salesChnlDtlMetaDataCode, String salesChnlDtlMetaDataVal,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.salesChnlDtlId = salesChnlDtlId;
		this.salesChnlId = salesChnlId;
		this.salesChnlDtlMetaDataCode = salesChnlDtlMetaDataCode;
		this.salesChnlDtlMetaDataVal = salesChnlDtlMetaDataVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SalesChannelDetails [salesChnlDtlId=" + salesChnlDtlId
				+ ", salesChnlId=" + salesChnlId 
				+"salesChnlDtlMetaDataCode=" + salesChnlDtlMetaDataCode+ 
				", salesChnlDtlMetaDataVal=" + salesChnlDtlMetaDataVal + 
				 "]";
	}
	
	
}
