
/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCodeDescription. The class will have a
 * direct mapping toe DB table inds_code_desc.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "SCR_TYP_ASSN")
@NamedQueries({ 
	@NamedQuery(name = "ScoreTypeAssociation.removeIndustryCodeDescriptionByIndustryCodeId", query = "DELETE FROM IndustryCodeDescription i where i.industryCodeId = :industryCodeId"),
	@NamedQuery(name = "ScoreTypeAssociation.removeByIndustryCodeDescriptionId", query = "DELETE FROM IndustryCodeDescription i where i.industryCodeDescriptionId = :industryCodeDescriptionId ")
})
public class ScoreTypeAssociation extends Audit {
	
	/**
	 * Serial Version ID.
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "SCR_TYP_ASSN_ID")
	private Long scoreTypeAssociationId;
	
	@Column(name = "SCR_TYP_ID")
	private Long scoreTypeId;
	
	@Column(name = "SCR_GRU_ID")
	private Long granularityTypeId;
	
	/**
	 * @return the scoreTypeAssociationId
	 */
	public Long getScoreTypeAssociationId() {
		return scoreTypeAssociationId;
	}

	/**
	 * @param scoreTypeAssociationId the scoreTypeAssociationId to set
	 */
	public void setScoreTypeAssociationId(Long scoreTypeAssociationId) {
		this.scoreTypeAssociationId = scoreTypeAssociationId;
	}

	/**
	 * @return the scoreTypeId
	 */
	public Long getScoreTypeId() {
		return scoreTypeId;
	}

	/**
	 * @param scoreTypeId the scoreTypeId to set
	 */
	public void setScoreTypeId(Long scoreTypeId) {
		this.scoreTypeId = scoreTypeId;
	}

	/**
	 * @return the scoreGranularityId
	 */
	public Long getGranularityTypeId() {
		return granularityTypeId;
	}

	/**
	 * @param scoreGranularityId the scoreGranularityId to set
	 */
	public void setGranularityTypeId(Long granularityTypeId) {
		this.granularityTypeId = granularityTypeId;
	}


	/**
	 * Empty Constructor.
	 */
	public ScoreTypeAssociation() {
		super();
	}

	/**
	 * 
	 * @param scoreTypeAssociationId
	 * @param scoreTypeId
	 * @param scoreGranularityId
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 */
	public ScoreTypeAssociation(Long scoreTypeAssociationId,
			Long scoreTypeId, Long granularityTypeId, 
			String createdUser, Date createdDate, String modifiedUser,
			Date modifiedDate) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.scoreTypeAssociationId = scoreTypeAssociationId;
		this.scoreTypeId = scoreTypeId;
		this.granularityTypeId = granularityTypeId;
		
	}

	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "scoreTypeAssociationId [scoreTypeAssociationId="
				+ scoreTypeAssociationId + ", scoreTypeId="
				+ scoreTypeId + ", granularityTypeId=" + granularityTypeId
				+ "]";
	}
}
