package com.dnb.dsc.refdata.core.vo;
public class GeoPropertyFileVO {

	private String validateGeoUnitIdQuery;
	private String validateGeoNmeIdQuery;
	private String validateGeoCodeIdQuery;
	private String validateGeoUnitAssnIdQuery;
	private String validateGeoUnitTypCdQuery;
	private String validateGeoNameTypCdQuery;
	private String validateGeoCdTypCdQuery;	
	private String geoUnitIdSeqQuery;
	private String geoUnitInsertQuery;
	private String geoUnitNmeInsertQuery;
	private String geoUnitCodeInsertQuery;
	
	private String geoUnitDeleteQuery;
	private String geoUnitNmeDeleteQuery;
	private String geoUnitCodeDeleteQuery;
	private String geoUnitAssnPrntDeleteQuery;
	private String geoUnitAssnChldDeleteQuery;
	private String geoUnitNmeIdDeleteQuery;
	private String geoUnitCodeIdDeleteQuery;
	
	private String geoUnitAssnInsertQuery;
	private String geoUnitAssnUpdateQuery;
	private String geoOutputFilePath;
	private String geoErrorFilePath;
	private String geoLoadOutputFilePath;
	private String geoLoadErrorFilePath;
	

	// private String cdValQuery;
	// private String validateIdQuery;

	public GeoPropertyFileVO(String validateGeoUnitIdQuery,
			String validateGeoNmeIdQuery, String validateGeoCodeIdQuery,
			String validateGeoUnitAssnIdQuery,
			String validateGeoUnitTypCdQuery, String validateGeoNameTypCdQuery,
			String validateGeoCdTypCdQuery,String geoUnitIdSeqQuery,
			String geoUnitInsertQuery,String geoUnitNmeInsertQuery,
			String geoUnitCodeInsertQuery,String geoUnitDeleteQuery,
			String geoUnitNmeDeleteQuery,String geoUnitCodeDeleteQuery,
			String geoUnitAssnPrntDeleteQuery,String geoUnitAssnChldDeleteQuery,
			String geoUnitNmeIdDeleteQuery,String geoUnitCodeIdDeleteQuery,
			String geoUnitAssnInsertQuery,String geoUnitAssnUpdateQuery,String geoOutputFilePath,
			String geoErrorFilePath,String geoLoadOutputFilePath,String geoLoadErrorFilePath) {

		this.validateGeoUnitIdQuery = validateGeoUnitIdQuery;
		this.validateGeoNmeIdQuery = validateGeoNmeIdQuery;
		this.validateGeoCodeIdQuery = validateGeoCodeIdQuery;
		this.validateGeoUnitAssnIdQuery = validateGeoUnitAssnIdQuery;
		this.validateGeoUnitTypCdQuery = validateGeoUnitTypCdQuery;
		this.validateGeoNameTypCdQuery = validateGeoNameTypCdQuery;
		this.validateGeoCdTypCdQuery = validateGeoCdTypCdQuery;
		this.geoUnitIdSeqQuery = geoUnitIdSeqQuery;
		this.geoUnitInsertQuery = geoUnitInsertQuery;
		this.geoUnitNmeInsertQuery = geoUnitNmeInsertQuery;
		this.geoUnitCodeInsertQuery = geoUnitCodeInsertQuery;
		
		this.geoUnitDeleteQuery=geoUnitDeleteQuery;
		this.geoUnitNmeDeleteQuery=geoUnitNmeDeleteQuery;
		this.geoUnitCodeDeleteQuery=geoUnitCodeDeleteQuery;
		this.geoUnitAssnPrntDeleteQuery=geoUnitAssnPrntDeleteQuery;
		this.geoUnitAssnChldDeleteQuery=geoUnitAssnChldDeleteQuery;
		this.geoUnitNmeIdDeleteQuery=geoUnitNmeIdDeleteQuery;
		this.geoUnitCodeIdDeleteQuery=geoUnitCodeIdDeleteQuery;
		
		this.geoUnitAssnInsertQuery = geoUnitAssnInsertQuery; 
		this.geoUnitAssnUpdateQuery = geoUnitAssnUpdateQuery;
		this.geoOutputFilePath = geoOutputFilePath;
		this.geoErrorFilePath = geoErrorFilePath;
		this.geoLoadOutputFilePath = geoLoadOutputFilePath;
		this.geoLoadErrorFilePath = geoLoadErrorFilePath;
	}

	/**
	 * @return the validateGeoUnitIdQuery
	 */
	public String getValidateGeoUnitIdQuery() {
		return validateGeoUnitIdQuery;
	}

	/**
	 * @param validateGeoUnitIdQuery
	 *            the validateGeoUnitIdQuery to set
	 */
	public void setValidateGeoUnitIdQuery(String validateGeoUnitIdQuery) {
		this.validateGeoUnitIdQuery = validateGeoUnitIdQuery;
	}

	/**
	 * @return the validateGeoNmeIdQuery
	 */
	public String getValidateGeoNmeIdQuery() {
		return validateGeoNmeIdQuery;
	}

	/**
	 * @param validateGeoNmeIdQuery
	 *            the validateGeoNmeIdQuery to set
	 */
	public void setValidateGeoNmeIdQuery(String validateGeoNmeIdQuery) {
		this.validateGeoNmeIdQuery = validateGeoNmeIdQuery;
	}

	/**
	 * @return the validateGeoCodeIdQuery
	 */
	public String getValidateGeoCodeIdQuery() {
		return validateGeoCodeIdQuery;
	}

	/**
	 * @param validateGeoCodeIdQuery
	 *            the validateGeoCodeIdQuery to set
	 */
	public void setValidateGeoCodeIdQuery(String validateGeoCodeIdQuery) {
		this.validateGeoCodeIdQuery = validateGeoCodeIdQuery;
	}

	/**
	 * @return the validateGeoUnitAssnIdQuery
	 */
	public String getValidateGeoUnitAssnIdQuery() {
		return validateGeoUnitAssnIdQuery;
	}

	/**
	 * @param validateGeoUnitAssnIdQuery
	 *            the validateGeoUnitAssnIdQuery to set
	 */
	public void setValidateGeoUnitAssnIdQuery(String validateGeoUnitAssnIdQuery) {
		this.validateGeoUnitAssnIdQuery = validateGeoUnitAssnIdQuery;
	}

	/**
	 * @return the validateGeoUnitTypCdQuery
	 */
	public String getValidateGeoUnitTypCdQuery() {
		return validateGeoUnitTypCdQuery;
	}

	/**
	 * @param validateGeoUnitTypCdQuery
	 *            the validateGeoUnitTypCdQuery to set
	 */
	public void setValidateGeoUnitTypCdQuery(String validateGeoUnitTypCdQuery) {
		this.validateGeoUnitTypCdQuery = validateGeoUnitTypCdQuery;
	}

	/**
	 * @return the validateGeoNameTypCdQuery
	 */
	public String getValidateGeoNameTypCdQuery() {
		return validateGeoNameTypCdQuery;
	}

	/**
	 * @param validateGeoNameTypCdQuery
	 *            the validateGeoNameTypCdQuery to set
	 */
	public void setValidateGeoNameTypCdQuery(String validateGeoNameTypCdQuery) {
		this.validateGeoNameTypCdQuery = validateGeoNameTypCdQuery;
	}

	/**
	 * @return the validateGeoCdTypCdQuery
	 */
	public String getValidateGeoCdTypCdQuery() {
		return validateGeoCdTypCdQuery;
	}

	/**
	 * @param validateGeoCdTypCdQuery
	 *            the validateGeoCdTypCdQuery to set
	 */
	public void setValidateGeoCdTypCdQuery(String validateGeoCdTypCdQuery) {
		this.validateGeoCdTypCdQuery = validateGeoCdTypCdQuery;
	}

	/**
	 * @return the geoUnitAssnUpdateQuery
	 */
	public String getGeoUnitAssnUpdateQuery() {
		return geoUnitAssnUpdateQuery;
	}

	/**
	 * @param geoUnitAssnUpdateQuery the geoUnitAssnUpdateQuery to set
	 */
	public void setGeoUnitAssnUpdateQuery(String geoUnitAssnUpdateQuery) {
		this.geoUnitAssnUpdateQuery = geoUnitAssnUpdateQuery;
	}
	 /*
	  * * @return the geoOutputFilePath
	 */
	public String getGeoOutputFilePath() {
		return geoOutputFilePath;
	}

	/**
	 * @param geoOutputFilePath
	 *            the geoOutputFilePath to set
	 */
	public void setGeoOutputFilePath(String geoOutputFilePath) {
		this.geoOutputFilePath = geoOutputFilePath;
	}

	/**
	 * @return the geoErrorFilePath
	 */
	public String getGeoErrorFilePath() {
		return geoErrorFilePath;
	}

	/**
	 * @param geoErrorFilePath
	 *            the geoErrorFilePath to set
	 */
	public void setGeoErrorFilePath(String geoErrorFilePath) {
		this.geoErrorFilePath = geoErrorFilePath;
	}

	/**
	 * @return the geoUnitIdSeqQuery
	 */
	public String getGeoUnitIdSeqQuery() {
		return geoUnitIdSeqQuery;
	}

	/**
	 * @param geoUnitIdSeqQuery the geoUnitIdSeqQuery to set
	 */
	public void setGeoUnitIdSeqQuery(String geoUnitIdSeqQuery) {
		this.geoUnitIdSeqQuery = geoUnitIdSeqQuery;
	}

	/**
	 * @return the geoUnitInsertQuery
	 */
	public String getGeoUnitInsertQuery() {
		return geoUnitInsertQuery;
	}

	/**
	 * @param geoUnitInsertQuery the geoUnitInsertQuery to set
	 */
	public void setGeoUnitInsertQuery(String geoUnitInsertQuery) {
		this.geoUnitInsertQuery = geoUnitInsertQuery;
	}

	/**
	 * @return the geoUnitNmeInsertQuery
	 */
	public String getGeoUnitNmeInsertQuery() {
		return geoUnitNmeInsertQuery;
	}

	/**
	 * @param geoUnitNmeInsertQuery the geoUnitNmeInsertQuery to set
	 */
	public void setGeoUnitNmeInsertQuery(String geoUnitNmeInsertQuery) {
		this.geoUnitNmeInsertQuery = geoUnitNmeInsertQuery;
	}

	/**
	 * @return the geoUnitCodeInsertQuery
	 */
	public String getGeoUnitCodeInsertQuery() {
		return geoUnitCodeInsertQuery;
	}

	/**
	 * @param geoUnitCodeInsertQuery the geoUnitCodeInsertQuery to set
	 */
	public void setGeoUnitCodeInsertQuery(String geoUnitCodeInsertQuery) {
		this.geoUnitCodeInsertQuery = geoUnitCodeInsertQuery;
	}

	/**
	 * @return the geoUnitAssnInsertQuery
	 */
	public String getGeoUnitAssnInsertQuery() {
		return geoUnitAssnInsertQuery;
	}

	/**
	 * @param geoUnitAssnInsertQuery the geoUnitAssnInsertQuery to set
	 */
	public void setGeoUnitAssnInsertQuery(String geoUnitAssnInsertQuery) {
		this.geoUnitAssnInsertQuery = geoUnitAssnInsertQuery;
	}
	/*
	 *  * @return the geoLoadOutputFilePath
	 */
	public String getGeoLoadOutputFilePath() {
		return geoLoadOutputFilePath;
	}

	/**
	 * @param geoLoadOutputFilePath the geoLoadOutputFilePath to set
	 */
	public void setGeoLoadOutputFilePath(String geoLoadOutputFilePath) {
		this.geoLoadOutputFilePath = geoLoadOutputFilePath;
	}

	/**
	 * @return the geoLoadErrorFilePath
	 */
	public String getGeoLoadErrorFilePath() {
		return geoLoadErrorFilePath;
	}

	/**
	 * @param geoLoadErrorFilePath the geoLoadErrorFilePath to set
	 */
	public void setGeoLoadErrorFilePath(String geoLoadErrorFilePath) {
		this.geoLoadErrorFilePath = geoLoadErrorFilePath;
	}

	/**
	 * @return the geoUnitDeleteQuery
	 */
	public String getGeoUnitDeleteQuery() {
		return geoUnitDeleteQuery;
	}

	/**
	 * @param geoUnitDeleteQuery the geoUnitDeleteQuery to set
	 */
	public void setGeoUnitDeleteQuery(String geoUnitDeleteQuery) {
		this.geoUnitDeleteQuery = geoUnitDeleteQuery;
	}

	/**
	 * @return the geoUnitNmeDeleteQuery
	 */
	public String getGeoUnitNmeDeleteQuery() {
		return geoUnitNmeDeleteQuery;
	}

	/**
	 * @param geoUnitNmeDeleteQuery the geoUnitNmeDeleteQuery to set
	 */
	public void setGeoUnitNmeDeleteQuery(String geoUnitNmeDeleteQuery) {
		this.geoUnitNmeDeleteQuery = geoUnitNmeDeleteQuery;
	}

	/**
	 * @return the geoUnitCodeDeleteQuery
	 */
	public String getGeoUnitCodeDeleteQuery() {
		return geoUnitCodeDeleteQuery;
	}

	/**
	 * @param geoUnitCodeDeleteQuery the geoUnitCodeDeleteQuery to set
	 */
	public void setGeoUnitCodeDeleteQuery(String geoUnitCodeDeleteQuery) {
		this.geoUnitCodeDeleteQuery = geoUnitCodeDeleteQuery;
	}

	/**
	 * @return the geoUnitAssnPrntDeleteQuery
	 */
	public String getGeoUnitAssnPrntDeleteQuery() {
		return geoUnitAssnPrntDeleteQuery;
	}

	/**
	 * @param geoUnitAssnPrntDeleteQuery the geoUnitAssnPrntDeleteQuery to set
	 */
	public void setGeoUnitAssnPrntDeleteQuery(String geoUnitAssnPrntDeleteQuery) {
		this.geoUnitAssnPrntDeleteQuery = geoUnitAssnPrntDeleteQuery;
	}

	/**
	 * @return the geoUnitAssnChldDeleteQuery
	 */
	public String getGeoUnitAssnChldDeleteQuery() {
		return geoUnitAssnChldDeleteQuery;
	}

	/**
	 * @param geoUnitAssnChldDeleteQuery the geoUnitAssnChldDeleteQuery to set
	 */
	public void setGeoUnitAssnChldDeleteQuery(String geoUnitAssnChldDeleteQuery) {
		this.geoUnitAssnChldDeleteQuery = geoUnitAssnChldDeleteQuery;
	}

	/**
	 * @return the geoUnitNmeIdDeleteQuery
	 */
	public String getGeoUnitNmeIdDeleteQuery() {
		return geoUnitNmeIdDeleteQuery;
	}

	/**
	 * @param geoUnitNmeIdDeleteQuery the geoUnitNmeIdDeleteQuery to set
	 */
	public void setGeoUnitNmeIdDeleteQuery(String geoUnitNmeIdDeleteQuery) {
		this.geoUnitNmeIdDeleteQuery = geoUnitNmeIdDeleteQuery;
	}

	/**
	 * @return the geoUnitCodeIdDeleteQuery
	 */
	public String getGeoUnitCodeIdDeleteQuery() {
		return geoUnitCodeIdDeleteQuery;
	}

	/**
	 * @param geoUnitCodeIdDeleteQuery the geoUnitCodeIdDeleteQuery to set
	 */
	public void setGeoUnitCodeIdDeleteQuery(String geoUnitCodeIdDeleteQuery) {
		this.geoUnitCodeIdDeleteQuery = geoUnitCodeIdDeleteQuery;
	}
	
	

}
