/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * This class used as an entity class for the GeoCodeConfiguration. The class
 * will have a direct mapping toe DB table UI_GEO_CODE_CONF.
 * 
 * @author Cognizant
 * @version last updated : Nov 12, 2012
 * @see
 * 
 */
@Entity
@Table(name = "UI_GEO_CODE_CONFG")
@NamedQueries({
	@NamedQuery(name = "GeoCodeConfiguration.retrieveGeoUnitCodeConfigurations", query = "SELECT g FROM GeoCodeConfiguration g where g.geoCodeTypeCode = :geoCodeTypeCode") 
	})	
public class GeoCodeConfiguration implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8412698446840115475L;

	@Id
	@Column(name = "UI_GEO_CODE_CONFG_ID")
	private Long geoCodeConfigId;
	
	@Column(name = "CTRY_GEO_UNIT_ID")
	private Long geoUnitId;

	@Column(name = "GEO_CODE_TYP_CD")
	private Long geoCodeTypeCode;

	@Column(name = "GEO_UNIT_TYP_CD")
	private Long geoUnitTypeCode;
	
	@Column(name = "GEO_CODE_TYP_MAX_LEN")
	private Integer codeMaximumLength;
	
	@Column(name = "GEO_CODE_TYP_PAD_INDC")
	private Boolean paddingIndicator;
	
	@Column(name = "PRNT_GEO_UNIT_TYP_CD")
	private Long uniqueWithInGeoUnitTypeCode;
	
	@Transient
	private Long uniqueWithInGeoUnitId;

	/**
	 * @param geoUnitId
	 * @param geoCodeTypeCode
	 * @param geoUnitTypeCode
	 * @param codeMinimumLength
	 * @param codeMaximumLength
	 * @param paddingIndicator
	 * @param uniqueWithInGeoUnitTypeCode
	 */
	public GeoCodeConfiguration(Long geoUnitId, Long geoCodeTypeCode,
			Long geoUnitTypeCode,Integer codeMaximumLength,
			Boolean paddingIndicator, Long uniqueWithInGeoUnitTypeCode) {
		this.geoUnitId = geoUnitId;
		this.geoCodeTypeCode = geoCodeTypeCode;
		this.geoUnitTypeCode = geoUnitTypeCode;		
		this.codeMaximumLength = codeMaximumLength;
		this.paddingIndicator = paddingIndicator;
		this.uniqueWithInGeoUnitTypeCode = uniqueWithInGeoUnitTypeCode;
	}

	/**
	 * 
	 */
	public GeoCodeConfiguration() {
		super();
	}

	/**
	 * @return the geoCodeConfigId
	 */
	public Long getGeoCodeConfigId() {
		return geoCodeConfigId;
	}

	/**
	 * @param geoCodeConfigId the geoCodeConfigId to set
	 */
	public void setGeoCodeConfigId(Long geoCodeConfigId) {
		this.geoCodeConfigId = geoCodeConfigId;
	}

	/**
	 * @return the geoUnitId
	 */
	public Long getGeoUnitId() {
		return geoUnitId;
	}

	/**
	 * @param geoUnitId the geoUnitId to set
	 */
	public void setGeoUnitId(Long geoUnitId) {
		this.geoUnitId = geoUnitId;
	}

	/**
	 * @return the geoCodeTypeCode
	 */
	public Long getGeoCodeTypeCode() {
		return geoCodeTypeCode;
	}

	/**
	 * @param geoCodeTypeCode the geoCodeTypeCode to set
	 */
	public void setGeoCodeTypeCode(Long geoCodeTypeCode) {
		this.geoCodeTypeCode = geoCodeTypeCode;
	}

	/**
	 * @return the geoUnitTypeCode
	 */
	public Long getGeoUnitTypeCode() {
		return geoUnitTypeCode;
	}

	/**
	 * @param geoUnitTypeCode the geoUnitTypeCode to set
	 */
	public void setGeoUnitTypeCode(Long geoUnitTypeCode) {
		this.geoUnitTypeCode = geoUnitTypeCode;
	}
	
	

	/**
	 * @return the codeMaximumLength
	 */
	public Integer getCodeMaximumLength() {
		return codeMaximumLength;
	}

	/**
	 * @param codeMaximumLength the codeMaximumLength to set
	 */
	public void setCodeMaximumLength(Integer codeMaximumLength) {
		this.codeMaximumLength = codeMaximumLength;
	}

	/**
	 * @return the paddingIndicator
	 */
	public Boolean isPaddingIndicator() {
		return paddingIndicator;
	}

	/**
	 * @param paddingIndicator the paddingIndicator to set
	 */
	public void setPaddingIndicator(Boolean paddingIndicator) {
		this.paddingIndicator = paddingIndicator;
	}

	/**
	 * @return the uniqueWithInGeoUnitTypeCode
	 */
	public Long getUniqueWithInGeoUnitTypeCode() {
		return uniqueWithInGeoUnitTypeCode;
	}

	/**
	 * @param uniqueWithInGeoUnitTypeCode the uniqueWithInGeoUnitTypeCode to set
	 */
	public void setUniqueWithInGeoUnitTypeCode(Long uniqueWithInGeoUnitTypeCode) {
		this.uniqueWithInGeoUnitTypeCode = uniqueWithInGeoUnitTypeCode;
	}

	/**
	 * @return the uniqueWithInGeoUnitId
	 */
	public Long getUniqueWithInGeoUnitId() {
		return uniqueWithInGeoUnitId;
	}

	/**
	 * @param uniqueWithInGeoUnitId the uniqueWithInGeoUnitId to set
	 */
	public void setUniqueWithInGeoUnitId(Long uniqueWithInGeoUnitId) {
		this.uniqueWithInGeoUnitId = uniqueWithInGeoUnitId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GeoCodeConfiguration [geoUnitId=" + geoUnitId
				+ ", geoCodeTypeCode=" + geoCodeTypeCode + ", geoUnitTypeCode="
				+ geoUnitTypeCode + ", codeMaximumLength=" + codeMaximumLength
				+ ", paddingIndicator=" + paddingIndicator
				+ ", uniqueWithInGeoUnitTypeCode="
				+ uniqueWithInGeoUnitTypeCode + "]";
	}
}
