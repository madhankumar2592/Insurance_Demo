/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 * This class used as an entity class for the Code Value. The class will have a
 * direct mapping toe DB table cd_val.
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
@Entity
@Table(name = "SYS_APPY")
@NamedQueries({
		@NamedQuery(name = "SystemApplicability.retrieveSystemsForCodeValue", query = "SELECT distinct new SystemApplicability(sa.sysAppyId, sa.dnbSystemCode,sa.applicabilityIndicator, sa.codeTableId, sa.codeValueId,sa.effectiveDate, sa.expirationDate, sa.createdUser,sa.createdDate, sa.modifiedDate, sa.modifiedUser, cvt.codeValueDescription,ct.codeTableName) FROM SystemApplicability sa, CodeValueText cvt , CodeTable ct WHERE sa.applicabilityIndicator = 0 AND cvt.codeValueId = sa.dnbSystemCode AND  sa.codeValueId= :codeValueId AND sa.codeTableId=ct.codeTableId order by sa.dnbSystemCode "),
		@NamedQuery(name = "SystemApplicability.retrieveSystemsForCodeTable", query = "SELECT distinct new SystemApplicability(sa.dnbSystemCode, cvt.codeValueDescription) FROM SystemApplicability sa, CodeValueText cvt , CodeTable ct WHERE cvt.codeValueId = sa.dnbSystemCode AND  sa.codeTableId= :codeTableId AND sa.codeTableId=ct.codeTableId and sa.expirationDate is null and cvt.expirationDate is null order by sa.dnbSystemCode "),
		@NamedQuery(name = "SystemApplicability.retrieveSystemsForCodeTableReview", query = "SELECT sa FROM SystemApplicability sa WHERE sa.applicabilityIndicator = 1 AND  sa.codeTableId= :codeTableId "),
		@NamedQuery(name = "SystemApplicability.retrieveSystemsForCodeValueReview", query = "SELECT sa FROM SystemApplicability sa WHERE sa.applicabilityIndicator = 0 AND  sa.codeValueId= :codeValueId"),
		@NamedQuery(name = "SystemApplicability.retrieveAllSystems", query = "SELECT distinct new SystemApplicability(sa.codeValueId, cvt.codeValueDescription) FROM SystemApplicability sa, CodeValueText cvt WHERE  sa.dnbSystemCode= :dnbSystemCode AND  sa.codeTableId= :codeTableId AND sa.codeValueId= cvt.codeValueId  and cvt.languageCode = 39 order by sa.codeValueId"),
		@NamedQuery(name = "SystemApplicability.retrieveAllSystemsIrrespOfInd", query = "SELECT distinct new SystemApplicability(sa.dnbSystemCode, cvt.codeValueDescription) FROM SystemApplicability sa, CodeValueText cvt WHERE cvt.codeValueId = sa.dnbSystemCode order by sa.dnbSystemCode "),
		@NamedQuery(name = "SystemApplicability.retrieveCodeTableSystems", query = "SELECT distinct new SystemApplicability(sa.sysAppyId, sa.dnbSystemCode, sa.applicabilityIndicator, sa.codeTableId, sa.codeValueId, sa.effectiveDate, sa.expirationDate, sa.createdUser, sa.createdDate, sa.modifiedDate, sa.modifiedUser, cvt.codeValueDescription) FROM SystemApplicability sa, CodeValueText cvt WHERE  sa.codeTableId= :codeTableId AND sa.applicabilityIndicator=1 AND sa.dnbSystemCode= cvt.codeValueId AND cvt.languageCode=39 and sa.expirationDate is null and cvt.expirationDate is null order by sa.dnbSystemCode"),
		@NamedQuery(name = "SystemApplicability.retrieveSystemForCode", query = "SELECT distinct new SystemApplicability(sa.sysAppyId, sa.dnbSystemCode, sa.applicabilityIndicator, sa.codeTableId, sa.codeValueId, cvt.codeValueDescription, ct.codeTableName) FROM SystemApplicability sa, CodeValueText cvt, CodeTable ct WHERE cvt.codeValueId = sa.codeValueId and ct.codeTableId = sa.codeTableId and sa.dnbSystemCode = :dnbSystemCode order by sa.codeTableId"),
		@NamedQuery(name = "SystemApplicability.retrieveSystemForCodeWithoutDescription", query = "SELECT distinct new SystemApplicability(sa.sysAppyId, sa.dnbSystemCode, sa.applicabilityIndicator, sa.codeTableId, sa.codeValueId) FROM SystemApplicability sa WHERE sa.dnbSystemCode = :dnbSystemCode order by sa.codeTableId"),
		@NamedQuery(name = "SystemApplicability.searchSystemByCodeTable", query = "SELECT sa FROM SystemApplicability sa, CodeValueText cvt WHERE  sa.applicabilityIndicator=1 AND  sa.codeTableId= :codeTableId AND cvt.codeValueDescription like :codeValueDescription AND sa.dnbSystemCode = :dnbSystemCode"), 
		@NamedQuery(name = "SystemApplicability.retrieveTxnSystemApplicabilities", query = "SELECT distinct sa FROM SystemApplicability sa WHERE sa.dnbSystemCode = :dnbSystemCode "),
		@NamedQuery(name = "SystemApplicability.removeSystemApplicabilities", query = "DELETE SystemApplicability sa WHERE sa.dnbSystemCode = :dnbSystemCode "),
		@NamedQuery(name = "SystemApplicability.removeSystemByCodeTableById", query = "DELETE SystemApplicability sa WHERE sa.codeTableId = :codeTableId and applicabilityIndicator = 1 "),
        @NamedQuery(name = "SystemApplicability.removeSystemAppyByCodeValueId", query = "DELETE SystemApplicability sa WHERE sa.codeValueId = :codeValueId and applicabilityIndicator = 0 "),
		@NamedQuery(name = "SystemApplicability.retrieveCodeValueSystemForCode", query = "SELECT distinct new SystemApplicability(sa.sysAppyId, sa.dnbSystemCode, sa.applicabilityIndicator, sa.codeTableId, sa.codeValueId,sa.expirationDate , cvt.codeValueDescription,ct.codeTableName) FROM SystemApplicability sa, CodeValueText cvt, CodeTable ct WHERE sa.applicabilityIndicator = 0 and cvt.codeValueId = sa.codeValueId and ct.codeTableId = sa.codeTableId and sa.dnbSystemCode = :dnbSystemCode and cvt.languageCode=39 order by sa.codeTableId,sa.codeValueId"),
		@NamedQuery(name = "SystemApplicability.retrieveCodeTableSystemForCode", query = "SELECT distinct new SystemApplicability(sa.sysAppyId, sa.dnbSystemCode, sa.applicabilityIndicator, sa.codeTableId, sa.codeValueId, null, ct.codeTableName) FROM SystemApplicability sa, CodeTable ct WHERE sa.applicabilityIndicator = 1 and ct.codeTableId = sa.codeTableId and sa.dnbSystemCode = :dnbSystemCode order by sa.codeTableId"),
		@NamedQuery(name = "SystemApplicability.lockSystemApplicabilityForEdit", query = "SELECT distinct new SystemApplicability(sa.modifiedUser) FROM SystemApplicability sa WHERE sa.dnbSystemCode = :dnbSystemCode")
})
public class SystemApplicability extends Audit implements Serializable {

	private static final long serialVersionUID = 6L;

	@Id
	@Column(name = "SYS_APPY_ID")
	private Long sysAppyId;

	@Column(name = "DNB_SYS_CD")
	private Long dnbSystemCode;

	@Column(name = "CD_TBL_APPY_INDC")
	private Integer applicabilityIndicator;

	@Column(name = "CD_TBL_ID")
	private Long codeTableId;

	@Column(name = "CD_VAL_ID")
	private Long codeValueId;

	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.DATE)
	private Date effectiveDate;

	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.DATE)
	private Date expirationDate;

	@Transient
	private String codeValueDescription;

	@Transient
	private String codeTableName;
	
	@Transient
	private String dnbSystemDesc;
	
	@Transient
	private String errorCode;
	
	@Transient
	private String cdValIdBulk;
	
	@Transient
	private String sysChangeIndicator;

	public SystemApplicability() {
		super();
	}

	public SystemApplicability(Long sysAppyId, Long dnbSystemCode,
			Integer applicabilityIndicator, Long codeTableId, Long codeValueId,Date expirationDate,
			String codeValueDescription, String codeTableName) {
		super();
		this.sysAppyId = sysAppyId;
		this.dnbSystemCode = dnbSystemCode;
		this.applicabilityIndicator = applicabilityIndicator;
		this.codeTableId = codeTableId;
		this.codeValueId = codeValueId;
		this.expirationDate=expirationDate;
		this.codeValueDescription = codeValueDescription;
		this.codeTableName = codeTableName;
		
		
	}

	public SystemApplicability(Long sysAppyId, Long dnbSystemCode,
			Integer applicabilityIndicator, Long codeTableId, Long codeValueId,
			Date effectiveDate, Date expirationDate, String createdUser,
			Date createdDate, Date modifiedDate, String modifiedUser,
			String codeValueDescription, String codeTableName) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.sysAppyId = sysAppyId;
		this.dnbSystemCode = dnbSystemCode;
		this.applicabilityIndicator = applicabilityIndicator;
		this.codeTableId = codeTableId;
		this.codeValueId = codeValueId;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
		this.codeValueDescription = codeValueDescription;
		this.codeTableName = codeTableName;
	}


	/**
	 * @param sysAppyId
	 * @param dnbSystemCode
	 * @param applicabilityIndicator
	 * @param codeTableId
	 * @param codeValueId
	 * @param effectiveDate
	 * @param expirationDate
	 * @param codeValueDescription
	 */
	public SystemApplicability(Long sysAppyId, Long dnbSystemCode,
			Integer applicabilityIndicator, Long codeTableId, Long codeValueId,
			Date effectiveDate, Date expirationDate,  String createdUser,
			Date createdDate, Date modifiedDate, String modifiedUser,String codeValueDescription) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);//added arguments to invoke super constructor
		this.sysAppyId = sysAppyId;
		this.dnbSystemCode = dnbSystemCode;
		this.applicabilityIndicator = applicabilityIndicator;
		this.codeTableId = codeTableId;
		this.codeValueId = codeValueId;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
		this.codeValueDescription = codeValueDescription;
	}
	
	


	public SystemApplicability(Long dnbSystemCode, String codeValueDescription) {
		super();
		this.dnbSystemCode = dnbSystemCode;
		this.codeValueDescription = codeValueDescription;
	}

	public SystemApplicability(Long sysAppyId, Long dnbSystemCode,
			Integer applicabilityIndicator, Long codeTableId, Long codeValueId,
			String codeValueDescription, String codeTableName) {
		super();
		this.sysAppyId = sysAppyId;
		this.dnbSystemCode = dnbSystemCode;
		this.applicabilityIndicator = applicabilityIndicator;
		this.codeTableId = codeTableId;
		this.codeValueId = codeValueId;
		this.codeValueDescription = codeValueDescription;
		this.codeTableName = codeTableName;
	}
	
	

	public SystemApplicability(Long sysAppyId, Long dnbSystemCode,
			Integer applicabilityIndicator, Long codeTableId, Long codeValueId) {
		super();
		this.sysAppyId = sysAppyId;
		this.dnbSystemCode = dnbSystemCode;
		this.applicabilityIndicator = applicabilityIndicator;
		this.codeTableId = codeTableId;
		this.codeValueId = codeValueId;
	}

	public SystemApplicability(String modifiedUser){
		super();
		this.setModifiedUser(modifiedUser);
	}
	
	/**
	 * @return the sysAppyId
	 */
	public Long getSysAppyId() {
		return sysAppyId;
	}

	/**
	 * @param sysAppyId
	 *            the sysAppyId to set
	 */
	public void setSysAppyId(Long sysAppyId) {
		this.sysAppyId = sysAppyId;
	}

	/**
	 * @return the dnbSystemCode
	 */
	public Long getDnbSystemCode() {
		return dnbSystemCode;
	}

	/**
	 * @param dnbSystemCode
	 *            the dnbSystemCode to set
	 */
	public void setDnbSystemCode(Long dnbSystemCode) {
		this.dnbSystemCode = dnbSystemCode;
	}

	/**
	 * @return the codeTableAppyIndicator
	 */
	public Integer getApplicabilityIndicator() {
		return applicabilityIndicator;
	}

	/**
	 * @param codeTableAppyIndicator
	 *            the codeTableAppyIndicator to set
	 */
	public void setApplicabilityIndicator(Integer applicabilityIndicator) {
		this.applicabilityIndicator = applicabilityIndicator;
	}

	/**
	 * @return the codeTableId
	 */
	public Long getCodeTableId() {
		return codeTableId;
	}

	/**
	 * @param codeTableId
	 *            the codeTableId to set
	 */
	public void setCodeTableId(Long codeTableId) {
		this.codeTableId = codeTableId;
	}

	/**
	 * @return the codeValueId
	 */
	public Long getCodeValueId() {
		return codeValueId;
	}

	/**
	 * @param codeValueId
	 *            the codeValueId to set
	 */
	public void setCodeValueId(Long codeValueId) {
		this.codeValueId = codeValueId;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate
	 *            the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate
	 *            the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the codeValueDescription
	 */
	public String getCodeValueDescription() {
		return codeValueDescription;
	}

	/**
	 * @param codeValueDescription
	 *            the codeValueDescription to set
	 */
	public void setCodeValueDescription(String codeValueDescription) {
		this.codeValueDescription = codeValueDescription;
	}


	/**
	 * @return the codeTableName
	 */
	public String getCodeTableName() {
		return codeTableName;
	}

	/**
	 * @param codeTableName
	 *            the codeTableName to set
	 */
	public void setCodeTableName(String codeTableName) {
		this.codeTableName = codeTableName;
	}
	
	

	/**
	 * @return the dnbSystemDesc
	 */
	public String getDnbSystemDesc() {
		return dnbSystemDesc;
	}


	/**
	 * @param dnbSystemDesc the dnbSystemDesc to set
	 */
	public void setDnbSystemDesc(String dnbSystemDesc) {
		this.dnbSystemDesc = dnbSystemDesc;
	}


	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}


	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}
	
	/**
	 * @return the cdValIdBulk
	 */
	public String getCdValIdBulk() {
		return cdValIdBulk;
	}


	/**
	 * @param cdValIdBulk the cdValIdBulk to set
	 */
	public void setCdValIdBulk(String cdValIdBulk) {
		this.cdValIdBulk = cdValIdBulk;
	}


	/**
	 * @return the sysChangeIndicator
	 */
	public String getSysChangeIndicator() {
		return sysChangeIndicator;
	}


	/**
	 * @param sysChangeIndicator the sysChangeIndicator to set
	 */
	public void setSysChangeIndicator(String sysChangeIndicator) {
		this.sysChangeIndicator = sysChangeIndicator;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SystemApplicability [sysAppyId=" + sysAppyId
				+ ", dnbSystemCode=" + dnbSystemCode
				+ ", applicabilityIndicator=" + applicabilityIndicator
				+ ", codeTableId=" + codeTableId + ", codeValueId="
				+ codeValueId + ", effectiveDate=" + effectiveDate
				+ ", expirationDate=" + expirationDate + ", codeValueDescription="
				+ codeValueDescription + ", codeTableName=" + codeTableName
				+ "]";
	}



}
