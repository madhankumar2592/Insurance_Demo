package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.Audit;

public class GlobalElementVO extends Audit implements Serializable{
	
	private static final long serialVersionUID = 899326529180285578L;
	
	
	private List<String> hintsList;
	private List<String> hintsDescList;
	private List<String> elementNameList;
	private List<String> platformList;
	
	
	

	/**
	 * @param hintsList the hintsList to set
	 */
	public void setHintsList(List<String> hintsList) {
		this.hintsList = hintsList;
	}


	/**
	 * @return the hintsList
	 */
	public List<String> getHintsList() {
		return hintsList;
	}


	/**
	 * @param hintsDescList the hintsDescList to set
	 */
	public void setHintsDescList(List<String> hintsDescList) {
		this.hintsDescList = hintsDescList;
	}


	/**
	 * @return the hintsDescList
	 */
	public List<String> getHintsDescList() {
		return hintsDescList;
	}

	/**
	 * @param elementNameList the elementNameList to set
	 */
	public void setElementNameList(List<String> elementNameList) {
		this.elementNameList = elementNameList;
	}

	/**
	 * @return the elementNameList
	 */
	public List<String> getElementNameList() {
		return elementNameList;
	}


	/**
	 * @param platformList the platformList to set
	 */
	public void setPlatformList(List<String> platformList) {
		this.platformList = platformList;
	}


	/**
	 * @return the platformList
	 */
	public List<String> getPlatformList() {
		return platformList;
	}
	
	

}
