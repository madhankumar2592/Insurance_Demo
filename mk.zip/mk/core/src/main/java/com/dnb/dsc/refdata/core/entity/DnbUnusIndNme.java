package com.dnb.dsc.refdata.core.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "dnb_unus_ind_nme")
@NamedQueries({
	@NamedQuery(name = "DnbUnusIndNme.removeDnbUnusIndNmeById", query = "DELETE DnbUnusIndNme i where i.dnbUnusGlsyId = :dnbUnusGlsyId")
})	
public class DnbUnusIndNme extends Audit{

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "dnb_unus_glsy_id")
	private Long dnbUnusGlsyId;

	@Column(name = "nme_pfx_txt")
	private String nmePfxTxt;

	@Column(name = "nme_sfx_txt")
	private String nmeSfxTxt;

	@Column(name = "frnm")
	private String frnm;

	@Column(name = "srnme")
	private String srnme;

	@Column(name = "midl_nme")
	private String midlNme;

	public Long getDnbUnusGlsyId() {
		return dnbUnusGlsyId;
	}

	public void setDnbUnusGlsyId(Long dnbUnusGlsyId) {
		this.dnbUnusGlsyId = dnbUnusGlsyId;
	}

	public String getNmePfxTxt() {
		return nmePfxTxt;
	}

	public void setNmePfxTxt(String nmePfxTxt) {
		this.nmePfxTxt = nmePfxTxt;
	}

	public String getNmeSfxTxt() {
		return nmeSfxTxt;
	}

	public void setNmeSfxTxt(String nmeSfxTxt) {
		this.nmeSfxTxt = nmeSfxTxt;
	}

	public String getFrnm() {
		return frnm;
	}

	public void setFrnm(String frnm) {
		this.frnm = frnm;
	}

	public String getSrnme() {
		return srnme;
	}

	public void setSrnme(String srnme) {
		this.srnme = srnme;
	}

	public String getMidlNme() {
		return midlNme;
	}

	public void setMidlNme(String midlNme) {
		this.midlNme = midlNme;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DnbUnusIndNme [dnbUnusGlsyId=" + dnbUnusGlsyId + ", nmePfxTxt="
				+ nmePfxTxt + ", nmeSfxTxt=" + nmeSfxTxt + ", frnm=" + frnm
				+ ", srnme=" + srnme + ", midlNme=" + midlNme + "]";
	}

}
