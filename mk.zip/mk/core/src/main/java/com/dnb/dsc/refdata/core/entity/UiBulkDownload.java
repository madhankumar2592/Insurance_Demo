/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;


/**
 * This class used as an entity class for the ui bulk download. The class
 * will have a direct mapping toe DB table  ui bulk download .
 * 
 * @author Cognizant
 * @version last updated : Mar 29, 2012
 * @see
 * 
 */
@Entity
@Table(name = "UI_BULK_DWNL")
@NamedQueries({
		@NamedQuery(name = "IndustryCode.retrieveUIBulkDownload", query = "SELECT g FROM UiBulkDownload g where g.userId = :userId")})
public class UiBulkDownload implements Serializable {

	private static final long serialVersionUID = 1L;

	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trackingIdGenerator")
	@SequenceGenerator(name = "trackingIdGenerator", sequenceName="soruiconfig.UI_BLK_DWNL_ID_SEQ" , allocationSize=1)
	@Column(name = "UI_BULK_DWNL_ID")
	private Long uiBulkDownloadId;

	@Column(name = "USR_ID")
	private String userId;

	@Column(name = "DMN_NME")
	public String domainName;

	@Column(name = "FLE_TYP")
	public String fileType;

	@Column(name = "DWNL_STRT_TME")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.UI_DWNL_DATE_TIME_FORMAT)
	private Date dwnloadStartTime;

	@Column(name = "DWNL_END_TME")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.UI_DWNL_DATE_TIME_FORMAT)
	private Date dwnloadEndTime;

	@Column(name = "BULK_DWNL_STAT")	
	public String bulkDownloadStatus;
	
	@Transient	
	public String fileName;

	

	/**
	 * @param uiBulkDownloadId
	 * @param userId
	 * @param domainName
	 * @param fileType
	 * @param dwnloadStartTime
	 * @param dwnloadEndTime
	 * @param bulkDownloadStatus
	 * 
	 * 
	 * 
	 *            /**
	 * @return the uiBulkDownloadId
	 */
	public Long getUiBulkDownloadId() {
		return uiBulkDownloadId;
	}

	/**
	 * @param uiBulkDownloadId
	 *            the uiBulkDownloadId to set
	 */
	public void setUiBulkDownloadId(Long uiBulkDownloadId) {
		this.uiBulkDownloadId = uiBulkDownloadId;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the domainName
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * @param domainName
	 *            the domainName to set
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}

	/**
	 * @param fileType
	 *            the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	/**
	 * @return the dwnloadStartTime
	 */
	public Date getDwnloadStartTime() {
		return dwnloadStartTime;
	}

	/**
	 * @param dwnloadStartTime
	 *            the dwnloadStartTime to set
	 */
	public void setDwnloadStartTime(Date dwnloadStartTime) {
		this.dwnloadStartTime = dwnloadStartTime;
	}

	/**
	 * @return the dwnloadEndTime
	 */
	public Date getDwnloadEndTime() {
		return dwnloadEndTime;
	}

	/**
	 * @param dwnloadEndTime
	 *            the dwnloadEndTime to set
	 */
	public void setDwnloadEndTime(Date dwnloadEndTime) {
		this.dwnloadEndTime = dwnloadEndTime;
	}

	/**
	 * @return the bulkDownloadStatus
	 */
	public String getBulkDownloadStatus() {
		return bulkDownloadStatus;
	}

	/**
	 * @param bulkDownloadStatus
	 *            the bulkDownloadStatus to set
	 */
	public void setBulkDownloadStatus(String bulkDownloadStatus) {
		this.bulkDownloadStatus = bulkDownloadStatus;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	

}
