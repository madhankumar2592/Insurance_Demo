package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

public class ScrProdRemoveVO implements Serializable {
	
	private static final long serialVersionUID = -1082881608475535248L;
	private List<Long> scoreTypesCodes;
	private String parameter;
	private String deleteQuery;
	public List<Long> getScoreTypesCodes() {
		return scoreTypesCodes;
	}
	public void setScoreTypesCodes(List<Long> scoreTypesCodes) {
		this.scoreTypesCodes = scoreTypesCodes;
	}
	public String getParameter() {
		return parameter;
	}
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
	public String getDeleteQuery() {
		return deleteQuery;
	}
	public void setDeleteQuery(String deleteQuery) {
		this.deleteQuery = deleteQuery;
	}


}
