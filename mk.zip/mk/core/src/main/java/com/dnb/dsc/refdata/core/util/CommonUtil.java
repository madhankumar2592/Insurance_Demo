/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;


/**
 * <p>
 * The class will provide common utility methods for all the domain.
 * </p>
 * 
 * @author Cognizant Technology Solutions
 * @version last updated : Mar 15, 2012
 * @see CommonUtil
 */
public class CommonUtil {
	
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CommonUtil.class);
	
	
	/**
	 * Truncate a String to the given length with no warnings or error raised if
	 * it is bigger.
	 * 
	 * @param value
	 *            String to be truncated
	 * @param length
	 *            Maximum length of string
	 * @return Returns value if value is null or value.length() is less or equal
	 *         to than length, otherwise a String representing value truncated
	 *         to length.
	 */
	public static String truncate(String value, int length) {
		if (value != null && value.length() > length)
			value = value.substring(0, length);
		return value;
	}
	
	/**
	 * Method to get Cookie Value from the Http Request
	 *
	 * @param request
	 * @param cookieName
	 * @return role
	 */
	public static String getCookieValue(HttpServletRequest request, String cookieName) {
		LOGGER.info("entering CommonUtil | getCookieValue");
		LOGGER.info("entering CommonUtil | getCookieValue | Cookie Name::"+cookieName);
		Cookie cookies[] = request.getCookies();
		Cookie role_cookie = null;
		String role = null;

		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equals(cookieName)) {
					role_cookie = cookies[i];
					role = role_cookie.toString();
					break;
				}
			}
		}
		LOGGER.info("entering CommonUtil | getCookieValue | role::",role);
		LOGGER.info("exiting CommonUtil | getCookieValue");
		return role;
	}

	/**
	 * 
	 * The method to convert the given input date to the specified string
	 * format. The method uses the Reference Data date format yyyy-mm-dd as the
	 * output pattern.
	 * 
	 * @param input 
	 * @return output Date in the string format
	 */
	public static String convertDate(Date input) {
		// Create an instance of SimpleDateFormat used for formatting  
		// the string representation of date (month/day/year) 
		DateFormat df = new SimpleDateFormat(RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT); 
		// Using DateFormat format method we can create a string  
		// representation of a date with the defined format. 
		String output = df.format(input);
		return output;
	}
}
