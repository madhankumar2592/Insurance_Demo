package com.dnb.dsc.refdata.core.vo;

import org.springframework.web.multipart.MultipartFile;

public class IndusCodeBulkUploadVO {

	private Long industryCodeTypeCode;
	private Long fromIndusCodeTypeCode;
	private Long toIndusCodeTypeCode;
	private Long fromIndusCodeId;
	private Long toIndusCodeId;
	private String fromIndusCode;
	private String toIndusCode;
	private int prfdMappingInd;
	private String fileType;
	private String errorCd;
	private MultipartFile file;
	/**
	 * @return the industryCodeTypeCode
	 */
	public Long getIndustryCodeTypeCode() {
		return industryCodeTypeCode;
	}
	/**
	 * @param industryCodeTypeCode the industryCodeTypeCode to set
	 */
	public void setIndustryCodeTypeCode(Long industryCodeTypeCode) {
		this.industryCodeTypeCode = industryCodeTypeCode;
	}
	/**
	 * @return the fromIndusCodeTypeCode
	 */
	public Long getFromIndusCodeTypeCode() {
		return fromIndusCodeTypeCode;
	}
	/**
	 * @param fromIndusCodeTypeCode the fromIndusCodeTypeCode to set
	 */
	public void setFromIndusCodeTypeCode(Long fromIndusCodeTypeCode) {
		this.fromIndusCodeTypeCode = fromIndusCodeTypeCode;
	}
	/**
	 * @return the toIndusCodeTypeCode
	 */
	public Long getToIndusCodeTypeCode() {
		return toIndusCodeTypeCode;
	}
	/**
	 * @param toIndusCodeTypeCode the toIndusCodeTypeCode to set
	 */
	public void setToIndusCodeTypeCode(Long toIndusCodeTypeCode) {
		this.toIndusCodeTypeCode = toIndusCodeTypeCode;
	}
	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}
	/**
	 * @return the fromIndusCodeId
	 */
	public Long getFromIndusCodeId() {
		return fromIndusCodeId;
	}
	/**
	 * @param fromIndusCodeId the fromIndusCodeId to set
	 */
	public void setFromIndusCodeId(Long fromIndusCodeId) {
		this.fromIndusCodeId = fromIndusCodeId;
	}
	/**
	 * @return the toIndusCodeId
	 */
	public Long getToIndusCodeId() {
		return toIndusCodeId;
	}
	/**
	 * @param toIndusCodeId the toIndusCodeId to set
	 */
	public void setToIndusCodeId(Long toIndusCodeId) {
		this.toIndusCodeId = toIndusCodeId;
	}
	/**
	 * @return the fromIndusCode
	 */
	public String getFromIndusCode() {
		return fromIndusCode;
	}
	/**
	 * @param fromIndusCode the fromIndusCode to set
	 */
	public void setFromIndusCode(String fromIndusCode) {
		this.fromIndusCode = fromIndusCode;
	}
	/**
	 * @return the toIndusCode
	 */
	public String getToIndusCode() {
		return toIndusCode;
	}
	/**
	 * @param toIndusCode the toIndusCode to set
	 */
	public void setToIndusCode(String toIndusCode) {
		this.toIndusCode = toIndusCode;
	}
	/**
	 * @return the prfdMappingInd
	 */
	public int getPrfdMappingInd() {
		return prfdMappingInd;
	}
	/**
	 * @param prfdMappingInd the prfdMappingInd to set
	 */
	public void setPrfdMappingInd(int prfdMappingInd) {
		this.prfdMappingInd = prfdMappingInd;
	}
	/**
	 * @return the errorCd
	 */
	public String getErrorCd() {
		return errorCd;
	}
	/**
	 * @param errorCd the errorCd to set
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}
	/**
	 * @param file the file to set
	 */
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	/**
	 * @return the file
	 */
	public MultipartFile getFile() {
		return file;
	}
	
	
	
}
