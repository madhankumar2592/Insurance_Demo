package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;

import com.dnb.dsc.refdata.core.entity.Audit;

public class ProductMetaData extends Audit implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5062701881859741675L;

	private Long productDtlId;
	
	/**
	 *productMetadataCode
	 */
	private Long productMetadataCode;
	
	/**
	 * productMetadataValue
	 */
	private String productMetadataValue;
	/**
	 * 
	 * @return productMetadataCode
	 */

	public Long getProductMetadataCode() {
		return productMetadataCode;
	}
	
	public Long getProductDtlId() {
		return productDtlId;
	}

	public void setProductDtlId(Long productDtlId) {
		this.productDtlId = productDtlId;
	}

	/**
	 * 
	 * @param productMetadataCode
	 * 				the productMetadataCode to set
	 */
	public void setProductMetadataCode(Long productMetadataCode) {
		this.productMetadataCode = productMetadataCode;
	}

	/**
	 * 
	 * @return productMetadataValue
	 */
	public String getProductMetadataValue() {
		return productMetadataValue;
	}

	/**
	 * 
	 * @param productMetadataValue the productMetadataValue to set
	 */
	public void setProductMetadataValue(String productMetadataValue) {
		this.productMetadataValue = productMetadataValue;
	}

}
