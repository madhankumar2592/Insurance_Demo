/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */

package com.dnb.dsc.refdata.core.util;

import java.util.Properties;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * <p>
 * Upon adding a property in the refdata-env-config.properties , the
 * corresponding getters and setters of the properties have to be added in this
 * class.
 * </p>
 * 
 * @author Cognizant Technology Solutions
 * @version last updated : Mar 15, 2012
 * @see RefDataConfigUtil
 */
@Component("refDataConfigUtil")
public class RefDataConfigUtil {
	
	/**
	 * The instance variable for Logging
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(RefDataConfigUtil.class);
	
	@Resource(name = "refDataProperties")
	private Properties refDataProperties;

	/**
	 * 
	 * The method will retrieve the value for the key from the spring context.
	 * The refDataProperties will be loaded into the spring context on server
	 * load.
	 * 
	 * @param key
	 * @return value
	 */
	public String getRefDataProperty(String key) {
		String value = refDataProperties.getProperty(key);
		
		LOGGER.debug("RefDataConfigUtil | getRefDataProperty for key " + key
				+ " is " + value);
		return value;
	}	

	/**
	 * 
	 * The method to fetch the service deploy URL from the refdata-env-config
	 * properties file. The method will fetch the property value from the spring
	 * context using the key.
	 * 
	 * @return service deploy URL
	 */
	public String getServiceDeployURL() {
		return getRefDataProperty(RefDataPropertiesConstants.REFDATA_SERVICE_DEPLOY_URL);
	}
	
	/**
	 * 
	 * The method to fetch the service deploy URL from the refdata-env-config
	 * properties file. The method will fetch the property value from the spring
	 * context using the key.
	 * 
	 * @return service deploy URL
	 */
	public String getBatchDeployURL() {
		return getRefDataProperty(RefDataPropertiesConstants.REFDATA_BATCH_DEPLOY_URL);
	}

	/**
	 * 
	 * The method to return the value for a specified key. The key - value pairs
	 * stored in the properties file will be bulk fetch as part of server load
	 * and stored on the spring context. Whenever this method is invoked, the
	 * spring context properties will be searched for the specified key and the
	 * value attribute will be returned.
	 * 
	 * @param key
	 * @return value
	 */
	public String getValue(String key) {
		return getRefDataProperty(key);
	}
}
