/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */


package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "RESC")
@NamedQueries({
	@NamedQuery(name = "Resource.retreiveResourceTypeCodeValues", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT distinct(d.rescCode) FROM Resource d) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "Resource.retreiveProdResource", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT distinct(d.rescCode) FROM Resource d where d.rescId in (select r.rescId from ResourceMapping r where r.productId in (select p.productId from Product p where p.productCode =:prodCode))) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "Resource.retreiveProdFamVerResource", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT distinct(d.rescCode) FROM Resource d where d.rescId in (select r.rescId from ResourceMapping r where r.productId in (select p.productId from Product p where p.productCode =:prodCode and p.productFamCode =:famCode))) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "Resource.retreiveProdCodeFamVerResource", query = "SELECT distinct new CodeValueText(t.codeValueId, t.codeValueShortDescription, t.codeValueDescription) FROM CodeValueText t where t.codeValueId in (SELECT distinct(d.rescCode) FROM Resource d where d.rescId in (select r.rescId from ResourceMapping r where r.productId in (select p.productId from Product p where p.productCode =:prodCode and p.productFamCode =:famCode and p.productVersion =:prodVer))) and t.languageCode = 39 and t.writingScriptCode = 19349 and t.expirationDate is null order by t.codeValueDescription"),
	@NamedQuery(name = "Resource.removeRescById", query = "DELETE FROM Resource c where c.rescId  in ( :rescId)")

		})
public class Resource extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "RESC_ID")
	private Long rescId;
	
	@Column(name = "BILG_SYS_CODE")
	private String bilgSysCode;
		
	@Column(name = "RESC_VERS")
	private Long rescVersion;
	
	@Column(name = "RESC_CD")
	private Long rescCode;
	
	@Column(name = "RESC_TYP_CODE")
	private String rescTypeCode;
	
	@Column(name = "BILG_SYS_TYP_CD")
	private Long bilgSysTypeCode;	
	
	@Column(name = "INAC_INDC")
	private Long inactiveIndicator;

	public Long getRescId() {
		return rescId;
	}

	public void setRescId(Long rescId) {
		this.rescId = rescId;
	}

	public String getBilgSysCode() {
		return bilgSysCode;
	}

	public void setBilgSysCode(String bilgSysCode) {
		this.bilgSysCode = bilgSysCode;
	}

	public Long getRescVersion() {
		return rescVersion;
	}

	public void setRescVersion(Long rescVersion) {
		this.rescVersion = rescVersion;
	}

	public Long getRescCode() {
		return rescCode;
	}

	public void setRescCode(Long rescCode) {
		this.rescCode = rescCode;
	}

	public String getRescTypeCode() {
		return rescTypeCode;
	}

	public void setRescTypeCode(String rescTypeCode) {
		this.rescTypeCode = rescTypeCode;
	}

	public Long getBilgSysTypeCode() {
		return bilgSysTypeCode;
	}

	public void setBilgSysTypeCode(Long bilgSysTypeCode) {
		this.bilgSysTypeCode = bilgSysTypeCode;
	}

	public Long getInactiveIndicator() {
		return inactiveIndicator;
	}

	public void setInactiveIndicator(Long inactiveIndicator) {
		this.inactiveIndicator = inactiveIndicator;
	}

	/**
	 * Empty Constructor.
	 */
	public Resource() {
		super();
	}
	
	public Resource(Long rescId) {
		super();
		this.rescId = rescId;
	}
	/*public Resource(Long ResourceVersion) {
		super();
		this.ResourceVersion = ResourceVersion;
	}*/
	public Resource(Long rescId, String bilgSysCode) {
		super();
		this.rescId = rescId;
		this.bilgSysCode = bilgSysCode;
	}
	
	
	/**
	 * 
	 * @param ResourceId
	 * @param ResourceVersion
	 * @param ResourceTypeId
	 * @param ResourceMarketCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param inactiveIndicator
	 */
	public Resource(Long rescId, String bilgSysCode, Long rescVersion, Long rescCode,
			String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate, String rescTypeCode,Long bilgSysTypeCode, Long inactiveIndicator
			) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.rescId = rescId;
		this.bilgSysCode = bilgSysCode;
		this.rescVersion = rescVersion;
		this.rescCode = rescCode;
		this.rescTypeCode = rescTypeCode;
		this.bilgSysTypeCode = bilgSysTypeCode;
		this.inactiveIndicator = inactiveIndicator;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Resource [rescId=" + rescId
				+ ", bilgSysCode=" + bilgSysCode 
				+"rescVersion=" + rescVersion+ 
				"rescCode=" + rescCode + 
				", rescTypeCode=" + rescTypeCode + 
				"bilgSysTypeCode=" + bilgSysTypeCode + 
				", inactiveIndicator=" + inactiveIndicator + 
				 "]";
	}
	
	
}
