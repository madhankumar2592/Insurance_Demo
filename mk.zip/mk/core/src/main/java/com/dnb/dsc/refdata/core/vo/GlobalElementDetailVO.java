package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;

import com.dnb.dsc.refdata.core.entity.Audit;

public class GlobalElementDetailVO extends Audit implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private Long globalElementDetailId;	
	private Long globalElementId;	
	private Long globalElementMetadataCode;	
	private String globalElementMetadataValue;	
	private Long globalElementMetadataTypeCode;	
	private Long globalElementMetadataLangCode;
	private String globalElementDetailComment;
	private String shortDescription;
	private String longDescription;
	
	/**
	 * @return the globalElementDetailId
	 */
	public Long getGlobalElementDetailId() {
		return globalElementDetailId;
	}
	/**
	 * @param globalElementDetailId the globalElementDetailId to set
	 */
	public void setGlobalElementDetailId(Long globalElementDetailId) {
		this.globalElementDetailId = globalElementDetailId;
	}
	/**
	 * @return the globalElementId
	 */
	public Long getGlobalElementId() {
		return globalElementId;
	}
	/**
	 * @param globalElementId the globalElementId to set
	 */
	public void setGlobalElementId(Long globalElementId) {
		this.globalElementId = globalElementId;
	}
	/**
	 * @return the globalElementMetadataCode
	 */
	public Long getGlobalElementMetadataCode() {
		return globalElementMetadataCode;
	}
	/**
	 * @param globalElementMetadataCode the globalElementMetadataCode to set
	 */
	public void setGlobalElementMetadataCode(Long globalElementMetadataCode) {
		this.globalElementMetadataCode = globalElementMetadataCode;
	}
	/**
	 * @return the globalElementMetadataValue
	 */
	public String getGlobalElementMetadataValue() {
		return globalElementMetadataValue;
	}
	/**
	 * @param globalElementMetadataValue the globalElementMetadataValue to set
	 */
	public void setGlobalElementMetadataValue(String globalElementMetadataValue) {
		this.globalElementMetadataValue = globalElementMetadataValue;
	}
	/**
	 * @return the globalElementMetadataTypeCode
	 */
	public Long getGlobalElementMetadataTypeCode() {
		return globalElementMetadataTypeCode;
	}
	/**
	 * @param globalElementMetadataTypeCode the globalElementMetadataTypeCode to set
	 */
	public void setGlobalElementMetadataTypeCode(Long globalElementMetadataTypeCode) {
		this.globalElementMetadataTypeCode = globalElementMetadataTypeCode;
	}
	/**
	 * @return the globalElementMetadataLangCode
	 */
	public Long getGlobalElementMetadataLangCode() {
		return globalElementMetadataLangCode;
	}
	/**
	 * @param globalElementMetadataLangCode the globalElementMetadataLangCode to set
	 */
	public void setGlobalElementMetadataLangCode(Long globalElementMetadataLangCode) {
		this.globalElementMetadataLangCode = globalElementMetadataLangCode;
	}
	/**
	 * @param globalElementDetailComment the globalElementDetailComment to set
	 */
	public void setGlobalElementDetailComment(String globalElementDetailComment) {
		this.globalElementDetailComment = globalElementDetailComment;
	}
	/**
	 * @return the globalElementDetailComment
	 */
	public String getGlobalElementDetailComment() {
		return globalElementDetailComment;
	}
	/**
	 * @param shortDescription the shortDescription to set
	 */
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	/**
	 * @return the shortDescription
	 */
	public String getShortDescription() {
		return shortDescription;
	}
	/**
	 * @param longDescription the longDescription to set
	 */
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}
	/**
	 * @return the longDescription
	 */
	public String getLongDescription() {
		return longDescription;
	}
	

}
