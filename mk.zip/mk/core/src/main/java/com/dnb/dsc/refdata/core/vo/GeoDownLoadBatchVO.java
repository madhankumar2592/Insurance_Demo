/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.GeoUnit;
import com.dnb.dsc.refdata.core.entity.GeoUnitAssociation;
import com.dnb.dsc.refdata.core.entity.GeoUnitCode;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;

/**
 * This class used as an value object class.
 * 
 * @author Cognizant
 * @version last updated : Dec 09, 2011
 * @see
 * 
 */
public class GeoDownLoadBatchVO {

	private GeoUnitName geoUnitName;
	private GeoUnit geoUnit;
	private GeoUnitCode geoUnitCode;
	private GeoUnitAssociation geoUnitAssn;
	private CodeValueText cdValTxtLang;
	private CodeValueText cdValTxtWritngScrpt;
	private CodeValueText cdValTxtGeoTypcd;
	private CodeValueText cdValTxtDataPrvCd;
	private String prntGeoName;
	private String chldGeoName;
	private String prntGeoUnitTypCd;
	private String prntGeoUnitTypDesc;
	private String chldGeoUnitTypCd;
	private String chldGeoUnitTypDesc;

	/**
	 * @return the cdValTxtDataPrvCd
	 */
	public CodeValueText getCdValTxtDataPrvCd() {
		return cdValTxtDataPrvCd;
	}

	/**
	 * @param cdValTxtDataPrvCd
	 *            the cdValTxtDataPrvCd to set
	 */
	public void setCdValTxtDataPrvCd(CodeValueText cdValTxtDataPrvCd) {
		this.cdValTxtDataPrvCd = cdValTxtDataPrvCd;
	}

	/**
	 * @return the cdValTxtGeoTypcd
	 */
	public CodeValueText getCdValTxtGeoTypcd() {
		return cdValTxtGeoTypcd;
	}

	/**
	 * @param cdValTxtGeoTypcd
	 *            the cdValTxtGeoTypcd to set
	 */
	public void setCdValTxtGeoTypcd(CodeValueText cdValTxtGeoTypcd) {
		this.cdValTxtGeoTypcd = cdValTxtGeoTypcd;
	}

	/**
	 * @return the geoUnit
	 */
	public GeoUnit getGeoUnit() {
		return geoUnit;
	}

	/**
	 * @param geoUnit
	 *            the geoUnit to set
	 */
	public void setGeoUnit(GeoUnit geoUnit) {
		this.geoUnit = geoUnit;
	}

	/**
	 * @return the geoUnitName
	 */
	public GeoUnitName getGeoUnitName() {
		return geoUnitName;
	}

	/**
	 * @param geoUnitName
	 *            the geoUnitName to set
	 */
	public void setGeoUnitName(GeoUnitName geoUnitName) {
		this.geoUnitName = geoUnitName;
	}

	/**
	 * @return the cdValTxtLang
	 */
	public CodeValueText getCdValTxtLang() {
		return cdValTxtLang;
	}

	/**
	 * @param cdValTxtLang
	 *            the cdValTxtLang to set
	 */
	public void setCdValTxtLang(CodeValueText cdValTxtLang) {
		this.cdValTxtLang = cdValTxtLang;
	}

	/**
	 * @return the cdValTxtWritngScrpt
	 */
	public CodeValueText getCdValTxtWritngScrpt() {
		return cdValTxtWritngScrpt;
	}

	/**
	 * @param cdValTxtWritngScrpt
	 *            the cdValTxtWritngScrpt to set
	 */
	public void setCdValTxtWritngScrpt(CodeValueText cdValTxtWritngScrpt) {
		this.cdValTxtWritngScrpt = cdValTxtWritngScrpt;
	}

	/**
	 * @return the geoUnitCode
	 */
	public GeoUnitCode getGeoUnitCode() {
		return geoUnitCode;
	}

	/**
	 * @param geoUnitCode
	 *            the geoUnitCode to set
	 */
	public void setGeoUnitCode(GeoUnitCode geoUnitCode) {
		this.geoUnitCode = geoUnitCode;
	}

	/**
	 * @return the geoUnitAssn
	 */
	public GeoUnitAssociation getGeoUnitAssn() {
		return geoUnitAssn;
	}

	/**
	 * @param geoUnitAssn
	 *            the geoUnitAssn to set
	 */
	public void setGeoUnitAssn(GeoUnitAssociation geoUnitAssn) {
		this.geoUnitAssn = geoUnitAssn;
	}

	/**
	 * @return the prntGeoName
	 */
	public String getPrntGeoName() {
		return prntGeoName;
	}

	/**
	 * @param prntGeoName
	 *            the prntGeoName to set
	 */
	public void setPrntGeoName(String prntGeoName) {
		this.prntGeoName = prntGeoName;
	}

	/**
	 * @return the chldGeoName
	 */
	public String getChldGeoName() {
		return chldGeoName;
	}

	/**
	 * @param chldGeoName
	 *            the chldGeoName to set
	 */
	public void setChldGeoName(String chldGeoName) {
		this.chldGeoName = chldGeoName;
	}

	/**
	 * @return the prntGeoUnitTypCd
	 */
	public String getPrntGeoUnitTypCd() {
		return prntGeoUnitTypCd;
	}

	/**
	 * @param prntGeoUnitTypCd the prntGeoUnitTypCd to set
	 */
	public void setPrntGeoUnitTypCd(String prntGeoUnitTypCd) {
		this.prntGeoUnitTypCd = prntGeoUnitTypCd;
	}

	/**
	 * @return the prntGeoUnitTypDesc
	 */
	public String getPrntGeoUnitTypDesc() {
		return prntGeoUnitTypDesc;
	}

	/**
	 * @param prntGeoUnitTypDesc the prntGeoUnitTypDesc to set
	 */
	public void setPrntGeoUnitTypDesc(String prntGeoUnitTypDesc) {
		this.prntGeoUnitTypDesc = prntGeoUnitTypDesc;
	}

	/**
	 * @return the chldGeoUnitTypCd
	 */
	public String getChldGeoUnitTypCd() {
		return chldGeoUnitTypCd;
	}

	/**
	 * @param chldGeoUnitTypCd the chldGeoUnitTypCd to set
	 */
	public void setChldGeoUnitTypCd(String chldGeoUnitTypCd) {
		this.chldGeoUnitTypCd = chldGeoUnitTypCd;
	}

	/**
	 * @return the chldGeoUnitTypDesc
	 */
	public String getChldGeoUnitTypDesc() {
		return chldGeoUnitTypDesc;
	}

	/**
	 * @param chldGeoUnitTypDesc the chldGeoUnitTypDesc to set
	 */
	public void setChldGeoUnitTypDesc(String chldGeoUnitTypDesc) {
		this.chldGeoUnitTypDesc = chldGeoUnitTypDesc;
	}

}
