package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "HLP_HINT_TYP")
@NamedQueries({
		@NamedQuery(name = "HelpfulHintType.retrieveHints", query = "SELECT distinct new HelpfulHintType(ht.helpfulHintTypeIdentifier,ht.helpfulHintTypeDescription) FROM HelpfulHintType ht order by ht.helpfulHintTypeIdentifier")		
		})
public class HelpfulHintType extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "HLP_HINT_TYP_ID")
	private Long helpfulHintTypeIdentifier;

	@Column(name = "HLP_HINT_TYP_DESC")
	private String helpfulHintTypeDescription;
	
	@OneToMany(mappedBy = "helpfulHintTypeIdentifier", cascade = CascadeType.ALL)
	private List<HelpfulHint> helpfulHints;
	
	@Transient
	private String helpfulHintText;
	
	
	public HelpfulHintType(){
		super();
	}
	
	public HelpfulHintType(Long helpfulHintTypeIdentifier,String helpfulHintTypeDescription){
		this.setHelpfulHintTypeIdentifier(helpfulHintTypeIdentifier);
		this.helpfulHintTypeDescription = helpfulHintTypeDescription;		
	}

	

	/**
	 * @param helpfulHintTypeDescription the helpfulHintTypeDescription to set
	 */
	public void setHelpfulHintTypeDescription(String helpfulHintTypeDescription) {
		this.helpfulHintTypeDescription = helpfulHintTypeDescription;
	}

	/**
	 * @return the helpfulHintTypeDescription
	 */
	public String getHelpfulHintTypeDescription() {
		return helpfulHintTypeDescription;
	}

	/**
	 * @param helpfulHints the helpfulHints to set
	 */
	public void setHelpfulHints(List<HelpfulHint> helpfulHints) {
		this.helpfulHints = helpfulHints;
	}

	/**
	 * @return the helpfulHints
	 */
	public List<HelpfulHint> getHelpfulHints() {
		return helpfulHints;
	}

	/**
	 * @param helpfulHintText the helpfulHintText to set
	 */
	public void setHelpfulHintText(String helpfulHintText) {
		this.helpfulHintText = helpfulHintText;
	}

	/**
	 * @return the helpfulHintText
	 */
	public String getHelpfulHintText() {
		return helpfulHintText;
	}

	/**
	 * @param helpfulHintTypeIdentifier the helpfulHintTypeIdentifier to set
	 */
	public void setHelpfulHintTypeIdentifier(Long helpfulHintTypeIdentifier) {
		this.helpfulHintTypeIdentifier = helpfulHintTypeIdentifier;
	}

	/**
	 * @return the helpfulHintTypeIdentifier
	 */
	public Long getHelpfulHintTypeIdentifier() {
		return helpfulHintTypeIdentifier;
	}

	

}
