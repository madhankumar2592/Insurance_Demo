package com.dnb.dsc.refdata.core.vo;

import com.dnb.dsc.refdata.core.entity.CodeValueText;
import com.dnb.dsc.refdata.core.entity.DnbUnusAdr;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsy;
import com.dnb.dsc.refdata.core.entity.DnbUnusGlsyCtryAppy;
import com.dnb.dsc.refdata.core.entity.DnbUnusIndNme;
import com.dnb.dsc.refdata.core.entity.DnbUnusTlcmAdr;
import com.dnb.dsc.refdata.core.entity.GeoUnitName;
import com.dnb.dsc.refdata.core.entity.IndustryCode;
import com.dnb.dsc.refdata.core.entity.IndustryCodeDescription;
import com.dnb.dsc.refdata.core.entity.IndustryCodeInferment;
import com.dnb.dsc.refdata.core.entity.InfermentText;
import com.dnb.dsc.refdata.core.entity.InfermentTextCountryApplicability;
import com.dnb.dsc.refdata.core.entity.LegalFormInferment;
import com.dnb.dsc.refdata.core.entity.PhoneAreaCode;

public class ControlWordsDownloadBatchVO {
	
	
	private IndustryCodeInferment industryCodeInferment; 
	private InfermentTextCountryApplicability infermentTextCountryApplicability;
	private IndustryCodeDescription industryCodeDescription; 
	private IndustryCode industryCode; 
	private CodeValueText codeValueText,codeValueText1;
	private InfermentText infermentText;
	private LegalFormInferment legalFormInferment;
	private DnbUnusGlsy dnbUnusGlsy;
	private DnbUnusGlsyCtryAppy dnbUnusGlsyCtryAppy;
	private GeoUnitName geoUnitName;
	private DnbUnusIndNme dnbUnusIndNme;
	private DnbUnusTlcmAdr dnbUnusTlcmAdr;
	private DnbUnusAdr dnbUnusAdr;
	private PhoneAreaCode phoneAreaCode;
	
	/**
	 * @return the industryCodeInferment
	 */
	public IndustryCodeInferment getIndustryCodeInferment() {
		return industryCodeInferment;
	}
	/**
	 * @param industryCodeInferment the industryCodeInferment to set
	 */
	public void setIndustryCodeInferment(IndustryCodeInferment industryCodeInferment) {
		this.industryCodeInferment = industryCodeInferment;
	}
	/**
	 * @return the industryCodeDescription
	 */
	public IndustryCodeDescription getIndustryCodeDescription() {
		return industryCodeDescription;
	}
	/**
	 * @param industryCodeDescription the industryCodeDescription to set
	 */
	public void setIndustryCodeDescription(
			IndustryCodeDescription industryCodeDescription) {
		this.industryCodeDescription = industryCodeDescription;
	}
	/**
	 * @return the industryCode
	 */
	public IndustryCode getIndustryCode() {
		return industryCode;
	}
	/**
	 * @param industryCode the industryCode to set
	 */
	public void setIndustryCode(IndustryCode industryCode) {
		this.industryCode = industryCode;
	}
	/**
	 * @return the codeValueText
	 */
	public CodeValueText getCodeValueText() {
		return codeValueText;
	}
	/**
	 * @param codeValueText the codeValueText to set
	 */
	public void setCodeValueText(CodeValueText codeValueText) {
		this.codeValueText = codeValueText;
	}
	/**
	 * @return the infermentText
	 */
	public InfermentText getInfermentText() {
		return infermentText;
	}
	/**
	 * @param infermentText the infermentText to set
	 */
	public void setInfermentText(InfermentText infermentText) {
		this.infermentText = infermentText;
	}
	/**
	 * @param codeValueText1 the codeValueText1 to set
	 */
	public void setCodeValueText1(CodeValueText codeValueText1) {
		this.codeValueText1 = codeValueText1;
	}
	/**
	 * @return the codeValueText1
	 */
	public CodeValueText getCodeValueText1() {
		return codeValueText1;
	}
	/**
	 * @param legalFormInferment the legalFormInferment to set
	 */
	public void setLegalFormInferment(LegalFormInferment legalFormInferment) {
		this.legalFormInferment = legalFormInferment;
	}
	/**
	 * @return the legalFormInferment
	 */
	public LegalFormInferment getLegalFormInferment() {
		return legalFormInferment;
	}
	/**
	 * @param dnbUnusGlsy the dnbUnusGlsy to set
	 */
	public void setDnbUnusGlsy(DnbUnusGlsy dnbUnusGlsy) {
		this.dnbUnusGlsy = dnbUnusGlsy;
	}
	/**
	 * @return the dnbUnusGlsy
	 */
	public DnbUnusGlsy getDnbUnusGlsy() {
		return dnbUnusGlsy;
	}
	/**
	 * @param dnbUnusGlsyCtryAppy the dnbUnusGlsyCtryAppy to set
	 */
	public void setDnbUnusGlsyCtryAppy(DnbUnusGlsyCtryAppy dnbUnusGlsyCtryAppy) {
		this.dnbUnusGlsyCtryAppy = dnbUnusGlsyCtryAppy;
	}
	/**
	 * @return the dnbUnusGlsyCtryAppy
	 */
	public DnbUnusGlsyCtryAppy getDnbUnusGlsyCtryAppy() {
		return dnbUnusGlsyCtryAppy;
	}
	/**
	 * @param geoUnitName the geoUnitName to set
	 */
	public void setGeoUnitName(GeoUnitName geoUnitName) {
		this.geoUnitName = geoUnitName;
	}
	/**
	 * @return the geoUnitName
	 */
	public GeoUnitName getGeoUnitName() {
		return geoUnitName;
	}
	/**
	 * @param dnbUnusIndNme the dnbUnusIndNme to set
	 */
	public void setDnbUnusIndNme(DnbUnusIndNme dnbUnusIndNme) {
		this.dnbUnusIndNme = dnbUnusIndNme;
	}
	/**
	 * @return the dnbUnusIndNme
	 */
	public DnbUnusIndNme getDnbUnusIndNme() {
		return dnbUnusIndNme;
	}
	/**
	 * @param dnbUnusTlcmAdr the dnbUnusTlcmAdr to set
	 */
	public void setDnbUnusTlcmAdr(DnbUnusTlcmAdr dnbUnusTlcmAdr) {
		this.dnbUnusTlcmAdr = dnbUnusTlcmAdr;
	}
	/**
	 * @return the dnbUnusTlcmAdr
	 */
	public DnbUnusTlcmAdr getDnbUnusTlcmAdr() {
		return dnbUnusTlcmAdr;
	}
	/**
	 * @param dnbUnusAdr the dnbUnusAdr to set
	 */
	public void setDnbUnusAdr(DnbUnusAdr dnbUnusAdr) {
		this.dnbUnusAdr = dnbUnusAdr;
	}
	/**
	 * @return the dnbUnusAdr
	 */
	public DnbUnusAdr getDnbUnusAdr() {
		return dnbUnusAdr;
	}
	/**
	 * @param phoneAreaCode the phoneAreaCode to set
	 */
	public void setPhoneAreaCode(PhoneAreaCode phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}
	/**
	 * @return the phoneAreaCode
	 */
	public PhoneAreaCode getPhoneAreaCode() {
		return phoneAreaCode;
	}
	/**
	 * @param infermentTextCountryApplicability the infermentTextCountryApplicability to set
	 */
	public void setInfermentTextCountryApplicability(
			InfermentTextCountryApplicability infermentTextCountryApplicability) {
		this.infermentTextCountryApplicability = infermentTextCountryApplicability;
	}
	/**
	 * @return the infermentTextCountryApplicability
	 */
	public InfermentTextCountryApplicability getInfermentTextCountryApplicability() {
		return infermentTextCountryApplicability;
	}

}
