/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * This class used as an entity class for the IndustrialCode. The class will have a
 * direct mapping toe DB table inds_code.<p>
 * 
 * @author Cognizant
 * @version last updated : Mar 08, 2012
 * @see
 * 
 */
@Entity
@Table(name = "INDS_CODE")
@NamedQueries({
		@NamedQuery(name = "IndustryCode.retrieveCrossWalksForIndsCodeTypeCode", query = "SELECT distinct new IndustryCode(i2.industryCodeTypeCode, (SELECT cvt.codeValueDescription from CodeValueText cvt where cvt.languageCode = :enLangCode and cvt.codeValueId = i2.industryCodeTypeCode)) FROM IndustryCodeMap m, IndustryCode i1, IndustryCode i2 where m.industryCodeMapPK.fromIndustryCodeId = i1.industryCodeId and m.industryCodeMapPK.toIndustryCodeId = i2.industryCodeId and i1.industryCodeTypeCode = :indsCodeTypeCode"),
		@NamedQuery(name = "IndustryCode.retrieveIndustryCodeByIndustryCodeId", query = "SELECT g FROM IndustryCode g where g.industryCodeId = :industryCodeId"),
		@NamedQuery(name = "IndustryCode.retrieveDescriptionForIndsCodeTypeCode", query = "select new IndustryCode(icd.industryDescription) from IndustryCode ic, IndustryCodeDescription icd where ic.industryCodeId = icd.industryCodeId and ic.industryCodeTypeCode = :industryCodeTypeCode and ic.industryCode = :industryCode and (icd.languageCode = :languageCode or icd.languageCode in(select distinct languageCode from IndustryCodeDescription))"),
		@NamedQuery(name = "IndustryCode.retrieveIndsIdForIndsCodeTypeCode", query = "select new IndustryCode(ic.industryCodeId) from IndustryCode ic where ic.industryCodeTypeCode = :industryCodeTypeCode and ic.industryCode = :industryCode"),
		@NamedQuery(name = "IndustryCode.countIndustryCode", query = "SELECT count(g.industryCodeId) FROM IndustryCode g WHERE g.industryCodeId = :industryCodeId"),
		@NamedQuery(name = "IndustryCode.retrieveGroupLevelsForIndsCodeTypeCode", query = "SELECT distinct new IndustryCode(i.industryCodeGroupLvelCode, (SELECT cvt.codeValueDescription from CodeValueText cvt where cvt.languageCode = :enLangCode and cvt.codeValueId = i.industryCodeGroupLvelCode)) FROM IndustryCode i where i.industryCodeTypeCode = :indsCodeTypeCode and i.industryCodeGroupLvelCode <> 0"),
		@NamedQuery(name = "IndustryCode.retrieveGroupLevelsForIndsCodeTypeCodeAndLanguageCode", query = "SELECT distinct new IndustryCode(i.industryCodeGroupLvelCode, (SELECT cvt.codeValueDescription from CodeValueText cvt where cvt.languageCode = :enLangCode and cvt.codeValueId = i.industryCodeGroupLvelCode)) FROM IndustryCode i, IndustryCodeDescription d where i.industryCodeId = d.industryCodeId and i.industryCodeTypeCode = :indsCodeTypeCode and i.industryCodeGroupLvelCode <> 0 and d.languageCode = :languageCode"),		
		@NamedQuery(name = "IndustryCode.removeIndustryCodeById", query = "DELETE FROM IndustryCode i where i.industryCodeId = :industryCodeId"),
		@NamedQuery(name = "IndustryCode.retrieveIndustryCodeByindsCodeId", query = "select ic from IndustryCode ic, IndustryCodeDescription icd where ic.industryCodeId = icd.industryCodeId and icd.languageCode = :languageCode and ic.industryCodeId=:industryCodeId"),
		@NamedQuery(name = "IndustryCode.retrieveIndustryCodeDescriptionByIndsCodeTypeCode", query = "select new IndustryCode(ic.industryCode,icd.industryDescription) from IndustryCode ic, IndustryCodeDescription icd where ic.industryCodeId = icd.industryCodeId and ic.industryCodeTypeCode = :industryCodeTypeCode and icd.languageCode = :languageCode"),
		@NamedQuery(name = "IndustryCode.countIndustryCodeDescriptionForDuplicate", query = "select count(ic.industryCode) from IndustryCode ic, IndustryCodeDescription icd where ic.industryCodeId = icd.industryCodeId and ic.industryCodeTypeCode = :industryCodeTypeCode and ic.industryCode != :industryCode and upper(icd.industryDescription) like upper(:industryDescription)")
		})
public class IndustryCode extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "INDS_CODE_ID")
	private Long industryCodeId;
	
	@Column(name = "INDS_CODE")
	private String industryCode;
	
	@Column(name = "INDS_CODE_TYP_CD")
	private Long industryCodeTypeCode;
	
	@Column(name = "INDS_CODE_GRP_CD")
	private Long industryCodeGroupLvelCode;

	@OneToMany(mappedBy = "industryCodeId", cascade = CascadeType.ALL)
	private List<IndustryCodeDescription> industryCodeDescriptions;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "FROM_INDS_CODE_ID")
	private List<IndustryCodeMap> industryCodeMaps;
	
	//Added for industry bulk upload
	@Transient
	private String industryCodeIdBulk;
	
	@Transient
	private Long industryCodeDescIdBulk;
	
	@Transient
	private Long writScriptCD;
	
	@Transient
	private Long descLenCD;
	
	@Transient
	private Long toDescLenCD;
	
	
	@Transient
	private String errorCD;
	
	@Transient
	private String induCodeIdInDescBulk;
	
	@Transient
	private String industryCodeDescription;
	
	@Transient
	private String industryCrosswalkDescription;
	
	@Transient
	private Long languageCode;
	
	@Transient
	private String languageDescription;
	
	@Transient
	private String codeTypeCodeDescription;
	
	@Transient
	private Long fromIndustryCodeId;
	
	@Transient
	private Long toIndustryCodeId;
	
	@Transient
	private String crosswalkIndustryCode;
	
	@Transient
	private String crosswalkIndustryDescription;
	
	@Transient
	private Integer preferredMapIndicator;
	
	@Transient
	private Long crosswalkCodeTypeCode;
	
	@Transient
	private String groupLevelDescription;
	
	@Transient
	private String batchIdentity;
	
	@Transient
	private String descLenCdDescription;
	
	@Transient
	private String toDescLenCdDescription;
	
	
	/**
	 * @return the batchIdentity
	 */
	public String getBatchIdentity() {
		return batchIdentity;
	}

	/**
	 * @param batchIdentity the batchIdentity to set
	 */
	public void setBatchIdentity(String batchIdentity) {
		this.batchIdentity = batchIdentity;
	}

	@Transient
	private List<String> changeIndicatorList;
	
	@Transient
	private List<String> industryCodeList;
	
	/**
	 * Empty Constructor.
	 */
	public IndustryCode() {
		super();
	}

	/**
	 * 
	 * @param industryCodeId
	 * @param industryCode
	 * @param industryCodeTypeCode
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 * @param industryCodeGroupLvelCode
	 */
	public IndustryCode(Long industryCodeId, String industryCode,
			Long industryCodeTypeCode, String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate,
			Long industryCodeGroupLvelCode) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.industryCodeId = industryCodeId;
		this.industryCode = industryCode;
		this.industryCodeTypeCode = industryCodeTypeCode;
		this.industryCodeGroupLvelCode = industryCodeGroupLvelCode;
	}

	/**
	 * @param industryCodeId
	 * @param industryCode
	 * @param industryCodeTypeCode
	 * @param industryCodeDescription
	 * @param languageCode
	 * @param languageDescription
	 * @param codeTypeCodeDescription
	 */
	public IndustryCode(Long industryCodeId, String industryCode,
			 String industryCodeDescription,
			Long languageCode, String languageDescription, Long industryCodeTypeCode,
			String codeTypeCodeDescription) {
		this.industryCodeId = industryCodeId;
		this.industryCode = industryCode;		
		this.industryCodeDescription = industryCodeDescription;
		this.industryCodeTypeCode = industryCodeTypeCode;
		this.languageCode = languageCode;
		this.languageDescription = languageDescription;
		this.codeTypeCodeDescription = codeTypeCodeDescription;
	}
	
	/**
	 * @param industryCodeId
	 * @param industryCode
	 * @param industryCodeGroupLvelCode
	 * @param industryCodeTypeCode
	 * @param industryCodeDescription
	 * @param languageCode
	 * @param languageDescription
	 * @param codeTypeCodeDescription
	 * @param descLenCD
	 */
	public IndustryCode(Long industryCodeId, String industryCode,Long industryCodeGroupLvelCode,
			 String industryCodeDescription,
			Long languageCode, String languageDescription, Long industryCodeTypeCode,
			String codeTypeCodeDescription, Long descLenCD,String descLenCdDescription) {
		this.industryCodeId = industryCodeId;
		this.industryCode = industryCode;
		this.industryCodeGroupLvelCode = industryCodeGroupLvelCode;
		this.industryCodeDescription = industryCodeDescription;
		this.industryCodeTypeCode = industryCodeTypeCode;
		this.languageCode = languageCode;
		this.languageDescription = languageDescription;
		this.codeTypeCodeDescription = codeTypeCodeDescription;
		this.descLenCD = descLenCD;
		this.descLenCdDescription = descLenCdDescription;
	}	
	
	/**
	 * @param industryCodeId
	 * @param industryCode
	 * @param industryCodeTypeCode
	 * @param industryCodeDescription
	 * @param languageCode
	 * @param languageDescription
	 * @param codeTypeCodeDescription
	 * @param descLenCD
	 */
	public IndustryCode(Long industryCodeId, String industryCode,
			 String industryCodeDescription,
			Long languageCode, String languageDescription, Long industryCodeTypeCode,
			String codeTypeCodeDescription, Long descLenCD) {
		this.industryCodeId = industryCodeId;
		this.industryCode = industryCode;		
		this.industryCodeDescription = industryCodeDescription;
		this.industryCodeTypeCode = industryCodeTypeCode;
		this.languageCode = languageCode;
		this.languageDescription = languageDescription;
		this.codeTypeCodeDescription = codeTypeCodeDescription;
		this.descLenCD = descLenCD;
	}	

	/**
	 * 
	 * @param fromIndustryCodeId
	 * @param industryCode
	 * @param industryCodeDescription
	 * @param toIndustryCodeId
	 * @param crosswalkIndustryCode
	 * @param crosswalkIndustryDescription
	 * @param preferredMapIndicator
	 * @param industryCodeTypeCode
	 * @param crosswalkCodeTypeCode
	 */
	public IndustryCode(Long fromIndustryCodeId, String industryCode,
			String industryCodeDescription, Long toIndustryCodeId,
			String crosswalkIndustryCode, String crosswalkIndustryDescription,
			Integer preferredMapIndicator, Long industryCodeTypeCode,
			Long crosswalkCodeTypeCode) {
		this.fromIndustryCodeId = fromIndustryCodeId;
		this.industryCode = industryCode;
		this.industryCodeDescription = industryCodeDescription;
		this.toIndustryCodeId = toIndustryCodeId;
		this.crosswalkIndustryCode = crosswalkIndustryCode;
		this.crosswalkIndustryDescription = crosswalkIndustryDescription;
		this.preferredMapIndicator = preferredMapIndicator;
		this.industryCodeTypeCode = industryCodeTypeCode;
		this.crosswalkCodeTypeCode = crosswalkCodeTypeCode;
	}
	
	/**
	 * 
	 * @param fromIndustryCodeId
	 * @param industryCode
	 * @param industryCodeDescription
	 * @param toIndustryCodeId
	 * @param crosswalkIndustryCode
	 * @param crosswalkIndustryDescription
	 * @param preferredMapIndicator
	 * @param industryCodeTypeCode
	 * @param crosswalkCodeTypeCode
	 */
	public IndustryCode(Long fromIndustryCodeId, String industryCode,
			String industryCodeDescription,Long fromDescLenCode,
			String descLenCdDescription,
			Long toIndustryCodeId,String crosswalkIndustryCode,
			String crosswalkIndustryDescription,Long toDescLenCode,
			String toDescLenCdDescription,
			Integer preferredMapIndicator, Long industryCodeTypeCode,
			Long crosswalkCodeTypeCode) {
		this.fromIndustryCodeId = fromIndustryCodeId;
		this.industryCode = industryCode;
		this.industryCodeDescription = industryCodeDescription;
		this.descLenCD = fromDescLenCode;
		this.descLenCdDescription = descLenCdDescription;
		this.toIndustryCodeId = toIndustryCodeId;
		this.crosswalkIndustryCode = crosswalkIndustryCode;
		this.crosswalkIndustryDescription = crosswalkIndustryDescription;
		this.toDescLenCD = toDescLenCode;
		this.toDescLenCdDescription = toDescLenCdDescription;
		this.preferredMapIndicator = preferredMapIndicator;
		this.industryCodeTypeCode = industryCodeTypeCode;
		this.crosswalkCodeTypeCode = crosswalkCodeTypeCode;
	}

	/**
	 * @param industryCodeTypeCode
	 * @param crosswalkIndustryCode
	 */
	public IndustryCode(Long industryCodeTypeCode,
			String industryCrosswalkDescription) {
		this.industryCrosswalkDescription = industryCrosswalkDescription;
		this.industryCodeTypeCode = industryCodeTypeCode;
	}

	/**
	 * This constructor is used by query - IndustryCode.retrieveIndustryCodeByIndustryCodeTypeCode.
	 * 
	 */
	public IndustryCode(String industryCodeDescription) {
		this.industryCodeDescription = industryCodeDescription;
	}

	/**
	 * This constructor is used by query - IndustryCode.retrieveIndsIdForIndsCodeTypeCode
	 * 
	 */
	public IndustryCode(Long industryCodeId) {
		this.industryCodeId = industryCodeId;
	}

	
	public IndustryCode(String industryCode,String industryCodeDescription){
	    this.industryCode = industryCode;
	    this.industryCodeDescription =industryCodeDescription;
	}

	/**
	 * @return the industrialCodeId
	 */
	public Long getIndustryCodeId() {
		return industryCodeId;
	}

	/**
	 * @param industryCodeId the industrialCodeId to set
	 */
	public void setIndustryCodeId(Long industryCodeId) {
		this.industryCodeId = industryCodeId;
	}

	/**
	 * @return the industrialCode
	 */
	public String getIndustryCode() {
		return industryCode;
	}

	/**
	 * @param industryCode the industrialCode to set
	 */
	public void setIndustryCode(String industryCode) {
		this.industryCode = industryCode;
	}

	/**
	 * @return the industrialCodeTypeCode
	 */
	public Long getIndustryCodeTypeCode() {
		return industryCodeTypeCode;
	}

	/**
	 * @param industryCodeTypeCode the industrialCodeTypeCode to set
	 */
	public void setIndustryCodeTypeCode(Long industryCodeTypeCode) {
		this.industryCodeTypeCode = industryCodeTypeCode;
	}

	/**
	 * @return the industrialCodeGroupLvelCode
	 */
	public Long getIndustryCodeGroupLvelCode() {
		return industryCodeGroupLvelCode;
	}

	/**
	 * @param industrialCodeGroupLvelCode the industrialCodeGroupLvelCode to set
	 */
	public void setIndustryCodeGroupLvelCode(Long industryCodeGroupLvelCode) {
		this.industryCodeGroupLvelCode = industryCodeGroupLvelCode;
	}

	/**
	 * @return the industryCodeDescription
	 */
	public String getIndustryCodeDescription() {
		return industryCodeDescription;
	}

	/**
	 * @param industryCodeDescription the industryCodeDescription to set
	 */
	public void setIndustryCodeDescription(String industryCodeDescription) {
		this.industryCodeDescription = industryCodeDescription;
	}

	/**
	 * @return the industryCrosswalkDescription
	 */
	public String getIndustryCrosswalkDescription() {
		return industryCrosswalkDescription;
	}

	/**
	 * @param industryCrosswalkDescription the industryCrosswalkDescription to set
	 */
	public void setIndustryCrosswalkDescription(String industryCrosswalkDescription) {
		this.industryCrosswalkDescription = industryCrosswalkDescription;
	}

	/**
	 * @return the languageCode
	 */
	public Long getLanguageCode() {
		return languageCode;
	}

	/**
	 * @param languageCode the languageCode to set
	 */
	public void setLanguageCode(Long languageCode) {
		this.languageCode = languageCode;
	}

	/**
	 * @return the languageDescription
	 */
	public String getLanguageDescription() {
		return languageDescription;
	}

	/**
	 * @param languageDescription the languageDescription to set
	 */
	public void setLanguageDescription(String languageDescription) {
		this.languageDescription = languageDescription;
	}

	/**
	 * @return the codeTypeCodeDescription
	 */
	public String getCodeTypeCodeDescription() {
		return codeTypeCodeDescription;
	}

	/**
	 * @param codeTypeCodeDescription the codeTypeCodeDescription to set
	 */
	public void setCodeTypeCodeDescription(String codeTypeCodeDescription) {
		this.codeTypeCodeDescription = codeTypeCodeDescription;
	}

	
	/**
	 * @return the fromIndustryCodeId
	 */
	public Long getFromIndustryCodeId() {
		return fromIndustryCodeId;
	}

	/**
	 * @param fromIndustryCodeId the fromIndustryCodeId to set
	 */
	public void setFromIndustryCodeId(Long fromIndustryCodeId) {
		this.fromIndustryCodeId = fromIndustryCodeId;
	}

	/**
	 * @return the toIndustryCodeId
	 */
	public Long getToIndustryCodeId() {
		return toIndustryCodeId;
	}

	/**
	 * @param toIndustryCodeId the toIndustryCodeId to set
	 */
	public void setToIndustryCodeId(Long toIndustryCodeId) {
		this.toIndustryCodeId = toIndustryCodeId;
	}

	/**
	 * @return the crosswalkIndustryCode
	 */
	public String getCrosswalkIndustryCode() {
		return crosswalkIndustryCode;
	}

	/**
	 * @param crosswalkIndustryCode the crosswalkIndustryCode to set
	 */
	public void setCrosswalkIndustryCode(String crosswalkIndustryCode) {
		this.crosswalkIndustryCode = crosswalkIndustryCode;
	}

	/**
	 * @return the crosswalkIndustryDescription
	 */
	public String getCrosswalkIndustryDescription() {
		return crosswalkIndustryDescription;
	}

	/**
	 * @param crosswalkIndustryDescription the crosswalkIndustryDescription to set
	 */
	public void setCrosswalkIndustryDescription(String crosswalkIndustryDescription) {
		this.crosswalkIndustryDescription = crosswalkIndustryDescription;
	}

	/**
	 * @return the preferredMapIndicator
	 */
	public Integer getPreferredMapIndicator() {
		return preferredMapIndicator;
	}

	/**
	 * @param preferredMapIndicator the preferredMapIndicator to set
	 */
	public void setPreferredMapIndicator(Integer preferredMapIndicator) {
		this.preferredMapIndicator = preferredMapIndicator;
	}

	/**
	 * @return the crosswalkCodeTypeCode
	 */
	public Long getCrosswalkCodeTypeCode() {
		return crosswalkCodeTypeCode;
	}

	/**
	 * @param crosswalkCodeTypeCode the crosswalkCodeTypeCode to set
	 */
	public void setCrosswalkCodeTypeCode(Long crosswalkCodeTypeCode) {
		this.crosswalkCodeTypeCode = crosswalkCodeTypeCode;
	}

	/**
	 * @return the industryCodeDescriptions
	 */
	public List<IndustryCodeDescription> getIndustryCodeDescriptions() {
		return industryCodeDescriptions;
	}

	/**
	 * @param industryCodeDescriptions the industryCodeDescriptions to set
	 */
	public void setIndustryCodeDescriptions(
			List<IndustryCodeDescription> industryCodeDescriptions) {
		this.industryCodeDescriptions = industryCodeDescriptions;
	}

	/**
	 * @return the industryCodeMaps
	 */
	public List<IndustryCodeMap> getIndustryCodeMaps() {
		return industryCodeMaps;
	}

	/**
	 * @param industryCodeMaps the industryCodeMaps to set
	 */
	public void setIndustryCodeMaps(List<IndustryCodeMap> industryCodeMaps) {
		this.industryCodeMaps = industryCodeMaps;
	}
	
	/**
	 * @return the groupLevelDescription
	 */
	public String getGroupLevelDescription() {
		return groupLevelDescription;
	}

	/**
	 * @param groupLevelDescription the groupLevelDescription to set
	 */
	public void setGroupLevelDescription(String groupLevelDescription) {
		this.groupLevelDescription = groupLevelDescription;
	}

		
	/**
	 * @return the changeIndicatorList
	 */
	public List<String> getChangeIndicatorList() {
		return changeIndicatorList;
	}

	/**
	 * @param changeIndicatorList the changeIndicatorList to set
	 */
	public void setChangeIndicatorList(List<String> changeIndicatorList) {
		this.changeIndicatorList = changeIndicatorList;
	}

	/**
	 * @return the industryCodeList
	 */
	public List<String> getIndustryCodeList() {
		return industryCodeList;
	}

	/**
	 * @param industryCodeList the industryCodeList to set
	 */
	public void setIndustryCodeList(List<String> industryCodeList) {
		this.industryCodeList = industryCodeList;
	}
	
	/**
	 * @return the industryCodeIdBulk
	 */
	public String getIndustryCodeIdBulk() {
		return industryCodeIdBulk;
	}

	/**
	 * @param industryCodeIdBulk the industryCodeIdBulk to set
	 */
	public void setIndustryCodeIdBulk(String industryCodeIdBulk) {
		this.industryCodeIdBulk = industryCodeIdBulk;
	}
	
	
	
	/**
	 * @return the industryCodeDescIdBulk
	 */
	public Long getIndustryCodeDescIdBulk() {
		return industryCodeDescIdBulk;
	}

	/**
	 * @param industryCodeDescIdBulk the industryCodeDescIdBulk to set
	 */
	public void setIndustryCodeDescIdBulk(Long industryCodeDescIdBulk) {
		this.industryCodeDescIdBulk = industryCodeDescIdBulk;
	}

	
	
	/**
	 * @return the writScriptCD
	 */
	public Long getWritScriptCD() {
		return writScriptCD;
	}

	/**
	 * @param writScriptCD the writScriptCD to set
	 */
	public void setWritScriptCD(Long writScriptCD) {
		this.writScriptCD = writScriptCD;
	}

	/**
	 * @return the descLenCD
	 */
	public Long getDescLenCD() {
		return descLenCD;
	}

	/**
	 * @param descLenCD the descLenCD to set
	 */
	public void setDescLenCD(Long descLenCD) {
		this.descLenCD = descLenCD;
	}
	
	

	/**
	 * @return the errorCD
	 */
	public String getErrorCD() {
		return errorCD;
	}

	/**
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(String errorCD) {
		this.errorCD = errorCD;
	}
	
	

	/**
	 * @return the induCodeIdInDescBulk
	 */
	public String getInduCodeIdInDescBulk() {
		return induCodeIdInDescBulk;
	}

	/**
	 * @param induCodeIdInDescBulk the induCodeIdInDescBulk to set
	 */
	public void setInduCodeIdInDescBulk(String induCodeIdInDescBulk) {
		this.induCodeIdInDescBulk = induCodeIdInDescBulk;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "IndustryCode [industryCodeId=" + industryCodeId
				+ ", industryCode=" + industryCode + ", industryCodeTypeCode="
				+ industryCodeTypeCode 
				+ ", industryCodeGroupLvelCode=" + industryCodeGroupLvelCode
				+ ", industryCodeDescriptions=" + industryCodeDescriptions
				+ ", industryCodeMaps=" + industryCodeMaps
				+ ", industryCodeDescription=" + industryCodeDescription
				+ ", industryCrosswalkDescription="
				+ industryCrosswalkDescription + ", languageCode="
				+ languageCode + ", languageDescription=" + languageDescription
				+ ", codeTypeCodeDescription=" + codeTypeCodeDescription
				+ ", fromIndustryCodeId=" + fromIndustryCodeId
				+ ", toIndustryCodeId=" + toIndustryCodeId
				+ ", crosswalkIndustryCode=" + crosswalkIndustryCode
				+ ", crosswalkIndustryDescription="
				+ crosswalkIndustryDescription + ", preferredMapIndicator="
				+ preferredMapIndicator + ", crosswalkCodeTypeCode="
				+ crosswalkCodeTypeCode + "]";
	}
	
	/**
	 * @return the toDescLenCD
	 */
	public Long getToDescLenCD() {
		return toDescLenCD;
	}

	/**
	 * @param toDescLenCD the toDescLenCD to set
	 */
	public void setToDescLenCD(Long toDescLenCD) {
		this.toDescLenCD = toDescLenCD;
	}

	/**
	 * @param descLenCdDescription the descLenCdDescription to set
	 */
	public void setDescLenCdDescription(String descLenCdDescription) {
		this.descLenCdDescription = descLenCdDescription;
	}

	/**
	 * @return the descLenCdDescription
	 */
	public String getDescLenCdDescription() {
		return descLenCdDescription;
	}

	/**
	 * @param toDescLenCdDescription the toDescLenCdDescription to set
	 */
	public void setToDescLenCdDescription(String toDescLenCdDescription) {
		this.toDescLenCdDescription = toDescLenCdDescription;
	}

	/**
	 * @return the toDescLenCdDescription
	 */
	public String getToDescLenCdDescription() {
		return toDescLenCdDescription;
	}

}
