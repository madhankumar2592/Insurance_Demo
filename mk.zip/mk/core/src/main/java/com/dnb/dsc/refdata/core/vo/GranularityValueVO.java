
/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;
import java.util.List;

import com.dnb.dsc.refdata.core.entity.Audit;


public class GranularityValueVO extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	

	private Long scoreTypeCode;
	
	
	private List<GranularityDetailVO> granularityDetailVO;
		
	private Long scoreTypeId;
	/**
	 * @return the scoreTypeId
	 */
	public Long getScoreTypeId() {
		return scoreTypeId;
	}
	/**
	 * @param scoreTypeId the scoreTypeId to set
	 */
	public void setScoreTypeId(Long scoreTypeId) {
		this.scoreTypeId = scoreTypeId;
	}
	/**
	 * @return the scoreTypeCode
	 */
	public Long getScoreTypeCode() {
		return scoreTypeCode;
	}
	/**
	 * @param scoreTypeCode the scoreTypeCode to set
	 */
	public void setScoreTypeCode(Long scoreTypeCode) {
		this.scoreTypeCode = scoreTypeCode;
	}
	/**
	 * @return the granularityDetailVO
	 */
	public List<GranularityDetailVO> getGranularityDetailVO() {
		return granularityDetailVO;
	}
	/**
	 * @param granularityDetailVO the granularityDetailVO to set
	 */
	public void setGranularityDetailVO(List<GranularityDetailVO> granularityDetailVO) {
		this.granularityDetailVO = granularityDetailVO;
	}
	
}
