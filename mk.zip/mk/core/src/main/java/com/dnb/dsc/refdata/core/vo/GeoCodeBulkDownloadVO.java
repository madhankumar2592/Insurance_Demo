package com.dnb.dsc.refdata.core.vo;

public class GeoCodeBulkDownloadVO {
	
	private String geoFileType; 
    private Long countryCode; 
    private Long[] geoUnitTypeList; 
    private Long provinceCode; 
    private Long countyCode; 
    private Long cityCode; 
    private String postalCode; 
    private Long[] geoNameTypeList; 
    private Long[] languageList; 
    private Long[] geoCodeTypeList;
    private Long uiBlkDwnldId;
    private String fileName;
    private String geoUnitHirarchies;
    private Long prntTypCd;
    private Long chldTypCd;
	/**
	 * @return the prntTypCd
	 */
	public Long getPrntTypCd() {
		return prntTypCd;
	}
	/**
	 * @param prntTypCd the prntTypCd to set
	 */
	public void setPrntTypCd(Long prntTypCd) {
		this.prntTypCd = prntTypCd;
	}
	/**
	 * @return the chldTypCd
	 */
	public Long getChldTypCd() {
		return chldTypCd;
	}
	/**
	 * @param chldTypCd the chldTypCd to set
	 */
	public void setChldTypCd(Long chldTypCd) {
		this.chldTypCd = chldTypCd;
	}
	/**
	 * @return the geoFileType
	 */
	public String getGeoFileType() {
		return geoFileType;
	}
	/**
	 * @param geoFileType the geoFileType to set
	 */
	public void setGeoFileType(String geoFileType) {
		this.geoFileType = geoFileType;
	}
	/**
	 * @return the countryCode
	 */
	public Long getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(Long countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * @return the geoUnitList
	 */
	public Long[] getGeoUnitTypeList() {
		return geoUnitTypeList;
	}
	/**
	 * @param geoUnitList the geoUnitList to set
	 */
	public void setGeoUnitTypeList(Long[] geoUnitTypeList) {
		this.geoUnitTypeList = geoUnitTypeList;
	}
	/**
	 * @return the provinceCode
	 */
	public Long getProvinceCode() {
		return provinceCode;
	}
	/**
	 * @param provinceCode the provinceCode to set
	 */
	public void setProvinceCode(Long provinceCode) {
		this.provinceCode = provinceCode;
	}
	/**
	 * @return the countyCode
	 */
	public Long getCountyCode() {
		return countyCode;
	}
	/**
	 * @param countyCode the countyCode to set
	 */
	public void setCountyCode(Long countyCode) {
		this.countyCode = countyCode;
	}
	/**
	 * @return the cityCode
	 */
	public Long getCityCode() {
		return cityCode;
	}
	/**
	 * @param cityCode the cityCode to set
	 */
	public void setCityCode(Long cityCode) {
		this.cityCode = cityCode;
	}
	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}
	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	/**
	 * @return the geoNameTypeList
	 */
	public Long[] getGeoNameTypeList() {
		return geoNameTypeList;
	}
	/**
	 * @param geoNameTypeList the geoNameTypeList to set
	 */
	public void setGeoNameTypeList(Long[] geoNameTypeList) {
		this.geoNameTypeList = geoNameTypeList;
	}
	/**
	 * @return the languageList
	 */
	public Long[] getLanguageList() {
		return languageList;
	}
	/**
	 * @param languageList the languageList to set
	 */
	public void setLanguageList(Long[] languageList) {
		this.languageList = languageList;
	}
	/**
	 * @return the geoCodeTypeList
	 */
	public Long[] getGeoCodeTypeList() {
		return geoCodeTypeList;
	}
	/**
	 * @param geoCodeTypeList the geoCodeTypeList to set
	 */
	public void setGeoCodeTypeList(Long[] geoCodeTypeList) {
		this.geoCodeTypeList = geoCodeTypeList;
	}
	/**
	 * @param uiBlkDwnldId the uiBlkDwnldId to set
	 */
	public void setUiBlkDwnldId(Long uiBlkDwnldId) {
		this.uiBlkDwnldId = uiBlkDwnldId;
	}
	/**
	 * @return the uiBlkDwnldId
	 */
	public Long getUiBlkDwnldId() {
		return uiBlkDwnldId;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @return the geoUnitHirarchies
	 */
	public String getGeoUnitHirarchies() {
		return geoUnitHirarchies;
	}
	/**
	 * @param geoUnitHirarchies the geoUnitHirarchies to set
	 */
	public void setGeoUnitHirarchies(String geoUnitHirarchies) {
		this.geoUnitHirarchies = geoUnitHirarchies;
		if( geoUnitHirarchies!=null &&  geoUnitHirarchies.length()!=0 ){			
			String typList[]=geoUnitHirarchies.split(":");
			setPrntTypCd(new Long(typList[0]));
			setChldTypCd(new Long(typList[1]));
		}
		//System.out.println(getPrntTypCd());
		//System.out.println(getChldTypCd());
	}
	
	
	


}
