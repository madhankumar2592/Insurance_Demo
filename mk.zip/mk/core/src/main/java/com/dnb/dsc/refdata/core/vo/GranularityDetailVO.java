package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;

import com.dnb.dsc.refdata.core.entity.Audit;


public class GranularityDetailVO extends Audit implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 1L;

	private Long granularityTypeCode;
	
	private Long scoreTypeId;
	
	private Long granularityTypeId;
	
	/**
	 * @return the granularityTypeId
	 */
	public Long getGranularityTypeId() {
		return granularityTypeId;
	}

	/**
	 * @param granularityTypeId the granularityTypeId to set
	 */
	public void setGranularityTypeId(Long granularityTypeId) {
		this.granularityTypeId = granularityTypeId;
	}

	/**
	 * @param scoreTypeCode the scoreTypeCode to set
	 */
	public void setScoreTypeCode(Long granularityTypeId) {
		this.granularityTypeId = granularityTypeId;
	}

	/**
	 * @return the scoreTypeId
	 */
	public Long getScoreTypeId() {
		return scoreTypeId;
	}

	/**
	 * @param scoreTypeId the scoreTypeId to set
	 */
	public void setScoreTypeId(Long scoreTypeId) {
		this.scoreTypeId = scoreTypeId;
	}

	/**
	 * @return the granularityTypeCode
	 */
	public Long getGranularityTypeCode() {
		return granularityTypeCode;
	}

	/**
	 * @param granularityTypeCode the granularityTypeCode to set
	 */
	public void setGranularityTypeCode(Long granularityTypeCode) {
		this.granularityTypeCode = granularityTypeCode;
	}
		
}
