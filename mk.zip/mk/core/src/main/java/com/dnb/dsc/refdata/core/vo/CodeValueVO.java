/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.vo;

import java.io.Serializable;

/**
 * This class used as an value object class for the CodeValueVO. The class
 * will store the code values for all the SCoTS elements.
 *
 * @author Cognizant
 * @version last updated : Jan 25, 2011
 * @see
 *
 */
public class CodeValueVO implements Serializable {

	private static final long serialVersionUID = 8993265291802855778L;
	/**
	 * The code attribute
	 */
	private Long code;
	/**
	 * The value attribute
	 */
	private String value;
	/**
	 * The description attribute
	 */
	private String description;

	public CodeValueVO(){}

	/**
	 * @param code
	 * @param value
	 * @param description
	 */
	public CodeValueVO(Long code, String value, String description) {
		this.code = code;
		this.value = value;
		this.description = description;
	}

	/**
	 * @param code
	 * @param value
	 * @param description
	 */
	public CodeValueVO(Long code, String value) {
		this.code = code;
		this.value = value;

	}
	/**
	 * @return the code
	 */
	public Long getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(Long code) {
		this.code = code;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CodeValueVO [code=" + code + ", value=" + value
				+ ", description=" + description + "]";
	}
}
