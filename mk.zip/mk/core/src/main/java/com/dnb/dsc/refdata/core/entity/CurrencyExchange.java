/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the Currency Exchange. The class will
 * have a direct mapping toe DB table crcy_exch.
 * 
 * @author Cognizant
 * @version last updated : Feb 29, 2012
 * @see
 * 
 */
@Entity
@Table(name = "CRCY_EXCH")
@NamedQueries({
        @NamedQuery(name = "CurrencyExchange.retrieveCurrencyExchangeByCurrencyExchangeId", query = "SELECT crcy FROM CurrencyExchange crcy where crcy.currencyExchangeId = :currencyExchangeId"),
		@NamedQuery(name = "CurrencyExchange.retrieveCurrencyExchangeByTrackingId", query = "SELECT crcy from CurrencyExchange crcy, WorkflowTracking w where crcy.currencyExchangeId = w.domainIdentifier and w.trackingId = :trackingId"),
		@NamedQuery(name = "CurrencyExchange.retrieveAllDataProviders", query = "SELECT distinct new CurrencyExchange(c.dataProviderCode, t.codeValueShortDescription) FROM CurrencyExchange c, CodeValueText t where c.dataProviderCode = t.codeValueId and t.languageCode = :langCode"),
		@NamedQuery(name = "CurrencyExchange.countCurrencyExchange", query = "SELECT count(c.currencyExchangeId) FROM CurrencyExchange c WHERE c.currencyExchangeId = :currencyExchangeId"),
		@NamedQuery(name = "CurrencyExchange.removeCurrencyExchangeById", query = "DELETE CurrencyExchange c where c.currencyExchangeId = :currencyExchangeId") })
public class CurrencyExchange extends Audit implements Serializable {

	private static final long serialVersionUID = 2L;

	@Id
	@Column(name = "CRCY_EXCH_ID")
	private Long currencyExchangeId;

	@Column(name = "FROM_CRCY_CD")
	private Long fromCurrencyCode;

	@Column(name = "TO_CRCY_CD")
	private Long toCurrencyCode;

	@Column(name = "CRCY_EXCH_DT")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date currencyExchangeDate;

	@Column(name = "CRCY_EXCH_DT_PRCN_CD")
	private Long currencyExchangeDatePrcnCode;

	@Column(name = "CRCY_EXCH_RTE")
	private Double currencyExchangeRate;

	@Column(name = "DATA_PRVD_CD")
	private Long dataProviderCode;

	@Transient
	private String fromCurrencyShortDescription;

	@Transient
	private String toCurrencyShortDescription;

	@Transient
	private String fromCurrencyFullDescription;

	@Transient
	private String toCurrencyFullDescription;

	@Transient
	private String dataProvider;

	@Transient
	private Double oldCurrencyExchangeRate;
	
	/*Added for Batch Component*/
	@Transient
	private String errorCd;

	/**
	 * Constructor
	 */
	public CurrencyExchange() {
		super();
	}

	/**
	 * @param currencyExchangeId
	 * @param fromCurrencyCode
	 * @param toCurrencyCode
	 * @param currencyExchangeDate
	 * @param currencyExchangeDatePrcnCode
	 * @param currencyExchangeRate
	 * @param dataProviderCode
	 * @param rowCreatedId
	 * @param rowCreatedTimestamp
	 * @param rowModifiedId
	 * @param rowModifiedTimestamp
	 */
	public CurrencyExchange(Long currencyExchangeId, Long fromCurrencyCode,
			Long toCurrencyCode, Date currencyExchangeDate,
			Long currencyExchangeDatePrcnCode, Double currencyExchangeRate,
			Long dataProviderCode, String createdUser,
			Date createdDate, String modifiedUser,
			Date modifiedDate) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.currencyExchangeId = currencyExchangeId;
		this.fromCurrencyCode = fromCurrencyCode;
		this.toCurrencyCode = toCurrencyCode;
		this.currencyExchangeDate = currencyExchangeDate;
		this.currencyExchangeDatePrcnCode = currencyExchangeDatePrcnCode;
		this.currencyExchangeRate = currencyExchangeRate;
		this.dataProviderCode = dataProviderCode;
	}

	/**
	 * The constructor for the retrieve functionality
	 * 
	 * @param fromCurrencyCode
	 * @param toCurrencyCode
	 * @param currencyExchangeDate
	 * @param currencyExchangeRate
	 * @param dataProviderCode
	 */
	public CurrencyExchange(Long currencyExchangeId, Long fromCurrencyCode,
			Long toCurrencyCode, Date currencyExchangeDate,
			Double currencyExchangeRate, Long currencyExchangeDatePrcnCode,
			Long dataProviderCode, String fromCurrencyShortDescription,
			String fromCurrencyFullDescription,
			String toCurrencyShortDescription,
			String toCurrencyFullDescription, String dataProvider,
			Date createdDate, String createdUser,
			Date modifiedDate, String modifiedUser) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.currencyExchangeId = currencyExchangeId;
		this.fromCurrencyCode = fromCurrencyCode;
		this.toCurrencyCode = toCurrencyCode;
		this.currencyExchangeDate = currencyExchangeDate;
		this.currencyExchangeRate = currencyExchangeRate;
		this.currencyExchangeDatePrcnCode = currencyExchangeDatePrcnCode;
		this.dataProviderCode = dataProviderCode;
		this.fromCurrencyShortDescription = fromCurrencyShortDescription;
		this.fromCurrencyFullDescription = fromCurrencyFullDescription;
		this.toCurrencyShortDescription = toCurrencyShortDescription;
		this.toCurrencyFullDescription = toCurrencyFullDescription;
		this.dataProvider = dataProvider;
	}	

	/**
	 * @param dataProviderCode
	 * @param dataProvider
	 */
	public CurrencyExchange(Long dataProviderCode, String dataProvider) {
		this.dataProviderCode = dataProviderCode;
		this.dataProvider = dataProvider;
	}

	/**
	 * @return the currencyExchangeId
	 */
	public Long getCurrencyExchangeId() {
		return currencyExchangeId;
	}

	/**
	 * @param currencyExchangeId
	 *            the currencyExchangeId to set
	 */
	public void setCurrencyExchangeId(Long currencyExchangeId) {
		this.currencyExchangeId = currencyExchangeId;
	}

	/**
	 * @return the fromCurrencyCode
	 */
	public Long getFromCurrencyCode() {
		return fromCurrencyCode;
	}

	/**
	 * @param fromCurrencyCode
	 *            the fromCurrencyCode to set
	 */
	public void setFromCurrencyCode(Long fromCurrencyCode) {
		this.fromCurrencyCode = fromCurrencyCode;
	}

	/**
	 * @return the toCurrencyCode
	 */
	public Long getToCurrencyCode() {
		return toCurrencyCode;
	}

	/**
	 * @param toCurrencyCode
	 *            the toCurrencyCode to set
	 */
	public void setToCurrencyCode(Long toCurrencyCode) {
		this.toCurrencyCode = toCurrencyCode;
	}

	/**
	 * @return the currencyExchangeDate
	 */
	public Date getCurrencyExchangeDate() {
		return currencyExchangeDate;
	}

	/**
	 * @param currencyExchangeDate
	 *            the currencyExchangeDate to set
	 */
	public void setCurrencyExchangeDate(Date currencyExchangeDate) {
		this.currencyExchangeDate = currencyExchangeDate;
	}

	/**
	 * @return the currencyExchangeDatePrcnCode
	 */
	public Long getCurrencyExchangeDatePrcnCode() {
		return currencyExchangeDatePrcnCode;
	}

	/**
	 * @param currencyExchangeDatePrcnCode
	 *            the currencyExchangeDatePrcnCode to set
	 */
	public void setCurrencyExchangeDatePrcnCode(
			Long currencyExchangeDatePrcnCode) {
		this.currencyExchangeDatePrcnCode = currencyExchangeDatePrcnCode;
	}

	/**
	 * @return the currencyExchangeRate
	 */
	public Double getCurrencyExchangeRate() {
		return currencyExchangeRate;
	}

	/**
	 * @param currencyExchangeRate
	 *            the currencyExchangeRate to set
	 */
	public void setCurrencyExchangeRate(Double currencyExchangeRate) {
		this.currencyExchangeRate = currencyExchangeRate;
	}

	/**
	 * @return the dataProviderCode
	 */
	public Long getDataProviderCode() {
		return dataProviderCode;
	}

	/**
	 * @param dataProviderCode
	 *            the dataProviderCode to set
	 */
	public void setDataProviderCode(Long dataProviderCode) {
		this.dataProviderCode = dataProviderCode;
	}

	public String getFromCurrencyShortDescription() {
		return fromCurrencyShortDescription;
	}

	public void setFromCurrencyShortDescription(
			String fromCurrencyShortDescription) {
		this.fromCurrencyShortDescription = fromCurrencyShortDescription;
	}

	public String getToCurrencyShortDescription() {
		return toCurrencyShortDescription;
	}

	public void setToCurrencyShortDescription(String toCurrencyShortDescription) {
		this.toCurrencyShortDescription = toCurrencyShortDescription;
	}

	public String getFromCurrencyFullDescription() {
		return fromCurrencyFullDescription;
	}

	public void setFromCurrencyFullDescription(
			String fromCurrencyFullDescription) {
		this.fromCurrencyFullDescription = fromCurrencyFullDescription;
	}

	public String getToCurrencyFullDescription() {
		return toCurrencyFullDescription;
	}

	public void setToCurrencyFullDescription(String toCurrencyFullDescription) {
		this.toCurrencyFullDescription = toCurrencyFullDescription;
	}

	public String getDataProvider() {
		return dataProvider;
	}

	public void setDataProvider(String dataProvider) {
		this.dataProvider = dataProvider;
	}

	/**
	 * @return the oldCurrencyExchangeRate
	 */
	public Double getOldCurrencyExchangeRate() {
		return oldCurrencyExchangeRate;
	}

	/**
	 * @param oldCurrencyExchangeRate the oldCurrencyExchangeRate to set
	 */
	public void setOldCurrencyExchangeRate(Double oldCurrencyExchangeRate) {
		this.oldCurrencyExchangeRate = oldCurrencyExchangeRate;
	}

	/**
	 * @return the errorCd
	 */
	public String getErrorCd() {
		return errorCd;
	}
	
	/**
	 * @param errorCd the errorCd to set
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CurrencyExchange [fromCurrencyCode=" + fromCurrencyCode
				+ ", toCurrencyCode=" + toCurrencyCode
				+ ", currencyExchangeDate=" + currencyExchangeDate
				+ ", currencyExchangeRate=" + currencyExchangeRate
				+ ", dataProviderCode=" + dataProviderCode + "]";
	}
}
