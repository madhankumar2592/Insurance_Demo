/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.dnb.dsc.refdata.core.constant.RefDataPropertiesConstants;

/**
 * This class used as an entity class for the Code Value Association. The class  
 * will have a direct mapping toe DB table cd_val_assn .
 * 
 * @author Cognizant
 * @version last updated : Mar 29, 2012
 * @see
 * 
 */
@Entity
@Table(name = "CD_VAL_ASSN")
@NamedQueries({
	@NamedQuery(name = "CodeValueAssociation.removeCodeValueAssociationsByTableId", query = "DELETE FROM CodeValueAssociation a where a.codeValueAssociationId in (:associationIds) "), 
	@NamedQuery(name = "CodeValueAssociation.retrieveParentCodeValueAssociations", query = "SELECT distinct new CodeValueAssociation(ct.codeTableId, ct.codeTableName, cva.parentCodeValueId, cva.childCodeValueId, cvt.codeValueDescription, cva.codeValueAssociationId, cva.effectiveDate, cva.expirationDate) from CodeTable ct, CodeValue cv, CodeValueAssociation cva, CodeValueText cvt WHERE cva.childCodeValueId = :childCodeValueId and cva.parentCodeValueId = cv.codeValueId and cv.codeTableId = ct.codeTableId and cva.parentCodeValueId = cvt.codeValueId and cvt.languageCode = 39"),
	@NamedQuery(name = "CodeValueAssociation.retrieveChildCodeValueAssociations", query = "SELECT distinct new CodeValueAssociation(ct.codeTableId, ct.codeTableName, cva.parentCodeValueId, cva.childCodeValueId, cvt.codeValueDescription, cva.codeValueAssociationId, cva.effectiveDate, cva.expirationDate) from CodeTable ct, CodeValue cv, CodeValueAssociation cva, CodeValueText cvt WHERE cva.parentCodeValueId = :parentCodeValueId and cva.childCodeValueId = cv.codeValueId and cv.codeTableId = ct.codeTableId and cva.childCodeValueId = cvt.codeValueId and cvt.languageCode = 39")
	/*@NamedQuery(name = "CodeValueAssociation.countScotsRelationship", query="SELECT * FROM soruiconfig.CodeValueAssociation where   parentCodeValueId in (SELECT codeValueId from sorusr.CodeValue where codeTableId=:parentTableId) and childCodeValueId in (SELECT codeValueId from sorusr.CodeValue where codeTableId=:childTableId)"),
	@NamedQuery(name = "CodeValueAssociation.modifieduser",query="SELECT modifiedUser from soruiconfig.CodeValueAssociation where   parentCodeValueId in (SELECT codeValueId from sorusr.CodeValue where codeTableId=:parentTableId) and childCodeValueId in (SELECT codeValueId from sorusr.CodeValue where codeTableId=:childTableId)")*/
})
public class CodeValueAssociation extends Audit {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "CD_VAL_ASSN_ID")
	private Long codeValueAssociationId;
	
	@Column(name = "PRNT_CD_VAL_ID")
	private Long parentCodeValueId;
	
	@Column(name = "CHLD_CD_VAL_ID")
	private Long childCodeValueId;
	
	@Column(name = "EFFV_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date effectiveDate;
	
	@Column(name = "EXPN_DT")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = RefDataPropertiesConstants.DEFAULT_DATE_TIME_FORMAT)
	private Date expirationDate;
	
	@Transient
	private Long parentCodeTableId;
	
	@Transient
	private String parentCodeTableName;
	
	@Transient
	private String codeValueDescription;
	
	@Transient
	private Long childCodeTableId;

	/**
	 * Empty Constructor.
	 */
	public CodeValueAssociation() {
		super();
		this.effectiveDate = new Date();
	}

	/**
	 * @param codeValueAssociationId
	 * @param parentCodeValueId
	 * @param childCodeValueId
	 * @param effectiveDate
	 * @param expirationDate
	 * @param createdUser
	 * @param createdDate
	 * @param modifiedUser
	 * @param modifiedDate
	 */
	public CodeValueAssociation(Long codeValueAssociationId,
			Long parentCodeValueId, Long childCodeValueId, Date effectiveDate,
			Date expirationDate, String createdUser, Date createdDate,
			String modifiedUser, Date modifiedDate) {
		super(createdUser, createdDate, modifiedUser, modifiedDate);
		this.codeValueAssociationId = codeValueAssociationId;
		this.parentCodeValueId = parentCodeValueId;
		this.childCodeValueId = childCodeValueId;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
	}

	public CodeValueAssociation(
			Long codeTableId, String codeTableName, 
			Long parentCodeValueId, Long childCodeValueId, 
			String codeValueDescription, Long codeValueAssociationId, 
			Date effectiveDate, Date expirationDate){
		this.parentCodeTableId = codeTableId;
		this.parentCodeTableName = codeTableName;
		this.parentCodeValueId = parentCodeValueId;
		this.childCodeValueId = childCodeValueId;
		this.codeValueDescription = codeValueDescription;
		this.codeValueAssociationId = codeValueAssociationId;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the codeValueAssociationId
	 */
	public Long getCodeValueAssociationId() {
		return codeValueAssociationId;
	}

	/**
	 * @param codeValueAssociationId the codeValueAssociationId to set
	 */
	public void setCodeValueAssociationId(Long codeValueAssociationId) {
		this.codeValueAssociationId = codeValueAssociationId;
	}

	/**
	 * @return the parentCodeValueId
	 */
	public Long getParentCodeValueId() {
		return parentCodeValueId;
	}

	/**
	 * @param parentCodeValueId the parentCodeValueId to set
	 */
	public void setParentCodeValueId(Long parentCodeValueId) {
		this.parentCodeValueId = parentCodeValueId;
	}

	/**
	 * @return the childCodeValueId
	 */
	public Long getChildCodeValueId() {
		return childCodeValueId;
	}

	/**
	 * @param childCodeValueId the childCodeValueId to set
	 */
	public void setChildCodeValueId(Long childCodeValueId) {
		this.childCodeValueId = childCodeValueId;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the parentCodeTableId
	 */
	public Long getParentCodeTableId() {
		return parentCodeTableId;
	}

	/**
	 * @param parentCodeTableId the parentCodeTableId to set
	 */
	public void setParentCodeTableId(Long parentCodeTableId) {
		this.parentCodeTableId = parentCodeTableId;
	}

	/**
	 * @return the childCodeTableId
	 */
	public Long getChildCodeTableId() {
		return childCodeTableId;
	}

	/**
	 * @param childCodeTableId the childCodeTableId to set
	 */
	public void setChildCodeTableId(Long childCodeTableId) {
		this.childCodeTableId = childCodeTableId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CodeValueAssociation [codeValueAssociationId="
				+ codeValueAssociationId + ", parentCodeValueId="
				+ parentCodeValueId + ", childCodeValueId=" + childCodeValueId
				+ ", effectiveDate=" + effectiveDate + ", expirationDate="
				+ expirationDate + "]";
	}

	/**
	 * @return the parentCodeTableName
	 */
	public String getParentCodeTableName() {
		return parentCodeTableName;
	}

	/**
	 * @param parentCodeTableName the parentCodeTableName to set
	 */
	public void setParentCodeTableName(String parentCodeTableName) {
		this.parentCodeTableName = parentCodeTableName;
	}

	/**
	 * @return the codeValueDescription
	 */
	public String getCodeValueDescription() {
		return codeValueDescription;
	}

	/**
	 * @param codeValueDescription the codeValueDescription to set
	 */
	public void setCodeValueDescription(String codeValueDescription) {
		this.codeValueDescription = codeValueDescription;
	}
}
