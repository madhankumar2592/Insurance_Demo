/*
 * D&B PROPRIETARY/CONFIDENTIAL.
 * Copyright � 2012, Dun & Bradstreet. All rights reserved.  
 * Unauthorized use, review, disclosure is strictly prohibited and may be unlawful.
 */
package com.dnb.dsc.refdata.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * This class used as an entity class for the WorkFlow Tracking. The class  
 * will have a direct mapping toe DB table workflow_tracking.
 * 
 * @author Cognizant
 * @version last updated : Feb 19, 2012
 * @see
 * 
 */
@Entity
@Table(name = "WORKFLOW_TRACKING")
public class WorkflowTracking implements Serializable {
	
	private static final long serialVersionUID = 5835936824608829920L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trackingIdGenerator")
	@SequenceGenerator(name = "trackingIdGenerator", sequenceName="soruiconfig.WORKFLOW_TRACKING_SEQ" , allocationSize=1)
	@Column(name = "TRACKING_ID")
	private Long trackingId;

	@Column(name = "DOMAIN_NME")
	private String domainName;
	
	@Column(name = "DOMAIN_ID")
	private Long domainIdentifier;

	/**
	 * @param trackingId
	 * @param domainName
	 * @param domianIdentifier
	 */
	public WorkflowTracking(Long trackingId, String domainName,
			Long domianIdentifier) {
		this.trackingId = trackingId;
		this.domainName = domainName;
		this.domainIdentifier = domianIdentifier;
	}
	
	public WorkflowTracking() {
		super();
	}

	/**
	 * @return the trackingId
	 */
	public Long getTrackingId() {
		return trackingId;
	}

	/**
	 * @param trackingId the trackingId to set
	 */
	public void setTrackingId(Long trackingId) {
		this.trackingId = trackingId;
	}

	/**
	 * @return the domainName
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * @param domainName the domainName to set
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @return the domianIdentifier
	 */
	public Long getDomianIdentifier() {
		return domainIdentifier;
	}

	/**
	 * @param domianIdentifier the domianIdentifier to set
	 */
	public void setDomianIdentifier(Long domianIdentifier) {
		this.domainIdentifier = domianIdentifier;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WorkflowTracking [trackingId=" + trackingId + ", domainName="
				+ domainName + ", domianIdentifier=" + domainIdentifier + "]";
	}	
}
