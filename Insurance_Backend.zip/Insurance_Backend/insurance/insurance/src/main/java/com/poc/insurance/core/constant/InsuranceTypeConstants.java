package com.poc.insurance.core.constant;

public class InsuranceTypeConstants {

	public static final double BASE_PREMIUM = 5000L;
	
	public static final double AGE_GROUP_ONE = 0.1;

	public static final double AGE_GROUP_TWO = 0.1;


	
	public static final double GENDER_MALE = 0.02;

	public static final double HEALTH_ISSUE = 0.01;
	
	public static final double HABITS = 0.03;

	
	


	
	

	



}
