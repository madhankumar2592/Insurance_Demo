/**
 * 
 */
package com.insurance.payment.service;

import com.insurance.payment.core.entity.User;

/**
 * This is used as the services interface for the Insurance Payment operations
 *
 * @author Madhan
 * @version 
 * @see
 *
 */
public interface PaymentService {
	

public String payment(User user);

}
