/**
 * 
 */
package com.insurance.payment.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.payment.core.entity.User;
import com.insurance.payment.dao.PaymentDAO;

/**
 * This is used as the services class for the payment services 
 *
 * @author Madhan
 * @version 
 * @see
 *
 */

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	PaymentDAO paymentDAO;
	
	
	/**
	 * 
	 * The method is to pay premium amount . The user will enter userDetails
	 * to  find the insurance premium and the data will be passed to this method 
	 * The method is invoked on when the user clicks pay premium button.
	 * 
	 * @param User user
	 * @return status
	 */	

	public String payment(User user) {	

		return 	paymentDAO.payUser(user);
	}

}
